package com.app.basketiodriver.ui.earning.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.earning.monthly.ReportView
import com.app.basketiodriver.data.model.api.response.earning.payout.PayoutCreditData
import com.app.basketiodriver.databinding.ItemOrderEarningsBinding
import com.app.basketiodriver.databinding.ItemPayoutCreditBinding
import com.app.basketiodriver.ui.base.DataListAdapter
import com.app.basketiodriver.ui.base.DataViewHolder
import com.app.basketiodriver.utils.CommonUtils
import com.app.basketiodriver.utils.DateUtils
import com.app.basketiodriver.utils.OnItemClickedListener
import java.util.*

class OrderPayoutCreditAdapter(val mContext : Context, val listener: OnItemClickedListener<PayoutCreditData>) :
    DataListAdapter<PayoutCreditData, ItemPayoutCreditBinding>() {
    override fun createBinding(inflater: LayoutInflater, parent: ViewGroup? ): ItemPayoutCreditBinding {
        return DataBindingUtil.inflate(inflater, R.layout.item_payout_credit, parent, false)
    }

    override fun onBindViewHolder(holder: DataViewHolder<ItemPayoutCreditBinding>, position: Int) {
        super.onBindViewHolder(holder, position)
        holder.binding.root.setOnClickListener { listener.onClicked(holder.binding.payoutItem!!) }
    }

    override fun bind(binding: ItemPayoutCreditBinding?, item: PayoutCreditData) {
        binding!!.payoutItem = item

        binding.txtPayMethod.text = item.payment_method_name
        binding.txtPayStatus.text = item.status

        if (item.created_on != "")
            binding.txtDate.text = DateUtils.getMMDDDate(item.created_on)

        binding.txtPayType.text = item.payment_type
        binding.txtPayValue.text = String.format(Locale("en"), "%s %s", PreferenceManager.currency, item.amount)
        CommonUtils.setBalanceTextColor(binding.txtPayValue, "" + item.amount)
    }
}