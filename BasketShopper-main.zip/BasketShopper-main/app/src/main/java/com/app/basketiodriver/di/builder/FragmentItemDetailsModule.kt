package com.app.basketiodriver.di.builder

import com.app.basketiodriver.ui.dialogs.*
import dagger.Module
import dagger.android.ContributesAndroidInjector


@Module
abstract class  FragmentItemDetailsModule {
    @ContributesAndroidInjector
    abstract fun contributeCanNotFindItemDialogFragment(): CanNotFindItemDialogFragment

    @ContributesAndroidInjector
    abstract fun contributeFlagItemDialogFragment(): FlagItemDialogFragment

    @ContributesAndroidInjector
    abstract fun contributeMessageBottomSheetFragment(): MessageBottomSheetFragment

    @ContributesAndroidInjector
    abstract fun contributeRefundDialogFragment(): RefundDialogFragment

    @ContributesAndroidInjector
    abstract fun contributeAmountDialogFragment(): AmountDialogFragment

    @ContributesAndroidInjector
    abstract fun contributeReplaceQuantityDialogFragment(): ReplaceQuantityDialogFragment

    @ContributesAndroidInjector
    abstract fun contributeIncorrectItemDialogFragment(): IncorrectItemDialogFragment
}