package com.app.basketiodriver.ui.earning.fragments


import android.app.Activity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ExpandableListView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.earning.ShopperYearlyResponse
import com.app.basketiodriver.data.model.api.response.earning.YearEarningsData
import com.app.basketiodriver.data.model.api.response.earning.YearlyBalanceReportItem
import com.app.basketiodriver.databinding.FragmentSummaryBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.earning.EarningViewModel
import com.app.basketiodriver.ui.earning.adapters.YearEarningsExpandableListAdapter
//import com.app.basketiodriver.ui.earning.adapters.YearlyBalanceReportsAdapter
import com.app.basketiodriver.ui.home.adapters.ExpandableListAdapter
import com.app.basketiodriver.utils.CommonUtils
import com.app.basketiodriver.utils.InfoHelp
import com.app.basketiodriver.utils.OnItemClickedListener
import java.util.*


/**
 * A simple [Fragment] subclass.
 */
class SummaryFragment : BaseFragment<FragmentSummaryBinding?, EarningViewModel>(),
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_summary

    override val viewModel: EarningViewModel
        get() {
            return getViewModel(baseActivity as FragmentActivity, EarningViewModel::class.java)
        }


    // Scroll Listener
    private lateinit var scrollListener: RecyclerView.OnScrollListener
    private lateinit var linearLayoutManager: LinearLayoutManager

    var isLoading : Boolean = false
    var numberOfRecord = 0 // Record count to be loaded in each api call

    var yearBalanceReportList : ArrayList<YearlyBalanceReportItem> = arrayListOf()
    var yearEarningsList : ArrayList<YearEarningsData> = arrayListOf()

//    private lateinit var yearlyBalanceAdapter : YearlyBalanceReportsAdapter

    private lateinit var parentView : View
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setTitle(getString(R.string.annual_earnings))

        parentView = view

        initView()

        // Load the year report
        getShopperYearlyBalanceReport()
    }

    // Initialize the View
    private fun initView(){

//        linearLayoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
//        viewDataBinding!!.yearEarningRecycler.layoutManager = linearLayoutManager
//        viewDataBinding!!.yearEarningRecycler.setHasFixedSize(true)

        scrollListener = object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
            }

            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                super.onScrollStateChanged(recyclerView, newState)

                val lastVisibleItemPosition = linearLayoutManager.findLastVisibleItemPosition()
                val totalItemCount = recyclerView.layoutManager!!.itemCount

                if (totalItemCount == lastVisibleItemPosition + 1) {
                    Log.d("YearlyBalance", "Loading new list...")
                    recyclerView.removeOnScrollListener(scrollListener)

                    // Load the New Balance List
                    if (numberOfRecord > 0 && !isLoading){
                        getShopperYearlyBalanceReport()
                    }
                }
            }
        }

        // Add the scroll listener
//        viewDataBinding!!.yearEarningRecycler.addOnScrollListener(scrollListener)

        // Onclick listener
//        yearlyBalanceAdapter = YearlyBalanceReportsAdapter(requireContext(), object : OnItemClickedListener<YearlyBalanceReportItem>{
//            override fun onClicked(item: YearlyBalanceReportItem) {
//                val year = item.year
//                val monthNumber = item.year
//                val monthName = item.monthName
//
//                // Go to monthly earning page
//                navigate(SummaryFragmentDirections.actionSummaryFragmentToMonthlyEarningFragment(item))
//            }
//        })

        // Show the tooltip when tap the question mark
        viewDataBinding!!.txtLbBalance.setOnClickListener{
            InfoHelp.showHelpDialog(it, baseActivity?.resources?.getString(R.string.your_current_balance)!!, baseActivity as Activity, true)
        }

    }

    // Sort earning list
    private fun sortYearEarningsList(){
        // Clear all previous data
        yearEarningsList.clear()

        // Sort the list by year
        val itemCount = yearBalanceReportList.size
        var earningData : YearEarningsData = YearEarningsData()
        for (i in 0 until itemCount) {
            val balanceItem = yearBalanceReportList[i]

            if (earningData.year == ""){
                earningData.year = balanceItem.year
                earningData.items.add(balanceItem)
            }
            else{
                if (balanceItem.year.equals(earningData.year, true)){
                    earningData.items.add(balanceItem)
                }
                else{
                    yearEarningsList.add(earningData)

                    // create new model for another year
                    earningData = YearEarningsData()
                    earningData.year = balanceItem.year
                    earningData.items.add(balanceItem)
                }
            }
        }

        if (earningData.items.size > 0){
            yearEarningsList.add(earningData)
        }

        // Refresh the list view
        val expandableListAdapter = YearEarningsExpandableListAdapter(baseActivity as Activity, yearEarningsList)
        viewDataBinding!!.yearEarningsListView.setAdapter(expandableListAdapter)
        viewDataBinding!!.yearEarningsListView.setOnGroupClickListener { _, v, groupPosition, id ->
            // do something
            false
        }

        viewDataBinding!!.yearEarningsListView.setOnChildClickListener(ExpandableListView.OnChildClickListener { parent, v, groupPosition, childPosition, id ->

            // Go to Monthly Earning
            val selectedItem = yearEarningsList[groupPosition].items[childPosition]
            navigate(SummaryFragmentDirections.actionSummaryFragmentToMonthlyEarningFragment(selectedItem))

            false
        })
    }


    // Refresh RecyclerView
    private fun refreshYearlyBalanceRecycler(){
        sortYearEarningsList()

//        viewDataBinding!!.yearEarningRecycler.adapter = yearlyBalanceAdapter
//        yearlyBalanceAdapter.replace(yearBalanceReportList)
    }

    private fun getShopperYearlyBalanceReport(){
        val c = Calendar.getInstance()
        val year = c[Calendar.YEAR]

        viewModel.getYearlyBalanceReport(year, numberOfRecord, object : HandleResponse<ShopperYearlyResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Toast.makeText(baseActivity, error?.message, Toast.LENGTH_SHORT).show()
                }else{
                    Toast.makeText(baseActivity, baseActivity!!.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }
            }

            override fun handleSuccessResponse(successResponse: ShopperYearlyResponse) {
                val data = successResponse.data
                if (data != null) {
                    // Check if account was suspended
                    if (data.isAccountSuspended){
                        viewDataBinding!!.suspendedLayout.visibility = View.VISIBLE
                    }
                    else{
                        viewDataBinding!!.suspendedLayout.visibility = View.GONE
                    }

                    // Current Balance
                    val balance = PreferenceManager.currency + " " + data.currentAccountBalance
                    viewDataBinding!!.currentBalancedText.text = balance

                    // Set color
                    CommonUtils.setBalanceTextColor(viewDataBinding!!.currentBalancedText, "" + data.currentAccountBalance)

                    if (numberOfRecord == 0){
                        yearBalanceReportList = data.yearlyBalanceReport
                    }
                    else{
                        yearBalanceReportList.addAll(data.yearlyBalanceReport)
                    }

                    // update the loaded record count
                    numberOfRecord = data.numbOfRecord

                    // Refresh the recycler view
                    if (yearBalanceReportList.size > 0){
                        refreshYearlyBalanceRecycler()
                    }
                }
                else{
                    Toast.makeText(baseActivity, successResponse.message, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }
}
