package com.app.basketiodriver.ui.earning.fragments


import android.os.Bundle
import androidx.fragment.app.Fragment
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentBatchBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.earning.EarningViewModel


/**
 * A simple [Fragment] subclass.
 */
class BatchFragment : BaseFragment<FragmentBatchBinding?, EarningViewModel>(),
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_batch

    override val viewModel: EarningViewModel
        get() {
            return getViewModel(requireActivity(), EarningViewModel::class.java)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTitle("Batch Summary #021654")

    }


}
