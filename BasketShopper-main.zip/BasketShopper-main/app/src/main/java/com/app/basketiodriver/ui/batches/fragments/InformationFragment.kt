package com.app.basketiodriver.ui.batches.fragments

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentInformationBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.home.HomeViewModel


/**
 * A simple [Fragment] subclass.
 */
class InformationFragment : BaseFragment<FragmentInformationBinding?, HomeViewModel>(),
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_information

    override val viewModel: HomeViewModel
        get() {
            return getViewModel(requireActivity(), HomeViewModel::class.java)
        }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewDataBinding?.btnBack?.setOnClickListener {
            navController()
                .navigateUp()
        }
        viewDataBinding?.btnAddress?.setOnClickListener {
            navigate(
                InformationFragmentDirections.actionInformationFragmentToDashboardMapFragment()
            )
        }


    }

}
