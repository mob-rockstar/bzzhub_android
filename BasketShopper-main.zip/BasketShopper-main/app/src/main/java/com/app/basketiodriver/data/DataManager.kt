
package com.app.basketiodriver.data

import androidx.lifecycle.MutableLiveData
import com.app.basketiodriver.data.local.db.DbHelper
import com.app.basketiodriver.data.model.api.ChatMessage
import com.app.basketiodriver.data.model.api.User
import com.app.basketiodriver.data.remote.ApiHelper

/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
interface DataManager : DbHelper, ApiHelper {

    fun setUserAsLoggedOut()
    fun updateApiHeader(userId: Int?, accessToken: String?)
    fun updateUserInfo(
            accessToken: String?,
            currentUser: User?
    )

    fun getConnectivityStateLD(): MutableLiveData<Int>
    fun getNewMessages(): MutableLiveData<ChatMessage>


    enum class LoggedInMode(val type: Int) {
        LOGGED_IN_MODE_LOGGED_OUT(0), LOGGED_IN_MODE_GOOGLE(1), LOGGED_IN_MODE_FB(2), LOGGED_IN_MODE_SERVER(3);

    }
}