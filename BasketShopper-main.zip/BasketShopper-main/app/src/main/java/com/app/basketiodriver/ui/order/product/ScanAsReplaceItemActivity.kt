package com.app.basketiodriver.ui.order.product

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.Html
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.SearchView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.app.basketiodriver.BuildConfig
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.checkout.CustomerInfo
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.model.api.response.order.CommonResponse
import com.app.basketiodriver.data.model.api.response.order.ItemResponse
import com.app.basketiodriver.data.model.api.response.order.ReplacementOrdersItemRequest
import com.app.basketiodriver.data.model.api.response.order.SimilarProduct
import com.app.basketiodriver.databinding.ActivityScanAsReplaceItemBinding
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.app.basketiodriver.ui.dialogs.AmountDialogFragment
import com.app.basketiodriver.ui.dialogs.IncorrectItemDialogFragment
import com.app.basketiodriver.ui.dialogs.ReplaceQuantityDialogFragment
import com.app.basketiodriver.ui.order.adapter.SimilarProductListAdapter
import com.app.basketiodriver.ui.order.product.ScanItem.Companion.ITEM_AMOUNT
import com.app.basketiodriver.ui.order.product.ScanItem.Companion.ITEM_WEIGHT
import com.app.basketiodriver.utils.GlideApp
import com.app.basketiodriver.utils.price.PriceConstructor
import com.app.basketiodriver.utils.price.PriceConstructorNew
import com.google.gson.Gson
import com.tbruyelle.rxpermissions2.RxPermissions
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import javax.inject.Inject

class ScanAsReplaceItemActivity : BaseActivity<ActivityScanAsReplaceItemBinding, OrderDetailsViewModel>(), AmountDialogFragment.AmountDialogOnClickListener,
//    OnScanListener,
    HasAndroidInjector {
    override val layoutId: Int
        get() = R.layout.activity_scan_as_replace_item

    override val viewModel: OrderDetailsViewModel
        get() {
            return getViewModel(OrderDetailsViewModel::class.java)
        }

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>
    override fun androidInjector() = dispatchingAndroidInjector

    // Properties
    var orderId : Long = 0
    var itemId : Long = 0
    var ordersItem : OrdersItem? = null
    var item : SimilarProduct? = null
    var info : CustomerInfo? = null
    var autoFocus : Boolean = true

    var isReplaceItem : Int = 0

    var actionFrom = 1

    var scannedBarCode : String? = null

    // Barcode picker
//    var picker : BarcodePicker?= null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (intent.extras != null){
            // get order id
            orderId = intent.getLongExtra("ARG_ORDER_OUTLET_ID", 0)

            // item id
            itemId = intent.getLongExtra("ARG_ITEM_ID", 0)

            // customer info
            info = intent.extras!!.getSerializable("ARG_INFO") as? CustomerInfo

            // similar item
            item = intent.extras!!.getSerializable("ARG_ITEM_DETAIL") as? SimilarProduct

            // orders item
            ordersItem = intent.extras!!.getSerializable("ARG_ORDER_ITEM") as? OrdersItem

            // auto focus
            autoFocus = intent.extras!!.getBoolean("ARG_AUTO_FOCUS", true)

            // action from
            actionFrom = intent.getIntExtra("ARG_ACTION_FROM", 1)


            isReplaceItem = intent.getIntExtra("ARG_IS_REPLACEMENT", 0)
        }

        // Init toolbar
        initToolBar()

        // Set the ClickListener
        setListeners()

        // Init the Barcode Reader
//        initBarcodeReader()

        // Display item information
        setDataToView()
    }

    private fun initToolBar(){
        initToolbar(getString(R.string.found_item),
            true, viewDataBinding!!.layoutToolBar.toolbar,
            View.OnClickListener {
                run {
                    finish()
                }
            })
    }

    // Initialize the Barcode Reader
//    private fun initBarcodeReader(){
//        ScanditLicense.setAppKey(BuildConfig.SCANDIT_KEY)
//        val settings : ScanSettings = ScanSettings.create()
//        val symbolsToEnable = intArrayOf(
//            Barcode.SYMBOLOGY_EAN13,
//            Barcode.SYMBOLOGY_EAN8,
//            Barcode.SYMBOLOGY_UPCA,
//            Barcode.SYMBOLOGY_CODE39,
//            Barcode.SYMBOLOGY_CODE128
//        )
//        for (sym in symbolsToEnable) {
//            settings.setSymbologyEnabled(sym, true)
//        }
//        picker = BarcodePicker(this, settings)
//        picker!!.setOnScanListener(this)
//        viewDataBinding!!.relativeCamera.addView(
//            picker, FrameLayout.LayoutParams(
//                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
//            )
//        )
//    }

    private fun setListeners(){
//        viewDataBinding!!.txtScanCanNotFind.setOnClickListener {
//            cantFindResult()
//        }

        viewDataBinding!!.txtBarCodeNotScan.setOnClickListener {
            viewDataBinding!!.txtBarCodeNotScan.isClickable = false
            openItemNotFound()
        }

        viewDataBinding!!.refreshCamera.setOnClickListener {
//            if (picker != null){
//                picker!!.startScanning()
//                it.visibility = View.GONE
//            }
        }
    }

    private fun setDataToView(){
        if (item != null){
            GlideApp.with(this).load(item!!.productImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(viewDataBinding!!.productInfoLayout.orderItemImage)

            viewDataBinding!!.productInfoLayout.txtTitle.text = item!!.productName!!.replace("\n", "").replace("\r", "")// + " " + item!!.aisleName

            if (item!!.getDescriptionLabel().isEmpty()) {
                viewDataBinding!!.productInfoLayout.tvPriceDescription.visibility = View.GONE
            } else {
                viewDataBinding!!.productInfoLayout.tvPriceDescription.visibility = View.VISIBLE
                viewDataBinding!!.productInfoLayout.tvPriceDescription.text = item!!.getDescriptionLabel()
            }

            viewDataBinding!!.txtBarcode.text = String.format("UPC: %s", item!!.barCode!!.trim { it <= ' ' })

            viewDataBinding!!.productInfoLayout.txtPricePerUnit.text = Html.fromHtml(PriceConstructorNew.getFormatPrice(item, PriceConstructor.LabelType.SIMPLE))
        }
    }

    // Can't find item
    private fun cantFindResult(){
        setResult(Activity.RESULT_FIRST_USER)
        finish()
    }


    // Open the item not found
    private fun openItemNotFound(){
        // Open the CameraActivity
        val intent = Intent(this, OpenCameraActivity::class.java)
        if (item != null){
            intent.putExtra("ARG_SIMILAR_ITEM", item!!)
        }
        else{
            intent.putExtra("ARG_ORDER_ITEM", ordersItem!!)
        }

        intent.putExtra("ARG_ORDER_ID", orderId)
        intent.putExtra("ARG_BAR_CODE", scannedBarCode)
        intent.putExtra("ARG_OLD_ITEM_ID", itemId)

        startActivityForResult(intent, ScanItem.OPEN_CAMERA_ACTIVITY_REQ)
    }

    // Check if permission is granted
//    @SuppressLint("MissingPermission", "CheckResult")
//    private fun grantCameraPermission(){
//        val permissions = RxPermissions(this)
//        permissions.request(Manifest.permission.CAMERA)
//            .subscribe { granted: Boolean ->
//                if (granted) {
//                    if (picker != null) {
//                        picker!!.startScanning()
//                        viewDataBinding!!.refreshCamera.visibility = View.GONE
//                    }
//                }
//            }
//    }

    // Check the barcode
    private fun checkBarcode(barcode : String){
//        viewDataBinding!!.txtLoadingView.visibility = View.VISIBLE

        val orderItemId : Long = ordersItem!!.ordersOutletsItemsId ?: 0
        val replaceItemId : Long = (item!!.outletItemId ?: 0).toLong()
        viewModel.checkBarcode(orderItemId, barcode, isReplaceItem, replaceItemId, object  :
            HandleResponse<CommonResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                viewDataBinding!!.txtLoadingView.visibility = View.GONE
                Toast.makeText(this@ScanAsReplaceItemActivity, error?.message, Toast.LENGTH_SHORT).show()
            }

            override fun handleSuccessResponse(successResponse: CommonResponse) {
                viewDataBinding!!.txtLoadingView.visibility = View.GONE
                val response = successResponse.data

                if (successResponse != null) {
                    Toast.makeText(this@ScanAsReplaceItemActivity, successResponse.message, Toast.LENGTH_SHORT).show()

                    if (successResponse.status == 200){
                        if (item!!.soldPer != 3 && item!!.soldPer != 2){
                            replaceItem()
                        }
                        else{
                            showAmountDialog()
                        }
                    }
                    else {
                        showProduct(barcode)
                    }
                }
                else{
                    Toast.makeText(this@ScanAsReplaceItemActivity, R.string.error_check_barcode, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    private fun showProduct(barcode : String){
        viewModel.getProductByBarcode(orderId, barcode, object : HandleResponse<ItemResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                Toast.makeText(this@ScanAsReplaceItemActivity, error?.message, Toast.LENGTH_SHORT).show()
            }

            override fun handleSuccessResponse(successResponse: ItemResponse) {
                if (successResponse.response != null){
                    if (successResponse.response.httpCode == 200 && successResponse.response.itemDetails != null){
                        // Show the IncorrectItemDialogFragment
                        try{
                            val incorrectFragment = IncorrectItemDialogFragment.newInstance(successResponse.response.itemDetails, item!!)
                            incorrectFragment.show(supportFragmentManager, IncorrectItemDialogFragment.javaClass.name)
                        }
                        catch (e : Exception){
                            e.printStackTrace()
                        }
                    }
                    else{
                        Toast.makeText(this@ScanAsReplaceItemActivity, successResponse.response.message, Toast.LENGTH_SHORT).show()
                    }
                }
                else{
                    Toast.makeText(this@ScanAsReplaceItemActivity, R.string.error_server_return_null, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    // Show the amount dialog
    private fun showAmountDialog(){
        try{
            val amountDialog = AmountDialogFragment.newInstance(item!!, 1.0)
            amountDialog.show(supportFragmentManager, AmountDialogFragment.javaClass.name)
            amountDialog.setAmountNextClickListener(this)
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    private fun replaceItem(){
        if (ordersItem!!.soldPer == 2){
            replaceQuantityDialog(ordersItem!!, item!!, ordersItem!!.itemQty ?: 0.0)
        }
        else if (ordersItem!!.soldPer == 3){
            replaceQuantityDialog(ordersItem!!, item!!, ordersItem!!.approxWeight)
        }
        else if (ordersItem!!.itemQty != null && ordersItem!!.itemQty!! >= 1){
            replaceQuantityDialog(ordersItem!!, item!!, ordersItem!!.itemQty!!)
        }
        else{
            foundResult(1.0)
        }
    }

    private fun replaceQuantityDialog(ordersItem: OrdersItem, similarProduct: SimilarProduct, quantity : Double){
        // Show the ReplaceQuantityDialog
        try{
            val orgOrderId = if (ordersItem.replacementRequested != null && ordersItem.replacementRequested == 1) (ordersItem.oldOutletItemId ?: "0").toInt() else ordersItem.outletItemId ?: 0
            val replaceQtyDialogFragment = ReplaceQuantityDialogFragment.newInstance(orderId, ordersItem, similarProduct, quantity, orgOrderId, actionFrom)
            replaceQtyDialogFragment.show(supportFragmentManager, ReplaceQuantityDialogFragment.javaClass.name)
            replaceQtyDialogFragment.clickListener = this
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    // found result
    private fun foundResult(amount: Double){
        val intent = Intent()
        intent.putExtra(ScanItem.ITEM_AMOUNT, amount)
        setResult(Activity.RESULT_OK, intent)
        finish()
    }

    /**
     * ScanListener
     */
//    override fun didScan(scanSession: ScanSession?) {
//        if (scanSession != null && scanSession.newlyRecognizedCodes.size > 0) {
//            val barcode = scanSession.newlyRecognizedCodes[0].data
//            scannedBarCode = barcode
//
//            runOnUiThread {
//                checkBarcode(barcode)
//                if (picker != null) {
//                    picker!!.stopScanning()
//                }
//
//                viewDataBinding!!.refreshCamera.visibility = View.VISIBLE
//            }
//        }
//    }

    /**
     * AmountDialog ClickListener
     */
    override fun onNextClick(requestItems : ArrayList<ReplacementOrdersItemRequest>){

    }

    override fun onNextClick(amount: Double) {
        viewDataBinding!!.txtLoadingView.visibility = View.GONE
        foundResult(amount)
    }

    override fun onNextClick(itemId: Long, amount: Double) {

    }

    override fun onNextClick(amount: Double, weight: Double) {
        val intent = Intent()
        intent.putExtra(ITEM_AMOUNT, amount)
        intent.putExtra(ITEM_WEIGHT, weight)
        setResult(RESULT_OK, intent)
        finish()
    }

    override fun onNextClick(itemId: Long, amount: Double, weight: Double) {

    }

    /**
     * OnActivityResult
     */
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == RESULT_OK) {
            if (requestCode == ScanItem.OPEN_CAMERA_ACTIVITY_REQ){
                // Replace item
                replaceItem()
            }
        }
        else{
            finish()
        }
    }

    override fun onResume() {
        super.onResume()

//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
//            grantCameraPermission()
//        }
//        else{
//            if (picker != null){
//                viewDataBinding!!.txtLoadingView.visibility = View.GONE
//                picker!!.startScanning()
//            }
//        }
    }

    override fun onPause() {
//        if (picker != null)
//            picker!!.stopScanning()

        super.onPause()
    }
}