package com.app.basketiodriver.ui.home.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseExpandableListAdapter
import androidx.databinding.DataBindingUtil
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.ListGroupChildBinding
import com.app.basketiodriver.databinding.ListGroupHeaderBinding


/**
Created by ibraheem lubbad on 2/27/20.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/

class ExpandableListAdapter(private val context: Context, val listItems: ArrayList<MenuModel>) :
    BaseExpandableListAdapter() {
    override fun getChild(groupPosition: Int, childPosititon: Int): MenuModel? {
        return if (listItems[groupPosition].subMenu == null) {
            null
        } else {
            listItems[groupPosition].subMenu!![childPosititon]
        }
    }

    override fun getChildId(groupPosition: Int, childPosition: Int): Long {
        return childPosition.toLong()
    }

    override fun getChildView(
        groupPosition: Int, childPosition: Int,
        isLastChild: Boolean, convertView: View?, parent: ViewGroup
    ): View {

        val v = if (convertView == null) {
            DataBindingUtil.inflate(
                context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
                , R.layout.list_group_child, parent, false
            )
            //  ListGroupChildBinding.inflate( context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater)
        } else {
            convertView.tag as ListGroupChildBinding
        }

        v.root.tag = v
        v.tvMenuName.text = getChild(groupPosition, childPosition)!!.menuName
//        v.tvSeparator.visibility =
//            if (childPosition != getChildrenCount(groupPosition) - 1) View.VISIBLE else View.GONE
         v.ivMenuIcon.setImageResource(getChild(groupPosition,childPosition)!!.menuIcon!!)
        return v.root
    }

    override fun getChildrenCount(groupPosition: Int): Int {
        return if (listItems[groupPosition].subMenu == null) 0 else listItems[groupPosition].subMenu!!.size
    }

    override fun getGroup(groupPosition: Int): MenuModel {
        return listItems[groupPosition]
    }

    override fun getGroupCount(): Int {
        return listItems.size
    }

    override fun getGroupId(groupPosition: Int): Long {
        return groupPosition.toLong()
    }

    override fun getGroupView(
        groupPosition: Int, isExpanded: Boolean,
        convertView: View?, parent: ViewGroup
    ): View {

        val v = if (convertView == null) {
            //  ListGroupHeaderBinding.inflate( context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater)
            DataBindingUtil.inflate(
                context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
                , R.layout.list_group_header, parent, false
            )

        } else {
            convertView.tag as ListGroupHeaderBinding
        }


        /*  if ( getGroup(groupPosition).subMenu.isNullOrEmpty()){
              v.ivIndecator.visibility=View.GONE
          }else{
              v.ivIndecator.visibility=View.GONE
             v.ivIndecator.setImageResource(
                  if (isExpanded)  R.drawable.ic_keyboard_arrow_up_white_24dp else R.drawable.ic_keyboard_arrow_down_white_24dp

          }
  */

        v.root.tag = v
        v.tvMenuName.text = getGroup(groupPosition).menuName
        v.ivMenuIcon.setImageResource(getGroup(groupPosition).menuIcon!!)

        return v.root
    }

    override fun hasStableIds(): Boolean {
        return false
    }

    override fun areAllItemsEnabled(): Boolean {
        return true
    }

    override fun isChildSelectable(groupPosition: Int, childPosition: Int): Boolean {
        return true
    }

}