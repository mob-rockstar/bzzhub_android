package com.app.basketiodriver.data.model.api.response.earning

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
class ShopperYearlyResponse : Parcelable {
    @SerializedName("data")
    val data: BalanceYearData? = null

    @SerializedName("message")
    val message: String = ""
}