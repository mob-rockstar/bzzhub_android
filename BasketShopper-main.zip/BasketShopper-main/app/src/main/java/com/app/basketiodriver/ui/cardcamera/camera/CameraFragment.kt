// "Therefore those skilled at the unorthodox
// are infinite as heaven and earth,
// inexhaustible as the great rivers.
// When they come to an end,
// they begin again,
// like the days and months;
// they die and are reborn,
// like the four seasons."
//
// - Sun Tsu,
// "The Art of War"
package com.app.basketiodriver.ui.cardcamera.camera

import android.content.Intent
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentBatchBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.cardcamera.CameraViewModel
import com.app.basketiodriver.ui.cardcamera.cropper2.CropDemoPreset
import com.app.basketiodriver.ui.cardcamera.cropper2.CropImageViewOptions
import com.app.basketiodriver.utils.AppLogger
import com.theartofdev.edmodo.cropper.CropImage
import com.theartofdev.edmodo.cropper.CropImageView
import com.theartofdev.edmodo.cropper.CropImageView.*

/** The fragment that will show the Image Cropping UI by requested preset.  */
class CameraFragment : BaseFragment<FragmentBatchBinding?, CameraViewModel>(),
    Injectable, OnSetImageUriCompleteListener, OnCropImageCompleteListener {


    override val layoutId: Int
        get() = R.layout.fragment_main_rect

    override val viewModel: CameraViewModel
        get() {
            return getViewModel(requireActivity(), CameraViewModel::class.java)
        }


    private var mCropImageView: CropImageView? = null

    /** Set the image to show for cropping.  */
    fun setImageUri(imageUri: Uri?) {
        mCropImageView!!.setImageUriAsync(imageUri)
        //        CropImage.activity(imageUri)
        //                .start(getContext(), this);
    }

    /** Set the options of the crop image view to the given values.  */
    fun setCropImageViewOptions(options: CropImageViewOptions) {
        mCropImageView!!.scaleType = options.scaleType
        mCropImageView!!.cropShape = options.cropShape
        mCropImageView!!.guidelines = options.guidelines
        mCropImageView!!.setAspectRatio(options.aspectRatio.first, options.aspectRatio.second)
        mCropImageView!!.setFixedAspectRatio(options.fixAspectRatio)
        mCropImageView!!.setMultiTouchEnabled(options.multitouch)
        mCropImageView!!.isShowCropOverlay = options.showCropOverlay
        mCropImageView!!.isShowProgressBar = options.showProgressBar
        mCropImageView!!.isAutoZoomEnabled = options.autoZoomEnabled
        mCropImageView!!.maxZoom = options.maxZoomLevel
        mCropImageView!!.isFlippedHorizontally = options.flipHorizontally
        mCropImageView!!.isFlippedVertically = options.flipVertically
    }

    /** Set the initial rectangle to use.  */
    fun setInitialCropRect() {
        mCropImageView!!.cropRect = Rect(100, 300, 500, 1200)
    }

    /** Reset crop window to initial rectangle.  */
    fun resetCropRect() {
        mCropImageView!!.resetCropRect()
    }

    fun updateCurrentCropViewOptions() {
        val options = CropImageViewOptions()
        options.scaleType = mCropImageView!!.scaleType
        options.cropShape = mCropImageView!!.cropShape
        options.guidelines = mCropImageView!!.guidelines
        options.aspectRatio = mCropImageView!!.aspectRatio
        options.fixAspectRatio = mCropImageView!!.isFixAspectRatio
        options.showCropOverlay = mCropImageView!!.isShowCropOverlay
        options.showProgressBar = mCropImageView!!.isShowProgressBar
        options.autoZoomEnabled = mCropImageView!!.isAutoZoomEnabled
        options.maxZoomLevel = mCropImageView!!.maxZoom
        options.flipHorizontally = mCropImageView!!.isFlippedHorizontally
        options.flipVertically = mCropImageView!!.isFlippedVertically
        // ((CameraActivity) getActivity()).setCurrentOptions(options);
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val rootView: View
        rootView = when (viewModel.previewParameter) {
            CropDemoPreset.RECT -> inflater.inflate(R.layout.fragment_main_rect, container, false)
            CropDemoPreset.CIRCULAR -> inflater.inflate(
                R.layout.fragment_main_oval,
                container,
                false
            )
            CropDemoPreset.CUSTOMIZED_OVERLAY -> inflater.inflate(
                R.layout.fragment_main_customized,
                container,
                false
            )
            CropDemoPreset.MIN_MAX_OVERRIDE -> inflater.inflate(
                R.layout.fragment_main_min_max,
                container,
                false
            )
            CropDemoPreset.SCALE_CENTER_INSIDE -> inflater.inflate(
                R.layout.fragment_main_scale_center,
                container,
                false
            )

            else -> throw IllegalStateException("Unknown preset: $viewModel.previewParameter")
        }
        return rootView
    }

    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?
    ) {
        super.onViewCreated(view, savedInstanceState)
        mCropImageView = view.findViewById(R.id.cropImageView)
        mCropImageView!!.setOnSetImageUriCompleteListener(this)
        mCropImageView!!.setOnCropImageCompleteListener(this)
        updateCurrentCropViewOptions()
        if (savedInstanceState == null) {
            /* if (mDemoPreset === CropDemoPreset.SCALE_CENTER_INSIDE) {
                 //    mCropImageView.setImageResource(R.drawable.cat_small);
             } else {
                 // mCropImageView.setImageResource(R.drawable.cat);
             }*/
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.main_action_crop -> {
                mCropImageView!!.getCroppedImageAsync()
                return true
            }
            R.id.main_action_rotate -> {
                mCropImageView!!.rotateImage(90)
                return true
            }
            R.id.main_action_flip_horizontally -> {
                mCropImageView!!.flipImageHorizontally()
                return true
            }
            R.id.main_action_flip_vertically -> {
                mCropImageView!!.flipImageVertically()
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    override fun onDetach() {
        super.onDetach()
        if (mCropImageView != null) {
            mCropImageView!!.setOnSetImageUriCompleteListener(null)
            mCropImageView!!.setOnCropImageCompleteListener(null)
        }
    }

    override fun onSetImageUriComplete(
        view: CropImageView,
        uri: Uri,
        error: Exception
    ) {
        if (error == null) {
            Toast.makeText(activity, "Image load successful", Toast.LENGTH_SHORT).show()
        } else {
            Log.e("AIC", "Failed to load image by URI", error)
            Toast.makeText(activity, "Image load failed: " + error.message, Toast.LENGTH_LONG)
                .show()
        }
    }

    override fun onCropImageComplete(
        view: CropImageView,
        result: CropResult
    ) {
        handleCropResult(result)
    }

    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            val result = CropImage.getActivityResult(data)
            handleCropResult(result)
        }
    }

    private fun handleCropResult(result: CropResult) {
        if (result.error == null) {
            AppLogger.d("handleCropResult ${result.error}")
            /*  Intent intent = new Intent(getActivity(), CropResultActivity.class);
      intent.putExtra("SAMPLE_SIZE", result.getSampleSize());
      if (result.getUri() != null) {
        intent.putExtra("URI", result.getUri());
      } else {
        CropResultActivity.mImage =
            mCropImageView.getCropShape() == CropImageView.CropShape.OVAL
                ? CropImage.toOvalBitmap(result.getBitmap())
                : result.getBitmap();
      }
      startActivity(intent);*/
        } else {
            Log.e("AIC", "Failed to crop image", result.error)
            Toast.makeText(
                    activity,
                    "Image crop failed: " + result.error.message,
                    Toast.LENGTH_LONG
                )
                .show()
        }
    }

    companion object {
        // endregion
        /** Returns a new instance of this fragment for the given section number.  */
        fun newInstance(): CameraFragment {
            val fragment = CameraFragment()
            val args = Bundle()
            fragment.arguments = args
            return fragment
        }
    }
}