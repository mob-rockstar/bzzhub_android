package com.app.basketiodriver.data.model.api.response

import com.app.basketiodriver.data.model.api.response.Base.BaseResponse
import com.google.gson.annotations.SerializedName


/**
Created by ibraheem lubbad on 2020-02-11.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class BookingSlotsResponse : BaseResponse() {


    @SerializedName("data")
    //  var slotsResponseData: SlotsResponseData? = null
    val shopperBookingSlots: ArrayList<ShopperBookingSlots>? = null

    @SerializedName("total_month_RI")
    val total_month_RI: Int? = 0


}