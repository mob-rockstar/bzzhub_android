package com.app.basketiodriver.ui.dialogs

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.fragment.app.FragmentManager
import com.app.basketiodriver.R
import com.app.basketiodriver.ShopperApp
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.general.SimpleResponse
import com.app.basketiodriver.data.remote.socket.ChatMessageHelper
import com.app.basketiodriver.data.remote.socket.SystemMessage
import com.app.basketiodriver.data.remote.socket.SystemMessageReq
import com.app.basketiodriver.databinding.FragmentConfirmPaymentDialogBinding
import com.app.basketiodriver.di.Navigators
import com.app.basketiodriver.ui.base.BaseDialogFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.dashbaord.OrdersManager
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_ORDER_FINISHED
import com.app.basketiodriver.ui.home.HomeActivity
import com.app.basketiodriver.ui.home.HomeViewModel
import com.app.basketiodriver.ui.order.ArrivedToCustomerActivity
import com.app.basketiodriver.utils.AppConstants
import io.reactivex.Observable
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.*


class ConfirmPaymentDialogFragment : BaseDialogFragment<FragmentConfirmPaymentDialogBinding, HomeViewModel>(){

    override val layoutId: Int
        get() = R.layout.fragment_confirm_payment_dialog

    override val viewModel: HomeViewModel
        get() {
            return getViewModel(baseActivity, HomeViewModel::class.java)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    // Set Full screen
    override fun getTheme(): Int {
        return R.style.MyDialogWhite
    }

    var symbols: DecimalFormatSymbols = DecimalFormatSymbols(Locale.US)
    var formatter: DecimalFormat = DecimalFormat("#0.00", symbols)

    var orderId : Long = 0
    var price : Double = 0.0
    var newPrice : Double = 0.0

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        /**
         * get params
         */
        arguments?.let {
            orderId = it.getLong(KEY_ORDER_ID)
            price   = it.getDouble(KEY_TOTAL_PRICE)

            initViews()
        }
    }

    override fun show(manager: FragmentManager, tag: String?) {
        try {
            val ft = manager.beginTransaction()
            ft.add(this, tag)
            ft.commitAllowingStateLoss()
        } catch (ignored: Exception) {
            ignored.printStackTrace()
        }
    }

    private fun initViews(){
        ShopperApp.Instance.stopNotificationSound(baseActivity)
        viewDataBinding!!.tCalculateTotal.text = String.format(Locale.US, "%.2f", price)

        // Currency
        viewDataBinding!!.tvCurrency1.text = PreferenceManager.currency
        viewDataBinding!!.tvCurrency2.text = PreferenceManager.currency

        initToolbar()

        setListeners()
    }

    private fun initToolbar(){
        viewDataBinding!!.layoutToolBar.toolBarTitle.setText(R.string.dashboard)
        viewDataBinding!!.layoutToolBar.btnBack.setOnClickListener {
            dismiss()
        }
    }

    @SuppressLint("CheckResult")
    private fun setListeners(){
        val etPriceObservable: Observable<String> = Observable.create { e ->
            viewDataBinding!!.etPrice.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(
                    s: CharSequence,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun onTextChanged(
                    s: CharSequence,
                    start: Int,
                    before: Int,
                    count: Int
                ) {
                }

                override fun afterTextChanged(s: Editable) {
                    e.onNext(s.toString())
                }
            })
        }

        etPriceObservable.subscribe { s ->
            try {
                newPrice = parsePrice(s)
                val change: Double = newPrice - price
                viewDataBinding!!.etPrice.post {
                    viewDataBinding!!.lChange.visibility = View.VISIBLE
                    validChange(change)
                    viewDataBinding!!.tChange.text = formatter.format(change)
                }
            } catch (e: NumberFormatException) {
                viewDataBinding!!.etPrice.post {
                    viewDataBinding!!.lChange.visibility = View.GONE
                    viewDataBinding!!.bConfirm.isEnabled = false
                }
            }
        }

        viewDataBinding!!.bConfirm.setOnClickListener {
            try {
                requestConfirmPayment()
            }
            catch ( e : Exception){
                viewDataBinding!!.etPrice.error = getString(R.string.invalid_price)
            }
        }

        viewDataBinding!!.etPrice.setOnEditorActionListener{ v, actionId, event ->
            if(actionId == EditorInfo.IME_ACTION_DONE){
                if (viewDataBinding!!.bConfirm.isEnabled) {
                    requestConfirmPayment()
                }

                false
            }

            true
        }
    }

    @Throws(java.lang.NumberFormatException::class)
    private fun parsePrice(priseString: String): Double {
        return priseString.toDouble()
    }

    private fun validChange(change : Double){
        if (change < 0){
            viewDataBinding!!.tChange.setTextColor(Color.RED)
            viewDataBinding!!.bConfirm.isEnabled = false
        }
        else{
            viewDataBinding!!.tChange.setTextColor(Color.BLACK)
            viewDataBinding!!.bConfirm.isEnabled = true
        }
    }

    private fun requestConfirmPayment(){
        if (activity != null && activity is ArrivedToCustomerActivity){
            viewModel.pushAmountFromCustomer(orderId, newPrice, 0.0, object : HandleResponse<SimpleResponse>{
                override fun handleErrorResponse(error: ErrorResponse?) {
                    Toast.makeText(baseActivity, error?.message, Toast.LENGTH_SHORT).show()
                }

                override fun handleSuccessResponse(successResponse: SimpleResponse) {
                    if (successResponse.response != null && successResponse.response.httpCode == 200){
                        // Update the order status into ORDER_FINISHED
                        updateOrderStatus()
                    }
                    else{
                        Toast.makeText(baseActivity, baseActivity.resources?.getString(R.string.error_update_status), Toast.LENGTH_SHORT).show()
                    }
                }
            })
        }

    }

    fun sendSystemMessage(systemMessageReq: SystemMessageReq){
        viewModel.sendSystemMessage(systemMessageReq, object : HandleResponse<SystemMessage> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                // Close the chat room
                closeChattingRoom()
            }

            override fun handleSuccessResponse(successResponse: SystemMessage) {
                // Close the chat room
                closeChattingRoom()
            }
        })
    }

    // Close the chatting room
    private fun closeChattingRoom(){
        try{
            (baseActivity.application as ShopperApp).closeChatRoom(orderId)

            // Go to Dashboard
            Navigators.goToDashboardWithCongratulation(baseActivity, orderId)
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    /**
     * Update the order status
     */
    private fun updateOrderStatus(){
        if (activity != null && activity is ArrivedToCustomerActivity) {
            viewModel.updateOrderStatus(STATUS_ORDER_FINISHED, orderId, object : HandleResponse<SimpleResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    Toast.makeText(baseActivity, error?.message, Toast.LENGTH_SHORT).show()
                }

                override fun handleSuccessResponse(successResponse: SimpleResponse) {
                    val response = successResponse.response
                    if (response != null){
                        if (response.httpCode == 200){
                            // Stop sending the shopper location
                            Log.e("ConfirmPaymentDialog", "Stopping updating shopper location...")
                            PreferenceManager.shouldStopLocation = true

                            // Send message
                            val message: String = AppConstants.MESSAGE_TYPE_FINISHED + " " +PreferenceManager.currentShopperFirstName + " " + resources.getString(
                                    R.string.left_chat)
                            val systemMessageReq = SystemMessageReq(orderId.toString(), "text", message)
                            sendSystemMessage(systemMessageReq)
                        }
                        else{
                            Toast.makeText(baseActivity, response.message, Toast.LENGTH_SHORT).show()
                        }
                    }
                    else{
                        Toast.makeText(baseActivity, baseActivity.resources?.getString(R.string.error_update_status), Toast.LENGTH_SHORT).show()
                    }
                }
            })
        }
    }

    companion object {
        const val KEY_ORDER_ID        = "order_id"
        const val KEY_TOTAL_PRICE     = "total_price"

        fun newInstance(
            orderId : Long, amount : Double
        ): ConfirmPaymentDialogFragment {
            val fragment = ConfirmPaymentDialogFragment()

            val data = Bundle()
            data.putLong(KEY_ORDER_ID, orderId)
            data.putDouble(KEY_TOTAL_PRICE, amount)

            fragment.arguments = data

            return fragment
        }
    }
}