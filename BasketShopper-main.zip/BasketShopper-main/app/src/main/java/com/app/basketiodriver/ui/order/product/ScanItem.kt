package com.app.basketiodriver.ui.order.product

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.Html
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast
import androidx.fragment.app.Fragment
import app.basket.scanner.BasketScanner
import com.app.basketiodriver.BuildConfig
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.checkout.CustomerInfo
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.model.api.response.order.CommonResponse
import com.app.basketiodriver.data.model.api.response.order.ReplacementOrdersItemRequest
import com.app.basketiodriver.data.model.api.response.order.SimilarProduct
import com.app.basketiodriver.databinding.ActivityScanItemBinding
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.app.basketiodriver.ui.dialogs.AmountDialogFragment
import com.app.basketiodriver.ui.dialogs.IncorrectItemDialogFragment
import com.app.basketiodriver.utils.GlideApp
import com.app.basketiodriver.utils.price.PriceConstructor
import com.google.gson.Gson
import com.tbruyelle.rxpermissions2.RxPermissions
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.*
import javax.inject.Inject


class ScanItem : BaseActivity<ActivityScanItemBinding, OrderDetailsViewModel>(),
//    OnScanListener,
    AmountDialogFragment.AmountDialogOnClickListener, HasAndroidInjector {

    override val layoutId: Int
        get() = R.layout.activity_scan_item

    override val viewModel: OrderDetailsViewModel
        get() {

            return getViewModel(OrderDetailsViewModel::class.java)
        }

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>
    override fun androidInjector() = dispatchingAndroidInjector

    // Properties
    var orderId: Long = 0
    var item: OrdersItem? = null
    var info: CustomerInfo? = null
    var autoFocus: Boolean = true

    var scannedBarCode: String? = null

    var isBarcodeScan: Boolean = false
    var isChatOpen: Boolean = false

    var symbols: DecimalFormatSymbols = DecimalFormatSymbols(Locale.ENGLISH)

//    var picker: BarcodePicker? = null
//    var barcodeCapture : BarcodeCapture? = null

    // Express Store
    var isExpress: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (intent.extras != null) {
            // get order id
            orderId = intent.getLongExtra("ARG_ORDER_ID", 0)

            // customer info
            info = intent.extras!!.getSerializable("ARG_INFO") as? CustomerInfo

            // order item
            item = intent.extras!!.getSerializable("KEY_ITEM_DETAIL") as? OrdersItem

            // auto focus
            autoFocus = intent.extras!!.getBoolean("KEY_AUTO_FOCUS", true)

            // Express store
            isExpress = intent.extras!!.getInt("ARG_IS_EXPRESS", 0)
        }

        // Init toolbar
        initToolBar()

        // Set the ClickListener
        setListeners()

        // Init the Barcode Reader
//        initBarcodeReader()

        // Display item information
        setDataToView()

//        startScanner()
    }

    override fun onResume() {
        super.onResume()
//        startScanner()
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//            grantCameraPermission()
//        } else {
////            startScanner()
////            if (picker != null) {
////                viewDataBinding!!.txtLoadingView.visibility = View.GONE
//////                picker!!.startScanning()
////
////            }
//        }

        isChatOpen = false
        isBarcodeScan = false
    }

    private fun startScanner() {
        BasketScanner.scan(onSuccess = {
            Toast.makeText(
                this@ScanItem,
                it,
                Toast.LENGTH_SHORT
            ).show()
            scannedBarCode = it

            runOnUiThread {
                checkBarcode(it)
//                        if (picker != null) {
//                            picker!!.stopScanning()
//                        }

                viewDataBinding!!.refreshCamera.visibility = View.VISIBLE
            }
        }, onCanceled = {}, onEmptyResult = {}, onFailure = {
            Toast.makeText(this@ScanItem, it.message + "", Toast.LENGTH_LONG).show()
        })
//        BasketScanner.scan {
//            when (it) {
//                is ScannerResult.Success ->{
//                    Toast.makeText(
//                        this@ScanItem,
//                        it.barcode,
//                        Toast.LENGTH_SHORT
//                    ).show()
//                    scannedBarCode = it.barcode
//
//                    runOnUiThread {
//                        checkBarcode(it.barcode)
////                        if (picker != null) {
////                            picker!!.stopScanning()
////                        }
//
//                        viewDataBinding!!.refreshCamera.visibility = View.VISIBLE
//                    }
//                }
//
//
//                is ScannerResult.Failure -> Toast.makeText(
//                    this@ScanItem,
//                    it.exception.message,
//                    Toast.LENGTH_SHORT
//                ).show()
//
//                is ScannerResult.Canceled -> {}
//                is ScannerResult.EmptyResult -> {}
//
//            }
//        }
    }

    override fun onPause() {
//        if (picker != null)
//            picker!!.stopScanning()

        super.onPause()
    }

    private fun initToolBar() {
        initToolbar(getString(R.string.scan_item_title),
            true, viewDataBinding!!.layoutToolBar.toolbar,
            View.OnClickListener {
                run {
                    finish()
                }
            })
    }

    private fun setListeners() {
//        viewDataBinding!!.btnScanCannotFind.setOnClickListener {
//            cantFindResult()
//        }

        viewDataBinding!!.txtBarCodeNotScan.setOnClickListener {
            if (!isBarcodeScan) {
                isBarcodeScan = true
                openItemNotFound()
            }
        }

        viewDataBinding!!.refreshCamera.setOnClickListener {
//            if (picker != null) {
////                picker!!.startScanning()
//                startScanner()
//                it.visibility = View.GONE
//            }
        }
    }

    // Initialize the Barcode Reader
//    private fun initBarcodeReader() {
//        ScanditLicense.setAppKey(BuildConfig.SCANDIT_KEY)
//        val settings: ScanSettings = ScanSettings.create()
//        val symbolsToEnable = intArrayOf(
//            Barcode.SYMBOLOGY_EAN13,
//            Barcode.SYMBOLOGY_EAN8,
//            Barcode.SYMBOLOGY_UPCA,
//            Barcode.SYMBOLOGY_CODE39,
//            Barcode.SYMBOLOGY_CODE128
//        )
//        for (sym in symbolsToEnable) {
//            settings.setSymbologyEnabled(sym, true)
//        }
////        picker = BarcodePicker(this, settings)
////        picker!!.setOnScanListener(this)
////        viewDataBinding!!.relativeCamera.addView(
////            picker, FrameLayout.LayoutParams(
////                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
////            )
////        )
//    }

    @SuppressLint("SetTextI18n")
    private fun setDataToView() {
        if (item != null) {
            GlideApp.with(this).load(item!!.productImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder)
                .into(viewDataBinding!!.productInfoLayout.orderItemImage)

            val formatter = DecimalFormat("#.## x ", symbols)
            if (item!!.quantityDifference == 1)
                viewDataBinding!!.productInfoLayout.txtTitle.text =
                    formatter.format(item!!.actualQty).toString() + item!!.productName
            else if (item!!.replacementRequested != null && item!!.replacementRequested == 1)
                if (item!!.itemStatus == 2) {
                    viewDataBinding!!.productInfoLayout.txtTitle.text = item!!.productName
                } else {
                    viewDataBinding!!.productInfoLayout.txtTitle.text =
                        formatter.format(item!!.actualQty).toString() + item!!.productName
                }
            else
                viewDataBinding!!.productInfoLayout.txtTitle.text = formatter.format(item!!.itemQty)
                    .toString() + item!!.productName // + item!!.aisleName

            if (item!!.getDescriptionLabel().isEmpty()) {
                viewDataBinding!!.productInfoLayout.tvPriceDescription.visibility = View.GONE
            } else {
                viewDataBinding!!.productInfoLayout.tvPriceDescription.visibility = View.VISIBLE
                viewDataBinding!!.productInfoLayout.tvPriceDescription.text =
                    item!!.getDescriptionLabel()
            }

            viewDataBinding!!.txtBarcode.text =
                String.format("UPC: %s", item!!.barCode.trim { it <= ' ' })

            viewDataBinding!!.productInfoLayout.txtPricePerUnit.text =
                Html.fromHtml(
                    PriceConstructor.getFormatPrice(
                        item,
                        PriceConstructor.LabelType.SIMPLE,
                        PreferenceManager.currency,
                        true
                    )
                )

        }
    }

    // Can't find item
    private fun cantFindResult() {
        setResult(Activity.RESULT_FIRST_USER)
        finish()
    }

    // found result
    private fun foundResult(amount: Double) {
        val intent = Intent()
        intent.putExtra(ITEM_AMOUNT, amount)
        setResult(Activity.RESULT_OK, intent)
        finish()
    }

    // Open the item not found
    private fun openItemNotFound() {
        // Open the CameraActivity
        val intent = Intent(this, OpenCameraActivity::class.java)
        if (item != null) {
            intent.putExtra("ARG_ORDER_ITEM", item!!)
        }

        intent.putExtra("ARG_ORDER_ID", orderId)
        intent.putExtra("ARG_BAR_CODE", scannedBarCode)
        startActivityForResult(intent, OPEN_CAMERA_ACTIVITY_REQ)
    }

    // Check if permission is granted
    @SuppressLint("MissingPermission", "CheckResult")
    private fun grantCameraPermission() {
        val permissions = RxPermissions(this)
        permissions.request(Manifest.permission.CAMERA)
            .subscribe { granted: Boolean ->
                if (granted) {
//                    if (picker != null) {
////                        picker!!.startScanning()
//                        startScanner()
//                        viewDataBinding!!.refreshCamera.visibility = View.GONE
//                    }
                }
            }
    }

    // Check the barcode
    private fun checkBarcode(barcode: String) {
        viewDataBinding!!.txtLoadingView.visibility = View.VISIBLE
        viewModel.checkBarcode(item!!.ordersOutletsItemsId ?: 0, barcode, 0, 0, object :
            HandleResponse<CommonResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                viewDataBinding!!.txtLoadingView.visibility = View.GONE
                Toast.makeText(this@ScanItem, error?.message, Toast.LENGTH_SHORT).show()
            }

            override fun handleSuccessResponse(successResponse: CommonResponse) {
                viewDataBinding!!.txtLoadingView.visibility = View.GONE
                val response = successResponse.data

                if (successResponse != null) {
                    Toast.makeText(this@ScanItem, successResponse.message, Toast.LENGTH_SHORT)
                        .show()

                    if (successResponse.status == 200) {

                        // Show the amount dialog
                        showAmountDialog()
                    } else if (successResponse.status == 402 && response != null) {
                        val gson = Gson()
                        val item: SimilarProduct = gson.fromJson(
                            response.asJsonArray[0],
                            SimilarProduct::class.java
                        )
                        showIncorrectItem(item)
                    } else if (successResponse.status == 400) {
                        openItemNotFound()
                    } else {
                        openItemNotFound()
                    }
                } else {
                    Toast.makeText(this@ScanItem, R.string.error_check_barcode, Toast.LENGTH_SHORT)
                        .show()
                }
            }
        })
    }

    // Show the IncorrectItem Dialog
    private fun showIncorrectItem(product: SimilarProduct) {
        try {
            // Show the IncorrectItemDialogFragment
            val incorrectFragment = IncorrectItemDialogFragment.newInstance(product, item!!)
            incorrectFragment.show(
                supportFragmentManager,
                IncorrectItemDialogFragment.javaClass.name
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showAmountDialog() {
        try {
//            if (item!!.itemQty != null && item!!.itemQty == 1.0 && isExpress == 1){ // Express store
//                foundResult(1.0)
//            }
            if (item!!.upcType == 1 && item!!.itemQty != null && item!!.itemQty == 1.0) { //
                // No need to show the amount dialog
                foundResult(1.0)
            } else {
                gotoAmountWeightPopup()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Show the amount & weight popup
    private fun gotoAmountWeightPopup() {
        val amountDialog = AmountDialogFragment.newInstance(item!!, item!!.actualQty)
        amountDialog.show(supportFragmentManager, AmountDialogFragment.javaClass.name)
        amountDialog.setAmountNextClickListener(this)
    }

    // Resume scan
    fun resumeScan() {
        startScanner()
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//            grantCameraPermission()
//        } else {
//            if (picker != null) {
//                viewDataBinding!!.refreshCamera.visibility = View.GONE
////                picker!!.startScanning()
//                startScanner()
//            }
//        }
    }

    /**
     * OnScanListener
     */
//    override fun didScan(scanSession: ScanSession?) {
//        if (scanSession != null && scanSession.newlyRecognizedCodes.size > 0) {
//            val barcode = scanSession.newlyRecognizedCodes[0].data
//            scannedBarCode = barcode
//
//            runOnUiThread {
//                checkBarcode(barcode)
//                if (picker != null) {
//                    picker!!.stopScanning()
//                }
//
//                viewDataBinding!!.refreshCamera.visibility = View.VISIBLE
//            }
//        }
//    }

    /**
     * AmountDialog ClickListener
     */
    override fun onNextClick(requestItems: ArrayList<ReplacementOrdersItemRequest>) {

    }

    override fun onNextClick(amount: Double) {
        foundResult(amount)
    }

    override fun onNextClick(itemId: Long, amount: Double) {

    }

    override fun onNextClick(amount: Double, weight: Double) {
        val intent = Intent()
        intent.putExtra(ITEM_AMOUNT, amount)
        intent.putExtra(ITEM_WEIGHT, weight)
        setResult(Activity.RESULT_OK, intent)
        finish()
    }

    override fun onNextClick(itemId: Long, amount: Double, weight: Double) {

    }

    /**
     * OnActivityResult
     */
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == RESULT_OK) {
            if (requestCode == OPEN_CAMERA_ACTIVITY_REQ) {
                // Show the amount dialog
                showAmountDialog()
            }
        } else {
            resumeScan()
        }
    }


    companion object {
        const val OPEN_CAMERA_ACTIVITY_REQ = 2
        const val ITEM_AMOUNT = "item_amount"
        const val ITEM_WEIGHT = "item_weight"
        const val SCANDIT_APP_KEY = BuildConfig.SCANDIT_KEY

        /*
                const val SCANDIT_APP_KEY =
                    "Aae/ZaSBMOOEPoQNID5iwLYDthFhN0BL9lV4VNpNqkSpPrlzfF1fFTxgZyoTUH9lDm0QmcBTjNZzWrFYEXWCkfos68JCVHV62hvH+ShaFgyvViWCMXfK3vVWYdQxGnPUozCTBlo6SnrOAe50lhIqHMgPygUSpxsrpbRmeqCywhq2T0H4qS4g2IuqCK/LHQ2v1QmoCwwyalGTe/25YUwRVp3ZnwBPZ7AWfPZ5pNOvp9V5i+H6nv/GSxt7hQQwZT6YCNCZn1DNR3bBYSNTP8Q0MrDT6R45+BA9QtiR87TsQabZBbhX+fR5BmscC/PTZsoiOPNcRNDa1HJDhjXvDKejxywT3Yt4rF4h6qhTqIl20RoTQxt7c51aKOxqVUrMBoovX0ILvLP78QmdTYRgN7COQI6CNg6MnMWMuLp9Ho0/3HHkA3KtJOQyslSbU7uMkemONq1SKmKJq0qeiQJbMXXlCyqzYUTnL5X1YVGW4oh7ezmOJgaCu6UPpPx3QH4LsveG67VNtKBUQLxnKw44yKlvZLlelBmYGyKNrLWvpmQVncu8KZKGgxmn+WnqmMJ2+l2M4Ps5xKau9/WLt8mkJb5dfoithu2F++fpSq/DB0F/Uk6St8bR9i3wWCfTn9yuvyE2j9Po0aunXlKWG7Ak6yrv4lFq4fb9873Z7rx/l2EEi171KwWWxTMQRA4ggYUbOa0GcHf98CZvxgBCISq4XObaGeRqoJ43hYDt9mwS1lNZHghryYn6qhnRjMYfU/1ciZUNfsV+42VrpFu3E/NrNeaHhNyuIovDV19XagzTh37p06rzTIwmsqPEE4DF3R6r"
        */
    }
}