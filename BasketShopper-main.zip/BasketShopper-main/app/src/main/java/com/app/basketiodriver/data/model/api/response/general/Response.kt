package com.app.basketiodriver.data.model.api.response.general

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Response {
    @SerializedName("httpCode")
    @Expose
    val httpCode: Int? = null

    @SerializedName("Message")
    @Expose
    val message: String = ""

    @SerializedName("is_account_suspended")
    @Expose
    val isAccountSuspended: Boolean = false

    @SerializedName("is_booked_shift")
    @Expose
    val isBookedShift = false

    @SerializedName("is_shift_start_early")
    @Expose
    val isShiftStartEarly: Boolean = false
}