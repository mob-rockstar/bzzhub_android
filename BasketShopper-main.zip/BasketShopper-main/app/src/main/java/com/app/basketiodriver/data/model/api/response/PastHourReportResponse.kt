package com.app.basketiodriver.data.model.api.response

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import java.util.*

class PastHourReportResponse {
    @SerializedName("data")
    var data: ArrayList<HoursDetailsData>? = null

    @SerializedName("message")
    var message: String? = null

    inner class HoursDetailsData {
        @SerializedName("date")
        @Expose
        var date: String? = null

        @SerializedName("shift_start_time")
        @Expose
        var shift_start_time: String? = null

        @SerializedName("shift_end_time")
        @Expose
        var shift_end_time: String? = null

        @SerializedName("zone")
        @Expose
        var zone: String? = null

        @SerializedName("service_type")
        @Expose
        var service_type: String? = null
    }
}