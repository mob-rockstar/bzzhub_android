package com.app.basketiodriver.ui.home.fragments.card_payments

import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.View
import androidx.fragment.app.Fragment
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentPhysicalCardBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.home.HomeViewModel
import com.app.basketiodriver.ui.payment_cards.CardPaymentActivity
import com.app.basketiodriver.ui.payment_cards.MailCardActivity


/**
 * A simple [Fragment] subclass.
 */
class PhysicalCardFragment : BaseFragment<FragmentPhysicalCardBinding?, HomeViewModel>(),
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_physical_card

    override val viewModel: HomeViewModel
        get() {
            return getViewModel(requireActivity(), HomeViewModel::class.java)
        }

    companion object {

        fun newInstance(
        ): PhysicalCardFragment {
            val fragment =
                PhysicalCardFragment()
            return fragment
        }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_info, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setHasOptionsMenu(true)

        viewDataBinding!!.btnOrderNewCard.setOnClickListener {
            startActivity(MailCardActivity.newIntent(requireContext()))
        }
        viewDataBinding!!.btnRegisterCard.setOnClickListener {
            startActivity(CardPaymentActivity.newIntent(requireContext()))
        }
    }
}
