package com.app.basketiodriver.data.local.db.realm

import com.app.basketiodriver.data.model.db.PaymentChangedOrder

object RealmManager {
    private val orderRepo = PaymentChangedOrderRepo()

    // Getters
    fun getLocalPaymentChangedOrders() : List<PaymentChangedOrder> {
        return orderRepo.findAll()
    }

    fun getPaymentChangerOrderWithId(orderId : Long) : PaymentChangedOrder?{
        return orderRepo.getById(orderId)
    }

    fun saveLocalPaymentChangedOrder(order : PaymentChangedOrder) {
        orderRepo.save(order)
    }

    fun deleteLocalPaymentChangedOrder(order: PaymentChangedOrder){
        orderRepo.delete(order)
    }
}