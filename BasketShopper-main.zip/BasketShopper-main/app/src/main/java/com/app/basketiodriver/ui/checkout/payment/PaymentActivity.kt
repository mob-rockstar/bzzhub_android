package com.app.basketiodriver.ui.checkout.payment

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.checkout.OutletDetails
import com.app.basketiodriver.data.model.api.response.checkout.OutletOrder
import com.app.basketiodriver.data.model.api.response.checkout.ShopperOrderReview
import com.app.basketiodriver.data.model.api.response.general.SimpleResponse
import com.app.basketiodriver.data.model.api.response.order.OrderOTPResponse
import com.app.basketiodriver.data.remote.socket.ChatMessageHelper
import com.app.basketiodriver.data.remote.socket.SystemMessage
import com.app.basketiodriver.data.remote.socket.SystemMessageReq
import com.app.basketiodriver.databinding.ActivityPaymentBinding
import com.app.basketiodriver.di.Navigators
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.checkout.card.CheckoutCardViewModel
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_CHECKOUT
import com.app.basketiodriver.ui.dialogs.TotalConfirmDialogFragment
import com.app.basketiodriver.ui.order.product.ItemDetails.Companion.SCAN_ACTIVITY
import com.app.basketiodriver.utils.AppConstants
import com.google.common.io.BaseEncoding.base64
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import java.util.*
import javax.inject.Inject

import android.util.Base64
import app.basket.scanner.BasketScanner
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.PAYMENT_TYPE_BRING_CC
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.PAYMENT_TYPE_CASH_1
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.PAYMENT_TYPE_CASH_2
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.PAYMENT_TYPE_CREDIT
import java.util.concurrent.TimeUnit


class PaymentActivity : BaseActivity<ActivityPaymentBinding, CheckoutCardViewModel>(),
    HasAndroidInjector {

    var orders: OutletOrder? = null
    var outletDetails: OutletDetails? = null

    var oldSubTotal: Double = 0.0
    var paymentGatewayId = PAYMENT_TYPE_CASH_1 // 18 : Cash, 24 : Credit card

    var payClick = false
    var openScanner = false

    var totalConfirmDialog: TotalConfirmDialogFragment? = null

    // Timer
    var timer: Timer? = null

    // OTP Timer
    var otpTimer: Timer? = null
    var isFirstOTPCall: Boolean = true


    override val layoutId: Int
        get() = R.layout.activity_payment

    override val viewModel: CheckoutCardViewModel
        get() {
            return getViewModel(CheckoutCardViewModel::class.java)
        }

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>
    override fun androidInjector() = dispatchingAndroidInjector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize the Toolbar
        initToolbar(getString(R.string.charge_card),
            true, viewDataBinding!!.layoutToolBar.toolbar,
            View.OnClickListener {
                run {
                    onBackPressed()
                }
            })

        // Get params
        orders = intent.getSerializableExtra("ARG_ORDER") as? OutletOrder
        oldSubTotal = intent.getDoubleExtra("KEY_SUBTOTAL", 0.0)
        paymentGatewayId = intent.getIntExtra("KEY_PAYMENT_GATEWAY", 18)

        // Setup views
        initViews()
    }

    private fun initViews() {
        // set currency
        viewDataBinding!!.txtAcQuantity.text = PreferenceManager.currency

        if (orders != null && orders!!.id != null) {
            viewDataBinding!!.txtBID.text = String.format(Locale.US, "%d", orders!!.id)
        }

        viewDataBinding!!.txtTotal.text = String.format(Locale.US, "%.2f", oldSubTotal)
        viewDataBinding!!.txtPayTitle.text = String.format(
            Locale.US, "%s %.2f %s", getString(R.string.please_pay_jd), oldSubTotal, getString(
                R.string.as_cash
            )
        )
        viewDataBinding!!.txtPayBody.text = String.format(
            Locale.US, "%s %.2f %s", getString(R.string.please_pay_jd), oldSubTotal, getString(
                R.string.to_store_for_transaction
            )
        )

        viewDataBinding!!.btnPayNextCreditCard.isClickable = false
        viewDataBinding!!.btnPayNextCreditCard.isEnabled = false

        setListeners()
    }

    private fun refreshViews() {
        viewDataBinding!!.txtPayTitle.text = String.format(
            Locale.US, "%s %.2f %s", getString(R.string.please_pay_jd), oldSubTotal, getString(
                R.string.as_cash
            )
        )
        viewDataBinding!!.txtPayBody.text = String.format(
            Locale.US, "%s %.2f %s", getString(R.string.please_pay_jd), oldSubTotal, getString(
                R.string.to_store_for_transaction
            )
        )
    }

    private fun setListeners() {
        // Cash Pay
        viewDataBinding!!.btnPayNext.setOnClickListener {
            // Move to next step (Receipt Info)
            val price =
                if (viewDataBinding!!.edtReceiptTotal.text.isEmpty()) 0.0 else viewDataBinding!!.edtReceiptTotal.text.toString()
                    .toDoubleOrNull() ?: 0.0
            Navigators.goToReceiptInfoActivity(this, orders!!.id ?: 0, price)
        }

        // CreditCard Pay
        viewDataBinding!!.btnPayNextCreditCard.setOnClickListener {

        }

        // Scan
        viewDataBinding!!.btnScan.setOnClickListener {
            if (!openScanner) {
                openScanner = true
                // Go to scan page
//                Navigators.goToScanditActivity(this, "", true)
                // open new scanner SDK
                startScanner()
            }
        }

        // Next
        viewDataBinding!!.btnConfirmOrder.setOnClickListener {
            if (validate()) {
                val price =
                    viewDataBinding!!.edtReceiptTotal.text.toString().toDoubleOrNull() ?: 0.0
                updateOrderSubtotal(price)
            }
        }
    }

    private fun startScanner() {
        BasketScanner.scan(onSuccess = {
            if (it != null && it.isNotEmpty()) {
                if (it.length > 3) {
                    val result = (it.toDoubleOrNull() ?: 0.0) / 1000
                    if (result != 0.0) {
                        viewDataBinding!!.edtReceiptTotal.setText(
                            String.format(
                                Locale.US,
                                "%.3f",
                                result
                            )
                        )
                    } else {
                        // Display the scan result without parsing
                        viewDataBinding!!.edtReceiptTotal.setText(it)
                    }
                } else {
                    // Display the scan result without parsing
                    viewDataBinding!!.edtReceiptTotal.setText(it)
                }
            }

        }, onCanceled = {}, onEmptyResult = {}, onFailure = {
            Toast.makeText(this@PaymentActivity, it.message + "", Toast.LENGTH_LONG).show()
        })
    }

    // Get otp for credit cards
    private fun getOrderOTP() {
        viewModel.getOrderOTP(orders!!.id!!, object : HandleResponse<OrderOTPResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected) {
                    Toast.makeText(this@PaymentActivity, error?.message, Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(
                        this@PaymentActivity,
                        resources?.getString(R.string.no_internet_conn_msg_txt),
                        Toast.LENGTH_SHORT
                    ).show()
                }

                if (isFirstOTPCall) {
                    isFirstOTPCall = false

                    // Start the timer to refresh the TOP
                    startOTPTimer()
                }
            }

            override fun handleSuccessResponse(successResponse: OrderOTPResponse) {
                if (successResponse.status == 200) {
                    if (successResponse.data != null && successResponse.data.isNotEmpty()) {

                        val otp = successResponse.data[0].otp
                        val decodedOtp =
                            Base64.decode(otp, Base64.DEFAULT).toString(charset("UTF-8"))

                        // show the decoded otp
                        viewDataBinding!!.txtOTP.text = decodedOtp

                        if (isFirstOTPCall) {
                            isFirstOTPCall = false

                            // Start the timer to refresh the TOP
                            startOTPTimer()
                        }

                        // Cancel the timer
//                        if (otpTimer != null){
//                            otpTimer!!.cancel()
//                        }

                    } else {
                        if (isFirstOTPCall) {
                            Toast.makeText(
                                this@PaymentActivity,
                                successResponse.message,
                                Toast.LENGTH_SHORT
                            ).show()

                            isFirstOTPCall = false

                            // Start the timer to refresh the TOP
                            startOTPTimer()
                        }

                    }
                } else {
                    if (isFirstOTPCall) {
                        Toast.makeText(
                            this@PaymentActivity,
                            successResponse.message,
                            Toast.LENGTH_SHORT
                        ).show()

                        isFirstOTPCall = false

                        // Start the timer to refresh the TOP
                        startOTPTimer()
                    }
                }
            }
        })
    }

    // Update the order status
    private fun setOrderStatusToCheckout() {
        viewModel.updateOrderStatus(
            STATUS_CHECKOUT,
            orders!!.id!!,
            object : HandleResponse<SimpleResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (isNetworkConnected) {
                        Toast.makeText(this@PaymentActivity, error?.message, Toast.LENGTH_SHORT)
                            .show()
                    } else {
                        Toast.makeText(
                            this@PaymentActivity,
                            resources?.getString(R.string.no_internet_conn_msg_txt),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun handleSuccessResponse(successResponse: SimpleResponse) {
                    val response = successResponse.response
                    if (response != null) {
                        if (response.httpCode == 200) {
                            // Send message
                            //////////////////////
                            val message: String =
                                AppConstants.MESSAGE_TYPE_CHECKING_OUT_ORDER + " " + PreferenceManager.currentShopperFirstName + " " + resources.getString(
                                    R.string.check_out_your_order
                                )

                            val systemMessageReq = SystemMessageReq(
                                orders!!.id!!.toString(),
                                "text",
                                message
                            )

                            sendSysteMessage(systemMessageReq) {
                                viewDataBinding!!.lvConfirmPayment.visibility = View.GONE

                                // Move to next step (Receipt Info)
                                val price =
                                    if (viewDataBinding!!.edtReceiptTotal.text.isEmpty()) 0.0 else viewDataBinding!!.edtReceiptTotal.text.toString()
                                        .toDoubleOrNull() ?: 0.0
                                Navigators.goToReceiptInfoActivity(
                                    this@PaymentActivity,
                                    orders!!.id ?: 0,
                                    price
                                )
                            }
                        } else {
                            Toast.makeText(
                                this@PaymentActivity,
                                response.message,
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } else {
                        Toast.makeText(
                            this@PaymentActivity,
                            getString(R.string.error_update_status),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            })
    }

    fun sendSysteMessage(systemMessageReq: SystemMessageReq, onAfterSystemMessage: () -> Unit) {
        viewModel.sendSystemMessage(systemMessageReq, object : HandleResponse<SystemMessage> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                onAfterSystemMessage()
            }

            override fun handleSuccessResponse(successResponse: SystemMessage) {
                onAfterSystemMessage()
            }
        })
    }

    // Update the subtotal
    private fun updateOrderSubtotal(newSubtotal: Double) {
        viewModel.shopperUpdateSubtotal(
            orders!!.id!!,
            newSubtotal,
            object : HandleResponse<SimpleResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (isNetworkConnected) {
                        Toast.makeText(this@PaymentActivity, error?.message, Toast.LENGTH_SHORT)
                            .show()
                    } else {
                        Toast.makeText(
                            this@PaymentActivity,
                            resources?.getString(R.string.no_internet_conn_msg_txt),
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

                override fun handleSuccessResponse(successResponse: SimpleResponse) {
                    val response = successResponse.response
                    if (response != null) {
                        if (response.httpCode == 200) {
                            // Update the UI
                            refreshViews()

                            viewDataBinding!!.lvConfirmPayment.visibility = View.GONE

                            if (paymentGatewayId == PAYMENT_TYPE_CASH_1 || paymentGatewayId == PAYMENT_TYPE_CASH_2) { // Cash on Delivery
                                setOrderStatusToCheckout()
                            } else { // CC or Bring CC order
                                startTimer()

                                if (paymentGatewayId == PAYMENT_TYPE_CREDIT) {
                                    viewDataBinding!!.txtPaymentTitle.setText(R.string.pay_using_credit_card)
                                } else {
                                    viewDataBinding!!.txtPaymentTitle.setText(R.string.bring_cc_machine)
                                }

                                viewDataBinding!!.lvPaymentTypeCreditCard.visibility = View.VISIBLE

                                // Get the otp for credit cards
                                getOrderOTP()
                            }
                        } else {
                            Toast.makeText(
                                this@PaymentActivity,
                                response.message,
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } else {
                        Toast.makeText(
                            this@PaymentActivity,
                            R.string.error_server_return_null,
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            })
    }

    // Get order data
    private fun getOrderData() {
        viewModel.getShopperOrderReview(orders!!.id!!, object : HandleResponse<ShopperOrderReview> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected) {
                    Toast.makeText(this@PaymentActivity, error?.message, Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(
                        this@PaymentActivity,
                        resources?.getString(R.string.no_internet_conn_msg_txt),
                        Toast.LENGTH_LONG
                    ).show()
                }
            }

            @SuppressLint("UseCompatLoadingForDrawables")
            override fun handleSuccessResponse(successResponse: ShopperOrderReview) {
                val response = successResponse.responseOrderReview
                if (response != null) {
                    if (response.httpCode != 200) {
                        Toast.makeText(this@PaymentActivity, response.message, Toast.LENGTH_SHORT)
                            .show()
                    } else {
                        outletDetails = response.outletDetails

                        if (outletDetails != null && outletDetails!!.cashierConfirmed == 1) {
                            // Stop timers
                            if (timer != null)
                                timer!!.cancel()

                            if (otpTimer != null) {
                                otpTimer!!.cancel()
                            }

                            viewDataBinding!!.btnPayNextCreditCard.isEnabled = true
                            viewDataBinding!!.btnPayNextCreditCard.isClickable = true
                            viewDataBinding!!.btnPayNextCreditCard.background =
                                resources.getDrawable(R.drawable.btn_bottom_radius)
//                            viewDataBinding!!.btnPayNextCreditCard.setTextColor(resources.getColor(R.color.colorWhite))

                            clickedWaitingTransactionButton()
                        }
                    }
                } else {
                    Toast.makeText(
                        this@PaymentActivity,
                        R.string.error_load_info,
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        })
    }

    // Clicked the "Waiting for process transaction"
    private fun clickedWaitingTransactionButton() {
        if (!payClick) {
            payClick = true
            if (orders != null && orders!!.id != null) {
                setOrderStatusToCheckout()
            }
        }
    }

    // Validate
    private fun validate(): Boolean {
        var isValid = true

        val totalStr = viewDataBinding!!.edtReceiptTotal.text.toString()
        try {
            when {
                totalStr.trim().isEmpty() -> {
                    Toast.makeText(
                        this,
                        R.string.please_enter_total_amount_on_the_receipt,
                        Toast.LENGTH_SHORT
                    ).show()
                    isValid = false
                }

                (totalStr.toDoubleOrNull() ?: 0.0) > 5000 -> {
                    Toast.makeText(this, R.string.please_check_total, Toast.LENGTH_SHORT).show()
                    isValid = false
                }

                (totalStr.toDoubleOrNull() ?: 0.0) <= 0 -> {
                    Toast.makeText(this, R.string.please_check_total, Toast.LENGTH_SHORT).show()
                    isValid = false
                }

                (totalStr.toDoubleOrNull() ?: 0.0) > oldSubTotal -> {
                    isValid = false
                    showConfirmDialog()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()

            isValid = false
            Toast.makeText(
                this,
                R.string.please_enter_total_amount_on_the_receipt,
                Toast.LENGTH_SHORT
            ).show()
        }

        return isValid

    }

    private fun showConfirmDialog() {
        totalConfirmDialog = TotalConfirmDialogFragment()
        totalConfirmDialog!!.show(supportFragmentManager, "TotalConfirmDialog")
        totalConfirmDialog!!.listener = onDialogClickListener
    }

    /**
     * TotalConfirmDialog Listener
     */
    val onDialogClickListener = object : TotalConfirmDialogFragment.DialogButtonClickListener {
        override fun onClickOk() {
            val price =
                if (viewDataBinding!!.edtReceiptTotal.text.isEmpty()) 0.0 else viewDataBinding!!.edtReceiptTotal.text.toString()
                    .toDoubleOrNull() ?: 0.0
            updateOrderSubtotal(price)
        }

        override fun onClickCancel() {
            // Didn't agree
        }
    }

    // Start the timer
    private fun startTimer() {
        val delay = TimeUnit.SECONDS.toMillis(5) // delay for 5 secs.
        val period = TimeUnit.SECONDS.toMillis(10) // repeat every 10 secs.

        if (timer != null) {
            timer!!.cancel()
        }

        timer = Timer()
        timer!!.scheduleAtFixedRate(object : TimerTask() {
            override fun run() {
                //Call function
                runOnUiThread { if (!isDestroyed) getOrderData() }
            }
        }, delay, period)
    }

    // Start the otp timer
    private fun startOTPTimer() {
        val delay = TimeUnit.SECONDS.toMillis(8) // delay for 8 secs.
        val period = TimeUnit.SECONDS.toMillis(5) // repeat every 5 secs.

        if (otpTimer != null) {
            otpTimer!!.cancel()
        }

        otpTimer = Timer()
        otpTimer!!.scheduleAtFixedRate(object : TimerTask() {
            override fun run() {
                //Call function
                runOnUiThread { if (!isDestroyed) getOrderOTP() }
            }
        }, delay, period)
    }

    override fun onResume() {
        super.onResume()

        openScanner = false
        payClick = false

        isFirstOTPCall = true

        if ((paymentGatewayId == PAYMENT_TYPE_CREDIT || paymentGatewayId == PAYMENT_TYPE_BRING_CC)
            && viewDataBinding!!.lvPaymentTypeCreditCard.visibility == View.VISIBLE
        ) {
            startTimer()

            // auto-refresh to get the OTP
            getOrderOTP()
        }
    }

    override fun onStart() {
        super.onStart()

        openScanner = false
        payClick = false

        isFirstOTPCall = true
    }

    override fun onStop() {
        super.onStop()

        if (timer != null) {
            timer!!.cancel()
        }

        if (otpTimer != null) {
            otpTimer!!.cancel()
        }
    }

    override fun onDestroy() {
        super.onDestroy()

        if (timer != null) {
            timer!!.cancel()
        }

        if (otpTimer != null) {
            otpTimer!!.cancel()
        }
    }

    override fun onBackPressed() {
        hideKeyboard()
//        super.onBackPressed()

        // Go to Dashboard
        Navigators.goToDashboard(this)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        openScanner = false

        if (requestCode == SCAN_ACTIVITY && resultCode == Activity.RESULT_OK) {
            if (data != null && data.extras != null) {
                val scanResult = data.extras!!.getString("ScanResult")
                if (scanResult != null && scanResult.isNotEmpty()) {
                    if (scanResult.length > 3) {
                        val result = (scanResult.toDoubleOrNull() ?: 0.0) / 1000
                        if (result != 0.0) {
                            viewDataBinding!!.edtReceiptTotal.setText(
                                String.format(
                                    Locale.US,
                                    "%.3f",
                                    result
                                )
                            )
                        } else {
                            // Display the scan result without parsing
                            viewDataBinding!!.edtReceiptTotal.setText(scanResult)
                        }
                    } else {
                        // Display the scan result without parsing
                        viewDataBinding!!.edtReceiptTotal.setText(scanResult)
                    }
                }
            }
        }
    }
}