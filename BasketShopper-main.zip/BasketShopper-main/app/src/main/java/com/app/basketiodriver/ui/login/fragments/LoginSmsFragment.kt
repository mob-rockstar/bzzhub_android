package com.app.basketiodriver.ui.login.fragments

import android.os.Bundle
import android.view.View
import bloder.com.blitzcore.enableWhen
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentLoginSmsBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.login.LoginActivity
import com.app.basketiodriver.ui.login.LoginViewModel
import com.mukesh.countrypicker.Country
import com.mukesh.countrypicker.CountryPicker
import com.mukesh.countrypicker.OnCountryPickerListener


/**
Created by ibraheem lubbad on 2020-01-15.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class LoginSmsFragment : BaseFragment<FragmentLoginSmsBinding?, LoginViewModel>(),
    OnCountryPickerListener,
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_login_sms

    override val viewModel: LoginViewModel
        get() {
            return getViewModel(requireActivity(), LoginViewModel::class.java)
        }

    var mCountryPicker: CountryPicker? = null


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.log_in_with_sms))


        /**
         * read coming data via  intent if has mobile number click on next verify mobile number directly
         */
        if (activity!!.intent.hasExtra(LoginActivity.KEY_MOBILE_NUMBER) &&
            activity!!.intent.getStringExtra(LoginActivity.KEY_MOBILE_NUMBER) != null
        ) {
            viewDataBinding!!.edMobileNumber.setText(activity!!.intent.getStringExtra(LoginActivity.KEY_MOBILE_NUMBER))
            viewDataBinding!!.countryCodeTex.text =
                activity!!.intent.getStringExtra(LoginActivity.KEY_MOBILE_CODE_NUMBER)
            viewDataBinding!!.btnNext.callOnClick()
        } else {
            /**
             * set default value
             */
            viewDataBinding!!.edMobileNumber.setText(viewModel.mobileNumber)
            viewDataBinding!!.countryCodeTex.text = viewModel.codeMobileNumber

        }

        validation()
        setListener()
    }

    private fun validation() {
        viewDataBinding!!.btnNext.enableWhen {
            viewDataBinding!!.edMobileNumber.isPhoneNumber() onValidationSuccess {
                viewDataBinding!!.edMobileNumber.onSuccess()
            } onValidationError {
                viewDataBinding!!.edMobileNumber.onError()
            }
        }
    }

    /**
     * Used for set listener
     */
    private fun setListener() {
        val builder = CountryPicker.Builder().with(baseActivity!!)
            .listener(this)

        mCountryPicker = builder.build()

        viewDataBinding!!.countryCodeLayout.setOnClickListener {
            run {
                mCountryPicker!!.showDialog(baseActivity!!)
            }
        }

        // Go to Login with password page
        viewDataBinding!!.btnLoginWithPassword.setOnClickListener {
            navigate(LoginSmsFragmentDirections.actionLoginSmsFragmentToLoginPasswordFragment())
        }

        // Tap the Send code button
        viewDataBinding!!.btnNext.setOnClickListener {
            run {
                hideKeyboard()
                viewDataBinding!!.tvStatus.visibility = View.VISIBLE
                val code = viewDataBinding!!.countryCodeTex.text.toString()
                val mobile = viewDataBinding!!.edMobileNumber.text.toString()

                // Validate the mobile number user entered
//                viewModel.validateMobileNumber(
//                    code,
//                    mobile,
//                    object : HandleResponse<CheckMobileResponse> {
//                        override fun handleErrorResponse(error: ErrorResponse?) {
//                            viewDataBinding!!.tvError.text = error?.message
//                            viewDataBinding!!.tvStatus.visibility = View.GONE
//                        }
//
//                        override fun handleSuccessResponse(successResponse: CheckMobileResponse) {
//                            navigate(LoginSmsFragmentDirections.actionLoginFragmentToOtpVerificationFragment())
//                        }
//
//                    })

                // Go to Enter SMS Code page
                navigate(LoginSmsFragmentDirections.actionLoginFragmentToOtpVerificationFragment())
            }
        }
    }

    override fun onSelectCountry(country: Country?) {
        viewDataBinding!!.countryCodeTex.text = country?.dialCode
    }
}
