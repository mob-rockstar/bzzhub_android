package com.app.basketiodriver.ui.dashbaord


import androidx.fragment.app.Fragment
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentIncomingBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.home.HomeViewModel


/**
 * A simple [Fragment] subclass.
 */
class IncomingFragment : BaseFragment<FragmentIncomingBinding?, HomeViewModel>(),
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_incoming

    override val viewModel: HomeViewModel
        get() {
            return getViewModel(requireActivity(), HomeViewModel::class.java)
        }

    companion object {

        fun newInstance(
        ): IncomingFragment {
            val fragment = IncomingFragment()

            return fragment
        }
    }


}
