package com.app.basketiodriver.data.model.api.response

import com.app.basketiodriver.data.model.api.response.Base.BaseResponse
import com.google.gson.annotations.SerializedName


/**
Created by ibraheem lubbad on 2020-02-24.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class EarningReportResponse : BaseResponse() {

    @SerializedName("data")
    var earningReportResponse: EarningReportData? = null

    class EarningReportData(
        @SerializedName("total_balance") val total_balance: Double = 0.0,
        @SerializedName("total_tips") val total_tips: Double = 0.0,
        @SerializedName("total_incentives") val total_incentives: Double = 0.0,
        @SerializedName("total_earnings") val total_earnings: Double = 0.0,
        @SerializedName("total_collected") val total_collected: Double = 0.0,
        @SerializedName("total_promo") val total_promo: Double = 0.0,
        @SerializedName("current_account_balance") val current_account_balance: Double = 0.0,
        @SerializedName("is_account_suspended") val is_account_suspended: Boolean = true

    )

}