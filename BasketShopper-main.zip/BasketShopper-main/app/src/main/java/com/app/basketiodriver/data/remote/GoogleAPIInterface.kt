package com.app.basketiodriver.data.remote

import com.app.basketiodriver.data.model.api.response.directions.ServerAnswer
import io.reactivex.Single
import retrofit2.http.GET
import retrofit2.http.Query


interface GoogleAPIInterface {

    @GET("directions/json")
    fun getDirections(
        @Query("origin") origin: String?,
        @Query("destination") destination: String?,
        @Query("key") key: String?,
        @Query("mode") mode: String?
    ): Single<ServerAnswer>
}