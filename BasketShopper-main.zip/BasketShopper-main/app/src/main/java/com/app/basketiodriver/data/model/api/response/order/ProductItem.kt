package com.app.basketiodriver.data.model.api.response.order

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName
import java.io.Serializable
import java.util.*

class ProductItem : Serializable{
    @SerializedName("orders_outlets_items_id")
    @Expose
    val ordersOutletsItemsId: Int? = null

    @SerializedName("outlet_item_id")
    @Expose
    val outletItemId: Int? = null

    @SerializedName("item_ordered_qty")
    @Expose
    val itemOrderedQty: Double? = null

    @SerializedName("item_product_image")
    @Expose
    val itemProductImage: String? = null

    @SerializedName("item_product_info_image")
    @Expose
    val itemProductInfoImage: String? = null

    @SerializedName("item_barcode")
    @Expose
    val itemBarcode: String? = null

    @SerializedName("item_department_name")
    @Expose
    val itemDepartmentName: String? = null

    @SerializedName("item_aisle_name")
    @Expose
    val itemAisleName: String? = null

    @SerializedName("item_department_aisle_name")
    @Expose
    val itemDepartmentAisleName: String? = null

    @SerializedName("item_product_name")
    @Expose
    val itemProductName: String? = null

    @SerializedName("item_approx_weight")
    @Expose
    val itemApproxWeight: Double = 0.0

    @SerializedName("item_selling_price")
    @Expose
    val itemSellingPrice: Double? = null

    @SerializedName("item_sold_per")
    @Expose
    val itemSoldPer: Int = 0

    @SerializedName("item_sold_per_label")
    @Expose
    val itemSoldPerLabel: String? = null

    @SerializedName("item_unit")
    @Expose
    var itemUnit: String = ""

    @SerializedName("item_label_value")
    @Expose
    val itemLabelValue: String? = null

    @SerializedName("item_each_suffix")
    @Expose
    var itemEachSuffix: Int? = null

    @SerializedName("item_shopper_tips")
    @Expose
    val itemShopperTips: String? = null

    @SerializedName("item_customer_comments")
    @Expose
    val itemCustomerComments: String? = null

    @SerializedName("item_status")
    @Expose
    val itemStatus: String? = null

    fun getDescriptionLabel() : String{
        return when (itemSoldPer) {
            1 -> if (itemLabelValue != null) String.format(
                Locale.US,
                "(%s %s)",
                itemLabelValue.trim(),
                itemUnit.trim()
            ) else ""
            2 -> ""
            3 -> String.format(
                Locale.US,
                "(%s %s each)",
                itemApproxWeight ?: 0,
                itemUnit.trim()
            )
            else -> ""
        }
    }
}