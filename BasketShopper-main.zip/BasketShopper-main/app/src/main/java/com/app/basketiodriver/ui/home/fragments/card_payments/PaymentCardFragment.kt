package com.app.basketiodriver.ui.home.fragments.card_payments

import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.View
import androidx.fragment.app.Fragment
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentPaymentCardBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.home.HomeViewModel
import com.app.basketiodriver.ui.payment_cards.GooglePaymentActivity

/**
 * A simple [Fragment] subclass.
 */
class PaymentCardFragment : BaseFragment<FragmentPaymentCardBinding?, HomeViewModel>(),
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_payment_card

    override val viewModel: HomeViewModel
        get() {
            return getViewModel(requireActivity(), HomeViewModel::class.java)
        }

    companion object {

        fun newInstance(
        ): PaymentCardFragment {
            val fragment =
                PaymentCardFragment()
            return fragment
        }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_info, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.payment_card))
        setHasOptionsMenu(true)
        viewDataBinding!!.physicalCardLayout.setOnClickListener {
            navigate(PaymentCardFragmentDirections.actionPaymentCardFragmentToPhysicalCardFragment())
        }

        viewDataBinding!!.googleCardLayout.setOnClickListener {
            startActivity(GooglePaymentActivity.newIntent(requireContext()))
        }
    }

}
