package com.app.basketiodriver.ui.onboarding

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.Navigation
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.ActivityOnBoardingBinding
import com.app.basketiodriver.ui.base.BaseActivity
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import javax.inject.Inject

/**
 * Created by ibraheem lubbad on 2020-01-22.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class OnBoardingActivity : BaseActivity<ActivityOnBoardingBinding?, OnBoardingViewModel>(),
    HasAndroidInjector {


    override val layoutId: Int
        get() = R.layout.activity_on_boarding

    override val viewModel: OnBoardingViewModel
        get() {
            return getViewModel(OnBoardingViewModel::class.java)
        }

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>
    override fun androidInjector() = dispatchingAndroidInjector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initToolbar(
            "",
            true, viewDataBinding!!.toolbarLayout.toolbar,
            View.OnClickListener {
                run {
                    if (!Navigation.findNavController(
                            this,
                            R.id.navHostOnBoardingFragments
                        ).popBackStack()
                    ) {
                        finish()
                    }
                }
            })
        viewModel.initStages()
    }

    companion object {
        fun newIntent(context: Context?): Intent {
            return Intent(context, OnBoardingActivity::class.java)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
    }
}
