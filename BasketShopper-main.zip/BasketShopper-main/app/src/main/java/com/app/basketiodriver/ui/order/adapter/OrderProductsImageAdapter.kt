package com.app.basketiodriver.ui.order.adapter

import android.util.Log
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.model.api.response.order.Product
import com.app.basketiodriver.data.model.api.response.order.ProductItem
import com.app.basketiodriver.utils.GlideApp

class OrderProductsImageAdapter(private val mActivity : FragmentActivity, private val productItems : List<Product>, val list : List<OrdersItem>) : OrderReviewListAdapter(mActivity , list) {
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
//        super.onBindViewHolder(holder, position)

        val myHolder = holder as OrderReviewHolder
        val item = productItems[position]

        // Display the product image
        if (item.itemProductImage != null) {
            GlideApp.with(mActivity).load(item.itemProductImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(myHolder.binding.ivItem)
        }
        else{
            Log.d("OrderReview", "********** Product Image is Null *************")
        }
    }

    override fun getItemCount(): Int {
        return productItems.size
    }
}