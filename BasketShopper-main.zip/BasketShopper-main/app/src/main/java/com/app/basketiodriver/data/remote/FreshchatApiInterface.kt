package com.app.basketiodriver.data.remote

import com.app.basketiodriver.data.model.api.response.ShopperAppConfigResponse
import com.app.basketiodriver.data.model.api.ticket.TicketFieldsData
import com.google.gson.JsonObject
import io.reactivex.Single
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import java.util.Objects

interface FreshchatApiInterface {

    @GET("ticket_fields")
    fun getTicketFields(): Single<ArrayList<TicketFieldsData>>

    @POST("tickets")
    fun createTicket(@Body body : HashMap<String, Any>) : Single<JsonObject>
}