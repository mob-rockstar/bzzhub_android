
package com.app.basketiodriver.data.local.db.dao

import androidx.room.*
import com.app.basketiodriver.data.model.api.User
import io.reactivex.Single


/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
@Dao
interface UserDao {
    @Query("SELECT * FROM users")
    fun loadAll(): List<User?>?
    @Delete
    fun delete(user: User?)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(user: User?)

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1 ")
    fun findById(id: Int?): Single<User?>?

    @Query("SELECT * FROM users LIMIT 1 ")
    fun getCurreatUser(): Single<User?>?


/*    @Delete
    fun delete(user: User?)

    @Query("SELECT * FROM users WHERE name LIKE :name LIMIT 1")
    fun findByName(name: String?): Single<User?>?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(user: User?)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(users: List<User?>?)



    @Query("SELECT * FROM users WHERE id IN (:userIds)")
    fun loadAllByIds(userIds: List<Int?>?): List<User?>?*/
}