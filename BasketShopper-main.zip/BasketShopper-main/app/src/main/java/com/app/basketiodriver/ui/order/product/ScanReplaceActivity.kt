package com.app.basketiodriver.ui.order.product

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.text.Html
import android.util.Log
import android.view.*
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import com.app.basketiodriver.BuildConfig
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.model.api.response.order.CommonResponse
import com.app.basketiodriver.data.model.api.response.order.ItemResponse
import com.app.basketiodriver.data.model.api.response.order.ReplacementOrdersItemRequest
import com.app.basketiodriver.data.remote.socket.SystemMessage
import com.app.basketiodriver.data.remote.socket.SystemMessageReq
import com.app.basketiodriver.databinding.ActivityScanReplaceBinding
import com.app.basketiodriver.databinding.DialogAddCashAmountBinding
import com.app.basketiodriver.databinding.DialogItemScannedBinding
import com.app.basketiodriver.di.Navigators
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.app.basketiodriver.ui.dialogs.AmountDialogFragment
import com.app.basketiodriver.utils.AppConstants
import com.app.basketiodriver.utils.GlideApp
import com.app.basketiodriver.utils.PopupUtils
import com.app.basketiodriver.utils.order.OrderItemSingleton
import com.app.basketiodriver.utils.price.PriceConstructor
import com.squareup.picasso.Picasso
import com.tbruyelle.rxpermissions2.RxPermissions
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import java.util.*

import javax.inject.Inject
import kotlin.collections.ArrayList

class ScanReplaceActivity : BaseActivity<ActivityScanReplaceBinding, OrderDetailsViewModel>(),
    HasAndroidInjector,
//    OnScanListener,
    AmountDialogFragment.AmountDialogOnClickListener{

    override val layoutId: Int
        get() = R.layout.activity_scan_replace

    override val viewModel: OrderDetailsViewModel
        get() {
            return getViewModel(OrderDetailsViewModel::class.java)
        }

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>
    override fun androidInjector() = dispatchingAndroidInjector

    var item : OrdersItem? = null
    var newItem : OrdersItem? = null
    var orderId : Long = 0

    var isReplaceItem : Int = 0

    // Barcode picker
//    var picker : BarcodePicker?= null

    // AmountDialog
    var amountDialog : AmountDialogFragment? = null

    // Replacement Items
    var scannedItems : MutableList<OrdersItem> = arrayListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (intent.extras != null) {
            orderId      = intent.extras!!.getLong("ARG_ORDER_ID")
            item         = intent.extras!!.getSerializable("ARG_ORDERS_ITEM") as? OrdersItem
            isReplaceItem = intent.extras!!.getInt("ARG_IS_REPLACEMENT", 0)
        }

        initView()
    }

    @SuppressLint("LogNotTimber")
    private fun initView(){
//        initBarcodeReader()
        setListeners()

        Log.d("ScanReplaceActivity", "Replacement Limit : " + viewModel.replaceLimitCount)
    }

    // Initialize the Barcode Reader
//    private fun initBarcodeReader(){
//        ScanditLicense.setAppKey(BuildConfig.SCANDIT_KEY)
//        val settings : ScanSettings = ScanSettings.create()
//        val symbolsToEnable = intArrayOf(
//            Barcode.SYMBOLOGY_EAN13,
//            Barcode.SYMBOLOGY_EAN8,
//            Barcode.SYMBOLOGY_UPCA,
//            Barcode.SYMBOLOGY_CODE39,
//            Barcode.SYMBOLOGY_CODE128
//        )
//        for (sym in symbolsToEnable) {
//            settings.setSymbologyEnabled(sym, true)
//        }
//        picker = BarcodePicker(this, settings)
//        picker!!.setOnScanListener(this)
//        viewDataBinding!!.relativeCamera.addView(
//            picker, FrameLayout.LayoutParams(
//                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
//            )
//        )
//    }

    private fun setListeners(){
        viewDataBinding!!.refreshCamera.setOnClickListener {
            newItem = null

//            if (picker != null){
//                picker!!.startScanning()
//                it.visibility = View.GONE
//            }
        }
    }

    // Show the amount dialog
    private fun showAmountDialog(){
        try{
            amountDialog = AmountDialogFragment.newInstance(item!!, scannedItems, item!!.itemQty ?: 0.0)
            amountDialog!!.show(supportFragmentManager, AmountDialogFragment.javaClass.name)
            amountDialog!!.setAmountNextClickListener(this)
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    // Replace the multiple items
    private fun replaceMultipleItems(items : ArrayList<ReplacementOrdersItemRequest>){
        val oldItemId = if (item!!.replacementRequested != null && item!!.replacementRequested == 1) ((item!!.oldOutletItemId ?: "0").toLongOrNull() ?: 0) else (item!!.outletItemId ?: 0).toLong()

        viewModel.replaceMultipleOrdersItems(oldItemId, orderId, items, 1, object : HandleResponse<CommonResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                Toast.makeText(this@ScanReplaceActivity, error?.message, Toast.LENGTH_SHORT).show()
            }

            override fun handleSuccessResponse(successResponse: CommonResponse) {
                if (successResponse.status == 200) {
                    var message = ""
                    message = if (item!!.replacementRequested != null && item!!.replacementRequested == 1){
                        AppConstants.MESSAGE_TYPE_REPLACED + " " + PreferenceManager.currentShopperFirstName + " " + getString(R.string.replaced) + ","+ getString(R.string.item) + " " + item!!.oldProductName + ", " + getString(R.string.with_1) + ", " +getString(R.string.item) + " "+ items[0].product!!.productName+"."
                    } else{
                        AppConstants.MESSAGE_TYPE_REPLACED + " " + PreferenceManager.currentShopperFirstName + " " + getString(R.string.replaced) + ", " + getString(R.string.item) + " "+ item!!.productName + ", " + getString(R.string.with_1) + ", "+ getString(R.string.item) + " "+ items[0].product!!.productName+"."
                    }

                    // Send system message to user
                    val systemMessageReq = SystemMessageReq(orderId.toString(), "text", message)
                    sendSystemMessage(systemMessageReq){
                        setResult(Activity.RESULT_OK)
                        finish()
                    }
                }
                else{
                    Toast.makeText(this@ScanReplaceActivity, successResponse.message, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    private fun sendSystemMessage(systemMessageReq: SystemMessageReq, onAfterSystemMessageClicked: ()->Unit){
        viewModel.sendSystemMessage(systemMessageReq, object : HandleResponse<SystemMessage> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                onAfterSystemMessageClicked()
            }

            override fun handleSuccessResponse(successResponse: SystemMessage) {
                onAfterSystemMessageClicked()
            }
        })
    }

    // Replace item
    private fun replaceItem(itemId: Long, amount: Double, weight: Double?){

        val oldItemId = if (item!!.replacementRequested != null && item!!.replacementRequested == 1) ((item!!.oldOutletItemId ?: "0").toLongOrNull() ?: 0) else (item!!.outletItemId ?: 0).toLong()
        viewModel.shopperReplaceItem(amount, oldItemId, itemId, orderId, 1, object : HandleResponse<CommonResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                Toast.makeText(this@ScanReplaceActivity, error?.message, Toast.LENGTH_SHORT).show()
            }

            override fun handleSuccessResponse(successResponse: CommonResponse) {
                if (successResponse.status == 200) {
                    setResult(Activity.RESULT_OK)
                    finish()
                }
                else{
                    Toast.makeText(this@ScanReplaceActivity, successResponse.message, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    // Check the barcode
    private fun checkBarcode(barcode : String){
        viewModel.getProductByBarcode(orderId, barcode, object : HandleResponse<ItemResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                Toast.makeText(this@ScanReplaceActivity, error?.message, Toast.LENGTH_SHORT).show()
            }

            override fun handleSuccessResponse(successResponse: ItemResponse) {
                if (successResponse.response != null){
                    if (successResponse.response.httpCode == 200){
                        // Show the ProductDialog
                        if (successResponse.response.itemDetails != null)
                            showScannedProductDialog(successResponse.response.itemDetails)
                        else
                            Toast.makeText(this@ScanReplaceActivity, successResponse.response.message, Toast.LENGTH_SHORT).show()
                    }
                    else if (successResponse.response.httpCode == 201){
                        createCustomPlacement(barcode)
                    }
                    else{
                        Toast.makeText(this@ScanReplaceActivity, successResponse.response.message, Toast.LENGTH_SHORT).show()
                    }
                }
                else{
                    Toast.makeText(this@ScanReplaceActivity, R.string.error_server_return_null, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    private fun createCustomPlacement(barcode: String){
        Navigators.goToReplaceCustomItemActivity(this, barcode, item!!.ordersOutletsItemsId ?: 0)
    }

    // Show the item popup after scanned the item
    private fun showScannedProductDialog(scanItem : OrdersItem){
        newItem = scanItem

        // Save the scanned item
        scannedItems.add(scanItem)

        try {
            val dialog = Dialog(this)
            val binding: DialogItemScannedBinding = DataBindingUtil.inflate(LayoutInflater.from(this), R.layout.dialog_item_scanned,null,false)

            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setContentView(binding.root)
            dialog.setCancelable(false)
            dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window?.setGravity(Gravity.CENTER)
            dialog.setOnKeyListener { it, keyCode, event -> // Prevent dialog close on back press button
                keyCode == KeyEvent.KEYCODE_BACK
            }

            // Cancel
            binding.tvCancel.setOnClickListener {
                // Remove the all scanned items
                scannedItems.clear()

                // Dismiss the dialog
                dialog.dismiss()

                viewDataBinding!!.refreshCamera.visibility = View.GONE
//                if (picker != null)
//                    picker!!.startScanning()
            }

            // Confirm
            binding.tvConfirm.setOnClickListener {
                dialog.dismiss()

                // Show the Enter amount & weight dialog
                showAmountDialog()
            }

            // Scan more item
            binding.tvScanMore.setOnClickListener {
                if (scannedItems.size >= OrderItemSingleton.getReplacementLimit()) {
                    // Show alert
                    val msg = String.format(Locale.ENGLISH, getString(R.string.msg_replacement_limit_count), OrderItemSingleton.getReplacementLimit())
                    showErrorMessages(msg)
                }
                else{
                    // Scan more item
                    dialog.dismiss()

                    viewDataBinding!!.refreshCamera.visibility = View.GONE
//                    if (picker != null)
//                        picker!!.startScanning()
                }
            }

            // Show the Item information
            // Product image
            if (scanItem.productImage != null){
//                Picasso.get().load(scanItem.productImage).fit().error(R.drawable.placeholder).into(binding.productLayout.orderItemImage)
                GlideApp.with(this).load(scanItem.productImage).error(R.drawable.placeholder).into(binding.productLayout.orderItemImage)
            }

            // Title
            binding.productLayout.orderItemTitle.text = scanItem.productName ?: "N/A"// + " " + item.aisleName

            // Cost
            binding.productLayout.orderCost.text = Html.fromHtml(PriceConstructor.getFormatPrice(item, PriceConstructor.LabelType.SIMPLE, PreferenceManager.currency,true))

            // Description
            if (scanItem.getDescriptionLabel().isEmpty()) {
                binding.productLayout.tvPriceDescription.visibility = View.GONE
            } else {
                binding.productLayout.tvPriceDescription.visibility = View.VISIBLE
                binding.productLayout.tvPriceDescription.text = scanItem.getDescriptionLabel()
            }

            PopupUtils.setDefaultDialogProperty(dialog)
            dialog.show()
        }
        catch (e : Exception) {
            e.printStackTrace()
        }
    }

    private fun setDataToView(root : View, item : OrdersItem){
        try {
            val itemImageView: ImageView = root.findViewById(R.id.order_item_image)
            val itemTitleView: TextView = root.findViewById(R.id.order_item_title)
            val itemCostView: TextView = root.findViewById(R.id.order_cost)
            val priceDescription: TextView = root.findViewById(R.id.tvPriceDescription)

            // Product image
            if (item.productImage != null){
//                Picasso.get().load(item.productImage).fit().error(R.drawable.placeholder)
//                    .into(itemImageView)
                GlideApp.with(this).load(item.productImage).error(R.drawable.placeholder).into(itemImageView)
            }

            // Title
            itemTitleView.text = item.productName!!// + " " + item.aisleName

            // Cost
            itemCostView.text = Html.fromHtml(PriceConstructor.getFormatPrice(item, PriceConstructor.LabelType.SIMPLE, PreferenceManager.currency,true
                )
            )

            // Description
            if (item.getDescriptionLabel().isEmpty()) {
                priceDescription.visibility = View.GONE
            } else {
                priceDescription.visibility = View.VISIBLE
                priceDescription.text = item.getDescriptionLabel()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Check if permission is granted
    @SuppressLint("MissingPermission", "CheckResult")
//    private fun grantCameraPermission(){
//        val permissions = RxPermissions(this)
//        permissions.request(Manifest.permission.CAMERA)
//            .subscribe { granted: Boolean ->
//                if (granted) {
//                    if (picker != null) {
//                        picker!!.startScanning()
//                        viewDataBinding!!.refreshCamera.visibility = View.GONE
//                    }
//                }
//            }
//    }

    /**
     * ScanListener
     */
//    override fun didScan(scanSession: ScanSession?) {
//        if (scanSession != null && scanSession.newlyRecognizedCodes.size > 0) {
//            val barcode = scanSession.newlyRecognizedCodes[0].data
//
//            runOnUiThread {
//                checkBarcode(barcode)
//                if (picker != null) {
//                    picker!!.stopScanning()
//                }
//
//                viewDataBinding!!.refreshCamera.visibility = View.VISIBLE
//            }
//        }
//    }

    // Called when replaced the item with multiple items
    override fun onNextClick(requestItems: ArrayList<ReplacementOrdersItemRequest>) {
        replaceMultipleItems(requestItems)
    }
    override fun onNextClick(amount: Double) {
        if (amountDialog != null && amountDialog!!.isAdded){
            amountDialog!!.dismiss()
        }

        if (newItem != null && newItem!!.soldPer != 3){
            // replace item
            replaceItem((newItem!!.outletItemId ?: 0).toLong(), amount, null)
        }
    }

    override fun onNextClick(itemId: Long, amount: Double) {

    }

    override fun onNextClick(amount: Double, weight: Double) {
        if (newItem != null)
            replaceItem((newItem!!.outletItemId ?: 0).toLong(), amount, weight)
    }


    override fun onNextClick(itemId: Long, amount: Double, weight: Double) {

    }

    /**
     * OnActivityResult
     */
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {

        if (resultCode == RESULT_OK) {
            if (requestCode == REPLACE_ITEM_REQUEST){
                setResult(Activity.RESULT_OK)
                finish()
            }
        }

        super.onActivityResult(requestCode, resultCode, data)
    }

    override fun onResume() {
        super.onResume()

//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
//            grantCameraPermission()
//        }
//        else{
//            if (picker != null){
//                picker!!.startScanning()
//            }
//        }
    }

    override fun onPause() {
//        if (picker != null)
//            picker!!.stopScanning()

        super.onPause()
    }

    companion object{
        const val REPLACE_ITEM_REQUEST = 4543
    }
}