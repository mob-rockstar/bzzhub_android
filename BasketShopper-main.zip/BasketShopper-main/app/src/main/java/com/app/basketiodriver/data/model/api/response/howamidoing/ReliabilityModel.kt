package com.app.basketiodriver.data.model.api.response.howamidoing

import android.os.Parcel
import com.thoughtbot.expandablerecyclerview.models.ExpandableGroup

class ReliabilityModel : ExpandableGroup<RIRecords> {
    constructor(title: String?, items: MutableList<RIRecords>?) : super(title, items)
    constructor(inn : Parcel?) : super(inn)
}