package com.app.basketiodriver.ui.onboarding

import com.app.basketiodriver.ui.base.BaseNavigator

/**
 * Created by ibraheem lubbad on 2020-01-22.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
interface OnBoardingNavigator : BaseNavigator