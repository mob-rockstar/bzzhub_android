/*
 * Copyright (C) 2017 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.app.basketiodriver.di.builder


import com.app.basketiodriver.ui.dashbaord.AcknowledgeFragment
import com.app.basketiodriver.ui.dashbaord.IncomingFragment
import com.app.basketiodriver.ui.dashbaord.LocationInstructionFragment
import com.app.basketiodriver.ui.dialogs.*
import com.app.basketiodriver.ui.earning.fragments.SummaryFragment
import com.app.basketiodriver.ui.home.fragments.*
import com.app.basketiodriver.ui.home.fragments.card_payments.PaymentCardFragment
import com.app.basketiodriver.ui.home.fragments.card_payments.PhysicalCardFragment
//import com.app.basketiodriver.ui.home.fragments.earnings.CashOutFragment
//import com.app.basketiodriver.ui.home.fragments.full0rder.OrderStatusDoneFragment
//import com.app.basketiodriver.ui.home.fragments.full0rder.OrderStatusInreviewFragment
//import com.app.basketiodriver.ui.home.fragments.full0rder.OrderToDoFragment
//import com.app.basketiodriver.ui.home.fragments.full0rder.fragments.CanNotFindItemFragment
//import com.app.basketiodriver.ui.home.fragments.full0rder.fragments.OrderDetailFragment
//import com.app.basketiodriver.ui.home.fragments.messages.ChatMessagesFragment
//import com.app.basketiodriver.ui.home.fragments.messages.InboxFragment
//import com.app.basketiodriver.ui.home.fragments.messages.MessageFragment
import com.app.basketiodriver.ui.home.fragments.promotions.PromotionTypeFragment
import com.app.basketiodriver.ui.home.fragments.promotions.PromotionsFragment
import com.app.basketiodriver.ui.profile.fragments.ProfileFragment
import com.app.basketiodriver.ui.weekhours.fragments.HoursWeekFragment
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class FragmentDrawerModule {

    @ContributesAndroidInjector
    abstract fun contributeHoursFragment(): HoursFragment

    @ContributesAndroidInjector
    abstract fun contributeHoursWeekFragment(): HoursWeekFragment

    @ContributesAndroidInjector
    abstract fun contributeEarningFragment(): EarningFragment

    @ContributesAndroidInjector
    abstract fun contributeSummaryFragment(): SummaryFragment

    @ContributesAndroidInjector
    abstract fun contributeIncomingFragment(): IncomingFragment

    @ContributesAndroidInjector
    abstract fun contributeAcknowledgeFragment(): AcknowledgeFragment


    @ContributesAndroidInjector
    abstract fun contributeOndemandDashbaordFragment(): OndemandDashbaordFragment

    @ContributesAndroidInjector
    abstract fun contributeLocationInstructionFragment(): LocationInstructionFragment

    @ContributesAndroidInjector
    abstract fun contributeCreateTicketDialogFragment(): CreateTicketDialogFragment
//    @ContributesAndroidInjector
//    abstract fun contributeChatMessagesFragment(): ChatMessagesFragment
//
//    @ContributesAndroidInjector
//    abstract fun contributeInboxFragment(): InboxFragment
//
//    @ContributesAndroidInjector
//    abstract fun contributeMessageFragment(): MessageFragment

    @ContributesAndroidInjector
    abstract fun contributeSettingsFragment(): SettingsFragment
    @ContributesAndroidInjector
    abstract fun contributePromotionsFragment(): PromotionsFragment

    @ContributesAndroidInjector
    abstract fun contributePromotionTypeFragment(): PromotionTypeFragment

    @ContributesAndroidInjector
    abstract fun contributeCurrentOrderFragment(): CurrentOrderFragment

    @ContributesAndroidInjector
    abstract fun contributeEditMyZonesFragment(): EditMyZonesFragment

    @ContributesAndroidInjector
    abstract fun contributeReferralsFragment(): ReferralsFragment

    @ContributesAndroidInjector
    abstract fun contributePaymentCardFragment(): PaymentCardFragment

    @ContributesAndroidInjector
    abstract fun contributePhysicalCardFragment(): PhysicalCardFragment

    @ContributesAndroidInjector
    abstract fun contributeReimbursementFragment(): ReimbursementFragment

    @ContributesAndroidInjector
    abstract fun contributeDemoOrdersFragment(): DemoOrdersFragment

//    @ContributesAndroidInjector
//    abstract fun contributeEarningsCash00Fragment(): EarningsCash00Fragment
//
//    @ContributesAndroidInjector
//    abstract fun contributeHowEarningsCalculateFragment(): HowEarningsCalculateFragment

//    @ContributesAndroidInjector
//    abstract fun contributeCashOutFragment(): CashOutFragment

    @ContributesAndroidInjector
    abstract fun contributeProfileFragment(): ProfileFragment

    ///  start order list
    @ContributesAndroidInjector
    abstract fun contributeBatchDetailFragment(): BatchDetailFragment

//    @ContributesAndroidInjector
//    abstract fun contributeOrderStatusDoneFragment(): OrderStatusDoneFragment
//
//    @ContributesAndroidInjector
//    abstract fun contributeOrderStatusInreviewFragment(): OrderStatusInreviewFragment
//
//    @ContributesAndroidInjector
//    abstract fun contributeOrderToDoFragment(): OrderToDoFragment
//
//    @ContributesAndroidInjector
//    abstract fun contributeCanNotFindItemFragment(): CanNotFindItemFragment

//    @ContributesAndroidInjector
//    abstract fun contributeOrderDetailFragment(): OrderDetailFragment

    @ContributesAndroidInjector
    abstract fun contributeTakeOrderManuallyDialogFragment(): TakeOrderManuallyDialogFragment

    @ContributesAndroidInjector
    abstract fun contributeCongratulationDialogFragment(): CongratulationDialogFragment

    @ContributesAndroidInjector
    abstract fun contributeConfirmPaymentDialogFragment(): ConfirmPaymentDialogFragment

    @ContributesAndroidInjector
    abstract fun contributeTermsAndConditionDialogFragment(): TermsAndConditionDialogFragment

    @ContributesAndroidInjector
    abstract fun contributeCardInstructionsDialogFragment(): CardInstructionsDialogFragment

    @ContributesAndroidInjector
    abstract fun contributeBringCCMachineDialogFragment(): BringCCMachineDialogFragment

    @ContributesAndroidInjector
    abstract fun contributeCheckoutInstructionsDialogFragment(): CheckoutInstructionsDialogFragment

    /// end order list
}
