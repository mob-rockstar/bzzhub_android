package com.app.basketiodriver.data.model.api.response.order

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class OrderInfo {
    @SerializedName("items_total_count")
    @Expose
    val itemsTotalCount: Int = 0

    @SerializedName("payment_method")
    @Expose
    val paymentMethod: String? = null

    @SerializedName("ordered_subtotal")
    @Expose
    val orderedSubtotal: Double = 0.0

    @SerializedName("delivery_charge")
    @Expose
    val deliveryCharge: Double = 0.0

    @SerializedName("promo_total_amount")
    @Expose
    val promoTotalAmount: Double = 0.0

    @SerializedName("discount")
    @Expose
    val discount: Double = 0.0

    @SerializedName("delivery_instructions")
    @Expose
    val deliveryInstructions: String = ""

    @SerializedName("adjustment")
    @Expose
    val adjustment: Double? = null

    @SerializedName("ordered_total")
    @Expose
    val orderedTotal: Double = 0.0

    @SerializedName("call_before_checkout")
    @Expose
    val callBeforeCheckout = 0

    @SerializedName("customer_mobile_number")
    @Expose
    val customerPhone: String? = null

    @SerializedName("service_fee")
    @Expose
    val serviceFee: Double = 0.0
}