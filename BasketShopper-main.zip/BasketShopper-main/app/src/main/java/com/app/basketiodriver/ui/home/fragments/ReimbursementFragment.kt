package com.app.basketiodriver.ui.home.fragments

import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.View
import androidx.fragment.app.Fragment
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentReimbursementBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.home.HomeViewModel
import com.app.basketiodriver.ui.reimbursement.NewReimbursementRequestActivity


/**
 * A simple [Fragment] subclass.
 */
class ReimbursementFragment : BaseFragment<FragmentReimbursementBinding?, HomeViewModel>(),
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_reimbursement

    override val viewModel: HomeViewModel
        get() {
            return getViewModel(requireActivity(), HomeViewModel::class.java)
        }

    companion object {
        fun newInstance(
        ): ReimbursementFragment {
            return ReimbursementFragment()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_info, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.reimbursements))
        setHasOptionsMenu(true)
        viewDataBinding!!.btnAddNewRequest.setOnClickListener {
            startActivity(NewReimbursementRequestActivity.newIntent(requireContext()))

        }
    }
}
