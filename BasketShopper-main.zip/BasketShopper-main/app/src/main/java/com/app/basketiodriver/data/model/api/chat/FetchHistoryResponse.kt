package com.app.basketiodriver.data.model.api.chat

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


open class FetchHistoryResponse {

    @SerializedName("history")
    @Expose
    var history: List<Message>? = null


    open class Message {

        @SerializedName("_id")
        @Expose
        var id: String = ""

        @SerializedName("type")
        @Expose
        var type: String = "text"

        @SerializedName("content")
        @Expose
        var content: String? = null

        @SerializedName("by")
        @Expose
        var by: By? = null

        @SerializedName("is_send")
        @Expose
        var isSend: Boolean = false

        @SerializedName("is_received")
        @Expose
        var isReceived: Boolean = false

        @SerializedName("is_read")
        @Expose
        var isRead: Boolean = false

        @SerializedName("send_at")
        @Expose
        var send_at: String? = null

        @SerializedName("received_at")
        @Expose
        var received_at: String? = null

        @SerializedName("read_at")
        @Expose
        var read_at: String? = null

    }

    open class By {

        @SerializedName("identifier")
        @Expose
        var id: String = ""

        @SerializedName("role")
        @Expose
        var role: String? = null

    }

}