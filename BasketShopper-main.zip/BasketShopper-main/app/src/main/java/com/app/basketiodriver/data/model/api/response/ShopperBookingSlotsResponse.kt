package com.app.basketiodriver.data.model.api.response

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import java.util.*


/**
Created by ibraheem lubbad on 6/29/20.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/

class ShopperBookingSlotsResponse {
    @SerializedName("data")
    private var data: ArrayList<DetailsData>? = null

    @SerializedName("message")
    private var message: String? = null

    @SerializedName("total_month_RI")
    private var riCount = 0
    fun getData(): ArrayList<DetailsData>? {
        return data
    }

    fun setData(data: ArrayList<DetailsData>?) {
        this.data = data
    }

    fun getRiCount(): Int {
        return riCount
    }

    fun setRiCount(riCount: Int) {
        this.riCount = riCount
    }

    inner class DetailsData {
        @SerializedName("booking_id")
        @Expose
        var booking_id: String? = null

        @SerializedName("start_time")
        @Expose
        var start_time: String? = null

        @SerializedName("end_time")
        @Expose
        var end_time: String? = null

        @SerializedName("is_slot_free")
        @Expose
        var is_slot_free = 0

        @SerializedName("is_you_booked")
        @Expose
        var is_you_booked = 0

        @SerializedName("is_slot_past")
        @Expose
        private var is_slot_past = false
        fun is_slot_past(): Boolean {
            return is_slot_past
        }

        fun setIs_slot_past(is_slot_past: Boolean) {
            this.is_slot_past = is_slot_past
        }
    }

    fun getMessage(): String? {
        return message
    }

    fun setMessage(message: String?) {
        this.message = message
    }
}
