package com.app.basketiodriver.ui.onboarding.fragments


import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import androidx.navigation.Navigation
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.DialogBottomChangeRoleBinding
import com.app.basketiodriver.databinding.DialogNotHasCarBinding
import com.app.basketiodriver.databinding.FragmentSelectShopperRoleBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.onboarding.OnBoardingViewModel
import com.app.basketiodriver.ui.onboarding.OnJoinWaitListNavigator
import com.app.basketiodriver.ui.utils.ViewPagerAdapter
import com.app.basketiodriver.utils.AppConstants
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayout.OnTabSelectedListener


/**
 * Created by ibraheem lubbad on 2020-01-22.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class SelectShopperRoleFragment :
    BaseFragment<FragmentSelectShopperRoleBinding?, OnBoardingViewModel>(),
    Injectable {

    override val layoutId: Int
        get() = R.layout.fragment_select_shopper_role

    override val viewModel: OnBoardingViewModel
        get() {
            return getViewModel(requireActivity(), OnBoardingViewModel::class.java)
        }

    override fun onResume() {
        super.onResume()
        setTitle(getString(R.string.select_shopper_role))


        val viewPagerAdapter = ViewPagerAdapter(childFragmentManager)

        val joinWaitListNavigator = object : OnJoinWaitListNavigator {
                override fun goToJoin() {
                    /**
                     * To warn  user if has  car and select shop only service
                     */
                    if (viewModel.isHasCar && viewModel.DOC_SELECTED_ROLE.equals(AppConstants.KEY_SHOP_ONLY)) {
                        showDialogConfirmation()
                    } else {
                        goToWaitList()
                    }


            }
        }

        viewPagerAdapter.setFragments(
            RoleShopOnlyFragment(joinWaitListNavigator),
            RoleShopAndDriveFragment(joinWaitListNavigator)
        )

        viewPagerAdapter.setTitles(
            getString(R.string.shop_only),
            getString(R.string.full_service)
        )


        viewDataBinding!!.viewPager.adapter = viewPagerAdapter
        viewDataBinding!!.tabLayout.setupWithViewPager(viewDataBinding!!.viewPager)


        /**
         * If user select has a car directly him to shop only tab
         */
        if (!SelectShopperRoleFragmentArgs.fromBundle(arguments!!).hasCar) {
            viewDataBinding!!.viewPager.currentItem = 1
            viewDataBinding!!.tabLayout.getTabAt(1)!!.select()
        }



        viewDataBinding!!.tabLayout.setOnTabSelectedListener(object : OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {

                /**
                 * if user select don't have car and try to  choose full service option
                 */
                if (!SelectShopperRoleFragmentArgs.fromBundle(arguments!!).hasCar && tab.position == 0) {
                    showDialogNotHasCar()
                } else if (tab.position != viewDataBinding!!.viewPager.currentItem) {
                    viewDataBinding!!.viewPager.currentItem = tab.position
                }

            }

            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

    }

    private fun goToWaitList() {
        navigate(
            SelectShopperRoleFragmentDirections.actionSelectShopperRoleFragmentToWaitListFragment()
        )
    }


    /**
     * if user select he don't has a car prevent them to choose full service
     */
    fun showDialogNotHasCar() {
        val dialog = Dialog(context!!, R.style.PauseDialog)
        val binding = DialogNotHasCarBinding.inflate(LayoutInflater.from(context!!))
        dialog.setContentView(binding.root)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setCanceledOnTouchOutside(true)
        binding.btnHasCar.setOnClickListener {
            Navigation.findNavController(view!!).popBackStack()
            dialog.dismiss()
        }
        dialog.setOnDismissListener { viewDataBinding!!.tabLayout.getTabAt(1)!!.select() }

        dialog.show()
    }

    fun showDialogConfirmation() {
        val dialog = Dialog(context!!, R.style.PauseDialog)
        val binding = DialogBottomChangeRoleBinding.inflate(LayoutInflater.from(context!!))
        dialog.setContentView(binding.root)
        dialog.setCanceledOnTouchOutside(true)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        binding.btnNo.setOnClickListener {
            Navigation.findNavController(view!!).popBackStack()
            dialog.dismiss()
        }
        binding.btnYes.setOnClickListener {
            goToWaitList()
            dialog.dismiss()
        }

        dialog.show()
    }
}

