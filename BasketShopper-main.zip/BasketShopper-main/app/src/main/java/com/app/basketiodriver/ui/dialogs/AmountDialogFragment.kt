package com.app.basketiodriver.ui.dialogs

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.Html
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.fragment.app.FragmentManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.model.api.response.order.ReplacementOrdersItemRequest
import com.app.basketiodriver.data.model.api.response.order.ReplacementSearchItemRequest
import com.app.basketiodriver.data.model.api.response.order.SimilarProduct
import com.app.basketiodriver.databinding.FragmentAmountDialogBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseDialogFragment
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.app.basketiodriver.ui.order.adapter.EnterQuantityWeightListAdapter
import com.app.basketiodriver.ui.order.adapter.EnterQuantityWeightOrdersItemListAdapter
import com.app.basketiodriver.utils.GlideApp
import com.app.basketiodriver.utils.price.PriceConstructor
import com.app.basketiodriver.utils.price.PriceConstructorNew
import java.io.Serializable
import java.lang.Double.parseDouble
import java.lang.Double.valueOf
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.*
import kotlin.collections.ArrayList


class AmountDialogFragment : BaseDialogFragment<FragmentAmountDialogBinding?, OrderDetailsViewModel>(),
    Injectable {

    var symbols: DecimalFormatSymbols = DecimalFormatSymbols(Locale.ENGLISH)
    var formatter: DecimalFormat = DecimalFormat("#.## ", symbols)
    var formatterSingle: DecimalFormat = DecimalFormat("# ", symbols)

    private var type : Int = 0 // 0 : OrdersItem, 1 : SimilarItem

    var orderId : Long = 0L
    var item : OrdersItem? = null
    var similarProduct : SimilarProduct?= null
    var quantity : Double = 1.0

    var nextClickListener : AmountDialogOnClickListener ?= null

    // replacement items
    var replaceItems : ArrayList<OrdersItem>? = null
    var replaceRequestItems : ArrayList<ReplacementOrdersItemRequest> = arrayListOf()
    var orgItem : OrdersItem? = null

    lateinit var linearLayoutManager: LinearLayoutManager
    lateinit var replacementProductListAdapter : EnterQuantityWeightOrdersItemListAdapter

    override val layoutId: Int
        get() = R.layout.fragment_amount_dialog

    override val viewModel: OrderDetailsViewModel
        get() {
            return getViewModel(baseActivity, OrderDetailsViewModel::class.java)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    // Set Full screen
    override fun getTheme(): Int {
        return R.style.MyDialogWhite
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initToolbar()

        /**
         * get params
         */
        arguments?.let {
            quantity        = it.getDouble(KEY_QUANTITY, 1.0)
            item            = it.getSerializable(KEY_ORDER_ITEM) as? OrdersItem
            similarProduct  = it.getSerializable(KEY_SIMILAR_PRODUCT) as? SimilarProduct

            type            = it.getInt(KEY_TYPE, 0)

            // Scanned items for replacement
            replaceItems = it.getSerializable(KEY_SCANNED_ITEMS) as? ArrayList<OrdersItem>
            orgItem      = it.getSerializable(KEY_ORIGINAL_ORDER_ITEM) as? OrdersItem

            initViews()
        }
    }

    override fun show(manager: FragmentManager, tag: String?) {
        try {
            val ft = manager.beginTransaction()
            ft.add(this, tag)
            ft.commitAllowingStateLoss()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun initToolbar(){
        viewDataBinding!!.layoutToolBar.toolBarTitle.setText(R.string.enter_quantity_weight)
        viewDataBinding!!.layoutToolBar.btnBack.setOnClickListener {
            dismiss()
        }
    }

    // Initialize the Views
    @SuppressLint("SetTextI18n")
    private fun initViews(){

        if (replaceItems != null && replaceItems!!.isNotEmpty()) {
            viewDataBinding!!.originalLayout.visibility = View.GONE
            viewDataBinding!!.replaceLayout.visibility = View.VISIBLE

            setReplacementItems()
        }
        else{
            viewDataBinding!!.originalLayout.visibility = View.VISIBLE
            viewDataBinding!!.replaceLayout.visibility = View.GONE
        }

        // Found Item
        viewDataBinding!!.enterAmountButton.setOnClickListener {
            onNextClick()
        }

        // Weight ChangeListener
        viewDataBinding!!.weightEditText.addTextChangedListener(object : TextWatcher{
            override fun afterTextChanged(s: Editable?) {
                try {
                    if (item != null){
                        if (s != null && s.isNotEmpty()){
                            val inputValue = s.toString().toDoubleOrNull() ?: 0.0
                            if (item!!.soldPer == 2) {

                                if (item!!.itemQty != null){
                                    if (inputValue > item!!.itemQty!!) {
                                        viewDataBinding!!.txtValidatePrice.visibility = View.VISIBLE
                                        viewDataBinding!!.txtValidatePrice.setText(R.string.more_then_req)
                                    }
                                    else{
                                        viewDataBinding!!.txtValidatePrice.visibility = View.GONE
                                    }
                                }
                                else{
                                    if (inputValue > quantity) {
                                        viewDataBinding!!.txtValidatePrice.visibility = View.VISIBLE
                                        viewDataBinding!!.txtValidatePrice.setText(R.string.more_then_req)
                                    }
                                    else{
                                        viewDataBinding!!.txtValidatePrice.visibility = View.GONE
                                    }
                                }

//                                viewDataBinding!!.txtValidatePrice.setText(R.string.more_then_req)
                            }
                            else if (item!!.soldPer == 3){
                                val qty = if (item!!.itemQty == null) quantity else item!!.itemQty!!
                                val totalAmount = qty * item!!.approxWeight

                                if (inputValue > totalAmount) {
                                    viewDataBinding!!.txtValidatePrice.visibility = View.VISIBLE
                                }
                                else{
                                    viewDataBinding!!.txtValidatePrice.visibility = View.GONE
                                }

                                viewDataBinding!!.txtValidatePrice.setText(R.string.more_then_req)
                            }
                        }
                        else{
                            viewDataBinding!!.txtValidatePrice.visibility = View.GONE
                        }
                    }
                }
                catch (e : Exception){
                    e.printStackTrace()
                }
            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }
        })

        // Amount ChangeListener
        viewDataBinding!!.amountEditText.addTextChangedListener(object : TextWatcher{
            override fun afterTextChanged(s: Editable?) {
                try {
                    if (item != null){
                        if (s != null && s.isNotEmpty()){
                            val inputValue = s.toString().toDoubleOrNull() ?: 0.0
                            if (item!!.soldPer == 1 || item!!.soldPer == 3) {
                                if (item!!.itemQty != null){
                                    if (inputValue > item!!.itemQty!!) {
                                        viewDataBinding!!.txtValidateQuantity.visibility = View.VISIBLE
                                        viewDataBinding!!.txtValidateQuantity.setText(R.string.more_then_req)
                                    }
                                    else{
                                        viewDataBinding!!.txtValidateQuantity.visibility = View.GONE
                                    }
                                }
                                else{
                                    if (inputValue > quantity) {
                                        viewDataBinding!!.txtValidateQuantity.visibility = View.VISIBLE
                                        viewDataBinding!!.txtValidateQuantity.setText(R.string.more_then_req)
                                    }
                                    else{
                                        viewDataBinding!!.txtValidateQuantity.visibility = View.GONE
                                    }
                                }
                            }
                            else {
                                viewDataBinding!!.txtValidateQuantity.visibility = View.GONE
                            }
                        }
                        else{
                            viewDataBinding!!.txtValidateQuantity.visibility = View.GONE
                        }
                    }
                }
                catch (e : Exception){
                    e.printStackTrace()
                }
            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }
        })

        if (replaceItems != null && replaceItems!!.isNotEmpty()) {
            item = replaceItems!![0]
        }

        if (type == 1 && similarProduct != null) { // Similar Product Item
            viewDataBinding!!.txtQuantity.text = ""

            if (similarProduct!!.soldPer == 2){
                viewDataBinding!!.amountEditText.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                viewDataBinding!!.productLayout.txtPricePerUnit.text = baseActivity.getString(R.string.supposed_weight) + " " + formatter.format(similarProduct!!.approxWeight) + " " + similarProduct!!.unit
                viewDataBinding!!.weightEditText.setHint(R.string.total_weight)
            }
            else{
                viewDataBinding!!.amountEditText.inputType = InputType.TYPE_CLASS_NUMBER
                viewDataBinding!!.productLayout.txtPricePerUnit.visibility = View.INVISIBLE
            }

            when (similarProduct!!.soldPer) {
                2 -> {
                    viewDataBinding!!.cardView3.visibility = View.GONE
                    viewDataBinding!!.cardView4.visibility = View.VISIBLE
                }
                3 -> {
                    viewDataBinding!!.cardView3.visibility = View.VISIBLE
                    viewDataBinding!!.cardView4.visibility = View.VISIBLE
                }
                else -> {
                    viewDataBinding!!.cardView3.visibility = View.VISIBLE
                    viewDataBinding!!.cardView4.visibility = View.GONE
                }
            }

            setProductDataToView()
        }
        else if (item != null){ // Orders Item
            when (item!!.soldPer) {
                2 -> {
                    viewDataBinding!!.cardView3.visibility = View.GONE
                    viewDataBinding!!.cardView4.visibility = View.VISIBLE
                }
                3 -> {
                    viewDataBinding!!.cardView3.visibility = View.VISIBLE
                    viewDataBinding!!.cardView4.visibility = View.VISIBLE
                }
                else -> {
                    viewDataBinding!!.cardView3.visibility = View.VISIBLE
                    viewDataBinding!!.cardView4.visibility = View.GONE
                }
            }

            if (item!!.itemQty == null){
                viewDataBinding!!.txtQuantity.text = String.format(Locale.US, "/ %s", formatterSingle.format(quantity))
            }
            else{
                viewDataBinding!!.txtQuantity.text = String.format(Locale.US, "/ %s", formatterSingle.format(item!!.itemQty ?: 1))
            }

            if (item!!.soldPer == 2 || item!!.soldPer == 3) {
                viewDataBinding!!.amountEditText.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            }
            else{
                viewDataBinding!!.amountEditText.inputType = InputType.TYPE_CLASS_NUMBER
            }

            setDataToView()
        }
    }

    // Display the replace items
    @SuppressLint("SetTextI18n")
    private fun setReplacementItems(){
        linearLayoutManager = LinearLayoutManager(activity)
        viewDataBinding!!.rvReplacement.layoutManager = linearLayoutManager

        // Display the original product information
        // Product Image
        if (orgItem!!.productImage != null){
            GlideApp.with(requireActivity()).load(orgItem!!.productImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(viewDataBinding!!.oldProduct.orderItemImage)
        }

        val formatter = DecimalFormat("#.## x ", symbols)

        // Item Title
        if (orgItem!!.quantityDifference == 1) {
            viewDataBinding!!.oldProduct.txtTitle.text = formatter.format(orgItem!!.actualQty) + orgItem!!.productName
        }
        else if (orgItem!!.replacementRequested != null && orgItem!!.replacementRequested == 1) {
            if (orgItem!!.itemStatus == 2) {
                viewDataBinding!!.oldProduct.txtTitle.text = orgItem!!.oldProductName
            } else {
                viewDataBinding!!.oldProduct.txtTitle.text = formatter.format(orgItem!!.actualQty) + orgItem!!.oldProductName
            }

            if (orgItem!!.oldProductImage != null) {
                GlideApp.with(requireActivity()).load(orgItem!!.oldProductImage).fitCenter()
                    .placeholder(R.drawable.placeholder)
                    .error(R.drawable.placeholder).into(viewDataBinding!!.oldProduct.orderItemImage)
            }
        }
        else {
            viewDataBinding!!.oldProduct.txtTitle.text = formatter.format(orgItem!!.itemQty ?: 0) + (orgItem!!.productName ?: "")// + item!!.aisleName
        }

        // Description
        if (orgItem!!.getDescriptionLabel().isEmpty()) {
            viewDataBinding!!.oldProduct.tvPriceDescription.visibility = View.GONE
        } else {
            viewDataBinding!!.oldProduct.tvPriceDescription.visibility = View.VISIBLE
            viewDataBinding!!.oldProduct.tvPriceDescription.text = orgItem!!.getDescriptionLabel()
        }

        // Unit
        viewDataBinding!!.oldProduct.txtPricePerUnit.text = Html.fromHtml(PriceConstructor.getFormatPrice(orgItem!!, PriceConstructor.LabelType.SIMPLE, PreferenceManager.currency, true))

        for (product in replaceItems!!){
            val requestItem = ReplacementOrdersItemRequest()
            requestItem.product = product

            replaceRequestItems.add(requestItem)
        }

        // Initialize the product list
        replacementProductListAdapter = EnterQuantityWeightOrdersItemListAdapter(baseActivity, replaceItems!!, this)
        viewDataBinding!!.rvReplacement.adapter = replacementProductListAdapter
    }

    /**
     * Update the item quantity
     */
    fun updateItemQuantity(item : OrdersItem, qty : Int) {
        for (requestItem in replaceRequestItems){
            if (requestItem.product!! == item) {
                requestItem.quantity = qty.toDouble()
                break
            }
        }
    }

    /**
     * Update the item weight
     */
    fun updateItemWeight(item : OrdersItem, weight: Double){
        for (requestItem in replaceRequestItems){
            if (requestItem.product!! == item) {
                requestItem.weight = weight
                break
            }
        }
    }

    /**
     *  Remove the item from replacement list
     */
    fun removeItemFromReplacementList(item : OrdersItem){
        for (requestItem in replaceRequestItems){
            if (requestItem.product!! == item) {
                replaceRequestItems.remove(requestItem)
                break
            }
        }

        replaceItems!!.remove(item)

        // Hide the FoundItem button if no items in list
        if (replaceItems!!.size == 0) {
            viewDataBinding!!.bottomLayout.visibility = View.GONE
        }
        else{
            viewDataBinding!!.bottomLayout.visibility = View.VISIBLE
        }
    }

    // Display the Similar Product information
    private fun setProductDataToView(){
        // product image
        if (similarProduct!!.productImage != null){
            GlideApp.with(baseActivity).load(similarProduct!!.productImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(viewDataBinding!!.productLayout.orderItemImage)
        }

        // Name
        viewDataBinding!!.productLayout.txtTitle.text = similarProduct!!.productName

        // Description
        if (similarProduct!!.getDescriptionLabelNew() == ""){
            viewDataBinding!!.productLayout.tvPriceDescription.visibility = View.GONE
        }
        else{
            viewDataBinding!!.productLayout.tvPriceDescription.visibility = View.VISIBLE
            viewDataBinding!!.productLayout.tvPriceDescription.text = similarProduct!!.getDescriptionLabelNew()
        }

        viewDataBinding!!.productLayout.txtPricePerUnit.visibility = View.VISIBLE
        viewDataBinding!!.productLayout.txtPricePerUnit.text = PriceConstructorNew.getFormatPrice(similarProduct!!, PriceConstructor.LabelType.SIMPLE)

    }

    // Display the OrdersItem Information
    @SuppressLint("SetTextI18n")
    private fun setDataToView(){
        // Department
        if (item!!.departmentName != null && item!!.departmentName!!.isNotEmpty()){
            viewDataBinding!!.tvDepartment.text = item!!.departmentName
        }
        else {
            viewDataBinding!!.tvDepartment.text = "--"
        }

        // Display the UPC for local items
        if (item!!.upcType != null && item!!.upcType == 2) { // Local items
            viewDataBinding!!.tvUPC.text = String.format("UPC: %s", item!!.upc)
            viewDataBinding!!.tvUPC.visibility = View.VISIBLE
        }
        else{
            viewDataBinding!!.tvUPC.visibility = View.GONE
        }

        // Product image
        if (item!!.productImage != null){
            GlideApp.with(baseActivity).load(item!!.productImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(viewDataBinding!!.productLayout.orderItemImage)
        }

        val formatter = DecimalFormat("#.## x ", symbols)
        val formatter2 = DecimalFormat("#.##", symbols)

        // Set the product name
        if (item!!.quantityDifference == 1)
            viewDataBinding!!.productLayout.txtTitle.text = String.format(Locale.ENGLISH, "%s%s", formatter.format(item!!.actualQty), item!!.productName)
        else if (item!!.replacementRequested != null && item!!.replacementRequested == 1)
            if (item!!.itemStatus == 2) {
                viewDataBinding!!.productLayout.txtTitle.text = item!!.productName
            } else {
                viewDataBinding!!.productLayout.txtTitle.text = String.format(Locale.ENGLISH, "%s%s", formatter.format(item!!.actualQty), item!!.productName)
            }
        else {
            viewDataBinding!!.productLayout.txtTitle.text = String.format(Locale.ENGLISH, "%s%s", formatter.format(item!!.itemQty ?: 0), (item!!.productName ?: ""))
            if (item!!.soldPer == 2)
                viewDataBinding!!.productLayout.txtTitle.text = String.format(Locale.ENGLISH, "%s kg x %s", formatter2.format(item!!.itemQty ?: 0), (item!!.productName ?: ""))
        }

        if (item!!.getDescriptionLabel().isEmpty()) {
            viewDataBinding!!.productLayout.tvPriceDescription.visibility = View.GONE
        } else {
            viewDataBinding!!.productLayout.tvPriceDescription.visibility = View.VISIBLE
            viewDataBinding!!.productLayout.tvPriceDescription.text = item!!.getDescriptionLabel()
        }

        viewDataBinding!!.productLayout.txtPricePerUnit.text = Html.fromHtml(PriceConstructor.getFormatPrice(item, PriceConstructor.LabelType.SIMPLE, PreferenceManager.currency, true))
    }

    private fun validateAmount() : Boolean {
        return try {
            if (viewDataBinding!!.amountEditText.text.toString().isEmpty()) return false
            if (viewDataBinding!!.amountEditText.text == null) return false
            try {
                valueOf(viewDataBinding!!.amountEditText.text.toString())
            } catch (e: Exception) {
                return false
            }
            if (type == 0) {
                if (item!!.soldPer == 2) return true
            } else if (type == 1) {
                if (similarProduct!!.soldPer == 2) return true
            }
            parseDouble(viewDataBinding!!.amountEditText.text.toString()) > 0
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun validateWeight() : Boolean {
        return try {
            if (viewDataBinding!!.cardView4.visibility == View.GONE) return true
            var weight = 0.0

            if (type == 0) {
                if (item!!.soldPer == 2) {
                    weight = item!!.itemQty ?: 0.0
                }
                else if (item!!.soldPer == 3) {
                    weight = if (item!!.approxWeight > 0) {
                        item!!.approxWeight * (item!!.itemQty ?: 0.0)
                    } else {
                        item!!.actualApproxWeight * (item!!.itemQty ?: 0.0)
                    }
                }
            } else {
                if (similarProduct!!.soldPer == 2) {
                    weight = similarProduct!!.approxWeight
                    if (weight < 1) {
                        weight = 1.0
                    }
                } else if (similarProduct!!.soldPer == 3) {
                    weight = similarProduct!!.approxWeight
                }
            }

            val maxWeight = weight * 1.3
            val weightVal = viewDataBinding!!.weightEditText.text != null && viewDataBinding!!.weightEditText.text.toString().trim()
                .isNotEmpty()
                    && parseDouble(viewDataBinding!!.weightEditText.text.toString()) > 0
            if (!weightVal)
            {
//                Toast.makeText(baseActivity, R.string.err_msg_invalid_weight, Toast.LENGTH_SHORT).show()
                false
            }
            else if (parseDouble(viewDataBinding!!.weightEditText.text.toString()) > maxWeight)
            {
//                Toast.makeText(baseActivity, R.string.err_msg_invalid_weight, Toast.LENGTH_SHORT).show()
                false
            }

            weightVal
        }
        catch (e: Exception) {
//            Toast.makeText(baseActivity, R.string.err_msg_invalid_weight, Toast.LENGTH_SHORT).show()
            false
        }
    }

    private fun validateAmounts() : Boolean {
        return try {
            val valid =
                viewDataBinding!!.amountEditText.text != null && viewDataBinding!!.amountEditText.text.toString()
                    .isNotEmpty()
                        && parseDouble(viewDataBinding!!.amountEditText.text.toString()) > 0
            if (!valid) {
                Toast.makeText(baseActivity, R.string.err_msg_invalid_amount, Toast.LENGTH_SHORT).show()
            }
            valid
        } catch (e: Exception) {
            Toast.makeText(baseActivity, R.string.err_msg_invalid_amount, Toast.LENGTH_SHORT).show()
            false
        }
    }

    /**
     * Found Item
     */
    private fun onNextClick(){
        if (nextClickListener != null) {
            if (replaceItems != null) {
                nextClickListener!!.onNextClick(replaceRequestItems)
            }
            else if (item != null) {
                if (validateAmount() || validateWeight()) {
                    viewDataBinding!!.amountEditText.error = null
                    if (item!!.soldPer == 3 && validateWeight() && validateAmount()) {
                        nextClickListener!!.onNextClick(parseDouble(viewDataBinding!!.amountEditText.text.toString()), parseDouble(viewDataBinding!!.weightEditText.text.toString()))
                    }
                    else if (item!!.soldPer == 4 && validateAmount()) {
                        nextClickListener!!.onNextClick(parseDouble(viewDataBinding!!.amountEditText.text.toString()))
                    }
                    else if (item!!.soldPer == 1 && validateAmounts()) {
                        nextClickListener!!.onNextClick(parseDouble(viewDataBinding!!.amountEditText.text.toString()))
                    }
                    else if (item!!.soldPer == 2 && validateWeight()) {
                        nextClickListener!!.onNextClick(parseDouble(viewDataBinding!!.weightEditText.text.toString()))
                    }
                    else if (validateAmount() && viewDataBinding!!.cardView4.visibility == View.GONE) {
                        nextClickListener!!.onNextClick(parseDouble(viewDataBinding!!.amountEditText.text.toString()))
                    }
                } else {
                    Toast.makeText(baseActivity, R.string.err_msg_invalid_amount, Toast.LENGTH_SHORT).show()
                    viewDataBinding!!.amountEditText.error = getString(R.string.err_msg_invalid_amount)
                }
            }
            else if (type == 1 && similarProduct != null) {
                if (validateAmount() || validateWeight()) {
                    viewDataBinding!!.amountEditText.error = null
                    if (similarProduct!!.soldPer == 3 && validateWeight() && validateAmount())
                        nextClickListener!!.onNextClick(parseDouble(viewDataBinding!!.amountEditText.text.toString()), parseDouble(viewDataBinding!!.weightEditText.text.toString()))
                    else if (similarProduct!!.soldPer == 1 && validateAmounts())
                        nextClickListener!!.onNextClick(parseDouble(viewDataBinding!!.amountEditText.text.toString()))
                    else if (similarProduct!!.soldPer == 2 && validateWeight()) {
                        nextClickListener!!.onNextClick(parseDouble(viewDataBinding!!.weightEditText.text.toString()))
                    } else if (validateAmount()) {
                        nextClickListener!!.onNextClick(parseDouble(viewDataBinding!!.amountEditText.text.toString()))
                    }
                } else {
                    Toast.makeText(baseActivity, R.string.err_msg_invalid_amount, Toast.LENGTH_SHORT).show()
                    viewDataBinding!!.amountEditText.error = getString(R.string.err_msg_invalid_amount)
                }
            }
        }
    }

    // Set click listener
    fun setAmountNextClickListener(listener : AmountDialogOnClickListener){
        this.nextClickListener = listener
    }

    companion object {
        const val KEY_ORDER_ITEM      = "orders_item"
        const val KEY_ORIGINAL_ORDER_ITEM  = "original_orders_item"
        const val KEY_SCANNED_ITEMS   = "scanned_items"
        const val KEY_SIMILAR_PRODUCT = "similar_product"
        const val KEY_QUANTITY        = "key_qty"
        const val KEY_TYPE            = "key_type"


        fun newInstance(item : OrdersItem, qty : Double): AmountDialogFragment {
            val fragment = AmountDialogFragment()

            val data = Bundle()

            data.putSerializable(KEY_ORDER_ITEM, item)
            data.putDouble(KEY_QUANTITY, qty)
            data.putInt(KEY_TYPE, 0)

            fragment.arguments = data

            return fragment
        }

        fun newInstance(orgItem : OrdersItem, scannedItems : List<OrdersItem>, qty : Double): AmountDialogFragment {
            val fragment = AmountDialogFragment()

            val data = Bundle()

            data.putSerializable(KEY_ORIGINAL_ORDER_ITEM, orgItem)
            data.putSerializable(KEY_SCANNED_ITEMS, scannedItems as Serializable)
            data.putDouble(KEY_QUANTITY, qty)
            data.putInt(KEY_TYPE, 0)

            fragment.arguments = data

            return fragment
        }

        fun newInstance(similarItem : SimilarProduct, qty : Double): AmountDialogFragment {
            val fragment = AmountDialogFragment()

            val data = Bundle()

            data.putSerializable(KEY_SIMILAR_PRODUCT, similarItem)
            data.putDouble(KEY_QUANTITY, qty)
            data.putInt(KEY_TYPE, 1)

            fragment.arguments = data

            return fragment
        }


    }

    interface AmountDialogOnClickListener {
        fun onNextClick(amount: Double)

        fun onNextClick(itemId: Long, amount: Double)

        fun onNextClick(amount: Double, weight: Double)

        fun onNextClick(
            itemId: Long,
            amount: Double,
            weight: Double
        )

        fun onNextClick(requestItems : ArrayList<ReplacementOrdersItemRequest>){

        }
    }
}