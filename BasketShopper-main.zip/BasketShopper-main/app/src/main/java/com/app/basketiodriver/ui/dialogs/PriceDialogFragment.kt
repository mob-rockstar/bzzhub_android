package com.app.basketiodriver.ui.dialogs

import android.os.Bundle
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentAmountDialogBinding
import com.app.basketiodriver.databinding.FragmentPriceDialogBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseDialogFragment
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.app.basketiodriver.ui.home.HomeViewModel

class PriceDialogFragment : BaseDialogFragment<FragmentPriceDialogBinding?, HomeViewModel>(),
    Injectable {

    override val layoutId: Int
        get() = R.layout.fragment_price_dialog

    override val viewModel: HomeViewModel
        get() {
            return getViewModel(baseActivity, HomeViewModel::class.java)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    // Set Full screen
    override fun getTheme(): Int {
        return R.style.MyDialogWhite
    }
}