package com.app.basketiodriver.ui.home.adapters

/**
 * Created by ibraheem lubbad on 2/27/20.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 */
class MenuModel(
    var menuId: String,
    var menuName: String,
    var menuIcon: Int?,
    var subMenu: ArrayList<MenuModel>?
)