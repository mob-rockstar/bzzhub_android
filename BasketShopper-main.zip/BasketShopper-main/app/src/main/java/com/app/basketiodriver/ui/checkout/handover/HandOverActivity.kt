package com.app.basketiodriver.ui.checkout.handover

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.order.HandoverCodeResponse
import com.app.basketiodriver.databinding.ActivityHandoverBinding
import com.app.basketiodriver.di.Navigators
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.base.HandleResponse
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel


class HandOverActivity : BaseActivity<ActivityHandoverBinding, HandOverViewModel>() {
    override val layoutId: Int
        get() = R.layout.activity_handover

    override val viewModel: HandOverViewModel
        get() {
            return getViewModel(HandOverViewModel::class.java)
        }

    var orderId : Long = 0
    var orderOutletId : Long = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        initToolbar(getString(R.string.handover_order_to_driver),
            true, viewDataBinding!!.layoutToolBar.toolbar,
            View.OnClickListener {
                run {
                    onBackPressed()
                }
            })

        // Get the params
        orderId         = intent.getLongExtra("ARG_ORDER_ID", 0)
        orderOutletId   = intent.getLongExtra("ARG_ORDER_OUTLET_ID", 0)

        initViews()
    }

    private fun initViews(){
        viewDataBinding!!.swipeLayout.setOnRefreshListener(object : SwipeRefreshLayout.OnRefreshListener{
            override fun onRefresh() {
                viewDataBinding!!.swipeLayout.isRefreshing = true
                viewDataBinding!!.swipeLayout.isEnabled = false

                updateHandover()
            }
        })

        updateHandover()
    }

    private fun updateHandover(){
        viewModel.updateHandoverCode(orderId, orderOutletId, object : HandleResponse<HandoverCodeResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Toast.makeText(this@HandOverActivity, error?.message, Toast.LENGTH_SHORT).show()
                }else{
                    Toast.makeText(this@HandOverActivity, resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }
                setSwipeRefreshLayout()
            }

            override fun handleSuccessResponse(successResponse: HandoverCodeResponse) {
                setSwipeRefreshLayout()

                if (successResponse.data != null){
                    Toast.makeText(this@HandOverActivity, successResponse.message, Toast.LENGTH_SHORT).show()

                    val code = successResponse.data!!.code ?: ""
                    viewDataBinding!!.txtHandoverText.text = code
                    generateQRCode(code)
                }
                else{
                    Toast.makeText(this@HandOverActivity, R.string.error_server_return_null, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    // Generate QrCode
    private fun generateQRCode(code : String){
        val bitmap = QRCodeHelper
            .newInstance(this)
            .setContent(code)
            .setErrorCorrectionLevel(ErrorCorrectionLevel.Q)
            .setMargin(2)
            .qrcOde

        // set qr code image
        viewDataBinding!!.ivQrCode.setImageBitmap(bitmap)
    }

    private fun setSwipeRefreshLayout(){
        viewDataBinding!!.swipeLayout.isEnabled = true
        viewDataBinding!!.swipeLayout.isRefreshing = false
    }

    override fun onBackPressed() {
//        super.onBackPressed()
        Navigators.goToDashboard(this)
        finish()
    }
}