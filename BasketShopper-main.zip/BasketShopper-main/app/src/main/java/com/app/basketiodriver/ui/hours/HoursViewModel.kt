package com.app.basketiodriver.ui.hours

import android.app.Application
import com.app.basketiodriver.data.DataManager
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.hours.BookingReportResponse
import com.app.basketiodriver.data.remote.APIManager
import com.app.basketiodriver.ui.base.BaseNavigator
import com.app.basketiodriver.ui.base.BaseViewModel
import com.app.basketiodriver.ui.base.HandleResponse
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class HoursViewModel constructor(application: Application, dataManager: DataManager
) : BaseViewModel<BaseNavigator?>(application, dataManager) {
    fun getShopperBookingReport(
        fromDate:String, toDate:String,
        handleResponse: HandleResponse<BookingReportResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperBookingReport(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, fromDate, toDate)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }

                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }
}