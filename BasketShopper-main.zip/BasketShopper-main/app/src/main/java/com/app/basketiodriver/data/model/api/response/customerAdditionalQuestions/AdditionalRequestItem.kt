package com.app.basketiodriver.data.model.api.response.customerAdditionalQuestions

data class AdditionalRequestItem(
    val active: Boolean,
    var answers: List<Answer>,
    val description: List<DescriptionX>,
    val id: Int,
    val rank: Int,
    val title: List<TitleX>,
    val type: String,
    val validation: Validation,
    var height : Int,
)