package com.app.basketiodriver.data.model.api.response

import com.app.basketiodriver.data.model.api.response.Base.BaseResponse
import com.google.gson.annotations.SerializedName

/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class ShopperDocumentsResponse :
    BaseResponse() {


    @SerializedName("data")
    var list: ArrayList<ShoppperDocument>? = null

    override fun toString(): String {
        return "ShopperDocumentsResponse(list=$list)"
    }



    data class ShoppperDocument(
        @SerializedName("type") val type: String,
        @SerializedName("file") val file: String,
        @SerializedName("file_url") val file_url: String,
        @SerializedName("file_type") val file_type: String,
        @SerializedName("order") val order: Int,
        @SerializedName("status") val status: String,
        @SerializedName("review_note") val review_note: String

    )


/*
"type": "Passport",
"file": "shoppers/documents/10_2_1586868758.0327.png",
"file_url": "https://s3.eu-central-1.amazonaws.com/cdn.basket.jo/shoppers/documents/10_2_1586868758.0327.png",
"file_type": "back",
"order": 1,
"status": "REJECTED",
"review_note": null
 */



}