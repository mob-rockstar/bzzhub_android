package com.app.basketiodriver.di.builder

import com.app.basketiodriver.ui.weekhours.EarlyAccessStatus.fragments.EarlyAccessStatusCurrentStatus
import com.app.basketiodriver.ui.weekhours.EarlyAccessStatus.fragments.EarlyAccessStatusProgressFragment
import dagger.Module
import dagger.android.ContributesAndroidInjector

/**
 * Created by ibraheem lubbad on 6/15/20.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 */
@Module
internal abstract class EarlyAccessStatusModule {

    @ContributesAndroidInjector
    abstract fun contributeEarlyAccessStatusCurrentStatus(): EarlyAccessStatusCurrentStatus


    @ContributesAndroidInjector
    abstract fun contributeEarlyAccessStatusProgressFragment(): EarlyAccessStatusProgressFragment

}