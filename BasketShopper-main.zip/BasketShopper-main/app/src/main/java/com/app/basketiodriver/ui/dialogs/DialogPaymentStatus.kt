package com.app.basketiodriver.ui.dialogs

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.Window
import androidx.databinding.DataBindingUtil
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.DialogPaymentStatusBinding
import com.app.basketiodriver.utils.PopupUtils
import java.util.*

class DialogPaymentStatus {

    var dialog: Dialog? = null

    fun openDialog(context: Context){
        dialog = Dialog(context)

        val binding: DialogPaymentStatusBinding = DataBindingUtil.inflate(
            LayoutInflater.from(context),
            R.layout.dialog_payment_status,
            null,
            false
        )

        dialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog?.setContentView(binding.root)
        dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog?.window?.setGravity(Gravity.CENTER)

        // Close
        binding.btnOk.setOnClickListener {
            dialog?.dismiss()
        }

        PopupUtils.setDefaultDialogProperty(dialog!!)
        dialog?.show()
    }

    companion object {
        private var instance: DialogPaymentStatus? = null
        private val Instance: DialogPaymentStatus
            get() {
                if (instance == null) {
                    instance = DialogPaymentStatus()
                }
                return instance!!
            }

        fun openDialog(context: Context) {
            Instance.openDialog(context)
        }
    }
}