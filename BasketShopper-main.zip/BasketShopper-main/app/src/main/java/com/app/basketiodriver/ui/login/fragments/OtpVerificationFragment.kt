package com.app.basketiodriver.ui.login.fragments

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.Handler
import android.text.Editable
import android.text.Spannable
import android.text.SpannableString
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import android.widget.TextView.OnEditorActionListener
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import bloder.com.blitzcore.enableWhen
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.general.SimpleResponse
import com.app.basketiodriver.data.model.api.response.otp.CheckOTP
import com.app.basketiodriver.databinding.FragmentOtpVerifyBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.login.LoginViewModel
import com.app.basketiodriver.utils.AppLogger
import timber.log.Timber
import java.util.*


/**
Created by ibraheem lubbad on 2020-01-15.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class OtpVerificationFragment : BaseFragment<FragmentOtpVerifyBinding?, LoginViewModel>(),
    Injectable {

    override val layoutId: Int
        get() = R.layout.fragment_otp_verify

    override val viewModel: LoginViewModel
        get() {
            return getViewModel(baseActivity as FragmentActivity, LoginViewModel::class.java)
        }


    // lateinit var timer: CountDownTimer

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setTitle(getString(R.string.enter_sms_code))

        validation()
        setListener()

        /**
         * Display the mobile number
         */
        val mobileNo = String.format(Locale.ENGLISH, "%s%s", viewModel.codeMobileNumber, viewModel.mobileNumber)
        val hintMsg = String.format(Locale.ENGLISH, baseActivity!!.resources.getString(R.string.forgot_hint), mobileNo)
        val wordToSpan = SpannableString(hintMsg)
        val startIdx = wordToSpan.indexOf(mobileNo)
        val endIdx = startIdx + mobileNo.length
        wordToSpan.setSpan(ForegroundColorSpan(baseActivity!!.resources.getColor(R.color.colorPrimary)), startIdx, endIdx, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        viewDataBinding!!.tvHint.text = wordToSpan
    }

    /**
     * Initialize the OTP boxes
     */
    @SuppressLint("UseCompatLoadingForDrawables")
    private fun initOtpBoxes(){
        viewDataBinding!!.edNumber1.text.clear()
        viewDataBinding!!.edNumber2.text.clear()
        viewDataBinding!!.edNumber3.text.clear()
        viewDataBinding!!.edNumber4.text.clear()
        viewDataBinding!!.edNumber5.text.clear()
        viewDataBinding!!.edNumber6.text.clear()

        viewDataBinding!!.edNumber1.background = baseActivity!!.resources.getDrawable(R.drawable.bg_code_box)
        viewDataBinding!!.edNumber2.background = baseActivity!!.resources.getDrawable(R.drawable.bg_code_box)
        viewDataBinding!!.edNumber3.background = baseActivity!!.resources.getDrawable(R.drawable.bg_code_box)
        viewDataBinding!!.edNumber4.background = baseActivity!!.resources.getDrawable(R.drawable.bg_code_box)
        viewDataBinding!!.edNumber5.background = baseActivity!!.resources.getDrawable(R.drawable.bg_code_box)
        viewDataBinding!!.edNumber6.background = baseActivity!!.resources.getDrawable(R.drawable.bg_code_box)
    }

    /**
     * Validate otp code
     */
    private fun validation() {
        viewDataBinding!!.btnVerify.enableWhen {
            viewDataBinding!!.edNumber1.isFilled()
            viewDataBinding!!.edNumber2.isFilled()
            viewDataBinding!!.edNumber3.isFilled()
            viewDataBinding!!.edNumber4.isFilled()
            viewDataBinding!!.edNumber5.isFilled()
            viewDataBinding!!.edNumber6.isFilled()
        }
    }

    private fun setListener() {
        viewDataBinding!!.edNumber6.setOnEditorActionListener(keyBoardEnterListener)

        viewDataBinding!!.edNumber1.addTextChangedListener(object : TextWatcher {
            @SuppressLint("UseCompatLoadingForDrawables")
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                if (viewDataBinding!!.edNumber1.text.toString().length == 1) {
                    viewDataBinding!!.edNumber1.background = baseActivity!!.resources.getDrawable(R.drawable.bg_code_box_green)
                    viewDataBinding!!.edNumber1.clearFocus()
                    viewDataBinding!!.edNumber2.requestFocus()
                    viewDataBinding!!.edNumber2.isCursorVisible = true
                    viewDataBinding!!.tvError.text = ""
                }
                else if (viewDataBinding!!.edNumber1.text.toString().isNullOrEmpty()) {
                    viewDataBinding!!.edNumber1.background = baseActivity!!.resources.getDrawable(R.drawable.bg_code_box)
                }
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
            }
        })

        viewDataBinding!!.edNumber2.addTextChangedListener(object : TextWatcher {
            @SuppressLint("UseCompatLoadingForDrawables")
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {

                if (viewDataBinding!!.edNumber2.text.toString().length == 1) {
                    viewDataBinding!!.edNumber2.clearFocus()
                    viewDataBinding!!.edNumber3.requestFocus()
                    viewDataBinding!!.edNumber3.isCursorVisible = true
                    viewDataBinding!!.edNumber2.background = baseActivity!!.resources.getDrawable(R.drawable.bg_code_box_green)
                }
                else if (viewDataBinding!!.edNumber2.text.toString().isNullOrEmpty()) {
                    viewDataBinding!!.edNumber2.clearFocus()
                    viewDataBinding!!.edNumber1.requestFocus()
                    viewDataBinding!!.edNumber1.isCursorVisible = true
                    viewDataBinding!!.edNumber2.background = baseActivity!!.resources.getDrawable(R.drawable.bg_code_box)
                }
                viewDataBinding!!.tvError.text = ""
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) { // TODO Auto-generated method stub
            }

            override fun afterTextChanged(s: Editable) { // TODO Auto-generated method stub
            }
        })
        viewDataBinding!!.edNumber3.addTextChangedListener(object : TextWatcher {
            @SuppressLint("UseCompatLoadingForDrawables")
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                if (viewDataBinding!!.edNumber3.text.toString().length == 1) {
                    viewDataBinding!!.edNumber3.clearFocus()
                    viewDataBinding!!.edNumber4.requestFocus()
                    viewDataBinding!!.edNumber4.isCursorVisible = true
                    viewDataBinding!!.edNumber3.background = baseActivity!!.resources.getDrawable(R.drawable.bg_code_box_green)
                }
                else if (viewDataBinding!!.edNumber3.text.toString().isNullOrEmpty()) {
                    viewDataBinding!!.edNumber3.clearFocus()
                    viewDataBinding!!.edNumber2.requestFocus()
                    viewDataBinding!!.edNumber2.isCursorVisible = true
                    viewDataBinding!!.edNumber3.background = baseActivity!!.resources.getDrawable(R.drawable.bg_code_box)
                }
                viewDataBinding!!.tvError.text = ""
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) { // TODO Auto-generated method stub
            }

            override fun afterTextChanged(s: Editable) { // TODO Auto-generated method stub
            }
        })
        viewDataBinding!!.edNumber4.addTextChangedListener(object : TextWatcher {
            @SuppressLint("UseCompatLoadingForDrawables")
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) { // TODO Auto-generated method stub
                if (viewDataBinding!!.edNumber4.text.toString().length == 1) {
                    viewDataBinding!!.edNumber4.clearFocus()
                    viewDataBinding!!.edNumber5.requestFocus()
                    viewDataBinding!!.edNumber5.isCursorVisible = true
                    viewDataBinding!!.edNumber4.background = baseActivity!!.resources.getDrawable(R.drawable.bg_code_box_green)
                }
                else if (viewDataBinding!!.edNumber4.text.toString().isNullOrEmpty()) {
                    viewDataBinding!!.edNumber4.clearFocus()
                    viewDataBinding!!.edNumber3.requestFocus()
                    viewDataBinding!!.edNumber3.isCursorVisible = true
                    viewDataBinding!!.edNumber4.background = baseActivity!!.resources.getDrawable(R.drawable.bg_code_box)
                }
                viewDataBinding!!.tvError.text = ""
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) { // TODO Auto-generated method stub
            }

            override fun afterTextChanged(s: Editable) { // TODO Auto-generated method stub
            }
        })

        viewDataBinding!!.edNumber5.addTextChangedListener(object : TextWatcher {
            @SuppressLint("UseCompatLoadingForDrawables")
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) { // TODO Auto-generated method stub
                if (viewDataBinding!!.edNumber5.text.toString().length == 1) {
                    viewDataBinding!!.edNumber5.clearFocus()
                    viewDataBinding!!.edNumber6.requestFocus()
                    viewDataBinding!!.edNumber6.isCursorVisible = true
                    viewDataBinding!!.edNumber5.background = baseActivity!!.resources.getDrawable(R.drawable.bg_code_box_green)
                }
                else if (viewDataBinding!!.edNumber5.text.toString().isNullOrEmpty()) {
                    viewDataBinding!!.edNumber5.clearFocus()
                    viewDataBinding!!.edNumber4.requestFocus()
                    viewDataBinding!!.edNumber4.isCursorVisible = true
                    viewDataBinding!!.edNumber5.background = baseActivity!!.resources.getDrawable(R.drawable.bg_code_box)
                }
                viewDataBinding!!.tvError.text = ""
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) { // TODO Auto-generated method stub
            }

            override fun afterTextChanged(s: Editable) { // TODO Auto-generated method stub
            }
        })
        viewDataBinding!!.edNumber6.addTextChangedListener(object : TextWatcher {
            @SuppressLint("UseCompatLoadingForDrawables")
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) { // TODO Auto-generated method stub
                if (viewDataBinding!!.edNumber6.text.toString().isNullOrEmpty()) {
                    viewDataBinding!!.edNumber6.clearFocus()
                    viewDataBinding!!.edNumber5.requestFocus()
                    viewDataBinding!!.edNumber5.isCursorVisible = true
                    viewDataBinding!!.edNumber6.background = baseActivity!!.resources.getDrawable(R.drawable.bg_code_box)
                }
                else{
                    viewDataBinding!!.edNumber6.background = baseActivity!!.resources.getDrawable(R.drawable.bg_code_box_green)
                }
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) { // TODO Auto-generated method stub
            }

            override fun afterTextChanged(s: Editable) { // TODO Auto-generated method stub
            }
        })

        // Tapped Resend OTP button
        viewDataBinding!!.btnReSendOTP.setOnClickListener {
            run {
                resendOTP()
            }
        }

        // Tapped Verify button
        viewDataBinding!!.btnVerify.setOnClickListener {
            validateAndLogin()
        }
    }

    // Resend OTP
    private fun resendOTP(){
        val userMobile = viewModel.codeMobileNumber.plus(viewModel.mobileNumber)
        viewModel.shopperForgetPassword(userMobile, object:HandleResponse<SimpleResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                AppLogger.d("<===== Failed to resend Otp")

                val errorMsg = error?.message ?: getString(R.string.something_went_wrong)
                processResendOtpError(errorMsg)
            }

            override fun handleSuccessResponse(successResponse: SimpleResponse) {
                AppLogger.d("<===== Sent PIN to your mobile number")
                val updateResponse = successResponse.response
                if (updateResponse != null) {
                    if (updateResponse.httpCode == 200) {
//                        viewDataBinding!!.tvStatus.text = getString(R.string.correct)

                        initOtpBoxes()

//                        viewDataBinding!!.layoutCodeProgressing.visibility = View.GONE
//                        viewDataBinding!!.layoutCode.visibility = View.VISIBLE

                        Toast.makeText(baseActivity, updateResponse.message, Toast.LENGTH_SHORT).show()
                    }
                    else{
                        processResendOtpError(updateResponse.message)
                    }
                }
                else{
                    processResendOtpError(getString(R.string.something_went_wrong))
                }
            }
        })
    }

    // Process Resend otp error
    @SuppressLint("UseCompatLoadingForDrawables")
    private fun processResendOtpError(errorMsg : String, isWrong : Boolean = false){
//        viewDataBinding!!.tvError.text = errorMsg
//        viewDataBinding!!.layoutCodeProgressing.visibility = View.GONE
//        viewDataBinding!!.layoutCode.visibility = View.VISIBLE

        Toast.makeText(baseActivity, errorMsg, Toast.LENGTH_SHORT).show()
    }

    private val keyBoardEnterListener =
        OnEditorActionListener { v: TextView?, actionId: Int, event: KeyEvent? ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                //   validateAndLogin()
                true
            }
            false
        }

    // Show the error message
    @SuppressLint("UseCompatLoadingForDrawables")
    private fun processError(errorMsg : String, isWrong: Boolean = false){
        // Enable Resend button
        viewDataBinding!!.btnReSendOTP.isEnabled = true
        viewDataBinding!!.btnReSendOTP.setTextColor(resources.getColor(R.color.colorPrimary))

        Toast.makeText(baseActivity, errorMsg, Toast.LENGTH_SHORT).show()

//        viewDataBinding!!.tvError.text = errorMsg
//        viewDataBinding!!.layoutCodeProgressing.visibility = View.GONE
//        viewDataBinding!!.layoutCode.visibility = View.VISIBLE

        if (isWrong){
            viewDataBinding!!.edNumber1.background = baseActivity!!.resources.getDrawable(R.drawable.bg_code_box_red)
            viewDataBinding!!.edNumber2.background = baseActivity!!.resources.getDrawable(R.drawable.bg_code_box_red)
            viewDataBinding!!.edNumber3.background = baseActivity!!.resources.getDrawable(R.drawable.bg_code_box_red)
            viewDataBinding!!.edNumber4.background = baseActivity!!.resources.getDrawable(R.drawable.bg_code_box_red)
            viewDataBinding!!.edNumber5.background = baseActivity!!.resources.getDrawable(R.drawable.bg_code_box_red)
            viewDataBinding!!.edNumber6.background = baseActivity!!.resources.getDrawable(R.drawable.bg_code_box_red)
        }
    }

    // Called when tap the Verify button
    private fun validateAndLogin() {
        hideKeyboard()

//        viewDataBinding!!.layoutCodeProgressing.visibility = View.VISIBLE
//        viewDataBinding!!.layoutCode.visibility = View.GONE
//        viewDataBinding!!.tvStatus.text = getString(R.string.verifying)

//        if (OtpVerificationFragmentArgs.fromBundle(arguments!!).isForgetPassword) {
//            //      timer.cancel()
//        }

        val codeVerification = viewDataBinding!!.edNumber1.text.toString()
            .plus(viewDataBinding!!.edNumber2.text.toString())
            .plus(viewDataBinding!!.edNumber3.text.toString())
            .plus(viewDataBinding!!.edNumber4.text.toString())
            .plus(viewDataBinding!!.edNumber5.text.toString())
            .plus(viewDataBinding!!.edNumber6.text.toString())

        AppLogger.d("<===== OTP Code")
        Timber.tag("OtpVerification").d(codeVerification)

        // Disable Resend button
        viewDataBinding!!.btnReSendOTP.isEnabled = false
        viewDataBinding!!.btnReSendOTP.setTextColor(resources.getColor(R.color.colorGreyNobel))

        // Call api to verify otp
        val userMobile = viewModel.codeMobileNumber.plus(viewModel.mobileNumber)
        viewModel.verifyOTP(userMobile, codeVerification, object:HandleResponse<CheckOTP>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                processError(error?.message ?: getString(R.string.something_went_wrong))
            }

            override fun handleSuccessResponse(successResponse: CheckOTP) {
//                viewDataBinding!!.tvStatus.text = getString(R.string.correct)
                val otpResponse = successResponse.response
                if (otpResponse != null){
                    if (otpResponse.httpCode == 200) {
                        Handler().postDelayed(
                            {
                                if (OtpVerificationFragmentArgs.fromBundle(arguments!!).isForgetPassword) {
                                    navigate(OtpVerificationFragmentDirections.actionOtpVerificationFragmentToSetNewPin())
                                }
                                else {

                                }
                            }, 1000
                        )
                    }
                    else{
                        // Display error message
                        processError(otpResponse.message, true)
                    }
                }
                else{
                    // Display error message
                    processError(getString(R.string.something_went_wrong))
                }
            }
        })

    }
}
