package com.app.basketiodriver.ui.checkout.receipt

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import app.basket.scanner.BasketScanner
import com.app.basketiodriver.BuildConfig
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.ActivityReceiptInfoBinding
import com.app.basketiodriver.di.Navigators
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.checkout.card.CheckoutCardViewModel
import com.app.basketiodriver.ui.checkout.scan.ScanditActivity
import com.app.basketiodriver.utils.AppConstants
//import kotlinx.android.synthetic.main.activity_receipt_info.*

class ReceiptInfoActivity : BaseActivity<ActivityReceiptInfoBinding, CheckoutCardViewModel>()  {
    var orderId : Long = 0
    var oldSubtotal : Double = 0.0

    var scanReceipt : Boolean = false
    var manualReceipt : Boolean = false

    var barCode : String = ""

    final val SCAN_ACTIVITY : Int = 234

    override val layoutId: Int
        get() = R.layout.activity_receipt_info

    override val viewModel: CheckoutCardViewModel
        get() {
            return getViewModel(CheckoutCardViewModel::class.java)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize the Toolbar
        initToolbar(getString(R.string.charge_card),
            true, viewDataBinding!!.layoutToolBar.toolbar,
            View.OnClickListener {
                run {
                    onBackPressed()
                }
            })

        // get order id
        orderId = intent.getLongExtra("KEY_ORDER_OUTLET_ID", 0)
        oldSubtotal = intent.getDoubleExtra("KEY_ORDER_SUBTOTAL", 0.0)

        initView()
    }

    private fun initView(){
        setActions()
    }

    private fun setActions(){
        viewDataBinding!!.btnManualReceipt.setOnClickListener {
            if (!viewDataBinding!!.edtReceiptNumber.text.toString().trim().isEmpty()){
                val receiptNumber = viewDataBinding!!.edtReceiptNumber.text.toString()
                if (!manualReceipt){
                    manualReceipt = true

                    // Go to UploadReceiptInfo page
                    // Take a photo of receipt
                    Navigators.goToReceiptCheckActivity(this, orderId, receiptNumber)
                }
                else{
                    Toast.makeText(this, R.string.please_enter_receipt_no, Toast.LENGTH_SHORT).show()
                }
            }
        }

        viewDataBinding!!.btnScanReceipt.setOnClickListener {
            scanReceipt = true
            // Go to Scan Receipt Page
//            Navigators.goToScanditActivity(this, "", true)
            // start new scanning SDK
            startScanner()
        }
    }
    private fun startScanner() {
        BasketScanner.scan(onSuccess = {
            scanReceipt = false
            if (it != ""){
                setBarcode(it)
            }

        }, onCanceled = {}, onEmptyResult = {}, onFailure = {
            Toast.makeText(this@ReceiptInfoActivity, it.message + "", Toast.LENGTH_LONG).show()
        })
    }

    private fun setBarcode(barcode : String){
        this.barCode = barcode
        viewDataBinding!!.edtReceiptNumber.setText(barCode)
        viewDataBinding!!.lvScanReceipt.visibility = View.GONE
        viewDataBinding!!.lvManualReceipt.visibility = View.VISIBLE
    }

    private fun isCarrifourMall(outletId: Long): Boolean {
        if (!BuildConfig.BUILD_TYPE.equals("release", true)) return false
        val malls = ArrayList<Long>()
        malls.add(139L)
        malls.add(138L)
        malls.add(137L)
        malls.add(105L)
        malls.add(82L)
        malls.add(78L)
        malls.add(77L)
        malls.add(76L)
        malls.add(75L)
        malls.add(68L)
        malls.add(67L)

        return malls.contains(outletId)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        scanReceipt = false

        if (requestCode == SCAN_ACTIVITY && resultCode == Activity.RESULT_OK){
            val scanResult : String = data?.extras!!.getString("ScanResult", "")
            if (scanResult != ""){
                setBarcode(scanResult)
            }
        }
        else if (requestCode == SCAN_ACTIVITY && resultCode == Activity.RESULT_CANCELED){
            if (data != null){
                val unableScan : Int = data.extras!!.getInt("UnableScan", 0)
                if (unableScan == 1)
                    setBarcode("")
            }
        }
    }

    override fun onBackPressed() {
//        super.onBackPressed()

        if (viewDataBinding!!.lvManualReceipt.visibility == View.VISIBLE){
            viewDataBinding!!.lvManualReceipt.visibility = View.GONE
            viewDataBinding!!.lvScanReceipt.visibility = View.VISIBLE
        }
        else{
            // Go to Dashboard
            Navigators.goToDashboard(this)
        }
    }

    override fun onResume() {
        super.onResume()

        scanReceipt = false
        manualReceipt = false
    }

    override fun onStart() {
        super.onStart()

        scanReceipt = false
        manualReceipt = false
    }
}