package com.app.basketiodriver.ui.onboarding.fragments


import android.app.DatePickerDialog
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import bloder.com.blitzcore.enableWhen
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.requests.ProfileRequest
import com.app.basketiodriver.data.model.api.response.Base.BaseResponse
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.databinding.FragmentAdditionalInfoBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.onboarding.OnBoardingViewModel
import com.app.basketiodriver.utils.AppLogger
import com.mukesh.countrypicker.Country
import com.mukesh.countrypicker.CountryPicker
import com.mukesh.countrypicker.OnCountryPickerListener
import java.text.SimpleDateFormat
import java.util.*


/**
 * A simple [Fragment] subclass.
 */

class AdditionalInfoFragment :
    BaseFragment<FragmentAdditionalInfoBinding?, OnBoardingViewModel>(),
    Injectable, OnCountryPickerListener, View.OnClickListener {


    override val layoutId: Int
        get() = R.layout.fragment_additional_info

    override val viewModel: OnBoardingViewModel
        get() {
            return getViewModel(requireActivity(), OnBoardingViewModel::class.java)
        }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setTitle(getString(R.string.personal_data))

        validation()

        viewDataBinding!!.btnNext.setOnClickListener(this)


        var cal = Calendar.getInstance()

        val myFormat = "yyyy/MM/dd" // mention the format you need
        val dateFormatter = SimpleDateFormat(myFormat, Locale.US)
        viewDataBinding!!.edDateOfBirth.setText(dateFormatter.format(cal.time))


        val dateSetListener =
            DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->
                cal.set(Calendar.YEAR, year)
                cal.set(Calendar.MONTH, monthOfYear)
                cal.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                viewDataBinding!!.edDateOfBirth.setText(dateFormatter.format(cal.time))

            }
        viewDataBinding!!.edDateOfBirth.setOnClickListener {
            DatePickerDialog(
                requireContext(), dateSetListener,
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)
            ).show()

        }

        val adapter: ArrayAdapter<String> = ArrayAdapter<String>(
            requireContext(),
            android.R.layout.simple_spinner_item, resources.getStringArray(R.array.gender_list)
        )
        viewDataBinding!!.edGender.adapter = adapter

        val builder = CountryPicker.Builder().with(baseActivity!!)
            .listener(this)

        mCountryPicker = builder.build()


        viewDataBinding!!.edNationality.setOnClickListener {
            run {
                mCountryPicker!!.showDialog(baseActivity!!)
            }
        }

    }

    var mCountryPicker: CountryPicker? = null
    private fun validation() {

        viewDataBinding!!.btnNext.enableWhen {
            viewDataBinding!!.edDateOfBirth.isFilled() onValidationSuccess {
                viewDataBinding!!.edDateOfBirth.onSuccess()
            } onValidationError {
                viewDataBinding!!.edDateOfBirth.onError()
            }
            viewDataBinding!!.edGender.isSelect() onValidationSuccess {
                viewDataBinding!!.edGender.onSuccess()
            } onValidationError {
                viewDataBinding!!.edGender.onError()
            }
            viewDataBinding!!.edNationality.isFilled() onValidationSuccess {
                viewDataBinding!!.edNationality.onSuccess()
            } onValidationError {
                viewDataBinding!!.edNationality.onError()
            }
            viewDataBinding!!.edNationalIDNumber.isFilled() onValidationSuccess {
                viewDataBinding!!.edNationalIDNumber.onSuccess()
            } onValidationError {
                viewDataBinding!!.edNationalIDNumber.onError()
            }
        }

    }

    override fun onClick(p0: View?) {
        when (p0!!.id) {
            R.id.btnNext -> {

                val profile = ProfileRequest();
                profile.dob = viewDataBinding!!.edDateOfBirth.text.toString()
                profile.gender = viewDataBinding!!.edGender.selectedItemPosition
                profile.national_id_number = viewDataBinding!!.edNationalIDNumber.text.toString()
                profile.nationality = viewDataBinding!!.edNationality.text.toString()

                viewModel.shopperUpdateProfile(profile, object : HandleResponse<BaseResponse> {
                    override fun handleErrorResponse(error: ErrorResponse?) {
                        AppLogger.d("handleErrorResponse  ${error}")
                    }

                    override fun handleSuccessResponse(successResponse: BaseResponse) {
                        popNavigate()
                        AppLogger.d("popNavigate ${popNavigate(R.id.reviewApplicationFragment)}")
                        AppLogger.d("handleSuccessResponse-->shopperUpdateProfile")

                    }

                });


            }

        }
    }

    override fun onSelectCountry(country: Country?) {
        viewDataBinding!!.edNationality.setText(country?.name)
    }
}





