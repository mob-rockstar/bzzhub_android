package com.app.basketiodriver.ui.order.product

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.Html
import android.view.Gravity
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.widget.SearchView
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import app.basket.scanner.BasketScanner
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.checkout.CustomerInfo
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.model.api.response.order.CommonResponse
import com.app.basketiodriver.data.model.api.response.order.ItemResponse
import com.app.basketiodriver.data.model.api.response.order.ReplacementOrdersItemRequest
import com.app.basketiodriver.data.model.api.response.order.SimilarProduct
import com.app.basketiodriver.data.model.api.response.order.SimilarResponse
import com.app.basketiodriver.data.remote.socket.SystemMessage
import com.app.basketiodriver.data.remote.socket.SystemMessageReq
import com.app.basketiodriver.databinding.ActivitySearchForSimilarBinding
import com.app.basketiodriver.databinding.DialogItemScannedBinding
import com.app.basketiodriver.di.Navigators
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.app.basketiodriver.ui.dialogs.AmountDialogFragment
import com.app.basketiodriver.ui.dialogs.ReplaceQuantityDialogFragment
import com.app.basketiodriver.ui.order.adapter.SimilarProductListAdapter
import com.app.basketiodriver.ui.order.product.ItemDetails.Companion.SCAN_ACTIVITY
import com.app.basketiodriver.ui.order.product.ScanItem.Companion.ITEM_AMOUNT
import com.app.basketiodriver.ui.order.product.ScanItem.Companion.ITEM_WEIGHT
import com.app.basketiodriver.utils.AppConstants
import com.app.basketiodriver.utils.GlideApp
import com.app.basketiodriver.utils.PopupUtils
import com.app.basketiodriver.utils.order.OrderItemSingleton
import com.app.basketiodriver.utils.price.PriceConstructor
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import io.reactivex.Observable
import io.reactivex.ObservableEmitter
import io.reactivex.ObservableOnSubscribe
import java.util.*
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import kotlin.collections.ArrayList

class SearchForSimilarActivity :
    BaseActivity<ActivitySearchForSimilarBinding, OrderDetailsViewModel>(),
    SearchView.OnQueryTextListener, ObservableOnSubscribe<String>,
    AmountDialogFragment.AmountDialogOnClickListener, HasAndroidInjector,
    SimilarProductListAdapter.SimilarProductItemClickListener {
    override val layoutId: Int
        get() = R.layout.activity_search_for_similar

    override val viewModel: OrderDetailsViewModel
        get() {
            return getViewModel(OrderDetailsViewModel::class.java)
        }

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    var orderId: Long = 0
    var itemId: Long = 0
    var searchId: Long = 0
    var originalItemQty: Double = 0.0

    var ordersItem: OrdersItem? = null
    var info: CustomerInfo? = null

    var actionFrom = 1

    var clickOnScan = false
    var onItemClick = false

    // search result
    var itemsList: ArrayList<SimilarProduct> = arrayListOf()

    lateinit var mAdapter: SimilarProductListAdapter

    lateinit var searchObservable: Observable<String>
    lateinit var mEmitter: ObservableEmitter<String>

    var isReplaceItem: Int = 0

    // Searched items for replacement
    var selectedItemsForReplace: ArrayList<SimilarProduct> = arrayListOf()
    var newItem: OrdersItem? = null

    // Replacement Items
    var scannedItems: MutableList<OrdersItem> = arrayListOf()

    var amountDialog: AmountDialogFragment? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Init toolbar
        initToolBar()

        viewDataBinding!!.rvReplaceItem.layoutManager = LinearLayoutManager(this)
        viewDataBinding!!.rvReplaceItem.setHasFixedSize(true)

        if (intent.extras != null) {
            ordersItem = intent.extras!!.getSerializable("ARG_ORDER_ITEM") as? OrdersItem
            info = intent.extras!!.getSerializable("ARG_INFO") as? CustomerInfo
//            actionFrom      = intent.getIntExtra("ACTION_FROM", 1)

            orderId = intent.extras!!.getLong("ARG_ORDER_ID")
            itemId = intent.extras!!.getLong("ARG_ITEM_ID")
            searchId = intent.extras!!.getLong("ARG_SEARCH_ID")
            originalItemQty = intent.extras!!.getDouble("ARG_ORIGINAL_ITEM_QTY")

            isReplaceItem = intent.extras!!.getInt("ARG_IS_REPLACEMENT", 0)
        }

        initViews()

        initSearchView()
    }

    private fun initToolBar() {
        initToolbar(getString(R.string.select_item_for_replacement),
            true, viewDataBinding!!.layoutToolBar.toolbar,
            View.OnClickListener {
                run {
                    onBackPressed()
                }
            })
    }

    private fun initViews() {
        if (ordersItem != null && (ordersItem!!.soldPer == 2 || ordersItem!!.upcType == 2)) {
            viewDataBinding!!.txtScanItem.visibility = View.GONE
        } else {
            viewDataBinding!!.txtScanItem.visibility = View.VISIBLE
        }

        // Confirm Button
        viewDataBinding!!.confirm.setOnClickListener {
            if (selectedItemsForReplace.size > OrderItemSingleton.getReplacementLimit()) {
                // Show alert
                val msg = String.format(
                    Locale.ENGLISH,
                    getString(R.string.msg_replacement_limit_count),
                    OrderItemSingleton.getReplacementLimit()
                )
                showErrorMessages(msg)
            } else {
                // Replace the item with searched items
                replaceItem()
            }
        }

        // Scan As Replace
        viewDataBinding!!.txtScanItem.setOnClickListener {
            if (!clickOnScan) {
                clickOnScan = true

                // Go to ScanReplaceActivity
//                val intent = Intent(this, ScanReplaceActivity::class.java)
//                intent.putExtra("ARG_ORDERS_ITEM", ordersItem!!)
//                intent.putExtra("ARG_ORDER_ID", orderId)
//                intent.putExtra("ARG_IS_REPLACEMENT", isReplaceItem)
//                startActivityForResult(intent, SCAN_ACTIVITY)
                // start new scanning sdk
                startScanner()
            }
        }

        viewDataBinding!!.tvBarcodeDone.setOnClickListener {
            val etBarcode = viewDataBinding!!.etManuallyBarcode.text.toString().trim()
            if (etBarcode.isNotEmpty()){
                checkBarcode(etBarcode)
            }else{
                Toast.makeText(this@SearchForSimilarActivity ,resources.getString(R.string.plz_enter_barcode_manually),Toast.LENGTH_SHORT).show()
            }

        }
    }

    private fun startScanner() {
        BasketScanner.scan(onSuccess = {
            checkBarcode(it)
        }, onCanceled = {}, onEmptyResult = {}, onFailure = {
            Toast.makeText(this@SearchForSimilarActivity, it.message + "", Toast.LENGTH_LONG).show()
        })
    }

    private fun checkBarcode(barcode: String) {
        viewModel.getProductByBarcode(orderId, barcode, object : HandleResponse<ItemResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                Toast.makeText(this@SearchForSimilarActivity, error?.message, Toast.LENGTH_SHORT)
                    .show()
            }

            override fun handleSuccessResponse(successResponse: ItemResponse) {
                if (successResponse.response != null) {
                    if (successResponse.response.httpCode == 200) {
                        // Show the ProductDialog
                        if (successResponse.response.itemDetails != null)
                            showScannedProductDialog(successResponse.response.itemDetails)
                        else
                            Toast.makeText(
                                this@SearchForSimilarActivity,
                                successResponse.response.message,
                                Toast.LENGTH_SHORT
                            ).show()
                    } else if (successResponse.response.httpCode == 201) {
                        createCustomPlacement(barcode)
                    } else {
                        Toast.makeText(
                            this@SearchForSimilarActivity,
                            successResponse.response.message,
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    Toast.makeText(
                        this@SearchForSimilarActivity,
                        R.string.error_server_return_null,
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        })
    }

    private fun createCustomPlacement(barcode: String) {
        Navigators.goToReplaceCustomItemActivity(
            this,
            barcode,
            ordersItem!!.ordersOutletsItemsId ?: 0
        )
    }

    private fun showScannedProductDialog(scanItem: OrdersItem) {
        newItem = scanItem

        // Save the scanned item
        scannedItems.add(scanItem)

        try {
            val dialog = Dialog(this)
            val binding: DialogItemScannedBinding = DataBindingUtil.inflate(
                LayoutInflater.from(this),
                R.layout.dialog_item_scanned,
                null,
                false
            )

            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setContentView(binding.root)
            dialog.setCancelable(false)
            dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window?.setGravity(Gravity.CENTER)
            dialog.setOnKeyListener { it, keyCode, event -> // Prevent dialog close on back press button
                keyCode == KeyEvent.KEYCODE_BACK
            }

            // Cancel
            binding.tvCancel.setOnClickListener {
                // Remove the all scanned items
                scannedItems.clear()

                // Dismiss the dialog
                dialog.dismiss()

                //                if (picker != null)
//                    picker!!.startScanning()
                startScanner()
            }

            // Confirm
            binding.tvConfirm.setOnClickListener {
                dialog.dismiss()

                // Show the Enter amount & weight dialog
                showAmountDialog()
            }

            // Scan more item
            binding.tvScanMore.setOnClickListener {
                if (scannedItems.size >= OrderItemSingleton.getReplacementLimit()) {
                    // Show alert
                    val msg = String.format(
                        Locale.ENGLISH,
                        getString(R.string.msg_replacement_limit_count),
                        OrderItemSingleton.getReplacementLimit()
                    )
                    showErrorMessages(msg)
                } else {
                    // Scan more item
                    dialog.dismiss()

//                    viewDataBinding!!.refreshCamera.visibility = View.GONE
//                    if (picker != null)
//                        picker!!.startScanning()
                    startScanner()
                }
            }

            // Show the Item information
            // Product image
            if (scanItem.productImage != null) {
//                Picasso.get().load(scanItem.productImage).fit().error(R.drawable.placeholder).into(binding.productLayout.orderItemImage)
                GlideApp.with(this).load(scanItem.productImage).error(R.drawable.placeholder)
                    .into(binding.productLayout.orderItemImage)
            }

            // Title
            binding.productLayout.orderItemTitle.text =
                scanItem.productName ?: "N/A"// + " " + item.aisleName

            // Cost
            binding.productLayout.orderCost.text = Html.fromHtml(
                PriceConstructor.getFormatPrice(
                    ordersItem,
                    PriceConstructor.LabelType.SIMPLE,
                    PreferenceManager.currency,
                    true
                )
            )

            // Description
            if (scanItem.getDescriptionLabel().isEmpty()) {
                binding.productLayout.tvPriceDescription.visibility = View.GONE
            } else {
                binding.productLayout.tvPriceDescription.visibility = View.VISIBLE
                binding.productLayout.tvPriceDescription.text = scanItem.getDescriptionLabel()
            }

            PopupUtils.setDefaultDialogProperty(dialog)
            dialog.show()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showAmountDialog() {
        try {
            amountDialog = AmountDialogFragment.newInstance(
                ordersItem!!,
                scannedItems,
                ordersItem!!.itemQty ?: 0.0
            )
            amountDialog!!.show(supportFragmentManager, AmountDialogFragment.javaClass.name)
            amountDialog!!.setAmountNextClickListener(this)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @SuppressLint("CheckResult")
    private fun initSearchView() {
        viewDataBinding!!.searchView.isIconifiedByDefault = false
        viewDataBinding!!.searchView.setOnQueryTextListener(this)

        viewDataBinding!!.searchView.queryHint = getString(R.string.search_item_hint)

        searchObservable = getCurrentSearchObservable()
        searchObservable.debounce(1, TimeUnit.SECONDS).subscribe(this::getProducts)
    }

    // Set the product list adapter
    private fun setAdapter() {
        mAdapter = SimilarProductListAdapter(this, itemsList, this, isReplaceItem)
        viewDataBinding!!.rvReplaceItem.adapter = mAdapter
    }

    // Get the product list by search key
    private fun getProducts(search: String) {
        runOnUiThread { viewDataBinding!!.progress.visibility = View.VISIBLE }
        val isCustomItem =
            if (ordersItem!!.item_type != null && ordersItem!!.item_type == 1) 0 else 1

        viewModel.shopperSimilarProductList(
            searchId,
            isCustomItem,
            search,
            object : HandleResponse<SimilarResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    runOnUiThread { viewDataBinding!!.progress.visibility = View.GONE }
                    if (isNetworkConnected) {
                        Toast.makeText(
                            this@SearchForSimilarActivity,
                            error?.message,
                            Toast.LENGTH_LONG
                        ).show()
                    } else {
                        Toast.makeText(
                            this@SearchForSimilarActivity,
                            resources?.getString(R.string.no_internet_conn_msg_txt),
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

                override fun handleSuccessResponse(successResponse: SimilarResponse) {
                    runOnUiThread { viewDataBinding!!.progress.visibility = View.GONE }

                    val data = successResponse.response
                    if (data != null) {
                        if (data.httpCode == 200) {
                            onSuccess(data.similarProducts)
                        } else {
                            Toast.makeText(
                                this@SearchForSimilarActivity,
                                data.message,
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } else {
                        Toast.makeText(
                            this@SearchForSimilarActivity,
                            R.string.error_server_return_null,
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            })
    }

    // Process the search result
    private fun onSuccess(list: ArrayList<SimilarProduct>) {
        itemsList = list
        setAdapter()

        if (itemsList.size > 0) {
            viewDataBinding!!.txtNoResultFound.visibility = View.GONE
            viewDataBinding!!.confirm.visibility = View.VISIBLE
        } else {
            viewDataBinding!!.txtNoResultFound.visibility = View.VISIBLE
            viewDataBinding!!.confirm.visibility = View.GONE
        }

    }

    private fun getCurrentSearchObservable(): Observable<String> {
        return Observable.create(this)
    }

    // Replace item
    private fun replaceItem() {
        if (ordersItem != null) {
            if (ordersItem!!.soldPer == 2) {
                replaceQuantityDialog(ordersItem!!, ordersItem!!.itemQty ?: 0.0)
            } else if (ordersItem!!.soldPer == 3) {
                replaceQuantityDialog(ordersItem!!, ordersItem!!.approxWeight)
            } else if (ordersItem!!.itemQty ?: 0.0 >= 1) {
                replaceQuantityDialog(ordersItem!!, ordersItem!!.itemQty ?: 0.0)
            } else {
                foundResult(1.0)
            }
        }
    }

    private fun replaceQuantityDialog(ordersItem: OrdersItem, quantity: Double) {
        // Show the ReplaceQuantityDialog
        val orgOrderId =
            if (ordersItem.replacementRequested != null && ordersItem.replacementRequested == 1) (ordersItem.oldOutletItemId
                ?: "0").toInt() else ordersItem.outletItemId ?: 0

        val selectedItems: ArrayList<SimilarProduct> = arrayListOf()
        selectedItems.addAll(selectedItemsForReplace)

        if (selectedItems.size > 0) {
            val replaceQtyDialogFragment = ReplaceQuantityDialogFragment.newInstance(
                orderId,
                ordersItem,
                selectedItems,
                quantity,
                orgOrderId,
                1
            )
            replaceQtyDialogFragment.show(
                supportFragmentManager,
                ReplaceQuantityDialogFragment.javaClass.name
            )
            replaceQtyDialogFragment.clickListener = this
        }

    }

    private fun foundResult(amount: Double) {
        val intent = Intent()
        intent.putExtra(ITEM_AMOUNT, amount)
        setResult(Activity.RESULT_OK, intent)
        finish()
    }

    /**
     * SearchView QueryTextListener
     */
    override fun onQueryTextSubmit(query: String?): Boolean {
        if (query == null || query.isEmpty()) {
            mAdapter = SimilarProductListAdapter(this, arrayListOf(), this)
            viewDataBinding!!.rvReplaceItem.adapter = mAdapter
        } else {
            getProducts(query)
        }

        return false
    }

    override fun onQueryTextChange(newText: String?): Boolean {
        if (newText == null || newText.isEmpty()) {
            mAdapter = SimilarProductListAdapter(this, arrayListOf(), this)
            viewDataBinding!!.rvReplaceItem.adapter = mAdapter
        } else {
            mEmitter.onNext(newText)
        }

        return true
    }

    /**
     * Observable Subscriber
     */
    override fun subscribe(emitter: ObservableEmitter<String>) {
        mEmitter = emitter
    }

    /**
     * SimilarProductList ItemClickListener
     */
    override fun onClickSimilarProduct(item: SimilarProduct) {
        if (!onItemClick) {
            onItemClick = true
            if (item.upcType == 2) {
                replaceItem()
            } else {
                // Go To ScanAsReplaceItemActivity
                val intent = Intent(this, ScanAsReplaceItemActivity::class.java)
                intent.putExtra("ARG_ITEM_DETAIL", item)
                intent.putExtra("ARG_ORDER_OUTLET_ID", orderId)
                intent.putExtra("ARG_ITEM_ID", itemId)
                intent.putExtra("ARG_AUTO_FOCUS", true)
                intent.putExtra("ARG_INFO", info)
                intent.putExtra("ARG_ORDER_ITEM", ordersItem)
                intent.putExtra("ARG_IS_REPLACEMENT", 1)
                startActivityForResult(intent, SCAN_ACTIVITY)
            }

            onItemClick = false
        }
    }

    // Replace the multiple items
    private fun replaceMultipleItems(items : ArrayList<ReplacementOrdersItemRequest>){
        val oldItemId = if (ordersItem!!.replacementRequested != null && ordersItem!!.replacementRequested == 1) ((ordersItem!!.oldOutletItemId ?: "0").toLongOrNull() ?: 0) else (ordersItem!!.outletItemId ?: 0).toLong()

        viewModel.replaceMultipleOrdersItems(oldItemId, orderId, items, 1, object : HandleResponse<CommonResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                Toast.makeText(this@SearchForSimilarActivity, error?.message, Toast.LENGTH_SHORT).show()
            }

            override fun handleSuccessResponse(successResponse: CommonResponse) {
                if (successResponse.status == 200) {
                    var message = ""
                    message = if (ordersItem!!.replacementRequested != null && ordersItem!!.replacementRequested == 1){
                        AppConstants.MESSAGE_TYPE_REPLACED + " " + PreferenceManager.currentShopperFirstName + " " + getString(R.string.replaced) + ","+ getString(R.string.item) + " " + ordersItem!!.oldProductName + ", " + getString(R.string.with_1) + ", " +getString(R.string.item) + " "+ items[0].product!!.productName+"."
                    } else{
                        AppConstants.MESSAGE_TYPE_REPLACED + " " + PreferenceManager.currentShopperFirstName + " " + getString(R.string.replaced) + ", " + getString(R.string.item) + " "+ ordersItem!!.productName + ", " + getString(R.string.with_1) + ", "+ getString(R.string.item) + " "+ items[0].product!!.productName+"."
                    }

                    // Send system message to user
                    val systemMessageReq = SystemMessageReq(orderId.toString(), "text", message)
                    sendSystemMessage(systemMessageReq){
                        setResult(Activity.RESULT_OK)
                        finish()
                    }
                }
                else{
                    Toast.makeText(this@SearchForSimilarActivity, successResponse.message, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }


    private fun sendSystemMessage(systemMessageReq: SystemMessageReq, onAfterSystemMessageClicked: ()->Unit){
        viewModel.sendSystemMessage(systemMessageReq, object : HandleResponse<SystemMessage> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                onAfterSystemMessageClicked()
            }

            override fun handleSuccessResponse(successResponse: SystemMessage) {
                onAfterSystemMessageClicked()
            }
        })
    }

    /**
     * AmountNewDialog ClickListener
     */
    override fun onNextClick(amount: Double) {
        foundResult(amount)
    }

    override fun onNextClick(requestItems: ArrayList<ReplacementOrdersItemRequest>) {
        replaceMultipleItems(requestItems)
    }

    override fun onNextClick(itemId: Long, amount: Double) {

    }

    override fun onNextClick(amount: Double, weight: Double) {
        val intent = Intent()
        intent.putExtra(ITEM_AMOUNT, amount)
        intent.putExtra(ITEM_WEIGHT, weight)
        setResult(Activity.RESULT_OK, intent)
        finish()
    }

    // Called when replaced the multiple items
    override fun onNextClick(itemId: Long, amount: Double, weight: Double) {
        val intent = Intent()
        setResult(Activity.RESULT_OK, intent)
        finish()
    }

    /**
     * OnActivityResult
     */
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == SCAN_ACTIVITY) {
            if (resultCode == Activity.RESULT_OK) {
                setResult(Activity.RESULT_OK)
                finish()
            }
        }

        super.onActivityResult(requestCode, resultCode, data)
    }


    override fun onDestroy() {
        super.onDestroy()

        mEmitter.onComplete()
    }

    override fun onResume() {
        super.onResume()

        clickOnScan = false
        onItemClick = false
    }

    override fun onStart() {
        super.onStart()

        clickOnScan = false
        onItemClick = false
    }

    override fun onBackPressed() {
//        super.onBackPressed()
        hideKeyboard()
        finish()
    }
}