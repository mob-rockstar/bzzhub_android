package com.app.basketiodriver.data.model.api.response.settings

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class SettingsResponse {
    @SerializedName("response")
    @Expose
    val response: ContactData? = null

    inner class ContactData {
        @SerializedName("httpCode")
        @Expose
        val httpCode: Long? = null

        @SerializedName("Message")
        @Expose
        val message: String = ""

        @SerializedName("contact_settings")
        @Expose
        val contactSettings: ContactSettings? = null
    }
}