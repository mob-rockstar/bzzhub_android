package com.app.basketiodriver.data.model.api.response.earning.order

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName


class ShopperOrderDetailData {
    @SerializedName("order_outlet_id")
    @Expose
    var order_outlet_id: String? = null

    @SerializedName("customer_name")
    @Expose
    var customer_name: String? = null

    @SerializedName("customer_address_landmark")
    @Expose
    var customer_address_landmark: String? = null

    @SerializedName("customer_address")
    @Expose
    var customer_address: String? = null

    @SerializedName("vendor_name")
    @Expose
    var vendor_name: String? = null

    @SerializedName("contact_address")
    @Expose
    var contact_address: String? = null

    @SerializedName("total_amount")
    @Expose
    var total_amount: String = "0.00"

    @SerializedName("total_delivered_items")
    @Expose
    var total_delivered_items: String = "0"

    @SerializedName("travel_distance")
    @Expose
    var travel_distance: String = "0"

    @SerializedName("service_type")
    @Expose
    var service_type: String? = null

    @SerializedName("shopping_earning")
    @Expose
    var shopping_earning: String = "0.00"

    @SerializedName("delivery_earning")
    @Expose
    var delivery_earning: String = "0.00"

    @SerializedName("total_earnings")
    @Expose
    var total_earnings: String = "0.00"

    @SerializedName("total_collected")
    @Expose
    var total_collected: String = "0.00"

    @SerializedName("total_extra_amount_with_shopper")
    @Expose
    var total_extra_amount_with_shopper: String = "0.00"

    @SerializedName("contact_support_text")
    @Expose
    var contact_support_text: String? = null

    @SerializedName("current_account_balance")
    @Expose
    var current_account_balance: String = "0.00"

    @SerializedName("is_account_suspended")
    @Expose
    var is_account_suspended : Boolean = false

    @SerializedName("vendor_image")
    @Expose
    var vendor_image: String? = null

    @SerializedName("service_type_flag")
    @Expose
    var service_type_flag = 0
}