package com.app.basketiodriver.data.remote.socket

import com.google.gson.annotations.SerializedName

open class SocketTokenData {
    @SerializedName("service_token")
    var serviceToken: String = ""
}