package com.app.basketiodriver.ui.order.product

import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.checkout.CustomerInfo
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.model.api.response.order.Product
import com.app.basketiodriver.databinding.ActivityProductListBinding
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.checkout.adapter.DepartmentAdapter
import com.app.basketiodriver.ui.home.HomeViewModel
import com.app.basketiodriver.ui.order.adapter.ProductListAdapter
import com.app.basketiodriver.utils.AppUtils

class NewProductListActivity : BaseActivity<ActivityProductListBinding, HomeViewModel>() {
    override val layoutId: Int
        get() = R.layout.activity_product_list

    override val viewModel: HomeViewModel
        get() {
            return getViewModel(HomeViewModel::class.java)
        }

    var itemsList : ArrayList<OrdersItem> = arrayListOf()
    lateinit var listAdapter : DepartmentAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        initToolbar(getString(R.string.product_list),
            true, viewDataBinding!!.layoutToolBar.toolbar,
            View.OnClickListener {
                run {
                    onBackPressed()
                }
            })

        itemsList = intent.getSerializableExtra("ARG_ITEMS_ARRAY") as ArrayList<OrdersItem>

        initView()
    }

    private fun initView(){
        viewDataBinding!!.rvProducts.layoutManager = LinearLayoutManager(this)
        viewDataBinding!!.rvProducts.setHasFixedSize(true)

        val departments = AppUtils.sortItems(itemsList, 1)
        listAdapter = DepartmentAdapter(this, departments, "", 0, CustomerInfo(), false, false, 0)

        viewDataBinding!!.rvProducts.adapter = listAdapter
    }
}