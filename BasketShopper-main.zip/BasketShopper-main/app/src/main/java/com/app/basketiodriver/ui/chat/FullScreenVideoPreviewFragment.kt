package com.app.basketiodriver.ui.chat

import android.net.Uri
import android.os.Bundle
import android.view.View
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.model.api.response.order.SimilarProduct
import com.app.basketiodriver.databinding.FragmentFullVideoPreviewBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseDialogFragment
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.cardcamera.camera.CameraFragment
import com.app.basketiodriver.ui.dialogs.AmountDialogFragment
import com.google.android.exoplayer2.SimpleExoPlayer
import com.google.android.exoplayer2.source.ProgressiveMediaSource
import com.google.android.exoplayer2.upstream.DataSource
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory
import com.google.android.exoplayer2.util.Util


class FullScreenVideoPreviewFragment(

) : BaseDialogFragment<FragmentFullVideoPreviewBinding?, ChatViewModel>(),
    Injectable {

    private var player: SimpleExoPlayer? = null

    override val layoutId: Int
        get() = R.layout.fragment_full_video_preview

    override val viewModel: ChatViewModel
        get() {
            return getViewModel(baseActivity, ChatViewModel::class.java)
        }

    // Set Full screen
    override fun getTheme(): Int {
        return R.style.MyDialogWhite
    }

    var videoURL = ""

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        arguments?.let {
            videoURL = it.getString(KEY_URL, "")

        }
        viewDataBinding?.ivClose?.setOnClickListener { dismiss() }

        player = SimpleExoPlayer.Builder(baseActivity!!).build()
        viewDataBinding?.playerView?.player = player

        val dataSourceFactory: DataSource.Factory = DefaultDataSourceFactory(context!!, Util.getUserAgent(baseActivity!!, baseActivity!!.getString(R.string.app_name)))
        val mediaSource = ProgressiveMediaSource.Factory(dataSourceFactory).createMediaSource(Uri.parse(videoURL))
        player?.prepare(mediaSource, true, false)
        player?.playWhenReady = true
    }

    override fun onDetach() {
        player?.release()
        super.onDetach()
    }

    companion object {
        const val KEY_URL = "arg_url"
        // endregion
        /** Returns a new instance of this fragment for the given section number.  */
        fun newInstance(url : String): FullScreenVideoPreviewFragment {
            val fragment = FullScreenVideoPreviewFragment()
            val args = Bundle()
            args.putString(KEY_URL, url)

            fragment.arguments = args
            return fragment
        }
    }
}