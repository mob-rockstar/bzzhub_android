package com.app.basketiodriver.ui.home

import android.app.Application
import android.view.View
import com.app.basketiodriver.data.DataManager
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.requests.EarningReportDetailRequest
import com.app.basketiodriver.data.model.api.response.BookingSlotsResponse
import com.app.basketiodriver.data.model.api.response.hours.BookingReportResponse
import com.app.basketiodriver.data.model.api.response.EarningReportResponse
import com.app.basketiodriver.data.model.api.response.ServerTokenResponse
import com.app.basketiodriver.data.model.api.response.checkout.ShopperOrderReview
import com.app.basketiodriver.data.model.api.response.dashboard.OrderResponse
import com.app.basketiodriver.data.model.api.response.dashboard.ShopperOrderByIDResponse
import com.app.basketiodriver.data.model.api.response.general.SimpleResponse
import com.app.basketiodriver.data.model.api.response.order.DashboardOrderInfoResponse
import com.app.basketiodriver.data.model.api.response.order.HandoverCodeResponse
import com.app.basketiodriver.data.model.api.response.order.HistoryOrderInfoResponse
import com.app.basketiodriver.data.model.api.response.settings.SettingsResponse
import com.app.basketiodriver.data.model.api.response.shopper.ShopperResponse
import com.app.basketiodriver.data.model.api.response.terms.AgreeTermAndConditionResponse
import com.app.basketiodriver.data.model.api.response.terms.TermsAndConditionResponse
import com.app.basketiodriver.data.model.api.ticket.TicketFieldsData
import com.app.basketiodriver.data.remote.APIManager
import com.app.basketiodriver.data.remote.FreshchatApiService
import com.app.basketiodriver.data.remote.socket.ActiveDeviceTokenResponse
import com.app.basketiodriver.data.remote.socket.SocketTokenResponse
import com.app.basketiodriver.data.remote.socket.SystemMessage
import com.app.basketiodriver.data.remote.socket.SystemMessageReq
import com.app.basketiodriver.mvvm.ui.login.LoginNavigator
import com.app.basketiodriver.ui.base.BaseViewModel
import com.app.basketiodriver.ui.base.HandleResponse
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

/**
 * Created by ibraheem lubbad on 2020-02-05.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class HomeViewModel(
    application: Application,
    dataManager: DataManager
) :
    BaseViewModel<LoginNavigator?>(application, dataManager) {

    // Get the contact information
    fun getContactInformation(countryId : Int, cityId : Int, handleResponse : HandleResponse<SettingsResponse>){
        compositeDisposable.add(
            APIManager.getSettings(countryId, cityId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
//                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }

                    },
                    { x ->
                        run {
//                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    fun getShopperBookingReport(
        fromDate:String, toDate:String,
        handleResponse: HandleResponse<BookingReportResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperBookingReport(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, fromDate, toDate)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessResponse(result)
                    }

                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            )
        )
    }

    fun getEarningReportDetails(
        request: EarningReportDetailRequest,
        handleResponse: HandleResponse<EarningReportResponse.EarningReportData?>
    ) {

    }

    /**
     * Method to get the shopper details
     * @param langCode current language code , 1 : EN
     * @param shopperId current shopper ID
     * @param handleResponse HandleResponse<ShopperResponse>
     */
    fun getShopperDetails(langCode : Int, shopperId:Long, handleResponse: HandleResponse<ShopperResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.getShopperDetails(langCode, shopperId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }


                    }
                )
        )
    }

    /**
     * Method to get service token
     */
    fun getServiceToken(handleResponse: HandleResponse<ServerTokenResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.getServiceAppToken(PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }


                    }
                )
        )
    }

    /**
     * Method to change the shopper online status
     */
    fun changeShopperOnlineStatus(status : Int, isEarly : Int, handleResponse : HandleResponse<SimpleResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.changeShopperOnlineStatus(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, status, isEarly)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }


                    }
                )
        )
    }

    /**
     * Method to get order list
     */
    fun getOrderList(page : Int, count : Int, handleResponse: HandleResponse<OrderResponse>){
        compositeDisposable.add(
            APIManager.getOrders(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, count, page)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }


    /**
     * Method to get order review(detail)
     */
    fun getShopperOrderReview(orderId : Long, handleResponse: HandleResponse<ShopperOrderReview>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperOrderReview(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, orderId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to update the shopper order status
     */
    fun updateOrderStatus(orderStatus : Int, orderId : Long, handleResponse: HandleResponse<SimpleResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.updateOrderStatus(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, PreferenceManager.shopperStatus, orderStatus, orderId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    fun getTicketTypeList(handleResponse: HandleResponse<ArrayList<TicketFieldsData>>){
        setIsLoading(true)
        compositeDisposable.add(
            FreshchatApiService.getTicketTypes()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe (
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to get dashboard order info
     */
    fun getDashboardOrderInfo(orderId : Long, handleResponse: HandleResponse<DashboardOrderInfoResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.getDashboardOrderInfo(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, orderId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to get history order info
     */
    fun getHistoryOrderInfo(orderId : Long, handleResponse: HandleResponse<HistoryOrderInfoResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.getHistoryOrderInfo(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, orderId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to verify Handover code
     */
    fun verifyHandoverCode(code : String, handleResponse: HandleResponse<HandoverCodeResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.verifyHandoverCode(PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, code)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to push the amount
     */
    fun pushAmountFromCustomer(orderId: Long, receivedByCustomer: Double, returnedToCustomer: Double, handleResponse: HandleResponse<SimpleResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.pushAmountFromCustomer(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, orderId, receivedByCustomer, returnedToCustomer)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     *
     * @param selectedDate Selected Date
     * @param handleResponse HandleResponse<BookingSlotsResponse>
     */
    fun getShopperBookingSlots(
        selectedDate:String,
        handleResponse: HandleResponse<BookingSlotsResponse>
    ) {
//        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperBookingSlots(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, selectedDate)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
//                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
//                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to get Terms & conditions
     */
    fun getTermsConditions(handleResponse: HandleResponse<TermsAndConditionResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperTermsAndConditions(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )

    }

    /**
     * Method to agree terms & conditions
     */
    fun agreeTermsAndConditions(handleResponse: HandleResponse<AgreeTermAndConditionResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.agreeTermsAndConditions(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to store pocket money
     */
    fun storePocketMoney(money: Double, handleResponse: HandleResponse<SimpleResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.storePocketMoney(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, money)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    fun sendSystemMessage(message: SystemMessageReq, handleResponse: HandleResponse<SystemMessage>){
        setIsLoading(true)
        compositeDisposable.add(APIManager.sendSystemMessage(message)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessResponse(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            )
        )
    }


    // Get List of tokens which my device logged in
    fun getTokenList(handleResponse: HandleResponse<ActiveDeviceTokenResponse>){
        compositeDisposable.addAll(APIManager.getActiveDeviceTokenList()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessResponse(result)
                    }
                }
            ) { x ->
                run {
                    setIsLoading(false)
                    handleResponse.handleErrorResponse(getThrowableError(x))
                }
            })
    }

    // Get token of socket server
    fun getSocketToken(handleResponse: HandleResponse<SocketTokenResponse>) {
        compositeDisposable.addAll(APIManager.getSocketToken()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessResponse(result)
                    }
                }
            ) { x ->
                run {
                    setIsLoading(false)
                    handleResponse.handleErrorResponse(getThrowableError(x))
                }
            })
    }
}