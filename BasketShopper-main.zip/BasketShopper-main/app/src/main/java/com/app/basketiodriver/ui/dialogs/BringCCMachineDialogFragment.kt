package com.app.basketiodriver.ui.dialogs

import android.os.Bundle
import android.view.View
import androidx.fragment.app.FragmentManager
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentBringCcMachineBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseDialogFragment
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel

class BringCCMachineDialogFragment : BaseDialogFragment<FragmentBringCcMachineBinding?, OrderDetailsViewModel>(),
    Injectable {

    override val layoutId: Int
        get() = R.layout.fragment_bring_cc_machine

    override val viewModel: OrderDetailsViewModel
        get() {
            return getViewModel(baseActivity, OrderDetailsViewModel::class.java)
        }

    var listener : ContinueOrderListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    // Set Full screen
    override fun getTheme(): Int {
        return R.style.MyDialogWhite
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initToolbar()

        viewDataBinding!!.btnContinue.setOnClickListener {
            dismissAllowingStateLoss()

            if (listener != null){
                listener!!.onContinueOrder()
            }
        }
    }

    private fun initToolbar(){
        viewDataBinding!!.layoutToolBar.toolBarTitle.setText(R.string.payment_method)
        viewDataBinding!!.layoutToolBar.btnBack.setOnClickListener {
            dismissAllowingStateLoss()
        }
    }

    override fun show(manager: FragmentManager, tag: String?) {
        try {
            val ft = manager.beginTransaction()
            ft.add(this, tag)
            ft.commitAllowingStateLoss()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    companion object{
        fun newInstance() : BringCCMachineDialogFragment {
            val fragment = BringCCMachineDialogFragment()

            return fragment
        }
    }

    /**
     * ContinueOrderListener
     */
    interface ContinueOrderListener {
        fun onContinueOrder()
    }
}