package com.app.basketiodriver.ui.checkout.adapter

import android.os.Build
import android.text.Html
import android.text.Spanned
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.model.api.response.checkout.OrdersReplacementItem
import com.app.basketiodriver.databinding.ItemReplacementListBinding
import com.app.basketiodriver.utils.BaseRecyclerViewAdapter
import com.app.basketiodriver.utils.GlideApp
import com.app.basketiodriver.utils.price.PriceConstructor
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.*

class ReplacementItemListAdapter (val activity : FragmentActivity, val listItem : List<OrdersReplacementItem>, private val orderItem : OrdersItem)
    : BaseRecyclerViewAdapter<OrdersReplacementItem, ItemReplacementListBinding>()  {

    override val layoutId: Int
        get() = R.layout.item_replacement_list

    var symbols: DecimalFormatSymbols = DecimalFormatSymbols(Locale.US)
    var formatter: DecimalFormat = DecimalFormat("#.## x ", symbols)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return ReplacementItemViewHolder(createBindView(parent))
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val holder = holder as ReplacementItemViewHolder
        val item = listItem[position]

        // Price
        val price = PriceConstructor.getFormatReplacementItemPrice(item, PriceConstructor.LabelType.SIMPLE, PreferenceManager.currency)

        if (position == itemCount - 1) {
            holder.binding.bottomLines.visibility = View.GONE
        }
        else{
            holder.binding.bottomLines.visibility = View.VISIBLE
        }

        // Item Title
        holder.binding.orderItemTitle.text = item.productName

        // Customer note
        if (item.notes != null && item.notes.isNotEmpty()){
            holder.binding.ivInfo.visibility = View.VISIBLE
        }
        else{
            holder.binding.ivInfo.visibility = View.GONE
        }

        // Product Quantity
        if (item.quantityDifference == 1){
            holder.binding.txtQuantity.text = formatter.format(item.actualQty)
        }
        else if (item.replacementRequested == 1){
            if (orderItem.itemStatus == 2) {
                holder.binding.txtQuantity.text = formatter.format(item.actualQty)
            }
            else{
                holder.binding.txtQuantity.text = formatter.format(item.itemQty ?: 1)
            }
        }
        else{
            holder.binding.txtQuantity.text = formatter.format(item.itemQty ?: 1)
        }

        // Price
        holder.binding.tvOrderCost.text = getHtmlString(price)

        // Description
        if (orderItem.getDescriptionLabel().isEmpty()){
            holder.binding.tvPriceDescription.visibility = View.GONE
        }
        else{
            holder.binding.tvPriceDescription.visibility = View.VISIBLE
            holder.binding.tvPriceDescription.text = item.getDescriptionLabel()
        }

        // Item Image
        if (item.productImage != null) {
            GlideApp.with(activity).load(item.productImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(holder.binding.ivOrderItem)
        }

//        holder.binding.orderItemLayout.tag = position
    }

    override fun getItemCount(): Int {
        return listItem.size
    }

    private fun getHtmlString(str : String) : Spanned {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            // FROM_HTML_MODE_LEGACY is the behaviour that was used for versions below android N
            // we are using this flag to give a consistent behaviour
            return Html.fromHtml(str, Html.FROM_HTML_MODE_LEGACY)
        } else {
            return Html.fromHtml(str)
        }
    }

    inner class ReplacementItemViewHolder(val binding: ItemReplacementListBinding) :
        RecyclerView.ViewHolder(binding.root)
}