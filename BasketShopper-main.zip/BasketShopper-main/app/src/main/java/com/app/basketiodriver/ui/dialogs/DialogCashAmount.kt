package com.app.basketiodriver.ui.dialogs

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.TextView
import androidx.databinding.DataBindingUtil
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.databinding.DialogAddCashAmountBinding
import com.app.basketiodriver.utils.PopupUtils


class DialogCashAmount {
    var tvErrorMessage: TextView? = null
    var dialog: Dialog? = null

    fun openDialog(
        context: Context, ableToCancel : Boolean, addCashAmount: (promo: String) -> Unit
    ) {
        dialog = Dialog(context)
        val binding: DialogAddCashAmountBinding = DataBindingUtil.inflate(
            LayoutInflater.from(context),
            R.layout.dialog_add_cash_amount,
            null,
            false
        )

        dialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog?.setContentView(binding.root)
        dialog?.setCancelable(false)
        dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog?.window?.setGravity(Gravity.CENTER)
        dialog?.setOnKeyListener { dialog, keyCode, event -> // Prevent dialog close on back press button
            keyCode == KeyEvent.KEYCODE_BACK
        }

        // Currency
        binding.txtJd.text = PreferenceManager.currency

        tvErrorMessage = binding.tvError
        var cashAmount = ""

        //Enable or disable 'Redeem' button base on promo code content
        binding.edtAmount.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                cashAmount = binding.edtAmount.text.toString().trim()
                if (cashAmount.isEmpty()) {

                } else {
                    // Hide error message
                    tvErrorMessage?.text = null
                }
            }

            override fun afterTextChanged(s: Editable) {}
        })

        binding.ivClose.visibility = if (ableToCancel) View.VISIBLE else View.INVISIBLE

        // Close
        binding.ivClose.setOnClickListener {
            isOpened = false
            dialog?.dismiss()
        }

        // Submit
        binding.btnSubmit.setOnClickListener {
            addCashAmount(cashAmount)
        }

        PopupUtils.setDefaultDialogProperty(dialog!!)

        dialog?.show()
        isOpened = true
    }


    fun dismissDialog(){
        if (dialog != null){
            dialog!!.dismiss()
            isOpened = false
        }
    }

    fun setErrorText(errorText: String){
        if (dialog != null && tvErrorMessage != null) {
            tvErrorMessage?.text = errorText
            tvErrorMessage?.visibility = View.VISIBLE
        }
    }

    companion object {
        var isOpened : Boolean = false
        private var instance: DialogCashAmount? = null
        private val Instance: DialogCashAmount
            get() {
                if (instance == null) {
                    instance = DialogCashAmount()
                }
                return instance!!
            }

        fun openDialog(
            context: Context, isCancel : Boolean, addAmount: (amount: String) -> Unit
        ) {
            Instance.openDialog(context, isCancel, addAmount)
        }

        fun dismissDialog(){
            Instance.dismissDialog()
        }

        fun setErrorMessage(errorText: String){
            Instance.setErrorText(errorText)
        }
    }
}