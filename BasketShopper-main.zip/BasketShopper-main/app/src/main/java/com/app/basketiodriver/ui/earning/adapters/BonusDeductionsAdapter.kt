package com.app.basketiodriver.ui.earning.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.earning.bonus.BonusDeductionsData
import com.app.basketiodriver.data.model.api.response.earning.payout.PayoutCreditData
import com.app.basketiodriver.databinding.ItemBonusDeductionsBinding
import com.app.basketiodriver.databinding.ItemPayoutCreditBinding
import com.app.basketiodriver.ui.base.DataListAdapter
import com.app.basketiodriver.ui.base.DataViewHolder
import com.app.basketiodriver.utils.CommonUtils
import com.app.basketiodriver.utils.DateUtils
import com.app.basketiodriver.utils.OnItemClickedListener
import java.util.*

class BonusDeductionsAdapter (val mContext : Context, val listener: OnItemClickedListener<BonusDeductionsData>) :
    DataListAdapter<BonusDeductionsData, ItemBonusDeductionsBinding>() {
    override fun createBinding(inflater: LayoutInflater, parent: ViewGroup? ): ItemBonusDeductionsBinding {
        return DataBindingUtil.inflate(inflater, R.layout.item_bonus_deductions, parent, false)
    }

    override fun onBindViewHolder(holder: DataViewHolder<ItemBonusDeductionsBinding>, position: Int) {
        super.onBindViewHolder(holder, position)
        holder.binding.root.setOnClickListener { listener.onClicked(holder.binding.bonusItem!!) }
    }

    override fun bind(binding: ItemBonusDeductionsBinding?, item: BonusDeductionsData) {
        binding!!.bonusItem = item

        binding.txtPayMethod.text = item.comments
        binding.txtPayStatus.text = item.status

        if (item.created_on != null && item.created_on != "")
            binding.txtDate.text = DateUtils.getMMDDDate(item.created_on)

        binding.txtPayValue.text = String.format(Locale("en"), "%s %s", PreferenceManager.currency, item.amount)
        if (item.type != null) {
            if (item.type!!.equals("Bonus", true)) {
                binding.txtPayValue.setTextColor(mContext.resources.getColor(R.color.colorPrimary))
            }
            else{
                binding.txtPayValue.setTextColor(mContext.resources.getColor(R.color.item_not_found_color))
            }
        }
    }
}