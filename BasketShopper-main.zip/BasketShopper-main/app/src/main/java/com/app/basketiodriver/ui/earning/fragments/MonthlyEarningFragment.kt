package com.app.basketiodriver.ui.earning.fragments

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.FragmentActivity
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.earning.monthly.MonthlySummaryItem
import com.app.basketiodriver.data.model.api.response.earning.monthly.ShopperMonthlySummaryResponse
import com.app.basketiodriver.databinding.FragmentMonthlyEarningBinding
import com.app.basketiodriver.databinding.FragmentSummaryBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.earning.EarningViewModel
import com.app.basketiodriver.ui.earning.fragments.MonthlyEarningFragmentArgs.fromBundle
import com.app.basketiodriver.utils.CommonUtils
import com.app.basketiodriver.utils.InfoHelp
import java.util.*

class MonthlyEarningFragment : BaseFragment<FragmentMonthlyEarningBinding?, EarningViewModel>(),
    Injectable {
    override val layoutId: Int
        get() = R.layout.fragment_monthly_earning

    override val viewModel: EarningViewModel
        get() {
            return getViewModel(baseActivity as FragmentActivity, EarningViewModel::class.java)
        }


    // Yearly Balance Report
    val yearReportItem by lazy {
        fromBundle(arguments!!).yearReportItem
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setTitle(getString(R.string.annual_earnings))

        // Initialize the UI
        initUI()
    }

    private fun initUI(){
        // Set the title
        initToolBar()

        // Set the tooltips
        setTooltips()

        // get monthly report
        shopperMonthlyBalanceReport()

        // Go to Earnings Detail
        viewDataBinding!!.earningsLL.setOnClickListener {
            navigate(MonthlyEarningFragmentDirections.actionMonthlyEarningFragmentToMonthlyEarningDetailFragment(yearReportItem))
        }

        // Go to Payment Detail
        viewDataBinding!!.paymentLL.setOnClickListener {
           navigate(MonthlyEarningFragmentDirections.actionMonthlyEarningFragmentToEarningsCreditFragment(yearReportItem, "Payout"))
        }

        // Go to Credit Detail
        viewDataBinding!!.creditLL.setOnClickListener {
            navigate(MonthlyEarningFragmentDirections.actionMonthlyEarningFragmentToEarningsCreditFragment(yearReportItem, "Credit"))
        }
    }

    private fun initToolBar(){
        val monthTitle = yearReportItem.monthName ?: ""
        val year : Int = if (yearReportItem != null) yearReportItem.year.toInt() else Calendar.getInstance().get(Calendar.YEAR)
        val title = monthTitle + " " + year
        setTitle(title)
    }

    // Set tooltip
    private fun setTooltips(){
        viewDataBinding!!.txtLsMonthBalance.setOnClickListener{
            InfoHelp.showHelpDialog(it, baseActivity?.resources?.getString(R.string.your_last_month_balance)!!, baseActivity as Activity, false)
        }

        viewDataBinding!!.txtEarningLabel.setOnClickListener{
            InfoHelp.showHelpDialog(it, baseActivity?.resources?.getString(R.string.total_earnings_this_month)!!, baseActivity as Activity, false)
        }

        viewDataBinding!!.txtCollectedLabel.setOnClickListener{
            InfoHelp.showHelpDialog(it, baseActivity?.resources?.getString(R.string.total_amount_collected_from_customers)!!, baseActivity as Activity, false)
        }

        viewDataBinding!!.paymentLabel.setOnClickListener{
            InfoHelp.showHelpDialog(it, baseActivity?.resources?.getString(R.string.total_payment_and_credit)!!, baseActivity as Activity, false)
        }

        viewDataBinding!!.creditLabel.setOnClickListener{
            InfoHelp.showHelpDialog(it, baseActivity?.resources?.getString(R.string.total_credit_this_month)!!, baseActivity as Activity, false)
        }

        viewDataBinding!!.txtMonthBalanceLabel.setOnClickListener{
            InfoHelp.showHelpDialog(it, baseActivity?.resources?.getString(R.string.your_total_balance_end_of_month)!!, baseActivity as Activity, false)
        }

        viewDataBinding!!.currentBalanceLabel.setOnClickListener{
            InfoHelp.showHelpDialog(it, baseActivity?.resources?.getString(R.string.your_current_balance)!!, baseActivity as Activity, true)
        }
    }

    // Update UI
    private fun updateUI(monthlyData : MonthlySummaryItem){
        if (monthlyData.isAccountSuspended) {
            viewDataBinding!!.suspendedLL.visibility = View.VISIBLE
        }
        else{
            viewDataBinding!!.suspendedLL.visibility = View.GONE
        }

        // Current Balance
        val currBalance = PreferenceManager.currency + " " + monthlyData.currentAccountBalance
        viewDataBinding!!.currentBalancedTV.text = currBalance
        CommonUtils.setBalanceTextColor(viewDataBinding!!.currentBalancedTV, "" + monthlyData.currentAccountBalance)

        // Last Month Balance
        val lastMonthBalance = PreferenceManager.currency + " " + monthlyData.previousMonthBalance
        viewDataBinding!!.lastMonthBalanceTV.text = lastMonthBalance
        CommonUtils.setBalanceTextColor(viewDataBinding!!.lastMonthBalanceTV, "" + monthlyData.previousMonthBalance)

        // Earnings
        val earnings = PreferenceManager.currency + " " + monthlyData.totalMonthEarnings
        viewDataBinding!!.earningsTV.text = earnings
        CommonUtils.setBalanceTextColor(viewDataBinding!!.earningsTV, "" + monthlyData.totalMonthEarnings)

        // Collected
        val collected = PreferenceManager.currency + " " + monthlyData.totalMonthCollected
        viewDataBinding!!.collectedTV.text = collected
        CommonUtils.setBalanceTextColor(viewDataBinding!!.collectedTV, "" + monthlyData.totalMonthCollected)

        // Payment
        val payment = PreferenceManager.currency + " " + monthlyData.total_month_payout
        viewDataBinding!!.paymentTV.text = payment
        CommonUtils.setBalanceTextColor(viewDataBinding!!.paymentTV, "" + monthlyData.total_month_payout)

        // Credit
        val credit = PreferenceManager.currency + " " + monthlyData.total_month_credits
        viewDataBinding!!.creditTV.text = credit
        CommonUtils.setBalanceTextColor(viewDataBinding!!.creditTV, "" + monthlyData.total_month_credits)

        // End of Month Balance
        val endBalance = PreferenceManager.currency + " " + monthlyData.totalEndOfMonthBalance
        viewDataBinding!!.endOfMonthBalanced.text = endBalance
        CommonUtils.setBalanceTextColor(viewDataBinding!!.endOfMonthBalanced, "" + monthlyData.totalEndOfMonthBalance)

    }

    // Get Monthly Report
    private fun shopperMonthlyBalanceReport(){
        val month : Int = if (yearReportItem != null) yearReportItem.monthNumber else Calendar.getInstance().get(Calendar.MONTH)
        val year : Int = if (yearReportItem != null) yearReportItem.year.toInt() else Calendar.getInstance().get(Calendar.YEAR)

        viewModel.getMonthlyBalanceReport(month, year, object:HandleResponse<ShopperMonthlySummaryResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Toast.makeText(baseActivity, error?.message, Toast.LENGTH_SHORT).show()
                }else{
                    Toast.makeText(baseActivity, baseActivity?.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }
            }

            override fun handleSuccessResponse(successResponse: ShopperMonthlySummaryResponse) {
                if (successResponse.data != null){
                    try {
                        updateUI(successResponse.data!!)
                    }
                    catch (e : Exception){
                        e.printStackTrace()
                    }
                }
                else{
                    Toast.makeText(baseActivity, successResponse.message, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }
}