package com.app.basketiodriver.ui.base


/**
Created by ibraheem lubbad on 2020-01-07.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
interface BaseNavigator {

    fun handleError(error: String)
    fun handleSuccess(success: String)
    fun gotToNext()
}