package com.app.basketiodriver.ui.howdoing.fragments


import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.widget.Switch
import android.widget.Toast
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.howamidoing.HowAmIDoingDetail
import com.app.basketiodriver.data.model.api.response.howamidoing.HowAmIDoingResponse
import com.app.basketiodriver.databinding.FragmentHomeHowDoingBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.howdoing.HowIamDoingViewModel

/**
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class HomeHowDoingFragment : BaseFragment<FragmentHomeHowDoingBinding?, HowIamDoingViewModel>(),
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_home_how_doing

    override val viewModel: HowIamDoingViewModel
        get() {
            return getViewModel(requireActivity(), HowIamDoingViewModel::class.java)
        }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.how_i_am_doing))

        getHowAmIDoingDetails()

        // View Details
        viewDataBinding!!.txtViewDetail.setOnClickListener {
            navigate(HomeHowDoingFragmentDirections.actionHomeHowDoingFragmentToReliabilityIncidentFragment())
        }

        // View Rating Details
        viewDataBinding!!.txtViewRatingDetail.setOnClickListener {
            navigate(HomeHowDoingFragmentDirections.actionHomeHowDoingFragmentToRatingsFragment())
        }
    }

    private fun getHowAmIDoingDetails(){
        viewModel.getHowAmIDoing(object : HandleResponse<HowAmIDoingResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Toast.makeText(baseActivity, error?.message, Toast.LENGTH_SHORT).show()
                }
                else{
                    Toast.makeText(baseActivity, baseActivity?.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_SHORT).show()
                }
            }

            override fun handleSuccessResponse(successResponse: HowAmIDoingResponse) {
                val data = successResponse.data
                if (data != null){
                    updateUI(data)
                }
                else{
                    Toast.makeText(baseActivity, successResponse.message, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    // Update the UI
    @SuppressLint("UseCompatLoadingForDrawables")
    private fun updateUI(data : HowAmIDoingDetail){
        if (data.averageRating != null){
            viewDataBinding!!.txtRatingText.text = data.averageRating.rating_text
            viewDataBinding!!.txtRating.text = data.averageRating.rating
        }

        if (data.reliabilityIncident != null){
            viewDataBinding!!.txtReason.text = data.reliabilityIncident.incident_text

            when (data.reliabilityIncident.incident) {
                0 -> {

                }
                1 -> {
                    viewDataBinding!!.txt1.background = baseActivity!!.resources.getDrawable(R.drawable.ri_1incident)
                }
                2 -> {
                    viewDataBinding!!.txt1.background = baseActivity!!.resources.getDrawable(R.drawable.ri_1incident_yellow)
                    viewDataBinding!!.txt2.background = baseActivity!!.resources.getDrawable(R.drawable.ri_2incident_yellow)
                }
                3 -> {
                    viewDataBinding!!.txt1.background = baseActivity!!.resources.getDrawable(R.drawable.ri_1incident_yellow)
                    viewDataBinding!!.txt2.background = baseActivity!!.resources.getDrawable(R.drawable.ri_2incident_yellow)
                    viewDataBinding!!.txt3.background = baseActivity!!.resources.getDrawable(R.drawable.ri_2incident_yellow)
                }
                4 -> {
                    viewDataBinding!!.txt2.background = baseActivity!!.resources.getDrawable(R.drawable.ri_2incident_yellow)
                    viewDataBinding!!.txt3.background = baseActivity!!.resources.getDrawable(R.drawable.ri_2incident_yellow)
                    viewDataBinding!!.txt4.background = baseActivity!!.resources.getDrawable(R.drawable.ri_2incident_yellow)
                }
                else -> {
                    viewDataBinding!!.txt1.background = baseActivity!!.resources.getDrawable(R.drawable.ri_1incident_red)
                    viewDataBinding!!.txt2.background = baseActivity!!.resources.getDrawable(R.drawable.ri_2incident_red)
                    viewDataBinding!!.txt3.background = baseActivity!!.resources.getDrawable(R.drawable.ri_2incident_red)
                    viewDataBinding!!.txt4.background = baseActivity!!.resources.getDrawable(R.drawable.ri_2incident_red)
                    viewDataBinding!!.txt5.background = baseActivity!!.resources.getDrawable(R.drawable.ri_2incident_red)

                    // Show the Suspend message
                    Toast.makeText(baseActivity, baseActivity?.resources?.getString(R.string.ri_suspend_message), Toast.LENGTH_SHORT).show()
                }
            }
        }

    }

}
