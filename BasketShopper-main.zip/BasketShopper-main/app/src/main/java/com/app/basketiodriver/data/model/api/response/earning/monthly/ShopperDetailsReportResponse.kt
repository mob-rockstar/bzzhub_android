package com.app.basketiodriver.data.model.api.response.earning.monthly
import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
class ShopperDetailsReportResponse : Parcelable {
    @SerializedName("data")
    val data: ShopperDetailsReportData? = null

    @SerializedName("message")
    val message: String? = null
}