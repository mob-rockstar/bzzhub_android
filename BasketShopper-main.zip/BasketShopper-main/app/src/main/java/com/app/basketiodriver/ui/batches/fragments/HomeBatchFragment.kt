package com.app.basketiodriver.ui.batches.fragments

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentHomeBatchBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.home.HomeViewModel

/**
 * A simple [Fragment] subclass.
 */
class HomeBatchFragment
    : BaseFragment<FragmentHomeBatchBinding?, HomeViewModel>(),
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_home_batch

    override val viewModel: HomeViewModel
        get() {
            return getViewModel(requireActivity(), HomeViewModel::class.java)
        }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewDataBinding?.slideView?.setOnSlideCompleteListener {
            navigate(
                HomeBatchFragmentDirections.actionHomeBatchFragmentToArrivedAtTheStoreFragment()
            )
        }

        viewDataBinding?.btnBack?.setOnClickListener { activity?.finish() }

    }

}




