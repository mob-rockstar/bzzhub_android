package com.app.basketiodriver.ui.cardcamera.camera

import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Camera

object CameraUtils {
    var camera: Camera? = null
        private set

    fun hasCamera(context: Context): Boolean {
        return context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA)
    }

    fun openCamera(): Camera? {
        camera = null
        try {
            camera = Camera.open() // attempt to get a Camera instance
        } catch (e: Exception) { // Camera is not available (in use or does not exist)
        }
        return camera // returns null if camera is unavailable
    }

    fun hasFlash(context: Context): Boolean {
        return context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)
    }
}