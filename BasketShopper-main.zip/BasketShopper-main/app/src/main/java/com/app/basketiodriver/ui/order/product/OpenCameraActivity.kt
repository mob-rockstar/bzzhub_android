package com.app.basketiodriver.ui.order.product

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.widget.Toast
import androidx.core.content.FileProvider
import com.app.basketiodriver.BuildConfig
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.model.api.response.order.SimilarProduct
import com.app.basketiodriver.data.model.api.response.order.SimpleDataResponse
import com.app.basketiodriver.databinding.ActivityOpenCameraBinding
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.app.basketiodriver.utils.GlideApp
import com.app.basketiodriver.utils.price.PriceConstructor
import com.app.basketiodriver.utils.price.PriceConstructorNew
import com.tbruyelle.rxpermissions2.RxPermissions
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

/**
 * Item Not Found page
 * Take a photo manually
 */

class OpenCameraActivity : BaseActivity<ActivityOpenCameraBinding, OrderDetailsViewModel>(){
    override val layoutId: Int
        get() = R.layout.activity_open_camera

    override val viewModel: OrderDetailsViewModel
        get() {
            return getViewModel(OrderDetailsViewModel::class.java)
        }

//    @Inject
//    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Fragment>
//    override fun supportFragmentInjector() = dispatchingAndroidInjector

    // Properties
    var orderId : Long = 0
    var oldItemId : Long = 0
    var barcode : String = ""

    var ordersItem : OrdersItem? = null
    var similarProduct : SimilarProduct?= null

    var isCameraOpen : Boolean = false

    var photoFile : File? = null

    var mCurrentPhotoPath : String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (intent.extras != null){
            // get order id
            if (intent.hasExtra("ARG_ORDER_ID"))
                orderId = intent.extras!!.getLong("ARG_ORDER_ID", 0)

            // similar product
            if (intent.hasExtra("ARG_SIMILAR_ITEM"))
                similarProduct = intent.extras!!.getSerializable("ARG_SIMILAR_ITEM") as? SimilarProduct

            // order item
            if (intent.hasExtra("ARG_ORDER_ITEM"))
                ordersItem = intent.extras!!.getSerializable("ARG_ORDER_ITEM") as? OrdersItem

            // old order id
            if (intent.hasExtra("ARG_OLD_ITEM_ID"))
                oldItemId = intent.extras!!.getLong("ARG_OLD_ITEM_ID", 0)

            // barcode
            if (intent.hasExtra("ARG_BAR_CODE"))
                barcode = intent.extras!!.getString("ARG_BAR_CODE", "")
        }

        // Init toolbar
        initToolBar()

        viewDataBinding!!.imgTakenPic.clipToOutline = true

        // Set the ClickListener
        setListeners()

        if (ordersItem != null){
            setItem()
        }
        else if (similarProduct != null){ // For replacement
            setSimilarItem()
        }
    }

    private fun initToolBar(){
        initToolbar(getString(R.string.item_not_found),
            true, viewDataBinding!!.layoutToolBar.toolbar,
            View.OnClickListener {
                run {
                    finish()
                }
            })
    }

    @SuppressLint("CheckResult")
    private fun setListeners(){
        // Capture Image
        viewDataBinding!!.btnCaptureImage.setOnClickListener {
            captureImage()
        }

        // Retake
        viewDataBinding!!.btnRetake.setOnClickListener {
            if (!isCameraOpen) {
                isCameraOpen = true

                val permissions = RxPermissions(this)
                permissions.request(Manifest.permission.CAMERA)
                    .subscribe { granted: Boolean ->
                        if (granted) {
                            createCameraIntent()
                        }
                    }
            }
        }

        // Use photo
        viewDataBinding!!.btnUsePhoto.setOnClickListener {
            usePhotoAsFound()
        }
    }

    private fun setItem(){
        if (ordersItem!!.productImage != null){
            GlideApp.with(this).load(ordersItem!!.productImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(viewDataBinding!!.productLayout.orderItemImage)
        }

        // Name
        viewDataBinding!!.productLayout.txtTitle.text = ordersItem!!.productName!!.replace("\n", "").replace("\r", "")

        // Description
        if (ordersItem!!.getDescriptionLabel() == ""){
            viewDataBinding!!.productLayout.tvPriceDescription.visibility = View.GONE
        }
        else{
            viewDataBinding!!.productLayout.tvPriceDescription.visibility = View.VISIBLE
            viewDataBinding!!.productLayout.tvPriceDescription.text = ordersItem!!.getDescriptionLabelNew()
        }

        viewDataBinding!!.productLayout.txtPricePerUnit.text = PriceConstructorNew.getFormatPrice(ordersItem!!, PriceConstructor.LabelType.SIMPLE, true)
    }

    private fun setSimilarItem(){
        if (similarProduct!!.productImage != null){
            GlideApp.with(this).load(similarProduct!!.productImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(viewDataBinding!!.productLayout.orderItemImage)
        }

        // Name
        viewDataBinding!!.productLayout.txtTitle.text = similarProduct!!.productName!!.replace("\n", "").replace("\r", "")

        // Description
        if (similarProduct!!.getDescriptionLabel() == ""){
            viewDataBinding!!.productLayout.tvPriceDescription.visibility = View.GONE
        }
        else{
            viewDataBinding!!.productLayout.tvPriceDescription.visibility = View.VISIBLE
            viewDataBinding!!.productLayout.tvPriceDescription.text = similarProduct!!.getDescriptionLabelNew()
        }

        viewDataBinding!!.productLayout.txtPricePerUnit.text = PriceConstructorNew.getFormatPrice(similarProduct!!, PriceConstructor.LabelType.SIMPLE)
    }

    // Capture image
    @SuppressLint("MissingPermission", "CheckResult")
    private fun captureImage(){
        if (!isCameraOpen) {
            isCameraOpen = true

            val permissions = RxPermissions(this)
            permissions.request(Manifest.permission.CAMERA)
                .subscribe { granted: Boolean ->
                    if (granted) {
                        createCameraIntent()
                    }
                }
        }
    }

    // Retake the picture
    private fun createCameraIntent(){
        val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (takePictureIntent.resolveActivity(packageManager) != null) {
            photoFile = null
            try {
                photoFile = createImageFile()
                val photoURI: Uri = FileProvider.getUriForFile(
                    this,
                    """${BuildConfig.APPLICATION_ID}.photopicker.fileprovider""",
                    photoFile!!
                )
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                startActivityForResult(takePictureIntent, REQUEST_TAKE_PHOTO)
            } catch (ex: IOException) {
                println("Error: " + ex.message)
            }
        }
    }

    @Throws(IOException::class)
    private fun createImageFile(): File? {
        val timeStamp: String =  SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ENGLISH).format(Date())
        val imageFileName = "JPEG_" + timeStamp + "_"
        val storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        val image = File.createTempFile(imageFileName, ".jpg", storageDir)
        mCurrentPhotoPath = image.absolutePath
        return image
    }

    // Use the photo as item image
    private fun usePhotoAsFound(){
        if (photoFile != null) {
            if (ordersItem != null) {
                if (barcode == "" && ordersItem!!.barCode != null)
                    barcode = ordersItem!!.barCode
                addForceMarkAsFound(orderId, barcode, ordersItem!!.ordersOutletsItemsId ?: 0, photoFile!!)
            }
            else if (similarProduct != null) {
                if (barcode == "" && similarProduct!!.barCode != null)
                    barcode = similarProduct!!.barCode!!
                addForceMarkAsFound(orderId, barcode, oldItemId, photoFile!!)
            }
        }
    }

    private fun addForceMarkAsFound(orderId : Long, barcode : String, orgItemId : Long, file : File){
        viewModel.addForceMarkAsFound(orderId, orgItemId, barcode, file, object : HandleResponse<SimpleDataResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                Toast.makeText(this@OpenCameraActivity, error?.message, Toast.LENGTH_SHORT).show()
            }

            override fun handleSuccessResponse(successResponse: SimpleDataResponse) {
                Toast.makeText(this@OpenCameraActivity, successResponse.message, Toast.LENGTH_SHORT).show()
                if (successResponse.httpCode == 200){
                    if (photoFile != null)
                        photoFile!!.deleteOnExit()

                    setResult(Activity.RESULT_OK)
                    finish()
                }
            }
        })
    }

    // Compress the photo
    private fun compressPhoto(){
        val file = File(mCurrentPhotoPath)
        var options = BitmapFactory.Options()
        options.inJustDecodeBounds = true
        BitmapFactory.decodeFile(file.absolutePath, options)
        val k = Math.min(options.outHeight, options.outWidth) / 720
        options = BitmapFactory.Options()
        if (k > 1) options.inSampleSize = k

        val matrix = Matrix()
        matrix.postRotate(90f)

        val out = BitmapFactory.decodeFile(file.absolutePath, options)
        val rotatedBitmap =
            Bitmap.createBitmap(out, 0, 0, out.width, out.height, matrix, true)
        val stream = FileOutputStream(file.absolutePath)

        rotatedBitmap.compress(Bitmap.CompressFormat.JPEG, 50, stream)
    }

    // Set the captured image
    private fun setBitmapToView(){
        GlideApp.with(this).load(File(mCurrentPhotoPath))
            .placeholder(R.drawable.placeholder)
            .error(R.drawable.placeholder).into(viewDataBinding!!.imgTakenPic)
    }

    // Show the taken photo
    private fun uploadPhoto(){
        viewDataBinding!!.rlPhotoCaptured.visibility = View.VISIBLE
    }

    // Show the error dialog
    private fun showErrorDialog(e: Exception) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.error))
            .setMessage(e.message + "\r\n" + getString(R.string.try_again))
            .setPositiveButton(getString(R.string.okay)) { _, _ ->
                //do things

            }
            .create().show()
    }

    /**
     * OnActivityResult
     */
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        isCameraOpen = false

        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_TAKE_PHOTO){
                try {
                    if (mCurrentPhotoPath == null && mCurrentPhotoPath == ""){
                        showErrorDialog(Exception(getString(R.string.file_not_found)))
                        return
                    }

                    compressPhoto()
                    setBitmapToView()
                    uploadPhoto()
                }
                catch (e : Exception){
                    showErrorDialog(e)
                }

            }
        }
    }

    override fun onResume() {
        super.onResume()

        isCameraOpen = false
    }

    override fun onStart() {
        super.onStart()

        isCameraOpen = false
    }

    companion object{
        const val REQUEST_TAKE_PHOTO = 1
    }

}
