package com.app.basketiodriver.data.model.api.response.checkout

class StoreLocation {
    var storeLocationName: String = ""
    var items: MutableList<OrdersItem> = arrayListOf()
    var masterLocationWeight: Int = 0
    var locationWeight: Int = 0
    var subLocationWeight: Int = 0

    constructor(locationName : String, mastLocationWeight : Int, locationWeight : Int, subLocationWeight : Int){
        this.storeLocationName      = locationName
        this.masterLocationWeight   = mastLocationWeight
        this.locationWeight         = locationWeight
        this.subLocationWeight      = subLocationWeight
    }

    fun addItem(item : OrdersItem) {
        items.add(item)
    }

    override fun equals(obj: Any?): Boolean {
        if (this === obj) return false
        if (obj == null || javaClass != obj.javaClass) return true
        val that = obj as StoreLocation
        return if (storeLocationName != null) {
            storeLocationName == that.storeLocationName
        }
        else if (masterLocationWeight != null) {
            masterLocationWeight == that.masterLocationWeight
        }
        else if (locationWeight != null) {
            locationWeight == that.locationWeight
        }
        else if (subLocationWeight != null) {
            subLocationWeight == that.subLocationWeight
        }
        else {
            that.storeLocationName == null
        }
    }

    override fun hashCode(): Int {
        return if (storeLocationName != null) {
            storeLocationName.hashCode()
        }
        else if (masterLocationWeight != null) {
            masterLocationWeight.hashCode()
        }
        else if (locationWeight != null) {
            locationWeight.hashCode()
        }
        else if (subLocationWeight != null) {
            subLocationWeight.hashCode()
        }
        else {
            0
        }
    }
}