package com.app.basketiodriver.data.model.api.response.order

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName

class SuggestionResponse {
    @SerializedName("status")
    @Expose
    val httpCode: Int? = null

    @SerializedName("message")
    @Expose
    val message: String = ""

    @SerializedName("data")
    @Expose
    val similarProducts: List<SimilarProduct>? = null
}