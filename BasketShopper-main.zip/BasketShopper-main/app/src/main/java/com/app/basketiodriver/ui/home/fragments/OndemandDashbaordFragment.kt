package com.app.basketiodriver.ui.home.fragments

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import com.app.basketiodriver.R
import com.app.basketiodriver.ShopperApp
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.BookingSlotsResponse
import com.app.basketiodriver.data.model.api.response.ShopperBookingSlots
import com.app.basketiodriver.data.model.api.response.dashboard.Order
import com.app.basketiodriver.data.model.api.response.dashboard.OrderResponse
import com.app.basketiodriver.data.model.api.response.general.SimpleResponse
import com.app.basketiodriver.data.model.api.response.settings.SettingsResponse
import com.app.basketiodriver.data.model.api.response.shopper.ShopperData
import com.app.basketiodriver.data.model.api.response.shopper.ShopperResponse
import com.app.basketiodriver.data.remote.socket.SocketManager
import com.app.basketiodriver.databinding.FragmentOndemandDashbaordBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.dashbaord.IncomingFragment
import com.app.basketiodriver.ui.dashbaord.OrdersManager
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_ORDER_FINISHED
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_SLIDE_ACKNOWLEDGE_ORDER
import com.app.basketiodriver.ui.dialogs.CheckoutInstructionsDialogFragment
import com.app.basketiodriver.ui.dialogs.TermsAndConditionDialogFragment
import com.app.basketiodriver.ui.home.HomeActivity
import com.app.basketiodriver.ui.home.HomeViewModel
import com.app.basketiodriver.ui.utils.ViewPagerAdapter
import com.app.basketiodriver.utils.*
import com.google.android.material.tabs.TabLayout
//import kotlinx.android.synthetic.main.app_bar_with_support.view.*
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import timber.log.Timber
import java.util.*
import javax.inject.Inject


/**
 * A simple [Fragment] subclass.
 */
class OndemandDashbaordFragment : BaseFragment<FragmentOndemandDashbaordBinding?, HomeViewModel>(),
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_ondemand_dashbaord

    override val viewModel: HomeViewModel
        get() {
            return getViewModel(baseActivity as FragmentActivity, HomeViewModel::class.java)
        }

    companion object {

        fun newInstance(
        ): IncomingFragment {
            val fragment = IncomingFragment()

            return fragment
        }
    }

    var orders : ArrayList<Order> = arrayListOf()

    @Inject
    lateinit var socketManager: SocketManager

    private var ifFromEarlyDialog = false
    private var isFirstLoading = true


    lateinit var orderTypeAdapter : ViewPagerAdapter
    lateinit var orderManager : OrdersManager

    private var loading = false
    private var lastPage = false

    private val ITEMS_COUNT = 20
    private var currentPage = 1

    var todayFirstShiftTime : String? = null

    var termsDialog : TermsAndConditionDialogFragment? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle("")

        PreferenceManager.applicationStatus = 2

        // Initialize the UI
        initUI()
    }

    override fun onResume(){
        super.onResume()

        refreshViews()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        EventBus.getDefault().register(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        if (event.message == AppConstants.MESSAGE_VERIFIED_HANDOVER){
            getShopperOrders(1)
        }
        else if (event.message == AppConstants.MESSAGE_ORDER_STARTED){
            refreshViews()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_ondemand_dashabord, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item.itemId) {
            R.id.btnMessage -> {
                navigate(OndemandDashbaordFragmentDirections.actionOndemandDashBaordFragmentToProfileFragment())
            }
        }

        return super.onOptionsItemSelected(item)
    }

    private fun refreshViews(){
        // Get shopper details
        getShopperDetails()

        // Check app version
        checkVersion()

        // clear the order list
        orders.clear()
        lastPage = false

        // Get order list
        getShopperOrders(1)

        // Get booking slots
        val cdate = Calendar.getInstance().time
        val csdate: String = DateUtils.getDatetoString(cdate)
        shopperBookingSlots(csdate)
    }

    // Check the current version
    private fun checkVersion(){

    }

    // Get booking slots
    private fun shopperBookingSlots(selectedDate : String){
        if (viewModel != null){
            try{
                viewModel.getShopperBookingSlots(selectedDate, object : HandleResponse<BookingSlotsResponse>{
                    override fun handleErrorResponse(error: ErrorResponse?) {
                        if (isNetworkConnected){
                            Toast.makeText(baseActivity, error?.message, Toast.LENGTH_SHORT).show()
                        }else{
                            Toast.makeText(baseActivity, baseActivity?.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                        }
                    }

                    override fun handleSuccessResponse(successResponse: BookingSlotsResponse) {
                        val response = successResponse.shopperBookingSlots

                        if (response != null) {
                            for (data : ShopperBookingSlots in response){
                                if (data.is_you_booked == 1) {
                                    todayFirstShiftTime = selectedDate + " " + data.start_time
                                    PreferenceManager.firstShiftTime = todayFirstShiftTime

                                    if (termsDialog == null)
                                        showPocketMoneyDialog()

                                    return
                                }
                            }
                        }
                        else {
                            Toast.makeText(baseActivity, successResponse.message, Toast.LENGTH_SHORT).show()
                        }
                    }
                })
            }
            catch (e : Exception){
                e.printStackTrace()
            }
        }
    }

    // Show the Cash on Hand dialog
    @SuppressLint("UseRequireInsteadOfGet")
    private fun showPocketMoneyDialog(){
        val cdate = Calendar.getInstance().time
        val csdate = DateUtils.getDatetoString(cdate)
        val cfdate = DateUtils.getDatetoStringfdate(cdate)

        try {
            if (!PreferenceManager.pocketMoney.equals(csdate, true)){
                val fstime = DateUtils.getdatefromstringPocket(PreferenceManager.firstShiftTime!!)
                val cfstime = DateUtils.getdatefromstringPocket(cfdate)

                if (fstime != null && cfstime != null){
                    if (activity != null && !activity!!.isFinishing && !activity!!.isDestroyed && PreferenceManager.shopperType == 1){ // Full service shopper
                        if (fstime.time >= cfstime.time){
                            PreferenceManager.cashOnHandDate = csdate
                            (activity as HomeActivity).showPocketCashDialog(false)
                        }
                        else if (!PreferenceManager.cashOnHandDate!!.equals(csdate, true)){
                            (activity as HomeActivity).showPocketCashDialog(false)
                            PreferenceManager.cashOnHandDate = csdate
                        }
                    }
                }
                else if (PreferenceManager.cashOnHandDate.equals(csdate, true)){
                    shopperBookingSlots(csdate)
                }
            }
            else if (!PreferenceManager.cashOnHandDate.equals(csdate, true)){
                shopperBookingSlots(csdate)
            }
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    // Show the support toolbar
    private fun showSupportToolBar(){
        try {
            (baseActivity as HomeActivity).showSupportMenuItems(true)
            if ((baseActivity as HomeActivity).viewDataBinding != null) {
                (baseActivity as HomeActivity).viewDataBinding!!.layoutToolBar.tvOrderCounts.setOnClickListener {
                    // Reload orders
                    reloadOrders()
                }
            }
        }
        catch (exception : Exception){
            print(exception.printStackTrace())
        }
    }

    // Reload orders
    private fun reloadOrders(){
        if (!isNetworkConnected){
            Toast.makeText(baseActivity, baseActivity?.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_SHORT).show()
            loading = false
            viewDataBinding!!.refreshLayout.isRefreshing = false
        }
        else{
            viewDataBinding!!.refreshLayout.isRefreshing = true

            orders.clear()
            lastPage = false

            orderManager.clear()

            // Get shopper order list
            getShopperOrders(1)
        }
    }

    private fun initUI(){
        showSupportToolBar()

        // Switch (Online & Offline)
        // Init Switch color
        switchColor(true)
//        viewDataBinding!!.switchOnlineStatus.setTextColor(Color.parseColor("#b71c1c"))

        // Set CheckedListener
        viewDataBinding!!.switchOnlineStatus.setOnCheckedChangeListener { button, selected ->
            viewDataBinding!!.switchOnlineStatus.text =  if (selected) baseActivity?.resources?.getString(R.string.online_label) else baseActivity?.resources?.getString(R.string.offline_label)

            if (viewDataBinding!!.switchOnlineStatus.text == baseActivity?.resources?.getString(R.string.online_label)){
                switchColor(true)
            }
            else{
                switchColor(false)
            }

            viewDataBinding!!.switchOnlineStatus.isEnabled = false

            // Change the shopper online status
            changeShopperOnlineStatus(viewDataBinding!!.switchOnlineStatus.isChecked, 0)
        }

        // Break
        viewDataBinding!!.btnBreak.setOnClickListener {

        }

        // Init TabLayout
        initTabLayout()

        // Init the Refresh layout
        initRefreshLayout()
    }

    private fun initRefreshLayout(){
        viewDataBinding!!.refreshLayout.setOnRefreshListener {
            // Check if no internet
            if (!isNetworkConnected){
                Toast.makeText(baseActivity, baseActivity?.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_SHORT).show()
                loading = false
                viewDataBinding!!.refreshLayout.isRefreshing = false
            }
            else{
                // Clear all orders
                orders.clear()

                Toast.makeText(baseActivity, baseActivity?.resources?.getString(R.string.refreshing_orders), Toast.LENGTH_SHORT).show()
                lastPage = false

                orderManager.clear()

                // Get shopper order list
                getShopperOrders(1)
            }
        }
    }

    private fun initTabLayout(){
        try{
            orderManager = OrdersManager(baseActivity as FragmentActivity, viewDataBinding!!.pager)
            orderManager.setShopperOrder(orders)
            orderManager.setTitles(baseActivity?.resources?.getString(R.string.incoming), baseActivity?.resources?.getString(R.string.acknowledge))
            val pager = orderManager.loadData()
            pager.isSaveEnabled = false

            // Init TabLayout
            viewDataBinding!!.tabs.setupWithViewPager(pager)
            viewDataBinding!!.tabs.tabGravity = TabLayout.GRAVITY_FILL
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    // Load the next page orders
    fun loadMore(){
        AppLogger.d("Load More ...")
        AppLogger.d("Page Index : " + (currentPage + 1))
        getShopperOrders(currentPage + 1)
    }

    // Check if currently load the next orders
    fun isLoading() : Boolean {
        return loading
    }

    fun isLastPage() : Boolean{
        return lastPage
    }

    // Refresh UI
    private fun updateUI(shopperData : ShopperData){
        // Display the profile image
        PreferenceManager.currentUserImageUrl = shopperData.image

        try {
            GlideApp.with(this).load(shopperData.image).fitCenter()
                .placeholder(R.drawable.ic_avatar)
                .error(R.drawable.ic_avatar).into(viewDataBinding?.ivShopperImage!!)
        }
        catch(e : Exception){
            e.printStackTrace()
        }

        // First Name
        PreferenceManager.currentShopperFirstName = shopperData.firstName
        // Last Name
        PreferenceManager.currentShopperLastName = shopperData.lastName
        viewDataBinding?.tvShopperName?.text = String.format(Locale("en"), "%s %s", shopperData.firstName, shopperData.lastName)

        // Email Address
        if (shopperData.email.isNotEmpty())
            PreferenceManager.currentShopperEmail = shopperData.email

        // Mobile
        if (shopperData.mobile.isNotEmpty())
            PreferenceManager.currentShopperMobile = shopperData.mobile

        // Shopper Type
        viewDataBinding?.tvShopperStatus?.text = String.format(Locale.ENGLISH, baseActivity!!.resources.getString(R.string.availability), shopperData.shopperType)
        viewDataBinding?.tvShopperStatus?.visibility = View.VISIBLE
        PreferenceManager.shopperType = shopperData.shopperTypeId

        if (shopperData.online == 1){
            PreferenceManager.shopperStatus = 1
        }
        else{
            PreferenceManager.shopperStatus = 0
        }

        try {
//            if (PreferenceManager.shopperStatus == 0){
//                // Stop LocationService
//                ShopperApp.Instance.stopLocationService(baseActivity as Activity)
//            }
//            else{
//                // Start Location
//                ShopperApp.Instance.startLocationService(baseActivity as Activity)
//            }

            // Online Status
            viewDataBinding?.switchOnlineStatus?.isChecked = shopperData.online == 1

            val title = if (viewDataBinding?.switchOnlineStatus?.isChecked == true) baseActivity?.resources?.getString(R.string.online_label) else baseActivity?.resources?.getString(R.string.offline_label)
            viewDataBinding?.switchOnlineStatus?.text = title
            if (title == baseActivity?.resources?.getString(R.string.online_label)) {
                switchColor(true)
//                viewDataBinding?.switchOnlineStatus?.setTextColor(Color.parseColor("#39b449"))
            }
            else{
                switchColor(false)
//                viewDataBinding?.switchOnlineStatus?.setTextColor(Color.parseColor("#b71c1c"))
            }
            viewDataBinding?.switchOnlineStatus?.visibility = View.VISIBLE

            // Check if shopper agreed Terms & Conditions
            if (shopperData.isTermsAgreed == 0 && termsDialog == null && !(baseActivity!!.isFinishing)){
                // Show the Terms and conditions dialog
                termsDialog = TermsAndConditionDialogFragment.newInstance()
                termsDialog!!.show(baseActivity!!.supportFragmentManager, TermsAndConditionDialogFragment.javaClass.name)
                termsDialog!!.isCancelable = false
                termsDialog!!.listener = agreeTermsListener
            }
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    /**
     * AgreeTermsListener
     */
    val agreeTermsListener : CheckoutInstructionsDialogFragment.AgreeTermsListener = object : CheckoutInstructionsDialogFragment.AgreeTermsListener{
        override fun onAgreed() {
            termsDialog = null

            // Get booking slots
            val cdate = Calendar.getInstance().time
            val csdate: String = DateUtils.getDatetoString(cdate)
            shopperBookingSlots(csdate)
        }
    }

    // Change the switch color
    private fun switchColor(checked : Boolean){

//        if (false) viewDataBinding!!.switchOnlineStatus.getThumbDrawable().setColorFilter(
//            if (checked) Color.parseColor("#2a8a36") else Color.parseColor("#f14643"), PorterDuff.Mode.MULTIPLY)
//        viewDataBinding!!.switchOnlineStatus.getTrackDrawable().setColorFilter(if (checked) Color.parseColor("#f14643") else Color.parseColor("#39b449"), PorterDuff.Mode.MULTIPLY)
    }

    // Update order count in action bar
    private fun updateOrderCountNumber(count : Int){
        PreferenceManager.orderCounterNumber = count
        try {
            // Show the order count in tool bar
            (baseActivity as HomeActivity).updateOrderCount(count)

            // ClickListener
            (baseActivity as HomeActivity).viewDataBinding!!.layoutToolBar.tvOrderCounts.setOnClickListener {
                reloadOrders()
            }
        }catch (e : Exception){
            e.printStackTrace()
        }
    }

    // Change shopper status in server using Socket.IO
    private fun changeShopperOnlineStatus(isOnline : Boolean, isStartEarly : Int){
        // Check if there are orders to be finished before change status
        if (!isOnline && orderManager.getAcknowledgeOrdersCount() > 0){
            Toast.makeText(baseActivity, baseActivity?.resources?.getString(R.string.offline_check_label), Toast.LENGTH_LONG).show()
            processStatusChangeSuccess(1)

            return
        }

        // Call api
        val status = if (isOnline) 1 else 0
        viewModel.changeShopperOnlineStatus(status, isStartEarly, object:HandleResponse<SimpleResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Toast.makeText(baseActivity, error?.message, Toast.LENGTH_LONG).show()
                }
                else{
                    Toast.makeText(baseActivity, baseActivity?.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }

                // return to previous status
                processStatusChangeError()
            }

            override fun handleSuccessResponse(successResponse: SimpleResponse) {
                if (successResponse.response != null){
                    if (successResponse.response.httpCode != 200){
                        Toast.makeText(baseActivity, successResponse.response.message, Toast.LENGTH_LONG).show()

                        // return to previous status
                        processStatusChangeError()
                    }
                    else{ // Success
                        if (!successResponse.response.isAccountSuspended) { // Not suspended
                            if (!successResponse.response.isBookedShift && isOnline) {
                                processStatusChangeSuccess(0)

                                // go to BookShift
                                showBookingShiftPopup(successResponse.response.message)
                            }
                            else if (successResponse.response.isBookedShift && isOnline){
                                if (successResponse.response.isShiftStartEarly && isOnline){
                                    // show the EarlyBooking popup
                                    showEarlyBookingPopup(successResponse.response.message)
                                }
                                else{
                                    processStatusChangeSuccess(1)
                                }
                            }
                            else if (successResponse.response.isBookedShift && !isOnline && !ifFromEarlyDialog){
                                processStatusChangeSuccess(1)

                                showNoOfflineBookShiftPopup(successResponse.response.message)
                            }
                            else{
                                viewDataBinding!!.switchOnlineStatus.isEnabled = true
                                viewDataBinding!!.switchOnlineStatus.text = if (viewDataBinding!!.switchOnlineStatus.isChecked) baseActivity?.resources?.getString(R.string.online_label) else baseActivity?.resources?.getString(R.string.offline_label)

                                if (viewDataBinding!!.switchOnlineStatus.text == baseActivity?.resources?.getString(R.string.online_label)) {
                                    switchColor(true)
//                                    viewDataBinding!!.switchOnlineStatus.setTextColor(Color.parseColor("#39b449"))
                                }
                                else{
                                    switchColor(false)
//                                    viewDataBinding!!.switchOnlineStatus.setTextColor(Color.parseColor("#b71c1c"))
                                }

                                // Swipe into Incoming
                                orderManager.setShowSwipeOnIncoming(viewDataBinding!!.switchOnlineStatus.isChecked)
                            }
                        }
                        else{
                            viewDataBinding!!.switchOnlineStatus.isEnabled = true
                            viewDataBinding!!.switchOnlineStatus.isChecked = false
                            if (isOnline) {
                                // Show the suspend popup
                                showSuspendPopup(successResponse.response.message)
                            }
                        }

                        ifFromEarlyDialog = false
                    }
                }
                else{
                    Toast.makeText(baseActivity, baseActivity?.resources?.getString(R.string.error_server_return_null), Toast.LENGTH_SHORT).show()

                    // return to previous status
                    processStatusChangeError()
                }
            }
        })
    }

    // Succeeded
    private fun processStatusChangeSuccess(shouldCheck : Int){
        viewDataBinding!!.switchOnlineStatus.isEnabled = true

        if (shouldCheck == 1) {
            viewDataBinding!!.switchOnlineStatus.isChecked = true
            PreferenceManager.shopperStatus = 1

        }
        else{
            viewDataBinding!!.switchOnlineStatus.isChecked = false
            PreferenceManager.shopperStatus = 0
        }

        viewDataBinding!!.switchOnlineStatus.text = if (viewDataBinding!!.switchOnlineStatus.isChecked) baseActivity?.resources?.getString(R.string.online_label) else baseActivity?.resources?.getString(R.string.offline_label)

        if (viewDataBinding!!.switchOnlineStatus.text == baseActivity?.resources?.getString(R.string.online_label)) {
            switchColor(true)
//            viewDataBinding!!.switchOnlineStatus.setTextColor(Color.parseColor("#39b449"))
        }
        else{
            switchColor(false)
//            viewDataBinding!!.switchOnlineStatus.setTextColor(Color.parseColor("#b71c1c"))
        }

    }

    // Failed
    private fun processStatusChangeError(){
        viewDataBinding!!.switchOnlineStatus.isEnabled = true
        viewDataBinding!!.switchOnlineStatus.isChecked = false
        PreferenceManager.shopperStatus = 0

        // Swipe to Incoming
        orderManager.setShowSwipeOnIncoming(viewDataBinding!!.switchOnlineStatus.isChecked)
    }

    // Show BookingShift Popup
    private fun showBookingShiftPopup(message : String) {
        val builder: AlertDialog.Builder = AlertDialog.Builder(baseActivity)

        val msg = baseActivity?.resources?.getString(R.string.msg_go_online)
        builder.setMessage(msg)
            .setCancelable(false)
            .setPositiveButton(
                baseActivity?.resources?.getString(R.string.go_to_hours)
            ) { _, _ -> //do things
                // Go to Hours
                if (baseActivity != null)
                    (baseActivity as HomeActivity).gotoHours()

            }.setNegativeButton(
                baseActivity?.resources?.getString(R.string.cancel)
            ) { _, _ ->
                //do things
            }
        val alert: AlertDialog = builder.create()
        alert.show()
    }

    // Show EarlyBooking Popup
    private fun showEarlyBookingPopup(message : String){
        val builder: AlertDialog.Builder = AlertDialog.Builder(baseActivity)

        builder.setMessage(message)
            .setCancelable(false)
            .setPositiveButton(
                baseActivity?.resources?.getString(R.string.yes)
            ) { _, _ -> //do things

                changeShopperOnlineStatus(true, 1)
            }.setNegativeButton(
                baseActivity?.resources?.getString(R.string.no)
            ) { _, _ ->
                //do things
                ifFromEarlyDialog = true
                viewDataBinding!!.switchOnlineStatus.isEnabled = true

                processStatusChangeSuccess(0)
            }
        val alert: AlertDialog = builder.create()
        alert.show()
    }

    // Show NoOfflineBookShift Popup
    private fun showNoOfflineBookShiftPopup(message: String){
        val builder: AlertDialog.Builder = AlertDialog.Builder(baseActivity)
        builder.setMessage(message)
            .setCancelable(false)
            .setPositiveButton(
                baseActivity?.resources?.getString(R.string.ok_btn_txt)
            ) { _, _ -> //do things

            }
        val alert: AlertDialog = builder.create()
        alert.show()
    }

    // Show the Suspend Popup
    private fun showSuspendPopup(message: String){
        val builder: AlertDialog.Builder = AlertDialog.Builder(baseActivity)

        builder.setMessage(message)
            .setCancelable(false)
            .setPositiveButton(
                baseActivity?.resources?.getString(R.string.ok_btn_txt)
            ) { _, _ -> //do things

            }
        val alert: AlertDialog = builder.create()
        alert.show()
    }

    // Load the shopper details
    private fun getShopperDetails(){

        try{
            // Check if no internet
            if (!isNetworkConnected){
                Toast.makeText(baseActivity, baseActivity?.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_SHORT).show()
                return
            }

            viewModel.getShopperDetails(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, object :
                HandleResponse<ShopperResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (isNetworkConnected){
                        Toast.makeText(baseActivity, error?.message, Toast.LENGTH_LONG).show()
                    }
                    else{
                        Toast.makeText(baseActivity, baseActivity?.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                    }
                }

                override fun handleSuccessResponse(successResponse: ShopperResponse) {
                    val response = successResponse.response
                    if (response != null){
                        if (response.httpCode == 200 && response.shopperData != null){
                            updateUI(response.shopperData)

                            // Read the contact information
                            getContactInfo(response.shopperData.countryId, response.shopperData.cityId)
                        }
                        else{
                            Toast.makeText(baseActivity, response.message, Toast.LENGTH_SHORT).show()
                        }
                    }
                    else{
                        Toast.makeText(baseActivity, baseActivity?.resources?.getString(R.string.err_loading_profile), Toast.LENGTH_SHORT).show()
                    }
                }
            })
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    /**
     * Get the contact information
     */

    fun getContactInfo(countryId : Int, cityId : Int){
        viewModel.getContactInformation(countryId, cityId, object : HandleResponse<SettingsResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Toast.makeText(baseActivity, error?.message, Toast.LENGTH_LONG).show()
                }
                else{
                    Toast.makeText(baseActivity, baseActivity?.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }
            }

            override fun handleSuccessResponse(successResponse: SettingsResponse) {
                if (successResponse.response != null){
                    val contactData = successResponse.response
                    if (contactData.contactSettings != null){
                        if (contactData.contactSettings.shopperCare.isNotEmpty()){
                            // Save the contact phone number
                            PreferenceManager.supportNumber = contactData.contactSettings.shopperCare

                            try {
                                (baseActivity as HomeActivity).initSupportMenu()
                            }
                            catch (e : Exception){
                                e.printStackTrace()
                            }
                        }
                        else{
                            Timber.tag("Dashboard").e("Support phone number is empty")
                        }
                    }
                    else{
                        Timber.tag("Dashboard").e("Can't read the contact information")
                        Timber.tag("Dashboard").e(contactData.message)
                    }
                }
                else{
                    Timber.tag("Dashboard").e("Can't read the contact information")
                }
            }
        })
    }

    // Get shopper orders
    fun getShopperOrders(page : Int){
        AppLogger.d("Get orders...")
        AppLogger.d("Page Index : " + page)

        try{
            loading = true
            viewDataBinding!!.refreshLayout.isRefreshing = true

            // Check if no internet
            if (!isNetworkConnected){
                Toast.makeText(baseActivity, baseActivity?.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                loading = false
                viewDataBinding!!.refreshLayout.isRefreshing = false

                return
            }

            viewModel.getOrderList(page, ITEMS_COUNT, object : HandleResponse<OrderResponse>{
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (isNetworkConnected){
                        Toast.makeText(baseActivity, error?.message, Toast.LENGTH_LONG).show()
                    }else{
                        Toast.makeText(baseActivity, baseActivity?.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                    }

                    viewDataBinding!!.refreshLayout.isRefreshing = false
                }

                override fun handleSuccessResponse(successResponse: OrderResponse) {

                    val response = successResponse.response
                    if (response != null){
                        if (response.httpCode != 200){
                            Toast.makeText(baseActivity, response.message, Toast.LENGTH_SHORT).show()
                        }
                        else{
                            currentPage = page
                            if (response.shopperOrder.size == 0) { // Empty orders
                                lastPage = true
                                PreferenceManager.activeStatus = 0

                                if (page <= 1) {
                                    // Save the order count to local preference
                                    updateOrderCountNumber(0)

                                    // Clear the orders
                                    orders.clear()
                                }

                                // Refresh the view pager
                                orderManager.setShopperOrder(orders)
                                orderManager.setTitles(baseActivity?.resources?.getString(R.string.incoming), baseActivity?.resources?.getString(R.string.acknowledge))
                                orderManager.loadData()

                            }
                            else{ // Order Exist
                                if (orders.isEmpty()){
                                    orders = response.shopperOrder
                                    filterOrders()
                                    sortOrders()

                                    if (page <= 1){
                                        updateOrderCountNumber(response.shopperOrder.size)
                                    }

                                    orderManager.setShopperOrder(orders)
                                    orderManager.setTitles(baseActivity?.resources?.getString(R.string.incoming), baseActivity?.resources?.getString(R.string.acknowledge))
                                    orderManager.loadData()
                                    orderManager.setShowSwipeOnIncoming(viewDataBinding!!.switchOnlineStatus.isChecked)
                                }
                                else{
                                    // Update the order count
                                    updateOrderCountNumber(response.shopperOrder.size)

                                    orders.addAll(response.shopperOrder)
                                    orderManager.addMore(response.shopperOrder)
                                }

                                PreferenceManager.activeStatus = 1
                            }
                        }
                    }
                    else{
                        Toast.makeText(baseActivity, baseActivity?.resources?.getString(R.string.error_server_return_null), Toast.LENGTH_SHORT).show()
                    }

                    loading = false
                    viewDataBinding!!.refreshLayout.isRefreshing = false
                }
            })
        }
        catch (e : Exception){
            e.printStackTrace()
        }

    }

    // Filter orders
    private fun filterOrders(){
        val list: List<Order> = orders
        val filterList: ArrayList<Order> = arrayListOf()
        for (order in list) {
            val status = order.orderStatus
            if (status >= STATUS_SLIDE_ACKNOWLEDGE_ORDER && status < STATUS_ORDER_FINISHED) {
                filterList.add(order)
            }
        }

        orders = filterList
    }

    // Sort orders
    private fun sortOrders(){
        val sortedOrders: List<Order> = orders

        Collections.sort(sortedOrders) { o2, o1 ->
            if (o1.orderStatus >= STATUS_ORDER_FINISHED) {
                return@sort -1
            } else if (o2.orderStatus >= STATUS_ORDER_FINISHED) {
                return@sort 1
            } else {
                return@sort o1.orderStatus.compareTo(o2.orderStatus)
            }
        }
    }


}
