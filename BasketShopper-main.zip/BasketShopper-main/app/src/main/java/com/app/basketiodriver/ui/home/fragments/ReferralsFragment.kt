package com.app.basketiodriver.ui.home.fragments

import android.graphics.Color
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentReferralsBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.ShareDialog.ShareDialog
import com.app.basketiodriver.ui.ShareDialog.Utils.Ratio
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.home.HomeViewModel
import com.app.basketiodriver.ui.referrals.ReferralsActivity


/**
 * A simple [Fragment] subclass.
 */
class ReferralsFragment : BaseFragment<FragmentReferralsBinding?, HomeViewModel>(),
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_referrals

    override val viewModel: HomeViewModel
        get() {
            return getViewModel(requireActivity(), HomeViewModel::class.java)
        }

    companion object {
        fun newInstance(
        ): ReferralsFragment {
            return ReferralsFragment()
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.invite_friends))
        setHasOptionsMenu(true)
        viewDataBinding!!.btnViewDetails.setOnClickListener {
            startActivity(ReferralsActivity.newIntent(requireContext()))
        }

        viewDataBinding!!.btnShare.setOnClickListener {
            ShareDialog.Builder()
                .setTitle(getString(R.string.share))
                .setTitleTintColor(Color.BLUE)
                .setHeaderLayout(R.layout.share_header)
                .setSizeRatio(Ratio(1.0, 0.5))
                .setShareContent(viewDataBinding!!.tvReferralsCode.text.toString())
                .build()
                .show(childFragmentManager)
        }

    }


}
