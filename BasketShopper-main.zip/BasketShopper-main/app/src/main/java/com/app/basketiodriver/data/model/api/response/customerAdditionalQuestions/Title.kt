package com.app.basketiodriver.data.model.api.response.customerAdditionalQuestions

data class Title(
    val lang: String,
    val text: String
)