package com.app.basketiodriver.ui.order.product.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.customerAdditionalQuestions.Answer
import com.app.basketiodriver.databinding.ItemProductQuestionAnswerBinding
import com.app.basketiodriver.utils.BaseRecyclerViewAdapter
import com.app.basketiodriver.utils.CommonUtils
import com.app.basketiodriver.utils.FormatterUtils
import com.app.basketiodriver.utils.ViewUtils

class ProductAnswerAdapter(
) : BaseRecyclerViewAdapter<Answer, ItemProductQuestionAnswerBinding>() {

    override val layoutId: Int
        get() = R.layout.item_product_question_answer

    var taxPercent = 0.0
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): AnswerViewHolder {
        return AnswerViewHolder(
            DataBindingUtil.inflate(
                LayoutInflater.from(viewGroup.context),
                R.layout.item_product_question_answer,
                viewGroup,
                false
            )
        )
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as AnswerViewHolder
        val answer = items[position]
        val mContext = holder.itemView.context

        holder.binding.layoutContent.layoutParams.height =
            if (answer.active) ViewUtils.dpToPx(50.0f) else 0


        holder.binding.tvTitle.text =
            CommonUtils.getAnswerTitleByLanguage(answer.title)

        
        if (answer.title.isNotEmpty()) {

            //    answer.title[if (answer.title.size > 1) PreferenceManager.currentUserLanguage - 1 else 0].text
        }


        holder.binding.tvPrice.text =
            if (answer.price > 0) "+${FormatterUtils.getPriceWithTax(answer.price, taxPercent)}"
            else mContext.getString(R.string.str_free)



        holder.itemView.setOnClickListener {
            if (!items[position].selected){
                for (i in 0 until items.size) {
                    items[i].selected = i == position
                }
                notifyDataSetChanged()
            }
        }

        holder.binding.viewDivider.visibility = if (position == items.size -1) View.GONE else View.VISIBLE
    }

    override fun getItemCount(): Int {
        return items.size
    }

    inner class AnswerViewHolder(val binding: ItemProductQuestionAnswerBinding) :
        RecyclerView.ViewHolder(binding.root)
}
