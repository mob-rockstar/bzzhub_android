package com.app.basketiodriver


//import com.zopim.android.sdk.api.ZopimChat
import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.location.Location
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.util.Log
import android.view.LayoutInflater
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.OnLifecycleEvent
import androidx.lifecycle.ProcessLifecycleOwner
import app.basket.scanner.BasketScanner
import com.app.basketiodriver.data.local.db.realm.RealmManager
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.chat.BaseResponse
import com.app.basketiodriver.data.model.api.chat.ChatMessage
import com.app.basketiodriver.data.model.api.chat.User
import com.app.basketiodriver.data.model.db.PaymentChangedOrder
import com.app.basketiodriver.data.remote.APIManager
import com.app.basketiodriver.data.remote.FreshchatApiService
import com.app.basketiodriver.data.remote.GoogleAPIManager
import com.app.basketiodriver.data.remote.socket.SocketManager
import com.app.basketiodriver.databinding.DialogOrderCanceledBinding
import com.app.basketiodriver.databinding.DialogPaymentChangedBinding
import com.app.basketiodriver.di.AppInjector
import com.app.basketiodriver.di.Navigators
import com.app.basketiodriver.service.FCMService
import com.app.basketiodriver.service.LocationService
import com.app.basketiodriver.service.NotificationSoundService
import com.app.basketiodriver.ui.chat.ChatActivity
import com.app.basketiodriver.utils.AppConstants
import com.app.basketiodriver.utils.AppLogger
import com.app.basketiodriver.utils.MessageEvent
import com.google.firebase.FirebaseApp
import com.google.firebase.crashlytics.FirebaseCrashlytics
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.gu.toolargetool.TooLargeTool
import com.huawei.agconnect.AGConnectApp
import com.squareup.picasso.Picasso
import com.zendesk.logger.Logger
import dagger.android.AndroidInjector
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import io.github.inflationx.calligraphy3.CalligraphyConfig
import io.github.inflationx.calligraphy3.CalligraphyInterceptor
import io.github.inflationx.viewpump.ViewPump
import io.realm.Realm
import io.realm.RealmConfiguration
import io.socket.client.Ack
import io.socket.client.Socket
import io.socket.emitter.Emitter
import org.greenrobot.eventbus.EventBus
import org.json.JSONObject
import timber.log.Timber
import zendesk.chat.Chat
import zendesk.chat.PushNotificationsProvider
import java.util.*
import javax.inject.Inject


class ShopperApp : Application(), HasAndroidInjector, LifecycleObserver {
    @Inject
    lateinit var activityDispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    @Inject
    lateinit var mCalligraphyConfig: CalligraphyConfig // Custom font

    override fun androidInjector(): AndroidInjector<Any> {
        return activityDispatchingAndroidInjector
    }

    // Current location
    var mCurrentLocation: Location? = null

    private var intent: Intent? = null

    // Location service intent
    var locationServiceIntent: Intent? = null

    // Chat socket
    var chatSocket: Socket? = null

    // Check if socket is initiated
    var isInitiatedSocket: Boolean = false

    // Notification sound intent
    var notificationSoundIntent: Intent? = null

    // Current visible activity
    var mCurrentActivity: Activity? = null

    // Zendesk Push
    var pushProvider: PushNotificationsProvider? = null

    @Inject
    lateinit var socketManager: SocketManager

    override fun onCreate() {
        super.onCreate()

        BasketScanner.init(this)
        // firebase
        FirebaseApp.initializeApp(this)

        // Init Preference Manager
        PreferenceManager.init(this)

        // Initialize the APIManager
        APIManager.init(this)
        FreshchatApiService.init(this)

        GoogleAPIManager.init(this)

        // Init for LifecycleOwner
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)

        // Logger
        AppLogger.init()

        AppInjector.init(this)

        // Init TooLargeTool
        TooLargeTool.startLogging(this, Log.DEBUG, "TooLargeTool")

        // Initialize the ViewPump for custom font usage
        ViewPump.init(
            ViewPump.builder()
                .addInterceptor(CalligraphyInterceptor(mCalligraphyConfig))
                .build()
        )

        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }

        // Initialize the Zendesk Chat SDK
        Chat.INSTANCE.init(
            this,
            AppConstants.KEY_ZENDESK_LIVE_CHAT,
            AppConstants.KEY_ZENDESK_APP_ID
        )
//        ZopimChat.init(AppConstants.KEY_ZENDESK_LIVE_CHAT)

        // Setup Huawei AppGallery
//        setupHuaweiAppGallery()

        // Init the socket.io
        initSocketIO()

//        FirebaseCrashlytics.getInstance().setCrashlyticsCollectionEnabled(true)

        // Start the location service
//        startLocationService()

        // Initialize the Realm
        Realm.init(this)
        val configuration =
            RealmConfiguration.Builder().allowWritesOnUiThread(true).allowQueriesOnUiThread(true)
                .schemaVersion(REALM_SCHEMA_VERSION)
                .deleteRealmIfMigrationNeeded()
                .name(DB_NAME)
                .build()
        Realm.setDefaultConfiguration(configuration)

        // Enable the Logs
        Logger.setLoggable(true)

//        Picasso.setSingletonInstance(Picasso.Builder(this).build())
    }


    override fun onTerminate() {
        super.onTerminate()

        try {
            // Stop the location service
            if (locationServiceIntent != null) {
                stopService(locationServiceIntent)
            }

            if (isInitiatedSocket) {
                if (socketManager.chatSocket != null && socketManager.chatSocket!!.connected()) {
                    socketManager.chatSocket!!.disconnect()
                    socketManager.chatSocket = null
                }
            }

            // Disconnect the socket
            if (PreferenceManager.socketToken != null && PreferenceManager.socketToken!!.isNotEmpty()) {
                socketManager.disconnect()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


    // Initialize the Huawei SDK
    private fun setupHuaweiAppGallery() {
        val agConnectApp = AGConnectApp.getInstance()
        agConnectApp.setClientId(BuildConfig.HUAWEI_CLIENT_ID)
        agConnectApp.setClientSecret(BuildConfig.HUAWEI_CLIENT_SECRET)
        agConnectApp.setApiKey(BuildConfig.HUAWEI_API_KEY)
    }

    fun setCurrentLocation(location: Location) {
        mCurrentLocation = location
    }

    fun setIntent(mIntent: Intent) {
        intent = mIntent
    }

    // Check if application is in foreground
    fun isAppForeground(mContext: Context): Boolean {
        val am = mContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val tasks = am.getRunningTasks(1)
        if (tasks.isNotEmpty()) {
            val topActivity = tasks[0].topActivity
            return topActivity!!.packageName == mContext.packageName
        }
        return true
    }

    /**
     * Init the Socket
     */
    private fun initSocketIO() {
        socketManager = SocketManager()
        if (PreferenceManager.isLoggedIn && (PreferenceManager.socketToken != null && PreferenceManager.socketToken!!.isNotEmpty())) {
            // Init the socket manager

            socketManager.init(newMessageCallback)

            isInitiatedSocket = true

            // Connect to location socket
            if (socketManager.basketLocationService != null && !socketManager.basketLocationService!!.connected()) {

                if (!isLocationConnecting) {
                    isLocationConnecting = true
                    socketManager.basketLocationService!!.connect()
                }
            }

            // Connect to chat socket
            if (socketManager.chatSocket != null && !socketManager.chatSocket!!.connected()) {
                socketManager.chatSocket!!.connect()
            }
        }
    }

    /**
     * Start the location service
     */
    fun startLocationService(mContext: Activity) {
        if (PreferenceManager.isLoggedIn) {
            try {
                if (locationServiceIntent == null) {
                    Timber.tag(TAG).d("===== Location intent is null, so need to create again ...")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        if (isVisible) {
                            Timber.tag(TAG).d("===== Staring location service ...")
                            locationServiceIntent = Intent(mContext, LocationService::class.java)
                            mContext.startForegroundService(locationServiceIntent)
                        } else {
                            Timber.tag(TAG)
                                .d("===== Can't start the location service because it's in background ...")
                        }
                    } else {
                        if (isAppForeground(this)) {
                            Timber.tag(TAG).d("===== Staring location service ...")
                            locationServiceIntent = Intent(mContext, LocationService::class.java)
                            mContext.startService(locationServiceIntent)
                        } else {
                            Timber.tag(TAG)
                                .d("===== Can't start the location service because it's in background ...")
                        }
                    }
                } else {
                    Timber.tag(TAG).d("===== Location intent is not null ...")
                }
            } catch (e: Exception) {
                Timber.tag(TAG)
                    .d("===== Can't start the location service because occurred exception ...")
                e.printStackTrace()

                locationServiceIntent = null
            }
        }
    }

    /**
     * Stop the location service
     */
    fun stopLocationService(mContext: Activity) {
        try {
            if (locationServiceIntent != null) {
                locationServiceIntent!!.action = AppConstants.STOP_FOREGROUND_ACTION

                Timber.tag(TAG).d("===== Stopping location service ...")

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    if (isVisible) mContext.startForegroundService(locationServiceIntent)
                } else {
                    if (isAppForeground(this)) mContext.startService(locationServiceIntent)
                }
                locationServiceIntent = null
            }
        } catch (e: java.lang.Exception) {
            e.printStackTrace()

            Timber.tag(TAG)
                .d("===== Can't stop the location service because occurred exception ...")
        }
    }

    /**
     * Method to post the shopper location by socket
     */
    fun postShopperLiveLocation(lat: Double, lng: Double, currLocation: Location) {
        if (socketManager.isLocationSocketConnected()) {

            Timber.tag(TAG).d("Location socket is connected to post location...")
            val jsonObject = JSONObject()

            try {
                jsonObject.put("shopper_id", PreferenceManager.currentShopperId!!.toString())
                jsonObject.put("lat", lat)
                jsonObject.put("lon", lng)
                jsonObject.put("speed", currLocation.speed)
                jsonObject.put("accuracy", currLocation.accuracy)
                jsonObject.put("direction", currLocation.bearing)
                jsonObject.put("measured_at", currLocation.time)
            } catch (e: Exception) {
                Timber.tag(TAG).e("Location socket is not connected to submit...")
                e.printStackTrace()
            }

            // Emit object
            socketManager.basketLocationService!!.emit(
                SocketManager.SOCKET_EVENT_UPDATE_LOCATION,
                jsonObject
            )
        } else {
            Timber.tag(TAG).e("Location socket is not connected to submit...")

            if (socketManager.basketLocationService != null && !isLocationConnecting)
                socketManager.basketLocationService!!.connect()
        }
    }

    /**
     * Method to post battery level
     */
    fun postBatteryLevel(batteryLevel: Float) {
        Timber.tag(TAG).d("Posting a Battery level...")
        Timber.tag(TAG).d("Battery level : " + batteryLevel.toString())

        if (socketManager.isLocationSocketConnected()) {

            val jsonObject = JSONObject()

            try {
//                val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
//                val batLevel = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)

                jsonObject.put("shopper_id", PreferenceManager.currentShopperId!!.toString())
                jsonObject.put("level", batteryLevel)
            } catch (e: Exception) {
                e.printStackTrace()
            }

            // Emit object
            socketManager.basketLocationService!!.emit(
                SocketManager.SOCKET_EVENT_UPDATE_BATTERY,
                jsonObject
            )
        } else {
            Timber.tag(TAG).d("Socket is not connected to submit...")

            if (socketManager.basketLocationService != null && !isLocationConnecting)
                socketManager.basketLocationService!!.connect()
        }
    }

    // Get the current visible activity
    fun getCurrentActivity(): Activity? {
        return mCurrentActivity
    }

    // Save the current visible activity
    fun setCurrentActivity(mCurrentActivity: Activity?) {
        this.mCurrentActivity = mCurrentActivity
    }

    fun notifyOrderCancel(orderId: Long) {
        try {
            if (mCurrentActivity != null && orderId != null) {
                Timber.tag(TAG).d("Showing the order cancel popup...")

                mCurrentActivity!!.runOnUiThread {
                    showOrderCanceledDialog(mCurrentActivity!!, orderId)
                }
            } else {
                Timber.tag(TAG).d("Can't get the current visible activity...")
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Notify the shopper that payment method was changed by user
     */
    fun notifyPaymentMethodChanged(paymentName: String, orderId: Long) {
        try {
            if (mCurrentActivity != null) {
                Timber.tag(TAG).d("Showing the payment changed popup...")

                mCurrentActivity!!.runOnUiThread {
                    showPaymentChangedDialog(mCurrentActivity!!, paymentName, orderId)
                }
            } else {
                Timber.tag(TAG)
                    .e("Can't get the current visible activity, maybe app is in background...")

                // Save the order id and payment method to local
                val orderData = PaymentChangedOrder()
                orderData.orderId = orderId
                orderData.paymentMethod = paymentName

                RealmManager.saveLocalPaymentChangedOrder(orderData)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Show the payment changed popup
     */
    private fun showPaymentChangedDialog(mContext: Activity, paymentName: String, orderId: Long) {
        if (PreferenceManager.isLoggedIn) {
            if (isVisible) {
                val orderNo = String.format(Locale.ENGLISH, "#%s", orderId)
                val msg = String.format(
                    Locale.ENGLISH,
                    mContext.resources.getString(R.string.payment_changed_body),
                    orderNo,
                    paymentName
                )

                val wordToSpan = SpannableString(msg)
                val orderNoStartIdx = wordToSpan.indexOf(orderNo)
                val orderNoEndIdx = orderNoStartIdx + orderNo.length
                wordToSpan.setSpan(
                    ForegroundColorSpan(mContext.resources.getColor(R.color.colorPrimary)),
                    orderNoStartIdx,
                    orderNoEndIdx,
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )

                val paymentStartIdx = wordToSpan.indexOf(paymentName)
                val paymentEndIdx = paymentStartIdx + paymentName.length
                wordToSpan.setSpan(
                    ForegroundColorSpan(mContext.resources.getColor(R.color.colorPrimary)),
                    paymentStartIdx,
                    paymentEndIdx,
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )

                val dialog = Dialog(mContext, R.style.PauseDialog)
                val binding = DialogPaymentChangedBinding.inflate(LayoutInflater.from(mContext))

                dialog.setContentView(binding.root)
                dialog.setCanceledOnTouchOutside(false)
                dialog.setCancelable(false)
                dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

                // Set the formatted text for order number and payment method
                binding.tvMessage.text = wordToSpan

                // Dismiss
                binding.btnDismiss.setOnClickListener {
                    dialog.dismiss()

                    // Remove the order if it's existed in local
                    val order = RealmManager.getPaymentChangerOrderWithId(orderId)
                    if (order != null) {
                        RealmManager.deleteLocalPaymentChangedOrder(order)
                    }

                    if (!existPaymentChangedOrders()) {
                        // Go back to Dashboard
                        Navigators.goToDashboard(mContext)
                    } else {
                        // Show the next popup
                        showNextPaymentChangedPopup()
                    }
                }

                // Show the dialog
                dialog.show()
            } else {
                // App is in background mode
                Timber.tag(TAG)
                    .e("Can't show the payment changed popup because app is in background...")

                // Save the order id and payment method to local
                val orderData = PaymentChangedOrder()
                orderData.orderId = orderId
                orderData.paymentMethod = paymentName

                RealmManager.saveLocalPaymentChangedOrder(orderData)
            }
        }
    }

    /**
     * Check if there are orders which payment method was changed
     */
    private fun existPaymentChangedOrders(): Boolean {
        return RealmManager.getLocalPaymentChangedOrders().isNotEmpty()
    }

    fun showNextPaymentChangedPopup() {
        try {
            val orders = RealmManager.getLocalPaymentChangedOrders()
            if (orders.isNotEmpty() && mCurrentActivity != null) {
                showPaymentChangedDialog(
                    mCurrentActivity!!,
                    orders[0].paymentMethod,
                    orders[0].orderId
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Show the order canceled dialog
    private fun showOrderCanceledDialog(mContext: Activity, orderId: Long) {
        if (PreferenceManager.isLoggedIn) {
            val message = String.format(
                Locale.ENGLISH,
                "%s #%s %s",
                mContext.getString(R.string.your_order),
                orderId,
                mContext.getString(R.string.canceled)
            )
//        val msg = String.format(Locale.ENGLISH, mContext.resources.getString(R.string.msg_order_cancelled), orderId.toString())

            val startIdx = mContext.getString(R.string.your_order).length + 1
            val endIdx = startIdx + orderId.toString().length + 1

            val wordToSpan = SpannableString(message)
            wordToSpan.setSpan(
                ForegroundColorSpan(mContext.resources.getColor(R.color.colorPrimary)),
                startIdx,
                endIdx,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )

            val dialog = Dialog(mContext, R.style.PauseDialog)
            val binding = DialogOrderCanceledBinding.inflate(LayoutInflater.from(mContext))

            dialog.setContentView(binding.root)
            dialog.setCanceledOnTouchOutside(false)
            dialog.setCancelable(false)
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

            // Show the colored order canceled text
            binding.tvCanceled.text = wordToSpan

            // Dismiss
            binding.btnDismiss.setOnClickListener {
                dialog.dismiss()

                // Go back to Dashboard
                Navigators.goToDashboard(mContext)
            }

            dialog.show()
        }
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_STOP)
    fun onAppBackgrounded() {
        Timber.tag(TAG).d("shopper apps is in background...")

        // Notify when app is in background mode
//        EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_APP_IN_BACKGROUND))

        // App is in background
        isVisible = false

        try {
            if (isInitiatedSocket) {
                Timber.tag(TAG).e("isInitiatedSocket : YES")
                if (socketManager.chatSocket != null && socketManager.chatSocket!!.connected()) {
                    Timber.tag(TAG).e("Disconnecting the chat socket...")
                    socketManager.chatSocket!!.disconnect()
                } else {
                    Timber.tag(TAG).e("Chat socket is null")
                }
            } else {
                Timber.tag(TAG).e("isInitiatedSocket : NO")
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    fun onAppForegrounded() {
        Timber.tag(TAG).d("shopper apps is in foreground...")

        // Notify when app is in foreground mode
        EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_APP_IN_FOREGROUND))

        // App is in foreground
        isVisible = true

        try {
            if (isInitiatedSocket) {
                Timber.tag(TAG).e("isInitiatedSocket : YES")
                if (socketManager.chatSocket != null) {
                    handleChatSocketEvent()

                    Timber.tag(TAG).e("Connecting the chat socket...")
                    socketManager.chatSocket!!.connect()
                } else {
                    Timber.tag(TAG).e("Chat socket is null")
                }
            } else {
                Timber.tag(TAG).e("isInitiatedSocket : NO")
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Check if there are orders which payment method was changed
//        showNextPaymentChangedPopup()
    }

    /**
     * Handle the chat socket connection
     */
    private fun handleChatSocketEvent() {
        try {
            if (isInitiatedSocket) {
                if (socketManager.chatSocket != null) {
                    // remove the connection listeners
                    removeChatSocketListeners()

                    socketManager.chatSocket!!.on(Socket.EVENT_CONNECT_ERROR) { a ->
                        Timber.tag(TAG).e("Chat Socket Connection Error")
                        Timber.tag(TAG).e(a[0].toString())
                    }
                    socketManager.chatSocket!!.on(Socket.EVENT_CONNECT_TIMEOUT) {
                        Timber.tag(TAG).e("Chat Socket Connection Timeout")
                    }
                    socketManager.chatSocket!!.on(Socket.EVENT_DISCONNECT) {
                        Timber.tag(TAG).e("Chat Socket Disconnected")
                    }
                    socketManager.chatSocket!!.on(Socket.EVENT_CONNECT) {
                        Timber.tag(TAG).e("Chat Socket Connected")
                    }
                    socketManager.chatSocket!!.on(
                        SocketManager.CHAT_EVENT_RECEIVE_MESSAGE,
                        newMessageCallback
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Remove the chat socket listeners
     */
    private fun removeChatSocketListeners() {
        Timber.tag(TAG).e("Removing the chat socket listeners...")

        try {
            if (isInitiatedSocket) {
                if (socketManager.chatSocket != null) {
                    socketManager.chatSocket!!.off(Socket.EVENT_CONNECT_ERROR) {
                    }
                    socketManager.chatSocket!!.off(Socket.EVENT_CONNECT_TIMEOUT) {
                    }
                    socketManager.chatSocket!!.off(Socket.EVENT_DISCONNECT) {
                    }
                    socketManager.chatSocket!!.off(Socket.EVENT_CONNECT) {
                    }
                    socketManager.chatSocket!!.off(
                        SocketManager.CHAT_EVENT_RECEIVE_MESSAGE,
                        newMessageCallback
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * New Message Callback(Socket)
     */
    var newMessageCallback: Emitter.Listener? = Emitter.Listener { args ->
        Handler(Looper.getMainLooper()).post(Runnable {
            try {
                val baseResponseType = object : TypeToken<BaseResponse>() {}.type
                val data = args.first() as String

                Timber.tag(TAG).e("Received the customer message;")
                Timber.tag(TAG).e(data)

                val response =
                    Gson().fromJson<BaseResponse>(args.first() as String, baseResponseType)
                if (!response.error) { // Success
                    val type = object : TypeToken<ChatMessage>() {}.type
                    val chatMessage = Gson().fromJson<ChatMessage>(response.payload, type)

                    // Check if the customer sent the message
                    if (chatMessage.by != null && "customer" == chatMessage.by!!.type ?: "") {
                        // Send the read status via socket
                        sendMessageReceivedStatus(chatMessage.orderId!!, chatMessage.id)

                        // Show the message notification
                        if (chatMessage.orderId != "0") {
                            if (chatMessage.type == "text") {
                                showInAppMessageNotification(
                                    chatMessage.content ?: "",
                                    chatMessage.orderId,
                                    chatMessage.by!!
                                )
                            } else {
                                showInAppMessageNotification(
                                    chatMessage.type.capitalize(Locale.ENGLISH),
                                    chatMessage.orderId, chatMessage.by!!
                                )
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        })
    }

    /**
     * Send the message received status via socket
     */
    @SuppressLint("TimberArgCount")
    private fun sendMessageReceivedStatus(orderOutletId: String, messageId: String) {
        Timber.tag(TAG).e("Sending the message received status via socket...")

        if (isInitiatedSocket && socketManager.chatSocket != null && socketManager.chatSocket!!.connected()) {
            socketManager.chatSocket?.emit(
                SocketManager.CHAT_EVENT_SEND_RECEIVED,
                JSONObject().apply {
                    put(SocketManager.CHAT_KEY_ROOM_ID, orderOutletId)
                    put(SocketManager.CHAT_KEY_MESSAGE_ID, messageId)
                },
                Ack {
                    val baseResponseType = object : TypeToken<BaseResponse>() {}.type
                    val response =
                        Gson().fromJson<BaseResponse>(it.first() as String, baseResponseType)

                    val callbackMsg = String.format(
                        Locale.ENGLISH,
                        "*** chat:room:send:received:status : %s ***",
                        response.message ?: ""
                    )
                    Timber.tag(TAG).e(callbackMsg)
                }
            )
        }
    }

    /**
     * Close the chatting room
     */
    @SuppressLint("TimberArgCount")
    fun closeChatRoom(orderOutletId: Long) {
        Timber.tag(TAG).e("Closing chatting room...")

        try {
            if (isInitiatedSocket && socketManager.chatSocket != null && socketManager.chatSocket!!.connected()) {
                socketManager.chatSocket!!.emit(
                    SocketManager.CHAT_EVENT_CLOSE_ROOM,
                    JSONObject().apply {
                        put(SocketManager.CHAT_KEY_ROOM_ID, orderOutletId)
                    },
                    Ack {
                        val baseResponseType = object : TypeToken<BaseResponse>() {}.type
                        val response =
                            Gson().fromJson<BaseResponse>(it.first() as String, baseResponseType)

                        val callbackMsg = String.format(
                            Locale.ENGLISH,
                            "*** chat:room:close : %s ***",
                            response.message ?: ""
                        )
                        Timber.tag(TAG).e(callbackMsg)
                    }
                )
            } else {
                Timber.tag(TAG).e("Chat socket is not initiated or not connected")
            }
        } catch (e: Exception) {
            Timber.tag(TAG).e("Failed to close the chatting room")
            e.printStackTrace()
        }
    }

    /**
     * Display the message notification
     */
    private fun showInAppMessageNotification(message: String, orderId: String, userInfo: User) {
        Timber.tag(TAG).e("Showing the customer message using notification ...")
        try {
            if (mCurrentActivity != null && mCurrentActivity is ChatActivity) { // If current page is not chat screen
                Timber.tag(TAG)
                    .e("current activity is chat screen : No need to show message notification")
            } else {
                Timber.tag(TAG).e("current activity is not chat page")

                val jsonObject = JSONObject()
                jsonObject.put("message", message)
                jsonObject.put("order_id", orderId)
                jsonObject.put("user_id", userInfo.id)
                jsonObject.put("user_name", userInfo.userName ?: "")
                jsonObject.put("user_photo", userInfo.image ?: "")


                // Post event
                EventBus.getDefault()
                    .post(MessageEvent(AppConstants.MESSAGE_RECEIVED_CHAT_MESSAGE, jsonObject))
            }
        } catch (e: Exception) {
            Timber.tag(TAG).e("Can't show the message notification ...")
            e.printStackTrace()
        }
    }

    /**
     * Notification Sound Manager
     */
    // Start the notification sound intent
    fun startNotificationSound(appContext: Context) {
        Timber.tag(TAG).e("Starting notification sound for assigning order...")
        try {
            if (notificationSoundIntent == null) {
                notificationSoundIntent = Intent(appContext, NotificationSoundService::class.java)
                Log.d(FCMService.TAG, "startNotificationSound: ")

                // Set the custom sound path as extra
                val buzzerURIPath = "android.resource://com.app.basketiodriver/raw/sound_order_assign"
                notificationSoundIntent!!.putExtra(
                    NotificationSoundService.SOUND_URI_KEY,
                    buzzerURIPath
                )

                // Start the service
                appContext.startService(notificationSoundIntent)
            }
        } catch (e: Exception) {
            Timber.tag(TAG).e("Failed to start the notification sound...")
            e.printStackTrace()
        }
    }

    // Stop the notification sound
    fun stopNotificationSound(appContext: Context) {
        Timber.d("ShopperApp: stopNotificationSound")
        try {
            if (notificationSoundIntent != null) {
                // Stop the service
                Log.d(FCMService.TAG, "stopNotificationSound: ")

                appContext.stopService(notificationSoundIntent)

                notificationSoundIntent = null
            }
        } catch (e: Exception) {
            Timber.d("ShopperApp: stopSoundException")
            e.printStackTrace()
        }
    }

    companion object {
        @SuppressLint("StaticFieldLeak")
        private var instance: ShopperApp? = null
        var isLocationConnecting: Boolean = false

        const val TAG = "ShopperApp"

        // For Realm
        const val DB_NAME = "basketshopper.db"
        const val REALM_SCHEMA_VERSION: Long = 2

        // Flag to check if app is in background
        var isVisible: Boolean = false

        val Instance: ShopperApp
            get() {
                if (instance == null) {
                    instance = ShopperApp()
                }
                return instance!!
            }

        fun setIntent(intent: Intent) {
            Instance.setIntent(intent)
        }
    }
}