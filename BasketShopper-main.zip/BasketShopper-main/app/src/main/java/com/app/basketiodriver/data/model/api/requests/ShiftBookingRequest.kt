package com.app.basketiodriver.data.model.api.requests

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

/**
 * Created by ibraheem lubbad on 2020-02-11.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 */
sealed class BookingReportRequest {

    data class BookingReport(
        @field:SerializedName("shopper_id") @field:Expose val shopper_id: Long,
        @field:SerializedName("token") @field:Expose val token: String,
        @field:SerializedName("fromDate") @field:Expose val from_date: String,
        @field:SerializedName("toDate") @field:Expose val to_date: String
    )

    data class BookingSlots(
        @field:SerializedName("shopper_id") @field:Expose val shopper_id: Long,
        @field:SerializedName("token") @field:Expose val token: String,
        @field:SerializedName("selected_date") @field:Expose val selected_date: String,
        @field:SerializedName("shopper_zone_id") @field:Expose val shopper_zone_id: Int? = 0
    )

    data class ManageBooking(
        @field:SerializedName("shopper_id") @field:Expose val shopper_id: Long,
        @field:SerializedName("token") @field:Expose val token: String,
        @field:SerializedName("selected_date") @field:Expose val selected_date: String?,
        @field:SerializedName("selected_slots") @field:Expose val selected_slots: String?,
        @field:SerializedName("action") @field:Expose val action: String
    )

    data class PastHourReport(
        @field:SerializedName("shopper_id") @field:Expose val shopper_id: Long,
        @field:SerializedName("token") @field:Expose val token: String,
        @field:SerializedName("from_date") @field:Expose val from_date: String,
        @field:SerializedName("to_date") @field:Expose val to_date: String
    )


}