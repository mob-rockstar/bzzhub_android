package com.app.basketiodriver.ui.order.product

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.Html
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import app.basket.scanner.BasketScanner
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.checkout.CustomerInfo
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.model.api.response.checkout.ShopperOrderDetail
import com.app.basketiodriver.data.model.api.response.customerAdditionalQuestions.AdditionalRequestItem
import com.app.basketiodriver.data.model.api.response.customerAdditionalQuestions.Answer
import com.app.basketiodriver.data.model.api.response.dashboard.Order
import com.app.basketiodriver.data.model.api.response.general.SimpleResponse
import com.app.basketiodriver.data.model.api.response.order.CommonResponse
import com.app.basketiodriver.data.model.api.response.order.ReplacementOrdersItemRequest
import com.app.basketiodriver.data.model.api.response.order.SimilarProduct
import com.app.basketiodriver.databinding.ActivityItemDetailsBinding
import com.app.basketiodriver.di.Navigators
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.app.basketiodriver.ui.dashbaord.StoreInstructionsActivity
import com.app.basketiodriver.ui.dialogs.AmountDialogFragment
import com.app.basketiodriver.ui.dialogs.CanNotFindItemDialogFragment
import com.app.basketiodriver.ui.dialogs.FlagItemDialogFragment
import com.app.basketiodriver.ui.dialogs.IncorrectItemDialogFragment
import com.app.basketiodriver.ui.dialogs.MessageBottomSheetFragment
import com.app.basketiodriver.ui.order.product.ScanItem.Companion.ITEM_AMOUNT
import com.app.basketiodriver.ui.order.product.ScanItem.Companion.ITEM_WEIGHT
import com.app.basketiodriver.ui.order.product.adapter.ProductQuestionAdapter
import com.app.basketiodriver.utils.AppConstants
import com.app.basketiodriver.utils.GlideApp
import com.app.basketiodriver.utils.MessageEvent
import com.app.basketiodriver.utils.price.PriceConstructor
import com.app.basketiodriver.utils.price.PriceConstructorNew
import com.google.gson.Gson
import com.google.gson.JsonElement
import com.google.gson.reflect.TypeToken
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
//import kotlinx.android.synthetic.main.app_bar_with_message.view.*
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.lang.reflect.Type
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.*
import javax.inject.Inject

class ItemDetails : BaseActivity<ActivityItemDetailsBinding, OrderDetailsViewModel>() , HasAndroidInjector, AmountDialogFragment.AmountDialogOnClickListener {

    override val layoutId: Int
        get() = R.layout.activity_item_details

    override val viewModel: OrderDetailsViewModel
        get() {
            return getViewModel(OrderDetailsViewModel::class.java)
        }

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    var symbols: DecimalFormatSymbols = DecimalFormatSymbols(Locale.US)
    var formatter: DecimalFormat = DecimalFormat("#.## x", symbols)

    // Properties
    var orderId : Long = 0
    var item : OrdersItem? = null
    var phoneNumber : String = ""
    var info : CustomerInfo? = null

    // Express store
    var isExpress : Int = 0

    private var isImageOpen = false
    private var isChatOpen  = false
    private var isFlagOpen  = false
    private var isFoundItem = false

    private var productQuestionAdapter = ProductQuestionAdapter()
    private var taxPercent: Double = 0.0
    var scannedBarCode: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (intent.extras != null){
            // get order id
            orderId = intent.getLongExtra("ARG_ORDER_ID", 0)

            // phone number
            phoneNumber = intent.getStringExtra("KEY_USER_MOBILE") ?: ""

            // customer info
            info = intent.extras!!.getSerializable("ARG_INFO") as? CustomerInfo

            // order item
            item = intent.extras!!.getSerializable("KEY_ITEM_DETAIL") as? OrdersItem

            // express store
            isExpress = intent.getIntExtra("ARG_IS_EXPRESS", 0)
        }

        // Init toolbar
        initToolBar()

        // Set OnClickListener
        setListeners()

        // Display the product details
        setDataToView()

        // Check if there are additional questions from customer
        checkCustomerQuestions(item?.customAdditionalQuestion ?: "")
    }

    override fun onDestroy() {
        super.onDestroy()
    }


    // Initialize the Toolbar
    private fun initToolBar(){

        var itemTitle = item?.productName ?: getString(R.string.item_details)
        itemTitle = itemTitle.replace("\r\n", " ")

        initToolbar(itemTitle,
            true, viewDataBinding!!.layoutToolBar.toolbar,
            View.OnClickListener {
                run {
                    finish()
                }
            })

        try{
            if (isExpress == 1){
                viewDataBinding!!.layoutToolBar.supportLayout.visibility = View.GONE
                viewDataBinding!!.msgLayout.visibility = View.GONE
            }
            else{
                viewDataBinding!!.layoutToolBar.supportLayout.visibility = View.VISIBLE
                viewDataBinding!!.msgLayout.visibility = View.GONE // View.VISIBLE
            }
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    private fun setListeners(){
        // Can't find item
        viewDataBinding!!.itemNotAvailableButton.setOnClickListener {
            try{
                val canNotFindDialog = CanNotFindItemDialogFragment.newInstance(item!!, info!!, orderId, viewModel.replaceLimitCount)
                canNotFindDialog.show(supportFragmentManager, CanNotFindItemDialogFragment.javaClass.name)
            }
            catch (e : Exception){
                e.printStackTrace()
            }
        }

        // flag the item
//        viewDataBinding!!.txtFlagItem.setOnClickListener {
//
//        }

        // Bottom sheet message
        viewDataBinding!!.msgLayout.setOnClickListener {
            try {
                val bottomMessageFragment = MessageBottomSheetFragment.newInstance(item!!, orderId)
                bottomMessageFragment.show(supportFragmentManager, MessageBottomSheetFragment.javaClass.name)
            }
            catch (e : Exception){
                e.printStackTrace()
            }
        }

        // Zoom image
        viewDataBinding!!.imgZoom.setOnClickListener {
            if (!isImageOpen){
                isImageOpen = true
                // Go to ZoomImageActivity
                Navigators.goToZoomImageActivity(this, item?.productImage ?: "")
            }
        }

        // Tap the product image
        viewDataBinding!!.orderItemImage.setOnClickListener {
            if (!isImageOpen){
                isImageOpen = true
                // Go to ZoomImageActivity
                Navigators.goToZoomImageActivity(this, item?.productImage ?: "")
            }
        }

        viewDataBinding!!.scanButton.setOnClickListener {
            // Go to ScanItemActivity
             scanProduct()
        }

        // Go to Chat activity
        viewDataBinding!!.layoutToolBar.supportLayout.setOnClickListener {
            // Go to ChatActivity
            /////////////////////
            Navigators.gotoChatActivity(
                this,
                orderId,
                PreferenceManager.getCustomerId(orderId.toString()) ?: "",
                info?.name ?: "",
                info?.image ?: ""
            )
        }

        // Instruction Checkbox
        viewDataBinding!!.noteCB.setOnCheckedChangeListener { button, isChecked ->
            if (isChecked){
                viewDataBinding!!.errorMessageTV.visibility = View.GONE
            }
            else{
                viewDataBinding!!.errorMessageTV.visibility = View.GONE // View.VISIBLE
                Toast.makeText(this, R.string.check_customer_note, Toast.LENGTH_SHORT).show()
            }
        }

        // Flag Item
        viewDataBinding!!.flagItem.setOnClickListener {
            val flagItemDialog = FlagItemDialogFragment.newInstance(orderId)
            flagItemDialog.show(supportFragmentManager, FlagItemDialogFragment.javaClass.name)
        }
        viewDataBinding!!.canNotScanItem.setOnClickListener {
            openItemNotFound()
        }
    }

    private fun setDataToView(){
        // product image
        if (item?.productImage != null){
            GlideApp.with(this).load(item?.productImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(viewDataBinding!!.orderItemImage)
        }

        // product name
        var itemTitle = item?.productName ?: ""
        itemTitle = itemTitle.replace("\r\n", " ")
        viewDataBinding!!.orderItemTitle.text = itemTitle

//        val customerOptions = item?.customAdditionalQuestion ?: ""
//        if (customerOptions.isEmpty()) {
//            viewDataBinding!!.rlSize.visibility        = View.VISIBLE
//            viewDataBinding!!.flagItem.visibility      = View.VISIBLE
//            viewDataBinding!!.expDate.visibility       = View.VISIBLE
//            viewDataBinding!!.rlQty.visibility         = View.VISIBLE
//            viewDataBinding!!.rlUpc.visibility         = View.VISIBLE
//            viewDataBinding!!.rlLocation.visibility    = View.VISIBLE
//            viewDataBinding!!.llShopperNote.visibility = View.VISIBLE
//            viewDataBinding!!.msgLayout.visibility     = View.VISIBLE
//        }
//        else{
//            viewDataBinding!!.rlSize.visibility        = View.GONE
//            viewDataBinding!!.flagItem.visibility      = View.GONE
//            viewDataBinding!!.expDate.visibility       = View.GONE
//            viewDataBinding!!.rlQty.visibility         = View.GONE
//            viewDataBinding!!.rlUpc.visibility         = View.GONE
//            viewDataBinding!!.rlLocation.visibility    = View.GONE
//            viewDataBinding!!.llShopperNote.visibility = View.GONE
//            viewDataBinding!!.msgLayout.visibility     = View.GONE
//        }

        viewDataBinding!!.rlSize.visibility        = View.VISIBLE
        viewDataBinding!!.flagItem.visibility      = View.VISIBLE
        viewDataBinding!!.expDate.visibility       = View.GONE
        viewDataBinding!!.rlQty.visibility         = View.VISIBLE
        viewDataBinding!!.rlUpc.visibility         = View.VISIBLE
        viewDataBinding!!.rlLocation.visibility    = View.VISIBLE
        viewDataBinding!!.llShopperNote.visibility = View.VISIBLE
        viewDataBinding!!.msgLayout.visibility     = View.VISIBLE

        // Quantity
        if (item?.quantityDifference == 1){
            viewDataBinding!!.txtQuantity.text = formatter.format(item?.actualQty)
        }
        else if (item?.replacementRequested != null && item?.replacementRequested == 1){
            viewDataBinding!!.txtQuantity.text = formatter.format(item?.actualQty)
        }
        else{
            viewDataBinding!!.txtQuantity.text = formatter.format(item?.itemQty ?: 1)
        }

        viewDataBinding!!.orderCost.text = Html.fromHtml(PriceConstructorNew.getFormatPrice(item!!, PriceConstructor.LabelType.SIMPLE, true))

        // UPC
        viewDataBinding!!.txtUpc.text = item?.upc

        // Location
        var location : String = ""
        if (item?.masterLocationName != null && item?.masterLocationName != ""){
            location += item?.masterLocationName + " - "
        }

        if (item?.locationName != null && item?.locationName != ""){
            location += item?.locationName + " - "
        }

        if (item?.subLocationName != null && item?.subLocationName != ""){
            location += item?.subLocationName
        }

        if (location.isEmpty()) location = "N/A"
        viewDataBinding!!.orderItemLocation.text = location

        // Price
        viewDataBinding!!.txtPrice.text = Html.fromHtml(PriceConstructorNew.getFormatPrice(item!!, PriceConstructor.LabelType.SIMPLE, true))

        // Size
        viewDataBinding!!.tvSize.text = item?.getDescriptionLabel()

        if (item?.getDescriptionLabel() != ""){
            viewDataBinding!!.tvPriceDescription.visibility = View.VISIBLE
            viewDataBinding!!.rlSize.visibility = View.VISIBLE
            viewDataBinding!!.sizeUnderline.visibility = View.VISIBLE
            viewDataBinding!!.tvPriceDescription.text = item?.getDescriptionLabelNew()
        }
        else{
            viewDataBinding!!.tvPriceDescription.visibility = View.GONE
            viewDataBinding!!.rlSize.visibility = View.GONE
            viewDataBinding!!.sizeUnderline.visibility = View.GONE
        }

        // Shopper Tips
        if (item?.shopperTips != null && item?.shopperTips != ""){
            viewDataBinding!!.txtShopperTip.text = item?.shopperTips
            viewDataBinding!!.llShopperTip.visibility = View.VISIBLE
        }
        else{
            viewDataBinding!!.llShopperTip.visibility = View.GONE
        }

        // Shopper Note
        if (item?.customerItemNotes != null && item?.customerItemNotes != ""){
            viewDataBinding!!.txtShopperNote.text = item?.customerItemNotes
            viewDataBinding!!.llShopperNote.visibility = View.VISIBLE
            viewDataBinding!!.errorMessageTV.visibility = View.VISIBLE
        }
        else{
            viewDataBinding!!.llShopperNote.visibility = View.GONE
            viewDataBinding!!.errorMessageTV.visibility = View.GONE
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun checkCustomerQuestions(customAdditionalProduct: String) {
        if (customAdditionalProduct != "") {

            viewDataBinding?.rvQuestions?.visibility = View.VISIBLE

            // Check if this json string is valid json format
            if (isValid(customAdditionalProduct)) {
                val questionElement: JsonElement = Gson().fromJson(customAdditionalProduct, JsonElement::class.java)

                val questionList: MutableList<AdditionalRequestItem>
                val listType: Type = object : TypeToken<List<AdditionalRequestItem?>?>() {}.type
                questionList = Gson().fromJson(questionElement, listType)

                val sortedQuestionList: MutableList<AdditionalRequestItem> = ArrayList()
                questionList.sortBy { it.rank }

                for (question in questionList){
                    val answers : List<Answer> = question.answers
                    val selectedAnswers : MutableList<Answer> = ArrayList<Answer>()
//                    val updatedAnswers :MutableList<Answer>  =  ArrayList<Answer>()

                    for (answer in answers) {
                        if (answer.selected) {
                            selectedAnswers.add(answer)
                        }
                    }
                    question.answers = selectedAnswers
                    if (selectedAnswers.isNotEmpty()){
                        sortedQuestionList.add(question)
                    }
                }

                viewDataBinding?.rvQuestions?.adapter = productQuestionAdapter
                viewDataBinding?.rvQuestions?.isNestedScrollingEnabled = false
                viewDataBinding?.rvQuestions?.layoutManager = LinearLayoutManager(this@ItemDetails, LinearLayoutManager.VERTICAL, false)
                productQuestionAdapter.taxPercent = taxPercent


                productQuestionAdapter.setItems(sortedQuestionList)
                productQuestionAdapter.notifyDataSetChanged()
            }
            else {
            viewDataBinding?.rvQuestions?.visibility = View.GONE
            }
        } else {
           viewDataBinding?.rvQuestions?.visibility = View.GONE
        }
    }

    private fun isValid(json: String): Boolean {
        try {
            JSONObject(json)
        } catch (e: JSONException) {
            try {
                JSONArray(json)
            } catch (ne: JSONException) {
                return false
            }
        }
        return true
    }

    // Scan the product item
    private fun scanProduct(){
        if (!isFoundItem){
            isFoundItem = true

            if (viewDataBinding!!.errorMessageTV.visibility == View.VISIBLE){
                if (viewDataBinding!!.noteCB.isChecked) {
                    // Go to scan page
//                    Navigators.goToScanItemActivity(this, item!!, true, info!!, SCAN_ACTIVITY, 0, isExpress)
                    // start new scanning library
                    startScanner()

                }
                else{
                    isFoundItem = false
                    Toast.makeText(this, R.string.check_customer_note, Toast.LENGTH_SHORT).show()
                }
            }
            else{
                if (item?.upcType == 2 || item?.item_type == 2){
                    // Show the amount dialog
                    showAmountDialog()
                }
                else{
                    // Go to scan page
//                    Navigators.goToScanItemActivity(this, item!!, true, info!!, SCAN_ACTIVITY, orderId, isExpress)
                    startScanner()
                }
            }
        }
    }
    private fun startScanner(){
        BasketScanner.scan(onSuccess = {
            scannedBarCode = it
            runOnUiThread {
                checkBarcode(it)
            }
        }, onCanceled = {}, onEmptyResult = {}, onFailure = {
            Toast.makeText(this@ItemDetails, it.message + "", Toast.LENGTH_LONG).show()
        })
    }

    // Check the barcode
    private fun checkBarcode(barcode: String) {
         viewModel.checkBarcode(item!!.ordersOutletsItemsId ?: 0, barcode, 0, 0, object :
            HandleResponse<CommonResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                 Toast.makeText(this@ItemDetails, error?.message, Toast.LENGTH_SHORT).show()
            }

            override fun handleSuccessResponse(successResponse: CommonResponse) {
                 val response = successResponse.data

                if (successResponse != null) {
                    Toast.makeText(this@ItemDetails, successResponse.message, Toast.LENGTH_SHORT)
                        .show()

                    if (successResponse.status == 200) {

                        // Show the amount dialog
                        showAmountDialog()
                    } else if (successResponse.status == 402 && response != null) {
                        val gson = Gson()
                        val item: SimilarProduct = gson.fromJson(
                            response.asJsonArray[0],
                            SimilarProduct::class.java
                        )
                        showIncorrectItem(item)
                    } else if (successResponse.status == 400) {
                        openItemNotFound()
                    } else {
                        openItemNotFound()
                    }
                } else {
                    Toast.makeText(this@ItemDetails, R.string.error_check_barcode, Toast.LENGTH_SHORT)
                        .show()
                }
            }
        })
    }

    // Open the item not found
    private fun openItemNotFound() {
        // Open the CameraActivity
        val intent = Intent(this, OpenCameraActivity::class.java)
        if (item != null) {
            intent.putExtra("ARG_ORDER_ITEM", item!!)
        }

        intent.putExtra("ARG_ORDER_ID", orderId)
        intent.putExtra("ARG_BAR_CODE", scannedBarCode)
        startActivityForResult(intent, ScanItem.OPEN_CAMERA_ACTIVITY_REQ)
    }
    // Show the IncorrectItem Dialog
    private fun showIncorrectItem(product: SimilarProduct) {
        try {
            // Show the IncorrectItemDialogFragment
            val incorrectFragment = IncorrectItemDialogFragment.newInstance(product, item!!)
            incorrectFragment.show(
                supportFragmentManager,
                IncorrectItemDialogFragment.javaClass.name
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


    private fun showAmountDialogCantscan() {
        try {
            if (item!!.upcType == 1 && item!!.itemQty != null && item!!.itemQty == 1.0) { //
                // No need to show the amount dialog
//                foundResult(1.0)
                updateStatus(true, 1.0)
            } else {
                gotoAmountWeightPopup()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    private fun gotoAmountWeightPopup() {
        val amountDialog = AmountDialogFragment.newInstance(item!!, item!!.actualQty)
        amountDialog.show(supportFragmentManager, AmountDialogFragment.javaClass.name)
        amountDialog.setAmountNextClickListener(this)
    }

    private fun showAmountDialog(){
        try{
            val amountDialog = AmountDialogFragment.newInstance(item!!, item!!.actualQty)
            amountDialog.show(supportFragmentManager, AmountDialogFragment.javaClass.name)
            amountDialog.setAmountNextClickListener(this)
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    private fun updateStatus(isFound : Boolean, amount : Double){
        if (item!!.replacementRequested != null && item!!.replacementRequested == 1){ // Replacement
            if (isFound){
                confirmReplacedItem(item!!.ordersOutletsItemsId ?: 0, amount)
            }
            else{
                cancelReplaced(item!!.ordersOutletsItemsId ?: 0)
            }
        }
        else if (item!!.quantityDifference == 1) {
            if (isFound){
                if ((item!!.itemQty ?: 0) == amount){
                    markAsFound(item!!.ordersOutletsItemsId ?: 0, true)
                }
                else{
                    changeItemCount(item!!.ordersOutletsItemsId ?: 0, amount)
                }
            }
            else{
                cancelQtyDiff(item!!.ordersOutletsItemsId ?: 0)
            }
        }
        else{
            if (isFound){
                if ((item!!.itemQty ?: 0) == amount){
                    markAsFound(item!!.ordersOutletsItemsId ?: 0, true)
                }
                else{
                    changeItemCount(item!!.ordersOutletsItemsId ?: 0, amount)
                }
            }
            else{
                markAsFound(item!!.ordersOutletsItemsId ?: 0, false)
            }
        }
    }

    private fun updateApproxWeight(amount: Double, weight: Double){
        viewModel.updateItemWeight(item!!.ordersOutletsItemsId ?: 0, weight, amount, object : HandleResponse<SimpleResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Toast.makeText(this@ItemDetails, error?.message, Toast.LENGTH_LONG).show()
                }
                else{
                    Toast.makeText(this@ItemDetails, resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }
            }

            override fun handleSuccessResponse(successResponse: SimpleResponse) {
                val response = successResponse.response
                if (response != null){

                    if (response.httpCode == 200){
                        Toast.makeText(this@ItemDetails, response.message, Toast.LENGTH_SHORT).show()
                        updateStatus(true, amount)
                    }
                    else{
                        Toast.makeText(this@ItemDetails, response.message, Toast.LENGTH_SHORT).show()
                    }
                }
                else{
                    Toast.makeText(this@ItemDetails, R.string.error_server_return_null, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    /**
     * Cancel the quantity difference
     */
    private fun cancelQtyDiff(itemId : Long){
        viewModel.cancelItemQtyDiff(itemId, object : HandleResponse<SimpleResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Toast.makeText(this@ItemDetails, error?.message, Toast.LENGTH_LONG).show()
                }
                else{
                    Toast.makeText(this@ItemDetails, resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }            }

            override fun handleSuccessResponse(successResponse: SimpleResponse) {
                val response = successResponse.response
                if (response != null){

                    Toast.makeText(this@ItemDetails, response.message, Toast.LENGTH_SHORT).show()

                    if (response.httpCode == 200){
                        finish()
                    }
                }
                else{
                    Toast.makeText(this@ItemDetails, R.string.error_server_return_null, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    /**
     * change the item amount
     */
    private fun changeItemCount(itemId : Long, amount: Double){
        viewModel.updateItemQuantity(itemId, amount, object : HandleResponse<SimpleResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Toast.makeText(this@ItemDetails, error?.message, Toast.LENGTH_LONG).show()
                }
                else{
                    Toast.makeText(this@ItemDetails, resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }            }

            override fun handleSuccessResponse(successResponse: SimpleResponse) {
                val response = successResponse.response
                if (response != null){

                    if (response.httpCode == 200){
                        Toast.makeText(this@ItemDetails, R.string.quantity_changed_customer_notified, Toast.LENGTH_SHORT).show()
                        finish()
                    }
                    else{
                        Toast.makeText(this@ItemDetails, response.message, Toast.LENGTH_SHORT).show()
                    }
                }
                else{
                    Toast.makeText(this@ItemDetails, R.string.error_server_return_null, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    /**
     * Mark as found
     */
    private fun markAsFound(itemId: Long, isFound : Boolean){
        viewModel.markAsFound(itemId, isFound, false, object : HandleResponse<SimpleResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Toast.makeText(this@ItemDetails, error?.message, Toast.LENGTH_LONG).show()
                }
                else{
                    Toast.makeText(this@ItemDetails, resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }            }

            override fun handleSuccessResponse(successResponse: SimpleResponse) {
                val response = successResponse.response
                if (response != null){
                    Toast.makeText(this@ItemDetails, response.message, Toast.LENGTH_SHORT).show()

                    if (response.httpCode == 200){
                        setResult(7)
                        finish()
                    }
                }
                else{
                    Toast.makeText(this@ItemDetails, R.string.error_server_return_null, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    /**
     * Cancel the replaced item
     */
    private fun cancelReplaced(itemId: Long){
        viewModel.cancelReplacedItem(itemId, object : HandleResponse<SimpleResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Toast.makeText(this@ItemDetails, error?.message, Toast.LENGTH_LONG).show()
                }
                else{
                    Toast.makeText(this@ItemDetails, resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }            }

            override fun handleSuccessResponse(successResponse: SimpleResponse) {
                val response = successResponse.response
                if (response != null){
                    Toast.makeText(this@ItemDetails, response.message, Toast.LENGTH_SHORT).show()

                    if (response.httpCode == 200){
                        finish()
                    }
                }
                else{
                    Toast.makeText(this@ItemDetails, R.string.error_server_return_null, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    /**
     * Confirm the replaced item
     */
    private fun confirmReplacedItem(itemId : Long, qty : Double){
        viewModel.confirmReplacedItem(itemId, qty, object : HandleResponse<SimpleResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Toast.makeText(this@ItemDetails, error?.message, Toast.LENGTH_LONG).show()
                }
                else{
                    Toast.makeText(this@ItemDetails, resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }            }

            override fun handleSuccessResponse(successResponse: SimpleResponse) {
                val response = successResponse.response
                if (response != null){
                    Toast.makeText(this@ItemDetails, response.message, Toast.LENGTH_SHORT).show()

                    if (response.httpCode == 200){
                        finish()
                    }
                }
                else{
                    Toast.makeText(this@ItemDetails, R.string.error_server_return_null, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    /**
     * Get shopper orders
     */
    fun queryShopperOrders(){
        viewModel.shopperOrderDetailRequest(orderId.toString(), "1", object : HandleResponse<ShopperOrderDetail>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Toast.makeText(this@ItemDetails, error?.message, Toast.LENGTH_LONG).show()
                }
                else{
                    Toast.makeText(this@ItemDetails, resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }
            }

            override fun handleSuccessResponse(successResponse: ShopperOrderDetail) {
                val response = successResponse.response
                if (response != null){
                    if (response.httpCode == 200){
                        // Save the customer info
                        PreferenceManager.setCustomerId(orderId.toString(), response.outletOrder!!.userId ?: "0")
                        PreferenceManager.setCustomerName(orderId.toString(), response.outletOrder!!.userFirstName ?: "")
                        PreferenceManager.setCustomerImage(orderId.toString(), response.outletOrder!!.userImage)

                        // Finish activity
                        setResult(8)
                        finish()
                    }
                    else{
                        Toast.makeText(this@ItemDetails, response.message, Toast.LENGTH_SHORT).show()
                    }
                }
                else{
                    Toast.makeText(this@ItemDetails, getString(R.string.error_load_shopper_detail), Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    /**
     * AmountDialog Listener
     */
    override fun onNextClick(requestItems : ArrayList<ReplacementOrdersItemRequest>){

    }

    override fun onNextClick(amount: Double) {
        updateStatus(true, amount)
    }

    override fun onNextClick(itemId: Long, amount: Double) {

    }

    override fun onNextClick(amount: Double, weight: Double) {
        updateApproxWeight(amount, weight)
    }

    override fun onNextClick(itemId: Long, amount: Double, weight: Double) {

    }

    override fun onStart() {
        super.onStart()

        isImageOpen = false
        isChatOpen = false
        isFlagOpen = false
        isFoundItem = false
    }

    override fun onResume() {
        super.onResume()

        isImageOpen = false
        isChatOpen = false
        isFlagOpen = false
        isFoundItem = false
    }

    /**
     * ActivityResult
     */
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        // Found item -> Scan Item
        if (requestCode == SCAN_ACTIVITY){
            if (resultCode == RESULT_OK) {
                if (data != null && data.hasExtra(ITEM_AMOUNT)){
                    if (data.hasExtra(ITEM_WEIGHT)){
                        updateApproxWeight(data.getDoubleExtra(ITEM_AMOUNT, 0.0), data.getDoubleExtra(ITEM_WEIGHT, 0.0))
                    }
                    else{
                        updateStatus(true, data.getDoubleExtra(ITEM_AMOUNT, 0.0))
                    }
                }
                else{
                    Toast.makeText(this, R.string.error_amount, Toast.LENGTH_SHORT).show()
                }
            }
            else if (resultCode == RESULT_FIRST_USER) {
                updateStatus(false, 0.0)

            }
        }

        // Can't find item -> Replace items
        if (requestCode == REPLACE_ITEM) {
            if (resultCode == RESULT_OK) {
                setResult(RESULT_OK)
                finish()
            }
            else if (resultCode == 8) {
                setResult(8)
                finish()
            }
        }
        if (requestCode == ScanItem.OPEN_CAMERA_ACTIVITY_REQ) {
            if (resultCode == RESULT_OK) {
                // Show the amount dialog
                showAmountDialog()
            }
        }

        super.onActivityResult(requestCode, resultCode, data)
    }

    companion object {
        const val SCAN_ACTIVITY = 234
        const val REPLACE_ITEM  = 17
    }
}