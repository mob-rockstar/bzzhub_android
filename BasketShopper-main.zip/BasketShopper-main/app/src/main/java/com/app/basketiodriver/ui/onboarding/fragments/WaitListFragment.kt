package com.app.basketiodriver.ui.onboarding.fragments


import android.os.Bundle
import android.view.View
import androidx.navigation.Navigation
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentWaitListBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.onboarding.OnBoardingViewModel


/**
 * Created by ibraheem lubbad on 2020-01-22.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class WaitListFragment : BaseFragment<FragmentWaitListBinding?, OnBoardingViewModel>(),
    View.OnClickListener,
    Injectable {

    override val layoutId: Int
        get() = R.layout.fragment_wait_list

    override val viewModel: OnBoardingViewModel
        get() {
            return getViewModel(requireActivity(), OnBoardingViewModel::class.java)
        }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.youre_on_our_waitlist))

        viewDataBinding!!.btnChangeRole.setOnClickListener(this)
        viewDataBinding!!.ivMessage.setOnClickListener(this)

    }

    override fun onClick(p0: View?) {

        when (p0!!.id) {
            R.id.btnChangeRole -> {
                Navigation.findNavController(view!!).popBackStack()
            }
         /*   R.id.ivMessage -> {
                navigate(WaitListFragmentDirections.actionWaitListFragmentToAdditionalInfoFragment())
            }*/
        }
    }



}
