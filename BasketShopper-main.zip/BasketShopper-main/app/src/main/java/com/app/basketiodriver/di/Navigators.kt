package com.app.basketiodriver.di

import android.app.Activity
import android.content.Intent
import com.app.basketiodriver.data.model.api.response.checkout.CustomerInfo
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.model.api.response.checkout.OutletOrder
import com.app.basketiodriver.data.model.api.response.dashboard.Order
import com.app.basketiodriver.data.model.api.response.order.Product
import com.app.basketiodriver.data.model.api.response.order.ProductItem
import com.app.basketiodriver.data.model.api.response.order.SimilarProduct
import com.app.basketiodriver.ui.chat.ChatActivity
import com.app.basketiodriver.ui.checkout.card.CheckoutCardActivity
import com.app.basketiodriver.ui.checkout.handover.HandOverActivity
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsActivity
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsActivity.Companion.REQ_DETAIL_PAGE
import com.app.basketiodriver.ui.checkout.payment.PaymentActivity
import com.app.basketiodriver.ui.checkout.receipt.ReceiptInfoActivity
import com.app.basketiodriver.ui.checkout.receipt.UploadReceiptInfoActivity
import com.app.basketiodriver.ui.checkout.scan.ScanditActivity
import com.app.basketiodriver.ui.dashbaord.StoreInstructionsActivity
import com.app.basketiodriver.ui.dashbaord.map.LocationMapActivity
import com.app.basketiodriver.ui.home.HomeActivity
import com.app.basketiodriver.ui.order.ArrivedToCustomerActivity
import com.app.basketiodriver.ui.order.StagingOrderActivity
import com.app.basketiodriver.ui.order.product.*
import com.app.basketiodriver.ui.order.product.ItemDetails.Companion.REPLACE_ITEM
import com.app.basketiodriver.ui.order.product.ItemDetails.Companion.SCAN_ACTIVITY
import com.app.basketiodriver.ui.order.product.ScanReplaceActivity.Companion.REPLACE_ITEM_REQUEST
import com.app.basketiodriver.ui.order.review.DashboardOrderInfoActivity
import com.app.basketiodriver.ui.order.review.HistoryOrderInfoActivity
import com.app.basketiodriver.utils.AppConstants


object Navigators {
    fun goToOrderDetails(activity : Activity, orderId : Long){
        val intent = Intent(activity, OrderDetailsActivity::class.java)
        intent.putExtra("KEY_ORDER_OUTLET_ID", orderId)
        activity.startActivity(intent)
    }

    fun goToLockOrderDetails(activity : Activity, orderId : Long, orderStatus : Int){
        val intent = Intent(activity, OrderDetailsActivity::class.java)
        intent.action = "ACTION_GO_TO_LOCK_ORDER_DETAILS"
        intent.putExtra("KEY_ORDER_OUTLET_ID", orderId)
        intent.putExtra("KEY_ORDER_STATUS", orderStatus)
        activity.startActivity(intent)
    }

    fun goToPaymentTypeActivity(activity : Activity, orderId : Long){
        val intent = Intent(activity, CheckoutCardActivity::class.java)
        intent.putExtra("KEY_ORDER_OUTLET_ID", orderId)
        activity.startActivity(intent)
//        activity.finish()
    }

    fun goToReceiptInfoActivity(activity : Activity, orderId : Long, price : Double){
        val intent = Intent(activity, ReceiptInfoActivity::class.java)
        intent.putExtra("KEY_ORDER_OUTLET_ID", orderId)
        intent.putExtra("KEY_ORDER_SUBTOTAL", price)
        activity.startActivity(intent)
//        activity.finish()
    }

    // Upload the receipt info
    fun goToReceiptCheckActivity(activity : Activity, orderId : Long, receiptNo : String){
        val intent = Intent(activity, UploadReceiptInfoActivity::class.java)
        intent.putExtra("ARG_RECEIPT_NO", receiptNo)
        intent.putExtra("ARG_ORDER_ID", orderId)
        activity.startActivity(intent)
    }

    // Go to location map page
    fun goToLocationMap(activity : Activity, orderId : Long, isExpress: Int){
        val intent = LocationMapActivity.newIntent(activity)
        intent.putExtra("ARG_ORDER_ID", orderId)
        intent.putExtra("ARG_IS_EXPRESS", isExpress)
        activity.startActivity(intent)
    }

    fun gotoHandOver(activity : Activity, orderId : Long, orderOutletId : Long){
        val intent = Intent(activity, HandOverActivity::class.java)
        intent.putExtra("ARG_ORDER_OUTLET_ID", orderOutletId)
        intent.putExtra("ARG_ORDER_ID", orderId)
        activity.startActivity(intent)
    }

    // Go to Dashboard
    fun goToDashboard(activity : Activity){
        val intent = HomeActivity.newIntent(activity)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        activity.startActivity(intent)
//        activity.finish()
    }

    // Go to Dashboard
    fun goToDashboardWithCongratulation(activity: Activity, congratulationOrderId : Long){
        val intent = HomeActivity.newIntent(activity)
        intent.setAction("Action_Congratulation")
        intent.putExtra("ARG_ORDER_ID", congratulationOrderId)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        activity.startActivity(intent)
    }

    // Go to Checkout (Payment)
    fun goToConfirmTotalActivity(activity: Activity, order : OutletOrder, price : Double, paymentGateway : Int){
        // Go to payment activity
        val intent = Intent(activity, PaymentActivity::class.java)
        intent.putExtra("KEY_SUBTOTAL", price)
        intent.putExtra("ARG_ORDER", order)
        intent.putExtra("KEY_PAYMENT_GATEWAY", paymentGateway)
        activity.startActivity(intent)
        activity.finish()
    }

    fun gotoOrderInfoActivity(activity: Activity, orderId : Long, status : Int, orderInfo : Order){
        val intent = Intent(activity, if (status > 12) HistoryOrderInfoActivity::class.java else DashboardOrderInfoActivity::class.java)
        intent.putExtra("KEY_ORDER_ID", orderId)
        intent.putExtra("KEY_ORDER_DETAIL", orderInfo)
        activity.startActivity(intent)
    }

    // Go to product dashboard activity
    fun goToProductDashboardActivity(activity: Activity, list: ArrayList<ProductItem>){
        val intent = Intent(activity, ProductDashboardActivity::class.java)
//        intent.putExtra("ARG_ITEMS_ARRAY", list)
        AppConstants.dashboardProductList = list
        activity.startActivity(intent)
    }

    // Go to products activity
    fun goToProductsActivity(activity: Activity, list: ArrayList<Product>){
        val intent = Intent(activity, ProductsActivity::class.java)
//        intent.putExtra("ARG_ITEMS_ARRAY", list)
        AppConstants.historyProductList = list
        activity.startActivity(intent)
    }

    // Go to product details
    fun goToCustomItemDetailsActivity(activity: Activity, item : OrdersItem, mobile : String, info : CustomerInfo, orderId : Long, isExpress : Int){
        val intent = Intent(activity, ItemDetails::class.java)
        intent.putExtra("KEY_ITEM_DETAIL", item)
        intent.putExtra("KEY_USER_MOBILE", mobile)
        intent.putExtra("ARG_INFO", info)
        intent.putExtra("ARG_ORDER_ID", orderId)
        intent.putExtra("ARG_IS_EXPRESS", isExpress)

        activity.startActivityForResult(intent, REQ_DETAIL_PAGE)
    }

    fun goToItemDetailsActivity(activity: Activity, item : OrdersItem, mobile : String, info : CustomerInfo, orderId : Long, isExpress : Int){
        val intent = Intent(activity, ItemDetails::class.java)
        intent.putExtra("KEY_ITEM_DETAIL", item)
        intent.putExtra("KEY_USER_MOBILE", mobile)
        intent.putExtra("ARG_INFO", info)
        intent.putExtra("ARG_ORDER_ID", orderId)
        intent.putExtra("ARG_IS_EXPRESS", isExpress)

        activity.startActivityForResult(intent, REQ_DETAIL_PAGE)
    }

    // Go to Image FullScreen
    fun goToZoomImageActivity(activity: Activity, imageURL : String){
        val intent = Intent(activity, ZoomImageActivity::class.java)
        intent.putExtra("ARG_URL", imageURL)
        activity.startActivity(intent)
    }

    // Go to ScanItemActivity
    fun goToScanItemActivity(activity: Activity, item : OrdersItem, autoFocus : Boolean, info : CustomerInfo, resultCode : Int, orderId : Long, isExpress : Int){
        val intent = Intent(activity, ScanItem::class.java)
        intent.putExtra("KEY_ITEM_DETAIL", item)
        intent.putExtra("KEY_AUTO_FOCUS", autoFocus)
        intent.putExtra("ARG_INFO", info)
        intent.putExtra("ARG_IS_EXPRESS", isExpress)

        if (orderId != 0L)
            intent.putExtra("ARG_ORDER_ID", orderId)

        activity.startActivityForResult(intent, resultCode)
    }

    // Go to SuggestionProductList
    fun goToSuggestionProductListActivity(activity: Activity, list: ArrayList<SimilarProduct>, orderId: Long, itemId : Long, searchId : Long, qty : Double, ordersItem : OrdersItem, info : CustomerInfo, actionFrom : Int){
        val intent = Intent(activity, BasketSuggestionListActivity::class.java)
        intent.putExtra(BasketSuggestionListActivity.ARG_ITEMS_ARRAY, list)
        intent.putExtra(BasketSuggestionListActivity.ARG_ORDER_ID, orderId)
        intent.putExtra(BasketSuggestionListActivity.ARG_ITEM_ID, itemId)
        intent.putExtra(BasketSuggestionListActivity.ARG_SEARCH_ID, searchId)
        intent.putExtra(BasketSuggestionListActivity.ARG_ORIGINAL_ITEM_QTY, qty)
        intent.putExtra(BasketSuggestionListActivity.ARG_ORDER_ITEM, ordersItem)
        intent.putExtra(BasketSuggestionListActivity.ARG_INFO, info)
        intent.putExtra(BasketSuggestionListActivity.ACTION_FROM, actionFrom)
        activity.startActivityForResult(intent, REPLACE_ITEM)
    }

    // Go to CreateCustomItemActivity
    fun goToAddCustomItemActivity(activity: Activity, barcode : String, orderId: Long){
        val intent = Intent(activity, CreateCustomItemActivity::class.java)
        intent.putExtra("ARG_BARCODE", barcode)
        intent.putExtra("ARG_ORDER_ID", orderId)
        activity.startActivity(intent)
    }

    fun goToReplaceCustomItemActivity(activity: Activity, barcode : String, outletId: Long) {
        val intent = Intent(activity, ReplaceCustomItemActivity::class.java)
        intent.putExtra("ARG_BARCODE", barcode)
        intent.putExtra("ARG_OUTLET_ID", outletId)

        activity.startActivityForResult(intent, REPLACE_ITEM_REQUEST)
    }

    fun goToSearchToAdd(activity: Activity, orderId: Long, itemId: Long){
        val intent = Intent(activity, AddBySearchActivity::class.java)
        intent.putExtra("ARG_ORDER_ID", orderId)
        intent.putExtra("ARG_ITEM_ID", itemId)
        activity.startActivity(intent)
    }

    // Scan the receipt page
    fun goToScanditActivity(activity: Activity, scannerType : String, autoFocus : Boolean){
        val intent = Intent(activity, ScanditActivity::class.java)
        intent.putExtra("KEY_AUTO_FOCUS", autoFocus)
        intent.putExtra("ARG_SCANNER_MODE_TYPE", scannerType)
        activity.startActivityForResult(intent, SCAN_ACTIVITY)
    }

    fun goToArrivedCustomerActivity(activity: Activity, orderId: Long, state : Int, total : Double, isExpress : Int){
        val intent = Intent(activity, ArrivedToCustomerActivity::class.java)
        intent.putExtra("ARG_ORDER_ID", orderId)
        intent.putExtra("ARG_ORDER_STATUS", state)
        intent.putExtra("ARG_TOTAL", total)
        intent.putExtra("ARG_IS_EXPRESS", isExpress)

        activity.startActivity(intent)
    }

    fun goToNewProductListActivity(activity: Activity, list : ArrayList<OrdersItem>){
        val intent = Intent(activity, NewProductListActivity::class.java)
        intent.putExtra("ARG_ITEMS_ARRAY", list)
        activity.startActivity(intent)
    }

    fun gotoChatActivity(activity: Activity, orderId: Long, userId: String, userName: String, userImage: String){
        val intent = Intent(activity, ChatActivity::class.java)
        intent.putExtra("KEY_ORDER_OUTLET_ID", orderId)
        intent.putExtra("KEY_USER_ID", userId)
        intent.putExtra("KEY_USER_NAME", userName)
        intent.putExtra("KEY_USER_IMAGE", userImage)
        activity.startActivity(intent)
    }

    // Go to StagingOrderActivity for shopper type = 2
    fun gotoStageOrder(activity: Activity, order : OutletOrder, orderId: Long){
        val intent = Intent(activity, StagingOrderActivity::class.java)
        intent.putExtra("ARG_ORDER_ID", orderId)
        intent.putExtra("ARG_ORDER", order)
        activity.startActivity(intent)
        activity.finish()
    }

    // Go to Store instruction
    fun gotoStoreInstructions(activity: Activity, instruction : String){
        val intent = Intent(activity, StoreInstructionsActivity::class.java)
        intent.putExtra("store_instruction", instruction)
        activity.startActivity(intent)
    }
}