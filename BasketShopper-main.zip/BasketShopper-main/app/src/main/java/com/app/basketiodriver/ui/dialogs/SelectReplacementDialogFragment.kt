package com.app.basketiodriver.ui.dialogs

import android.os.Bundle
import android.text.Html
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager.VERTICAL
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.databinding.FragmentFlagItemDialogBinding
import com.app.basketiodriver.databinding.FragmentSelectReplacementDialogBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseDialogFragment
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.app.basketiodriver.utils.GlideApp
import com.app.basketiodriver.utils.price.PriceConstructor
import com.app.basketiodriver.utils.price.PriceConstructorNew
import java.text.DecimalFormat

class SelectReplacementDialogFragment : BaseDialogFragment<FragmentSelectReplacementDialogBinding?, OrderDetailsViewModel>(),
    Injectable {

    var orderId : Long = 0
    var item : OrdersItem? = null

    override val layoutId: Int
        get() = R.layout.fragment_select_replacement_dialog

    override val viewModel: OrderDetailsViewModel
        get() {
            return getViewModel(requireActivity(), OrderDetailsViewModel::class.java)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    // Set Full screen
    override fun getTheme(): Int {
        return R.style.MyDialogWhite
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        /**
         * get params
         */
        arguments?.let {
            orderId = it.getLong(KEY_OUTLET_ID)
            item    = it.getSerializable(KEY_ORDERS_ITEM) as? OrdersItem

            initToolbar()
            initViews()
        }
    }

    // Initialize the toolbar
    private fun initToolbar(){
        viewDataBinding!!.layoutToolBar.toolBarTitle.text = getString(R.string.select_replacement)
        viewDataBinding!!.layoutToolBar.btnBack.setOnClickListener {
            dismiss()
        }
    }

    private fun initViews(){
        // Set the layout manager
        val layoutManager = LinearLayoutManager(activity)
        layoutManager.orientation = VERTICAL
        viewDataBinding!!.recyclerView.layoutManager = layoutManager

        // Product image
        if (item!!.productImage != null){
            GlideApp.with(baseActivity).load(item!!.productImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(viewDataBinding!!.productLayout.orderItemImage)
        }

        // Product name
        viewDataBinding!!.productLayout.txtTitle.text = item!!.productName

        if (item!!.getDescriptionLabel().isEmpty()) {
            viewDataBinding!!.productLayout.tvPriceDescription.visibility = View.GONE
        } else {
            viewDataBinding!!.productLayout.tvPriceDescription.visibility = View.VISIBLE
            viewDataBinding!!.productLayout.tvPriceDescription.text = item!!.getDescriptionLabel()
        }

        viewDataBinding!!.productLayout.txtPricePerUnit.text = Html.fromHtml(PriceConstructorNew.getFormatPrice(item, PriceConstructor.LabelType.SIMPLE, true))

        // Click replacement
        viewDataBinding!!.btnReplace.setOnClickListener {
            // Show the replace menu dialog
            showReplaceMenuDialog()
        }
    }

    private fun showReplaceMenuDialog(){

    }

    companion object{
        const val KEY_OUTLET_ID   = "key_outlet_id"
        const val KEY_ORDERS_ITEM = "key_orders_item"

        fun newInstance(ordersItem: OrdersItem, orderId : Long) : SelectReplacementDialogFragment {
            val fragment = SelectReplacementDialogFragment()

            val data = Bundle()
            data.putLong(KEY_OUTLET_ID, orderId)
            data.putSerializable(KEY_ORDERS_ITEM, ordersItem)
            fragment.arguments = data

            return fragment
        }
    }
}