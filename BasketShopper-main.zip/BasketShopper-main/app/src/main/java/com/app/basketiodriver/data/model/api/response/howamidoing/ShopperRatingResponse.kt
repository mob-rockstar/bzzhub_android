package com.app.basketiodriver.data.model.api.response.howamidoing

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class ShopperRatingResponse {
    @SerializedName("data")
    val data: RatingDetailData? = null

    @SerializedName("message")
    val message: String = ""

    inner class RatingDetailData {
        @SerializedName("rating")
        @Expose
        val rating: String? = null

        @SerializedName("total_rating_received")
        @Expose
        val totalRatingReceived: String? = null

        @SerializedName("from_date")
        @Expose
        val fromDate: String? = null

        @SerializedName("to_date")
        @Expose
        val toDate: String? = null

        @SerializedName("reward_amount")
        @Expose
        val rewardAmount: String? = null

        @SerializedName("reward_text")
        @Expose
        val rewardText: String? = null
    }
}