package com.app.basketiodriver.ui.onboarding.fragments.UploadDriverDocument


import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentFrontDocumentBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.cardcamera.camera.IDCardCamera
import com.app.basketiodriver.ui.onboarding.OnBoardingViewModel
import com.app.basketiodriver.utils.AppConstants

/**
 * Created by ibraheem lubbad on 2020-01-22.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class FrontDriverDocmentFragment :
    BaseFragment<FragmentFrontDocumentBinding?, OnBoardingViewModel>(),
    Injectable, View.OnClickListener {

    override val layoutId: Int
        get() = R.layout.fragment_front_document

    override val viewModel: OnBoardingViewModel
        get() {
            return getViewModel(requireActivity(), OnBoardingViewModel::class.java)
        }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.verify_your_driver_license))

        viewDataBinding!!.placeHolder.setImageResource(R.drawable.license)

        viewDataBinding!!.btnTakePhoto.setOnClickListener(this)


    }

    override fun onClick(p0: View?) {
        when (p0!!.id) {
            R.id.btnTakePhoto -> {
                IDCardCamera.create(this).openCamera(IDCardCamera.TYPE_IDCARD_BACK)
            }

        }
    }

    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        if (resultCode == IDCardCamera.RESULT_CODE) {
            val path = IDCardCamera.getImagePath(data)
            if (!TextUtils.isEmpty(path)) {

                if (requestCode == IDCardCamera.TYPE_IDCARD_FRONT || requestCode == IDCardCamera.TYPE_IDCARD_BACK) {
                   /* viewModel.documentTypes.add(
                        OnBoardingViewModel.Documents(
                            AppConstants.DOC_DRIVER_LICENSE,
                            AppConstants.SIDE_FRONT
                            , path
                        )
                    )*/

                    navigate(FrontDriverDocmentFragmentDirections.actionFrontDriverDocmentFragmentToBackDriverDocmentFragment())


                }

            }
        }
    }

}
