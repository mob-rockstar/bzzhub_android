package com.app.basketiodriver.ui.dialogs

import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.model.api.response.general.SimpleResponse
import com.app.basketiodriver.databinding.FragmentFlagItemDialogBinding
import com.app.basketiodriver.databinding.FragmentRefundDialogBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseDialogFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel

class FlagItemDialogFragment : BaseDialogFragment<FragmentFlagItemDialogBinding?, OrderDetailsViewModel>(),
    Injectable  {

    var outletId : Long = 0

    override val layoutId: Int
        get() = R.layout.fragment_flag_item_dialog

    override val viewModel: OrderDetailsViewModel
        get() {
            return getViewModel(requireActivity(), OrderDetailsViewModel::class.java)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    // Set Full screen
    override fun getTheme(): Int {
        return R.style.MyDialogWhite
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        /**
         * get params
         */
        arguments?.let {
            outletId = it.getLong(KEY_OUTLET_ID)

            initToolbar()
            initViews()
        }
    }

    // Initialize the toolbar
    private fun initToolbar(){
        viewDataBinding!!.layoutToolBar.toolBarTitle.text = getString(R.string.flag_item)
        viewDataBinding!!.layoutToolBar.btnBack.setOnClickListener {
            dismiss()
        }
    }

    // Initialize the views
    private fun initViews(){
        viewDataBinding!!.priceLayout.setOnClickListener {
            flagItem(outletId, 2)
        }

        viewDataBinding!!.locationLayout.setOnClickListener {
            flagItem(outletId, 1)
        }

        viewDataBinding!!.nameLayout.setOnClickListener {
            flagItem(outletId, 3)
        }

        viewDataBinding!!.imageLayout.setOnClickListener {
            flagItem(outletId, 4)
        }
    }

    private fun flagItem(outletId : Long, reason : Int){
        viewModel.shopperFlagItem(outletId, reason, object : HandleResponse<SimpleResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                Toast.makeText(baseActivity, error?.message, Toast.LENGTH_SHORT).show()
            }

            override fun handleSuccessResponse(successResponse: SimpleResponse) {
                val response = successResponse.response
                if (response != null){
                    Toast.makeText(baseActivity, response.message, Toast.LENGTH_SHORT).show()

                    if (response.httpCode == 200){

                    }
                }
                else{
                    Toast.makeText(baseActivity, baseActivity.getString(R.string.error_server_return_null), Toast.LENGTH_SHORT).show()
                }

                // Close the dialog
                if (isAdded)
                    dismiss()
            }
        })
    }

    companion object{
        const val KEY_OUTLET_ID = "key_outlet_id"

        fun newInstance(outletItemsId : Long) : FlagItemDialogFragment {
            val fragment = FlagItemDialogFragment()

            val data = Bundle()
            data.putLong(KEY_OUTLET_ID, outletItemsId)
            fragment.arguments = data

            return fragment
        }
    }
}