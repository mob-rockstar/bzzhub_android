package com.app.basketiodriver.data.model.api.response.dashboard

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class ShopperOrderByIDResponse {
    @SerializedName("response")
    @Expose
    val response: OrderResponseData? = null

    inner class OrderResponseData {
        @SerializedName("httpCode")
        @Expose
        val httpCode: Int? = null

        @SerializedName("Message")
        @Expose
        val message: String = ""

        @SerializedName("shopper_order")
        @Expose
        val shopperOrder: ShopperOrder? = null
    }
}