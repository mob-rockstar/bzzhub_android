package com.app.basketiodriver.data.model.db

import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import java.io.Serializable

open class PaymentChangedOrder : RealmObject(), Serializable {
    @PrimaryKey
    var orderId : Long = 0

    var paymentMethod : String = ""
}