package com.app.basketiodriver.data.model.api.response.Base


import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class ErrorResponse : BaseResponse {

    @SerializedName("errorMessages")
    @Expose
    var errorsMessages: HashMap<String,ArrayList<String>>? = null
    //var errorsMessages: ErrorsMessages? = null

    constructor()


}