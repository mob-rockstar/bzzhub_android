package com.app.basketiodriver.data.model.api.response.checkout

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import java.io.Serializable
import java.util.*

class OrdersReplacementItem : Serializable {
    @SerializedName("orders_outlets_items_id")
    @Expose
    val ordersOutletsItemsId: Long = 0

    @SerializedName("order_outlet_item_replacement_id")
    @Expose
    val ordersOutletsReplacementItemsId: Long? = null

    @SerializedName("actual_qty")
    @Expose
    var actualQty = 1.0
//    val actualQty: Int = 1

    @SerializedName("item_unit_price_actual")
    @Expose
    val itemUnitPriceActual: Double? = null

    @SerializedName("actual_selling_price")
    @Expose
    val actualSellingPrice: Double? = null

    @SerializedName("new_item_id")
    @Expose
    val newItemId: Long = 0

    @SerializedName("our_selling_price")
    @Expose
    val ourSellingPrice: Double = 0.0

    @SerializedName("item_unit_price_selling")
    @Expose
    val itemUnitPriceSelling: Double? = null

    @SerializedName("item_unit_tax_value")
    @Expose
    val itemUnitTaxValue: String? = null

    @SerializedName("measuring_unit")
    @Expose
    var measuringUnit: String? = null

    @SerializedName("actual_approx_weight")
    @Expose
    val actualApproxWeight: Int = 0

    @SerializedName("actaul_weight_for_approx_items")
    @Expose
    val actualWeightForApproxItems: String? = null

    @SerializedName("item_found")
    @Expose
    val itemFound: Int? = null

    @SerializedName("quantity_difference")
    @Expose
    val quantityDifference: Int = 0

    @SerializedName("quantity_difference_approved")
    @Expose
    val quantityDifferenceApproved: Int = 0

    @SerializedName("price_difference_reported")
    @Expose
    val priceDifferenceReported: Int? = null

    @SerializedName("price_difference_approved")
    @Expose
    val priceDifferenceApproved: Int? = null

    @SerializedName("replacement_requested")
    @Expose
    val replacementRequested: Int = 0

    @SerializedName("replacement_item_id")
    @Expose
    val replacementItemId: Long? = null

    @SerializedName("replacement_fullfilled")
    @Expose
    val replacementFullfilled: Int? = null

    @SerializedName("return_item")
    @Expose
    val returnItem: Int? = null

    @SerializedName("notes")
    @Expose
    val notes: String? = null

    @SerializedName("product_image")
    @Expose
    val productImage: String? = null

    @SerializedName("product_info_image")
    @Expose
    val productInfoImage: String? = null

    @SerializedName("sold_per")
    @Expose
    val soldPer: Int = 1

    @SerializedName("label_value")
    @Expose
    val labelValue: String? = null

    @SerializedName("size_label")
    @Expose
    val sizeLabel: Int? = null

    @SerializedName("approx_weight")
    @Expose
    val approxWeight: Double = 0.0

    @SerializedName("each_suffix")
    @Expose
    var eachSuffix: Int? = null

    @SerializedName("upc")
    @Expose
    val upc: String = ""

    @SerializedName("upc_type")
    @Expose
    val upcType: Int? = null

    @SerializedName("product_name")
    @Expose
    val productName: String = ""

    @SerializedName("shopper_tips")
    @Expose
    val shopperTips: String? = null

    @SerializedName("item_qty")
    @Expose
    var itemQty = 1.0
//    val itemQty: Int? = null

    @SerializedName("item_type")
    @Expose
    val itemType: Int? = null

    @SerializedName("custom_product_image")
    @Expose
    val customProductImage: String? = null

    @SerializedName("does_not_contain")
    @Expose
    val doesNotContain: Int? = null

    @SerializedName("custom_product_sold_type")
    @Expose
    val customProductSoldType: Int? = null

    @SerializedName("custom_product_name")
    @Expose
    val customProductName: String? = null

    @SerializedName("item_shopping_status")
    @Expose
    val itemShoppingStatus: Int? = null

    @SerializedName("aisle")
    @Expose
    val aisle: Int? = null

    @SerializedName("department_url")
    @Expose
    val departmentUrl: String? = null

    @SerializedName("department_name")
    @Expose
    val departmentName: String? = null

    @SerializedName("instore_master_location_id")
    @Expose
    val instoreMasterLocationId: Int? = null

    @SerializedName("instore_location_id")
    @Expose
    val instoreLocationId: Int? = null

    @SerializedName("instore_sublocation_id")
    @Expose
    val instoreSublocationId: Int? = null

    fun getDescriptionLabel() : String {
        return try {
            when (soldPer) {
                1 -> if (labelValue != null) String.format(Locale("en"), "%s %s", labelValue, measuringUnit) else " each"
                2 -> "per kg"
                3 -> String.format(Locale("en"), "%s %s each", approxWeight, measuringUnit)
                else -> "each"
            }
        } catch (e: Exception) {
            e.printStackTrace()
            "each"
        }
    }

}