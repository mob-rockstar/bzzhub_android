package com.app.basketiodriver.ui.dashbaord


import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.chat.BaseResponse
import com.app.basketiodriver.data.model.api.response.dashboard.Order
import com.app.basketiodriver.data.remote.socket.SocketManager
import com.app.basketiodriver.databinding.FragmentAcknowledgeBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.dashbaord.listener.PaginationScrollListener
import com.app.basketiodriver.ui.home.HomeActivity
import com.app.basketiodriver.ui.home.HomeViewModel
import com.app.basketiodriver.ui.home.fragments.OndemandDashbaordFragment
import com.app.basketiodriver.utils.AppConstants
import com.app.basketiodriver.utils.AppLogger
import com.app.basketiodriver.utils.MessageEvent
import com.app.basketiodriver.utils.SwipeManyStateButton
import com.app.basketiodriver.utils.SwipeManyStateButton.SwipeTouchListener
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import io.socket.client.Ack
import io.socket.client.Socket
import org.greenrobot.eventbus.EventBus
import org.json.JSONObject
import timber.log.Timber


/**
 * A simple [Fragment] subclass.
 */
class AcknowledgeFragment : BaseFragment<FragmentAcknowledgeBinding?, HomeViewModel>(),
    Injectable {

    override val layoutId: Int
        get() = R.layout.fragment_acknowledge

    override val viewModel: HomeViewModel
        get() {
            return getViewModel(requireActivity(), HomeViewModel::class.java)
        }

    private var orders : ArrayList<Order> = arrayListOf()
    private var loadMore : Boolean = false
    private var isButtonEnabled : Boolean = false
    private var haveOrders : Boolean = true

    private lateinit var layoutManager : LayoutWithSwitchScroll
    lateinit var orderAdapter: OrderAdapter

     var socketManager: SocketManager = SocketManager()

    protected var listener: SwipeTouchListener = object : SwipeTouchListener {
        override fun startTouch() {}
        override fun endTouch() {}
    }

    // pagination listener
    private lateinit var scrollListener : PaginationScrollListener

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initRecyclerView()

      //  getActiveTokenList()
        /**
         * get arguments
         */
        arguments?.let {
            isButtonEnabled = it.getBoolean(KEY_IS_BUTTON_ACTIVE)
            haveOrders      = it.getBoolean(KEY_HAVE_ORDERS)
            orders          = it.getSerializable(KEY_ORDERS_LIST) as ArrayList<Order>
            AppLogger.d("Got arguments")

            if (orders.size > 0) {
                viewDataBinding!!.tvNoOrders.visibility = View.GONE
            }
            else{
                viewDataBinding!!.tvNoOrders.visibility = View.VISIBLE
            }

            setContentRecyclerView()
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        initSocket()
    }

    override fun onResume() {

        if (orders != null && orders.size > 0){
            viewDataBinding!!.tvNoOrders.visibility = View.GONE
        }
        else{
            viewDataBinding!!.tvNoOrders.visibility = View.VISIBLE
        }

        setContentRecyclerView()

        super.onResume()
    }

    fun setSwipeTouchListener(swipeListener : SwipeManyStateButton.SwipeTouchListener){
        listener = object : SwipeTouchListener {
            override fun startTouch() {
                swipeListener.startTouch()
                layoutManager.setScrollEnabled(false)
            }

            override fun endTouch() {
                swipeListener.endTouch()
                layoutManager.setScrollEnabled(true)
            }
        }
    }

    private fun initRecyclerView(){
        layoutManager = LayoutWithSwitchScroll(requireContext())
        viewDataBinding!!.recyclerView.layoutManager = layoutManager
        viewDataBinding!!.recyclerView.setHasFixedSize(true)

        scrollListener = object : PaginationScrollListener(layoutManager) {
            override fun loadMoreItems() {
                if (parentFragment != null) {
                    (parentFragment as OndemandDashbaordFragment).loadMore()
                }
            }

            override fun isLastPage(): Boolean {
                return if (parentFragment == null) {
                    true
                } else{
                    (parentFragment as OndemandDashbaordFragment).isLastPage()
                }
            }

            override fun isLoadMore(): Boolean {
                return loadMore
            }

            override fun isLoading(): Boolean {
                if (parentFragment == null) {
                    return true
                }
                else{
                    return (parentFragment as OndemandDashbaordFragment).isLoading()
                }
            }
        }

        // Add the scroll listener
        viewDataBinding!!.recyclerView.addOnScrollListener(scrollListener)
    }

    // Open the store instructions
    private fun openStoreInstructions(order : Order){
        // Broadcast order view event
        EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_OPEN_STORE_INSTRUCTION, order))
    }

    // View the order info
    private fun viewOrderInfo(orderInfo : Order){
        // Broadcast updated event
        EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_OPEN_ORDER_REVIEW, orderInfo))
    }

    // Open the map
    private fun openLocation(orderId : Long){
        // Broadcast updated event
        EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_OPEN_ORDER_MAP, orderId))
    }

    private fun setContentRecyclerView(){
        // Set the adapter
        orderAdapter = OrderAdapter(baseActivity as FragmentActivity, listener, true, {order -> viewOrderInfo(order) }
            ,{selectedOrder -> openStoreInstructions(selectedOrder) }, {orderId ->  openLocation(orderId)}){
            orderStoreId ->  createRoom(orderStoreId)
        }
        viewDataBinding!!.recyclerView.adapter = orderAdapter

        // set the orders
        orderAdapter.setItems(orders)
    }

    fun setSwipeEnabled(enabled : Boolean){
        try {
            if (viewDataBinding!!.recyclerView.adapter != null && (viewDataBinding!!.recyclerView.adapter as OrderAdapter).isShowSwipeView() != enabled) {
                (viewDataBinding!!.recyclerView.adapter as OrderAdapter).setShowSwipeView(enabled)
                viewDataBinding!!.recyclerView.adapter!!.notifyDataSetChanged()
            }
        } catch (ex: Exception) {
            ex.printStackTrace()
        }
    }

    fun getItemsCount() : Int {
        return try {
            if (viewDataBinding?.recyclerView != null &&  viewDataBinding?.recyclerView!!.adapter != null){
                viewDataBinding?.recyclerView!!.adapter!!.itemCount
            } else{
                0
            }
        } catch (e : Exception){
            e.printStackTrace()
            0
        }
    }

    fun setLoadMore(loadMore : Boolean){
        this.loadMore = loadMore
    }

    fun addDataList(list : List<Order>){
        try {
            if (viewDataBinding?.recyclerView != null &&  viewDataBinding?.recyclerView!!.adapter != null){
                (viewDataBinding?.recyclerView!!.adapter as OrderAdapter).addList(list)
            }
        }
        catch (e : Exception){
            e.printStackTrace()
        }

    }

    private fun initSocket(){

    }

    private fun createRoom(orderStoreId: Long) {
        Timber.tag("JoinRoomError").d(orderStoreId.toString())
        try{
            if (((baseActivity as HomeActivity).socketManager).chatSocket != null){
                Timber.tag("JoinRoomError").d(orderStoreId.toString())
            }

            ((baseActivity as HomeActivity).socketManager).chatSocket?.emit(
                SocketManager.CHAT_EVENT_CREATE_ROOM,
                JSONObject().apply {
                    put(SocketManager.CHAT_KEY_ROOM_ID, orderStoreId.toString())
                },

                Ack {
                    val baseResponseType = object : TypeToken<BaseResponse>() {}.type
                    val response = Gson().fromJson<BaseResponse>(it.first() as String, baseResponseType)
                    Timber.tag("JoinRoomError").d("aaaaaaa")
                }
            )
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    companion object {
        fun newInstance(orders : ArrayList<Order>, isActive : Boolean, haveOrders : Boolean): AcknowledgeFragment {
            val fragment = AcknowledgeFragment()

            val data = Bundle()

            data.putSerializable(KEY_ORDERS_LIST, orders)
            data.putBoolean(KEY_IS_BUTTON_ACTIVE, isActive)
            data.putBoolean(KEY_HAVE_ORDERS, haveOrders)
            fragment.arguments = data

            return fragment
        }

        const val KEY_ORDERS_LIST = "orders_list"
        const val KEY_SHOPPER_DATA = "shopper_data"
        const val KEY_IS_BUTTON_ACTIVE = "is_button_active"
        const val KEY_HAVE_ORDERS = "is_have_orders"
    }
}


