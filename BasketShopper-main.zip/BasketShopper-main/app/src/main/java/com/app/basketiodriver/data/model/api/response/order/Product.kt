package com.app.basketiodriver.data.model.api.response.order

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName
import java.util.*

class Product {

    @SerializedName("orders_outlets_items_id")
    @Expose
    val ordersOutletsItemsId: Long? = null

    @SerializedName("outlet_item_id")
    @Expose
    val outletItemId: Int? = null

    @SerializedName("item_ordered_qty")
    @Expose
    val itemOrderedQty: Double? = null

    @SerializedName("item_shopped_qty")
    @Expose
    val itemShoppedQty: Double? = null

    @SerializedName("item_product_image")
    @Expose
    val itemProductImage: String? = null

    @SerializedName("item_product_info_image")
    @Expose
    val itemProductInfoImage: String? = null

    @SerializedName("item_barcode")
    @Expose
    val itemBarcode: String? = null

    @SerializedName("item_department_name")
    @Expose
    val itemDepartmentName: String? = null

    @SerializedName("item_aisle_name")
    @Expose
    val itemAisleName: String? = null

    @SerializedName("item_department_aisle_name")
    @Expose
    val itemDepartmentAisleName: String? = null

    @SerializedName("item_product_name")
    @Expose
    val itemProductName: String? = null

    @SerializedName("item_approx_weight")
    @Expose
    val itemApproxWeight: Double = 0.0

    @SerializedName("item_actual_approx_weight")
    @Expose
    val itemActualApproxWeight: Double = 0.0

    @SerializedName("item_selling_price")
    @Expose
    val itemSellingPrice: Double = 0.0

    @SerializedName("item_actual_selling_price")
    @Expose
    val itemActualSellingPrice: Double? = null

    @SerializedName("item_sold_per")
    @Expose
    val itemSoldPer: Int = 0

    @SerializedName("item_sold_per_label")
    @Expose
    val itemSoldPerLabel: String? = null

    @SerializedName("item_unit")
    @Expose
    var itemUnit: String = ""

    @SerializedName("item_label_value")
    @Expose
    val itemLabelValue: String? = null

    @SerializedName("item_each_suffix")
    @Expose
    var itemEachSuffix: Int = 0

    @SerializedName("item_shopper_tips")
    @Expose
    val itemShopperTips: String? = null

    @SerializedName("item_customer_comments")
    @Expose
    val itemCustomerComments: String? = null

    @SerializedName("item_status")
    @Expose
    val itemStatus: Int = 0

    @SerializedName("rep_item_ordered_qty")
    @Expose
    val repItemOrderedQty: String? = null

    @SerializedName("rep_item_shopped_qty")
    @Expose
    val repItemShoppedQty: String? = null

    @SerializedName("rep_item_product_image")
    @Expose
    val repItemProductImage: String? = null

    @SerializedName("rep_item_product_info_image")
    @Expose
    val repItemProductInfoImage: String? = null

    @SerializedName("rep_item_bar_code")
    @Expose
    val repItemBarCode: String? = null

    @SerializedName("rep_item_department_name")
    @Expose
    val repItemDepartmentName: String? = null

    @SerializedName("rep_item_aisle_name")
    @Expose
    val repItemAisleName: String? = null

    @SerializedName("rep_item_department_aisle_name")
    @Expose
    val repItemDepartmentAisleName: String? = null

    @SerializedName("rep_item_product_name")
    @Expose
    val repItemProductName: String? = null

    @SerializedName("rep_item_approx_weight")
    @Expose
    val repItemApproxWeight: String = "0.0"

    @SerializedName("rep_item_actual_approx_weight")
    @Expose
    val repItemActualApproxWeight: String? = null

    @SerializedName("rep_item_selling_price")
    @Expose
    val repItemSellingPrice: String = "0.0"

    @SerializedName("rep_item_actual_selling_price")
    @Expose
    val repItemActualSellingPrice: String? = null

    @SerializedName("rep_item_sold_per")
    @Expose
    val repItemSoldPer: String = "0"

    @SerializedName("rep_item_sold_per_label")
    @Expose
    val repItemSoldPerLabel: String? = null

    @SerializedName("rep_item_unit")
    @Expose
    val repItemUnit: String? = null

    @SerializedName("rep_item_label_value")
    @Expose
    val repItemLabelValue: String? = null

    @SerializedName("rep_item_each_suffix")
    @Expose
    val repItemEachSuffix: String = "0"

    @SerializedName("rep_item_shopper_tips")
    @Expose
    val repItemShopperTips: String? = null

    @SerializedName("rep_item_customer_comments")
    @Expose
    val repItemCustomerComments: String? = null

    @SerializedName("item_found")
    @Expose
    val itemFound: Int? = null

    @SerializedName("quantity_difference")
    @Expose
    val quantityDifference: Int? = null

    @SerializedName("quantity_difference_approved")
    @Expose
    val quantityDifferenceApproved: Int? = null

    @SerializedName("price_difference_reported")
    @Expose
    val priceDifferenceReported: Int? = null

    @SerializedName("price_difference_approved")
    @Expose
    val priceDifferenceApproved: Int? = null

    @SerializedName("return_item")
    @Expose
    val returnItem: Int? = null

    @SerializedName("replacement_requested")
    @Expose
    val replacementRequested: Int? = null

    @SerializedName("replacement_fullfilled")
    @Expose
    val replacementFullfilled: Int? = null

    fun getDescriptionLabel(): String {
        return when (itemSoldPer) {
            1 -> if (itemLabelValue != null) String.format(
                Locale.US,
                "(%s %s)",
                itemLabelValue.trim(),
                itemUnit.trim()
            ) else ""
            2 -> ""
            3 -> if (itemStatus < 3) String.format(
                Locale.US,
                "(%s %s each)",
                itemApproxWeight,
                itemUnit.trim()
            ) else java.lang.String.format(
                Locale.ENGLISH,
                "(%s %s each)",
                if (itemActualApproxWeight > 0) itemActualApproxWeight else itemApproxWeight,
                itemUnit.trim()
            )
            else -> ""
        }
    }
}