package com.app.basketiodriver.data.model.api.response.directions

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class Step {
    @SerializedName("distance")
    @Expose
    val distance: Distance? = null

    @SerializedName("duration")
    @Expose
    val duration: Duration? = null

    @SerializedName("end_location")
    @Expose
    val endLocation: EndLocation? = null

    @SerializedName("html_instructions")
    @Expose
    val htmlInstructions: String? = null

    @SerializedName("polyline")
    @Expose
    val polyline: Polyline? = null

    @SerializedName("start_location")
    @Expose
    val startLocation: StartLocation? = null

    @SerializedName("travel_mode")
    @Expose
    val travelMode: String? = null

    @SerializedName("maneuver")
    @Expose
    val maneuver: String? = null
}