package com.app.basketiodriver.data.model.api.response.otp

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class ResponseOTP {
    @SerializedName("httpCode")
    @Expose
    val httpCode: Int? = null

    @SerializedName("Message")
    @Expose
    val message: String = ""

    @SerializedName("shopper_id")
    @Expose
    val shopperId: Long? = null

    @SerializedName("token")
    @Expose
    val token: String? = null

    @SerializedName("email")
    @Expose
    val email: String = ""

    @SerializedName("mobile")
    @Expose
    val mobile: String = ""

    @SerializedName("first_name")
    @Expose
    val firstName: String = ""

    @SerializedName("last_name")
    @Expose
    val lastName: String = ""
}