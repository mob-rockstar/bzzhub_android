package com.app.basketiodriver.ui.onboarding.fragments


import android.os.Bundle
import android.text.Html
import android.view.View
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentNdacontractBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.onboarding.OnBoardingViewModel

/**
 * Created by ibraheem lubbad on 2020-01-22.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class NDAContractFragment : BaseFragment<FragmentNdacontractBinding?, OnBoardingViewModel>(),
    Injectable, View.OnClickListener {

    override val layoutId: Int
        get() = R.layout.fragment_ndacontract

    override val viewModel: OnBoardingViewModel
        get() {
            return getViewModel(requireActivity(), OnBoardingViewModel::class.java)
        }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.sign_nda_contract))

        viewModel.getNDAContract()


        viewModel.ndaContract.observeForever {
            viewDataBinding!!.tvContent.text = Html.fromHtml(it)
            viewDataBinding!!.btnSign.visibility = View.VISIBLE
        }

        viewDataBinding!!.btnSign.setOnClickListener(this)
    }

    override fun onClick(p0: View?) {
        when (p0!!.id) {
            R.id.btnSign -> {

                navigate(
                    NDAContractFragmentDirections.actionNdaContractFragmentToAddSignatureFragment()
                )
            }

        }
    }

}
