package com.app.basketiodriver.di.builder

import com.app.basketiodriver.ui.dialogs.*
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class  FragmentScanItemModule {
    @ContributesAndroidInjector
    abstract fun contributeCanNotFindItemDialogFragment(): CanNotFindItemDialogFragment

    @ContributesAndroidInjector
    abstract fun contributeRefundDialogFragment(): RefundDialogFragment

    @ContributesAndroidInjector
    abstract fun contributeAmountDialogFragment(): AmountDialogFragment

    @ContributesAndroidInjector
    abstract fun contributeIncorrectItemDialogFragment(): IncorrectItemDialogFragment
}