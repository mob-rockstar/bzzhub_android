package com.app.basketiodriver.data.model.api.response

import android.os.Parcelable
import com.app.basketiodriver.data.model.api.response.Base.BaseResponse

import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize


/**
Created by ibraheem lubbad on 4/11/20.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class DocumentsResponse :
    BaseResponse() {

    @SerializedName("data")
    var onbaordingDocumentLists: ArrayList<OnbaordingDocument>? = null




    @Parcelize
    data class OnbaordingDocument(

        @SerializedName("id") val id: Int,
        @SerializedName("name") val name: String,
        @SerializedName("title") val title: String,
        @SerializedName("DocumentEntity") val documentEntities: ArrayList<OnbaordingDocumentEntity>?,
        @SerializedName("SuperDocumentType") val superDocumentType: SuperDocumentType?,
        @SerializedName("OnboardFLow") val onboardFLow: OnboardFLow?

    ) : Parcelable

    @Parcelize
    data class OnbaordingDocumentEntity(

        @SerializedName("id") val id: Int,
        @SerializedName("file_type") val file_type: String,
        @SerializedName("file_extensions") val file_extensions:List<String>,
        @SerializedName("is_hidden") val is_hidden: Boolean,
        @SerializedName("placeholder_url") val placeholder_url: String,
        @SerializedName("order") val order: Int,
        @SerializedName("label") val label: String,
        @SerializedName("title") val title: String,
        @SerializedName("description") val description: String,
        var fileLocalPath: String

    ) : Parcelable


    @Parcelize
    data class SuperDocumentType(

        @SerializedName("id") val id: Int,
        @SerializedName("name") val name: String

    ) : Parcelable

    @Parcelize
    data class OnboardFLow(

        @SerializedName("active") val active: Boolean,
        @SerializedName("order") val order: Int,
        @SerializedName("is_required") val is_required: Boolean

    ) : Parcelable

    override fun toString(): String {
        return "DocumentsResponse(onbaordingDocumentLists=$onbaordingDocumentLists)"
    }

}