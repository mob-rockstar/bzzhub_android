package com.app.basketiodriver.ui.dashbaord.map

import android.app.Application
import com.app.basketiodriver.data.DataManager
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.dashboard.ShopperOrderByIDResponse
import com.app.basketiodriver.data.model.api.response.directions.ServerAnswer
import com.app.basketiodriver.data.model.api.response.general.SimpleResponse
import com.app.basketiodriver.data.remote.APIManager
import com.app.basketiodriver.data.remote.GoogleAPIManager
import com.app.basketiodriver.data.remote.socket.SystemMessage
import com.app.basketiodriver.data.remote.socket.SystemMessageReq
import com.app.basketiodriver.ui.base.BaseNavigator
import com.app.basketiodriver.ui.base.BaseViewModel
import com.app.basketiodriver.ui.base.HandleResponse
import com.google.android.gms.maps.model.LatLng
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class LocationMapViewModel constructor(application: Application, dataManager: DataManager
) : BaseViewModel<BaseNavigator?>(application, dataManager) {
    /**
     * Method to get shopper order details by id
     */
    fun getOrderDetailsByID(orderId:Long, handleResponse: HandleResponse<ShopperOrderByIDResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.getShopperOrderByID(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, orderId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to get directions between two locations
     */
    fun getDirections(startLocation : LatLng, endLocation : LatLng, key : String,  handleResponse: HandleResponse<ServerAnswer>){
        compositeDisposable.add(
            GoogleAPIManager.getDirections(startLocation, endLocation, key)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {

                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {

                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to update the shopper order status
     */
    fun updateOrderStatus(orderStatus : Int, orderId : Long, handleResponse: HandleResponse<SimpleResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.updateOrderStatus(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, PreferenceManager.shopperStatus, orderStatus, orderId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    fun sendSystemMessage(message: SystemMessageReq, handleResponse: HandleResponse<SystemMessage>){
        setIsLoading(true)
        compositeDisposable.add(APIManager.sendSystemMessage(message)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessResponse(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            )
        )
    }
}