package com.app.basketiodriver.ui.base

import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse


/**
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
interface HandleResponse<T> {

    fun handleErrorResponse(error: ErrorResponse?)
    fun handleSuccessResponse(successResponse: T)

}