package com.app.basketiodriver.data.remote.socket

data class ActiveDeviceToken(
    var platform: String,
    var token: String
)