package com.app.basketiodriver.data.local.prefs

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import com.app.basketiodriver.utils.AppConstants


object PreferenceManager {
    private const val PREF_KEY_ACCESS_TOKEN = "PREF_KEY_ACCESS_TOKEN"
    private const val PREF_KEY_CURRENT_USER_LANGUAGE = "PREF_KEY_USER_LANGUAGE"
    private const val PREF_KEY_CURRENT_SHOPPER_MOBILE = "PREF_KEY_CURRENT_SHOPPER_MOBILE"
    private const val PREF_KEY_CURRENT_SHOPPER_EMAIL = "PREF_KEY_CURRENT_SHOPPER_EMAIL"
    private const val PREF_KEY_CURRENT_SHOPPER_ID = "PREF_KEY_CURRENT_SHOPPER_ID"
    private const val PREF_KEY_CURRENT_SHOPPER_FIRST_NAME = "PREF_KEY_CURRENT_SHOPPER_FIRST_NAME"
    private const val PREF_KEY_CURRENT_SHOPPER_LAST_NAME = "PREF_KEY_CURRENT_SHOPPER_LAST_NAME"
    private const val PREF_KEY_CURRENT_USER_IMAGE_URL = "PREF_KEY_CURRENT_USER_IMAGE_URL"
    private const val PREF_KEY_CURRENT_USER_SETUP_STEP = "PREF_KEY_CURRENT_USER_SETUP_STEP"
    private const val PREF_KEY_CURRENT_USER_COUNTRY_ID = "PREF_KEY_CURRENT_USER_COUNTRY_ID"
    private const val PREF_KEY_CURRENT_USER_CITY_ID = "PREF_KEY_CURRENT_USER_CITY_ID"
    private const val PREF_KEY_CURRENT_USER_AREA_ID = "PREF_KEY_CURRENT_USER_AREA_ID"
    private const val PREF_KEY_CURRENT_USER_STORE_ID = "PREF_KEY_CURRENT_USER_STORE_ID"
    private const val PREF_KEY_USER_LOGGED_IN_MODE = "PREF_KEY_USER_LOGGED_IN_MODE"
    private const val PREF_KEY_DEVICE_TOKEN = "device_token"
    private const val PREF_KEY_DEVICE_ID = "device_id"
    private const val PREF_KEY_FCM_TOKEN = "fcm_token"
    private const val PREF_KEY_SOCKET_TOKEN = "socket_token"
    private const val PREF_KEY_USER_CART_COUNT = "PREF_KEY_USER_CART_COUNT"
    private const val PREF_KEY_USER_OPENED_ORDER_COUNT = "PREF_KEY_OPENED_ORDER_COUNT"
    private const val PREF_KEY_CURRENT_SHOPPER_ADDRESS = "PREF_KEY_CURRENT_SHOPPER_ADDRESS"
    private const val PREF_KEY_USER_MISSED_NOTIFICATION = "PREF_KEY_MISSED_NOTIFICATION"
    private const val PREF_KEY_MOBILE_VERIFIED = "PREF_KEY_MOBILE_VERIFIED"
    private const val PREF_KEY_APPLICATION_STATUS = "PREF_KEY_APPLICATION_STATUS"
    private const val PREF_KEY_LOGGED_IN  = "PREF_KEY_LOGGED_IN"
    private const val PREF_KEY_SHOPPER_STATUS  = "PREF_KEY_SHOPPER_STATUS"
    private const val PREF_KEY_SHOPPER_TYPE    = "PREF_KEY_SHOPPER_TYPE"
    private const val PREF_KEY_ACTIVE_STATUS   = "PREF_KEY_ACTIVE_STATUS"

    private const val PREF_KEY_CURRENCY        = "PREF_KEY_CURRENCY"

    private const val PREF_KEY_ORDER_COUNTER_NUMBER  = "PREF_KEY_ORDER_COUNTER_NUMBER"

    private const val PREF_KEY_SUPPORT_NUMBER  = "PREF_KEY_SUPPORT_NUMBER"

    // Customer
    private const val PREF_KEY_CUSTOMER_ID    = "PREF_KEY_CUSTOMER_ID"
    private const val PREF_KEY_CUSTOMER_NAME  = "PREF_KEY_CUSTOMER_NAME"
    private const val PREF_KEY_CUSTOMER_IMAGE = "PREF_KEY_CUSTOMER_IMAGE"

    private const val PREF_KEY_DRIVER_NAME    = "PREF_KEY_DRIVER_NAME"

    private const val PREF_KEY_FIRST_SHIFT_TIME = "PREF_KEY_FIRST_SHIFT_TIME"

    private const val PREF_KEY_POCKET_MONEY_DATE = "PREF_KEY_POCKET_MONEY_DATE"
    private const val PREF_KEY_CASH_ON_HAND_DATE = "PREF_KEY_CASH_ON_HAND_DATE"

    // Order id
    private const val PREF_KEY_ORDER_ID    = "PREF_KEY_ORDER_ID"
    private const val PREF_KEY_ORDER_OUTLET_ID   = "PREF_KEY_ORDER_OUTLET_ID"

    // Location update
    private const val PREF_KEY_LOCATION_UPDATE_TIME = "PREF_KEY_LOCATION_UPDATE_TIME"

    // HCM Token
    private const val PREF_KEY_HCM_TOKEN     = "PREF_KEY_HCM_TOKEN"

    private const val PREF_KEY_USER_CHAT_TOKEN     = "PREF_KEY_CHAT_TOKEN"

    private const val PREF_KEY_PAYMENT_CHANGED_ORDERS = "PREF_KEY_PAYMENT_CHANGED_ORDERS"

    private const val PREF_KEY_STOP_LOCATION_UPDATE = "PREF_KEY_STOP_LOCATION_UPDATE"


    private lateinit var mPrefs: SharedPreferences

    fun init(context: Context) {
        mPrefs = context.getSharedPreferences(AppConstants.PREF_NAME, Context.MODE_PRIVATE)
    }

    fun logout(){
        val token = fcmToken ?: ""
        val hToken = hcmToken ?: ""
        val languageCode = currentUserLanguage

        // clear all
        mPrefs.edit().clear().apply()

        fcmToken = token
        hcmToken = hToken
        isLoggedIn = false
        currentUserLanguage = languageCode
    }


    // Token from Server
    var accessToken: String?
        get() = mPrefs.getString(
            PREF_KEY_ACCESS_TOKEN, ""
        )
        set(accessToken) {
            mPrefs.edit().putString(
                PREF_KEY_ACCESS_TOKEN, accessToken
            ).apply()
        }

    // Hcm token
    var hcmToken: String?
        get() = mPrefs.getString(
            PREF_KEY_HCM_TOKEN, ""
        )
        set(token) {
            mPrefs.edit().putString(
                PREF_KEY_HCM_TOKEN, token
            ).apply()
        }

    // Support phone number
    var supportNumber: String?
        get() = mPrefs.getString(
            PREF_KEY_SUPPORT_NUMBER, "+96265900413"
        )
        set(number) {
            mPrefs.edit().putString(
                PREF_KEY_SUPPORT_NUMBER, number
            ).apply()
        }

    // Order list payment method was changed
    var paymentChangedOrderIds : String?
        get() = mPrefs.getString(
            PREF_KEY_PAYMENT_CHANGED_ORDERS, ""
        )
        set(number) {
            mPrefs.edit().putString(
                PREF_KEY_PAYMENT_CHANGED_ORDERS, number
            ).apply()
        }

    // User Mobile number
    var currentShopperMobile: String?
        get() = mPrefs.getString(
            PREF_KEY_CURRENT_SHOPPER_MOBILE, ""
        )
        set(mobile) {
            mPrefs.edit().putString(
                PREF_KEY_CURRENT_SHOPPER_MOBILE, mobile
            ).apply()
        }

    // Shopper Email Address
    var currentShopperEmail: String?
        get() = mPrefs.getString(
            PREF_KEY_CURRENT_SHOPPER_EMAIL, ""
        )
        set(email) {
            mPrefs.edit().putString(
                PREF_KEY_CURRENT_SHOPPER_EMAIL, email
            ).apply()
        }

    var firstShiftTime: String?
        get() = mPrefs.getString(
            PREF_KEY_FIRST_SHIFT_TIME, ""
        )
        set(time) {
            mPrefs.edit().putString(
                PREF_KEY_FIRST_SHIFT_TIME, time
            ).apply()
        }

    // Cash on hand date
    var cashOnHandDate: String?
        get() = mPrefs.getString(
            PREF_KEY_CASH_ON_HAND_DATE, ""
        )
        set(cashDate) {
            mPrefs.edit().putString(
                PREF_KEY_CASH_ON_HAND_DATE, cashDate
            ).apply()
        }

    // Pocket Money
    var pocketMoney : String?
        get() = mPrefs.getString(
            PREF_KEY_POCKET_MONEY_DATE, ""
        )
        set(moneyDate) {
            mPrefs.edit().putString(
                PREF_KEY_POCKET_MONEY_DATE, moneyDate
            ).apply()
        }

    // Order counter number
    var orderCounterNumber : Int
        get() = mPrefs.getInt(
            PREF_KEY_ORDER_COUNTER_NUMBER, 0
        )
        set(count) {
            mPrefs.edit().putInt(
                PREF_KEY_ORDER_COUNTER_NUMBER, count
            ).apply()
        }

    // Current order id
    var orderId : Long
        get() = mPrefs.getLong(
            PREF_KEY_ORDER_ID, 1
        )
        set(orderIdVal) {
            mPrefs.edit().putLong(
                PREF_KEY_ORDER_ID, orderIdVal
            ).apply()
        }

    // Location update time
    var locationUpdateTime : Long // Default : 2 mins
        get() = mPrefs.getLong(
            PREF_KEY_LOCATION_UPDATE_TIME, 120
        )
        set(time) {
            mPrefs.edit().putLong(
                PREF_KEY_LOCATION_UPDATE_TIME, time
            ).apply()
        }

    // Current order outlet id
    var orderOutletId : Long
        get() = mPrefs.getLong(
            PREF_KEY_ORDER_OUTLET_ID, 1
        )
        set(orderIdVal) {
            mPrefs.edit().putLong(
                PREF_KEY_ORDER_OUTLET_ID, orderIdVal
            ).apply()
        }

    // Current User Selected Language
    var currentUserLanguage: Int
        get() = mPrefs.getInt(
            PREF_KEY_CURRENT_USER_LANGUAGE, 1
        )
        set(lang) {
            mPrefs.edit().putInt(
                PREF_KEY_CURRENT_USER_LANGUAGE, lang
            ).apply()
        }

    // Check if current user is logged in
    var isLoggedIn : Boolean
        get() = mPrefs.getBoolean(PREF_KEY_LOGGED_IN, false)
        set(loggedIn){
            mPrefs.edit().putBoolean(PREF_KEY_LOGGED_IN, loggedIn).apply()
        }

    var shouldStopLocation : Boolean
        get() = mPrefs.getBoolean(PREF_KEY_STOP_LOCATION_UPDATE, false)
        set(shouldStop){
            mPrefs.edit().putBoolean(PREF_KEY_STOP_LOCATION_UPDATE, shouldStop).apply()
        }

    // Check if mobile verified
    var shopperMobileVerified: Int
        get() = mPrefs.getInt(
            PREF_KEY_MOBILE_VERIFIED, 0
        )
        set(lang) {
            mPrefs.edit().putInt(
                PREF_KEY_MOBILE_VERIFIED, lang
            ).apply()
        }

    // Application status
    var applicationStatus : Int
        get() = mPrefs.getInt(
            PREF_KEY_APPLICATION_STATUS, 0
        )
        set(lang) {
            mPrefs.edit().putInt(
                PREF_KEY_APPLICATION_STATUS, lang
            ).apply()
        }

    var shopperStatus : Int
        get() = mPrefs.getInt(
            PREF_KEY_SHOPPER_STATUS, 0
        )
        set(status) {
            mPrefs.edit().putInt(
                PREF_KEY_SHOPPER_STATUS, status
            ).apply()
        }

    var activeStatus : Int
        get() = mPrefs.getInt(
            PREF_KEY_ACTIVE_STATUS, 0
        )
        set(status) {
            mPrefs.edit().putInt(
                PREF_KEY_ACTIVE_STATUS, status
            ).apply()
        }

    var shopperType : Int
        get() = mPrefs.getInt(
            PREF_KEY_SHOPPER_TYPE, 0
        )
        set(type) {
            mPrefs.edit().putInt(
                PREF_KEY_SHOPPER_TYPE, type
            ).apply()
        }

    // Shopper ID
    var currentShopperId: Long?
        get() {
            val userId = mPrefs.getLong(
                PREF_KEY_CURRENT_SHOPPER_ID, AppConstants.NULL_INDEX
            )
            return if (userId == AppConstants.NULL_INDEX) null else userId
        }
        set(userId) {
            val id = userId ?: AppConstants.NULL_INDEX
            mPrefs.edit().putLong(
                PREF_KEY_CURRENT_SHOPPER_ID, id
            ).apply()
        }

    // Device ID
    var deviceId: String?
        get() = mPrefs.getString(
            PREF_KEY_DEVICE_ID, ""
        )!!
        set(deviceId) {
            mPrefs.edit().putString(
                PREF_KEY_DEVICE_ID, deviceId
            ).apply()
        }


    var deviceToken: String?
        get() = mPrefs.getString(
            PREF_KEY_DEVICE_TOKEN, ""
        )!!
        set(deviceToken) {
            mPrefs.edit().putString(
                PREF_KEY_DEVICE_TOKEN, deviceToken
            ).apply()
        }

    // Currency
    var currency: String
        get() = mPrefs.getString(
            PREF_KEY_CURRENCY, "JD"
        )!!
        set(currency) {
            mPrefs.edit().putString(
                PREF_KEY_CURRENCY, currency
            ).apply()
        }

    // Firebase Token
    var fcmToken: String?
        get() = mPrefs.getString(
            PREF_KEY_FCM_TOKEN, "sdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdf"
        )!!
        set(deviceToken) {
            mPrefs.edit().putString(
                PREF_KEY_FCM_TOKEN, deviceToken
            ).apply()
        }

    // Token from Socket Server
    var socketToken: String?
        get() = mPrefs.getString(
            PREF_KEY_SOCKET_TOKEN, ""
        )!!
        set(socketToken) {
            mPrefs.edit().putString(
                PREF_KEY_SOCKET_TOKEN, socketToken
            ).apply()
        }

    // Current User Login Mode - Loggedin, Loggedout, Social
    var currentUserLoggedInMode: LoggedInMode
        get() = LoggedInMode.fromInt(
            mPrefs.getInt(
                PREF_KEY_USER_LOGGED_IN_MODE,
                0
            )
        )
        set(mode) {
            mPrefs.edit().putInt(
                PREF_KEY_USER_LOGGED_IN_MODE, mode.type
            ).apply()
        }

    // Shopper First Name
    var currentShopperFirstName: String?
        get() = mPrefs.getString(
            PREF_KEY_CURRENT_SHOPPER_FIRST_NAME, ""
        )
        set(firstName) {
            mPrefs.edit().putString(
                PREF_KEY_CURRENT_SHOPPER_FIRST_NAME, firstName
            ).apply()
        }

    // Shopper Last Name
    var currentShopperLastName: String?
        get() = mPrefs.getString(
            PREF_KEY_CURRENT_SHOPPER_LAST_NAME, null
        )
        set(lastName) {
            mPrefs.edit().putString(
                PREF_KEY_CURRENT_SHOPPER_LAST_NAME, lastName
            ).apply()
        }

    // Driver name
    var driverName: String?
        get() = mPrefs.getString(
            PREF_KEY_DRIVER_NAME, ""
        )
        set(name) {
            mPrefs.edit().putString(
                PREF_KEY_DRIVER_NAME, name
            ).apply()
        }

    // User Image URL
    var currentUserImageUrl: String?
        get() = mPrefs.getString(
            PREF_KEY_CURRENT_USER_IMAGE_URL, null
        )
        set(profilePicUrl) {
            mPrefs.edit().putString(
                PREF_KEY_CURRENT_USER_IMAGE_URL, profilePicUrl
            ).apply()
        }

    // User Country ID
    var currentUserCountryId: Int
        get() = mPrefs.getInt(
            PREF_KEY_CURRENT_USER_COUNTRY_ID, 0
        )
        set(countryId) {
            mPrefs.edit().putInt(
                PREF_KEY_CURRENT_USER_COUNTRY_ID, countryId
            ).apply()
        }

    // User City ID
    var currentUserCityId: Int
        get() = mPrefs.getInt(
            PREF_KEY_CURRENT_USER_CITY_ID, 0
        )
        set(cityId) {
            mPrefs.edit().putInt(
                PREF_KEY_CURRENT_USER_CITY_ID, cityId
            ).apply()
        }

    // User Area ID
    var currentUserAreaId: Int
        get() = mPrefs.getInt(
            PREF_KEY_CURRENT_USER_AREA_ID, 0
        )
        set(areaId) {
            mPrefs.edit().putInt(
                PREF_KEY_CURRENT_USER_AREA_ID, areaId
            ).apply()
        }

    // User Store ID
    var currentUserStoreId: Int
        get() = mPrefs.getInt(
            PREF_KEY_CURRENT_USER_STORE_ID, 0
        )
        set(storeId) {
            mPrefs.edit().putInt(
                PREF_KEY_CURRENT_USER_STORE_ID, storeId
            ).apply()
        }

    // Profile Setup Step
    var currentUserSetupStep: Int
        get() = mPrefs.getInt(
            PREF_KEY_CURRENT_USER_SETUP_STEP, 0
        )
        set(steupStep) {
            mPrefs.edit().putInt(
                PREF_KEY_CURRENT_USER_SETUP_STEP, steupStep
            ).apply()
        }

    var currentUserAddress: String?
        get() = mPrefs.getString(
            PREF_KEY_CURRENT_SHOPPER_ADDRESS, ""
        )!!
        set(currentAddressString) {
            mPrefs.edit().putString(
                PREF_KEY_CURRENT_SHOPPER_ADDRESS, currentAddressString
            ).apply()
        }

    // Missed Notification ID
    var missedNotification: Int
        get() = mPrefs.getInt(
            PREF_KEY_USER_MISSED_NOTIFICATION, 0
        )
        set(count) {
            mPrefs.edit().putInt(
                PREF_KEY_USER_MISSED_NOTIFICATION, count
            ).apply()
        }

    var userChatToken: String?
        get() = mPrefs.getString(
            PREF_KEY_USER_CHAT_TOKEN, ""
        )!!
        set(currentUserChatToken) {
            mPrefs.edit().putString(
                PREF_KEY_USER_CHAT_TOKEN, currentUserChatToken
            ).apply()
        }

    fun setOrderStatus(orderStatus: Int ,orderId: String ) {
        mPrefs.edit().putInt(
            orderId, orderStatus
        ).apply()
    }

    fun getOrderStatus(orderId: String): Int{
        return mPrefs.getInt(orderId,0)
    }

    // Get customer id
    fun getCustomerId(orderId : String) : String? {
        return mPrefs.getString("cus$orderId", "0")
    }

    // Set customer id
    fun setCustomerId(orderId : String, customerId : String){
        mPrefs.edit().putString("cus$orderId", customerId).apply()
    }

    // Get customer name
    fun getCustomerName(orderId : String) : String?{
        return mPrefs.getString("CustomerName_$orderId", "")
    }

    // Set customer name
    fun setCustomerName(orderId : String, customerName : String){
        mPrefs.edit().putString("CustomerName_$orderId", customerName).apply()
    }

    // Set customer image
    open fun setCustomerImage(orderId: String, imageUrl: String?){
        var image = imageUrl
        if (image == null || image.isEmpty()) {
            image = "https://cdn.dev-basket.com/assets/images/profile.png"
        }
        mPrefs.edit().putString("imgCus$orderId", image).apply()
    }

    fun getCustomerImage(orderId: String): String? {
        return mPrefs.getString(
            "imgCus$orderId",
            "https://cdn.dev-basket.com/assets/images/profile.png"
        )
    }

    enum class LoggedInMode(val type: Int) {
        LOGGED_IN_MODE_LOGGED_OUT(0), LOGGED_IN_MODE_GOOGLE(1), LOGGED_IN_MODE_FB(2), LOGGED_IN_MODE_SERVER(
            3
        );

        companion object {
            fun fromInt(value: Int) = LoggedInMode.values().first { it.ordinal == value }
        }
    }

}