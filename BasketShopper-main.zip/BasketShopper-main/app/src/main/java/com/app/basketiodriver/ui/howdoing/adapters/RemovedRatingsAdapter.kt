package com.app.basketiodriver.ui.howdoing.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.ItemRemovedRatingBinding
import com.app.basketiodriver.ui.base.DataListAdapter


/**
Created by ibraheem lubbad on 2020-05-21.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class RemovedRatingsAdapter(val context: Context, val itemAction: ItemAction?) :
    DataListAdapter<String, ItemRemovedRatingBinding>() {

    interface ItemAction {
        fun clickOnItem()
    }

    override fun createBinding(
        inflater: LayoutInflater,
        parent: ViewGroup?
    ): ItemRemovedRatingBinding {
        return DataBindingUtil.inflate(inflater, R.layout.item_removed_rating, parent, false)
    }

    override fun bind(binding: ItemRemovedRatingBinding?, item: String) {
        binding?.root?.setOnClickListener { itemAction?.clickOnItem() }
    }


}