package com.app.basketiodriver.ui.howdoing.fragments


import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.howamidoing.HowAmIDoingDetailResponse
import com.app.basketiodriver.data.model.api.response.howamidoing.RIRecords
import com.app.basketiodriver.data.model.api.response.howamidoing.ReliabilityModel
import com.app.basketiodriver.databinding.FragmentReliabilityIncidentBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.howdoing.HowIamDoingViewModel
import com.app.basketiodriver.ui.howdoing.adapters.RIAdapter
import com.app.basketiodriver.ui.howdoing.adapters.RIHistoryAdapter
import com.thoughtbot.expandablerecyclerview.models.ExpandableGroup

import com.thoughtbot.expandablerecyclerview.listeners.GroupExpandCollapseListener

class ReliabilityIncidentFragment :
    BaseFragment<FragmentReliabilityIncidentBinding?, HowIamDoingViewModel>(),
    Injectable {

    override val layoutId: Int
        get() = R.layout.fragment_reliability_incident

    override val viewModel: HowIamDoingViewModel
        get() {
            return getViewModel(requireActivity(), HowIamDoingViewModel::class.java)
        }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.reliability_incidents))

        initUI()
    }

    private fun initUI(){
        // Init RecyclerManager
        val linearLayoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        viewDataBinding!!.recyclerView.layoutManager = linearLayoutManager
        viewDataBinding!!.recyclerView.setHasFixedSize(true)

        getHowAmIDoing()
    }

    // Get details
    private fun getHowAmIDoing(){
        viewModel.getHowAmIDoingDetails("RI", object:HandleResponse<HowAmIDoingDetailResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Toast.makeText(baseActivity, error?.message, Toast.LENGTH_LONG).show()
                }
                else{
                    Toast.makeText(baseActivity, baseActivity?.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }
            }

            override fun handleSuccessResponse(successResponse: HowAmIDoingDetailResponse) {
                val data = successResponse.data
                if (data != null){
                    updateUI(data)
                }
                else{
                    Toast.makeText(baseActivity, successResponse.message, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    private fun updateUI(data : HowAmIDoingDetailResponse.DetailsData){
        viewDataBinding!!.txtReason.text = data.incident_text

        when (data.incident) {
            0 -> {

            }
            1 -> {
                viewDataBinding!!.txt1.background = baseActivity!!.resources.getDrawable(R.drawable.ri_1incident)
            }
            2 -> {
                viewDataBinding!!.txt1.background = baseActivity!!.resources.getDrawable(R.drawable.ri_1incident_yellow)
                viewDataBinding!!.txt2.background = baseActivity!!.resources.getDrawable(R.drawable.ri_2incident_yellow)
            }
            3 -> {
                viewDataBinding!!.txt1.background = baseActivity!!.resources.getDrawable(R.drawable.ri_1incident_yellow)
                viewDataBinding!!.txt2.background = baseActivity!!.resources.getDrawable(R.drawable.ri_2incident_yellow)
                viewDataBinding!!.txt3.background = baseActivity!!.resources.getDrawable(R.drawable.ri_2incident_yellow)
            }
            4 -> {
                viewDataBinding!!.txt2.background = baseActivity!!.resources.getDrawable(R.drawable.ri_2incident_yellow)
                viewDataBinding!!.txt3.background = baseActivity!!.resources.getDrawable(R.drawable.ri_2incident_yellow)
                viewDataBinding!!.txt4.background = baseActivity!!.resources.getDrawable(R.drawable.ri_2incident_yellow)
            }
            else -> {
                viewDataBinding!!.txt1.background = baseActivity!!.resources.getDrawable(R.drawable.ri_1incident_red)
                viewDataBinding!!.txt2.background = baseActivity!!.resources.getDrawable(R.drawable.ri_2incident_red)
                viewDataBinding!!.txt3.background = baseActivity!!.resources.getDrawable(R.drawable.ri_2incident_red)
                viewDataBinding!!.txt4.background = baseActivity!!.resources.getDrawable(R.drawable.ri_2incident_red)
                viewDataBinding!!.txt5.background = baseActivity!!.resources.getDrawable(R.drawable.ri_2incident_red)

                // Show the Suspend message
//                Toast.makeText(baseActivity, baseActivity?.resources?.getString(R.string.ri_suspend_message), Toast.LENGTH_SHORT).show()
            }
        }

        val adapter = RIHistoryAdapter(baseActivity as FragmentActivity)
        adapter.setItems(data.riRecords ?: arrayListOf())
        viewDataBinding!!.recyclerView.adapter = adapter

        if (data.riRecords!= null){
            viewDataBinding!!.incidentHistoryView.visibility = if (data.riRecords.isEmpty()) View.INVISIBLE else View.VISIBLE
        }
        else{
            viewDataBinding!!.incidentHistoryView.visibility = View.INVISIBLE
        }
    }
}
