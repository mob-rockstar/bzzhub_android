package com.app.basketiodriver.ui.checkout.card

import android.app.Application
import com.app.basketiodriver.data.DataManager
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.checkout.ShopperOrderReview
import com.app.basketiodriver.data.model.api.response.general.SimpleResponse
import com.app.basketiodriver.data.model.api.response.order.CommonResponse
import com.app.basketiodriver.data.model.api.response.order.OrderOTPResponse
import com.app.basketiodriver.data.remote.APIManager
import com.app.basketiodriver.data.remote.socket.SystemMessage
import com.app.basketiodriver.data.remote.socket.SystemMessageReq
import com.app.basketiodriver.ui.base.BaseNavigator
import com.app.basketiodriver.ui.base.BaseViewModel
import com.app.basketiodriver.ui.base.HandleResponse
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class CheckoutCardViewModel constructor(application: Application, dataManager: DataManager):
    BaseViewModel<BaseNavigator?>(application, dataManager) {

    /**
     * Method to get order review(detail)
     */
    fun getShopperOrderReview(orderId : Long, handleResponse: HandleResponse<ShopperOrderReview>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperOrderReview(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, orderId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to update the shopper order status
     */
    fun updateOrderStatus(orderStatus : Int, orderId : Long, handleResponse: HandleResponse<SimpleResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.updateOrderStatus(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, PreferenceManager.shopperStatus, orderStatus, orderId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to update the subtotal
     */
    fun shopperUpdateSubtotal(outletId : Long, total : Double, handleResponse: HandleResponse<SimpleResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperUpdateSubtotal(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, outletId, total)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to upload the order receipt
     */
    fun shopperSendOrderReceipt(orderId : Long, storeReceiptNo : String, currentPhotoPaths : List<String>, handleResponse: HandleResponse<CommonResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperSendOrderReceipt(PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, orderId, storeReceiptNo, currentPhotoPaths)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    fun sendSystemMessage(message: SystemMessageReq, handleResponse: HandleResponse<SystemMessage>){
        setIsLoading(true)
        compositeDisposable.add(APIManager.sendSystemMessage(message)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessResponse(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            )
        )
    }


    /**
     * Method to get order otp for credit card
     */
    fun getOrderOTP(orderOutletId : Long, handleResponse: HandleResponse<OrderOTPResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.getOrderOTP(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, orderOutletId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }
}