package com.app.basketiodriver.data.model.api.response.terms

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName


class AgreeTermAndConditionResponse {
    @SerializedName("message")
    @Expose
    var message: String? = null

    @SerializedName("status")
    @Expose
    var status = 0
}