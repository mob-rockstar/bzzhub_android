package com.app.basketiodriver.data.model.api.chat

data class ShopperListResponse(
    var users: List<Shopper>
)