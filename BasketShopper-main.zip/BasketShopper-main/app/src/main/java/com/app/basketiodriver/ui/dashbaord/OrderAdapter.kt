package com.app.basketiodriver.ui.dashbaord

import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.app.basketiodriver.R
import com.app.basketiodriver.ShopperApp
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.dashboard.Order
import com.app.basketiodriver.data.model.api.response.general.SimpleResponse
import com.app.basketiodriver.data.remote.socket.ChatMessageHelper
import com.app.basketiodriver.databinding.ItemOrderListBinding
import com.app.basketiodriver.di.Navigators
import com.app.basketiodriver.service.LocationService
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.PAYMENT_TYPE_CASH_1
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.PAYMENT_TYPE_CASH_2
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.PAYMENT_TYPE_CREDIT
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_ARRIVED_TO_CUSTOMER
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_ARRIVED_TO_SHOP
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_ARRIVING_TO_SHOP
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_CHECKOUT
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_DELIVERY
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_ORDER_FINISHED
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_ORDER_REVIEW
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_SHOPPING
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_SLIDE_ACKNOWLEDGE_ORDER
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_SLIDE_START_DELIVERY
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_START
import com.app.basketiodriver.ui.home.HomeActivity
import com.app.basketiodriver.utils.*
import org.greenrobot.eventbus.EventBus
import timber.log.Timber
import java.util.*

class OrderAdapter(
    val activity: FragmentActivity,
    val listener: SwipeManyStateButton.SwipeTouchListener,
    val activeToTouch: Boolean,
    private val onViewOrderInfo: (order: Order) -> Unit,
    private val onOpenStoreInstructions: (order: Order) -> Unit,
    private val onOpenMap: (orderId: Long) -> Unit,
    private val createRoom: (orderStoreId: Long) -> Unit
) :
    BaseRecyclerViewAdapter<Order, ItemOrderListBinding> (){

    private var showSwipeView = false

    override val layoutId: Int
        get() = R.layout.item_order_list

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return OrderViewHolder(createBindView(parent))
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val holder = holder as OrderViewHolder
        val orderItem = items[position]

        setOrderStatus(holder, orderItem)

        holder.binding.tvTotalTitle.isAllCaps = true
        holder.binding.tvPaymentTitle.isAllCaps = true

        holder.binding.tvBatchId.text = String.format(Locale("en"), "%s", orderItem.orderOutletId)
        holder.binding.tvOrderId.text = String.format(Locale("en"), "%s", orderItem.orderId)

        holder.binding.tvItemCount.text = String.format(
            Locale("en"),
            "%s",
            orderItem.orderedItemCount
        )

        // Total price
        val totalPrice = (orderItem.orderedTotalAmount ?: "0.0").toDouble()
        holder.binding.tvTotalPrice.text = String.format(
            Locale("en"),
            "%.2f",
            totalPrice
        )

        GlideApp.with(activity).load(orderItem.outletLogo).fitCenter()
            .placeholder(R.drawable.ic_avatar)
            .error(R.drawable.ic_avatar).into(holder.binding.ivShopper)

        GlideApp.with(activity).load(orderItem.customerImage).fitCenter()
            .placeholder(R.drawable.ic_avatar)
            .error(R.drawable.ic_avatar).into(holder.binding.ivUser)

        holder.binding.tvShopperName.text = orderItem.storeName
        holder.binding.tvShopperAddress.text = orderItem.outletLocationArea

        if (orderItem.isNewCustomer == 1){
            holder.binding.txtNew.visibility = View.VISIBLE
        }
        else{
            holder.binding.txtNew.visibility = View.GONE
        }

        holder.binding.tvUserName.text = orderItem.customerName
        holder.binding.tvUserAddress.text = orderItem.customerLocationArea

        // payment type
        if (orderItem.paymentGateway == PAYMENT_TYPE_CASH_1 || orderItem.paymentGateway == PAYMENT_TYPE_CASH_2){
            holder.binding.tvPaymentType.text = activity.getString(R.string.cash)
            holder.binding.ivPaymentType.setImageResource(R.drawable.ic_type_cash)
        }
        else if (orderItem.paymentGateway == PAYMENT_TYPE_CREDIT){
            holder.binding.tvPaymentType.text = activity.getString(R.string.credit)
            holder.binding.ivPaymentType.setImageResource(R.drawable.ic_type_card)
        }
        else{
            holder.binding.tvPaymentType.text = activity.getString(R.string.bring_cc_machine)
            holder.binding.ivPaymentType.setImageResource(R.drawable.ic_pos)
        }

//        holder.binding.tvDateDelivery.text = String.format(
//            Locale("en"),
//            "%s %s",
//            orderItem.deliveryTime.toString().trim(),
//            orderItem.orderedDate.toString().trim()
//        )

        holder.binding.tvDateDelivery.text = String.format(Locale("en"),"%s", orderItem.deliveryTime.toString().trim())

        // Completed orders count
        holder.binding.tvCompletedOrders.text = String.format(Locale.ENGLISH, activity.getString(R.string.completed_orders), orderItem.completedOrdersCount)

        // Map button click
//        holder.binding.llMap.setOnClickListener {
//            onOpenMap(orderItem.orderOutletId!!)
//        }

        // Order Info click
        holder.binding.ivInfo.setOnClickListener {
            onViewOrderInfo(orderItem)
        }

        val status = orderItem.orderStatus
        if (status == STATUS_SLIDE_ACKNOWLEDGE_ORDER || status == STATUS_START) {
            holder.binding.btnChangeStatusOrder.visibility = View.VISIBLE
            holder.binding.btnContinueOrder.visibility = View.GONE
            setListenerChangeStateButton(holder, orderItem)
            holder.binding.btnChangeStatusOrder.setOnSwipeTouchListener(listener)
        }
        else if (status in (STATUS_START + 1) until STATUS_ORDER_FINISHED) {
            holder.binding.btnChangeStatusOrder.visibility = View.GONE
            holder.binding.btnContinueOrder.visibility = View.VISIBLE
        }
        Log.d("TAG", "onBindViewHolder_status====>: "+status.toString())
        if (status == STATUS_SHOPPING){
            holder.binding.btnContinueOrder.setText(R.string.continue_shopping)
        }
        else if (status == STATUS_ORDER_REVIEW){
            holder.binding.btnContinueOrder.setText(R.string.continue_order_review)
        }
        else if (status == STATUS_CHECKOUT){
            holder.binding.btnContinueOrder.setText(R.string.continue_checkout)

            // save the order id
        }
        else if (status == STATUS_ARRIVING_TO_SHOP){
            holder.binding.btnContinueOrder.setText(R.string.continue_arriving_shop)
        }
        else if (status == STATUS_SLIDE_START_DELIVERY){
            if (PreferenceManager.shopperType == 2){
                holder.binding.btnContinueOrder.setText(R.string.continue_handover_order)
            }
            else{
                holder.binding.btnContinueOrder.setText(R.string.continue_start_delivery)
            }
        }
        else if (status == STATUS_DELIVERY){
            // save the order id
            holder.binding.btnContinueOrder.setText(R.string.continue_delivering)
        }
        else if (status == STATUS_ARRIVED_TO_CUSTOMER){
            holder.binding.btnContinueOrder.setText(R.string.continue_arrived_customer)
        }
        else if (status == STATUS_ARRIVED_TO_SHOP){
            holder.binding.btnContinueOrder.setText(R.string.continue_arrived_shopper)
        }

        // Info button
        holder.binding.imbInfo.setOnClickListener {
            orderItem.deliveryInstructions

            // show the checkout terms dialog
            showCheckoutTermDialog(orderItem)
        }

        // Continue order
        holder.binding.btnContinueOrder.setOnClickListener {
//            holder.binding.btnContinueOrder.isClickable = false

            if (status == STATUS_SHOPPING){

                // Go to order details
                Navigators.goToOrderDetails(activity, orderItem.orderOutletId ?: 0)
            }
            else if (status == STATUS_ORDER_REVIEW){

                if (PreferenceManager.shopperType == 1){  // Full-service shopper
                    // Go to Store instructions page
                    showCheckoutTermDialog(orderItem)
                }
                else{
                    // Go to checkout card page
                    Navigators.goToPaymentTypeActivity(activity, orderItem.orderOutletId ?: 0)
                }
            }
            else if (status == STATUS_CHECKOUT){

                val orderPrice = orderItem.orderedSubtotal.toDoubleOrNull() ?: 0.0

                // Go to receipt information page
                Navigators.goToReceiptInfoActivity(
                    activity,
                    orderItem.orderOutletId ?: 0,
                    orderPrice
                )
            }
            else if (status == STATUS_ARRIVING_TO_SHOP || status == STATUS_SLIDE_START_DELIVERY || status == STATUS_DELIVERY || status == STATUS_ARRIVED_TO_CUSTOMER){
                if (status == STATUS_SLIDE_START_DELIVERY && PreferenceManager.shopperType == 2){
                    // Go to handover
                    Navigators.gotoHandOver(
                        activity,
                        orderItem.orderId ?: 0,
                        orderItem.orderOutletId ?: 0
                    )
                }
                else{
                    // Go to map screen
                    Navigators.goToLocationMap(activity, orderItem.orderOutletId ?: 0, orderItem.isExpress)
                }
            }
            else if (status == STATUS_ARRIVED_TO_SHOP) {
                // Go to Order Details
                Navigators.goToLockOrderDetails(
                    activity,
                    orderItem.orderOutletId ?: 0,
                    orderItem.orderStatus
                )
            }

            // Set the customer id and outlet id
            LocationService.customerId = orderItem.customerId ?: 0
            LocationService.orderOutletId = orderItem.orderOutletId ?: 0

            PreferenceManager.orderId = orderItem.orderId ?: 0
            PreferenceManager.orderOutletId = orderItem.orderOutletId ?: 0
        }
    }

    // Add more orders
    fun addList(list: List<Order>){
        items.addAll(list)
        notifyDataSetChanged()
    }

    // Show the checkout terms dialog
    private fun showCheckoutTermDialog(orderItem : Order){
        onOpenStoreInstructions(orderItem)
    }

    private fun setListenerChangeStateButton(holder: OrderViewHolder, order: Order){
        val outletId = order.orderOutletId ?: 0
        holder.binding.btnChangeStatusOrder.setOnStateChangeListener(object :
            SwipeManyStateButton.OnStateChangeListener {
            override fun onChangeState(state: Int?) {
                if (state != null) {
                    var updateState = state

                    if (updateState > 0 && (updateState - 1 == STATUS_SLIDE_ACKNOWLEDGE_ORDER)){
                        Timber.d("OrderAdapter: Starting to sound the buzzer...")

                        try{
                            // Stop the notification sound
                            ShopperApp.Instance.stopNotificationSound(activity)
                        }
                        catch (e : Exception){
                            e.printStackTrace()
                        }
                    }

                    // Check if shopper type is in-store shopper
                    if (PreferenceManager.shopperType == 2) {
                        if ((updateState - 1) <= 3){
                            updateState = 4
                        }
                    }

                    // Update the order status
                    tryUpdateStatus(updateState)
                }
            }

            // Update the status
            private fun tryUpdateStatus(state: Int) {
                try {
                    if (!activity.isFinishing && activity is HomeActivity) {
                        activity.viewModel.updateOrderStatus(state, outletId, object :
                            HandleResponse<SimpleResponse> {
                            override fun handleErrorResponse(error: ErrorResponse?) {
                                Toast.makeText(activity, error?.message, Toast.LENGTH_SHORT).show()
                                holder.binding.btnChangeStatusOrder.previousState()
                            }

                            override fun handleSuccessResponse(successResponse: SimpleResponse) {
                                val response = successResponse.response
                                if (response != null) {
                                    if (response.httpCode == 200) {


                                        doIfSpecialState(state, order, holder)
                                    } else {
                                        Toast.makeText(
                                            activity,
                                            response.message,
                                            Toast.LENGTH_SHORT
                                        ).show()
                                        holder.binding.btnChangeStatusOrder.previousState()
                                    }
                                } else {
                                    Toast.makeText(
                                        activity,
                                        activity.getString(R.string.error_update_status),
                                        Toast.LENGTH_SHORT
                                    ).show()
                                    holder.binding.btnChangeStatusOrder.previousState()
                                }
                            }
                        })
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        })
    }

    private fun doIfSpecialState(state: Int, order: Order, holder: OrderViewHolder){
        val outletId = order.orderOutletId ?: 0
        if (state == STATUS_START|| state == STATUS_SLIDE_ACKNOWLEDGE_ORDER){
            Timber.tag("JoinRoomError").d("RoomShouldBeCreated")
            createRoom(order.orderOutletId!!)
        }

        if (state == STATUS_START){
            // Save the customer id to LocationService
            /////
            val chatMessageHelper = ChatMessageHelper()
            chatMessageHelper.OrderStarted(
                outletId,
                PreferenceManager.currentShopperFirstName
                    .toString() + " " + activity.resources.getString(R.string.started_shopping),
                order.customerId,
                order.customerName
            )

            EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_ORDER_STARTED))
        }

        if (state == STATUS_ARRIVING_TO_SHOP) {
            // Save the customer id to LocationService
            /////

            Navigators.goToLocationMap(activity, outletId, order.isExpress)
        }

        if (state == STATUS_SHOPPING) {
            // Save the customer id to LocationService
            /////

            Navigators.goToOrderDetails(activity, outletId)
        }

        if (state == STATUS_DELIVERY) {
            // Save the customer id to LocationService
            /////

            Navigators.goToLocationMap(activity, outletId, order.isExpress)
        }

        if (state >= STATUS_ORDER_FINISHED){
            holder.binding.btnChangeStatusOrder.isEnabled = false
        }
    }

    // Set the order status
    private fun setOrderStatus(holder: OrderViewHolder, order: Order){
        if (activeToTouch){
            val status = order.orderStatus
            // set the status into holder

            holder.binding.btnChangeStatusOrder.state = status
            if (status >= STATUS_ORDER_FINISHED){
                holder.binding.btnChangeStatusOrder.isEnabled = false
            }
        }
        else{
            holder.binding.btnChangeStatusOrder.isEnabled = false
        }
    }

    fun isShowSwipeView() : Boolean {
        return showSwipeView
    }

    fun setShowSwipeView(isShow: Boolean){
        showSwipeView = isShow
    }

    inner class OrderViewHolder(val binding: ItemOrderListBinding) :
        RecyclerView.ViewHolder(binding.root)
}