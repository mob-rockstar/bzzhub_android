package com.app.basketiodriver.ui.earning

import android.app.Application
import android.content.Context
import com.app.basketiodriver.BuildConfig
import com.app.basketiodriver.data.DataManager
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.earning.ShopperYearlyResponse
import com.app.basketiodriver.data.model.api.response.earning.bonus.ShopperBonusDeductionsResponse
import com.app.basketiodriver.data.model.api.response.earning.monthly.ShopperDetailsReportResponse
import com.app.basketiodriver.data.model.api.response.earning.monthly.ShopperMonthlySummaryResponse
import com.app.basketiodriver.data.model.api.response.earning.order.ShopperOrderDetailResponse
import com.app.basketiodriver.data.model.api.response.earning.payout.ShopperPayoutCreditResponse
import com.app.basketiodriver.data.model.api.ticket.TicketFieldsData
import com.app.basketiodriver.data.remote.APIManager
import com.app.basketiodriver.data.remote.ApiInterface
import com.app.basketiodriver.data.remote.BasicAuthInterceptor
import com.app.basketiodriver.data.remote.FreshchatApiService
import com.app.basketiodriver.mvvm.ui.login.LoginNavigator
import com.app.basketiodriver.ui.base.BaseViewModel
import com.app.basketiodriver.ui.base.HandleResponse
import com.google.gson.GsonBuilder
import com.google.gson.JsonObject
import com.jakewharton.retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import okhttp3.Cache
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.File
import java.util.concurrent.TimeUnit


/**
 * Created by ibraheem lubbad on 2020-02-16.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 */
class EarningViewModel(
    application: Application,
    dataManager: DataManager
) :
    BaseViewModel<LoginNavigator?>(application, dataManager) {

    // Get yearly balance report
    fun getYearlyBalanceReport(year : Int, numberOfRecord : Int, handleResponse: HandleResponse<ShopperYearlyResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperYearlyBalanceReport(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, numberOfRecord, year)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    // Get monthly balance report
    fun getMonthlyBalanceReport(month:Int, year : Int, handleResponse: HandleResponse<ShopperMonthlySummaryResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperMonthlyBalanceReport(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, month, year)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    // Get Details Report
    fun getShopperDetailsReport(month:Int, year : Int, reportType:String, weekDay : Int, handleResponse: HandleResponse<ShopperDetailsReportResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperDetailsReport(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, month, year, reportType, weekDay)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    // Shopper Payout & Credit Details
    fun getShopperPayoutCreditDetails(month:Int, year : Int, requestType:String, handleResponse: HandleResponse<ShopperPayoutCreditResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperPayoutCreditDetails(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, month, year, requestType)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    // Shopper Bonus & Deduction
    fun getShopperBonusDeductionsDetails(month:Int, year : Int, requestType:String, handleResponse: HandleResponse<ShopperBonusDeductionsResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperBonusDeductions(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, month, year, requestType)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    // Shopper Order Details
    fun getShopperOrderDetails(month:Int, year : Int, orderId:String, handleResponse: HandleResponse<ShopperOrderDetailResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperOrderDetails(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, month, year, orderId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    // Get the ticket type list
    fun getTicketTypeList(handleResponse: HandleResponse<ArrayList<TicketFieldsData>>){
        setIsLoading(true)
        compositeDisposable.add(
            FreshchatApiService.getTicketTypes()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe (
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    fun createTicket(type : String, bid : Long, subject : String, description : String, priority : Int, status : Int, attach : File?, handleResponse: HandleResponse<JsonObject>) {
        setIsLoading(true)
        compositeDisposable.add(
            FreshchatApiService.createTicket(type, bid, subject, description, priority, status, attach)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe (
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }
}