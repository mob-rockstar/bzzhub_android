package com.app.basketiodriver.ui.onboarding.fragments.UploadDocuments


import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.DocumentsResponse
import com.app.basketiodriver.databinding.FragmentDocumentBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.cardcamera.camera.IDCardCamera
import com.app.basketiodriver.ui.onboarding.OnBoardingViewModel
import com.app.basketiodriver.utils.AppLogger
import com.app.basketiodriver.utils.GlideApp
import com.squareup.picasso.Picasso

/**
 * Created by ibraheem lubbad on 2020-01-22.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class DocumentFragment :
    BaseFragment<FragmentDocumentBinding?, OnBoardingViewModel>(),
    Injectable, View.OnClickListener {

    override val layoutId: Int
        get() = R.layout.fragment_document

    override val viewModel: OnBoardingViewModel
        get() {
            return getViewModel(requireActivity(), OnBoardingViewModel::class.java)
        }

    lateinit var onbaordingDocumentEntity: DocumentsResponse.OnbaordingDocumentEntity
    var index=0
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        viewDataBinding!!.btnTakePhoto.setOnClickListener(this)

        index = arguments?.let {
            DocumentFragmentArgs.fromBundle(it).index
        }!!

        onbaordingDocumentEntity =
            viewModel.currentOnbaordingDocument?.documentEntities?.get(index)!!

        AppLogger.d("onbaordingDocumentEntity ${onbaordingDocumentEntity}")

        onbaordingDocumentEntity.let {

//            Picasso.get()
//                .load(it.placeholder_url)
//                .into(viewDataBinding!!.placeHolder)

            GlideApp.with(this).load(it.placeholder_url).error(R.drawable.placeholder).into(viewDataBinding!!.placeHolder)

            setTitle(it.title)
            viewDataBinding!!.tvDesc.text = it.description
        }





    }

    override fun onClick(p0: View?) {
        when (p0!!.id) {
            R.id.btnTakePhoto -> {
                IDCardCamera.create(this).openCamera(IDCardCamera.TYPE_IDCARD_BACK)
            }

        }
    }

    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        if (resultCode == IDCardCamera.RESULT_CODE) {
            val path = IDCardCamera.getImagePath(data)
            if (!TextUtils.isEmpty(path)) {

                onbaordingDocumentEntity.fileLocalPath=path

                if (viewModel.currentOnbaordingDocument!!.documentEntities?.size==++index){
                    navigate(
                        DocumentFragmentDirections.actionFragmentDocumentToFragmentDocumentPreview()
                    )
                }else{
                    navigate(DocumentFragmentDirections.actionFragmentDocumentSelf2().setIndex(index))
                }


            }
        }
    }

}
