package com.app.basketiodriver.ui.cardcamera.cropper2

import android.graphics.Bitmap

interface CropListener {
    fun onFinish(bitmap: Bitmap?)
}