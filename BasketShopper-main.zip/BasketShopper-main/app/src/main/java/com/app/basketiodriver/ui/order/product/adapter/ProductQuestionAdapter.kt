package com.app.basketiodriver.ui.order.product.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.customerAdditionalQuestions.AdditionalRequestItem
import com.app.basketiodriver.databinding.ItemProductQuestionBinding
import com.app.basketiodriver.utils.BaseRecyclerViewAdapter
import com.app.basketiodriver.utils.CommonUtils
import com.app.basketiodriver.utils.ViewUtils

class ProductQuestionAdapter()
 : BaseRecyclerViewAdapter<AdditionalRequestItem, ItemProductQuestionBinding>() {

    override val layoutId: Int
    get() = R.layout.item_product_question

    var taxPercent = 0.0
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return QuestionViewHolder(
            DataBindingUtil.inflate(
                LayoutInflater.from(viewGroup.context),
                R.layout.item_product_question,
                viewGroup,
                false
            )
        )
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as QuestionViewHolder
        val question = items[position]
        val mContext = holder.itemView.context


        holder.binding.tvTitle.text = CommonUtils.getAnswerTitleXByLanguage(question.title)
        if (question.title.isNotEmpty()) {

        }

        holder.binding.recyclerViewAnswer.layoutManager =
            LinearLayoutManager(mContext, LinearLayoutManager.VERTICAL, false)
        val adapter = ProductAnswerAdapter()
        adapter.taxPercent = taxPercent
        adapter.setItems(question.answers)
        holder.binding.recyclerViewAnswer.adapter = adapter
        items[position].height = ViewUtils.dpToPx((12 + (56 *items[position].answers.size)).toFloat()).toInt()
    }

    private fun isItemValid(question: AdditionalRequestItem): Boolean {
        if (question.type == "checkbox") {
            var selectedCount = 0
            if (!question.validation.required) return true
            if (question.validation.min == 0) return true
            for (answer in question.answers) {
                if (question.validation.repeat > 0){
                    if (answer.selected) selectedCount += answer.answer_count
                }else{
                    if (answer.selected) selectedCount++
                }
            }
            if (selectedCount > question.validation.min - 1) return true
        } else {
            for (answer in question.answers) {
                if (answer.selected) return true
            }
        }
        return false
    }

    override fun getItemCount(): Int {
        return items.size
    }

    fun getItems(): List<AdditionalRequestItem> {
        return items
    }

    inner class QuestionViewHolder(val binding: ItemProductQuestionBinding) :
        RecyclerView.ViewHolder(binding.root)
}