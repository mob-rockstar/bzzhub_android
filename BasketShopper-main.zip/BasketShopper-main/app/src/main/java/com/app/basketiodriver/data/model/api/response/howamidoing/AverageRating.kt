package com.app.basketiodriver.data.model.api.response.howamidoing

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName

class AverageRating {
    @SerializedName("rating")
    @Expose
    var rating: String? = null

    @SerializedName("rating_text")
    @Expose
    var rating_text: String = ""
}