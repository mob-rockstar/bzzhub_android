package com.app.basketiodriver.data.model.api.response.earning

class YearEarningsData {
    var year: String = ""
    var items : ArrayList<YearlyBalanceReportItem> = arrayListOf()
}