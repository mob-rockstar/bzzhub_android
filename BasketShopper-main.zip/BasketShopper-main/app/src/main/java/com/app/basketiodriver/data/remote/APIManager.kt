package com.app.basketiodriver.data.remote

import android.content.Context
import com.app.basketiodriver.BuildConfig
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.chat.BaseResponse
import com.app.basketiodriver.data.model.api.response.*
import com.app.basketiodriver.data.model.api.response.checkout.ShopperOrderDetail
import com.app.basketiodriver.data.model.api.response.checkout.ShopperOrderReview
import com.app.basketiodriver.data.model.api.response.checkout.ShopperOrderTimer
import com.app.basketiodriver.data.model.api.response.dashboard.OrderResponse
import com.app.basketiodriver.data.model.api.response.dashboard.ShopperOrderByIDResponse
import com.app.basketiodriver.data.model.api.response.earning.ShopperYearlyResponse
import com.app.basketiodriver.data.model.api.response.earning.bonus.ShopperBonusDeductionsResponse
import com.app.basketiodriver.data.model.api.response.earning.monthly.ShopperDetailsReportResponse
import com.app.basketiodriver.data.model.api.response.earning.monthly.ShopperMonthlySummaryResponse
import com.app.basketiodriver.data.model.api.response.earning.order.ShopperOrderDetailResponse
import com.app.basketiodriver.data.model.api.response.earning.payout.ShopperPayoutCreditResponse
import com.app.basketiodriver.data.model.api.response.general.SimpleResponse
import com.app.basketiodriver.data.model.api.response.hours.BookingReportResponse
import com.app.basketiodriver.data.model.api.response.hours.RateCardResponse
import com.app.basketiodriver.data.model.api.response.howamidoing.HowAmIDoingDetailResponse
import com.app.basketiodriver.data.model.api.response.howamidoing.HowAmIDoingResponse
import com.app.basketiodriver.data.model.api.response.howamidoing.ShopperRatingResponse
import com.app.basketiodriver.data.model.api.response.notification.NotificationResponse
import com.app.basketiodriver.data.model.api.response.order.*
import com.app.basketiodriver.data.model.api.response.otp.CheckOTP
import com.app.basketiodriver.data.model.api.response.profile.ProfileImageResponse
import com.app.basketiodriver.data.model.api.response.settings.SettingsResponse
import com.app.basketiodriver.data.model.api.response.shopper.ShopperResponse
import com.app.basketiodriver.data.model.api.response.terms.AgreeTermAndConditionResponse
import com.app.basketiodriver.data.model.api.response.terms.TermsAndConditionResponse
import com.app.basketiodriver.data.remote.socket.ActiveDeviceTokenResponse
import com.app.basketiodriver.data.remote.socket.SocketTokenResponse
import com.app.basketiodriver.data.remote.socket.SystemMessage
import com.app.basketiodriver.data.remote.socket.SystemMessageReq
import com.google.gson.GsonBuilder
import com.google.gson.JsonObject
import com.jakewharton.retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import io.reactivex.Single
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.File
import java.util.concurrent.TimeUnit


object APIManager {

    private const val CACHE_FILE_NAME = "basket_http_cache"
    private lateinit var apiInterface: ApiInterface

    private val langCode: Int
        get() = PreferenceManager.currentUserLanguage

    private val shopperId: Long
        get() = PreferenceManager.currentShopperId ?: 0

    private val token: String
        get() = PreferenceManager.accessToken ?: ""

    private val fcmToken: String
        get() = PreferenceManager.fcmToken ?: ""

    private val deviceId: String
        get() = PreferenceManager.deviceId ?: ""

    private var USER_TYPE = "shopper"

    fun init(context: Context) {
        // cache
        val cacheFile = File(context.cacheDir, CACHE_FILE_NAME)
        cacheFile.mkdir()
        val cache = Cache(cacheFile, 10 * 1000 * 1000)

        // OKHttp
        val okHttpClient = OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .readTimeout(50, TimeUnit.SECONDS)
            .addInterceptor(LoggingInterceptor())
            .cache(cache)
            .build()

        // Retrofit
        val retrofit = Retrofit.Builder()
            .baseUrl(BuildConfig.BASE_URL)
            .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
            .addConverterFactory(
                GsonConverterFactory.create(
                    GsonBuilder()
                        .setLenient()
                        .create()
                )
            )
            .client(okHttpClient).build()

        apiInterface = retrofit.create(ApiInterface::class.java)
    }

    // Login with password api
    fun loginWithPassword(lang : Int, mobile : String, password : String) : Single<Login> {
        return apiInterface.loginWithPassword(lang, mobile, password, deviceId, fcmToken)
    }

    // Forgot password
    fun forgotPassword(lang : Int, mobile : String) : Single<SimpleResponse> {
        return apiInterface.sendForgotPasswordRequest(lang, mobile)
    }

    // Verify OTP
    fun checkOTPRequest(lang : Int, mobile:String, otp:String) : Single<CheckOTP>{
        return apiInterface.verifyOTP(lang, mobile, otp)
    }

    // Set new password
    fun setNewPassword(lang : Int, mobile : String, newPass : String, confirmPass:String) : Single<SimpleResponse>{
        return apiInterface.changeShopperPassword(lang, mobile, newPass, confirmPass)
    }

    // Get shopper details
    fun getShopperDetails(lang : Int, shopperId : Long) : Single<ShopperResponse>{
        return apiInterface.shopperDetailRequest(lang, shopperId, PreferenceManager.accessToken!!)
    }

    // Update profile image
    fun updateProfileImage(lang : Int, shopperId : Long, token : String, profileImage : File?) : Single<ProfileImageResponse> {
        var image: MultipartBody.Part? = null
        image = if (profileImage != null) {
            val requestFile: RequestBody = profileImage.asRequestBody("image/png".toMediaTypeOrNull())
            MultipartBody.Part.createFormData("image", profileImage.name, requestFile)
        } else {
            val attachmentEmpty = "".toRequestBody("image/png".toMediaTypeOrNull())
            MultipartBody.Part.createFormData("image", "", attachmentEmpty)
        }

        return apiInterface.shopperUpdateProfileImage(
            lang.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            shopperId.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            token.toRequestBody("text/plain".toMediaTypeOrNull()),
            image)

    }

    // Update password
    fun updateShopperPassword(lang : Int, mobile : String, oldPass: String, newPass : String, confirmPass:String, shopperId : Long, token : String) : Single<SimpleResponse>{
        return apiInterface.updateShopperPassword(lang, mobile, oldPass, newPass, confirmPass, shopperId, token)
    }

    // Shopper Booking Report
    fun shopperBookingReport(lang:Int, shopperId:Long, token :String, fromDate:String, toDate:String): Single<BookingReportResponse>{
        return apiInterface.shopperBookingReport(lang,shopperId, token, fromDate, toDate)
    }

    // shopperPastHoursReport
    fun shopperPastHoursReport(lang:Int, shopperId:Long, token :String, fromDate:String, toDate:String) : Single<PastHourReportResponse>{
        return apiInterface.getShopperPastHourReport(lang, shopperId, token, fromDate, toDate)
    }

    // Shopper Booking Slots
    fun shopperBookingSlots(lang:Int, shopperId:Long, token :String, date:String) : Single<BookingSlotsResponse>{
        return apiInterface.getShopperBookingSlots(lang, shopperId, token, date)
    }

    // Shopper Booking Slots With ZoneId
    fun shopperBookingSlotsWithZone(lang:Int, shopperId:Long, token :String, date:String, zoneId:Int): Single<BookingSlotsResponse>{
        return apiInterface.getShopperBookingSlotsWithZone(lang, shopperId, token, date, zoneId.toString())
    }

    // Shopper Zones
    fun shopperZones(lang:Int, shopperId:Long, token :String, date:String) : Single<ShopperZonesResponse> {
        return apiInterface.getShopperZones(lang, shopperId, token, date)
    }

    // Shopper Rate Card
    fun shopperRateCard(lang:Int, shopperId:Long, token :String, date:String) : Single<RateCardResponse> {
        return apiInterface.getShopperRateCard(lang, shopperId, token, date)
    }

    // Manage Shopper Booking
    fun manageShopperBooking(lang:Int, shopperId:Long, token :String, date:String, slots:String, action : String) : Single<ManageBookingSlotsResponse>{
        return apiInterface.manageShopperBooking(lang, shopperId, token, date, slots, action)
    }

    // Shopper Yearly Balancing
    fun shopperYearlyBalanceReport(lang:Int, shopperId:Long, token :String, recordCount: Int, year : Int) : Single<ShopperYearlyResponse>{
        return apiInterface.shopperYearlyAccountBalanceReport(lang, shopperId, token, recordCount, year)
    }
    // Shopper Monthly Balancing
    fun shopperMonthlyBalanceReport(lang:Int, shopperId:Long, token :String, month:Int, year : Int) : Single<ShopperMonthlySummaryResponse>{
        return  apiInterface.shopperMonthlyAccountReport(lang, shopperId, token, month, year)
    }

    // Shopper Details Report
    fun shopperDetailsReport(lang:Int, shopperId:Long, token :String, month:Int, year : Int, reportType : String, weekDay : Int) : Single<ShopperDetailsReportResponse>{
        return apiInterface.shopperDetailsReport(lang,shopperId, token, reportType, weekDay, month, year)
    }

    // Shopper Payout & Credit details
    fun shopperPayoutCreditDetails(lang:Int, shopperId:Long, token :String, month:Int, year : Int, type : String) : Single<ShopperPayoutCreditResponse>{
        return apiInterface.getShopperPayoutCreditDetails(lang,shopperId, token, type, month, year)
    }

    // Shopper Bonus & Deductions
    fun shopperBonusDeductions(lang:Int, shopperId:Long, token :String, month:Int, year : Int, type : String) : Single<ShopperBonusDeductionsResponse>{
        return apiInterface.getShopperBonusDeductionDetails(lang, shopperId, token, type, month, year)
    }

    // Shopper Order Detail
    fun shopperOrderDetails(lang:Int, shopperId:Long, token :String, month:Int, year : Int, id : String) : Single<ShopperOrderDetailResponse>{
        return apiInterface.getShopperOrderDetailsReport(lang, shopperId, token, id, month, year)
    }

    // Shopper How Am I Doing
    fun shopperHowAmIDoing(lang:Int, shopperId:Long, token :String) : Single<HowAmIDoingResponse>{
        return apiInterface.howAmIDoing(lang, shopperId, token)
    }

    // Shopper How Am I Doing Details
    fun shopperHowAmIDoingDetails(lang:Int, shopperId:Long, token :String, action : String) : Single<HowAmIDoingDetailResponse>{
        return apiInterface.howAmIDoingDetails(lang, shopperId, token, action)
    }

    // Shopper Rating Details
    fun shopperRatingDetails(lang:Int, shopperId:Long, token :String, type : String) : Single<ShopperRatingResponse>{
        return apiInterface.shopperRatingDetails(lang, shopperId, token, type)
    }

    // Service App Token
    fun getServiceAppToken(shopperId:Long, token :String) : Single<ServerTokenResponse>{
        return apiInterface.getServiceAppToken(shopperId, token)
    }

    // Change the shopper status
    fun changeShopperOnlineStatus(lang:Int, shopperId:Long, token :String, status : Int, startEarly : Int) : Single<SimpleResponse>{
        return apiInterface.shopperChangeOnlineStatus(lang, shopperId, token, status, startEarly)
    }

    // Ger Orders
    fun getOrders(lang:Int, shopperId:Long, token :String, limit:Int, offset:Int) : Single<OrderResponse>{
        return apiInterface.getOrders(lang, shopperId, token, limit, offset)
    }

    // Get shopper order by id
    fun getShopperOrderByID(lang:Int, shopperId:Long, token :String, orderId : Long) : Single<ShopperOrderByIDResponse>{
        return apiInterface.getShopperOrdersById(lang, shopperId, token, orderId)
    }

    // Update the order status
    fun updateOrderStatus(lang:Int, shopperId:Long, token :String, shopperStatus : Int, orderStatus : Int, orderId : Long) : Single<SimpleResponse>{
        return apiInterface.shopperUpdateStatusRequest(lang, shopperId, token, shopperStatus, orderStatus, orderId)
    }

    // Shopper Order Details
    fun shopperOrderDetailRequest(lang:Int, shopperId:Long, token :String, orderId : String, route : String): Single<ShopperOrderDetail>{
        return apiInterface.shopperOrdersDetailRequest(lang, shopperId, token, orderId, route)
    }

    // Shopper Order Timer
    fun shopperOrderTimerRequest(lang:Int, shopperId:Long, token :String, orderId: Long) : Single<ShopperOrderTimer>{
        return apiInterface.shopperOrderTimerRequest(lang, shopperId, token, orderId)
    }

    // Shopper Order Review
    fun shopperOrderReview(lang:Int, shopperId:Long, token :String, orderId: Long) : Single<ShopperOrderReview>{
        return apiInterface.getShopperOrderReview(lang, shopperId, token, orderId)
    }

    // Dashboard Order Review
    fun getDashboardOrderInfo(lang:Int, shopperId:Long, token :String, orderId: Long) : Single<DashboardOrderInfoResponse>{
        return apiInterface.getDashboardOrderInfo(lang, shopperId, token, orderId)
    }

    fun getHistoryOrderInfo(lang:Int, shopperId:Long, token :String, orderId: Long) : Single<HistoryOrderInfoResponse>{
        return apiInterface.getHistoryOrderInfo(lang, shopperId, token, orderId)
    }

    // Get reason list
    fun getCanNotFindItemReasonList(lang:Int, shopperId:Long, token :String) : Single<CommonResponse>{
        return apiInterface.getCanNotFindItemReasonList(lang, shopperId, token)
    }

    // Upload Chat attachment
    fun uploadChatAttachment(
        attachment: File,
        messageType: String,
        orderStoreId: Int,
        userType: String,
        userId: Long
    ): Single<com.app.basketiodriver.data.model.api.chat.BaseResponse> {
        val requestFile: RequestBody =
            attachment.asRequestBody("multipart/form-data".toMediaTypeOrNull())
        // MultipartBody.Part is used to send also the actual file name
        val attachmentBody = MultipartBody.Part.createFormData("file", attachment.name, requestFile)
        val messageTypeBody: RequestBody =
            messageType.toRequestBody("text/plain".toMediaTypeOrNull())
        val orderStoreIdBody: RequestBody =
            orderStoreId.toString().toRequestBody("text/plain".toMediaTypeOrNull())
        val userTypeBody: RequestBody = userType.toRequestBody("text/plain".toMediaTypeOrNull())
        val userIdBody: RequestBody =
            userId.toString().toRequestBody("text/plain".toMediaTypeOrNull())

        return apiInterface.uploadChatAttachment(
            PreferenceManager.socketToken!!,
            attachmentBody,
            messageTypeBody,
            orderStoreIdBody,
            userTypeBody,
            userIdBody
        )
    }


    // API to get maintenance detail
//    fun maintenanceDetails(): Single<MaintenanceResponse> {
//        return apiInterface.maintenanceDetails()
//            .map { serverResponse: ServerResponse<MaintenanceResponse>? -> serverResponse!!.response }
//    }


    // Confirm the replaced item
    fun confirmReplacedItem(lang:Int, shopperId:Long, token :String, id : Long, qty : Double) : Single<SimpleResponse>{
        return apiInterface.requestConfirmReplacedItem(lang, shopperId, token, id, qty)
    }

    // Cancel the replaced item
    fun cancelReplacedItem(lang:Int, shopperId:Long, token :String, id : Long) : Single<SimpleResponse>{
        return apiInterface.requestCancelReplacedItem(lang, shopperId, token, id)
    }

    // Mark as found
    fun shopperMarkItemAsFound(lang:Int, shopperId:Long, token :String, id : Long, isFound : Boolean, isQtyDiff : Boolean) : Single<SimpleResponse>{
        return apiInterface.shopperMarkItemAsFound(lang, shopperId, token, id, (if (isFound) 1 else 0), (if (isQtyDiff) 1 else 0), 0)
    }

    // Update the item quantity
    fun updateItemQty(lang:Int, shopperId:Long, token :String, id : Long, amount: Double) : Single<SimpleResponse> {
        return apiInterface.requestUpdateItemQty(lang, shopperId, token, id, amount)
    }

    // Confirm the item qty difference
    fun confirmItemQtyDifference(lang:Int, shopperId:Long, token :String, id : Long) : Single<SimpleResponse>{
        return apiInterface.requestItemConfirmQtyDifference(lang, shopperId, token, id)
    }

    // Cancel the item qty difference
    fun cancelItemQtyDifference(lang:Int, shopperId:Long, token :String, id : Long) : Single<SimpleResponse>{
        return apiInterface.requestCancelItemQtyDifference(lang, shopperId, token, id)
    }

    // Cancel the refund
    fun cancelRefund(lang:Int, shopperId:Long, token :String, id : Long) : Single<SimpleResponse>{
        return apiInterface.requestCancelRefund(lang, shopperId, token, id)
    }

    // Update the item weight
    fun updateItemWeight(lang:Int, shopperId:Long, token :String, id : Long, weight : Double, qty: Double) : Single<SimpleResponse> {
        return apiInterface.updateActualWeight(lang, shopperId, token, id, weight, qty)
    }

    // Set the item not found reason
    fun setItemNotFoundReason(lang:Int, shopperId:Long, token :String, orderId : Long, outletId : Long, orderItemId : Int, reasonId : Int) : Single<CommonResponse>{
        return apiInterface.setItemNotFoundReason(lang, shopperId, token, orderId, outletId, orderItemId, reasonId)
    }

    // Shopper suggestion product list
    fun shopperSuggestionProductList(lang:Int, shopperId:Long, token :String, itemId : Long, orderId: Long, search : String?) : Single<SuggestionResponse> {
        return apiInterface.shopperSuggestionProductList(lang, shopperId, token, itemId, orderId, search)
    }

    // Refund item
    fun itemRefund(lang:Int, shopperId:Long, token :String, itemId : Long, action : Int) : Single<CommonResponse>{
        return apiInterface.itemRefund(lang, shopperId, token, itemId, action)
    }

    // Check the barcode
    fun checkProductBarcode(lang:Int, shopperId:Long, token :String, itemId : Long, code : String, isReplace : Int, replaceItemId : Long) : Single<CommonResponse>{
        return apiInterface.checkProductBarcode(lang, shopperId, token, itemId, code, isReplace, replaceItemId)
    }

    // Replace the multiple items
    fun replaceMultipleItems(json : JsonObject) : Single<CommonResponse>{
//        val requestJson = json.toString().toRequestBody("text/plain".toMediaTypeOrNull())
        return apiInterface.shopperReplaceMultipleItems(json)
    }

    // add force as found
    fun addForceMarkAsFound(lang:Int, shopperId:Long, token :String, orderId : Long, orgItemId : Long, barcode : String, file : File) : Single<SimpleDataResponse>{
        var image: MultipartBody.Part? = null
        if (file != null) {
            val requestFile: RequestBody = file.asRequestBody("image/png".toMediaTypeOrNull())
            image = MultipartBody.Part.createFormData("scanned_product_image", file.name, requestFile)
        }

        return apiInterface.addForceMarkAsFound(
            lang.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            shopperId.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            token.toRequestBody("text/plain".toMediaTypeOrNull()),
            orderId.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            orgItemId.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            barcode.toRequestBody("text/plain".toMediaTypeOrNull()),
            image)
    }

    // Similar product list
    fun shopperSimilarProductList(lang:Int, shopperId:Long, token :String, itemId: Long, isCustom : Int, searchKey : String) : Single<SimilarResponse>{
        return apiInterface.shopperSimilarProductList(lang, shopperId, token, itemId, isCustom, searchKey)
    }

    // Add product list
    fun shopperAddProductList(lang:Int, shopperId:Long, token :String, itemId: Long, searchKey : String) : Single<SimilarResponse>{
        return apiInterface.shopperAddProductList(lang, shopperId, token, itemId, searchKey)
    }

    // Replace item to be done
    fun shopperReplaceItemToDone(lang:Int, shopperId:Long, token :String, qty : Double, weight: Double, oldItemId : Long, newItemId : Long, orderId : Long, actionFrom : Int) : Single<SimilarResponse> {
        return apiInterface.shopperReplaceItemToDone(lang, shopperId, token, orderId, qty, weight, oldItemId, newItemId, actionFrom)
    }

    // Replace item to be done
    fun shopperReplaceItem(lang:Int, shopperId:Long, token :String, qty : Double, oldItemId : Long, newItemId : Long, orderId : Long, actionFrom : Int) : Single<CommonResponse> {
        return apiInterface.shopperReplaceItem(lang, shopperId, token, qty, oldItemId, newItemId, orderId, actionFrom)
    }

    // Get product by barcode
    fun getProductByBarcode(lang:Int, shopperId:Long, token :String, outletId : Long, barcode : String) : Single<ItemResponse> {
        return apiInterface.getProductByBarcode(lang, shopperId, token, outletId, barcode)
    }

    // Get check custom item by barcode
    fun getCheckItemByBarcode(lang:Int, shopperId:Long, token :String, outletId : Long, barcode : String) : Single<SimpleResponse> {
        return apiInterface.getCheckItemByBarcode(lang, shopperId, token, outletId, barcode)
    }

    // Add item by barcode
    fun addItemByBarcode(lang:Int, shopperId:Long, token :String, outletId : Long, barcode : String, qty : Double, isScanned : Int) : Single<SimpleResponse>{
        return apiInterface.addItemByBarcode(lang, shopperId, token, outletId, barcode, qty, isScanned)
    }

    // Add custom item
    fun addCustomProduct(lang:Int, shopperId:Long, token :String, orderId : Long, barcode : String, name : String, file : File?, contain : Int, unit : String, count : Double, price : Double) : Single<SimpleResponse>{
        var image: MultipartBody.Part? = null
        if (file != null) {
            val requestFile: RequestBody = file.asRequestBody("image/*".toMediaTypeOrNull())
            image = MultipartBody.Part.createFormData("product_image", file.name, requestFile)
        }

        return apiInterface.addCustomProduct(
            lang.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            shopperId.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            token.toRequestBody("text/plain".toMediaTypeOrNull()),
            orderId.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            barcode.toRequestBody("text/plain".toMediaTypeOrNull()),
            name.toRequestBody("text/plain".toMediaTypeOrNull()),
            image,
            contain.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            unit.toRequestBody("text/plain".toMediaTypeOrNull()),
            count.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            price.toString().toRequestBody("text/plain".toMediaTypeOrNull())
            )
    }

    // Replace the custom item
    fun replaceCustomItem(lang:Int, shopperId:Long, token :String, orderId : Long, barcode : String, name : String, file : File?, contain : Int, unit : String, count : Double, price : Double) : Single<SimpleResponse>{
        var image: MultipartBody.Part? = null
        if (file != null) {
            val requestFile: RequestBody = file.asRequestBody("image/*".toMediaTypeOrNull())
            image = MultipartBody.Part.createFormData("product_image", file.name, requestFile)
        }

        return apiInterface.replaceCustomProduct(
            lang.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            shopperId.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            token.toRequestBody("text/plain".toMediaTypeOrNull()),
            orderId.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            barcode.toRequestBody("text/plain".toMediaTypeOrNull()),
            name.toRequestBody("text/plain".toMediaTypeOrNull()),
            image,
            contain.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            unit.toRequestBody("text/plain".toMediaTypeOrNull()),
            count.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            price.toString().toRequestBody("text/plain".toMediaTypeOrNull())
        )
    }

    // Flag item
    fun shopperFlagItem(shopperId:Long, token :String, orderId : Long, reason : Int) : Single<SimpleResponse>{
        return apiInterface.shopperFlagItemRequest(shopperId, token, orderId, reason)
    }

    // Update the subtotal
    fun shopperUpdateSubtotal(lang:Int, shopperId:Long, token :String, orderId : Long, price: Double) : Single<SimpleResponse>{
        return  apiInterface.shopperUpdateSubtotalRequest(lang, shopperId, token, orderId, price)
    }

    // Upload the order receipt
    fun shopperSendOrderReceipt(shopperId:Long, token :String, orderId: Long, receiptNo : String, photoPaths : List<String>) : Single<CommonResponse> {
        val body = arrayOfNulls<MultipartBody.Part>(photoPaths.size)
        for (i in photoPaths.indices) {
            val file = File(photoPaths[i])
            val requestFile: RequestBody = file.asRequestBody("image/*".toMediaTypeOrNull())
            body[i] = MultipartBody.Part.createFormData("order_recipt[]", file.name, requestFile)
        }

        return apiInterface.shopperSendOrderReceiptNew(
            "1".toRequestBody("text/plain".toMediaTypeOrNull()),
            shopperId.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            token.toRequestBody("text/plain".toMediaTypeOrNull()),
            orderId.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            body,
            receiptNo.toRequestBody("text/plain".toMediaTypeOrNull()))
    }

    // Handover
    fun updateHandoverCode(shopperId:Long, token :String, orderId : Long, outletId : Long) : Single<HandoverCodeResponse>{
        return apiInterface.updateHandOverCode(shopperId, token, orderId, outletId)
    }

    // Verify Handover code
    fun verifyHandoverCode(shopperId:Long, token :String, code : String) : Single<HandoverCodeResponse>{
        return apiInterface.verifyHandOverCode(shopperId, token, code)
    }

    fun pushAmountFromCustomer(lang:Int, shopperId:Long, token :String, orderId: Long, receivedBy : Double, returnedTo : Double) : Single<SimpleResponse>{
        return apiInterface.amountFromCustomer(lang, shopperId, token, orderId, receivedBy, returnedTo)
    }

    fun shopperTermsAndConditions(lang:Int, shopperId:Long, token :String) : Single<TermsAndConditionResponse>{
        return apiInterface.shopperTermsAndCondition(lang, shopperId, token)
    }

    fun agreeTermsAndConditions(lang:Int, shopperId:Long, token :String) : Single<AgreeTermAndConditionResponse>{
        return apiInterface.agreeTermsAndCondition(lang, shopperId, token)
    }

    fun storePocketMoney(lang:Int, shopperId:Long, token :String, money : Double) : Single<SimpleResponse>{
        return apiInterface.storePocketMoney(lang, shopperId, token, money)
    }

    // Check version
    fun checkVersion(lang: Int, version : String, buildVersion : String, appId : String) : Single<AppVersion> {
        return apiInterface.checkAppVersion(lang, "android_shopper", version, buildVersion, appId)
    }

    // Get notification
    fun shopperNotification(shopperId:Long, token :String) : Single<NotificationResponse> {
        return apiInterface.shopperNotification(shopperId, token)
    }

    // Get All Active Firebase Token of current User
    fun getActiveDeviceTokenList(): Single<ActiveDeviceTokenResponse> {
        return apiInterface.getDeviceTokenList(langCode, shopperId, token, USER_TYPE)
    }

    //Get token of socket server
    fun getSocketToken(): Single<SocketTokenResponse> {
        return apiInterface.getSocketToken(langCode, shopperId, token)
    }

    fun sendSystemMessage(systemMessageReq : SystemMessageReq) : Single<SystemMessage> {
        return apiInterface.sendSystemMessage(systemMessageReq, PreferenceManager.socketToken!!).subscribeOn(
            Schedulers.io()).observeOn(
            AndroidSchedulers.mainThread())
    }

    // Get order otp
    fun getOrderOTP(lang:Int, shopperId:Long, token :String, outletId : Long) : Single<OrderOTPResponse>{
        return apiInterface.getOrderOTP(lang, shopperId, token, outletId)
    }

    // Get the settings
    fun getSettings(countryID : Int, cityID : Int) : Single<SettingsResponse>{
        return apiInterface.getContactSettings(countryID, cityID)
    }

}