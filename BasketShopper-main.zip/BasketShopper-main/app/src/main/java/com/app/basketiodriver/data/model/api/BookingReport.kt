package com.app.basketiodriver.data.model.api

import com.google.gson.annotations.SerializedName


/**
Created by ibraheem lubbad on 2020-02-11.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
data class BookingReport(
    @SerializedName("date") val date: String,
    @SerializedName("slot_date") val slot_date: String,
    @SerializedName("is_peak_hour_10") val is_peak_hour_10: Int,
    @SerializedName("is_peak_hour_20") val is_peak_hour_20: Int,
    @SerializedName("is_shopper_require_flag") val is_shopper_require_flag: Int,
    @SerializedName("is_shopper_require_text") val is_shopper_require_text: String,
    @SerializedName("total_require") val total_require: Int,
    @SerializedName("total_booked") val total_booked: Int,
    @SerializedName("min_book_hour") val min_book_hour: String,
    @SerializedName("max_book_hour") val max_book_hour: String,
    @SerializedName("zone") val zone: String,
    @SerializedName("service_type") val service_type: String,
    @SerializedName("is_RI_reached") val is_RI_reached: Boolean
)