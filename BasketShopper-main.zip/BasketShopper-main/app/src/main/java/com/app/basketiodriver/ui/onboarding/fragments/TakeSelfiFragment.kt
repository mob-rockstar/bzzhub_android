package com.app.basketiodriver.ui.onboarding.fragments


import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import android.widget.Toast
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.Base.BaseResponse
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.databinding.FragmentTakeSelfiBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.cardcamera.camera.IDCardCamera
import com.app.basketiodriver.ui.onboarding.OnBoardingViewModel
import com.app.basketiodriver.utils.AppLogger
import java.io.File

/**
 * Created by ibraheem lubbad on 2020-01-22.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class TakeSelfiFragment :
    BaseFragment<FragmentTakeSelfiBinding?, OnBoardingViewModel>(), View.OnClickListener,
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_take_selfi

    override val viewModel: OnBoardingViewModel
        get() {
            return getViewModel(requireActivity(), OnBoardingViewModel::class.java)
        }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.take_a_selfie))
        viewDataBinding!!.btnTakePhoto.setOnClickListener(this)
    }

    override fun onClick(p0: View?) {
        when (p0!!.id) {
            R.id.btnTakePhoto -> {

                IDCardCamera.create(this).openCamera(IDCardCamera.TYPE_IDCARD_BACK)
            }

        }
    }

    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        if (resultCode == IDCardCamera.RESULT_CODE) {


            val path = IDCardCamera.getImagePath(data)

            /**
             * go to next screen after capture image
             */
            if (!TextUtils.isEmpty(path)) {
                viewModel.uploadUserImage(File(path),     object : HandleResponse<BaseResponse> {
                    override fun handleErrorResponse(error: ErrorResponse?) {
                        AppLogger.d("handleErrorResponse  ${error}")
                        if (isNetworkConnected){
                            Toast.makeText(baseActivity, error?.message, Toast.LENGTH_LONG).show()
                        }
                        else{
                            Toast.makeText(baseActivity, baseActivity!!.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                        }
                    }

                    override fun handleSuccessResponse(successResponse: BaseResponse) {
                        AppLogger.d("popNavigate ${ popNavigate(R.id.reviewApplicationFragment)}")
                    }

                });

            }

        }
    }


}
