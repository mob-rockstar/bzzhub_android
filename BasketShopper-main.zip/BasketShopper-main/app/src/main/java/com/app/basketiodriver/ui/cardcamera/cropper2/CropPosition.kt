package com.app.basketiodriver.ui.cardcamera.cropper2

enum class CropPosition {
    TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT
}