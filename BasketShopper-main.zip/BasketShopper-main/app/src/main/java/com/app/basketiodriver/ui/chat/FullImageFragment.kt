package com.app.basketiodriver.ui.chat

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentFullImageBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseDialogFragment
import com.app.basketiodriver.utils.GlideApp


class FullImageFragment (

) : BaseDialogFragment<FragmentFullImageBinding?, ChatViewModel>(),
    Injectable {

    override val layoutId: Int
        get() = R.layout.fragment_full_image

    override val viewModel: ChatViewModel
        get() {
            return getViewModel(baseActivity, ChatViewModel::class.java)
        }


    // Set Full screen
    override fun getTheme(): Int {
        return R.style.MyDialogWhite
    }


    var imageURL = ""

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        arguments?.let {
            imageURL = it.getString(FullScreenVideoPreviewFragment.KEY_URL, "")
        }

        if (imageURL == null) {
            dismiss()
        }

        viewDataBinding?.ivClose?.setOnClickListener { dismiss() }
        GlideApp.with(baseActivity).load(imageURL).fitCenter().error(R.drawable.placeholder300x300)
            .into(viewDataBinding?.ivFullImage!!)

    }

    companion object {
        const val KEY_URL = "arg_url"
        // endregion
        /** Returns a new instance of this fragment for the given section number.  */
        fun newInstance(url : String): FullImageFragment {
            val fragment = FullImageFragment()
            val args = Bundle()
            args.putString(KEY_URL, url)

            fragment.arguments = args
            return fragment
        }
    }
}