package com.app.basketiodriver.data.model.api.response.earning.monthly

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ReportView (
    // Week Report
    @SerializedName("day_name")
    var day_name: String = "",

    @SerializedName("day_balance")
    val day_balance: String = "0.00",

    // Month Report
    @SerializedName("week_name")
    val week_name: String = "",

    @SerializedName("week_balance")
    val week_balance: String = "0.00",

    // Day Report
    @SerializedName("order_outlet_id")
    val order_outlet_id: String? = null,

    @SerializedName("order_id")
    val order_id: String? = null,

    @SerializedName("outlet_id")
    val outlet_id: String? = null,

    @SerializedName("order_total_amount")
    val order_total_amount: String? = null,

    @SerializedName("vendor_name")
    val vendor_name: String = "",

    @SerializedName("vendor_address")
    val vendor_address: String = "",

    @SerializedName("first_name")
    val first_name: String = "",

    @SerializedName("last_name")
    val last_name: String = "",

    @SerializedName("ordered_item_count")
    val ordered_item_count: String? = null,

    @SerializedName("service_type")
    val service_type: String = "",

    @SerializedName("distance_in_km")
    val distance_in_km: String = "0.00",

    @SerializedName("customer_address")
    val customer_address: String = "",

    @SerializedName("service_type_flag")
    val service_type_flag : Int = 0,

    @SerializedName("vendor_image")
    val vendor_image: String? = null
) : Parcelable