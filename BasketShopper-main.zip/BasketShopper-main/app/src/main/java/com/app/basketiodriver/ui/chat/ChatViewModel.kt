package com.app.basketiodriver.ui.chat

import android.app.Application
import androidx.lifecycle.MutableLiveData
import com.app.basketiodriver.data.DataManager
import com.app.basketiodriver.data.model.api.chat.BaseResponse
import com.app.basketiodriver.data.remote.APIManager
import com.app.basketiodriver.data.remote.socket.ActiveDeviceTokenResponse
import com.app.basketiodriver.data.remote.socket.SocketTokenResponse
import com.app.basketiodriver.ui.base.BaseNavigator
import com.app.basketiodriver.ui.base.BaseViewModel
import com.app.basketiodriver.ui.base.HandleResponse
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import java.io.File

/**
 * Created by ibraheem lubbad on 2020-02-09.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 */
class ChatViewModel constructor(application: Application, dataManager: DataManager) :
    BaseViewModel<BaseNavigator?>(application, dataManager) {

    val connectivityStateLD: MutableLiveData<Int>? = dataManager.getConnectivityStateLD()

    // Upload Chat Attachment
    fun uploadChatAttachment(
        attachment: File,
        messageType: String,
        orderStoreId: Int,
        userType: String,
        userId: Long,
        handleResponse: HandleResponse<BaseResponse>
    ) {
        compositeDisposable.add(
            APIManager.uploadChatAttachment(
            attachment,
            messageType,
            orderStoreId,
            userType,
            userId
        )
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        handleResponse.handleSuccessResponse(result)
                    }
                },
                { x ->
                    run {
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    // Get List of tokens which my device logged in
    fun getTokenList(handleResponse: HandleResponse<ActiveDeviceTokenResponse>){
        compositeDisposable.addAll(APIManager.getActiveDeviceTokenList()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessResponse(result)
                    }
                }
            ) { x ->
                run {
                    setIsLoading(false)
                    handleResponse.handleErrorResponse(getThrowableError(x))
                }
            })
    }

    // Get token of socket server
    fun getSocketToken(handleResponse: HandleResponse<SocketTokenResponse>) {
        compositeDisposable.addAll(APIManager.getSocketToken()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessResponse(result)
                    }
                }
            ) { x ->
                run {
                    setIsLoading(false)
                    handleResponse.handleErrorResponse(getThrowableError(x))
                }
            })
    }

}