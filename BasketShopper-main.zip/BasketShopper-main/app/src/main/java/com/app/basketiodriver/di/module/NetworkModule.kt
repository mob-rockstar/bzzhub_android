package com.app.basketiodriver.di.module

import android.content.Context
import com.app.basketiodriver.BuildConfig
import com.app.basketiodriver.data.local.prefs.PreferencesHelper
import com.app.basketiodriver.data.remote.*
import com.app.basketiodriver.di.scoup.ApiInfo
import com.app.basketiodriver.utils.AppLogger
import com.google.gson.GsonBuilder
import com.jakewharton.retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import dagger.Module
import dagger.Provides
import okhttp3.Cache
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.File
import java.net.URLEncoder
import java.security.SecureRandom
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.inject.Singleton
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager


/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/

@Module
class NetworkModule {

    @Provides
    @Singleton
    fun provideApiHelper(appApiHelper: AppApiHelper): ApiHelper {
        return appApiHelper
    }
    @Provides
    @Singleton
    fun provideLoggingInterceptor(preferencesHelper: PreferencesHelper): LoggingInterceptor {

        return LoggingInterceptor(
        )
    }


    @Provides
    fun provideCache(context: Context): Cache {
        val cacheFile = File(context.cacheDir, "basket_http_cache")
        cacheFile.mkdir()
        return Cache(cacheFile, 10 * 1000 * 1000)
    }

    @Provides
    fun provideOkHttpClient(cache: Cache, loggingInterceptor: LoggingInterceptor): OkHttpClient {

        val interceptor = HttpLoggingInterceptor()
        interceptor.level = HttpLoggingInterceptor.Level.BODY

        return OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .readTimeout(50, TimeUnit.SECONDS)
            .addNetworkInterceptor(loggingInterceptor)
            .addInterceptor(interceptor)
            .cache(cache)
            .build()
    }


    @Singleton
    @Provides
    fun provideApiService(okHttpClient: OkHttpClient): ApiInterface {

        val retrofit = Retrofit.Builder()

            .baseUrl(BuildConfig.BASE_URL)
            .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
            .addConverterFactory(
                GsonConverterFactory.create(
                    GsonBuilder()
                        .setLenient()
                        .create()
                )
            )

            .client(okHttpClient).build()
        return retrofit.create(ApiInterface::class.java)
    }

    @Provides
    @Singleton
    fun provideProtectedApiHeader(
        @ApiInfo apiKey: String,
        preferencesHelper: PreferencesHelper
    ): ApiHeader.ProtectedApiHeader {
        return ApiHeader.ProtectedApiHeader(
            apiKey,
            preferencesHelper.currentUser?.id,
            preferencesHelper.accessToken
        )
    }


}