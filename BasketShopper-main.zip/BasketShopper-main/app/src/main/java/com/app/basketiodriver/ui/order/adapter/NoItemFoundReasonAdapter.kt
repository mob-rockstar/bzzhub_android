package com.app.basketiodriver.ui.order.adapter

import android.annotation.SuppressLint
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.dashboard.Order
import com.app.basketiodriver.data.model.api.response.order.ItemNotFoundReason
import com.app.basketiodriver.databinding.ItemReasonNotFoundBinding
import com.app.basketiodriver.ui.order.`interface`.NoItemFoundClickListener
import com.app.basketiodriver.utils.BaseRecyclerViewAdapter
import java.util.*

class NoItemFoundReasonAdapter(val activity : FragmentActivity, val listItems : List<ItemNotFoundReason>, private val onClickReason: (item : ItemNotFoundReason)->Unit) : BaseRecyclerViewAdapter<ItemNotFoundReason, ItemReasonNotFoundBinding> (){
    var selectedItemIndex : Int = -1

    override val layoutId: Int
        get() = R.layout.item_reason_not_found

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return ReasonViewHolder(createBindView(parent))
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val holder = holder as ReasonViewHolder
        val item = listItems[position]

        if (position == selectedItemIndex){
            holder.binding.ivCheck.visibility = View.VISIBLE
            holder.binding.txtReason.setTextColor(activity.resources.getColor(R.color.colorPrimary))
        }
        else{
            holder.binding.ivCheck.visibility = View.INVISIBLE
            holder.binding.txtReason.setTextColor(activity.resources.getColor(R.color.colorBlack))
        }

        holder.binding.txtReason.text = item.reason
        holder.binding.txtDesc.text = item.description

        holder.binding.lvItemReason.setOnClickListener {
            selectedItemIndex = position
            notifyDataSetChanged()

            onClickReason(item)
        }

        holder.binding.underline.visibility = if (position == listItems.size - 1) View.GONE else View.VISIBLE
    }

    override fun getItemCount(): Int {
        return listItems.size
    }

    inner class ReasonViewHolder(val binding: ItemReasonNotFoundBinding) :
        RecyclerView.ViewHolder(binding.root)

}