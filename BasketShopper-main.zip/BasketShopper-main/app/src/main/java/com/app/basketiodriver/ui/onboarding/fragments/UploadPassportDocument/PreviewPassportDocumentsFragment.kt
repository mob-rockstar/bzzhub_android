package com.app.basketiodriver.ui.onboarding.fragments.UploadPassportDocument


import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentPreviewDocumentsBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.cardcamera.camera.IDCardCamera
import com.app.basketiodriver.ui.onboarding.OnBoardingViewModel
import com.app.basketiodriver.utils.AppConstants

/**
 * A simple [Fragment] subclass.
 */

class PreviewPassportDocumentsFragment :
    BaseFragment<FragmentPreviewDocumentsBinding?, OnBoardingViewModel>(), View.OnClickListener,
    Injectable {

    override val layoutId: Int
        get() = R.layout.fragment_preview_documents

    override val viewModel: OnBoardingViewModel
        get() {
            return getViewModel(requireActivity(), OnBoardingViewModel::class.java)
        }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.preview_passport))

        viewDataBinding!!.btnUpload.setOnClickListener(this)
        viewDataBinding!!.btnRetakePhoto.setOnClickListener(this)



    }

    override fun onClick(p0: View?) {
        when (p0!!.id) {
            R.id.btnRetakePhoto -> {
                IDCardCamera.create(this).openCamera(IDCardCamera.TYPE_IDCARD_BACK)
            }

            R.id.btnUpload -> {
                navigate(
                    PreviewPassportDocumentsFragmentDirections.actionPreviewPassportDocumentsFragmentToFrontShopperIdDocmentFragment()
                )
            }

        }
    }


    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        if (resultCode == IDCardCamera.RESULT_CODE) {
            val path = IDCardCamera.getImagePath(data)

            viewDataBinding!!.placeHolder.setImageBitmap(
                BitmapFactory.decodeFile(
                    path
                )
            )

        }
    }

}

