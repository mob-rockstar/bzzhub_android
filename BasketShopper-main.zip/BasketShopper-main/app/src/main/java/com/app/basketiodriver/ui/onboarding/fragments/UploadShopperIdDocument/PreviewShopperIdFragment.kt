package com.app.basketiodriver.ui.onboarding.fragments.UploadShopperIdDocument


import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.text.TextUtils
import android.view.View

import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentLicensePreviewBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.cardcamera.camera.IDCardCamera
import com.app.basketiodriver.ui.onboarding.OnBoardingViewModel
import com.app.basketiodriver.utils.AppConstants

/**
 * Created by ibraheem lubbad on 2020-01-22.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class PreviewShopperIdFragment :
    BaseFragment<FragmentLicensePreviewBinding?, OnBoardingViewModel>(),
    Injectable, View.OnClickListener {

    override val layoutId: Int
        get() = R.layout.fragment_license_preview

    override val viewModel: OnBoardingViewModel
        get() {
            return getViewModel(requireActivity(), OnBoardingViewModel::class.java)
        }

    var selecteImageType = 0


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.document_id))

        viewDataBinding!!.btnUpload.setOnClickListener(this)
        viewDataBinding!!.btnRetakeBackPhoto.setOnClickListener(this)
        viewDataBinding!!.layoutBack.visibility = View.VISIBLE
        viewDataBinding!!.layoutFront.visibility = View.VISIBLE

        viewDataBinding!!.btnRetakeFrontPhoto.setOnClickListener(this)

     /*   viewModel.documentTypes.filter {
            it.type == AppConstants.DOC_NATIONAL_ID
        }.forEach {
            if (it.side.equals(AppConstants.SIDE_BACK)) {
                viewDataBinding!!.ivRetakeBackPhoto.setImageBitmap(
                    BitmapFactory.decodeFile(
                        it.path
                    )
                )
            } else {
                viewDataBinding!!.ivRetakeFrontPhoto.setImageBitmap(
                    BitmapFactory.decodeFile(
                        it.path
                    )
                )
            }
        }

*/
    }

    override fun onClick(p0: View?) {
        when (p0!!.id) {
            R.id.btnRetakeBackPhoto -> {
                selecteImageType = 0
                IDCardCamera.create(this).openCamera(IDCardCamera.TYPE_IDCARD_BACK)
            }
            R.id.btnRetakeFrontPhoto -> {
                selecteImageType = 1
                IDCardCamera.create(this).openCamera(IDCardCamera.TYPE_IDCARD_BACK)
            }
            R.id.btnUpload -> {
             /*   navigate(
                    PreviewShopperIdFragmentDirections.actionShopperIdPreviewFragmentToTakeSelfiFragment()
                )*/


            }


        }


    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (resultCode == IDCardCamera.RESULT_CODE) {
            val path = IDCardCamera.getImagePath(data)

            if (selecteImageType == 0) {
                if (!TextUtils.isEmpty(path)) {
                    if (requestCode == IDCardCamera.TYPE_IDCARD_FRONT) {
                        viewDataBinding!!.ivRetakeBackPhoto.setImageBitmap(
                            BitmapFactory.decodeFile(
                                path
                            )
                        )
                    } else if (requestCode == IDCardCamera.TYPE_IDCARD_BACK) {
                        viewDataBinding!!.ivRetakeBackPhoto.setImageBitmap(
                            BitmapFactory.decodeFile(
                                path
                            )
                        )
                    }
                }
            } else {
                if (!TextUtils.isEmpty(path)) {
                    if (requestCode == IDCardCamera.TYPE_IDCARD_FRONT) {
                        viewDataBinding!!.ivRetakeFrontPhoto.setImageBitmap(
                            BitmapFactory.decodeFile(
                                path
                            )
                        )
                    } else if (requestCode == IDCardCamera.TYPE_IDCARD_BACK) {
                        viewDataBinding!!.ivRetakeFrontPhoto.setImageBitmap(
                            BitmapFactory.decodeFile(
                                path
                            )
                        )
                    }
                }
            }

        }
    }

}
