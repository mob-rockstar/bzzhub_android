package com.app.basketiodriver.ui.checkout.handover

import android.app.Application
import com.app.basketiodriver.data.DataManager
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.order.HandoverCodeResponse
import com.app.basketiodriver.data.remote.APIManager
import com.app.basketiodriver.ui.base.BaseNavigator
import com.app.basketiodriver.ui.base.BaseViewModel
import com.app.basketiodriver.ui.base.HandleResponse
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class HandOverViewModel constructor(application: Application, dataManager: DataManager): BaseViewModel<BaseNavigator?>(application, dataManager) {
    /**
     * Method to get Handover code
     */
    fun updateHandoverCode(orderId : Long, outletId : Long, handleResponse: HandleResponse<HandoverCodeResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.updateHandoverCode(PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, orderId, outletId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }
}