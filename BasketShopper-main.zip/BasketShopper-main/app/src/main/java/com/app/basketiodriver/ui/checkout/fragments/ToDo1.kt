package com.app.basketiodriver.ui.checkout.fragments

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Parcelable
import android.text.Html
import android.util.Log
import android.view.*
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.checkout.CustomerInfo
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.model.api.response.checkout.OutletOrder
import com.app.basketiodriver.data.model.api.response.general.SimpleResponse
import com.app.basketiodriver.data.model.api.response.order.ItemResponse
import com.app.basketiodriver.data.model.api.response.order.ReplacementOrdersItemRequest
import com.app.basketiodriver.databinding.DialogItemScannedBinding
import com.app.basketiodriver.databinding.FragmentToDoBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.di.Navigators
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.checkout.adapter.DepartmentAdapter
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsActivity
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.app.basketiodriver.ui.dashbaord.OrdersManager
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_SHOPPING
import com.app.basketiodriver.ui.dialogs.AmountDialogFragment
import com.app.basketiodriver.ui.order.product.AddBySearchActivity
import com.app.basketiodriver.utils.AppConstants
import com.app.basketiodriver.utils.AppUtils
import com.app.basketiodriver.utils.GlideApp
import com.app.basketiodriver.utils.MessageEvent
import com.app.basketiodriver.utils.PopupUtils
import com.app.basketiodriver.utils.price.PriceConstructor
import com.squareup.picasso.Picasso
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.*


class ToDo1 : BaseFragment<FragmentToDoBinding, OrderDetailsViewModel>(), Injectable, AmountDialogFragment.AmountDialogOnClickListener {
    var symbols: DecimalFormatSymbols = DecimalFormatSymbols(Locale.ENGLISH)
    var formatter: DecimalFormat = DecimalFormat(" #.## ", symbols)
    var formatterSingle: DecimalFormat = DecimalFormat(" # ", symbols)

    var orderId : Long = 0L
    var info : CustomerInfo? = null

    var isDetailOpen : Boolean = false

    // new order item
    var newItem : OrdersItem? = null

    lateinit var linearLayoutManager: LinearLayoutManager

    // order
    lateinit var order : OutletOrder

    // Adapter
    lateinit var adapter : DepartmentAdapter

    val BARCODE_ACTIVITY2 = 542

    var amountDialog : AmountDialogFragment? = null

    // Parent Activity
    var parentActivity : Activity? = null

    override val layoutId: Int
        get() = R.layout.fragment_to_do

    override val viewModel: OrderDetailsViewModel
        get() {
            return if (parentActivity != null){
                getViewModel(parentActivity as FragmentActivity, OrderDetailsViewModel::class.java)
            } else{
                getViewModel(baseActivity as FragmentActivity, OrderDetailsViewModel::class.java)
            }
        }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        linearLayoutManager = LinearLayoutManager(context)

        viewDataBinding!!.recyclerTodo.layoutManager = linearLayoutManager
        viewDataBinding!!.recyclerTodo.setHasFixedSize(true)

        viewDataBinding!!.refreshLayout.setOnRefreshListener {
            Toast.makeText(baseActivity, getString(R.string.refreshing_orders), Toast.LENGTH_SHORT).show()
            (baseActivity as OrderDetailsActivity).queryShopperOrders()
        }

        // Get order from bundle
        if (arguments != null)
            order = requireArguments().getSerializable(OrderDetailsActivity.KEY_LIST_ORDER) as OutletOrder

        // Add new item
        viewDataBinding!!.tvAddNewItem.setOnClickListener {
            viewDataBinding!!.tvAddNewItem.isClickable = false
            if (activity != null){
                orderId = (activity as OrderDetailsActivity).orderId
                order.id = orderId
            }

            var itemId = 1L
            if (order.todoItemsCount > 0){
                itemId = order.todoOrdersItems[0].ordersOutletsItemsId ?: 0
            }
            else if (order.pendingOrdersItems.size > 0){
                itemId = order.pendingOrdersItems[0].ordersOutletsItemsId ?: 0
            }
            else if (order.doneItemsCount > 0){
                itemId = order.doneOrdersItems[0].ordersOutletsItemsId ?: 0
            }

            goToSearchToAdd(orderId, itemId)
        }

        // Chat Action
        viewDataBinding!!.chatFloatingButton.setOnClickListener {
            (baseActivity as OrderDetailsActivity).openChatActivity()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        EventBus.getDefault().register(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        if (event.message == AppConstants.MESSAGE_ITEM_REFUNDED) {
            // Get shopper orders
            viewDataBinding?.refreshLayout?.isRefreshing = false
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)

        if (context is OrderDetailsActivity)
            parentActivity = context
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onResume() {
        super.onResume()

        isDetailOpen = false
        if (arguments != null)
            order = requireArguments().getSerializable(OrderDetailsActivity.KEY_LIST_ORDER) as OutletOrder

        try{
            if (isAdded){
                /**
                Sort by department
                 */
                val clickable = requireArguments().getBoolean(OrderDetailsActivity.KEY_CLICKABLE, false)
                val departments = AppUtils.sortItems(order.todoOrdersItems, order.isSortingEnable)

                info = CustomerInfo(order.userImage ?: "", String.format(Locale("en"), "%s %s", order.userFirstName, order.userLastName),
                    order.userLocation ?: "", order.deliverySlot ?: "", order.userGoogleAddress ?: "", order.userAddressType ?: "",
                    order.userDepartmentBuilding ?: "", order.userAdditionalInfo ?: "", order.userNearLandmark ?: "")

                try{
                    // Init the department adapter
                    if (viewDataBinding != null){
                        val isExpress = order.isExpress
                        adapter = DepartmentAdapter(baseActivity as FragmentActivity, departments, order.userMobile ?: "", order.outletId ?: 0, info!!, false, clickable, isExpress)
                        viewDataBinding!!.recyclerTodo.adapter = adapter
                        viewDataBinding!!.recyclerTodo.adapter?.notifyDataSetChanged()

                        // Restore the recyclerview state
                        viewDataBinding!!.recyclerTodo.layoutManager?.onRestoreInstanceState((baseActivity as OrderDetailsActivity).getTodo1())

                        onSaveInstanceState(requireArguments())

                        // checkout button
                        setStateCheckoutButton()
                    }
                }
                catch (e : Exception) {
                    e.printStackTrace()
                }

                // Hide the "Add item" before shopping stage
                val orderStatus = (baseActivity as OrderDetailsActivity).orderStatus
                if (orderStatus != 0 && orderStatus < STATUS_SHOPPING){
                    viewDataBinding!!.addItemLayout.visibility = View.GONE
                }
                else {
                    viewDataBinding!!.addItemLayout.visibility = View.VISIBLE
                }

            }
        }
        catch ( e : Exception){
            e.printStackTrace()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)

        val positions = OrderDetailsActivity.position
        if (positions != null && positions.isNotEmpty()){
            viewDataBinding?.nestedScrollView?.post {
                viewDataBinding?.nestedScrollView?.scrollTo(
                    positions[0],
                    positions[1]
                )
            }
        }
    }

    fun getSaved(): Parcelable? {
        return if (viewDataBinding?.recyclerTodo != null) viewDataBinding?.recyclerTodo!!.layoutManager?.onSaveInstanceState() else null
    }

    fun getScroll(): IntArray {
        return if (viewDataBinding?.nestedScrollView != null) intArrayOf(
            viewDataBinding?.nestedScrollView!!.scrollX,
            viewDataBinding?.nestedScrollView!!.scrollY
        ) else intArrayOf()
    }

    private fun setStateCheckoutButton(){
        if (order.todoItemsCount != 0){
            viewDataBinding!!.tvPicking.visibility = View.GONE
        }
        else{
            viewDataBinding!!.tvPicking.visibility = View.VISIBLE
        }
    }

    private fun openIfExist(barcode: String, mContext: Activity?){
        val findOrderItem = filterOrderItemByBarcode(barcode)
        if (findOrderItem != null){
            info = CustomerInfo(order.userImage ?: "", String.format(Locale("en"), "%s %s", order.userFirstName, order.userLastName),
                order.userLocation ?: "", order.deliverySlot ?: "", order.userGoogleAddress ?: "", order.userAddressType ?: "",
                order.userDepartmentBuilding ?: "", order.userAdditionalInfo ?: "", order.userNearLandmark ?: "")

            // Go to ItemDetails
            if (mContext != null)
                Navigators.goToCustomItemDetailsActivity(mContext, findOrderItem, order.userMobile ?: "", info!!, order.orderId ?: 0, order.isExpress)

        }
    }

    // Filter order items by barcode
    private fun filterOrderItemByBarcode(barcode : String) : OrdersItem?{
        val items : ArrayList<OrdersItem> = arrayListOf()
        items.addAll(order.todoOrdersItems)
        items.addAll(order.pendingOrdersItems)
        items.addAll(order.doneOrdersItems)
        for (order in items){
            if (order.barCode == barcode){
                return order
            }
        }

        return null
    }

    // Go to search product page
    private fun goToSearchToAdd(orderId : Long, itemId : Long){
        val intent = Intent(context, AddBySearchActivity::class.java)
        intent.putExtra("ARG_ORDER_ID", orderId)
        intent.putExtra("ARG_ITEM_ID", itemId)

        startActivityForResult(intent, BARCODE_ACTIVITY2)
    }

    // Check barcode
    private fun checkBarcode(barcode : String){
        try{
            viewModel.getCheckItemByBarcode(order.outletId!!, barcode, object :
                HandleResponse<SimpleResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (isNetworkConnected){
                        Toast.makeText(baseActivity, error?.message, Toast.LENGTH_SHORT).show()
                    }else{
                        Toast.makeText(baseActivity, baseActivity!!.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                    }
                }

                override fun handleSuccessResponse(successResponse: SimpleResponse) {
                    val response = successResponse.response
                    if (response != null){
                        val responseCode = response.httpCode
                        Log.d("TAG", "handleSuccessResponse: "+responseCode)
                        when (responseCode!!) {
                            200 -> {
                                // Go to CreateCustomItemActivity
                                Navigators.goToAddCustomItemActivity(baseActivity as Activity, barcode, (order.outletId ?: 0).toLong())
                            }
                            201 -> {
                                showProduct(barcode, baseActivity as Activity)
                            }
                            202 -> {
                                openIfExist(barcode, baseActivity as Activity)
                            }
                            else -> {
                                Toast.makeText(baseActivity, response.message, Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                    else{
                        Toast.makeText(baseActivity, R.string.error_server_return_null, Toast.LENGTH_SHORT).show()
                    }
                }
            })
        }
        catch (e : Exception){
            e.printStackTrace()
        }

    }

    private fun showProduct(barcode : String, mContext : Activity){
        try {
            viewModel.getProductByBarcode(orderId, barcode, object : HandleResponse<ItemResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (isNetworkConnected){
                        Toast.makeText(baseActivity, error?.message, Toast.LENGTH_SHORT).show()
                    }else{
                        Toast.makeText(baseActivity, baseActivity!!.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                    }
                }

                override fun handleSuccessResponse(successResponse: ItemResponse) {
                    if (successResponse.response != null){
                        if (successResponse.response.httpCode == 200){
                            if (successResponse.response.itemDetails != null){
                                Log.d("TAG", "handleSuccessResponse: "+successResponse.response.itemDetails)

                                // Show the ProductDialog
                                showProductDialog(successResponse.response.itemDetails, mContext)
                            }
                            else{
                                // Show the null error message
                                Toast.makeText(baseActivity, R.string.error_server_return_null, Toast.LENGTH_SHORT).show()
                            }
                        }
                        else{
                            Toast.makeText(baseActivity, successResponse.response.message, Toast.LENGTH_SHORT).show()
                        }
                    }
                    else{
                        Toast.makeText(baseActivity, R.string.error_server_return_null, Toast.LENGTH_SHORT).show()
                    }
                }
            })
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    // Show the product information dialog
    private fun showProductDialog(item : OrdersItem, mContext: Activity){
        newItem = item

        val dialog = Dialog(mContext)
        val binding: DialogItemScannedBinding = DataBindingUtil.inflate(LayoutInflater.from(mContext), R.layout.dialog_item_scanned,null,false)

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(binding.root)
        dialog.setCancelable(false)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setGravity(Gravity.CENTER)
        dialog.setOnKeyListener { it, keyCode, event -> // Prevent dialog close on back press button
            keyCode == KeyEvent.KEYCODE_BACK
        }

        // Cancel
        binding.tvCancel.setOnClickListener {
            dialog.dismiss()
        }

        // Confirm
        binding.tvConfirm.setOnClickListener {
            dialog.dismiss()
            showAmountDialog(item, mContext)
        }

        // Show the Item information
        // Product image
        if (item.productImage != null){
                Picasso.get().load(item.productImage).fit().error(R.drawable.placeholder).into(binding.productLayout.orderItemImage)
          //  GlideApp.with(requireActivity()).load(item.productImage).error(R.drawable.placeholder).into(binding.productLayout.orderItemImage)
        }

        // Hide the "scan one more item"
        binding.tvScanMore.visibility = View.GONE

        // Title
        binding.productLayout.orderItemTitle.text = item.productName ?: "N/A"// + " " + item.aisleName

        // Cost
        binding.productLayout.orderCost.text = Html.fromHtml(PriceConstructor.getFormatPrice(item, PriceConstructor.LabelType.SIMPLE, PreferenceManager.currency,true))

        // Description
        if (item.getDescriptionLabel().isEmpty()) {
            binding.productLayout.tvPriceDescription.visibility = View.GONE
        } else {
            binding.productLayout.tvPriceDescription.visibility = View.VISIBLE
            binding.productLayout.tvPriceDescription.text = item.getDescriptionLabel()
        }

        PopupUtils.setDefaultDialogProperty(dialog)
        dialog.show()
//        try {
//
//        }
//        catch (e : Exception) {
//            e.printStackTrace()
//        }
    }

    @SuppressLint("SetTextI18n")
    private fun setDataToView(root : View, item : OrdersItem){
        try {
            val itemImageView: ImageView = root.findViewById(R.id.order_item_image)
            val itemTitleView: TextView = root.findViewById(R.id.order_item_title)
            val itemCostView: TextView = root.findViewById(R.id.order_cost)
            val priceDescription: TextView = root.findViewById(R.id.tvPriceDescription)

            if (item.productImage != null){
//                Picasso.get().load(item.productImage).fit().error(R.drawable.placeholder)
//                    .into(itemImageView)
                GlideApp.with(this).load(item.productImage).error(R.drawable.placeholder).into(itemImageView)
            }

            if (item != null) {
                itemTitleView.text = item.productName!! + " " + item.aisleName
                itemCostView.text = Html.fromHtml(
                    PriceConstructor.getFormatPrice(
                        item,
                        PriceConstructor.LabelType.SIMPLE,
                        PreferenceManager.currency,
                        true
                    )
                )
                if (item.getDescriptionLabel().isEmpty()) {
                    priceDescription.visibility = View.GONE
                } else {
                    priceDescription.visibility = View.VISIBLE
                    priceDescription.text = item.getDescriptionLabel()
                }
            }
            val threeDot: View = root.findViewById(R.id.three_dot)
            val params = threeDot.layoutParams
            params.width = 1
            threeDot.layoutParams = params
            threeDot.visibility = View.INVISIBLE
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showAmountDialog(item : OrdersItem, mContext: Activity){
        try {
            parentActivity = mContext

            amountDialog = AmountDialogFragment.newInstance(item, item.itemQty ?: 1.0)
            amountDialog!!.show((mContext as OrderDetailsActivity).supportFragmentManager, AmountDialogFragment.javaClass.name)
            amountDialog!!.setAmountNextClickListener(this)
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == BARCODE_ACTIVITY2 && resultCode == Activity.RESULT_OK) {
            // check barcode
            checkBarcode(data?.getStringExtra("ARG_BARCODE")!!)
            Log.d("TAG", "onActivityResult:TODO1 "+BARCODE_ACTIVITY2+ " "+ Activity.RESULT_OK +" "+data?.getStringExtra("ARG_BARCODE")!!)

        }

        super.onActivityResult(requestCode, resultCode, data)
    }

    /**
     * AmountDialog ClickListener
     */
    override fun onNextClick(requestItems : ArrayList<ReplacementOrdersItemRequest>){

    }

    override fun onNextClick(amount: Double) {
        if (amountDialog != null)
            amountDialog!!.dismiss()

        try {
            viewModel.addItemByBarcode(order.outletId!!, newItem!!.barCode, amount, 1, object :
                HandleResponse<SimpleResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (isNetworkConnected){
                        Toast.makeText(baseActivity, error?.message, Toast.LENGTH_SHORT).show()
                    }else{
                        Toast.makeText(baseActivity, baseActivity!!.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                    }
                }

                override fun handleSuccessResponse(successResponse: SimpleResponse) {
                    if (successResponse.response != null){
                        Toast.makeText(baseActivity, successResponse.response.message, Toast.LENGTH_SHORT).show()
                        if (successResponse.response.httpCode == 200){
                            // Go to order details
                            Navigators.goToOrderDetails(baseActivity as Activity, order.outletId!!)
                        }
                    }
                    else{
                        Toast.makeText(baseActivity, R.string.error_server_return_null, Toast.LENGTH_SHORT).show()
                    }
                }
            })
        }
        catch ( e : Exception){
            e.printStackTrace()
        }
    }

    override fun onNextClick(itemId: Long, amount: Double) {

    }

    override fun onNextClick(amount: Double, weight: Double) {

    }

    override fun onNextClick(itemId: Long, amount: Double, weight: Double) {

    }
}