package com.app.basketiodriver.ui.login.fragments

import android.os.Bundle
import android.transition.TransitionManager
import android.view.View
import android.view.ViewTreeObserver
import android.widget.Toast
import bloder.com.blitzcore.enableWhen
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.general.SimpleResponse
import com.app.basketiodriver.databinding.FragForgetPasswordBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.login.LoginViewModel
import com.app.basketiodriver.utils.AppLogger
import com.mukesh.countrypicker.Country
import com.mukesh.countrypicker.CountryPicker
import com.mukesh.countrypicker.OnCountryPickerListener


/**
Created by ibraheem lubbad on 2020-01-15.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class ForgetPasswordFragment : BaseFragment<FragForgetPasswordBinding?, LoginViewModel>(),
    OnCountryPickerListener,
    Injectable {

    override val layoutId: Int
        get() = R.layout.frag_forget_password

    override val viewModel: LoginViewModel
        get() {
            return getViewModel(requireActivity(), LoginViewModel::class.java)
        }
    /**
     *  country picker dialog
     */
    var mCountryPicker: CountryPicker? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.rest_password))

        /**
         * set default value
         */

        viewDataBinding!!.edMobileNumber.setText(viewModel.mobileNumber)
        viewDataBinding!!.tvCountryCode.text = viewModel.codeMobileNumber

        setListener()

        validation()

        /**
         * Mobile TextInputLayout
         */
        viewDataBinding!!.inputMobileNumber.viewTreeObserver.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                // Wait for the first draw to be sure the view is completely measured
                if (viewDataBinding!!.inputMobileNumber.height > 0) {
                    viewDataBinding!!.inputMobileNumber.viewTreeObserver.removeOnPreDrawListener(this)
                    updateHintPosition(viewDataBinding!!.edMobileNumber.hasFocus(), !viewDataBinding!!.edMobileNumber.text.isNullOrEmpty(), false)
                    return false
                }
                return true
            }
        })

        viewDataBinding!!.edMobileNumber.setOnFocusChangeListener { _, hasFocus ->
            updateHintPosition(hasFocus, !viewDataBinding!!.edMobileNumber.text.isNullOrEmpty(), true)
        }
    }

    private fun getPixelSizeInDp(dpSize : Int) : Int{
        val density = baseActivity?.resources?.displayMetrics!!.density
        return (dpSize * density + 0.5f).toInt()
    }

    private fun updateHintPosition(hasFocus: Boolean, hasText: Boolean, animate: Boolean) {
        if (animate) {
            TransitionManager.beginDelayedTransition(viewDataBinding!!.inputMobileNumber)
        }

        val padding = getPixelSizeInDp(6)
        if (hasFocus || hasText) {
            viewDataBinding!!.edMobileNumber.setPadding(padding, padding, padding, 0)
        } else {
            viewDataBinding!!.edMobileNumber.setPadding(padding, 0, padding, getTextInputLayoutTopSpace())
        }
    }

    private fun getTextInputLayoutTopSpace(): Int {
        var currentView: View = viewDataBinding!!.edMobileNumber
        var space = 0
        do {
            space += currentView.top
            currentView = currentView.parent as View
        } while (currentView.id != viewDataBinding!!.inputMobileNumber.id)
        return space
    }

    private fun validation() {

        viewDataBinding!!.btnRestPin.enableWhen {
            viewDataBinding!!.edMobileNumber.isPhoneNumber() onValidationSuccess {
//                viewDataBinding!!.edMobileNumber.onSuccess()
            } onValidationError {
//                viewDataBinding!!.edMobileNumber.onError()
            }
        }
    }

    /**
     * Used for set listener
     */
    private fun setListener() {

        val builder = CountryPicker.Builder().with(baseActivity!!)
            .listener(this)

        mCountryPicker = builder.build()

        viewDataBinding!!.countryCodeLayout.setOnClickListener {
            run {
                mCountryPicker!!.showDialog(baseActivity!!)
            }
        }

        viewDataBinding!!.btnRestPin.setOnClickListener {
            run {
                val code = viewDataBinding!!.tvCountryCode.text.toString()
                val mobile = viewDataBinding!!.edMobileNumber.text.toString()

                val userMobile = code + mobile

                viewModel.shopperForgetPassword(userMobile, object:HandleResponse<SimpleResponse> {
                    override fun handleErrorResponse(error: ErrorResponse?) {
                        AppLogger.d("<===== Failed to reset password")
                        AppLogger.d(error?.message)

                        val errorMsg = error?.message ?: "Failed to reset password, please try again later"
                        if (isNetworkConnected){
                            Toast.makeText(baseActivity, errorMsg, Toast.LENGTH_LONG).show()
                        }
                        else{
                            Toast.makeText(baseActivity, baseActivity?.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                        }
                    }

                    override fun handleSuccessResponse(successResponse: SimpleResponse) {
                        AppLogger.d("<===== Sent PIN to your mobile number")
                        val updateResponse = successResponse.response
                        if (updateResponse != null) {
                            if (updateResponse.httpCode == 200) {
                                viewModel.codeMobileNumber = code
                                viewModel.mobileNumber = mobile

                                // Go to Enter SMS page
                                navigate(ForgetPasswordFragmentDirections.actionForgetPasswordFragmentToOtpVerificationFragment().setIsForgetPassword(true))
                            }
                            else{
                                Toast.makeText(baseActivity, updateResponse.message, Toast.LENGTH_LONG).show()
                            }
                        }
                        else{
                            Toast.makeText(baseActivity, R.string.something_went_wrong, Toast.LENGTH_LONG).show()
                        }
                    }
                })

            }
        }
    }

    override fun onSelectCountry(country: Country?) {
        viewDataBinding!!.tvCountryCode.text = country?.dialCode
    }
}
