package com.app.basketiodriver.ui.onboarding.fragments


import android.app.DatePickerDialog
import android.os.Bundle
import android.view.View
import android.widget.Toast
import bloder.com.blitzcore.enableWhen
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentVehicleInfoBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.onboarding.OnBoardingViewModel
import com.app.basketiodriver.utils.AppLogger
import java.text.SimpleDateFormat
import java.util.*

/**
 * Created by ibraheem lubbad on 2020-01-22.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class VehicleInfoFragment :
    BaseFragment<FragmentVehicleInfoBinding?, OnBoardingViewModel>(), View.OnClickListener,
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_vehicle_info

    override val viewModel: OnBoardingViewModel
        get() {
            return getViewModel(requireActivity(), OnBoardingViewModel::class.java)
        }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.vehicle_data))
        validation()

        /* var newDate = Calendar.getInstance()


         var year = 0
         var monthOfYear = 0
         var dayOfMonth = 0
         newDate.set(year, monthOfYear, dayOfMonth)*/


        val myFormat = "MM/yyyy" // mention the format you need
        val dateFormatter = SimpleDateFormat(myFormat, Locale.US)

        val cal = Calendar.getInstance()
        viewDataBinding!!.edExpireYear.setText(dateFormatter.format(cal.time))

        val dateSetListener =
            DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->
                cal.set(Calendar.YEAR, year)
                cal.set(Calendar.MONTH, monthOfYear)
                cal.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                viewDataBinding!!.edExpireYear.setText(dateFormatter.format(cal.time))

            }
        viewDataBinding!!.edExpireYear.setOnClickListener {
            DatePickerDialog(
                requireContext(), dateSetListener,
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)
            ).show()
        }
    }

    private fun validation() {
        viewDataBinding!!.btnNext.setOnClickListener(this)

        viewDataBinding!!.btnNext.enableWhen {
            viewDataBinding!!.edVehicleBrandAndModel.isFilled() onValidationSuccess {
                viewDataBinding!!.edVehicleBrandAndModel.onSuccess()
            } onValidationError {
                viewDataBinding!!.edVehicleBrandAndModel.onError()
            }
            viewDataBinding!!.edYearOfCarManufacture.isFilled() onValidationSuccess {
                viewDataBinding!!.edYearOfCarManufacture.onSuccess()
            } onValidationError {
                viewDataBinding!!.edYearOfCarManufacture.onError()
            }
            viewDataBinding!!.edExpireYear.isFilled() onValidationSuccess {
                viewDataBinding!!.edExpireYear.onSuccess()
            } onValidationError {
                viewDataBinding!!.edExpireYear.onError()
            }
        }

    }

    override fun onClick(p0: View?) {
        when (p0!!.id) {

            R.id.btnNext -> {
               popNavigate()
              /*  if (viewModel.IS_PASSPORT_REQUIRED) {
                    navigate(VehicleInfoFragmentDirections.actionVehicleInfoFragmentToFrontPassportDocmentFragment())
                } else {
                    navigate(VehicleInfoFragmentDirections.actionVehicleInfoFragmentToFrontShopperIdDocmentFragment())
                }
*/
            }

        }
    }


}
