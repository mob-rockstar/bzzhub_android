package com.app.basketiodriver.data.model.api.response.earning.monthly

import com.google.gson.annotations.SerializedName


class ShopperMonthlySummaryResponse {
    @SerializedName("data")
    var data: MonthlySummaryItem? = null

    @SerializedName("message")
    var message: String = ""
}