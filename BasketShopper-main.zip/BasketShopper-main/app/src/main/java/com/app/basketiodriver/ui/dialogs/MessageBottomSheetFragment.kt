package com.app.basketiodriver.ui.dialogs

import android.R.attr.data
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.remote.socket.ChatMessageHelper
import com.app.basketiodriver.data.remote.socket.SystemMessage
import com.app.basketiodriver.data.remote.socket.SystemMessageReq
import com.app.basketiodriver.databinding.FragmentMessageBottomSheetDialogBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseDialogFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.app.basketiodriver.ui.dashbaord.OrdersManager
import com.app.basketiodriver.ui.order.adapter.MessageOptionListAdapter
import kotlin.Exception


class MessageBottomSheetFragment: BaseDialogFragment<FragmentMessageBottomSheetDialogBinding?, OrderDetailsViewModel>(),
    Injectable {

    var orderId : Long = 0L
    var item : OrdersItem? = null

    var msg : String = ""

    var optionsList : ArrayList<String> = arrayListOf()

    lateinit var adapter : MessageOptionListAdapter

    override val layoutId: Int
        get() = R.layout.fragment_message_bottom_sheet_dialog

    override val viewModel: OrderDetailsViewModel
        get() {
            return getViewModel(baseActivity, OrderDetailsViewModel::class.java)
        }

    // Set style
    override fun getTheme(): Int {
        return R.style.MyDialogWhite
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // set layout manager
        val layoutManager : LinearLayoutManager = LinearLayoutManager(activity, LinearLayoutManager.HORIZONTAL, false)
        viewDataBinding!!.recyclerView.layoutManager = layoutManager

        optionsList.add(getString(R.string.not_available))
        optionsList.add(getString(R.string.poor_qnt))
        optionsList.add(getString(R.string.conf_qnt))

        /**
         * get params
         */
        arguments?.let {
            orderId = it.getLong(CanNotFindItemDialogFragment.KEY_ORDER_ID)
            item = it.getSerializable(CanNotFindItemDialogFragment.KEY_ORDER_ITEM) as? OrdersItem

            viewDataBinding!!.txtProductName.text = ""
            viewDataBinding!!.txtProductName.setOnClickListener {
                if (msg != ""){
                    /////////////////////////////

                    // Send Message using ChatMessageHelper
                    try {
                        val systemMessageReq = SystemMessageReq(orderId.toString(), "text", msg)
                        sendSystemMessage(systemMessageReq){
                            dismissAllowingStateLoss()
                        }
                    }catch (e: Exception){

                    }
                }
            }

            initRecyclerView()
        }
    }

    private fun sendSystemMessage(systemMessageReq: SystemMessageReq, onAfterSystemMessageClicked: ()->Unit){
        viewModel.sendSystemMessage(systemMessageReq, object : HandleResponse<SystemMessage> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                onAfterSystemMessageClicked()
            }

            override fun handleSuccessResponse(successResponse: SystemMessage) {
                onAfterSystemMessageClicked()
            }
        })
    }

    private fun initRecyclerView(){
        try{
            adapter = MessageOptionListAdapter(requireActivity(), optionsList, { item, status -> onMessageOptionClicked(item, status)})
            viewDataBinding!!.recyclerView.adapter = adapter
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    private fun onMessageOptionClicked(data : String, status : Int){
        var qty = 0.0
        // Quantity
        if (item?.quantityDifference == 1){
            qty = item?.actualQty ?: 0.0
        }
        else if (item?.replacementRequested != null && item?.replacementRequested == 1){
            qty = item?.actualQty ?: 0.0
        }
        else{
            qty = item?.itemQty ?: 0.0
        }

        when (data) {
            getString(R.string.not_available) -> msg =
                (data + ", " + getString(R.string.the_store_not_have_product) + " "
                        + item?.productName +
                        ". " + getString(R.string.would_you_like_to_replacement))
            getString(R.string.poor_qnt) -> msg =
                (data + ", " + getString(R.string.unfortunately_qnt) + " "
                        + item?.productName +
                        " " + getString(R.string.is_not_great_substitution))
            getString(R.string.conf_qnt) -> msg =
                data + ", " + getString(R.string.looking_for_the) + " " + item?.productName +
                        ". " + getString(R.string.are_you_still_hopping) + " " + qty + " x?"
        }

        if (msg != ""){
            viewDataBinding!!.txtProductName.text = msg
        }
    }

    companion object {
        const val KEY_ORDER_ITEM      = "orders_item"
        const val KEY_ORDER_ID        = "order_id"


        fun newInstance(
            item : OrdersItem,
            orderId : Long
        ): MessageBottomSheetFragment {
            val fragment = MessageBottomSheetFragment()

            val data = Bundle()

            data.putSerializable(KEY_ORDER_ITEM, item)
            data.putLong(KEY_ORDER_ID, orderId)

            fragment.arguments = data

            return fragment
        }
    }

}