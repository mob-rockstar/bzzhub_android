package com.app.basketiodriver.ui.howdoing.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.howamidoing.ReliabilityModel
import com.app.basketiodriver.databinding.ItemRiDetailBinding
import com.app.basketiodriver.databinding.ItemRiTitleBinding
import com.app.basketiodriver.utils.DateUtils
import com.thoughtbot.expandablerecyclerview.ExpandableRecyclerViewAdapter
import com.thoughtbot.expandablerecyclerview.models.ExpandableGroup
import com.thoughtbot.expandablerecyclerview.viewholders.ChildViewHolder
import com.thoughtbot.expandablerecyclerview.viewholders.GroupViewHolder
import java.util.*

class RIAdapter : ExpandableRecyclerViewAdapter<RIAdapter.RITitleViewHolder, RIAdapter.RIViewHolder> {
    var mInflater : LayoutInflater? = null

//    constructor(groups: MutableList<out ExpandableGroup<ReliabilityModel>>?) : super(groups)

    constructor(groups: List<ExpandableGroup<*>?>) : super(groups)

    override fun onCreateGroupViewHolder(parent: ViewGroup, viewType: Int): RITitleViewHolder {
        if (mInflater == null)
            mInflater = LayoutInflater.from(parent.context)

        return RITitleViewHolder(DataBindingUtil.inflate<ItemRiTitleBinding>(
            LayoutInflater.from(parent.context),
            R.layout.item_ri_title,
            parent,
            false
        ))
    }

    override fun onCreateChildViewHolder(parent: ViewGroup, viewType: Int): RIViewHolder {
        if (mInflater == null)
            mInflater = LayoutInflater.from(parent.context)

        return RIViewHolder(DataBindingUtil.inflate<ItemRiDetailBinding>(
            LayoutInflater.from(parent.context),
            R.layout.item_ri_detail,
            parent,
            false
        ))
    }


    override fun onBindChildViewHolder(
        holder: RIViewHolder?,
        flatPosition: Int,
        group: ExpandableGroup<*>?,
        childIndex: Int
    ) {
        val riRecord = (group as ReliabilityModel).items[childIndex]
        if (holder != null){
            // Reason
            holder.binding.txtReason.text = String.format(Locale("en"), "%s %s", riRecord.reliability_incident_reason, DateUtils.getRIDateTime(riRecord.created_on))

            // Detail
            holder.binding.txtDetail.text = riRecord.reliability_incident_description
        }
    }

    override fun onBindGroupViewHolder(
        holder: RITitleViewHolder?,
        flatPosition: Int,
        group: ExpandableGroup<*>?
    ) {
        if (holder != null){
            // Set the title
            holder.binding.txtTitle.text = DateUtils.getRIDate(group?.title)
//            holder.binding.txtTitleExpand.text = DateUtils.getRIDate(group?.title)
        }
    }

    inner class RITitleViewHolder(val binding: ItemRiTitleBinding) :
        GroupViewHolder(binding.root){
    }

    inner class RIViewHolder(val binding: ItemRiDetailBinding) :
        ChildViewHolder(binding.root){
    }
}