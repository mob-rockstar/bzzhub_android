package com.app.basketiodriver.ui.howdoing.fragments

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentHowIamDoingCommentsBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.howdoing.HowIamDoingViewModel


/**
 * A simple [Fragment] subclass.
 */
class HowIamDoingCommentsFragment :
    BaseFragment<FragmentHowIamDoingCommentsBinding?, HowIamDoingViewModel>(),
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_how_iam_doing_comments

    override val viewModel: HowIamDoingViewModel
        get() {
            return getViewModel(requireActivity(), HowIamDoingViewModel::class.java)
        }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle("Comments")

    }


}
