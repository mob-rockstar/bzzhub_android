package com.app.basketiodriver.data.model.api.response.howamidoing

import android.os.Parcelable
import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize


@Parcelize
class HowAmIDoingDetailResponse : Parcelable{

    @SerializedName("data")
    val data: DetailsData? = null

    @SerializedName("message")
    val message: String = ""

    @Parcelize
    class DetailsData : Parcelable{
        @SerializedName("RI_records")
        @Expose
        val riRecords: List<RIRecords>? = null

        @SerializedName("incident")
        @Expose
        val incident = 0

        @SerializedName("incident_text")
        @Expose
        val incident_text: String = ""
    }

}