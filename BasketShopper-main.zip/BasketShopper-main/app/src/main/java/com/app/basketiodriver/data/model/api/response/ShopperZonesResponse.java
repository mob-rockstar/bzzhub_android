package com.app.basketiodriver.data.model.api.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class ShopperZonesResponse {

    @SerializedName("data")
    private ArrayList<DetailsData> data;

    @SerializedName("message")
    private String message;

    public ArrayList<DetailsData> getData() {
        return data;
    }

    public void setData(ArrayList<DetailsData> data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public class DetailsData {

        @Expose
        public int status;

        @SerializedName("zone_name")
        @Expose
        private String zone_name;

        @SerializedName("id")
        @Expose
        private int id;

        public String getZone_name() {
            return zone_name;
        }

        public void setZone_name(String zone_name) {
            this.zone_name = zone_name;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }
    }
}