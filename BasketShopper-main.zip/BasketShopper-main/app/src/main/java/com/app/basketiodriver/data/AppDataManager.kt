package com.app.basketiodriver.data

import android.content.Context
import androidx.lifecycle.MutableLiveData
import com.app.basketiodriver.data.local.db.AppDbHelper
import com.app.basketiodriver.data.model.api.ChatMessage
import com.app.basketiodriver.data.model.api.User
import com.app.basketiodriver.data.model.db.OnbaordingStages
import com.app.basketiodriver.data.remote.ApiHeader
import com.app.basketiodriver.data.remote.AppApiHelper
import com.app.basketiodriver.data.remote.socket.EventListener
import com.app.basketiodriver.data.remote.socket.SocketService
import com.app.basketiodriver.utils.ConnectivityStates
import io.reactivex.Observable
import io.reactivex.Single
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
@Singleton
class AppDataManager @Inject constructor(
    private val mContext: Context,
    private val mSocketService: SocketService,
    private val mDbHelper: AppDbHelper,
    private val mApiHelper: AppApiHelper
) : DataManager, EventListener {

    val connectivityState: MutableLiveData<Int> = MutableLiveData()
    val newMessagesLD: MutableLiveData<ChatMessage> = MutableLiveData()

    override val allUsers: Observable<List<User?>?>?
        get() = mDbHelper.allUsers

    override fun findCurrentUserOnbaordingConfig(userId: Int): Single<OnbaordingStages?>? {
        return mDbHelper.findCurrentUserOnbaordingConfig(userId)
    }

//    override fun saveCurrentUser(user: User) {
//        return mDbHelper.saveCurrentUser(user)
//    }

   override fun deleteCurrentUser(user: User) {
        return mDbHelper.deleteCurrentUser(user)
    }

//    override fun getCurrentUser(userId: Int): Single<User?>? {
//        return mDbHelper.getCurrentUser(userId)
//    }



    override fun updateCurrentUserOnbaordingConfig(onbaordingStages: OnbaordingStages) {
        return mDbHelper.updateCurrentUserOnbaordingConfig(onbaordingStages)
    }

    override val apiHeader: ApiHeader?
        get() = mApiHelper.apiHeader


    override fun setUserAsLoggedOut() {
        updateUserInfo(
            null,
            null

        )
    }

    override fun updateApiHeader(userId: Int?, accessToken: String?) {
        mApiHelper.apiHeader!!.protectedApiHeader.userId = userId
        mApiHelper.apiHeader!!.protectedApiHeader.accessToken = accessToken
    }

    override fun updateUserInfo(accessToken2: String?, currentUser: User?) {
//        accessToken = accessToken2
//        this.currentUser=currentUser
//        updateApiHeader(currentUser?.id, accessToken)
    }


    override fun getConnectivityStateLD(): MutableLiveData<Int> {
        return connectivityState
    }

    override fun getNewMessages(): MutableLiveData<ChatMessage> {
        return newMessagesLD
    }


    companion object {
        private const val TAG = "AppDataManager"
    }

    override fun onConnect() {
        connectivityState.postValue(ConnectivityStates.STATE_CONNECTED)
    }

    override fun onConnectionError() {
        connectivityState.postValue(ConnectivityStates.STATE_NOT_CONNECTED)
    }

    override fun onReconnect() {
        connectivityState.postValue(ConnectivityStates.STATE_RECONNECTING)
    }

    override fun onDisconnect() {
        connectivityState.postValue(ConnectivityStates.STATE_DISCONNECTED)
    }

    override fun onNewMessage(message: ChatMessage?) {
        newMessagesLD.postValue(message)
    }

}