package com.app.basketiodriver.ui.order.product

import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.order.ProductItem
import com.app.basketiodriver.databinding.ActivityProductListBinding
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.home.HomeViewModel
import com.app.basketiodriver.ui.order.adapter.ProductDashboardAdapter
import com.app.basketiodriver.utils.AppConstants
//import kotlinx.android.synthetic.main.app_bar_with_support.view.*
import java.util.*
import kotlin.collections.ArrayList

class ProductDashboardActivity : BaseActivity<ActivityProductListBinding, HomeViewModel>() {
    override val layoutId: Int
        get() = R.layout.activity_product_list

    override val viewModel: HomeViewModel
        get() {
            return getViewModel(HomeViewModel::class.java)
        }

    var list : ArrayList<ProductItem> = arrayListOf()
    lateinit var productsAdapter : ProductDashboardAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        initToolbar(getString(R.string.product_list),
            true, viewDataBinding!!.layoutToolBar.toolbar,
            View.OnClickListener {
                run {
                    onBackPressed()
                }
            })

//        list = intent.getSerializableExtra("ARG_ITEMS_ARRAY") as ArrayList<ProductItem>
        list = AppConstants.dashboardProductList
        productsAdapter = ProductDashboardAdapter(this, list)

        initView()
    }

    private fun initView(){
        viewDataBinding!!.rvProducts.layoutManager = LinearLayoutManager(this)
        viewDataBinding!!.rvProducts.setHasFixedSize(true)

        viewDataBinding!!.rvProducts.adapter = productsAdapter
    }

    override fun onBackPressed() {
        finish()
    }
}