package com.app.basketiodriver.data.remote.socket

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.app.basketiodriver.ShopperApp
import com.app.basketiodriver.ShopperApp_LifecycleAdapter
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.remote.APIManager
import com.app.basketiodriver.service.LocationService
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.utils.AppConstants
import io.socket.client.Ack
import io.socket.client.Socket
import org.json.JSONObject
import timber.log.Timber
import javax.inject.Inject


class ChatMessageHelper {
    var socket: Socket?

    fun OrderStarted(
        OrderOutletId: Long?,
        shopperName: String?,
        customerId: Long?,
        cusName: String?
    ) {
        Log.d("onMethod", "" + "order_started")

        if (socket != null && socket!!.connected()) {
            val jsonObject = JSONObject()
            try {
                jsonObject.put("order_outlet_id", OrderOutletId)
                jsonObject.put("shopper_name", shopperName)
                jsonObject.put("user_type", AppConstants.ORDER_START)
                jsonObject.put("customer_id", customerId)
                jsonObject.put("customer_name", cusName)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            socket!!.emit("order_started", jsonObject)
            LocationService.customerId = customerId!!
            Log.d("onMethod", "" + jsonObject.toString())
        }
    }

    /* All new Chat service */
    @SuppressLint("CheckResult")
    fun sendSystemMessage(
        orderId: Long,
        message: String?,
        status: Int
    ) {
        //if (status == 0 || status > PreferenceManager.getOrderStatus(orderId.toString()) || PreferenceManager.getOrderStatus(orderId.toString()) == 0
        if (true
        ) {
            if (status > 0) PreferenceManager.setOrderStatus(status, "" + orderId)
            val systemMessageReq = SystemMessageReq(orderId.toString(), "text", message!!)
      //      APIManager.sendSystemMessage(systemMessageReq)
        } else {
            Log.d("onMethod", "" + "order_started")
        }
    }

    /**
     * Used for create room for particular order Channel
     *
     * @param OrderOutletId
     */
    fun crateChatRoom(OrderOutletId: Long) {
        if (socket!!.connected()) {
            val jsonObject = JSONObject()
            try {
                Log.d("onMethod", "CreateRoom")
                jsonObject.put("order_id", OrderOutletId.toString())
                Log.e("onMethod", "Emit : = $jsonObject")
                socket!!.emit("chat:room:create", jsonObject, callback)
                Log.e("onMethod", "chat:room:create : =$jsonObject")
            } catch (e: Exception) {
                Log.d("onMethod", "CatchErrorCreateRoom")
            }
        }else{
            Log.d("onMethod", "ErrorCreateRoom")
        }
    }

    private val callback = Ack { args -> Log.e("Ack", "chat:room:create : =" + args[0].toString()) }
    fun closeChatRoom(OrderOutletId: Long?) {
        Log.d("onMethod", "closeChatRoom")
        if (socket!!.connected()) {
            val jsonObject = JSONObject()
            try {
                jsonObject.put("order_id", OrderOutletId)
                socket!!.emit("chat:room:close", jsonObject, Ack { args ->
                    Handler(Looper.getMainLooper()).post {
                        val data = args[0].toString()
                        Log.d("onMethod", "chat:room:close : =$data")
                    }
                })
                Log.d("onMethod", "chat:room:close : =$jsonObject")
            } catch (e: Exception) {
                Log.e("chat:room:close", e.message ?: "Failed to close the chat room")
            }
        }
    }

    fun userSendReadStatus(OrderOutletId: Long, messageId: String?) {
        Log.d("onMethod", "chat:room:send:read:status")
        if (socket!!.connected()) {
            val jsonObject = JSONObject()
            try {
                jsonObject.put("order_id", OrderOutletId.toString())
                jsonObject.put("message_id", messageId)
                socket!!.emit("chat:room:send:read:status", jsonObject, Ack { args ->
                    Handler(Looper.getMainLooper()).post {
                        val data = args[0].toString()
                        Log.d("onMethod", "chat:room:send:read:status : =$data")
                    }
                })
                Log.d("onMethod", "chat:room:send:read:status : =$jsonObject")
            } catch (e: Exception) {
                Log.e("send:read:status", e.message ?: "Failed to send the read message status")
            }
        }
    }

    init {
        var socketManager: SocketManager = SocketManager()
        socketManager.init(ShopperApp.Instance.newMessageCallback)
        socket = socketManager.chatSocket
    }
}
