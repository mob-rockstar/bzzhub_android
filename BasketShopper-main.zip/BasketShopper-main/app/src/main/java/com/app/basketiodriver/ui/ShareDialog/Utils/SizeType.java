package com.app.basketiodriver.ui.ShareDialog.Utils;

/**
 * Created by ogiba on 05.04.2017.
 */

public enum SizeType {
    FILL_WIDTH,
    WINDOWED,
    CUSTOM
}
