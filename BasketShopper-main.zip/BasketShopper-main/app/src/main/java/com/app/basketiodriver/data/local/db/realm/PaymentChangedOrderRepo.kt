package com.app.basketiodriver.data.local.db.realm

import com.app.basketiodriver.data.model.db.PaymentChangedOrder
import android.R.attr.order
import io.realm.Realm

import io.realm.RealmResults




class PaymentChangedOrderRepo : BaseRepo() {
    /**
     * Find all records
     */
    fun findAll(detached:Boolean = true) : List<PaymentChangedOrder>{
        var realmResults = realm.where(PaymentChangedOrder::class.java).findAll()

        return if (detached) {
            realm.copyFromRealm(realmResults)
        }
        else{
            realmResults
        }
    }

    /**
     * Find the data by using id
     */
    fun getById(id : Long, detached: Boolean = true) : PaymentChangedOrder?{
        var realmAddress: PaymentChangedOrder? =
            realm.where(PaymentChangedOrder::class.java).equalTo("orderId", id).findFirst()

        if (detached && realmAddress != null) {
            realmAddress = realm.copyFromRealm<PaymentChangedOrder>(realmAddress)
        }

        return realmAddress
    }

    /**
     * Save the object
     */
    fun save(order : PaymentChangedOrder) {
        realm.executeTransaction { r -> r.copyToRealmOrUpdate(order) }
    }

    /**
     * Delete the object
     */
    fun delete(order : PaymentChangedOrder){
        if (order.isValid){
            realm.executeTransaction {
                val result: RealmResults<PaymentChangedOrder> =
                    realm.where(PaymentChangedOrder::class.java).equalTo("orderId", order.orderId).findAll()
                result.deleteAllFromRealm()
            }
        }
    }
}