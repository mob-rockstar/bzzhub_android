package com.app.basketiodriver.data.model.api.response.order

import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class ItemResponse {

    @SerializedName("response")
    @Expose
    val response: ResponseData? = null

    inner class ResponseData{
        @SerializedName("httpCode")
        @Expose
        val httpCode: Int? = null

        @SerializedName("Message")
        @Expose
        val message: String? = null

        @SerializedName("item_details")
        @Expose
        val itemDetails: OrdersItem? = null
    }
}