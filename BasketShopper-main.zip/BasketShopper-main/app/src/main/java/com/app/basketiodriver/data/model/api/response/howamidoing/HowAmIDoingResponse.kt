package com.app.basketiodriver.data.model.api.response.howamidoing

import com.google.gson.annotations.SerializedName


class HowAmIDoingResponse {
    @SerializedName("data")
    val data: HowAmIDoingDetail? = null

    @SerializedName("message")
    val message: String = ""
}