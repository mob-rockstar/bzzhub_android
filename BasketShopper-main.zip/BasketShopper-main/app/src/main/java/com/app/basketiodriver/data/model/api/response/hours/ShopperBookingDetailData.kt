package com.app.basketiodriver.data.model.api.response.hours

import com.app.basketiodriver.data.model.api.BookingReport
import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class ShopperBookingDetailData {
    @SerializedName("estimated_earning")
    @Expose
    val estimatedEarning: String? = null

    @SerializedName("week_booking_report")
    @Expose
    val weekBookingReport: List<BookingReport>? = null
}