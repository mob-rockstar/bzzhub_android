package com.app.basketiodriver.ui.earning.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.earning.YearlyBalanceReportItem
import com.app.basketiodriver.data.model.api.response.earning.monthly.ReportView
import com.app.basketiodriver.databinding.ItemShopperDetailReportBinding
import com.app.basketiodriver.databinding.ItemShopperEarningsBinding
import com.app.basketiodriver.ui.base.DataListAdapter
import com.app.basketiodriver.ui.base.DataViewHolder
import com.app.basketiodriver.utils.CommonUtils
import com.app.basketiodriver.utils.OnItemClickedListener
import java.util.*

class WeeklyEarningAdapter (val mContext : Context, val reportType : String, val listener: OnItemClickedListener<ReportView>) :
    DataListAdapter<ReportView, ItemShopperDetailReportBinding>(){


    override fun createBinding(inflater: LayoutInflater, parent: ViewGroup? ): ItemShopperDetailReportBinding {
        return DataBindingUtil.inflate(inflater, R.layout.item_shopper_detail_report, parent, false)
    }

    override fun onBindViewHolder(holder: DataViewHolder<ItemShopperDetailReportBinding>, position: Int) {
        super.onBindViewHolder(holder, position)
        holder.binding.root.setOnClickListener { listener.onClicked(holder.binding.detailReportItem!!) }
    }

    override fun bind(binding: ItemShopperDetailReportBinding?, item: ReportView) {
        binding!!.detailReportItem = item

        if (reportType == "monthly"){
            // Week Name
            binding.monthTV.text = item.week_name

            // Amount
            binding.amountTV.text = String.format(Locale("en"), "%s %s", PreferenceManager.currency, item.week_balance)
            CommonUtils.setBalanceTextColor(binding.amountTV, "" + item.week_balance)
        }
        else if (reportType == "weekly"){
            // Day name
            binding.monthTV.text = item.day_name

            // Amount
            binding.amountTV.text = String.format(Locale("en"), "%s %s", PreferenceManager.currency, item.day_balance)
            CommonUtils.setBalanceTextColor(binding.amountTV, "" + item.day_balance)
        }
        else{
        }
    }
}