package com.app.basketiodriver.ui.onboarding

/**
 * Created by ibraheem lubbad on 2020-01-22.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/

interface OnJoinWaitListNavigator {

    /**
     * callback action to join wait list for type user
     */
    fun goToJoin()
}
