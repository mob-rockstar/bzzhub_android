package com.app.basketiodriver.ui.checkout.adapter

import android.view.ViewGroup
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.checkout.CustomerInfo
import com.app.basketiodriver.data.model.api.response.checkout.Department
import com.app.basketiodriver.data.model.api.response.checkout.StoreLocation
import com.app.basketiodriver.databinding.ItemDepartmentBinding
import com.app.basketiodriver.utils.BaseRecyclerViewAdapter

class StoreLocationAdapter (val activity : FragmentActivity, val list : List<StoreLocation>, val userMobile : String, val outletId : Long, val info : CustomerInfo, val dots:Boolean, val isClick : Boolean, val isExpress : Int)
    : BaseRecyclerViewAdapter<StoreLocation, ItemDepartmentBinding>()  {

    override val layoutId: Int
        get() = R.layout.item_department

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return StoreLocationViewHolder(createBindView(parent))
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val holder = holder as StoreLocationViewHolder
        val item = list[position]

        // Store Location Name
        holder.binding.tvDepartment.text = item.storeLocationName

        // Set the LayoutManager
        holder.binding.rvItems.setHasFixedSize(true)
        holder.binding.rvItems.layoutManager = LinearLayoutManager(activity)

        if (holder.binding.rvItems.adapter == null){
            holder.binding.rvItems.adapter = OrderDetailItemAdapter(activity, list[position].items, userMobile, outletId, info, isClick, dots, isExpress)
        }
        else {
            val itemAdapter = holder.binding.rvItems.adapter as OrderDetailItemAdapter
            itemAdapter.listItem = list[position].items
            itemAdapter.notifyDataSetChanged()
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    inner class StoreLocationViewHolder(val binding: ItemDepartmentBinding) :
        RecyclerView.ViewHolder(binding.root)
}