package com.app.basketiodriver.ui.base


import android.app.Application
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.app.basketiodriver.data.DataManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.utils.AppLogger
import com.google.gson.Gson
import com.google.gson.TypeAdapter
import com.jakewharton.retrofit2.adapter.rxjava2.HttpException
import io.reactivex.disposables.CompositeDisposable
import java.io.IOException
import java.lang.ref.WeakReference


/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
abstract class BaseViewModel<N>(val application: Application, val dataManager: DataManager) :
    ViewModel() {


    /**
     * Property to show loading dialog
     */
    val isLoading = MutableLiveData<Boolean>()

    private var mNavigator: WeakReference<N>? = null


    /**
     * Property to bind screen title
     */
    val screenTitle = MutableLiveData<String>()
    val errorResLiveData = MutableLiveData<ErrorResponse>()

    /**
     * default data
     */

    val shopperId = 18L
    val accessToken =
        "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOjE4LCJpc3MiOiJodHRwczovL2FwaS50ZXN0LWJhc2tldC5jb20vYXBpL3Y1L3Nob3BwZXItbG9naW4iLCJpYXQiOjE1OTMyNjU3ODksImV4cCI6NDE4NTI2NTc4OSwibmJmIjoxNTkzMjY1Nzg5LCJqdGkiOiJlZkJxNGpOSGN4dGVSUGRzIn0.LzDi7YRWzYubMY4gcX7DUxf1WNccf6yqIM2bIMX69Ro"

    var compositeDisposable = CompositeDisposable()


    override fun onCleared() {
        compositeDisposable.dispose()
        super.onCleared()


    }

    fun setIsLoading(isLoading: Boolean) {
        this.isLoading.value = (isLoading)
    }

    val navigator: N?
        get() = mNavigator!!.get()

    fun setNavigator(navigator: N) {
        mNavigator = WeakReference(navigator)
    }


    /**
     * parse error coming from api
     * @param t Throwable?
     * @param handelError BaseNavigator?
     */
    open fun parseError(t: Throwable?, handelError: BaseNavigator? = null) {
        if (t is HttpException) {
            val throwableError = getThrowableError(t)
            handelError?.handleError(throwableError?.message!!)
            errorResLiveData.postValue(throwableError)
        } else {
            handelError?.handleError(t!!.message!!)
        }
    }


    /**
     * parse error  to Error Response
     * @param t Throwable
     * @return ErrorResponse?
     */
    fun getThrowableError(t: Throwable): ErrorResponse? {

        if (t is HttpException) {
            val body = t.response().errorBody()
            val gson = Gson()
            val adapter: TypeAdapter<ErrorResponse> = gson.getAdapter(ErrorResponse::class.java)
            try {
               return adapter.fromJson(body!!.string())

            } catch (e: IOException) {
                AppLogger.d("IOException $e")
                e.printStackTrace()
            }
        } else {
            val errorResponse = ErrorResponse()
            errorResponse.message = t.message
            return errorResponse
        }
        return null
    }



    /**
     * refactor list of errors field  to one string as points
     * @param erorr ArrayList<String>?
     * @return String?
     */
    private fun parseFieldErorrs(erorr: List<String>?): String? {
        val errMessage = StringBuilder("\n")
        if (erorr == null || erorr.isEmpty()) return errMessage.toString()

        erorr.forEach {
            errMessage.append("- ").append(it).append("\n")
        }

        return errMessage.toString().trim()
    }

    /**
     * show error list
     * @param errorParser ErrorResponse
     * @return String?
     */
    fun parseFieldErorrs(errorParser: ErrorResponse): String? {
        if (errorParser.errorsMessages.isNullOrEmpty()) {
            return errorParser.message
        }
        var errorMMessages: String = ""
        errorParser.errorsMessages!!.mapValues {
            errorMMessages +=  parseFieldErorrs(it.value)

        }
        AppLogger.d("errorsMessages ${ errorParser.errorsMessages}")

 /*       var errorMMessages: String = ""
        errorMMessages += parseFieldErorrs(errorParser.errorsMessages!!.first_name)
        errorMMessages += parseFieldErorrs(errorParser.errorsMessages!!.last_name)
        errorMMessages += parseFieldErorrs(errorParser.errorsMessages!!.mobile)
        errorMMessages += parseFieldErorrs(errorParser.errorsMessages!!.email)
        errorMMessages += parseFieldErorrs(errorParser.errorsMessages!!.password)*/

        errorMMessages.trim { it <= ' ' }
        return errorMMessages
    }
}