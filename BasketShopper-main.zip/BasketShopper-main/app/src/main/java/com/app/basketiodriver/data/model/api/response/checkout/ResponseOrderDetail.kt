package com.app.basketiodriver.data.model.api.response.checkout

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class ResponseOrderDetail {
    @SerializedName("httpCode")
    @Expose
    val httpCode: Int? = null

    @SerializedName("Message")
    @Expose
    val message: String? = null

    @SerializedName("outlet_order")
    @Expose
    val outletOrder: OutletOrder? = null

    @SerializedName("replacement_suggestion_limit")
    @Expose
    val replaceLimitCount: Int = 1
}