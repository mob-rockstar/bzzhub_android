
package com.app.basketiodriver.data.model.api

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class ApiError(val errorCode: Int, @field:SerializedName("status_code") @field:Expose val statusCode: String?, @field:SerializedName("message") @field:Expose val message: String?) {

    override fun equals(`object`: Any?): Boolean {
        if (this === `object`) {
            return true
        }
        if (`object` == null || javaClass != `object`.javaClass) {
            return false
        }
        val apiError = `object` as ApiError
        if (errorCode != apiError.errorCode) {
            return false
        }
        if (if (statusCode != null) statusCode != apiError.statusCode else apiError.statusCode != null) {
            return false
        }
        return if (message != null) message == apiError.message else apiError.message == null
    }

    override fun hashCode(): Int {
        var result = errorCode
        result = 31 * result + (statusCode?.hashCode() ?: 0)
        result = 31 * result + (message?.hashCode() ?: 0)
        return result
    }

}