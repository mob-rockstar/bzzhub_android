package com.app.basketiodriver.data.model.api.response.earning.payout

import com.google.gson.annotations.SerializedName

data class PayoutCreditData (
    @SerializedName("id")
    var id : Int = 0,

    @SerializedName("payment_type")
    var payment_type: String = "",

    @SerializedName("payment_method_name")
    var payment_method_name: String = "",

    @SerializedName("amount")
    var amount: String = "0.00",

    @SerializedName("reference_number")
    var reference_number: String = "",

    @SerializedName("voucher_number")
    var voucher_number: String = "",

    @SerializedName("status")
    var status: String = "",

    @SerializedName("created_on")
    var created_on: String = ""
)