package com.app.basketiodriver.ui.onboarding.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseExpandableListAdapter
import androidx.databinding.DataBindingUtil
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.DocumentsResponse
import com.app.basketiodriver.databinding.StageGroupChildBinding
import com.app.basketiodriver.databinding.StageGroupHeaderBinding
import com.app.basketiodriver.ui.onboarding.data.Stage


/**
Created by ibraheem lubbad on 2/27/20.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/

class StagesAdapter(private val context: Context, var listItems: MutableList<Stage>) :
    BaseExpandableListAdapter() {

    override fun getChild(groupPosition: Int, childPosititon: Int): DocumentsResponse.OnbaordingDocument? {
        return listItems[groupPosition].userDcouments.get(childPosititon)
    }

    override fun getChildId(groupPosition: Int, childPosition: Int): Long {
        return childPosition.toLong()
    }

    override fun getChildView(
        groupPosition: Int, childPosition: Int,
        isLastChild: Boolean, convertView: View?, parent: ViewGroup
    ): View {

        val v = if (convertView == null) {
            DataBindingUtil.inflate(
                context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater,
                R.layout.stage_group_child,
                parent,
                false
            )
        } else {
            convertView.tag as StageGroupChildBinding
        }

        v.root.tag = v
        v.tvMenuName.text = getChild(groupPosition, childPosition)!!.name
        return v.root
    }

    override fun getChildrenCount(groupPosition: Int): Int {
        return listItems[groupPosition].userDcouments.size
    }

    override fun getGroup(groupPosition: Int): Stage {
        return listItems[groupPosition]
    }

    override fun getGroupCount(): Int {
        return listItems.size
    }

    override fun getGroupId(groupPosition: Int): Long {
        return groupPosition.toLong()
    }

    override fun getGroupView(
        groupPosition: Int, isExpanded: Boolean,
        convertView: View?, parent: ViewGroup
    ): View {

        val v = if (convertView == null) {
            //  ListGroupHeaderBinding.inflate( context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater)
            DataBindingUtil.inflate(
                context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater,
                R.layout.stage_group_header,
                parent,
                false
            )

        } else {
            convertView.tag as StageGroupHeaderBinding
        }

        v.root.tag = v
        v.tvMenuName.text = getGroup(groupPosition).title

        if (getGroup(groupPosition).isDone) {
            v.ivMenuIcon.setBackgroundResource(R.drawable.bg_circle_green)
            v.ivMenuIcon.setImageResource(R.drawable.ic_done_white)
        } else {
            v.ivMenuIcon.setBackgroundResource(R.drawable.bg_circle_gray)
            v.ivMenuIcon.setImageBitmap(null)
        }



        return v.root
    }

    override fun hasStableIds(): Boolean {
        return false
    }

    override fun areAllItemsEnabled(): Boolean {
        return false
    }

    override fun isChildSelectable(groupPosition: Int, childPosition: Int): Boolean {
        return true
    }

    public  fun addItem(stage:  Stage){
        listItems.add(stage)
    }
    public  fun addItems(stages:  MutableList<Stage>){
        listItems.addAll(stages)
    }

}