package com.app.basketiodriver.data.model.api.chat

data class Shopper(
    var identifier: String,
    var name: String,
    var photo: String,
    var role: String
)