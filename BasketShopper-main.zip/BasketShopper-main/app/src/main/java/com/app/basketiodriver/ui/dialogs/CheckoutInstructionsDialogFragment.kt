package com.app.basketiodriver.ui.dialogs

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.View
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.model.api.response.order.SimilarProduct
import com.app.basketiodriver.databinding.FragmentAmountDialogBinding
import com.app.basketiodriver.databinding.FragmentCheckoutInstructionsDialogBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseDialogFragment
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel

class CheckoutInstructionsDialogFragment : BaseDialogFragment<FragmentCheckoutInstructionsDialogBinding?, OrderDetailsViewModel>(),
    Injectable {
    override val layoutId: Int
        get() = R.layout.fragment_checkout_instructions_dialog

    override val viewModel: OrderDetailsViewModel
        get() {
            return getViewModel(baseActivity, OrderDetailsViewModel::class.java)
        }

    // Listener
    var listener : AgreeTermsListener? = null

    var instruction : String = ""

    // Flag to check shopper selected the condition
    var acceptedCondition : Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    // Set Full screen
    override fun getTheme(): Int {
        return R.style.MyDialogWhite
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initToolbar()

        /**
         * get params
         */
        arguments?.let {
            instruction = it.getString(KEY_INSTRUCTION, "")

            initViews()
        }
    }

    private fun initToolbar(){
        viewDataBinding!!.layoutToolBar.toolBarTitle.setText(R.string.store_instructions)
        viewDataBinding!!.layoutToolBar.btnBack.setOnClickListener {
            dismiss()
        }
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    private fun initViews(){
        // display the instructions
        viewDataBinding!!.tvTerms.text = instruction

        viewDataBinding!!.checkbox.setOnCheckedChangeListener{ button, selected ->
            acceptedCondition = selected

            if (selected) {
                viewDataBinding!!.btnAgree.isEnabled = true
                viewDataBinding!!.btnAgree.background = resources.getDrawable(R.drawable.bg_button_green)
                viewDataBinding!!.btnAgree.setTextColor(resources.getColor(R.color.colorWhite))
            }
            else{
                viewDataBinding!!.btnAgree.isEnabled = false
                viewDataBinding!!.btnAgree.background = resources.getDrawable(R.drawable.bg_button_gray)
                viewDataBinding!!.btnAgree.setTextColor(resources.getColor(R.color.colorDisableText))
            }
        }

        viewDataBinding!!.btnAgree.setOnClickListener {
            dismiss()

            if (acceptedCondition) {
                if (listener != null)
                    listener!!.onAgreed()


            }
        }
    }

    companion object{
        const val KEY_INSTRUCTION = "key_instruction"

        fun newInstance(instructions : String) : CheckoutInstructionsDialogFragment {
            val fragment = CheckoutInstructionsDialogFragment()

            val data = Bundle()
            data.putString(KEY_INSTRUCTION, instructions)
            fragment.arguments = data

            return fragment
        }
    }

    interface AgreeTermsListener {
        fun onAgreed()
    }
}