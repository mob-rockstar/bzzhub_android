package com.app.basketiodriver.data.model.api.response.checkout

class Department {
    var departmentName : String = ""
    var items : ArrayList<OrdersItem> = arrayListOf()

    constructor(departmentName: String) {
        this.departmentName = departmentName
    }

    fun addItem(item : OrdersItem){
        items.add(item)
    }

    override fun equals(other: Any?): Boolean {
        if (other === this) return true
        if (other == null || javaClass != other.javaClass) return false

        val that = other as Department

        return if (departmentName != null) departmentName == that.departmentName else that.departmentName == null
    }

    override fun hashCode(): Int {
        return if (departmentName != null) departmentName.hashCode() else 0
    }


}