package com.app.basketiodriver.ui.dashbaord

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.ActivityStoreInstructionsBinding
import com.app.basketiodriver.databinding.FragmentLocationInstructionBinding
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.home.HomeViewModel
import com.app.basketiodriver.ui.notifications.NotificationsActivity

class StoreInstructionsActivity : BaseActivity<ActivityStoreInstructionsBinding?, StoreInstructionsViewModel>() {
    override val layoutId: Int
        get() = R.layout.activity_store_instructions

    override val viewModel: StoreInstructionsViewModel
        get() {
            return getViewModel(StoreInstructionsViewModel::class.java)
        }

    var instruction : String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        initToolbar(getString(R.string.store_instructions),
            true, viewDataBinding!!.layoutToolBar.toolbar,
            View.OnClickListener {
                run {
                    finish()
                }
            })

        instruction = intent.getStringExtra("store_instruction") ?: ""
        viewDataBinding!!.tvInstruction.text = instruction

    }

    companion object {
        fun newIntent(context: Context?): Intent {
            return Intent(context, StoreInstructionsActivity::class.java)
        }
    }
}