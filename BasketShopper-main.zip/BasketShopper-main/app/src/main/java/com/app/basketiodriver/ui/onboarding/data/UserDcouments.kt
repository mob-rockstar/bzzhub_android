package com.app.basketiodriver.ui.onboarding.data

data class UserDcouments(
    val doc_id: String,
    val title: String,
    val is_required: Boolean,
    val sort: Int,
    val sub: List<Sub>?
)