package com.app.basketiodriver.data.model.api.response.customerAdditionalQuestions

data class TitleX(
    val lang: String,
    val text: String
)