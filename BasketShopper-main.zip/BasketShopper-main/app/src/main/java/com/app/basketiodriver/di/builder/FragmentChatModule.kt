package com.app.basketiodriver.di.builder

import com.app.basketiodriver.ui.chat.FullImageFragment
import com.app.basketiodriver.ui.chat.FullScreenVideoPreviewFragment
import com.app.basketiodriver.ui.checkout.fragments.ToDo
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class FragmentChatModule {

    @ContributesAndroidInjector
    abstract fun contributeFullImageFragment(): FullImageFragment

    @ContributesAndroidInjector
    abstract fun contributeFullScreenVideoPreviewFragment(): FullScreenVideoPreviewFragment
}