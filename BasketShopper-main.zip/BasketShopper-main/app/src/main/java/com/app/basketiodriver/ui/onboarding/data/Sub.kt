package com.app.basketiodriver.ui.onboarding.data

data class Sub(
    val sort: Int,
    val title: String,
    val tip: String,
    val description: String,
    val sub_id: String,
    val label: String,
    val placehoder_url: String,

    val file_exts: List<String>
)