package com.app.basketiodriver.data.model.api.response.directions

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName

class GeocodedWaypoint {
    @SerializedName("geocoder_status")
    @Expose
    private val geocoderStatus: String? = null

    @SerializedName("place_id")
    @Expose
    private val placeId: String? = null

    @SerializedName("types")
    @Expose
    private val types: List<String>? = null
}