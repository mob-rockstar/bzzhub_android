package com.app.basketiodriver.ui.earning.fragments

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.earning.bonus.BonusDeductionsData
import com.app.basketiodriver.data.model.api.response.earning.bonus.ShopperBonusDeductionsData
import com.app.basketiodriver.data.model.api.response.earning.bonus.ShopperBonusDeductionsResponse
import com.app.basketiodriver.data.model.api.response.earning.payout.PayoutCreditData
import com.app.basketiodriver.data.model.api.response.earning.payout.ShopperPayoutCreditData
import com.app.basketiodriver.data.model.api.response.earning.payout.ShopperPayoutCreditResponse
import com.app.basketiodriver.databinding.FragmentBonusDeductionsBinding
import com.app.basketiodriver.databinding.FragmentEarningsCreditBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.earning.EarningViewModel
import com.app.basketiodriver.ui.earning.adapters.BonusDeductionsAdapter
import com.app.basketiodriver.ui.earning.adapters.OrderPayoutCreditAdapter
import com.app.basketiodriver.ui.earning.fragments.BonusDeductionsFragmentArgs.fromBundle
import com.app.basketiodriver.utils.AppConstants
import com.app.basketiodriver.utils.CommonUtils
import com.app.basketiodriver.utils.InfoHelp
import com.app.basketiodriver.utils.OnItemClickedListener
import com.tbruyelle.rxpermissions2.RxPermissions
import io.reactivex.android.schedulers.AndroidSchedulers
import java.util.*

class BonusDeductionsFragment : BaseFragment<FragmentBonusDeductionsBinding?, EarningViewModel>(),
    Injectable {

    override val layoutId: Int
        get() = R.layout.fragment_bonus_deductions

    override val viewModel: EarningViewModel
        get() {
            return getViewModel(baseActivity as FragmentActivity, EarningViewModel::class.java)
        }

    // Yearly Balance Report
    val yearReportItem by lazy {
        fromBundle(arguments!!).yearReportItem
    }

    var requestType : String = "Bonus" // Bonus or Deduction

    private lateinit var bonusAdapter : BonusDeductionsAdapter
    var reportViewArray : ArrayList<BonusDeductionsData> = arrayListOf()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (arguments != null){
            requestType = fromBundle(arguments!!).requestType
        }

        // Initialize the UI
        initUI()

        getShopperBonusDeductionsDetails()

    }

    private fun initUI(){
        // Set the title
        val title = String.format(Locale("en"), "%s, %s", yearReportItem.monthName, yearReportItem.year)
        setTitle(title)

        // Init RecyclerManager
        val linearLayoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        viewDataBinding!!.recyclerView.layoutManager = linearLayoutManager
        viewDataBinding!!.recyclerView.setHasFixedSize(true)

        // Get Help
        viewDataBinding!!.btnHelp.setOnClickListener {
            getHelp()
        }

        if (requestType == "Bonus"){
            viewDataBinding!!.txtTitle.text = getString(R.string.bonus_summary)
        }
        else{
            viewDataBinding!!.txtTitle.text = getString(R.string.deductions_summary)
        }

        viewDataBinding!!.txtCurrentBalance.setOnClickListener{
            InfoHelp.showHelpDialog(it, baseActivity?.resources?.getString(R.string.your_current_balance)!!, baseActivity as Activity, true)
        }

        // Init Adapter
        bonusAdapter = BonusDeductionsAdapter(requireContext(), object :
            OnItemClickedListener<BonusDeductionsData> {
            override fun onClicked(item: BonusDeductionsData) {

            }
        })
    }

    // Call the support team
    private fun getHelp(){
        val builder: AlertDialog.Builder = AlertDialog.Builder(requireContext())
        builder.setTitle("")
        builder.setMessage(getString(R.string.support_call))
            .setCancelable(false)
            .setPositiveButton(
                getString(R.string.ok_btn_txt)
            ) { _, _ -> //do things
                callSupportTeam()

            }.setNegativeButton(
                getString(R.string.cancel_btn_txt)
            ) { _, _ ->
                //do things
            }
        val alert: AlertDialog = builder.create()
        alert.show()
    }

    @SuppressLint("CheckResult")
    private fun callSupportTeam(){
        val number = String.format(Locale("en"), "tel:%s", AppConstants.SUPPORT_PHONE_NUMBER)
        RxPermissions(this).request(
            Manifest.permission.CALL_PHONE
        ).observeOn(AndroidSchedulers.mainThread())
         .subscribe { granted ->
                if (granted) {
                    val intent = Intent(Intent.ACTION_CALL, Uri.parse(number))
                    startActivity(intent)
                }
                else{
                    Toast.makeText(baseActivity, getString(R.string.error_no_call_permission), Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun getShopperBonusDeductionsDetails(){
        val month : Int = if (yearReportItem != null) yearReportItem.monthNumber else Calendar.getInstance().get(
            Calendar.MONTH)
        val year : Int = if (yearReportItem != null) yearReportItem.year.toInt() else Calendar.getInstance().get(
            Calendar.YEAR)

        viewModel.getShopperBonusDeductionsDetails(month, year, requestType, object :
            HandleResponse<ShopperBonusDeductionsResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Toast.makeText(baseActivity, error?.message, Toast.LENGTH_SHORT).show()
                }else{
                    Toast.makeText(baseActivity, baseActivity!!.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }
            }

            override fun handleSuccessResponse(successResponse: ShopperBonusDeductionsResponse) {
                if (successResponse.data != null){
                    updateUI(successResponse.data)
                }
                else{
                    Toast.makeText(baseActivity, successResponse.message, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    private fun updateUI(data : ShopperBonusDeductionsData) {
        if (data.is_account_suspended) {
            viewDataBinding!!.suspendedLL.visibility = View.VISIBLE
        }
        else{
            viewDataBinding!!.suspendedLL.visibility = View.GONE
        }

        // Current Balance
        val currBalance = PreferenceManager.currency + " " + data.current_account_balance
        viewDataBinding!!.currentBalanceValue.text = currBalance
        CommonUtils.setBalanceTextColor(viewDataBinding!!.currentBalanceValue, "" + data.current_account_balance)

        reportViewArray = data.bonusDeductions

        updateBonusDeductionList()
    }

    // Refresh Bonus List
    private fun updateBonusDeductionList(){
        viewDataBinding!!.recyclerView.adapter = bonusAdapter
        bonusAdapter.replace(reportViewArray)

        if (reportViewArray.size > 0){
            viewDataBinding!!.emptyView.visibility = View.GONE
        }
        else{
            viewDataBinding!!.emptyView.visibility = View.VISIBLE
        }
    }
}