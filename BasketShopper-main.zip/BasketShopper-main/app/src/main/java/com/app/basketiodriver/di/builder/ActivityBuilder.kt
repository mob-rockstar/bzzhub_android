
package com.app.basketiodriver.di.builder


import com.app.basketiodriver.ui.availablebatches.AvailableBatchesActivity
import com.app.basketiodriver.ui.availablebatches.FirstOrderWelcomeActivity
import com.app.basketiodriver.ui.batches.BatchesActivity
import com.app.basketiodriver.ui.cardcamera.camera.CameraActivity
import com.app.basketiodriver.ui.chat.ChatActivity
//import com.app.basketiodriver.ui.checkout.CheckoutActivity
import com.app.basketiodriver.ui.checkout.card.CheckoutCardActivity
import com.app.basketiodriver.ui.checkout.handover.HandOverActivity
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsActivity
import com.app.basketiodriver.ui.checkout.payment.PaymentActivity
import com.app.basketiodriver.ui.checkout.receipt.ReceiptInfoActivity
import com.app.basketiodriver.ui.checkout.receipt.UploadReceiptInfoActivity
import com.app.basketiodriver.ui.checkout.scan.ScanditActivity
import com.app.basketiodriver.ui.complain.ComplainActivity
import com.app.basketiodriver.ui.dashbaord.StoreInstructionsActivity
import com.app.basketiodriver.ui.dashbaord.map.LocationMapActivity
import com.app.basketiodriver.ui.order.review.OrderReviewActivity
import com.app.basketiodriver.ui.earning.EarningActivity
import com.app.basketiodriver.ui.home.EnableLocationActivity
import com.app.basketiodriver.ui.home.HomeActivity
import com.app.basketiodriver.ui.hours.HoursActivity
import com.app.basketiodriver.ui.howdoing.HowDoingActivity
import com.app.basketiodriver.ui.login.LoginActivity
import com.app.basketiodriver.ui.messages.InboxActivity
import com.app.basketiodriver.ui.messages.MessagesActivity
import com.app.basketiodriver.ui.notifications.NotificationsActivity
import com.app.basketiodriver.ui.onboarding.OnBoardingActivity
import com.app.basketiodriver.ui.order.ArrivedToCustomerActivity
import com.app.basketiodriver.ui.order.OrderListActivity
import com.app.basketiodriver.ui.order.StagingOrderActivity
import com.app.basketiodriver.ui.order.product.*
import com.app.basketiodriver.ui.order.review.DashboardOrderInfoActivity
import com.app.basketiodriver.ui.order.review.HistoryOrderInfoActivity
import com.app.basketiodriver.ui.order.review.ReviewChangesLatestActivity
import com.app.basketiodriver.ui.profile.ProfileActivity
import com.app.basketiodriver.ui.rating.GoToDashbaordFragment
import com.app.basketiodriver.ui.rating.OrderCompletedFragment
import com.app.basketiodriver.ui.rating.RatingActivity
import com.app.basketiodriver.ui.referrals.ReferralsActivity
import com.app.basketiodriver.ui.register.RegisterActivity
import com.app.basketiodriver.ui.reimbursement.NewReimbursementRequestActivity
import com.app.basketiodriver.ui.reimbursement.SelectOrderDeliveryActivity
import com.app.basketiodriver.ui.settings.PrivacyActivity
import com.app.basketiodriver.ui.settings.ReportedIssuesActivity
import com.app.basketiodriver.ui.settings.TermsActivity
import com.app.basketiodriver.ui.splash.SplashActivity
import com.app.basketiodriver.ui.start.StartActivity
import com.app.basketiodriver.ui.status.StatusActivity
import com.app.basketiodriver.ui.weekhours.EarlyAccessStatus.EarlyAccessStatusActivity
import com.app.basketiodriver.ui.weekhours.HoursScheduleActivity
import com.app.basketiodriver.ui.weekhours.Vacation.VacationActivity
import dagger.Module
import dagger.android.ContributesAndroidInjector


/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
@Module
abstract class ActivityBuilder {


    @ContributesAndroidInjector
    abstract fun bindSplashActivity(): SplashActivity

    @ContributesAndroidInjector
    abstract fun bindStartActivity(): StartActivity

    @ContributesAndroidInjector(modules = [FragmentDrawerModule::class])
    abstract fun bindHomeActivity(): HomeActivity

    @ContributesAndroidInjector(modules = [FragmentLoginModule::class])
    abstract fun bindLoginActivity(): LoginActivity

    @ContributesAndroidInjector(modules = [FragmentRegisterModule::class])
    abstract fun bindRegisterActivity(): RegisterActivity


    @ContributesAndroidInjector(modules = [FragmentOnboardingModule::class])
    abstract fun bindOnBoardingActivity(): OnBoardingActivity


    @ContributesAndroidInjector(modules = [FragmentProfileModule::class])
    abstract fun bindProfileActivity(): ProfileActivity

    @ContributesAndroidInjector(modules = [FragmentHoursScheduleModule::class])
    abstract fun bindHoursScheduleActivity(): HoursScheduleActivity

//    @ContributesAndroidInjector()
//    abstract fun bindCheckoutActivity(): CheckoutActivity

    @ContributesAndroidInjector(modules = [FragmentCheckoutModule::class])
    abstract fun bindOrderDetailsActivity(): OrderDetailsActivity

    @ContributesAndroidInjector(modules = [FragmentCheckoutModule::class])
    abstract fun bindReviewChangesLatestActivity(): ReviewChangesLatestActivity

    @ContributesAndroidInjector()
    abstract fun bindCheckoutCardActivity(): CheckoutCardActivity

    @ContributesAndroidInjector(modules = [FragmentCheckoutModule::class])
    abstract fun bindPaymentActivity(): PaymentActivity

    @ContributesAndroidInjector()
    abstract fun bindReceiptInfoActivity(): ReceiptInfoActivity

    @ContributesAndroidInjector(modules = [FragmentDrawerModule::class])
    abstract fun bindArrivedToCustomerActivity(): ArrivedToCustomerActivity

    @ContributesAndroidInjector()
    abstract fun bindScanditActivity(): ScanditActivity

    @ContributesAndroidInjector()
    abstract fun bindUploadReceiptInfoActivity(): UploadReceiptInfoActivity

    @ContributesAndroidInjector()
    abstract fun bindHandOverActivity(): HandOverActivity

    @ContributesAndroidInjector(modules = [FragmentEarningModule::class])
    abstract fun bindEarningActivity(): EarningActivity

    @ContributesAndroidInjector(modules = [FragmentHowIAmDoingModule::class])
    abstract fun bindHowDoingActivity(): HowDoingActivity

    @ContributesAndroidInjector()
    abstract fun bindStatusActivity(): StatusActivity

    @ContributesAndroidInjector()
    abstract fun bindComplainActivity(): ComplainActivity

    @ContributesAndroidInjector(modules = [FragmentRateModule::class])
    abstract fun bindRatingActivity(): RatingActivity

    @ContributesAndroidInjector
    abstract fun bindGoToDashbaordFragment(): GoToDashbaordFragment

    @ContributesAndroidInjector
    abstract fun bindOrderCompletedFragment(): OrderCompletedFragment

    @ContributesAndroidInjector(modules = [FragmentOrderListModule::class])
    abstract fun bindOrderListActivity(): OrderListActivity

    @ContributesAndroidInjector(modules = [FragmentBatchesModule::class])
    abstract fun bindBatchesActivity(): BatchesActivity


    @ContributesAndroidInjector()
    abstract fun bindCameraActivity(): CameraActivity


    @ContributesAndroidInjector()
    abstract fun bindAvailableBatchesActivity(): AvailableBatchesActivity

    @ContributesAndroidInjector()
    abstract fun bindEnableLocationActivity(): EnableLocationActivity

    @ContributesAndroidInjector()
    abstract fun bindReportedIssuesActivity(): ReportedIssuesActivity


    @ContributesAndroidInjector()
    abstract fun bindReferralsActivity(): ReferralsActivity

    @ContributesAndroidInjector()
    abstract fun bindPrivacyActivity(): PrivacyActivity

    @ContributesAndroidInjector()
    abstract fun bindTermsActivity(): TermsActivity


    @ContributesAndroidInjector()
    abstract fun bindFirstOrderWelcomeActivity(): FirstOrderWelcomeActivity

    @ContributesAndroidInjector()
    abstract fun bindNewReimbursementRequestActivity(): NewReimbursementRequestActivity

    @ContributesAndroidInjector()
    abstract fun bindSelectOrderDeliveryActivity(): SelectOrderDeliveryActivity

    @ContributesAndroidInjector()
    abstract fun bindInboxActivity(): InboxActivity

    @ContributesAndroidInjector()
    abstract fun bindNotificationsActivity() : NotificationsActivity

    @ContributesAndroidInjector()
    abstract fun bindStoreInstructionsActivity() : StoreInstructionsActivity

    @ContributesAndroidInjector(modules = [FragmentItemDetailsModule::class])
    abstract fun bindOrderReviewActivity() : OrderReviewActivity

    //DashboardOrderInfoActivity
    @ContributesAndroidInjector()
    abstract fun bindDashboardOrderInfoActivity() : DashboardOrderInfoActivity

    //ProductDashboardActivity
    @ContributesAndroidInjector()
    abstract fun bindProductDashboardActivity() : ProductDashboardActivity

    //ProductsActivity
    @ContributesAndroidInjector()
    abstract fun bindProductsActivity() : ProductsActivity

    @ContributesAndroidInjector()
    abstract fun bindNewProductListActivity() : NewProductListActivity

    //ProductsActivity
    @ContributesAndroidInjector(modules = [FragmentItemDetailsModule::class])
    abstract fun bindItemDetails() : ItemDetails

    @ContributesAndroidInjector()
    abstract fun bindZoomImageActivity() : ZoomImageActivity

    @ContributesAndroidInjector()
    abstract fun bindBarcodeReaderActivity() : BarcodeReaderActivity

    @ContributesAndroidInjector(modules = [FragmentScanItemModule::class])
    abstract fun bindScanItem() : ScanItem

    @ContributesAndroidInjector(modules = [FragmentItemDetailsModule::class])
    abstract fun bindBasketSuggestionListActivity() : BasketSuggestionListActivity

    @ContributesAndroidInjector(modules = [FragmentItemDetailsModule::class])
    abstract fun bindCreateCustomItemActivity() : CreateCustomItemActivity

    @ContributesAndroidInjector(modules = [FragmentItemDetailsModule::class])
    abstract fun bindReplaceCustomItemActivity() : ReplaceCustomItemActivity

    @ContributesAndroidInjector(modules = [FragmentItemDetailsModule::class])
    abstract fun bindAddBySearchActivity() : AddBySearchActivity

    @ContributesAndroidInjector()
    abstract fun bindOpenCameraActivity() : OpenCameraActivity

    @ContributesAndroidInjector(modules = [FragmentItemDetailsModule::class])
    abstract fun bindSearchForSimilarActivity() : SearchForSimilarActivity

    @ContributesAndroidInjector(modules = [FragmentItemDetailsModule::class])
    abstract fun bindScanAsReplaceItemActivity() : ScanAsReplaceItemActivity

    @ContributesAndroidInjector(modules = [FragmentItemDetailsModule::class])
    abstract fun bindScanReplaceActivity() : ScanReplaceActivity

    @ContributesAndroidInjector()
    abstract fun bindHistoryOrderInfoActivity() : HistoryOrderInfoActivity

    @ContributesAndroidInjector()
    abstract fun bindLocationMapActivity() : LocationMapActivity

    @ContributesAndroidInjector()
    abstract fun bindMessagesActivity(): MessagesActivity

    @ContributesAndroidInjector()
    abstract fun bindVacationActivity(): VacationActivity

    @ContributesAndroidInjector(modules = [EarlyAccessStatusModule::class])
    abstract fun bindEarlyAccessStatus(): EarlyAccessStatusActivity

    @ContributesAndroidInjector(modules = [FragmentChatModule::class])
    abstract fun bindChatActivity(): ChatActivity

    @ContributesAndroidInjector
    abstract fun bindStagingOrderActivity(): StagingOrderActivity

    @ContributesAndroidInjector(modules = [FragmentDrawerModule::class])
    abstract fun bindHoursActivity(): HoursActivity
}