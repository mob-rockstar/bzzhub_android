package com.app.basketiodriver.ui.messages

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.ChatMessage
import com.app.basketiodriver.databinding.ActivityMessagesBinding
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.chat.ChatViewModel
import com.app.basketiodriver.ui.messages.adapters.MessagesAdapter

class MessagesActivity : BaseActivity<ActivityMessagesBinding?, ChatViewModel>() {


    override val layoutId: Int
        get() = R.layout.activity_messages

    override val viewModel: ChatViewModel
        get() {
            return getViewModel(ChatViewModel::class.java)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)



        initToolbar(
            "Messages",
            true, viewDataBinding!!.toolbarLayout.toolbar,
            View.OnClickListener {
                run {
                    finish()
                }
            })


        val messagesAdapter =
            MessagesAdapter(listOf(
                ChatMessage.getCopy(),
                ChatMessage.getCopy(),
                ChatMessage.getCopy(),
                ChatMessage.getCopy()
            ), object :
                MessagesAdapter.ItemAction {
                override fun clickOnItem() {


                }
            }
            )
        viewDataBinding!!.let {
            it.rvMessages.adapter = messagesAdapter
            it.rvMessages.layoutManager =
                LinearLayoutManager(baseContext, LinearLayoutManager.VERTICAL, false)
        }


    }

    companion object {
        fun newIntent(context: Context?): Intent {
            return Intent(context, MessagesActivity::class.java)
        }
    }
}
