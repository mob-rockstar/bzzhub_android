package com.app.basketiodriver.ui.chat

//import kotlinx.android.synthetic.main.item_order_list.*

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.media.MediaRecorder
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.Log
import android.view.*
import android.view.View.GONE
import android.view.View.VISIBLE
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.widget.doAfterTextChanged
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.chat.*
import com.app.basketiodriver.data.model.api.chat.User.Companion.TYPE_SHOPPER
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.remote.socket.SocketManager
import com.app.basketiodriver.databinding.ActivityChatBinding
import com.app.basketiodriver.databinding.DialogSelectMediaBinding
import com.app.basketiodriver.service.FCMService
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.base.BaseNavigator
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.chat.adapter.ChatMessagesAdapter
import com.app.basketiodriver.ui.media.Image.ImagePicker
import com.app.basketiodriver.ui.media.Utility
import com.app.basketiodriver.ui.media.Video.VideoPicker
import com.app.basketiodriver.utils.AppConstants
import com.app.basketiodriver.utils.FormatterUtils
import com.app.basketiodriver.utils.NotificationUtils
import com.app.basketiodriver.utils.PopupUtils
import com.google.gson.Gson
import com.google.gson.JsonNull
import com.google.gson.reflect.TypeToken
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import io.socket.client.Ack
import io.socket.client.Socket
import org.greenrobot.eventbus.EventBus
import org.json.JSONObject
import timber.log.Timber
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject


class ChatActivity : BaseActivity<ActivityChatBinding?, ChatViewModel>(),
    BaseNavigator, ChatMessagesAdapter.OnItemSelectListener,
    HasAndroidInjector {

    override val layoutId: Int
        get() = R.layout.activity_chat

    override val viewModel: ChatViewModel
        get() {
            return getViewModel(ChatViewModel::class.java)
        }

    // prevent double tapping variables
    private var lastClickTime: Long = 0

    @Inject
    lateinit var socketManager: SocketManager

    private var orderStoreId: Long = 0
    private var orderStatus: Int = 0

    private lateinit var chatMessagesAdapter: ChatMessagesAdapter
    private var chatMessages = ArrayList<com.app.basketiodriver.data.model.api.chat.ChatMessage>()
    private var isShowAttachments = false
    private val MY_PERMISSIONS_REQUEST_STORAGE_PERMISSIONS = 10
    private val MY_PERMISSIONS_REQUEST_STORAGE_PERMISSIONSFORVOICE = 11

    private var continueAfterPermission = 0

    private var tryToCreateRoom = false

    private var isTyping = false
    private var typingRunnable = Runnable { sendTypingStatus(false) }
    lateinit var builder: NotificationCompat.Builder
    private var isOpenRecordPanel = false
    private var audioRecordPath: String? = null
    private var myAudioRecorder: MediaRecorder? = null
    private var isRecording = false
    private var recordStartedTime = 0L
    private val MAX_RECORD_DURATION = 60000
    private val recordingHandler = Handler()
    private var selectedVideoPath: String? = null
    private val SELECT_VIDEO = 1
    private val PICK_IMAGE_REQUEST_CODE = 2
    private val recordingCounterRunnable = object : Runnable {
        override fun run() {
            val timeInMilliseconds = SystemClock.uptimeMillis() - recordStartedTime
            viewDataBinding?.tvRecordDuration?.text = FormatterUtils.formatDuration(
                timeInMilliseconds
            )

            if (timeInMilliseconds > MAX_RECORD_DURATION) {
                stopAudioRecording(true)
            } else {
                recordingHandler.postDelayed(this, 0)
            }
        }
    }

    private var onlineCheckRunnable = Runnable { checkShopperStatus() }

    var customerId = ""
    var customerName = ""
    var userImage = ""

    // Typing handler
    private val typingHandler = Handler()

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    //private var onlineCheckRunnable = Runnable { checkShopperStatus() }

    override fun handleError(error: String) {
        Toast.makeText(this@ChatActivity, error, Toast.LENGTH_SHORT).show()
    }

    override fun handleSuccess(success: String) {
        TODO("Not yet implemented")
    }

    override fun gotToNext() {
        TODO("Not yet implemented")
    }


    private fun sendTypingStatus(typing: Boolean) {
        isTyping = typing
        if (socketManager.isChatSocketConnected()) {
            socketManager.chatSocket?.emit(
                SocketManager.CHAT_EVENT_SEND_TYPING,
                JSONObject().apply {
                    put(SocketManager.CHAT_KEY_ROOM_ID, orderStoreId.toString())
                    put(SocketManager.CHAT_KEY_IS_TYPING, typing)
                }
            )
        } else {
            //    Toast.makeText(baseActivity, "Not connected, Please try again", Toast.LENGTH_SHORT).show()
        }
    }

    var progressView: View? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        extractArguments()

        progressView = viewDataBinding?.progressBar
        builder = NotificationCompat.Builder(this, FCMService.BASKET_CHANNEL_NAME)

        initUI()

        initToolbar()
        initRecyclerView()
        initSocketTokens()
        initChatLayout()

        initSocketEvents()
        //   BasketAnalyticsManager.chatWithShopper(PreferenceManager.currentUserId,0,orderStoreId)
    }

    private fun extractArguments() {
        orderStoreId = intent.getLongExtra("KEY_ORDER_OUTLET_ID", 0L)
        customerId = intent.getStringExtra("KEY_USER_ID") ?: ""
        userImage = intent.getStringExtra("KEY_USER_IMAGE") ?: ""
        customerName = intent.getStringExtra("KEY_USER_NAME") ?: ""

    }

    private fun initRecyclerView() {
        viewDataBinding?.rvChat?.layoutManager = LinearLayoutManager(this)
        viewDataBinding?.rvChat?.setHasFixedSize(true)

        chatMessagesAdapter = ChatMessagesAdapter(chatMessages) { message ->
            if (!message.isReceived && message.by?.type == User.TYPE_CUSTOMER) {
                sendChatReadStatus(message)
            }
        }
        viewDataBinding?.rvChat?.adapter = chatMessagesAdapter
        viewDataBinding?.rvChat?.post {
            viewDataBinding?.rvChat?.scrollToPosition(chatMessages.size - 1)
        }
        chatMessagesAdapter.setListener(this)
    }

    private fun initToolbar() {
        viewDataBinding?.ivBack?.setOnClickListener {
            finish()
        }

        viewDataBinding?.tvUserName?.text = customerName
    }

    private fun initChatLayout() {
        // Select the media
        viewDataBinding?.ivAttachment?.setOnClickListener { setAttachmentEnabled(!isShowAttachments) }

        // Send message
        viewDataBinding?.ivSend?.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime > 1000) {
                lastClickTime = SystemClock.elapsedRealtime()
                sendChatMessage()
            }
        }

        viewDataBinding?.ivCamera?.setOnClickListener {

            if (isStoragePermisssionGranted()){
                openPhotoCamera()
            }else{
                continueAfterPermission =1
                requestStoragePermission()
            }
        }
        viewDataBinding?.ivVideo?.setOnClickListener {
            if(isStoragePermisssionGranted()){
                openVideoCamera()
            }else{
                continueAfterPermission =1
                requestStoragePermission()
            }

        }
        viewDataBinding?.ivVoice?.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime > 1000) {
                lastClickTime = SystemClock.elapsedRealtime()
                toggleRecordLayout(!isOpenRecordPanel)
            }
            true
        }
        viewDataBinding?.ivPhotoGallery?.setOnClickListener {
            if (isStoragePermisssionGranted()){
                openImagePicker()
            }else{
                continueAfterPermission =1
                requestStoragePermission()
            }

        }
        viewDataBinding?.ivVideoGallery?.setOnClickListener {

            if (isStoragePermisssionGranted()){
                openVideoPicker()
            }else{
                continueAfterPermission =1
                requestStoragePermission()
            }
        }

        viewDataBinding?.tvRecordStart?.setOnClickListener {
        if (isStoragePermisssionGrantedForVoice()){
            startAudioRecording()

        }else{
            continueAfterPermission = 1
            requestStoragePermissionForVoice()
        }


        }
        viewDataBinding?.tvRecordSend?.setOnClickListener { stopAudioRecording(true) }
        viewDataBinding?.tvRecordCancel?.setOnClickListener { stopAudioRecording(false) }
    }

    private fun sendChatReadStatus(chatMessage: ChatMessage) {
        Timber.tag("ChatMessageId").d(
            chatMessage.id
                .toString()
        )
        if (socketManager.isChatSocketConnected()) {
            socketManager.chatSocket?.emit(
                SocketManager.CHAT_EVENT_SEND_READ,
                JSONObject().apply {
                    put(SocketManager.CHAT_KEY_ROOM_ID, orderStoreId.toString())
                    put(SocketManager.CHAT_KEY_MESSAGE_ID, chatMessage.id)
                }
            )
        } else {
            //     Toast.makeText(baseActivity, "Not connected, Please try again", Toast.LENGTH_SHORT).show()
        }
    }


    private fun initUI() {
        viewDataBinding?.ivSend?.visibility = View.GONE
        viewDataBinding?.composerMask?.visibility = View.GONE
        setAttachmentEnabled(false)
        viewDataBinding?.layoutUpload?.visibility = View.GONE
        toggleRecordLayout(false)
        viewDataBinding?.tvRecordDuration?.text = FormatterUtils.formatDuration(0L)

        viewDataBinding?.etComposer?.doAfterTextChanged {
            viewDataBinding?.ivSend?.apply {
                val hasText = it!!.isNotEmpty()
                visibility = if (hasText) View.VISIBLE else View.GONE
                viewDataBinding?.ivVoice?.visibility = if (hasText) View.GONE else View.VISIBLE
                viewDataBinding?.ivAttachment?.visibility = if (hasText) View.GONE else View.VISIBLE
                if (!isTyping) {
                    sendTypingStatus(true)
                }

                typingHandler.removeCallbacks(typingRunnable)
                typingHandler.postDelayed(typingRunnable, 1500)
            }
        }

        viewDataBinding?.etComposer?.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                setAttachmentEnabled(false)
                toggleRecordLayout(false)
            }
        }
        viewDataBinding?.etComposer?.isEnabled = true
        viewDataBinding?.layoutDisabledChat?.visibility = View.GONE
        if (orderStatus == 13) {
            viewDataBinding?.etComposer?.isEnabled = false
            //    viewDataBinding?.etComposer?.setText(R.string.str_chat_disabled)
            viewDataBinding?.layoutDisabledChat?.visibility = View.VISIBLE
            viewDataBinding?.layoutChat?.visibility = GONE
        }
    }

    /**
     * Clicked the Plus icon to select the media
     */
    private fun setAttachmentEnabled(enabled: Boolean) {
        isShowAttachments = enabled
        //        viewDataBinding?.layoutAttachment?.visibility =
        //            if (isShowAttachments) View.VISIBLE else View.GONE
        //        viewDataBinding?.ivAttachment?.setImageResource(if (isShowAttachments) R.drawable.ic_minus else R.drawable.ic_plus)

        if (isShowAttachments) {
            // Dismiss the keyboard
            viewDataBinding?.etComposer?.clearFocus()

            showSelectMediaDialog()

            toggleRecordLayout(false)
        }
    }

    fun setIsLoading(isLoading: Boolean) {
        progressView?.visibility = if (isLoading) VISIBLE else GONE
    }

    private fun toggleRecordLayout(enabled: Boolean) {
        isOpenRecordPanel = enabled
        if (isOpenRecordPanel) {
            viewDataBinding?.layoutRecordPanel?.visibility = View.VISIBLE
            viewDataBinding?.ivVoice?.setColorFilter(resources.getColor(R.color.green_color))
            toggleRecordButtons(false)

            viewDataBinding?.etComposer?.clearFocus()
            setAttachmentEnabled(false)
        } else {
            viewDataBinding?.layoutRecordPanel?.visibility = View.GONE
            viewDataBinding?.ivVoice?.setColorFilter(resources.getColor(R.color.green_color))
        }
    }

    private fun toggleRecordButtons(recording: Boolean) {
        if (recording) {
            viewDataBinding?.tvRecordCancel?.visibility = View.VISIBLE
            viewDataBinding?.tvRecordSend?.visibility = View.VISIBLE
            viewDataBinding?.tvRecordStart?.visibility = View.GONE
        } else {
            viewDataBinding?.tvRecordCancel?.visibility = View.GONE
            viewDataBinding?.tvRecordSend?.visibility = View.GONE
            viewDataBinding?.tvRecordStart?.visibility = View.VISIBLE
        }
    }

    // Mayank
    private fun openPhotoCamera() {
        if (SystemClock.elapsedRealtime() - lastClickTime > 1000) {
            lastClickTime = SystemClock.elapsedRealtime()
            // check camera and write_external_storage permissions

            ImagePicker.Builder(this@ChatActivity)
                .mode(ImagePicker.Mode.CAMERA)
                .compressLevel(ImagePicker.ComperesLevel.MEDIUM)
                .directory(ImagePicker.Directory.DEFAULT)
                .extension(ImagePicker.Extension.JPG)
                .scale(600, 600)
                .allowMultipleImages(false)
                .enableDebuggingMode(true)
                .build()

        }
    }

//    mayank
    private fun openVideoCamera() {
        if (SystemClock.elapsedRealtime() - lastClickTime > 1000) {
            lastClickTime = SystemClock.elapsedRealtime()

            val i = Intent(MediaStore.ACTION_VIDEO_CAPTURE)
            startActivityForResult(i, VideoPicker.RECORD_VIDEO)

//            VideoPicker.Builder(this@ChatActivity)
//                .mode(VideoPicker.Mode.CAMERA)
//                .directory(VideoPicker.Directory.DEFAULT)
//                .extension(VideoPicker.Extension.MP4)
//                .enableDebuggingMode(true)
//                .build()

        }
    }

    private fun openImagePicker() {
        if (SystemClock.elapsedRealtime() - lastClickTime > 1000) {
            lastClickTime = SystemClock.elapsedRealtime()

            ImagePicker.Builder(this@ChatActivity)
                .mode(ImagePicker.Mode.GALLERY)
                .compressLevel(ImagePicker.ComperesLevel.MEDIUM)
                .directory(ImagePicker.Directory.DEFAULT)
                .extension(ImagePicker.Extension.JPG)
                .scale(600, 600)
                .allowMultipleImages(false)
                .enableDebuggingMode(true)
                .build()

//            com.github.dhaval2404.imagepicker.ImagePicker.with(this)
//                .cameraOnly()
//                .compress(1024)
//                .maxResultSize(1080, 1080)
//                .start(PICK_IMAGE_REQUEST_CODE)



        }
    }

    @SuppressLint("CheckResult")
    private fun openVideoPicker() {
        if (SystemClock.elapsedRealtime() - lastClickTime > 1000) {
            lastClickTime = SystemClock.elapsedRealtime()
//            VideoPicker.Builder(this@ChatActivity)
//                .mode(VideoPicker.Mode.GALLERY)
//                .directory(VideoPicker.Directory.DEFAULT)
//                .extension(VideoPicker.Extension.MP4)
//                .enableDebuggingMode(true)
//                .build()

            val i = Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(i, SELECT_VIDEO)
        }
    }

    private fun initializeAudioPlayer() {
        audioRecordPath = "${Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)}/mediapicker/audios/${System.currentTimeMillis()}.mp3"
        myAudioRecorder = MediaRecorder()

        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.N) {
            myAudioRecorder?.setAudioSource(MediaRecorder.AudioSource.MIC)
            myAudioRecorder?.setOutputFormat(MediaRecorder.OutputFormat.AAC_ADTS)
            myAudioRecorder?.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
        } else {
            myAudioRecorder?.setAudioSource(MediaRecorder.AudioSource.MIC)
            myAudioRecorder?.setOutputFormat(MediaRecorder.OutputFormat.DEFAULT)
            myAudioRecorder?.setAudioEncoder(MediaRecorder.AudioEncoder.DEFAULT)
        }
        myAudioRecorder?.setOutputFile(audioRecordPath)
    }

    private fun startAudioRecording() {
        // create directory if not exist
        Utility.createFolderAudio(this,"/mediapicker/audios/")

        if (myAudioRecorder == null) {
            initializeAudioPlayer()
        }


        try {
            myAudioRecorder?.prepare()
            myAudioRecorder?.start()
            isRecording = true
            recordStartedTime = SystemClock.uptimeMillis()
            recordingHandler.postDelayed(recordingCounterRunnable, 0)
            toggleRecordButtons(true)

            viewDataBinding?.composerMask?.visibility = View.VISIBLE
        } catch (ex: Exception) {
            ex.printStackTrace()
            myAudioRecorder = null
        }
    }

    private fun stopAudioRecording(withUpload: Boolean) {
        if (myAudioRecorder != null) {
            try {
                myAudioRecorder?.stop()
                myAudioRecorder?.release()
                myAudioRecorder = null
                if (withUpload){
                    uploadAttachment(audioRecordPath!!, SocketManager.CHAT_MESSAGE_TYPE_VOICE)

                    Log.d("TAG", "stopAudioRecording: uploadAttachment")
                }

            } catch (ex: java.lang.Exception) {
                ex.printStackTrace()
                myAudioRecorder = null
            }
            recordingHandler.removeCallbacks(recordingCounterRunnable)
            toggleRecordButtons(false)
            viewDataBinding?.tvRecordDuration?.text = FormatterUtils.formatDuration(0L)
            viewDataBinding?.composerMask?.visibility = View.GONE
            toggleRecordLayout(false)
            isRecording = false
        }
    }

    @SuppressLint("StringFormatInvalid")
    private fun uploadAttachment(path: String, type: String) {

        val file = File(path)
        val fileSize = file.length() / (1024 * 1024) // get file size in MB
        // check file size
        if (fileSize > 50) {
            return this@ChatActivity.handleError(this@ChatActivity.getString(R.string.file_size_limitation))
        }
        viewDataBinding?.layoutUpload?.visibility = View.VISIBLE
        viewDataBinding?.tvUploading?.text = getString(
            R.string.uploading_attachment,
            when (type) {
                SocketManager.CHAT_MESSAGE_TYPE_VIDEO -> getString(R.string.str_video)
                SocketManager.CHAT_MESSAGE_TYPE_VOICE -> getString(R.string.str_voice)
                else -> getString(R.string.str_image)
            }
        )
        viewModel.uploadChatAttachment(
            file,
            type,
            orderStoreId.toInt(),
            TYPE_SHOPPER,
            PreferenceManager.currentShopperId!!,
            object :
                HandleResponse<BaseResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    viewDataBinding?.layoutUpload?.visibility = View.GONE
                    if (isNetworkConnected) {
                        this@ChatActivity.handleError(error?.message ?: "Failed to get Data")
                    } else {
                        this@ChatActivity.handleError(
                            resources?.getString(R.string.no_internet_conn_msg_txt) ?: ""
                        )
                    }
                }

                override fun handleSuccessResponse(successResponse: BaseResponse) {
                    viewDataBinding?.layoutUpload?.visibility = View.GONE

                    if (!successResponse.error && successResponse.payload !is JsonNull) {
                        // success to upload
                    } else {
                        this@ChatActivity.handleError(
                            successResponse.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    }
                }
            })
    }

    private fun initSocketTokens() {
        //        getActiveTokenList()
    }

    /*    fun getActiveTokenList() {
            viewModel.getTokenList(object : HandleResponse<ActiveDeviceTokenResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (isNetworkConnected) {
                        this@ChatActivity.handleError(error?.message ?: "Failed to get Data")
                    } else {
                        this@ChatActivity.handleError(
                            resources?.getString(R.string.no_internet_conn_msg_txt) ?: ""
                        )
                    }
                }

                override fun handleSuccessResponse(successResponse: ActiveDeviceTokenResponse) {
                    if (successResponse.status == 200) {
                        PreferenceManager.userChatToken = String(
                            android.util.Base64.encode(
                                Gson().toJson(
                                    successResponse.data
                                ).toByteArray(), android.util.Base64.DEFAULT
                            )
                        )
                        getSocketToken()
                    }
                }
            })
        }

        fun getSocketToken() {
            viewModel.getSocketToken(object : HandleResponse<SocketTokenResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (isNetworkConnected) {
                        this@ChatActivity.handleError(error?.message ?: "Failed to get Data")
                    } else {
                        this@ChatActivity.handleError(
                            resources?.getString(R.string.no_internet_conn_msg_txt) ?: ""
                        )
                    }
                }

                override fun handleSuccessResponse(successResponse: SocketTokenResponse) {
                    if (successResponse.status == 200) {
                        PreferenceManager.socketToken = successResponse.data?.serviceToken
                   //     socketManager.init()
                        Timber.tag("JoinRoomError").d("initSocket")
                        initSocketEvents()
                    }
                }
            })
        }*/

    // socket functions
    @SuppressLint("NotifyDataSetChanged")
    private fun initSocketEvents() {
        Timber.tag("JoinRoomError").d("showLoading")
        showLoading()


        if (socketManager.chatSocket != null) {
            if (socketManager.chatSocket!!.connected()){
                Timber.tag("JoinRoomError").e("Joining to Room...")
                joinRoom()
            }

            socketManager.chatSocket!!.run {
                Timber.tag("JoinRoomError").d("RunChatSocket")
                //    joinRoom()

                if (!socketManager.chatSocket!!.connected()){
                    on(Socket.EVENT_CONNECT) {
                        Timber.tag("JoinRoomError").d("EventConnect")
                        joinRoom()
                    }
                }

                // Receive message event
                on(SocketManager.CHAT_EVENT_RECEIVE_MESSAGE) {
                    val baseResponseType = object : TypeToken<BaseResponse>() {}.type
                    val response = Gson().fromJson<BaseResponse>(
                        it.first() as String,
                        baseResponseType
                    )

                    val data = it.first() as String
                    Timber.tag("ChatActivity").d("Received the chat messages;")
                    Timber.tag("ChatActivity").d(data)

                    if (!response.error) {
                        val type = object :
                            TypeToken<com.app.basketiodriver.data.model.api.chat.ChatMessage>() {}.type
                        val chatMessage =
                            Gson().fromJson<com.app.basketiodriver.data.model.api.chat.ChatMessage>(
                                response.payload,
                                type
                            )
                        if (chatMessage.send_at == null) {
                            // currently socket server isn't work for send_at field
                            val formatter = SimpleDateFormat(
                                "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
                                Locale.getDefault()
                            )
                            formatter.timeZone = TimeZone.getTimeZone("UTC")
                            chatMessage.send_at = formatter.format(Date())
                        }
                        if (!chatMessage.isReceived && chatMessage.by?.type == User.TYPE_CUSTOMER) {
                            sendChatReceivedStatus(chatMessage)
                        }
                        if (chatMessage.orderId?.toLong() != orderStoreId) {
                            var pendingIntent = Intent(this@ChatActivity, ChatActivity::class.java)
                            var newOrderStoreId  = chatMessage.orderId?.toLong()
                            pendingIntent.putExtra("KEY_ORDER_OUTLET_ID", chatMessage.orderId?.toLong())
                            pendingIntent.putExtra("KEY_USER_ID", chatMessage.by?.id)
                            pendingIntent.putExtra("KEY_USER_NAME", chatMessage.by?.userName ?: "")
                            pendingIntent.putExtra("KEY_USER_IMAGE", chatMessage.by?.image ?: "")
                            pendingIntent.flags = (Intent.FLAG_ACTIVITY_CLEAR_TOP
                                    or Intent.FLAG_ACTIVITY_CLEAR_TASK
                                    or Intent.FLAG_ACTIVITY_NEW_TASK)
                            val contentIntent: PendingIntent =
                                PendingIntent.getActivity(
                                    this@ChatActivity,
                                    0,
                                    pendingIntent,
                                    PendingIntent.FLAG_IMMUTABLE
                                )
                            try {
                                NotificationUtils.displaySimpleNotification(
                                    builder, this@ChatActivity.applicationContext,
                                    if (chatMessage.type == SocketManager.CHAT_MESSAGE_TYPE_IMAGE ||
                                        chatMessage.type == SocketManager.CHAT_MESSAGE_TYPE_VIDEO ||
                                        chatMessage.type == SocketManager.CHAT_MESSAGE_TYPE_VOICE
                                    ) chatMessage.type else chatMessage.content!!,
                                    "Basket", contentIntent
                                )
                            } catch (e: Exception) {
                            }
                        } else {
                            this@ChatActivity.runOnUiThread {
                                addMessageToList(chatMessage)
                            }
                        }
                    }
                }

                // Message received status event
                on(SocketManager.CHAT_EVENT_STATUS_RECEIVED) {
                    val baseResponseType = object : TypeToken<BaseResponse>() {}.type
                    val response = Gson().fromJson<BaseResponse>(
                        it.first() as String,
                        baseResponseType
                    )
                    if (!response.error) {
                        val type = object : TypeToken<StatusMessage>() {}.type
                        val message = Gson().fromJson<StatusMessage>(response.payload, type)
                        this@ChatActivity?.runOnUiThread {
                            for (chatMessage in chatMessages) {
                                if (chatMessage.id == message.id) {
                                    chatMessage.isReceived = true
                                }
                            }
                            chatMessagesAdapter.notifyDataSetChanged()
                        }
                    }
                }

                // Message read status event
                on(SocketManager.CHAT_EVENT_STATUS_READ) {
                    val baseResponseType = object : TypeToken<BaseResponse>() {}.type
                    val response = Gson().fromJson<BaseResponse>(
                        it.first() as String,
                        baseResponseType
                    )
                    if (!response.error) {
                        val type = object : TypeToken<StatusMessage>() {}.type
                        val message = Gson().fromJson<StatusMessage>(response.payload, type)
                        this@ChatActivity?.runOnUiThread {
                            for (chatMessage in chatMessages) {
                                if (chatMessage.id == message.id) {
                                    chatMessage.isRead = true
                                }
                            }
                            chatMessagesAdapter.notifyDataSetChanged()
                        }
                    }
                }

                // User typing status event
                on(SocketManager.CHAT_EVENT_STATUS_TYPING) {
                    val baseResponseType = object : TypeToken<BaseResponse>() {}.type
                    val response = Gson().fromJson<BaseResponse>(
                        it.first() as String,
                        baseResponseType
                    )
                    if (!response.error) {
                        val type = object : TypeToken<StatusMessage>() {}.type
                        val message = Gson().fromJson<StatusMessage>(response.payload, type)
                        if (message.user?.id != PreferenceManager.currentShopperId.toString()) {
                            this@ChatActivity?.runOnUiThread {
                                chatMessagesAdapter.setTypingStatus(message.isTyping)
                            }
                        }
                    }
                }
            }

            if (!socketManager.chatSocket!!.connected()){
                Timber.tag("JoinRoomError").e("Connecting the chat socket...")
                socketManager.chatSocket!!.connect()
            }
            //    socketManager.chatSocket!!.connect()
        }
        else{
            Timber.tag("JoinRoomError").e("Chat socket is null...")
        }
    }

    private fun sendChatReceivedStatus(chatMessage: ChatMessage) {
        if (socketManager.isChatSocketConnected()) {
            socketManager.chatSocket?.emit(
                SocketManager.CHAT_EVENT_SEND_RECEIVED,
                JSONObject().apply {
                    put(SocketManager.CHAT_KEY_ROOM_ID, orderStoreId.toString())
                    put(SocketManager.CHAT_KEY_MESSAGE_ID, chatMessage.id)
                }
            )
        } else {
            //    Toast.makeText(baseActivity, "Not connected, Please try again", Toast.LENGTH_SHORT).show()
        }
    }

    private fun removeSocketEvents() {
        leaveRoom()
        socketManager.chatSocket?.apply {
            off(Socket.EVENT_CONNECT)
            off(SocketManager.CHAT_EVENT_RECEIVE_MESSAGE)
            off(SocketManager.CHAT_EVENT_STATUS_RECEIVED)
            off(SocketManager.CHAT_EVENT_CHECK_ONLINE_STATUS)
            off(SocketManager.CHAT_EVENT_STATUS_READ)
            off(SocketManager.CHAT_EVENT_STATUS_TYPING)
        }
    }

    private fun leaveRoom() {
        socketManager.chatSocket?.emit(
            SocketManager.CHAT_EVENT_LEAVE_ROOM,
            JSONObject().apply {
                put(SocketManager.CHAT_KEY_ROOM_ID, orderStoreId.toString())
            },
            Ack {
                val baseResponseType = object : TypeToken<BaseResponse>() {}.type
                val response = Gson().fromJson<BaseResponse>(it.first() as String, baseResponseType)
                if (response.error) Timber.tag("ChatMessage_leaveRoom").v(response.message)

                socketManager.chatSocket?.disconnect()
            }
        )
    }

    private fun createRoom() {
        tryToCreateRoom = true
        socketManager.chatSocket?.emit(
            SocketManager.CHAT_EVENT_CREATE_ROOM,
            JSONObject().apply {
                put(SocketManager.CHAT_KEY_ROOM_ID, orderStoreId.toString())
            },

            Ack {
                val baseResponseType = object : TypeToken<BaseResponse>() {}.type
                val response = Gson().fromJson<BaseResponse>(it.first() as String, baseResponseType)

                if (!response.error) {
                    // try to join room again
                    joinRoom()
                } else {

                    // can't create room, close chat page
                    finish()
                }
            }
        )
    }

    private fun joinRoom() {
        Timber.tag("JoinRoomError").d("JoiningRoom")
        Timber.tag("JoinRoomError").d(orderStoreId.toString())
        socketManager.chatSocket?.emit(
            SocketManager.CHAT_EVENT_JOIN_ROOM,
            JSONObject().apply {
                put(SocketManager.CHAT_KEY_ROOM_ID, orderStoreId.toString())
            },
            Ack {
                val baseResponseType = object : TypeToken<BaseResponse>() {}.type
                val response = Gson().fromJson<BaseResponse>(it.first() as String, baseResponseType)
                Timber.tag("JoinRoomError").d(response.message)
                if (!response.error) {
                    checkShopperStatus()
                    getChatHistory()
                } else {
                    // can't join room, try to create room once
                    if (!tryToCreateRoom) {
                        createRoom()
                    } else {
                        finish()
                    }
                }
            }
        )
    }

    private fun checkShopperStatus() {
        socketManager.chatSocket?.emit(
            SocketManager.CHAT_EVENT_CHECK_ONLINE_STATUS,
            JSONObject().apply {
                put(SocketManager.CHAT_KEY_USER_ID, customerId)
                put(SocketManager.CHAT_KEY_USER_TYPE, "customer")
            },
            Ack {
                val baseResponseType = object : TypeToken<BaseResponse>() {}.type
                val response = Gson().fromJson<BaseResponse>(it.first() as String, baseResponseType)

                if (!response.error && response.payload !is JsonNull) {
                    val type = object : TypeToken<UserStatusResponse>() {}.type
                    val data = Gson().fromJson<UserStatusResponse>(response.payload, type)
                    val isShopperOnline = data.is_online == "true"
                    this@ChatActivity?.runOnUiThread {
                        viewDataBinding?.tvShopperStatus?.visibility =
                            if (isShopperOnline) View.VISIBLE else View.GONE
                    }
                }
            }
        )
        recordingHandler.postDelayed(onlineCheckRunnable, 1500)
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun getChatHistory() {
        socketManager.chatSocket?.emit(
            SocketManager.CHAT_EVENT_GET_HISTORY,
            JSONObject().apply {
                put(SocketManager.CHAT_KEY_ROOM_ID, orderStoreId.toString())
            },
            Ack {
                val baseResponseType = object : TypeToken<BaseResponse>() {}.type
                val response = Gson().fromJson<BaseResponse>(it.first() as String, baseResponseType)

                val data = it.first() as String
                Timber.tag("ChatActivity").d("Received the chat history")
                Timber.tag("ChatActivity").d(data)

                if (!response.error && response.payload !is JsonNull) {
                    Timber.tag("ChatActivity").d("Chat history is not null.")

                    val type = object : TypeToken<FetchHistoryResponse>() {}.type
                    val data = Gson().fromJson<FetchHistoryResponse>(response.payload, type)
                    //                    chatMessages.clear()

                    val chatList = arrayListOf<ChatMessage>()

                    if (data.history != null) {
                        for (message in data.history!!) {
                            val chatMessage = ChatMessage.fromHistoryMessage(message)
                            chatList.add(chatMessage)
                        }
                    }

                    chatMessages = chatList
                    checkMessageStatus()

                    this@ChatActivity?.runOnUiThread {
                        if (!this.isFinishing)
                            hideLoading()

                        // Refresh the chat list
                        chatMessagesAdapter.setMessageHistory(chatMessages)
                        chatMessagesAdapter.notifyDataSetChanged()
                        viewDataBinding?.rvChat?.post {
                            viewDataBinding?.rvChat?.scrollToPosition(chatMessages.size - 1)
                        }
                    }
                }
                else{
                    Timber.tag("ChatActivity").e("Chat history is null.")
                }
            }
        )
    }


    private fun checkMessageStatus() {
        for (chatMessage in chatMessages) {
            if (!chatMessage.isReceived && chatMessage.by?.type == User.TYPE_CUSTOMER) {
                sendChatReceivedStatus(chatMessage)
            }
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun addMessageToList(chatMessage: ChatMessage) {
        var isMessageDuplicated = false
        if (chatMessages != null && chatMessages.isNotEmpty()) {
            for (i in chatMessages) {
                if (i.id == chatMessage.id) isMessageDuplicated = true
            }
        }
        Timber.tag("ChatActivity").d(chatMessage.content)
        if (!isMessageDuplicated) {
            Timber.tag("ChatActivity").d("Chat message is not duplicated")
            chatMessages.add(chatMessage)
        }
        else{
            Timber.tag("ChatActivity").d("Chat message is duplicated")
        }
        chatMessagesAdapter.notifyDataSetChanged()
        viewDataBinding?.rvChat?.post {
            Timber.tag("ChatActivity").d("Scrolling to last chat message position...")
            viewDataBinding?.rvChat?.scrollToPosition(chatMessages.size - 1)
        }
    }

    private fun sendChatMessage() {
        if (socketManager.isChatSocketConnected()) {
            val chatMessage = buildChatMessage(viewDataBinding?.etComposer?.text.toString().trim())
            Timber.tag("ChatFragment").v("Chat Message Sent: $chatMessage")
            if (viewDataBinding?.etComposer?.text.toString().trim().isNotEmpty()) {
                socketManager.chatSocket?.emit(SocketManager.CHAT_EVENT_SEND_MESSAGE, chatMessage)
                viewDataBinding?.etComposer?.setText("")
                Timber.tag("ChatMessage").v(chatMessage.toString())
            }
        } else {
            Toast.makeText(this@ChatActivity, "Not connected, Please try again", Toast.LENGTH_SHORT)
                .show()
        }
    }

    private fun buildChatMessage(message: String): JSONObject {
        return JSONObject().apply {
            put(SocketManager.CHAT_KEY_ROOM_ID, orderStoreId.toString())
            put(SocketManager.CHAT_KEY_MESSAGE_TYPE, SocketManager.CHAT_MESSAGE_TYPE_TEXT)
            put(SocketManager.CHAT_KEY_MESSAGE_CONTENT, message)
        }
    }

    /**
     * Show the Select Media Dialog
     */
    private fun showSelectMediaDialog(){
        try {
            val dialog = Dialog(this)
            val binding: DialogSelectMediaBinding = DataBindingUtil.inflate(LayoutInflater.from(this), R.layout.dialog_select_media,null,false)

            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setContentView(binding.root)
            dialog.setCancelable(false)
            dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window?.setGravity(Gravity.CENTER)
            dialog.setOnKeyListener { it, keyCode, event -> // Prevent dialog close on back press button
                keyCode == KeyEvent.KEYCODE_BACK
            }

            // Cancel
            binding.ivClose.setOnClickListener {
                dialog.dismiss()
            }

            // Import photo
            binding.importPhoto.setOnClickListener {
                dialog.dismiss()

                if (isStoragePermisssionGranted()){
                    Log.d("TAG", "showSelectMediaDialog: ")
                    openImagePicker()
                }else{
                    continueAfterPermission =1
                    requestStoragePermission()
                }
            }

            // Import video
            binding.importVideo.setOnClickListener {
                dialog.dismiss()
                if (isStoragePermisssionGranted()){
                    openVideoPicker()
                }else{
                    continueAfterPermission =1
                    requestStoragePermission()
                }

            }

            // Record video
            binding.recordVideo.setOnClickListener {
                dialog.dismiss()

                if(isStoragePermisssionGranted()){
                    openVideoCamera()
                }else{
                    continueAfterPermission =1
                    requestStoragePermission()
                }
            }

            PopupUtils.setDefaultDialogProperty(dialog)
            dialog.show()
        }
        catch (e : Exception) {
            e.printStackTrace()
        }
    }

    override fun onImageSelected(url: String) {
        if (SystemClock.elapsedRealtime() - lastClickTime > 1000) {
            lastClickTime = SystemClock.elapsedRealtime()
            val dialog = FullImageFragment.newInstance(
                url
            )
            dialog.show(this@ChatActivity.supportFragmentManager, FullImageFragment.javaClass.name)
        }
    }

    override fun onVideoSelected(url: String) {
        if (SystemClock.elapsedRealtime() - lastClickTime > 1000) {
            lastClickTime = SystemClock.elapsedRealtime()
            val dialog = FullScreenVideoPreviewFragment.newInstance(
                url
            )
            dialog.show(
                this@ChatActivity.supportFragmentManager,
                FullScreenVideoPreviewFragment.javaClass.name
            )
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == PICK_IMAGE_REQUEST_CODE){
                Log.d("TAG", "FromImportPhoto: ")

                if(data?.data == null){
                    return
                }else{
                    val uri: Uri = data?.data!!
                    uploadAttachment(uri.path.toString(), SocketManager.CHAT_MESSAGE_TYPE_IMAGE)
                }

            }
        } else if (resultCode == com.github.dhaval2404.imagepicker.ImagePicker.RESULT_ERROR) {
            Toast.makeText(this, com.github.dhaval2404.imagepicker.ImagePicker.getError(data), Toast.LENGTH_SHORT).show()
        }

        if (requestCode === SELECT_VIDEO) {
            if(data?.data != null){
                selectedVideoPath = getPath(data?.data)
            }

            try {
                if (selectedVideoPath != null) {
                    uploadAttachment(selectedVideoPath.toString(), SocketManager.CHAT_MESSAGE_TYPE_VIDEO)
                }
            } catch (e: IOException) {
                //#debug
                e.printStackTrace()
            }
        }

        if (resultCode == Activity.RESULT_OK && requestCode== ImagePicker.IMAGE_PICKER_REQUEST_CODE  ) {
            val mPaths = data?.getStringArrayListExtra(ImagePicker.EXTRA_IMAGE_PATH)
            val path = mPaths?.get(0)
            Log.d("TAG", "onActivityResult: IMAGE_PICKER_REQUEST_CODE"+path)
            if (path != null)
                uploadAttachment(path, SocketManager.CHAT_MESSAGE_TYPE_IMAGE)
        }
        if (requestCode == VideoPicker.RECORD_VIDEO && resultCode == RESULT_OK) {
            // Video recording was successful, you can handle the recorded video here
//            val videoUri = data?.data
            selectedVideoPath = getPath(data?.data)
            uploadAttachment(selectedVideoPath.toString(), SocketManager.CHAT_MESSAGE_TYPE_VIDEO)
            Log.d("TAG", "onActivityResult: "+"VIDEO_PICKER_REQUEST_CODE"+selectedVideoPath.toString())
            // Do something with the videoUri
        }
        /*if (resultCode == Activity.RESULT_OK && requestCode==  VideoPicker.VIDEO_PICKER_REQUEST_CODE  ) {
            val mPaths = data?.getStringArrayListExtra(VideoPicker.EXTRA_VIDEO_PATH)
            val path = mPaths?.get(0)
            Log.d("TAG", "onActivityResult: "+"VIDEO_PICKER_REQUEST_CODE"+path.toString())
            if (path != null)
            uploadAttachment(path.toString(), SocketManager.CHAT_MESSAGE_TYPE_VIDEO)
        }
*/
    }


    override fun onDestroy() {
        // Dismiss the loading dialog
        hideLoading()

        removeSocketEvents()

        // Remove the callbacks
        typingHandler.removeCallbacks(typingRunnable)
        recordingHandler.removeCallbacks(onlineCheckRunnable)

        viewDataBinding?.rvChat?.adapter = null
        AppConstants.IS_CHAT_RUNNING = false

        // Unregister Event bus Receiver
        EventBus.getDefault().unregister(this)

        super.onDestroy()
    }

    override fun onBackPressed() {
        finish()
    }


    private fun requestStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permissions = arrayOf(
                Manifest.permission.READ_MEDIA_AUDIO,
                Manifest.permission.CAMERA,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE
            )
            ActivityCompat.requestPermissions(
                this,
                permissions,
                MY_PERMISSIONS_REQUEST_STORAGE_PERMISSIONS
            )
        } else {
            val permissions = arrayOf(
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE
            )
            ActivityCompat.requestPermissions(
                this,
                permissions,
                MY_PERMISSIONS_REQUEST_STORAGE_PERMISSIONS
            )
        }
    }

    private fun isStoragePermisssionGranted(): Boolean {
        var granted = false
        granted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED &&
                    checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
                    checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED &&
                    checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
                        checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
        }
        return granted
    }

    private fun requestStoragePermissionForVoice() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permissions = arrayOf(
                Manifest.permission.READ_MEDIA_AUDIO,
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE
            )
            ActivityCompat.requestPermissions(
                this,
                permissions,
                MY_PERMISSIONS_REQUEST_STORAGE_PERMISSIONSFORVOICE
            )
        } else {
            val permissions = arrayOf(
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_EXTERNAL_STORAGE
            )
            ActivityCompat.requestPermissions(
                this,
                permissions,
                MY_PERMISSIONS_REQUEST_STORAGE_PERMISSIONSFORVOICE
            )
        }
    }

    private fun isStoragePermisssionGrantedForVoice(): Boolean {
        var granted = false
        granted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                    &&  checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
                    checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
                        checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
                        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
        }
        return granted
    }

    private fun getPath(uri: Uri?): String? {
        val projection = arrayOf(MediaStore.Images.Media.DATA)
        val cursor: Cursor? = contentResolver.query(uri!!, projection, null, null, null)
        if (cursor != null) {
            val column_index: Int = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
            cursor.moveToFirst()
            return cursor.getString(column_index)
        } else return null
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == MY_PERMISSIONS_REQUEST_STORAGE_PERMISSIONSFORVOICE ){
            startAudioRecording()
        }
    }
}
