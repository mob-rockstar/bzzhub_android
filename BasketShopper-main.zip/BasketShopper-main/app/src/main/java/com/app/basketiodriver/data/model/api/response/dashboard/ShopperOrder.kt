package com.app.basketiodriver.data.model.api.response.dashboard

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class ShopperOrder {
    @SerializedName("overall_total_amount")
    @Expose
    val overallTotal: Double? = null

    @SerializedName("user_image")
    @Expose
    val userImage: String? = null

    @SerializedName("order_status")
    @Expose
    val orderStatus: Int? = null

    @SerializedName("order_outlet_id")
    @Expose
    val orderOutletId: Long? = null

    @SerializedName("outlet_id")
    @Expose
    val outletId: Long? = null

    @SerializedName("order_id")
    @Expose
    val orderId: Long? = null

    @SerializedName("delivery_instructions")
    @Expose
    val deliveryInstructions: String? = null


    @SerializedName("outlet_name")
    @Expose
    val outletName: String? = null

    @SerializedName("outlet_latitude")
    @Expose
    val outletLatitude: Double? = null

    @SerializedName("outlet_longitude")
    @Expose
    val outletLongitude: Double? = null

    @SerializedName("outlet_google_address")
    @Expose
    val outletContactAddress: String? = null

    @SerializedName("arrived_at_store_distance_config")
    @Expose
    val arrivedAtStoreDistanceConfig: Double? = null

    @SerializedName("user_latitude")
    @Expose
    val userLatitude: Double? = null

    @SerializedName("user_longitude")
    @Expose
    val userLongitude: Double? = null

    @SerializedName("user_google_address")
    @Expose
    val userAddress: String? = null

    @SerializedName("user_address_type")
    @Expose
    val userAddressType: String? = null

    @SerializedName("delivery_slot")
    @Expose
    val deliverySlot: String? = null

    @SerializedName("delivery_date")
    @Expose
    val deliveryDate: String? = null

    @SerializedName("vendor_id")
    @Expose
    val vendorId: Long? = null

    @SerializedName("logo_image")
    @Expose
    val logoImage: String? = null

    @SerializedName("shopper_first_name")
    @Expose
    val shopperFirstName: String = ""

    @SerializedName("shopper_last_name")
    @Expose
    val shopperLastName: String = ""

    @SerializedName("assigned_time")
    @Expose
    val assignedTime: String? = null

    @SerializedName("shopper_type")
    @Expose
    val shopperType: Long? = null

    @SerializedName("shopper_image")
    @Expose
    val shopperImage: String? = null

    @SerializedName("user_id")
    @Expose
    val userId: Long? = null

    @SerializedName("user_first_name")
    @Expose
    val userFirstName: String = ""

    @SerializedName("user_last_name")
    @Expose
    val userLastName: String = ""

    @SerializedName("user_mobile")
    @Expose
    val userMobile: String? = null

    @SerializedName("call_before_checkout")
    @Expose
    val callBeforeCheckout = 0

    @SerializedName("total_items_count")
    @Expose
    val itemCount: Int? = null

    @SerializedName("user_city")
    @Expose
    val userCity: String? = null

    @SerializedName("user_location")
    @Expose
    val userLocation: String? = null

    @SerializedName("user_department_building")
    @Expose
    val department: String? = null

    @SerializedName("user_additional_info")
    @Expose
    val info: String? = null

    @SerializedName("user_near_landmark")
    @Expose
    val landmark: String? = null

    @SerializedName("is_express")
    @Expose
    val isExpress: Int = 0
}