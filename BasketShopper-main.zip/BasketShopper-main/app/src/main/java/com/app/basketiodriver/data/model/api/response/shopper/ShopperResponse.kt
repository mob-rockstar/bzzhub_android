package com.app.basketiodriver.data.model.api.response.shopper

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class ShopperResponse {
    @SerializedName("response")
    @Expose
    val response: ShopperDetailResponse? = null
}