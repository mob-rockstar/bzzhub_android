package com.app.basketiodriver.ui.availablebatches

import android.content.Context
import android.content.Intent
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.ActivityFirstOrderWelcomeBinding
import com.app.basketiodriver.ui.base.BaseActivity

class FirstOrderWelcomeActivity :
    BaseActivity<ActivityFirstOrderWelcomeBinding?, AvailableBatchesViewModel>() {


    override val layoutId: Int
        get() = R.layout.activity_first_order_welcome

    override val viewModel: AvailableBatchesViewModel
        get() {
            return getViewModel(AvailableBatchesViewModel::class.java)
        }


    companion object {
        fun newIntent(context: Context?): Intent {
            return Intent(context, FirstOrderWelcomeActivity::class.java)
        }
    }
}
