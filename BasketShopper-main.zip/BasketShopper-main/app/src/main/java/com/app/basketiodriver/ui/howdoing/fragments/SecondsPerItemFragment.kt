package com.app.basketiodriver.ui.howdoing.fragments


import android.os.Bundle
import android.view.View
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentSecondsPerItemBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.howdoing.HowIamDoingViewModel

/**
Created by ibraheem lubbad on 2020-01-19.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class SecondsPerItemFragment : BaseFragment<FragmentSecondsPerItemBinding?, HowIamDoingViewModel>(),
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_seconds_per_item

    override val viewModel: HowIamDoingViewModel
        get() {
            return getViewModel(requireActivity(), HowIamDoingViewModel::class.java)
        }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.seconds_per_item))
    }


}