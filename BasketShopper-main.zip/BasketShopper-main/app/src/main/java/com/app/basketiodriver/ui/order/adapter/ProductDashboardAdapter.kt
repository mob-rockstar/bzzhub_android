package com.app.basketiodriver.ui.order.adapter

import android.text.Html
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.order.ProductItem
import com.app.basketiodriver.databinding.ItemProductBinding
import com.app.basketiodriver.utils.BaseRecyclerViewAdapter
import com.app.basketiodriver.utils.GlideApp
import com.app.basketiodriver.utils.price.PriceConstructor
import com.app.basketiodriver.utils.price.PriceConstructorNew
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.*

class ProductDashboardAdapter(val activity : FragmentActivity, val listItems : List<ProductItem>) : BaseRecyclerViewAdapter<ProductItem, ItemProductBinding>(){

    var symbols: DecimalFormatSymbols = DecimalFormatSymbols(Locale.US)
    var numberFormat: DecimalFormat = DecimalFormat("#.## x ", symbols)

    override val layoutId: Int
        get() = R.layout.item_product

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return ProductViewHolder(createBindView(parent))
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val holder = holder as ProductViewHolder
        val item = listItems[position]

        holder.binding.threeDot.visibility = View.GONE

        // Display the product image
        if (item.itemProductImage != null) {
            GlideApp.with(activity).load(item.itemProductImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(holder.binding.orderItemImage)
        }

        val title = String.format(Locale.US, "%s%s", numberFormat.format(item.itemOrderedQty ?: 0), item.itemProductName)
        holder.binding.orderItemTitle.text = title
//        holder.binding.orderItemDesc.text = item.itemAisleName

        holder.binding.tvPriceDescription.text = item.getDescriptionLabel()
        if (item.getDescriptionLabel() == ""){
            holder.binding.tvPriceDescription.visibility = View.GONE
        }
        else{
            holder.binding.tvPriceDescription.visibility = View.VISIBLE
        }

        val price = PriceConstructorNew.getFormatPrice(item, PriceConstructor.LabelType.SIMPLE)
        holder.binding.orderCost.text = Html.fromHtml(price)
    }

    override fun getItemCount(): Int {
        return listItems.size
    }

    inner class ProductViewHolder(val binding: ItemProductBinding) :
        RecyclerView.ViewHolder(binding.root)
}