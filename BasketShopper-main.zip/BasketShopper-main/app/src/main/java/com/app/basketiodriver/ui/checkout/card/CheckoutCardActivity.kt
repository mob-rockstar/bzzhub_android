package com.app.basketiodriver.ui.checkout.card

import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.checkout.OutletOrder
import com.app.basketiodriver.data.model.api.response.checkout.ShopperOrderReview
import com.app.basketiodriver.databinding.ActivityCheckoutCardBinding
import com.app.basketiodriver.databinding.ActivityOrderDetailsBinding
import com.app.basketiodriver.di.Navigators
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.app.basketiodriver.utils.GlideApp

class CheckoutCardActivity : BaseActivity<ActivityCheckoutCardBinding, CheckoutCardViewModel>() {

    var orderId : Long = 0
    lateinit var orders : OutletOrder

    var isLoyaltyCard : Int = 0
    var isPLUCard : Int = 0
    var isTaxCard : Int = 0

    // Loyalty Card Number
    var loyaltyCardNumber : Long = 0
    var loyaltyCardImage : String = ""

    var isNext : Boolean = false

    override val layoutId: Int
        get() = R.layout.activity_checkout_card

    override val viewModel: CheckoutCardViewModel
        get() {
            return getViewModel(CheckoutCardViewModel::class.java)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize the Toolbar
        initToolbar(getString(R.string.charge_card),
            true, viewDataBinding!!.layoutToolBar.toolbar,
            View.OnClickListener {
                run {
                    onBackPressed()
                }
            })

        // get order id
        orderId = intent.getLongExtra("KEY_ORDER_OUTLET_ID", 0)

        initView()
    }

    override fun onResume() {
        super.onResume()

        isNext = false
    }

    override fun onStart() {
        super.onStart()

        isNext = false
    }

    override fun onBackPressed() {
//        super.onBackPressed()

        // Call api to update the order status
        /////////////////////////////////////
        // Go to order details

        finish()
    }

    // Setup views
    private fun initView(){
        setActions()

        getOrder()
    }

    // Set the actions for click event
    private fun setActions(){
        viewDataBinding!!.btnTAXExemptNext.setOnClickListener {
            isLoyaltyCard = 0
            isPLUCard = 0
            isTaxCard = 0

            initCards()
        }

        viewDataBinding!!.btnLoyaltyCardNext.setOnClickListener {
            isLoyaltyCard = 0

            initCards()
        }

        viewDataBinding!!.btnPLUNext.setOnClickListener {
            isLoyaltyCard = 0
            isPLUCard = 0

            initCards()
        }
    }

    private fun initCards(){
        if (isLoyaltyCard == 1){
            initLoyaltyCard()
        }
        else if (isPLUCard == 1){
            initPLUCard()
        }
        else if (isTaxCard == 1){
            initTaxCard()
        }
        else{
            if (!isNext){
                isNext = true
                val subTotal = orders.subtotal
                if (subTotal != null && subTotal > 0.0){
                    // Go to Confirm Total page
                    Navigators.goToConfirmTotalActivity(this, orders, orders.subtotal ?: 0.0, orders.paymentGatewayId ?: 0)
                }
                else{
                    // Go to Confirm Total page
                    Navigators.goToConfirmTotalActivity(this, orders, orders.total ?: 0.0, orders.paymentGatewayId ?: 0)
                }
            }
        }
    }

    private fun initLoyaltyCard(){
        viewDataBinding!!.lvLoyaltyCard.visibility = View.VISIBLE
        viewDataBinding!!.lvPLUCard.visibility = View.GONE
        viewDataBinding!!.lvTaxExemptCard.visibility = View.GONE

        viewDataBinding!!.txtLYLoyaltyCardNumber.text = "" + loyaltyCardNumber

        if (loyaltyCardImage != ""){
            GlideApp.with(this).load(loyaltyCardImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(viewDataBinding!!.imgLoyaltyCard)
        }
    }

    private fun initPLUCard(){
        viewDataBinding!!.lvLoyaltyCard.visibility = View.GONE
        viewDataBinding!!.lvPLUCard.visibility = View.VISIBLE
        viewDataBinding!!.lvTaxExemptCard.visibility = View.GONE

        viewDataBinding!!.txtPLULoyaltyCardNumber.text = "" + loyaltyCardNumber
        viewDataBinding!!.txtPLUNo.text = "" + loyaltyCardNumber
    }

    private fun initTaxCard(){
        viewDataBinding!!.lvLoyaltyCard.visibility = View.GONE
        viewDataBinding!!.lvPLUCard.visibility = View.GONE
        viewDataBinding!!.lvTaxExemptCard.visibility = View.VISIBLE

        viewDataBinding!!.txtTaxBasketId.text = "" + loyaltyCardNumber
        if (loyaltyCardImage != ""){
            GlideApp.with(this).load(loyaltyCardImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(viewDataBinding!!.imgTaxCard)
        }
    }

    // Get order details
    private fun getOrder(){
        viewModel.getShopperOrderReview(orderId, object : HandleResponse<ShopperOrderReview>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Toast.makeText(this@CheckoutCardActivity, error?.message, Toast.LENGTH_SHORT).show()
                }else{
                    Toast.makeText(this@CheckoutCardActivity, resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }
            }

            override fun handleSuccessResponse(successResponse: ShopperOrderReview) {
                val response = successResponse.responseOrderReview
                if (response != null){
                    if (response.httpCode != 200){
                        Toast.makeText(this@CheckoutCardActivity, response.message, Toast.LENGTH_SHORT).show()
                    }
                    else{
                        orders = response.outletOrder!!
                        orders.id = orderId

                        if (response.outletDetails != null) {
                            isLoyaltyCard = response.outletDetails.loyalty_card_number_needed
                            loyaltyCardNumber = response.outletDetails.loyalty_card_number ?: 0
                            loyaltyCardImage = response.outletDetails.loyalty_card_image ?: ""

                            initCards()
                        }
                    }
                }
                else{
                    Toast.makeText(this@CheckoutCardActivity, R.string.error_load_info, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }
}