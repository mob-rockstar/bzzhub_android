package com.app.basketiodriver.ui.dialogs

import android.os.Bundle
import android.view.View
import androidx.fragment.app.FragmentManager
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentTotalConfirmDialogBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseDialogFragment
import com.app.basketiodriver.ui.checkout.card.CheckoutCardViewModel
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel

class TotalConfirmDialogFragment: BaseDialogFragment<FragmentTotalConfirmDialogBinding?, CheckoutCardViewModel>(),
    Injectable  {

    var listener : DialogButtonClickListener? = null

    override val layoutId: Int
        get() = R.layout.fragment_total_confirm_dialog

    override val viewModel: CheckoutCardViewModel
        get() {
            return getViewModel(baseActivity, CheckoutCardViewModel::class.java)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewDataBinding!!.btnAgree.setOnClickListener {
            dismissAllowingStateLoss()

            if (listener != null){
                listener!!.onClickOk()
            }
        }

        viewDataBinding!!.btnCancel.setOnClickListener {
            dismissAllowingStateLoss()

            if (listener != null){
                listener!!.onClickCancel()
            }
        }
    }

    override fun show(manager: FragmentManager, tag: String?) {
        try {
            val ft = manager.beginTransaction()
            ft.add(this, tag)
            ft.commitAllowingStateLoss()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    interface DialogButtonClickListener {
        fun onClickOk()
        fun onClickCancel()
    }
}