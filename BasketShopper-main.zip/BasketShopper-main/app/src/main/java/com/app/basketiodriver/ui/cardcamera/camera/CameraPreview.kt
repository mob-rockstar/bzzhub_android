package com.app.basketiodriver.ui.cardcamera.camera

import android.annotation.TargetApi
import android.content.Context
import android.content.res.Configuration
import android.hardware.Camera
import android.hardware.Camera.PictureCallback
import android.os.Build
import android.util.AttributeSet
import android.util.Log
import android.view.SurfaceHolder
import android.view.SurfaceView
import com.app.basketiodriver.ui.cardcamera.camera.SensorControler.CameraFocusListener
import com.app.basketiodriver.utils.ScreenUtils

class CameraPreview : SurfaceView, SurfaceHolder.Callback {
    private var camera: Camera? = null
    private var mAutoFocusManager: AutoFocusManager? = null
    private var mSensorControler: SensorControler? = null
    private var mContext: Context? = null
    private lateinit var mSurfaceHolder: SurfaceHolder

    constructor(context: Context) : super(context) {
        init(context)
    }

    constructor(
        context: Context,
        attrs: AttributeSet?
    ) : super(context, attrs) {
        init(context)
    }

    constructor(
        context: Context,
        attrs: AttributeSet?,
        defStyleAttr: Int
    ) : super(context, attrs, defStyleAttr) {
        init(context)
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    constructor(
        context: Context,
        attrs: AttributeSet?,
        defStyleAttr: Int,
        defStyleRes: Int
    ) : super(context, attrs, defStyleAttr, defStyleRes) {
        init(context)
    }

    private fun init(context: Context) {
        mContext = context
        mSurfaceHolder = holder
        mSurfaceHolder.addCallback(this)
        mSurfaceHolder.setKeepScreenOn(true)
        mSurfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS)
        mSensorControler = SensorControler.getInstance(context.applicationContext)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        camera = CameraUtils.openCamera()
        if (camera != null) {
            try {
                camera!!.setPreviewDisplay(holder)
                val parameters = camera!!.parameters
                if (resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT) {
                    camera!!.setDisplayOrientation(90)
                    parameters.setRotation(90)
                } else {
                    camera!!.setDisplayOrientation(0)
                    parameters.setRotation(0)
                }
                val sizeList =
                    parameters.supportedPreviewSizes
                val bestSize = getOptimalPreviewSize(
                    sizeList,
                    ScreenUtils.getScreenWidth(mContext!!),
                    ScreenUtils.getScreenHeight(mContext!!)
                )
                parameters.setPreviewSize(bestSize!!.width, bestSize.height)
                camera!!.parameters = parameters
                camera!!.startPreview()
                focus()
                //mAutoFocusManager = new AutoFocusManager(camera);
            } catch (e: Exception) {
                Log.d(
                    TAG,
                    "Error setting camera preview: " + e.message
                )
                try {
                    val parameters = camera!!.parameters
                    if (resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT) {

                        camera!!.setDisplayOrientation(90)
                        parameters.setRotation(90)
                    } else {
                        camera!!.setDisplayOrientation(0)
                        parameters.setRotation(0)
                    }
                    camera!!.parameters = parameters
                    camera!!.startPreview()
                    focus()

                } catch (e1: Exception) {
                    e.printStackTrace()
                    camera = null
                }
            }
        }
    }


    private fun getOptimalPreviewSize(
        sizes: List<Camera.Size>?,
        w: Int,
        h: Int
    ): Camera.Size? {
        val ASPECT_TOLERANCE = 0.1
        val targetRatio = w.toDouble() / h
        if (sizes == null) return null
        var optimalSize: Camera.Size? = null
        var minDiff = Double.MAX_VALUE
        // Try to find an size match aspect ratio and size
        for (size in sizes) {
            val ratio = size.width.toDouble() / size.height
            if (Math.abs(ratio - targetRatio) > ASPECT_TOLERANCE) continue
            if (Math.abs(size.height - h) < minDiff) {
                optimalSize = size
                minDiff = Math.abs(size.height - h).toDouble()
            }
        }
        // Cannot find the one match the aspect ratio, ignore the requirement
        if (optimalSize == null) {
            minDiff = Double.MAX_VALUE
            for (size in sizes) {
                if (Math.abs(size.height - h) < minDiff) {
                    optimalSize = size
                    minDiff = Math.abs(size.height - h).toDouble()
                }
            }
        }
        return optimalSize
    }

    override fun surfaceChanged(
        holder: SurfaceHolder,
        format: Int,
        w: Int,
        h: Int
    ) {
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        holder.removeCallback(this)
        release()
    }

    private fun release() {
        if (camera != null) {
            camera!!.setPreviewCallback(null)
            camera!!.stopPreview()
            camera!!.release()
            camera = null
            if (mAutoFocusManager != null) {
                mAutoFocusManager!!.stop()
                mAutoFocusManager = null
            }
        }
    }


    fun focus() {
        if (camera != null) {
            try {
                camera!!.autoFocus(null)
            } catch (e: Exception) {
                Log.d(TAG, "takePhoto $e")
            }
        }
    }


    fun switchFlashLight(): Boolean {
        if (camera != null) {
            val parameters = camera!!.parameters
            return if (parameters.flashMode == Camera.Parameters.FLASH_MODE_OFF) {
                parameters.flashMode = Camera.Parameters.FLASH_MODE_TORCH
                camera!!.parameters = parameters
                true
            } else {
                parameters.flashMode = Camera.Parameters.FLASH_MODE_OFF
                camera!!.parameters = parameters
                false
            }
        }
        return false
    }


    fun takePhoto(pictureCallback: PictureCallback?) {
        if (camera != null) {
            try {
                camera!!.takePicture(null, null, pictureCallback)
            } catch (e: Exception) {
                Log.d(TAG, "takePhoto $e")
            }
        }
    }

    fun startPreview() {
        if (camera != null) {
            camera!!.startPreview()
        }
    }

    fun onStart() {
        addCallback()
        if (mSensorControler != null) {
            mSensorControler!!.onStart()
            mSensorControler!!.setCameraFocusListener(object :
                CameraFocusListener {
                override fun onFocus() {
                    focus()
                }

            })
        }
    }

    fun onStop() {
        if (mSensorControler != null) {
            mSensorControler!!.onStop()
        }
    }

    fun addCallback() {
        if (mSurfaceHolder != null) {
            mSurfaceHolder.addCallback(this)
        }
    }

    companion object {
        private val TAG = CameraPreview::class.java.name
    }
}