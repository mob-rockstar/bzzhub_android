
package com.app.basketiodriver.data.local.db

import android.os.AsyncTask
import com.app.basketiodriver.data.local.db.dao.UserDao
import com.app.basketiodriver.data.model.api.User
import com.app.basketiodriver.data.model.db.OnbaordingStages
import io.reactivex.Observable
import io.reactivex.Single
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
@Singleton
class AppDbHelper @Inject constructor(private val mAppDatabase: AppDatabase) : DbHelper {


    override val allUsers: Observable<List<User?>?>?
        get() = Observable.fromCallable { mAppDatabase.userDao().loadAll() }

    override fun findCurrentUserOnbaordingConfig(userId: Int): Single<OnbaordingStages?>? {

       return  mAppDatabase.onbaordingStagesDao().findByUserId(userId)
    }

    override fun updateCurrentUserOnbaordingConfig(onbaordingStages: OnbaordingStages) {
        return  mAppDatabase.onbaordingStagesDao().insert(onbaordingStages)
    }


//
//    override fun saveCurrentUser(user: User) {
//          saveCurrentUserTask(mAppDatabase.userDao(),user)
//    }
//   override fun getCurrentUser(userId: Int): Single<User?>? {
//        return  mAppDatabase.userDao().getCurreatUser()
//    }

    override fun deleteCurrentUser(user: User) {
        deleteCurrentUserTask(mAppDatabase.userDao(),user)
    }


    private class saveCurrentUserTask(val userDao: UserDao, val user: User) : AsyncTask<User?, Void?, Void?>() {
        override fun doInBackground(vararg trips: User?): Void? {
            userDao.insert(user)
            return null
        }

    }    private class deleteCurrentUserTask(val userDao: UserDao, val user: User) : AsyncTask<User?, Void?, Void?>() {
        override fun doInBackground(vararg trips: User?): Void? {
            userDao.delete(user)
            return null
        }

    }





}