package com.app.basketiodriver.ui.checkout.fragments

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Parcelable
import android.view.View
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.checkout.CustomerInfo
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.model.api.response.checkout.OrdersReplacementItem
import com.app.basketiodriver.data.model.api.response.checkout.OutletOrder
import com.app.basketiodriver.databinding.FragmentPendingBinding
import com.app.basketiodriver.databinding.FragmentToDoBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.checkout.adapter.InreviewAdapter
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsActivity
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsActivity.Companion.KEY_CLICKABLE
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsActivity.Companion.KEY_LIST_ORDER
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.app.basketiodriver.ui.order.review.ReviewChangesLatestActivity
import com.app.basketiodriver.utils.AppConstants
import com.app.basketiodriver.utils.AppUtils
import com.app.basketiodriver.utils.MessageEvent
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.Serializable
import java.util.*
import kotlin.math.sign

class Pending : BaseFragment<FragmentPendingBinding, OrderDetailsViewModel>(), Injectable {

    var orderId : Long = 0L
    lateinit var order : OutletOrder

    var position : Int = 0

    lateinit var linearLayoutManager: LinearLayoutManager

    // Adapter
    lateinit var reviewAdapter : InreviewAdapter

    var info : CustomerInfo? = null

    override val layoutId: Int
        get() = R.layout.fragment_pending

    override val viewModel: OrderDetailsViewModel
        get() {
            return getViewModel(baseActivity as FragmentActivity, OrderDetailsViewModel::class.java)
        }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (arguments != null)
            order = requireArguments().getSerializable(KEY_LIST_ORDER) as OutletOrder
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        EventBus.getDefault().register(this)

    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        if (event.message == AppConstants.MESSAGE_ITEM_REFUNDED) {
            // Get shopper orders
            viewDataBinding?.refreshLayout?.isRefreshing = false
        }
    }



    override fun onResume() {
        super.onResume()

        if (arguments != null)
            order = requireArguments().getSerializable(KEY_LIST_ORDER) as OutletOrder

        if (activity != null){
            orderId = (activity as OrderDetailsActivity).orderId
        }

        initUI()
    }

    private fun initUI(){
        // Init the pending list adapter
        linearLayoutManager = LinearLayoutManager(activity)
        viewDataBinding!!.recyclerPending.layoutManager = linearLayoutManager
//        viewDataBinding!!.recyclerPending.setHasFixedSize(true)

        if (order.pendingOrdersItems.isNotEmpty()){
            viewDataBinding!!.rlEmptyView.visibility = View.GONE
//            viewDataBinding!!.txtSortTitle.visibility = View.VISIBLE
            viewDataBinding!!.recyclerPending.visibility = View.VISIBLE
        }
        else{
            viewDataBinding!!.rlEmptyView.visibility = View.VISIBLE
//            viewDataBinding!!.txtSortTitle.visibility = View.GONE
            viewDataBinding!!.recyclerPending.visibility = View.GONE
        }

        setStateCheckoutButton()

        // Sort by department
        sortByDepartment()

        viewDataBinding!!.refreshLayout.setOnRefreshListener {
            Toast.makeText(baseActivity, getString(R.string.refreshing_orders), Toast.LENGTH_SHORT).show()
            (baseActivity as OrderDetailsActivity).queryShopperOrders()
        }

        // Chat Action
        viewDataBinding!!.chatFloatingButton.setOnClickListener {
            (baseActivity as OrderDetailsActivity).openChatActivity()
        }

    }

    private fun setStateCheckoutButton(){
        if (order.todoItemsCount != 0 || viewDataBinding!!.recyclerPending.visibility == View.GONE){
            viewDataBinding!!.llBottom.visibility = View.GONE
        }
        else{
            viewDataBinding!!.llBottom.visibility = View.VISIBLE
        }
    }

    /**
     * Check if customer confirmed the replacement item
     */
    private fun checkIfCustomerConfirmedReplacement(){
        for (orderItem in order.pendingOrdersItems) {
            if (orderItem.itemShoppingStatus == 2 && orderItem.itemFound != null && orderItem.itemFound == 1) {
                for (replacementItem in orderItem.replacementItemList) {
                    if (replacementItem.ordersOutletsReplacementItemsId != null && replacementItem.replacementItemId != null){
                        if (replacementItem.ordersOutletsReplacementItemsId == replacementItem.replacementItemId) {
                            orderItem.isCustomerConfirmedReplace = true
                            orderItem.approvedReplaceItem = replacementItem

                            // Save the only confirmed item
                            val updateReplaceItems : ArrayList<OrdersReplacementItem> = arrayListOf()
                            updateReplaceItems.add(replacementItem)
                            orderItem.replacementItemList = updateReplaceItems

                            break
                        }
                    }
                }
            }
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun sortByDepartment(){
        var clickable = true
        if (arguments != null)
            clickable = requireArguments().getBoolean(KEY_CLICKABLE, true)

        info = CustomerInfo(order.userImage ?: "", String.format(Locale("en"), "%s %s", order.userFirstName, order.userLastName),
            order.userLocation ?: "", order.deliverySlot ?: "", order.userGoogleAddress ?: "", order.userAddressType ?: "",
            order.userDepartmentBuilding ?: "", order.userAdditionalInfo ?: "", order.userNearLandmark ?: "")

        // Check if there is item confirmed by customer
        checkIfCustomerConfirmedReplacement()

        // Set the adapter
        if (viewDataBinding != null){
            try{
                reviewAdapter = InreviewAdapter(baseActivity as FragmentActivity, order.pendingOrdersItems, order.userMobile ?: "", order.outletId ?: 0, info!!, clickable)
                viewDataBinding!!.recyclerPending.adapter = reviewAdapter
                reviewAdapter.notifyDataSetChanged()
//                viewDataBinding!!.recyclerPending.offsetChildrenVertical(position)

                // Restore the recyclerview state
                viewDataBinding!!.recyclerPending.layoutManager?.onRestoreInstanceState((baseActivity as OrderDetailsActivity).getPending())


                if (order.todoItemsCount != 0 || order.pendingItemsCount != 0){
                    viewDataBinding!!.btnReview.text = getString(R.string.review_changes)
                }
                else{
                    viewDataBinding!!.btnReview.text = getString(R.string.proceed_to_checkout)
                }

                viewDataBinding!!.btnReview.setOnClickListener {
                    viewDataBinding!!.btnReview.isClickable = false
                    openReviewChange()
                }
            }
            catch (e : Exception){
                e.printStackTrace()
            }
        }

    }

    fun getSaved(): Parcelable? {
        return if (viewDataBinding?.recyclerPending != null) viewDataBinding?.recyclerPending!!.layoutManager?.onSaveInstanceState() else null
    }

    private fun openReviewChange(){
        try {
            orderId = (activity as OrderDetailsActivity).orderId
            order.id = orderId

            // Go to ReviewChangesLatest Activity
            val bundle = Bundle()
            bundle.putSerializable("ARG_INFO", info!!)
            bundle.putSerializable("ARG_PENDING_LIST", order.pendingOrdersItems as Serializable)
            bundle.putSerializable("ARG_ORDER", order)

            startActivity(Intent(baseActivity, ReviewChangesLatestActivity::class.java).putExtras(bundle))
        }
        catch (e : Exception){
            e.printStackTrace()
        }

    }
}