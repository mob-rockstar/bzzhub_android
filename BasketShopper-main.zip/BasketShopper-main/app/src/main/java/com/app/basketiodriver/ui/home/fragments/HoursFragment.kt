package com.app.basketiodriver.ui.home.fragments


import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.fragment.app.Fragment
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentHoursBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.home.HomeActivity
import com.app.basketiodriver.ui.home.HomeViewModel
import com.app.basketiodriver.ui.utils.ViewPagerAdapter
import com.app.basketiodriver.ui.weekhours.fragments.HoursWeekFragment
import com.google.android.material.tabs.TabLayout
import java.text.SimpleDateFormat
import java.util.*

/**
 * A simple [Fragment] subclass.
 */
class HoursFragment : BaseFragment<FragmentHoursBinding?, HomeViewModel>(),
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_hours

    override val viewModel: HomeViewModel
        get() {
            return getViewModel(requireActivity(), HomeViewModel::class.java)
        }
    var thisWeekStartDate = ""
    var thisWeekEdnDate = ""

    var nextWeekStartDate = ""
    var nextWeekEndDate = ""

    var thisMonthName = ""
    var nextMonthName = ""

    lateinit var weekAdapter: ViewPagerAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initSupportMenu()

        hideSupportMenuItems()
        setTitle(getString(R.string.hours))

        viewDataBinding!!.tabLayout.tabGravity = TabLayout.GRAVITY_FILL

        weekAdapter = ViewPagerAdapter(childFragmentManager)
        weekAdapter.setFragments(
            HoursWeekFragment.newInstance(thisWeekStartDate, thisWeekEdnDate, thisMonthName),
            HoursWeekFragment.newInstance(nextWeekStartDate, nextWeekEndDate, nextMonthName)
            // HoursWeekFragment.newInstance( nextWeekStartDate,nextWeekEndDate,nextMonthName)
        )
        weekAdapter.setTitles(getString(R.string.this_week), getString(R.string.next_week))

        viewDataBinding!!.viewPager.adapter = weekAdapter
        viewDataBinding!!.tabLayout.setupWithViewPager(viewDataBinding!!.viewPager)
        viewDataBinding!!.tabLayout.setOnTabSelectedListener(object :
            TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                viewDataBinding!!.viewPager.currentItem = tab.position
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
    }

    // Show the support toolbar
    private fun hideSupportMenuItems(){
        try {
            (baseActivity as HomeActivity).showSupportMenuItems(false)
        }
        catch (exception: Exception){
            print(exception.printStackTrace())
        }
    }

    override fun onResume() {
        super.onResume()
    }

    @SuppressLint("LogNotTimber")
    private fun initSupportMenu() {
        // get today and clear time of day
        val cal = Calendar.getInstance()
        cal[Calendar.HOUR_OF_DAY] = 0 // ! clear would not reset the hour of day !

        cal.clear(Calendar.MINUTE)
        cal.clear(Calendar.SECOND)
        cal.clear(Calendar.MILLISECOND)

        // get start of this week in milliseconds
        cal[Calendar.DAY_OF_WEEK] = cal.firstDayOfWeek
        println("Start of this week:       " + cal.time)
        println("... in milliseconds:      " + cal.timeInMillis)

        val month1 = cal[Calendar.MONTH] + 1
        val day1 = cal[Calendar.DATE]
        val year1 = cal[Calendar.YEAR]

        Log.d("startDate = ", "$year1-$month1-$day1")

        val cl2 = Calendar.getInstance()
        cl2.time = cal.time
        cl2.add(Calendar.DAY_OF_WEEK, 6)
        println("end of this week:       " + cl2.time)
        println("... in milliseconds:      " + cl2.timeInMillis)

        val month7 = cl2[Calendar.MONTH] + 1
        val day7 = cl2[Calendar.DATE]
        val year7 = cl2[Calendar.YEAR]
        Log.d("endDate = ", "$year7-$month7-$day7")

        thisWeekStartDate = String.format(Locale.ENGLISH, "%d-%d-%d", year1, month1, day1)
        thisWeekEdnDate =  String.format(Locale.ENGLISH, "%d-%d-%d", year7, month7, day7)

        val month_date = SimpleDateFormat("MMMM", Locale.ENGLISH)
        thisMonthName = month_date.format(cal.time).toString() + " " + day1 + " - " + day7

        // start of the next week
        cal.add(Calendar.WEEK_OF_YEAR, 1)
        println("Start of the next week:   " + cal.time)
        println("... in milliseconds:      " + cal.timeInMillis)

        val month2 = cal[Calendar.MONTH] + 1
        val day2 = cal[Calendar.DATE]
        val year2 = cal[Calendar.YEAR]

        Log.d("startDate = ", "$year2-$month2-$day2")

        cal.add(Calendar.DAY_OF_WEEK, 6)
        println("end of the next week:   " + cal.time)
        println("... in milliseconds:      " + cal.timeInMillis)

        val month8 = cal[Calendar.MONTH] + 1
        val day8 = cal[Calendar.DATE]
        val year8 = cal[Calendar.YEAR]

        Log.d("endDate = ", "$year8-$month8-$day8")

        nextWeekStartDate = String.format(Locale.ENGLISH, "%d-%d-%d", year2, month2, day2)
        nextWeekEndDate = String.format(Locale.ENGLISH, "%d-%d-%d", year8, month8, day8)

        val month_date1 = SimpleDateFormat("MMMM", Locale.ENGLISH)
        nextMonthName = month_date1.format(cal.time) + " " + day2 + " - " + day8

    }
}





