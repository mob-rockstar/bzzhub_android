package com.app.basketiodriver.ui.onboarding.data

import com.app.basketiodriver.data.model.api.response.DocumentsResponse


/**
Created by ibraheem lubbad on 3/15/20.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class Stage(
    val id: String,
    val title: String,
    val isDone: Boolean,
    val isEnabled: Boolean,
    val userDcouments: List<DocumentsResponse.OnbaordingDocument>
)

