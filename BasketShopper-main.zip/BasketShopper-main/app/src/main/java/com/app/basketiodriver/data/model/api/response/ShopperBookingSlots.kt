package com.app.basketiodriver.data.model.api.response

import com.google.gson.annotations.SerializedName


/**
Created by ibraheem lubbad on 2020-02-11.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
data class ShopperBookingSlots(
    @SerializedName("booking_id") val booking_id: String,
    @SerializedName("status") val status: Int,
    @SerializedName("start_time") val start_time: String,
    @SerializedName("end_time") val end_time: String,
    @SerializedName("is_slot_free") val is_slot_free: Int,
    @SerializedName("is_you_booked") var is_you_booked: Int,
    @SerializedName("is_slot_past") val is_slot_past: Boolean
)