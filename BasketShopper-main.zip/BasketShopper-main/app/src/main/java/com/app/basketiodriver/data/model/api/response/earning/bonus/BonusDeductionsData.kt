package com.app.basketiodriver.data.model.api.response.earning.bonus

import com.google.gson.annotations.SerializedName

data class BonusDeductionsData (

    @SerializedName("id")
    var id : Int = 0,

    @SerializedName("amount")
    var amount: String = "0.00",

    @SerializedName("reference_number")
    var reference_number: String = "",

    @SerializedName("status")
    var status: String = "",

    @SerializedName("type")
    var type: String? = null,

    @SerializedName("created_on")
    var created_on: String? = null,

    @SerializedName("comments")
    var comments: String = "",

    @SerializedName("payment_date")
    var payment_date: String? = null
)