package com.app.basketiodriver.ui.ShareDialog;

import android.view.View;

/**
 * Created by ogiba on 20.03.2017.
 */

public interface OnItemClickListener {
    void onItemClick(View v, int position);
}
