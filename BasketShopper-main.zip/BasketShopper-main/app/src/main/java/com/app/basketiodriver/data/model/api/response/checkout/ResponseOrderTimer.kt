package com.app.basketiodriver.data.model.api.response.checkout

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class ResponseOrderTimer {
    @SerializedName("httpCode")
    @Expose
    val httpCode: Int? = null

    @SerializedName("Message")
    @Expose
    val message: String? = null

    @SerializedName("timer_now")
    @Expose
    val timerNow: Long? = null

    @SerializedName("shopping_goal")
    @Expose
    val shoppingGoal: Long? = null
}