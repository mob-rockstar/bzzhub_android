package com.app.basketiodriver.ui.availablebatches.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.ItemAvailableBatchBinding
import com.app.basketiodriver.ui.base.DataListAdapter


/**
Created by ibraheem lubbad on 2020-05-22.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class ItemAvailableBatchAdapter(val context: Context, val itemAction: ItemAction?) :
    DataListAdapter<String, ItemAvailableBatchBinding>() {

    interface ItemAction {
        fun clickOnItem()
    }

    override fun createBinding(
        inflater: LayoutInflater,
        parent: ViewGroup?
    ): ItemAvailableBatchBinding {
        return DataBindingUtil.inflate(inflater, R.layout.item_available_batch, parent, false)
    }

    override fun bind(binding: ItemAvailableBatchBinding?, item: String) {
        binding?.root?.setOnClickListener { itemAction?.clickOnItem() }

    }


}