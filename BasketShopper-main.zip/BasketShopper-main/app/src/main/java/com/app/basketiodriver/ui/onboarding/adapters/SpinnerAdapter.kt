package com.app.basketiodriver.ui.onboarding.adapters

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.databinding.DataBindingUtil
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.ItemSpinnerBinding


/**
Created by ibraheem lubbad on 2020-02-16.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class SpinnerAdapter(
    context: Context,
    resource: Int,
    objects: List<String>
) :
    ArrayAdapter<String?>(context, resource) {
    var objects: List<String>
    var itemSpinnerBinding: ItemSpinnerBinding? = null
    var itemSpinnerDownBinding: ItemSpinnerBinding? = null
    override fun getCount(): Int {
        return objects.size
    }

    @SuppressLint("ViewHolder")
    override fun getView(
        position: Int,
        convertView: View?,
        parent: ViewGroup
    ): View {
        itemSpinnerBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.item_spinner,
            null,
            false
        )
        itemSpinnerBinding!!.tvName.text = getItem(position)
        return convertView ?: itemSpinnerBinding!!.root
    }

    override fun getDropDownView(
        position: Int,
        convertView: View?,
        parent: ViewGroup
    ): View {
        itemSpinnerDownBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.item_spinner,
            null,
            false
        )

        itemSpinnerDownBinding!!.tvName.text = getItem(position)
        return convertView ?: itemSpinnerDownBinding!!.root
    }

    override fun getItem(position: Int): String? {
        return objects[position]
    }

    companion object {
        private const val TAG = "SpinnerAdapter"
    }

    init {
        this.objects = objects
    }
}
