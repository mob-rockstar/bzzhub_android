
package com.app.basketiodriver.data.local.db


import com.app.basketiodriver.data.model.api.User
import com.app.basketiodriver.data.model.db.OnbaordingStages
import io.reactivex.Observable
import io.reactivex.Single

/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
interface DbHelper {
    val allUsers: Observable<List<User?>?>?

    fun findCurrentUserOnbaordingConfig(userId:Int): Single<OnbaordingStages?>?
    fun updateCurrentUserOnbaordingConfig(onbaordingStages:OnbaordingStages)
//    fun getCurrentUser(userId: Int): Single<User?>?
//    fun saveCurrentUser(user: User)
    fun deleteCurrentUser(user: User)

}