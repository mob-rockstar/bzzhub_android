package com.app.basketiodriver.data.model.api.response.directions

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class OverviewPolyline {
    @SerializedName("points")
    @Expose
    val points: String? = null
}