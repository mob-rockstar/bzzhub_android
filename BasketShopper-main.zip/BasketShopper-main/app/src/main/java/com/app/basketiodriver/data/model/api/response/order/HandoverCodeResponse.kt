package com.app.basketiodriver.data.model.api.response.order

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName


class HandoverCodeResponse {
    @SerializedName("data")
    @Expose
    var data: HandoverCode? = null

    @SerializedName("message")
    @Expose
    var message: String = ""

    @SerializedName("status")
    @Expose
    var status = 0

    inner class HandoverCode {
        @SerializedName("code")
        @Expose
        var code: String? = null
    }
}