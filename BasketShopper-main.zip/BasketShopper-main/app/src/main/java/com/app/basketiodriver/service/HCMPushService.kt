package com.app.basketiodriver.service

import android.content.Intent
import android.util.Log
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.huawei.hms.push.HmsMessageService
import com.huawei.hms.push.RemoteMessage
import java.lang.Exception

class HCMPushService : HmsMessageService() {


    override fun onStartCommand(intent: Intent?, p1: Int, p2: Int): Int {
        return super.onStartCommand(intent, p1, p2)
    }

    override fun onTokenError(e: Exception?) {
        super.onTokenError(e)
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage?) {
        super.onMessageReceived(remoteMessage)
    }

    override fun onNewToken(token: String?) {
        super.onNewToken(token)

        Log.i(TAG, "*************** Received HCM Token *****************")

        // Save the HCM token to local
        if (token != null) {
            Log.i(TAG, token)
            PreferenceManager.hcmToken = token
        }
    }

    companion object {
        private const val TAG : String = "HCMPushService"
    }
}