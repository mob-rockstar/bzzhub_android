package com.app.basketiodriver.ui.earning

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.Navigation
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.ActivityEarningBinding
import com.app.basketiodriver.mvvm.ui.login.LoginNavigator
import com.app.basketiodriver.ui.base.BaseActivity
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import javax.inject.Inject

class EarningActivity : BaseActivity<ActivityEarningBinding?, EarningViewModel>(),
    LoginNavigator,
    HasAndroidInjector {


    override val layoutId: Int
        get() = R.layout.activity_earning

    override val viewModel: EarningViewModel
        get() {
            return getViewModel(EarningViewModel::class.java)
        }

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>
    override fun androidInjector() = dispatchingAndroidInjector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        initToolbar(getString(R.string.annual_earnings),
            true, viewDataBinding!!.layoutToolBar.toolbar,
            View.OnClickListener {
                run {

                    if (!Navigation.findNavController(this, R.id.navEarningFragment).popBackStack()
                    ) {
                        finish()
                    }
                }
            })
    }


    override fun handleError(error: String) {

    }

    override fun handleSuccess(success: String) {

    }

    override fun gotToNext() {

    }

    companion object {
        fun newIntent(context: Context?): Intent {
            return Intent(context, EarningActivity::class.java)
        }
    }
}
