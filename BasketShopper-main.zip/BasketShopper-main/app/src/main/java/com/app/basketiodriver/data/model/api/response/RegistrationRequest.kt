package com.app.basketiodriver.data.model.api.response

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
data class RegistrationRequest(


    @field:SerializedName("first_name") @field:Expose val first_name: String?,
    @field:SerializedName("last_name") @field:Expose val last_name: String?,
    @field:SerializedName("mobile") @field:Expose val mobile: String?,
    @field:SerializedName("email") @field:Expose val email: String?,
    @field:SerializedName("password") @field:Expose val password: String?,
    @field:SerializedName("gender") @field:Expose val gender: String?,
    @field:SerializedName("shopper_type") @field:Expose val shopper_type: String?,
    @field:SerializedName("login_platform") @field:Expose val login_platform: String="Android",
    @field:SerializedName("device_id") @field:Expose val device_id: String?,
    @field:SerializedName("device_token") @field:Expose val device_token: String?,
    @field:SerializedName("language_id") @field:Expose val language_id: Int?,
    @field:SerializedName("country_code") @field:Expose val country_code: String?

)