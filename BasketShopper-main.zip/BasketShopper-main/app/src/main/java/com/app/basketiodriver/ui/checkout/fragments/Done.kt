package com.app.basketiodriver.ui.checkout.fragments

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Parcelable
import android.view.View
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.checkout.CustomerInfo
import com.app.basketiodriver.data.model.api.response.checkout.Department
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.model.api.response.checkout.OutletOrder
import com.app.basketiodriver.databinding.FragmentDoneBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.checkout.adapter.DepartmentAdapter
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsActivity
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsActivity.Companion.KEY_CLICKABLE
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsActivity.Companion.KEY_LIST_ORDER
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.app.basketiodriver.ui.order.review.ReviewChangesLatestActivity
import com.app.basketiodriver.utils.AppConstants
import com.app.basketiodriver.utils.AppUtils
import com.app.basketiodriver.utils.MessageEvent
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.Serializable
import java.util.*
import kotlin.Comparator
import kotlin.collections.ArrayList
import kotlin.collections.HashSet


class Done : BaseFragment<FragmentDoneBinding, OrderDetailsViewModel>(), Injectable {
    override val layoutId: Int
        get() = R.layout.fragment_done

    override val viewModel: OrderDetailsViewModel
        get() {
            return getViewModel(baseActivity as FragmentActivity, OrderDetailsViewModel::class.java)
        }

    lateinit var info : CustomerInfo
    var orderId : Long = 0L
    var order : OutletOrder? = null

    // Adapter
    lateinit var adapter : DepartmentAdapter


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewDataBinding!!.refreshLayout.setOnRefreshListener {
            Toast.makeText(baseActivity, getString(R.string.refreshing_orders), Toast.LENGTH_SHORT).show()
            (baseActivity as OrderDetailsActivity).queryShopperOrders()
        }

        // Chat Action
        viewDataBinding!!.chatFloatingButton.setOnClickListener {
            (baseActivity as OrderDetailsActivity).openChatActivity()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
    }

    override fun onResume() {
        super.onResume()

        if (arguments != null)
            order = requireArguments().getSerializable(KEY_LIST_ORDER) as OutletOrder

        setStateCheckoutButton()

        // sort by department
        sortByDepartment()
    }

    private fun setStateCheckoutButton(){
        if (order!!.todoItemsCount != 0){
            viewDataBinding!!.llBottom.visibility = View.GONE
        }
        else{
            viewDataBinding!!.llBottom.visibility = View.VISIBLE
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun sortByDepartment(){
        var clickable = true
        if (arguments != null)
            clickable = requireArguments().getBoolean(KEY_CLICKABLE, true)
        val departments = AppUtils.sortItems(order?.doneOrdersItems!!, order?.isSortingEnable ?: 1)
        info = CustomerInfo(order!!.userImage ?: "", String.format(Locale("en"), "%s %s", order!!.userFirstName, order!!.userLastName),
            order!!.userLocation ?: "", order!!.deliverySlot ?: "", order!!.userGoogleAddress ?: "", order!!.userAddressType ?: "",
            order!!.userDepartmentBuilding ?: "", order!!.userAdditionalInfo ?: "", order!!.userNearLandmark ?: "")

        // Init the RecyclerView
        if (viewDataBinding != null){
            try {
                adapter = DepartmentAdapter(baseActivity as FragmentActivity, departments, order!!.userMobile ?: "", order!!.outletId ?: 0, info, false, clickable, order!!.isExpress)

//                viewDataBinding!!.recyclerDone.setHasFixedSize(true)
                viewDataBinding!!.recyclerDone.layoutManager = LinearLayoutManager(context)
                viewDataBinding!!.recyclerDone.adapter = adapter
                adapter.notifyDataSetChanged()

                // Restore the recyclerview state
                viewDataBinding!!.recyclerDone.layoutManager?.onRestoreInstanceState((baseActivity as OrderDetailsActivity).getDone())


                if (order != null){
                    if (order!!.todoItemsCount != 0 || order!!.pendingItemsCount != 0){
                        viewDataBinding!!.btnReview.text = getString(R.string.review_changes)
                    }
                    else{
                        viewDataBinding!!.btnReview.text = getString(R.string.proceed_to_checkout)
                    }

                    viewDataBinding!!.btnReview.setOnClickListener {
                        viewDataBinding!!.btnReview.isClickable = false
                        openReviewChange()
                    }
                }
            }
            catch ( e : Exception){
                e.printStackTrace()
            }
        }
    }

    fun getSaved(): Parcelable? {
        return if (viewDataBinding?.recyclerDone != null) viewDataBinding?.recyclerDone!!.layoutManager?.onSaveInstanceState() else null
    }

    private fun openReviewChange(){
        if (order != null){
            try {
                orderId = (activity as OrderDetailsActivity).orderId
                order!!.id = orderId

                // Go to ReviewChangesLatest Activity
                val bundle = Bundle()
                bundle.putSerializable("ARG_INFO", info!!)
                bundle.putSerializable("ARG_PENDING_LIST", order!!.pendingOrdersItems as Serializable)
                bundle.putSerializable("ARG_ORDER", order)

                startActivity(Intent(baseActivity, ReviewChangesLatestActivity::class.java).putExtras(bundle))
            }
            catch (e : Exception){
                e.printStackTrace()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        EventBus.getDefault().register(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        if (event.message == AppConstants.MESSAGE_ITEM_REFUNDED) {
            // Get shopper orders
            viewDataBinding?.refreshLayout?.isRefreshing = false
        }
    }

}