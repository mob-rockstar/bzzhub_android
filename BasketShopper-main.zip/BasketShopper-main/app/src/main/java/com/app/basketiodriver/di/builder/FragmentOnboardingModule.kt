/*
 * Copyright (C) 2017 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.app.basketiodriver.di.builder


import com.app.basketiodriver.ui.onboarding.fragments.*
import com.app.basketiodriver.ui.onboarding.fragments.UploadDocuments.DocumentFragment
import com.app.basketiodriver.ui.onboarding.fragments.UploadDocuments.PreviewDocumentFragment
import com.app.basketiodriver.ui.onboarding.fragments.UploadDriverDocument.BackDriverDocmentFragment
import com.app.basketiodriver.ui.onboarding.fragments.UploadDriverDocument.DriverLicensePreviewFragment
import com.app.basketiodriver.ui.onboarding.fragments.UploadDriverDocument.FrontDriverDocmentFragment
import com.app.basketiodriver.ui.onboarding.fragments.UploadPassportDocument.FrontPassportDocmentFragment
import com.app.basketiodriver.ui.onboarding.fragments.UploadPassportDocument.PreviewPassportDocumentsFragment
import com.app.basketiodriver.ui.onboarding.fragments.UploadShopperIdDocument.BackShopperIdDocumentFragment
import com.app.basketiodriver.ui.onboarding.fragments.UploadShopperIdDocument.FrontShopperIdDocumentFragment
import com.app.basketiodriver.ui.onboarding.fragments.UploadShopperIdDocument.PreviewShopperIdFragment
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class FragmentOnboardingModule {

    @ContributesAndroidInjector
    abstract fun contributeAdditionalInfoFragment(): AdditionalInfoFragment

    @ContributesAndroidInjector
    abstract fun contributeAddSignatureFragment(): AddSignatureFragment


    @ContributesAndroidInjector
    abstract fun contributeCarConfirmationFragment(): CarConfirmationFragment



    @ContributesAndroidInjector
    abstract fun contributeNDAContractFragment(): NDAContractFragment



    @ContributesAndroidInjector
    abstract fun contributeReviewApplicationFragment(): ReviewApplicationFragment

    @ContributesAndroidInjector
    abstract fun contributeReviewProgressFragment(): ReviewProgressFragment


    @ContributesAndroidInjector
    abstract fun contributeRoleShopAndDriveFragment(): RoleShopAndDriveFragment

    @ContributesAndroidInjector
    abstract fun contributeRoleShopOnlyFragment(): RoleShopOnlyFragment

    @ContributesAndroidInjector
    abstract fun contributeSelectShopperRoleFragment(): SelectShopperRoleFragment

    @ContributesAndroidInjector
    abstract fun contributeShopperRequirementsConfirmationFragment(): ShopperRequirementsConfirmationFragment

    @ContributesAndroidInjector
    abstract fun contributeTakeSelfiFragment(): TakeSelfiFragment

    @ContributesAndroidInjector
    abstract fun contributeVehicleInfoFragment(): VehicleInfoFragment

    @ContributesAndroidInjector
    abstract fun contributeVerifyBackLicenseFragment(): BackShopperIdDocumentFragment

    @ContributesAndroidInjector
    abstract fun contributeVerifyLicenseFragment(): FrontShopperIdDocumentFragment

    @ContributesAndroidInjector
    abstract fun contributeLicensePreviewFragment(): PreviewShopperIdFragment


    @ContributesAndroidInjector
    abstract fun contributeBackDriverDocmentFragment(): BackDriverDocmentFragment

    @ContributesAndroidInjector
    abstract fun contributeFrontDriverDocmentFragment(): FrontDriverDocmentFragment

    @ContributesAndroidInjector
    abstract fun contributeDriverLicensePreviewFragment(): DriverLicensePreviewFragment

    @ContributesAndroidInjector
    abstract fun contributeFrontPassportDocmentFragment(): FrontPassportDocmentFragment

    @ContributesAndroidInjector
    abstract fun contributePreviewPassportDocumentsFragment(): PreviewPassportDocumentsFragment



    @ContributesAndroidInjector
    abstract fun contributeWaitListFragment(): WaitListFragment

    @ContributesAndroidInjector
    abstract fun contributeDocumentFragment(): DocumentFragment


    @ContributesAndroidInjector
    abstract fun contributePreviewDocumentFragment(): PreviewDocumentFragment


}
