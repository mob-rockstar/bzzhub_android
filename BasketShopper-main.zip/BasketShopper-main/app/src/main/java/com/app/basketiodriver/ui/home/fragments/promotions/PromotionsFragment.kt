package com.app.basketiodriver.ui.home.fragments.promotions

import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.View
import androidx.fragment.app.Fragment
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentPromotionsBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.home.HomeViewModel
import com.app.basketiodriver.ui.utils.ViewPagerAdapter
import com.google.android.material.tabs.TabLayout


/**
 * A simple [Fragment] subclass.
 */
class PromotionsFragment : BaseFragment<FragmentPromotionsBinding?, HomeViewModel>(),
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_promotions

    override val viewModel: HomeViewModel
        get() {
            return getViewModel(requireActivity(), HomeViewModel::class.java)
        }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_info, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.hours))

        viewDataBinding!!.tabLayout.tabGravity = TabLayout.GRAVITY_FILL

        val promotionAdapter = ViewPagerAdapter(childFragmentManager)
        promotionAdapter.setFragments(
            PromotionTypeFragment.newInstance(),
            PromotionTypeFragment.newInstance()
        )
        promotionAdapter.setTitles(getString(R.string.current), getString(R.string.past))
        viewDataBinding!!.viewPager.adapter = promotionAdapter
        viewDataBinding!!.tabLayout.setupWithViewPager(viewDataBinding!!.viewPager)
        viewDataBinding!!.tabLayout.setOnTabSelectedListener(object :
            TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                viewDataBinding!!.viewPager.currentItem = tab.position
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
    }

}
