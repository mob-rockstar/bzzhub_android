package com.app.basketiodriver.ui.dialogs

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.Window
import androidx.databinding.DataBindingUtil
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.DialogInstoreOrderCompletedBinding
import com.app.basketiodriver.utils.PopupUtils
import java.util.*

class DialogInstoreOrderCompleted {

    var dialog: Dialog? = null

    // Show the dialog
    fun openDialog(context: Context, doneAction : () -> Unit) {
        dialog = Dialog(context)

        val binding: DialogInstoreOrderCompletedBinding = DataBindingUtil.inflate(
            LayoutInflater.from(context),
            R.layout.dialog_instore_order_completed,
            null,
            false
        )

        dialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog?.setContentView(binding.root)
        dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog?.window?.setGravity(Gravity.CENTER)
        dialog?.setCancelable(false)

        // Done
        binding.btnDone.setOnClickListener {
            doneAction()
        }

        // Show the dialog
        PopupUtils.setDefaultDialogProperty(dialog!!)
        dialog?.show()
    }

    // Dismiss the dialog
    fun dismissDialog(){
        if (dialog != null) dialog!!.dismiss()
    }

    companion object {
        private var instance: DialogInstoreOrderCompleted? = null
        private val Instance: DialogInstoreOrderCompleted
            get() {
                if (instance == null) {
                    instance = DialogInstoreOrderCompleted()
                }
                return instance!!
            }

        fun openDialog(context: Context, doneAction : () -> Unit) {
            Instance.openDialog(context, doneAction)
        }

        fun dismissDialog(){
            Instance.dismissDialog()
        }
    }
}