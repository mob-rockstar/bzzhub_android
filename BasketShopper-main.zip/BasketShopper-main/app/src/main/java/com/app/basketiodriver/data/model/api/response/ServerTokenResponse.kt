package com.app.basketiodriver.data.model.api.response

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class ServerTokenResponse {

    @SerializedName("data")
    @Expose
    var data: ServerTokenData? = null

    @SerializedName("message")
    @Expose
    var message: String = ""

    @SerializedName("status")
    @Expose
    var status = 0

    inner class ServerTokenData {
        @SerializedName("service_token")
        @Expose
        var serviceToken: String? = null
    }
}