package com.app.basketiodriver.data.remote.socket

data class SystemMessage(val error: Boolean, val message: String)