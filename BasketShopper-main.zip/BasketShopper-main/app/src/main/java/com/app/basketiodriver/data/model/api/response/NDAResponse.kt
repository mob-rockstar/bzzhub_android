package com.app.basketiodriver.data.model.api.response

import com.app.basketiodriver.data.model.api.response.Base.BaseResponse
import com.google.gson.annotations.SerializedName


/**
Created by ibraheem lubbad on 2020-02-11.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class NDAResponse : BaseResponse() {

    @SerializedName("data")
    var content: String? = null

}