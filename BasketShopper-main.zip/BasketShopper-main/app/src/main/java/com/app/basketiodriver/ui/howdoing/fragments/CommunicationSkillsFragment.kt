package com.app.basketiodriver.ui.howdoing.fragments


import android.os.Bundle
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentCommunicationSkillsBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.howdoing.HowIamDoingViewModel

/**
Created by ibraheem lubbad on 2020-01-19.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class CommunicationSkillsFragment :
    BaseFragment<FragmentCommunicationSkillsBinding?, HowIamDoingViewModel>(),
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_communication_skills

    override val viewModel: HowIamDoingViewModel
        get() {
            return getViewModel(requireActivity(), HowIamDoingViewModel::class.java)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTitle(getString(R.string.your_communication_skills))

    }


}
