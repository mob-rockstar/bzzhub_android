package com.app.basketiodriver.ui.checkout.adapter

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Build
import android.text.Html
import android.text.Spanned
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.checkout.CustomerInfo
import com.app.basketiodriver.data.model.api.response.checkout.Department
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.model.api.response.checkout.OrdersReplacementItem
import com.app.basketiodriver.data.model.api.response.order.SimilarProduct
import com.app.basketiodriver.data.model.api.response.order.SuggestionResponse
import com.app.basketiodriver.databinding.ItemReviewChangesBinding
import com.app.basketiodriver.di.Navigators
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsActivity
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.app.basketiodriver.ui.dialogs.RefundDialogFragment
import com.app.basketiodriver.ui.order.review.ReviewChangesLatestActivity
import com.app.basketiodriver.utils.AppConstants
import com.app.basketiodriver.utils.AppConstants.FROM_REVIEW_CHANGE
import com.app.basketiodriver.utils.BaseRecyclerViewAdapter
import com.app.basketiodriver.utils.GlideApp
import com.app.basketiodriver.utils.price.PriceConstructor
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.*

class InreviewAdapter(val activity : FragmentActivity, val listItem : List<OrdersItem>, val userMobile : String, val orderId : Long, val info : CustomerInfo, val isClickable : Boolean, val isReviewChanges : Boolean = false)
    : BaseRecyclerViewAdapter<OrdersItem, ItemReviewChangesBinding>()  {

    var type : Int = 0

    var symbols: DecimalFormatSymbols = DecimalFormatSymbols(Locale.US)
    var formatter: DecimalFormat = DecimalFormat("#.## x ", symbols)

    var reviewChangesClickListener : OnReviewChangesItemClickListener? = null

    lateinit var linearLayoutManager: LinearLayoutManager
    lateinit var replacementListAdapter : ReplacementItemListAdapter

    override val layoutId: Int
        get() = R.layout.item_review_changes

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return InReviewHolder(createBindView(parent))
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val holder = holder as InReviewHolder
        val item = listItem[position]

        // Initialize the Replacement list adapter
        linearLayoutManager = LinearLayoutManager(activity)
        holder.binding.rvReplacement.layoutManager = linearLayoutManager

        // Check if the customer confirmed the item
//        checkIfCustomerConfirmedReplacement(item, position)

        if(item.replacementItemList.isNotEmpty()){
            holder.binding.orderItemLayout.visibility = View.GONE
            holder.binding.rvReplacement.visibility = View.VISIBLE

            replacementListAdapter = ReplacementItemListAdapter(activity, item.replacementItemList, item)
            holder.binding.rvReplacement.adapter = replacementListAdapter
            replacementListAdapter.notifyDataSetChanged()
        }
        else{
            holder.binding.orderItemLayout.visibility = View.VISIBLE
            holder.binding.rvReplacement.visibility = View.GONE

            setOrderedItemLayout(holder, item, position)
        }

        // Original item
        setOriginalView(holder, item)

        // Check if should show the Make Changes, Approve
        holder.binding.llActionLayout.visibility = if (isReviewChanges) View.VISIBLE else View.GONE

        // Status
        setItemStatusLabel(holder, item)

        setItemCustomerStatusLabel(holder, item)

        // Approve item
        holder.binding.tvApprove.setOnClickListener {
            if (reviewChangesClickListener != null)
                reviewChangesClickListener!!.onClickApprove(item)
        }

        // Make changes item
        holder.binding.tvMakeChanges.setOnClickListener {
            if (reviewChangesClickListener != null)
                reviewChangesClickListener!!.onClickMakeChanges(item)
        }

//        if (activity is ReviewChangesLatestActivity) {
//            holder.binding.lnReviewsItem.setOnClickListener {

//          // Set click listener
//            if (reviewChangesClickListener != null)
//                reviewChangesClickListener!!.onItemClick(item)
//            }
//        }
    }

    /**
     * Check if customer confirmed the replacement item
     */
//    private fun checkIfCustomerConfirmedReplacement(item : OrdersItem, pos : Int){
//        for (replacementItem in item.replacementItemList) {
//            if (item.customerSuggestionType == 1 && replacementItem.ordersOutletsReplacementItemsId != null && replacementItem.replacementItemId != null){
//                if (replacementItem.ordersOutletsReplacementItemsId == replacementItem.replacementItemId) {
//                    item.isCustomerConfirmedReplace = true
//                    item.approvedReplaceItem = replacementItem
//
//                    // Save the only confirmed item
//                    val updateReplaceItems : ArrayList<OrdersReplacementItem> = arrayListOf()
//                    updateReplaceItems.add(replacementItem)
//                    item.replacementItemList = updateReplaceItems
//
//                    // Refresh the RecyclerView
//                    notifyItemChanged(pos)
//
//                    break
//                }
//            }
//        }
//    }

    override fun getItemCount(): Int {
        return listItem.size
    }

    private fun setOrderedItemLayout(holder : InReviewHolder, item : OrdersItem, position: Int){
        // Price
        val price = PriceConstructor.getFormatPrice(item, PriceConstructor.LabelType.SIMPLE, PreferenceManager.currency, true)

        // Item Title
        holder.binding.orderItemTitle.text = item.productName

        if (item.customerItemNotes != null && item.customerItemNotes!!.isNotEmpty()){
            holder.binding.ivInfo.visibility = View.VISIBLE
        }
        else{
            holder.binding.ivInfo.visibility = View.GONE
        }

        // Product Quantity
        if (item.quantityDifference == 1){
            holder.binding.txtQuantity.text = formatter.format(item.actualQty)
        }
        else if (item.replacementRequested != null && item.replacementRequested == 1){
            if (item.itemStatus == 2) {
                holder.binding.txtQuantity.text = formatter.format(item.actualQty)
            }
            else{
                holder.binding.txtQuantity.text = formatter.format(item.itemQty ?: 1)
            }
        }
        else{
            holder.binding.txtQuantity.text = formatter.format(item.itemQty ?: 1)
        }

        // Item Cost
        holder.binding.tvOrderCost.text = getHtmlString(price)

        // Description
        if (item.getDescriptionLabel().isEmpty()){
            holder.binding.tvPriceDescription.visibility = View.GONE
        }
        else{
            holder.binding.tvPriceDescription.visibility = View.VISIBLE
            holder.binding.tvPriceDescription.text = item.getDescriptionLabel()
        }

        // Item Image
        if (item.productImage != null) {
            GlideApp.with(activity).load(item.productImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(holder.binding.ivOrderItem)
        }

        holder.binding.orderItemLayout.tag = position
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    private fun setItemCustomerStatusLabel(holder : InReviewHolder, item : OrdersItem) {
        when (item.customerSuggestionType) {
            2 -> { // Scan to replace
                holder.binding.tvItemStatus.visibility = View.GONE
                holder.binding.tvShopperStatus.visibility = View.VISIBLE
                holder.binding.tvShopperStatus.setText(R.string.customer_wants_other_replacement)

                holder.binding.btnScan.visibility = View.VISIBLE
                holder.binding.btnScan.setText(R.string.scan_to_replace)
                holder.binding.btnScan.setOnClickListener {
                    // Open the similar list
                    openSimilarList(item)
                }

                holder.binding.tvShopperStatus.setTextColor(holder.binding.borderView.context.resources.getColor(R.color.colorReplacement))
                holder.binding.tvShopperStatus.setCompoundDrawablesWithIntrinsicBounds(holder.binding.tvItemStatus.context.getDrawable(R.drawable.ic_replaced), null, null, null)
            }
            3 -> { // Refund item
                holder.binding.tvItemStatus.visibility = View.GONE
                holder.binding.tvShopperStatus.visibility = View.VISIBLE
                holder.binding.tvShopperStatus.setText(R.string.refund)

                holder.binding.btnScan.visibility = View.VISIBLE
                holder.binding.btnScan.setText(R.string.refund_item)
                holder.binding.btnScan.setOnClickListener {
                    // Open the Refund Fragment Dialog
                    val refundDialog = RefundDialogFragment.newInstance(item, orderId, FROM_REVIEW_CHANGE)
                    refundDialog.show(activity.supportFragmentManager, RefundDialogFragment.javaClass.name)
                }

                holder.binding.tvShopperStatus.setTextColor(holder.binding.borderView.context.resources.getColor(R.color.colorRefund))
                holder.binding.tvShopperStatus.setCompoundDrawablesWithIntrinsicBounds(holder.binding.tvItemStatus.context.getDrawable(R.drawable.ic_refunded), null, null, null)
            }
            1 -> {
                if (item.isCustomerConfirmedReplace) {
                    holder.binding.tvItemStatus.visibility = View.VISIBLE
                    holder.binding.tvShopperStatus.visibility = View.GONE

                    holder.binding.btnScan.visibility = View.VISIBLE
                    holder.binding.btnScan.setText(R.string.approve)
                    holder.binding.btnScan.setOnClickListener {
                        // Approve the item confirmed by customer
                        approveReplaceItem(item)
                    }
                }
                else{
                    holder.binding.tvShopperStatus.visibility = View.GONE
                    holder.binding.btnScan.visibility = View.GONE
                }
            }
            else -> {
                holder.binding.tvShopperStatus.visibility = View.GONE
                holder.binding.btnScan.visibility = View.GONE
            }
        }
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    private fun setItemStatusLabel(holder : InReviewHolder, item : OrdersItem) : Int{

        if (item.itemShoppingStatus == 2){
            holder.binding.tvItemStatus.visibility = View.VISIBLE

            if (item.replacementRequested != null && item.replacementRequested == 1){
                holder.binding.tvItemStatus.text = activity.getString(R.string.replaced)
//                holder.binding.borderView.setBackgroundColor(holder.binding.borderView.context.resources.getColor(R.color.colorItemDifferent))
                holder.binding.tvItemStatus.setCompoundDrawablesWithIntrinsicBounds(holder.binding.tvItemStatus.context.getDrawable(R.drawable.ic_replaced), null, null, null)
                holder.binding.tvReplaceWithStatus.visibility = View.VISIBLE
                return 5
            }

            if (item.quantityDifference == 1){
                holder.binding.tvItemStatus.text = getHtmlString("<font>" + activity.getString(R.string.qty_diff) + formatter.format(item.itemQty ?: 0))
//                holder.binding.borderView.setBackgroundColor(holder.binding.borderView.context.resources.getColor(R.color.textColor2))
                holder.binding.tvItemStatus.setCompoundDrawablesWithIntrinsicBounds(holder.binding.tvItemStatus.context.getDrawable(R.drawable.ic_refunded), null, null, null)
                holder.binding.tvReplaceWithStatus.visibility = View.GONE
                return 3
            }

            if (item.returnItem != null && item.returnItem == 1){
                holder.binding.tvItemStatus.setText(R.string.refund)
//                holder.binding.borderView.setBackgroundColor(holder.binding.borderView.context.resources.getColor(R.color.textColor2))
                holder.binding.tvItemStatus.setCompoundDrawablesWithIntrinsicBounds(holder.binding.tvItemStatus.context.getDrawable(R.drawable.ic_refunded), null, null, null)
                holder.binding.tvReplaceWithStatus.visibility = View.GONE
                return 9
            }

            holder.binding.tvItemStatus.setText(R.string.not_found)
            holder.binding.tvReplaceWithStatus.visibility = View.GONE
            return 2
        }
        else{
            holder.binding.tvItemStatus.visibility = View.VISIBLE

            if (item.returnItem != null && item.returnItem == 1){
                holder.binding.tvItemStatus.setText(R.string.refund)
                return 9
            }
            else if (item.replacementRequested != null && item.replacementRequested == 1){
                holder.binding.tvItemStatus.text = activity.getString(R.string.replaced)
                return 9
            }
            else if (item.quantityDifference == 1){
                holder.binding.tvItemStatus.text = getHtmlString("<font>" + activity.getString(R.string.qty_diff) + formatter.format(item.itemQty ?: 0))
                return 9
            }
            else{
                holder.binding.tvItemStatus.visibility = View.GONE
            }
        }

        return 0
    }

    private fun setOriginalView(holder : InReviewHolder, item : OrdersItem) {
        if (item.replacementRequested != null && item.replacementRequested == 1){
            holder.binding.rlOriginal.visibility = View.VISIBLE

            // product image
            if (item.oldProductImage != null) {
                GlideApp.with(activity).load(item.oldProductImage).fitCenter()
                    .placeholder(R.drawable.placeholder)
                    .error(R.drawable.placeholder).into(holder.binding.ivOriginalProductImg)
            }

            // Quantity
            holder.binding.tvOldQuantity.text = formatter.format(item.itemQty ?: 0.0)

            // Product name
            holder.binding.tvOriginalProductName.text = item.oldProductName ?: ""

            // Price
            val price = PriceConstructor.getFormatPrice(item, PriceConstructor.LabelType.SIMPLE, PreferenceManager.currency,false)
            holder.binding.tvOriginalPrice.text = getHtmlString(price)

            // Product Description
//            if (item.oldLabelValue != null && item.oldLabelValue!!.isEmpty()){
//                holder.binding.tvPriceDescription.visibility = View.GONE
//            }
//            else{
//                holder.binding.tvPriceDescription.text = item.oldLabelValue
//                holder.binding.tvPriceDescription.visibility = View.VISIBLE
//            }

            holder.binding.oldTvPriceDescription.text = item.getDescriptionLabel()
        }
        else{
            holder.binding.rlOriginal.visibility = View.GONE
        }
    }

    private fun getHtmlString(str : String) : Spanned {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            // FROM_HTML_MODE_LEGACY is the behaviour that was used for versions below android N
            // we are using this flag to give a consistent behaviour
            return Html.fromHtml(str, Html.FROM_HTML_MODE_LEGACY)
        } else {
            return Html.fromHtml(str)
        }
    }

    private fun approveReplaceItem(item : OrdersItem){
        if (item.replacementRequested != null && item.replacementRequested == 1){
            // Approve the replaced item
            var itemQuantity = if (item.itemStatus == 2) item.actualQty else (item.itemQty ?: 0.0)
            if (activity is OrderDetailsActivity){
                activity.confirmReplaceItem(item.ordersOutletsItemsId ?: 0, itemQuantity)
            }
        }
    }

    private fun openSimilarList(item : OrdersItem){
        try {
            var parentViewModel : OrderDetailsViewModel? = null
            if (activity is OrderDetailsActivity){
                parentViewModel = activity.viewModel
            }
            else if (activity is ReviewChangesLatestActivity) {
                parentViewModel = activity.viewModel
            }

            parentViewModel?.shopperSuggestionProductList(item.ordersOutletsItemsId ?: 0, orderId, null, object :
                HandleResponse<SuggestionResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    Toast.makeText(activity, error?.message, Toast.LENGTH_SHORT).show()
                }

                override fun handleSuccessResponse(successResponse: SuggestionResponse) {
                    if (successResponse != null){
                        if (successResponse.httpCode == 200){
                            changeOldItem(successResponse, item)

                            // Go to suggestion product list page
                            val products = arrayListOf<SimilarProduct>()
                            products.addAll(successResponse.similarProducts!!)
                            val oldOutletId = if (item.oldOutletItemId != null && item.oldOutletItemId!!.isNotEmpty()) (item.oldOutletItemId ?: "0.0").toLong() else 0
                            val outletId = if (item.outletItemId != null) item.outletItemId!!.toLong() else 0
                            Navigators.goToSuggestionProductListActivity(activity, products, orderId,
                                if (item.replacementRequested != null && item.replacementRequested == 1) oldOutletId else outletId,
                                item.ordersOutletsItemsId!!, item.itemQty ?: 0.0, item, info, FROM_REVIEW_CHANGE)
                        } else{
                            Toast.makeText(activity, successResponse.message, Toast.LENGTH_SHORT).show()
                        }
                    } else{
                        Toast.makeText(activity, R.string.error_server_return_null, Toast.LENGTH_SHORT).show()
                    }
                }
            })
        }
        catch (e : Exception){
            e.printStackTrace()

            Toast.makeText(activity, R.string.something_went_wrong, Toast.LENGTH_SHORT).show()
        }
    }

    private fun changeOldItem(suggestionResponse : SuggestionResponse, item : OrdersItem) : OrdersItem{
        if (suggestionResponse.similarProducts != null && suggestionResponse.similarProducts.isNotEmpty()){
            val firstItem = suggestionResponse.similarProducts[0]
            if (firstItem.previousShopperSuggestedItem != null && firstItem.previousShopperSuggestedItem.isNotEmpty()){
                val similarProductPrevious = firstItem.previousShopperSuggestedItem[0]
                item.outletItemId = similarProductPrevious.outletItemId
                item.productName = similarProductPrevious.productName
                item.shopperTips = similarProductPrevious.shopperTips
                item.departmentName = similarProductPrevious.departmentName
                item.aisleName = similarProductPrevious.aisleName
                item.soldPer = similarProductPrevious.soldPer ?: 0
                item.soldPerLabel = similarProductPrevious.soldPerLabel
                item.labelValue = similarProductPrevious.labelValue
                item.sizeLabel = similarProductPrevious.sizeLabel
                item.approxWeight = similarProductPrevious.approxWeight ?: 0.0
                item.eachSuffix = similarProductPrevious.eachSuffix
                item.ourSellingPrice = similarProductPrevious.ourSellingPrice ?: 0.0
                item.unit = similarProductPrevious.unit
                item.productImage = similarProductPrevious.productImage
                item.productInfoImage = similarProductPrevious.productInfoImage
                item.barCode = similarProductPrevious.barCode ?: ""
                item.upcType = similarProductPrevious.upcType
            }
        }

        return item
    }

    inner class InReviewHolder(val binding: ItemReviewChangesBinding) :
        RecyclerView.ViewHolder(binding.root)

    interface OnReviewChangesItemClickListener {
        fun onItemClick(item: OrdersItem)

        fun onClickApprove(item: OrdersItem)

        fun onClickMakeChanges(item: OrdersItem)

        fun onItemClickOtherOption(
            activity: Activity,
            item: OrdersItem,
            info: CustomerInfo,
            orderId: Long
        )
    }
}