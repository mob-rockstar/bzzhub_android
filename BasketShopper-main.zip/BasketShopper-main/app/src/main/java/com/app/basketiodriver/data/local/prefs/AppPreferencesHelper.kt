package com.app.basketiodriver.data.local.prefs

import android.content.Context
import android.content.SharedPreferences
import com.app.basketiodriver.data.DataManager
import com.app.basketiodriver.data.model.api.User
import com.app.basketiodriver.di.scoup.PreferenceInfo
import com.app.basketiodriver.utils.AppConstants
import com.google.gson.Gson
import javax.inject.Inject

/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class AppPreferencesHelper @Inject constructor(context: Context, @PreferenceInfo prefFileName: String?) : PreferencesHelper {
    private val mPrefs: SharedPreferences
    override var accessToken: String?
        get() = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI1IiwianRpIjoiNWJiMjY0MThkY2ExMzdhNWJhYTk4YWQxNTQ3YmQ2YWVmMGU4ZDA5MzcxZDQ3MzBjMmEyOTNkMjYwMThkMjc4MDZiOGVmMjQ4MmE5MzYyNmUiLCJpYXQiOjE1ODkxNTE5MzAsIm5iZiI6MTU4OTE1MTkzMCwiZXhwIjoxNTg5MjM4MzMwLCJzdWIiOiI2MjEiLCJzY29wZXMiOltdfQ.hEEbpbSrvmXUtQVtMZ12c7tpPYLzDIhhfQSR614CQEuW81_DMipfa1F-nTb2zjK0wcsT0NBSDqm5BmGtZPpI62D1H_vpD7ZJu80d_aSNNLLdAP-d_3-547huNOCMV8H_jZgiEgIqUw9OXKyPTBamTiXryNgcW2MEHgas7zKTOP22C6DYsO_MnfKp7ncxRQTML1Ingjbhs0pNMt9TWe-NaL0FjQVVlT7O_8Yz6JWHI7VmWM_x7Z19GpJpiEg27acUph7gZwm8PF0ZlC70bZBCDpB2vfPGoK__Yl_egSah0ij62reorPJ03ZGPwYweRs-u5_kMwM07ZvGegSG27eDbu6oJmqlDwxGGxESGG_dCIAcsNkoJUvySjICJ542-UfhpnTOiEuOPLXGiiPL4Pa8ORJ08cSdvEgxKv5gLBmC_h1dLR8iPdzkh_Qee8Hft-YmmGLe5kiwoDkMZL613OvvyKLL9Zj2L4E-l2RUI6gajKWGQRsBxSV3mzSJgL1FkQYJ2OraYHZe0L7Wvh-cpR1kPsOxRccsJcw8_n1GsrMjXhBNWZqd7Ml3eMuVmQbivow-nA3WLR5kDyh2FAKeMbl1uvBaJy0OAflLLxYb2GHrFc3L5FyGxgSJSWvUZtricuAj3OM7xr5jdWbk0b3opmk4XNTaxNynPV8FSTiGgFIHffh8"
        //mPrefs.getString(PREF_KEY_ACCESS_TOKEN, null)
        set(accessToken) {
            mPrefs.edit().putString(PREF_KEY_ACCESS_TOKEN, accessToken).apply()
        }

    // "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIzIiwianRpIjoiNWNiMGRlYzY5Nzg3MWUwYWRmMzIzYzhjZmE4YjczOTkyZjliNzhhNWYwZWNlYTM5ZTFlZTAwYzY2MDNiNjRlMzliNzRlNjIyOWU0ZmE1YjUiLCJpYXQiOjE1ODgzMzA1MTgsIm5iZiI6MTU4ODMzMDUxOCwiZXhwIjoxNTg4NDE2OTE4LCJzdWIiOiI5Iiwic2NvcGVzIjpbXX0.dPE7a3FFDzKMDHPi5NgJDSOHptZvEuQJzOYEeW0kaOCkFm7Zd5qDiuuwOd53X1eB9zRSMXOIMphE7b23RR-VN95R3jVJ68jNxZcQdNq3vepTk4-3nx6YHlbZYEeRcyNjLKdrmU2gcpL1zArr5WoJrydI2jasFZwXdtyY0I9qnQs5k5TYgeRQsj-jF5oVcqihWqTHjupdLp6zfwRBmK-7je-NDiwQJl5Ci6AODeLJYZENr-8BEGHl7tDYbfdDCV_TRoLE1B-3kTuT8-L9iYZ0qqXJxMIDEyVBLzpiK7uhAzv4WD0ZsvFGCQZ6e3gfC0kFHlyqElRonHD1GMTesbwGy0k0UE5VsRAcGwNxoLVcGMdXko-9P1XhoXpe22G1_tsg_cQAafQuYBtCzYE2rOSPHSZsiYot4u0-gkr67cFqx6ZCE0GiCPqFxrBZOjQJrds4r-gwOihT1JIIWAoCqLR-CEKSknmqaMV8P1OURl5jdM7B2X6aVBtKydCybZ9Y-3YkUbPL2DCyhJsy17KxffTy1rzAkDv9N4Idsh39wHyqf_cTbnNbp2SWIPgIpD2XMXaFK1aCWbi3ohhXhrHqjcl9QU4IqY1KOKRqH3DQ_BBTIsknlmgFwBXL3rEIZ8TRVgJnQsSulOnmxf9EoLGiRGj1417V3qvZBmpyD7r4UcT7qb4"
    //   mPrefs.getString(PREF_KEY_ACCESS_TOKEN, null)
    override var currentUser: User?
        get() = Gson().fromJson(mPrefs.getString(PREF_KEY_CURRENT_USER, null), User::class.java)
        set(user) {
            mPrefs.edit().putString(PREF_KEY_CURRENT_USER, Gson().toJson(user)).apply()
        }

    override var currentUserLanguage: String
        get() = mPrefs.getString(PREF_KEY_CURRENT_USER_LANGUAGE, AppConstants.ENGLISH)!!
        set(lang) {
            mPrefs.edit().putString(PREF_KEY_CURRENT_USER_LANGUAGE, lang).commit()
        }


    override var deviceId: String?
        get() = mPrefs.getString(PREF_KEY_DEVICE_ID, null)!!
        set(deviceId) {
            mPrefs.edit().putString(PREF_KEY_DEVICE_ID, deviceId).commit()
        }


    override var deviceToken: String?
        get() = mPrefs.getString(PREF_KEY_DEVICE_TOKEN, null)!!
        set(deviceToken) {
            mPrefs.edit().putString(PREF_KEY_DEVICE_TOKEN, deviceToken).commit()
        }

    override fun getCurrentUserLoggedInMode(): Int {
        return mPrefs.getInt(PREF_KEY_USER_LOGGED_IN_MODE,
                DataManager.LoggedInMode.LOGGED_IN_MODE_LOGGED_OUT.type)
    }

    override fun setCurrentUserLoggedInMode(mode: DataManager.LoggedInMode) {
        mPrefs.edit().putInt(PREF_KEY_USER_LOGGED_IN_MODE, mode.type).commit()
    }





    companion object {
        private const val PREF_KEY_ACCESS_TOKEN = "PREF_KEY_ACCESS_TOKEN"
        private const val PREF_KEY_CURRENT_USER = "PREF_KEY_CURRENT_USER"
        private const val PREF_KEY_CURRENT_USER_LANGUAGE = "PREF_KEY_USER_LANGUAGE"

        private const val PREF_KEY_USER_LOGGED_IN_MODE = "PREF_KEY_USER_LOGGED_IN_MODE"
        private const val PREF_KEY_DEVICE_TOKEN = "device_token"
        private const val PREF_KEY_DEVICE_ID = "device_id"
    }

    init {
        mPrefs = context.getSharedPreferences(prefFileName, Context.MODE_PRIVATE)
    }
}