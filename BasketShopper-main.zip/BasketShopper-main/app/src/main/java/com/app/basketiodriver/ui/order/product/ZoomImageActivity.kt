package com.app.basketiodriver.ui.order.product

import android.os.Bundle
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.checkout.CustomerInfo
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.databinding.ActivityZoomImageBinding
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.app.basketiodriver.utils.GlideApp

class ZoomImageActivity : BaseActivity<ActivityZoomImageBinding, OrderDetailsViewModel>() {
    override val layoutId: Int
        get() = R.layout.activity_zoom_image

    override val viewModel: OrderDetailsViewModel
        get() {
            return getViewModel(OrderDetailsViewModel::class.java)
        }

    var imageURL : String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (intent.extras != null){
            imageURL = intent.extras!!.getString("ARG_URL", "")
        }

        if (imageURL != ""){
            // Display the product image
            GlideApp.with(this).load(imageURL).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(viewDataBinding!!.ivFullImage)
        }

        // Close
        viewDataBinding!!.ivClose.setOnClickListener {
            finish()
        }
    }
}