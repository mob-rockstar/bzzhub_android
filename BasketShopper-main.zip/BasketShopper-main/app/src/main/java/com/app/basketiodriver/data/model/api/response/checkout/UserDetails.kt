package com.app.basketiodriver.data.model.api.response.checkout

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName


class UserDetails {
    @SerializedName("user_id")
    @Expose
    val userId: Int? = null

    @SerializedName("user_first_name")
    @Expose
    val userFirstName: String? = null

    @SerializedName("user_last_name")
    @Expose
    val userLastName: String? = null

    @SerializedName("user_image")
    @Expose
    val userImage: String? = null

    @SerializedName("user_mobile")
    @Expose
    val userMobile: String? = null

    @SerializedName("call_before_checkout")
    @Expose
    val callBeforeCheckout : Int = 0

    @SerializedName("user_city")
    @Expose
    val userCity: String? = null

    @SerializedName("user_location")
    @Expose
    val userLocation: String? = null

    @SerializedName("user_latitude")
    @Expose
    val userLatitude: String? = null

    @SerializedName("user_longitude")
    @Expose
    val userLongitude: String? = null

    @SerializedName("delivery_instructions")
    @Expose
    val deliveryInstructions: String? = null

    @SerializedName("user_google_address")
    @Expose
    val userGoogleAddress: String? = null

    @SerializedName("user_address_type")
    @Expose
    val userAddressType: String? = null

    @SerializedName("user_department_building")
    @Expose
    val userDepartmentBuilding: String? = null

    @SerializedName("user_additional_info")
    @Expose
    val userAdditionalInfo: String? = null

    @SerializedName("user_near_landmark")
    @Expose
    val userNearLandmark: String? = null
}