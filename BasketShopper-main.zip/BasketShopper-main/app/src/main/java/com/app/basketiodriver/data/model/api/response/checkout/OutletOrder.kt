package com.app.basketiodriver.data.model.api.response.checkout

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName
import java.io.Serializable


class OutletOrder : Serializable {
    @SerializedName("id")
    @Expose
    var id: Long? = null

    @SerializedName("is_express")
    @Expose
    var isExpress: Int = 0

    @SerializedName("outlet_id")
    @Expose
    var outletId: Long? = null

    @SerializedName("order_id")
    @Expose
    val orderId: Long? = null

    @SerializedName("outlet_name")
    @Expose
    val outletName: String? = null

    @SerializedName("updated_date")
    @Expose
    val updatedDate: String? = null

    @SerializedName("delivery_date")
    @Expose
    val deliveryDate: String? = null

    @SerializedName("delivery_instructions")
    @Expose
    val deliveryInstructions: String? = null

    @SerializedName("delivery_slot")
    @Expose
    val deliverySlot: String? = null

    @SerializedName("delivery_charge")
    @Expose
    val deliveryCharge: Double? = null

    @SerializedName("under_threshold_amount")
    @Expose
    val underThresholdAmount: Double? = null

    @SerializedName("service_fee")
    @Expose
    val service_fee: Double? = null

    @SerializedName("promo_total_amount")
    @Expose
    val promoTotalAmount: Double? = null

    @SerializedName("one_hr_fee")
    @Expose
    val oneHrFee: Double? = null

    @SerializedName("item_tax_amount")
    @Expose
    val itemTaxAmount: Double? = null

    @SerializedName("service_tax")
    @Expose
    val serviceTax: Double? = null

    @SerializedName("free_delivery_discount")
    @Expose
    val freeDeliveryDiscount: Double? = null

    @SerializedName("item_total_amount")
    @Expose
    val itemTotalAmount: String? = null

    @SerializedName("overall_total_amount")
    @Expose
    val overallTotalAmount: Double? = null

    @SerializedName("vendor_id")
    @Expose
    val vendorId: Long? = null

    @SerializedName("logo_image")
    @Expose
    val logoImage: String? = null

    @SerializedName("user_mobile")
    @Expose
    val userMobile: String? = null

    @SerializedName("call_before_checkout")
    @Expose
    val callBeforeCheckout = 0

    @SerializedName("delivery_day")
    @Expose
    val deliveryDay: String? = null

    @SerializedName("payment_gateway_id")
    @Expose
    val paymentGatewayId // 18 =cash 24 =credit card
            : Int? = null

    @SerializedName("payment_status")
    @Expose
    val paymentStatus : Int? = null // 0 = unpaid 1 = paid

    @SerializedName("payment_gateway_name")
    @Expose
    val paymentGatewayName: String? = null

    @SerializedName("vendor_logo")
    @Expose
    val vendorLogo: String? = null

    @SerializedName("todo_orders_items")
    @Expose
    val todoOrdersItems: List<OrdersItem> = arrayListOf()

    @SerializedName("pending_orders_items")
    @Expose
    val pendingOrdersItems: List<OrdersItem> = arrayListOf()

    @SerializedName("done_orders_items")
    @Expose
    val doneOrdersItems: List<OrdersItem> = arrayListOf()

    @SerializedName("orders_items")
    @Expose
    val ordersItems: List<OrdersItem> = arrayListOf()

    @SerializedName("total_items_count")
    @Expose
    val totalItemsCount: Int = 0

    @SerializedName("todo_items_count")
    @Expose
    val todoItemsCount: Int = 0

    @SerializedName("pending_items_count")
    @Expose
    val pendingItemsCount: Int = 0

    @SerializedName("done_items_count")
    @Expose
    val doneItemsCount: Int = 0

    @SerializedName("final_total_amount")
    @Expose
    val finalTotal: Double? = null

    @SerializedName("total")
    @Expose
    val total: Double? = null

    @SerializedName("subtotal")
    @Expose
    var subtotal: Double? = null

    @SerializedName("subtotal_adjustment")
    @Expose
    val subtotalAdjustment: Double? = null

    @SerializedName("user_first_name")
    @Expose
    val userFirstName: String? = null

    @SerializedName("user_id")
    @Expose
    val userId: String? = null

    @SerializedName("user_last_name")
    @Expose
    val userLastName: String? = null

    @SerializedName("user_location")
    @Expose
    val userLocation: String? = null

    @SerializedName("user_image")
    @Expose
    val userImage: String? = null

    @SerializedName("user_google_address")
    @Expose
    val userGoogleAddress: String? = null

    @SerializedName("user_address_type")
    @Expose
    val userAddressType: String? = null

    @SerializedName("user_department_building")
    @Expose
    val userDepartmentBuilding: String? = null

    @SerializedName("user_additional_info")
    @Expose
    val userAdditionalInfo: String? = null

    @SerializedName("user_near_landmark")
    @Expose
    val userNearLandmark: String? = null

    @SerializedName("sorting_enable")
    @Expose
    val isSortingEnable: Int = 0

    @SerializedName("shopped_by")
    @Expose
    val shopped_by: Int? = null


    @SerializedName("delivered_by")
    @Expose
    val delivered_by: Int? = null

    @SerializedName("store_instruction")
    @Expose
    val storeInstruction: String? = null
}