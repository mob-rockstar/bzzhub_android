package com.app.basketiodriver.ui.cardcamera.cropper2

import android.content.Context
import android.graphics.Bitmap
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.FrameLayout
import android.widget.ImageView
import com.app.basketiodriver.R

class CropImageView : FrameLayout {
    private var mImageView: ImageView? = null
    private var mCropOverlayView: CropOverlayView? = null

    constructor(context: Context) : super(context)
    constructor(
        context: Context,
        attrs: AttributeSet?
    ) : super(context, attrs) {
        val inflater = LayoutInflater.from(context)
        val v = inflater.inflate(R.layout.crop_image_view, this, true)
        mImageView = v.findViewById(R.id.ImageView_image)
        mCropOverlayView = v.findViewById(R.id.CropOverlayView)
    }

    fun setImageBitmap(bitmap: Bitmap?) {
        mImageView!!.setImageBitmap(bitmap)
        mCropOverlayView!!.setBitmap(bitmap)
    }

    fun crop(listener: CropListener, needStretch: Boolean) {
        mCropOverlayView!!.crop(listener, needStretch)
    }
}