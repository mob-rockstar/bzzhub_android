package com.app.basketiodriver.ui.home.fragments

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.View
import androidx.fragment.app.Fragment
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.DialogChangeItemImageBinding
import com.app.basketiodriver.databinding.DialogChangeMapBinding
import com.app.basketiodriver.databinding.FragmentSettingsBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.dashbaord.IncomingFragment
import com.app.basketiodriver.ui.home.HomeActivity
import com.app.basketiodriver.ui.home.HomeViewModel
import com.app.basketiodriver.ui.settings.PrivacyActivity
import com.app.basketiodriver.ui.settings.ReportedIssuesActivity
import com.app.basketiodriver.ui.settings.SoftwareLicensingActivity
import com.app.basketiodriver.ui.settings.TermsActivity
import zendesk.chat.ChatEngine
import zendesk.messaging.MessagingActivity


/**
 * A simple [Fragment] subclass.
 */
class SettingsFragment  : BaseFragment<FragmentSettingsBinding?, HomeViewModel>(),
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_settings

    override val viewModel: HomeViewModel
        get() {
            return getViewModel(requireActivity(), HomeViewModel::class.java)
        }

    companion object {

        fun newInstance(
        ): IncomingFragment {
            val fragment = IncomingFragment()

            return fragment
        }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_info, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setHasOptionsMenu(true)
        viewDataBinding?.btnChangeMap?.setOnClickListener { showChangeMap() }
        viewDataBinding?.btnCheckReportedIssues?.setOnClickListener {
            startActivity(
                ReportedIssuesActivity.newIntent(requireContext())
            )
        }
        viewDataBinding?.btnPrivacyPolicy?.setOnClickListener {
            startActivity(
                PrivacyActivity.newIntent(
                    requireContext()
                )
            )
        }
        viewDataBinding?.btnTerms?.setOnClickListener {
            startActivity(
                TermsActivity.newIntent(
                    requireContext()
                )
            )
        }
        viewDataBinding?.btnSoftwareLicenses?.setOnClickListener {
            startActivity(
                SoftwareLicensingActivity.newIntent(requireContext())
            )
        }

        // Contact us
        viewDataBinding?.btnContactUs?.setOnClickListener {
           // open Zendesk ChatBot
            try {
                (requireActivity() as HomeActivity).chatWithSupport()
            }
            catch (exception : Exception){
                print(exception.printStackTrace())
            }
        }
    }

    fun showChangeItemImage() {
        val dialog = Dialog(requireContext(), R.style.PauseDialog)
        val binding = DialogChangeItemImageBinding.inflate(LayoutInflater.from(requireContext()))
        dialog.setContentView(binding.root)
        dialog.setCanceledOnTouchOutside(true)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        binding.btnOkay.setOnClickListener {
            dialog.dismiss()

        }

        dialog.show()
    }

    fun showChangeMap() {
        val dialog = Dialog(requireContext(), R.style.PauseDialog)
        val binding = DialogChangeMapBinding.inflate(LayoutInflater.from(requireContext()))
        dialog.setContentView(binding.root)
        dialog.setCanceledOnTouchOutside(true)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        binding.btnCancel.setOnClickListener {
            dialog.dismiss()

        }

        dialog.show()
    }
}
