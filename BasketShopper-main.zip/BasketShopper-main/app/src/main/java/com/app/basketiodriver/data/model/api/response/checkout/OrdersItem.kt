package com.app.basketiodriver.data.model.api.response.checkout

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import java.io.Serializable
import java.util.*


class OrdersItem : Serializable {
    @SerializedName("orders_outlets_items_id")
    @Expose
    val ordersOutletsItemsId: Long? = null

    @SerializedName("outlet_item_id")
    @Expose
    var outletItemId: Int? = null

    @SerializedName("product_name")
    @Expose
    var productName: String? = null

    @SerializedName("shopper_tips")
    @Expose
    var shopperTips: String? = null

    @SerializedName("order_status")
    @Expose
    val orderStatus: Int? = null

    @SerializedName("department_name")
    @Expose
    var departmentName: String? = null

    @SerializedName("aisle_name")
    @Expose
    var aisleName: String? = null

    @SerializedName("department_aisle_name")
    @Expose
    var departmentAisle: String? = null

    @SerializedName("item_qty")
    @Expose
    val itemQty: Double? = null

    @SerializedName("weight")
    @Expose
    val weight: Int? = null

    @SerializedName("sold_per")
    @Expose
    var soldPer : Int = 2

    @SerializedName("old_sold_per")
    @Expose
    var oldSoldPer: String? = null

    @SerializedName("sold_per_label")
    @Expose
    var soldPerLabel: String? = null

    @SerializedName("label_value")
    @Expose
    var labelValue: String? = null

    @SerializedName("old_label_value")
    @Expose
    var oldLabelValue: String? = null

    @SerializedName("size_label")
    @Expose
    var sizeLabel: Int? = null

    @SerializedName("approx_weight")
    @Expose
    var approxWeight: Double = 0.0

    @SerializedName("actual_approx_weight")
    @Expose
    var actualApproxWeight: Double = 0.0

    @SerializedName("old_approx_weight")
    @Expose
    var oldApproxWeight: String = "0.0"

    @SerializedName("each_suffix")
    @Expose
    var eachSuffix: Int? = null

    @SerializedName("old_each_suffix")
    @Expose
    var oldEachSuffix: String? = null

    @SerializedName("our_selling_price")
    @Expose
    var ourSellingPrice: Double = 0.0

    @SerializedName("old_our_selling_price")
    @Expose
    var oldSellingPrice: String = "0.0"

    @SerializedName("unit")
    @Expose
    var unit: String? = ""

    @SerializedName("old_unit")
    @Expose
    var oldUnit: String? = ""

    @SerializedName("product_image")
    @Expose
    var productImage: String? = null

    @SerializedName("product_info_image")
    @Expose
    var productInfoImage: String? = null

    @SerializedName("bar_code")
    @Expose
    var barCode: String = ""

    @SerializedName("has_replacement")
    @Expose
    val hasReplacement: Int? = null

    @SerializedName("old_bar_code")
    @Expose
    var oldBarCode: String? = null

    @SerializedName("old_product_info_image")
    @Expose
    val oldProductInfoImage: String? = null

    @SerializedName("old_product_image")
    @Expose
    var oldProductImage: String? = null

    @SerializedName("old_product_name")
    @Expose
    var oldProductName: String? = null

    @SerializedName("old_outlet_item_id")
    @Expose
    var oldOutletItemId: String? = null

    @SerializedName("item_status")
    @Expose
    var itemStatus = 0

    @SerializedName("item_status_label")
    @Expose
    val itemStatusLabel: String? = null

    @SerializedName("item_found")
    @Expose
    val itemFound: Int? = null

    @SerializedName("quantity_difference")
    @Expose
    var quantityDifference = 1

    @SerializedName("quantity_difference_approved")
    @Expose
    var quantityDifferenceApproved: Int? = null

    @SerializedName("price_difference_reported")
    @Expose
    val priceDifferenceReported: Int? = null

    @SerializedName("price_difference_approved")
    @Expose
    val priceDifferenceApproved: Int? = null

    @SerializedName("replacement_requested")
    @Expose
    var replacementRequested: Int? = null

    @SerializedName("replacement_fullfilled")
    @Expose
    var replacementFullfilled: Int? = null

    @SerializedName("return_item")
    @Expose
    var returnItem: Int? = null

    @SerializedName("item_shopping_status")
    @Expose
    var itemShoppingStatus: Int = 0

    @SerializedName("actual_qty")
    @Expose
    var actualQty = 1.0

    @SerializedName("actual_selling_price")
    @Expose
    val actualSellingPrice: Double? = null

    @SerializedName("customer_item_notes")
    @Expose
    var customerItemNotes: String? = null

    @SerializedName("added_by")
    @Expose
    val addedBy: Int = 0

    @SerializedName("master_location_weight")
    @Expose
    var masterLocationWeight: Int? = null

    @SerializedName("location_weight")
    @Expose
    var locationWeight: Int? = null

    @SerializedName("sub_location_weight")
    @Expose
    var subLocationWeight: Int? = null

    @SerializedName("master_location_name")
    @Expose
    var masterLocationName: String? = null

    @SerializedName("location_name")
    @Expose
    var locationName: String? = null

    @SerializedName("sub_location_name")
    @Expose
    var subLocationName: String? = null

    @SerializedName("old_size_label")
    @Expose
    val oldSizeLabel: String? = null

    @SerializedName("customer_suggestion_type")
    @Expose
    val customerSuggestionType: Int = 0

    @SerializedName("upc_type")
    @Expose
    var upcType: Int? = null

    @SerializedName("upc")
    @Expose
    var upc: String = ""

    @SerializedName("item_type")
    @Expose
    var item_type: Int? = null

    @SerializedName("customer_replacement_suggestion_id")
    @Expose
    val customerReplacementSuggestionId: Int? = null

    @SerializedName("custom_additional_question")
    @Expose
    val customAdditionalQuestion: String = ""

    @SerializedName("custom_additional_question_amount")
    @Expose
    val customAdditionalQuestionAmount: Double = 0.0

    @SerializedName("replacement_item_list")
    @Expose
    var replacementItemList : List<OrdersReplacementItem> = arrayListOf()

    // Flag to check if customer confirmed the replacement item
    var isCustomerConfirmedReplace : Boolean = false

    // Approved item by customer
    var approvedReplaceItem : OrdersReplacementItem? = null

    fun getDescriptionLabel() : String {
        return try {
            when (soldPer) {
                1 -> if (labelValue != null) String.format(Locale("en"), "%s %s", labelValue, unit) else " each"
                2 -> "per kg"
                3 -> if (itemStatus < 3) String.format(Locale("en"), "%s %s each", approxWeight, unit)
                     else String.format(Locale("en"), "%s %s each", if (actualApproxWeight > 0) actualApproxWeight else approxWeight, unit)
                else -> "each"
            }
        } catch (e: Exception) {
            e.printStackTrace()
            "each"
        }
    }

    fun getDescriptionLabelNew() : String {
        return try {
            when (soldPer) {
                1 -> if (labelValue != null) String.format(Locale("en"), "%s %s", labelValue, unit) else " each"
                2 -> "per kg"
                3 -> if (itemStatus < 3) String.format(Locale("en"), "around %s %s each", approxWeight, unit)
                else String.format(Locale("en"), "around %s %s each", if (actualApproxWeight > 0) actualApproxWeight else approxWeight, unit)
                else -> "each"
            }
        } catch (e: Exception) {
            e.printStackTrace()
            " each"
        }
    }

    fun getDescriptionLabelOld() : String {
        return try {
            when (soldPer) {
                1 -> if (oldLabelValue != null && oldUnit != null) String.format(Locale("en"), " %s %s", oldLabelValue, oldUnit) else "each"
                2 -> "per kg"
                3 -> if (itemStatus < 3 && oldUnit != null &&  oldApproxWeight != null) String.format(Locale("en"), " %s %s each", oldApproxWeight, oldUnit)
                else String.format(Locale("en"), " %s %s each", oldApproxWeight, oldUnit)
                else -> " each"
            }
        } catch (e: Exception) {
            e.printStackTrace()
            " each"
        }
    }
}