package com.app.basketiodriver.ui.howdoing.fragments

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentRatingsBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.howdoing.HowIamDoingViewModel
import com.app.basketiodriver.ui.howdoing.adapters.RemovedRatingsAdapter
import com.app.basketiodriver.ui.utils.ViewPagerAdapter
import com.app.basketiodriver.ui.weekhours.fragments.HoursWeekFragment
import com.google.android.material.tabs.TabLayout


/**
 * A simple [Fragment] subclass.
 */
class RatingsFragment : BaseFragment<FragmentRatingsBinding?, HowIamDoingViewModel>(),
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_ratings

    override val viewModel: HowIamDoingViewModel
        get() {
            return getViewModel(requireActivity(), HowIamDoingViewModel::class.java)
        }

    lateinit var ratingsPagerAdapter: ViewPagerAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.ratings))

        initUI()
    }

    private fun initUI(){
        // Init TabLayout
        initTabLayout()
    }

    private fun initTabLayout(){

        // Init the Ratings Adapter
        ratingsPagerAdapter = ViewPagerAdapter(childFragmentManager)
        ratingsPagerAdapter.setFragments(
            RatingThisWeekFragment.newInstance("Week"),
            RatingThisWeekFragment.newInstance("LastMonth")
        )
        ratingsPagerAdapter.setTitles(getString(R.string.tab_this_week), getString(R.string.tab_last_30days))
        viewDataBinding!!.viewpager.adapter = ratingsPagerAdapter

        viewDataBinding!!.tabLayout.tabGravity = TabLayout.GRAVITY_FILL
        viewDataBinding!!.tabLayout.setupWithViewPager(viewDataBinding!!.viewpager)
        viewDataBinding!!.tabLayout.setOnTabSelectedListener(object :
            TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                viewDataBinding!!.viewpager.currentItem = tab.position
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
    }

}
