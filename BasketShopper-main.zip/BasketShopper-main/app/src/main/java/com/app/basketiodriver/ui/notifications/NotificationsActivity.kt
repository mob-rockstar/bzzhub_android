package com.app.basketiodriver.ui.notifications

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.Navigation
import com.app.basketiodriver.R
import com.app.basketiodriver.ui.base.BaseActivity
import dagger.android.DispatchingAndroidInjector
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.notification.NotificationListData
import com.app.basketiodriver.data.model.api.response.notification.NotificationResponse
import com.app.basketiodriver.databinding.ActivityNotificationsBinding
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.notifications.adapter.NotificationListAdapter
import dagger.android.HasAndroidInjector
import javax.inject.Inject

class NotificationsActivity : BaseActivity<ActivityNotificationsBinding?, NotificationsViewModel>() {

    override val layoutId: Int
        get() = R.layout.activity_notifications

    override val viewModel: NotificationsViewModel
        get() {
            return getViewModel(NotificationsViewModel::class.java)
        }

    lateinit var notificationListAdapter: NotificationListAdapter

    var notificationList : List<NotificationListData> = arrayListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        initToolbar(getString(R.string.fab_notifications),
            true, viewDataBinding!!.layoutToolBar.toolbar,
            View.OnClickListener {
                run {
                    finish()
                }
            })

        setupUI()

        // Load the notifications
        getNotificationList()
    }

    private fun setupUI(){
        // Init the RecyclerView
        viewDataBinding!!.recyclerView.layoutManager = LinearLayoutManager(this)
        viewDataBinding!!.recyclerView.setHasFixedSize(true)

        // Refresh Layout
        viewDataBinding!!.refreshLayout.setOnRefreshListener {
            getNotificationList()
        }
    }

    // Get the notification list
    private fun getNotificationList(){
        viewDataBinding!!.refreshLayout.isRefreshing = true

        try {
            viewModel.getNotificationList(object : HandleResponse<NotificationResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    viewDataBinding!!.refreshLayout.isRefreshing = false
                    if (isNetworkConnected){
                        Toast.makeText(this@NotificationsActivity, error?.message, Toast.LENGTH_LONG).show()
                    }
                    else{
                        Toast.makeText(this@NotificationsActivity, resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                    }
                    viewDataBinding!!.txtNoNotification.visibility = View.VISIBLE
                }

                override fun handleSuccessResponse(successResponse: NotificationResponse) {
                    viewDataBinding!!.refreshLayout.isRefreshing = false

                    val response = successResponse.response
                    if (response != null){
                        if (response.httpCode == 200){
                            if (response.notificationListData != null){
                                notificationList = response.notificationListData
                                refreshNotificationList()
                            }
                            else{
                                Toast.makeText(this@NotificationsActivity, response.message, Toast.LENGTH_SHORT).show()
                            }
                        }
                        else{
                            Toast.makeText(this@NotificationsActivity, response.message, Toast.LENGTH_SHORT).show()
                            viewDataBinding!!.txtNoNotification.visibility = View.VISIBLE
                        }
                    }
                    else{
                        Toast.makeText(this@NotificationsActivity, R.string.error_server_return_null, Toast.LENGTH_SHORT).show()
                        viewDataBinding!!.txtNoNotification.visibility = View.VISIBLE
                    }
                }
            })
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    // Refresh recyclerview
    private fun refreshNotificationList(){

        if (notificationList.isNotEmpty()){
            viewDataBinding!!.txtNoNotification.visibility = View.GONE

            // Set the adapter
            notificationListAdapter = NotificationListAdapter(this, notificationList)
            viewDataBinding!!.recyclerView.adapter = notificationListAdapter
        }
        else{
            viewDataBinding!!.txtNoNotification.visibility = View.VISIBLE
        }
    }

    companion object {
        fun newIntent(context: Context?): Intent {
            return Intent(context, NotificationsActivity::class.java)
        }
    }
}