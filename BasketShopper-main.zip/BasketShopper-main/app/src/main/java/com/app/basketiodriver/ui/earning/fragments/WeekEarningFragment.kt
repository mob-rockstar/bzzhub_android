package com.app.basketiodriver.ui.earning.fragments


import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.earning.monthly.ReportView
import com.app.basketiodriver.data.model.api.response.earning.monthly.ShopperDetailsReportData
import com.app.basketiodriver.data.model.api.response.earning.monthly.ShopperDetailsReportResponse
import com.app.basketiodriver.databinding.FragmentWeekEarningBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.earning.EarningViewModel
import com.app.basketiodriver.ui.earning.adapters.WeeklyEarningAdapter
import com.app.basketiodriver.ui.earning.fragments.WeekEarningFragmentArgs.fromBundle
import com.app.basketiodriver.utils.AppConstants
import com.app.basketiodriver.utils.CommonUtils
import com.app.basketiodriver.utils.InfoHelp
import com.app.basketiodriver.utils.OnItemClickedListener
import com.tbruyelle.rxpermissions2.RxPermissions
import io.reactivex.android.schedulers.AndroidSchedulers
import java.util.*
import kotlin.collections.ArrayList


/**
 * A simple [Fragment] subclass.
 */
class WeekEarningFragment : BaseFragment<FragmentWeekEarningBinding?, EarningViewModel>(),
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_week_earning

    override val viewModel: EarningViewModel
        get() {
            return getViewModel(baseActivity as FragmentActivity, EarningViewModel::class.java)
        }

    // Yearly Balance Report
    val yearReportItem by lazy {
        fromBundle(arguments!!).shopperReportItem
    }

    // Review item
    val reviewItem by lazy {
        fromBundle(arguments!!).reportViewItem
    }

    // Week Number
    var weekNum = 1

    var reportViewArray : ArrayList<ReportView> = arrayListOf()
    private lateinit var reportViewAdapter : WeeklyEarningAdapter


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (arguments != null){
            weekNum = fromBundle(arguments!!).weekNum.toInt()
        }

        initUI()

        // Get weekly report details
        getShopperWeeklyReport()
    }

    private fun initUI(){
        // Set title
        setTitle(reviewItem.week_name)

        // Set tooltips
        viewDataBinding!!.txtBonusLabel.setOnClickListener {
            InfoHelp.showHelpDialog(it, baseActivity?.resources?.getString(R.string.total_bonuses_get)!!, baseActivity as Activity, false)
        }

        viewDataBinding!!.txtDeductions.setOnClickListener {
            InfoHelp.showHelpDialog(it, baseActivity?.resources?.getString(R.string.total_deductions)!!, baseActivity as Activity, false)
        }

        viewDataBinding!!.txtWeekEarning.setOnClickListener {
            InfoHelp.showHelpDialog(it, baseActivity?.resources?.getString(R.string.total_earning_this_week)!!, baseActivity as Activity, false)
        }

        viewDataBinding!!.txtCurrentBalance.setOnClickListener{
            InfoHelp.showHelpDialog(it, baseActivity?.resources?.getString(R.string.your_current_balance)!!, baseActivity as Activity, true)
        }

        // Init RecyclerManager
        val linearLayoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        viewDataBinding!!.recyclerView.layoutManager = linearLayoutManager
        viewDataBinding!!.recyclerView.setHasFixedSize(true)

        reportViewAdapter = WeeklyEarningAdapter(baseActivity as Activity, "weekly", object :
            OnItemClickedListener<ReportView> {
            override fun onClicked(item: ReportView) {
                // Go to daily report
                val day = item.day_name.substring(9,11).toInt()
                navigate(WeekEarningFragmentDirections.actionWeekEarningFragmentToDayEarningFragment(item, yearReportItem))
            }
        })

        // Get Help
        viewDataBinding!!.btnHelp.setOnClickListener {
            getHelp()
        }
    }

    private fun getShopperWeeklyReport(){
        val month : Int = if (yearReportItem != null) yearReportItem.monthNumber else Calendar.getInstance().get(
            Calendar.MONTH)
        val year : Int = if (yearReportItem != null) yearReportItem.year.toInt() else Calendar.getInstance().get(
            Calendar.YEAR)

        viewModel.getShopperDetailsReport(month, year, "weekly", weekNum, object :
            HandleResponse<ShopperDetailsReportResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Toast.makeText(baseActivity, error?.message, Toast.LENGTH_SHORT).show()
                }else{
                    Toast.makeText(baseActivity, baseActivity!!.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }
            }

            override fun handleSuccessResponse(successResponse: ShopperDetailsReportResponse) {
                if (successResponse.data != null){
                    updateUI(successResponse.data)
                }
                else{
                    Toast.makeText(baseActivity, successResponse.message, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    // Update the reports
    private fun updateUI(detailData: ShopperDetailsReportData){
        if (detailData.is_account_suspended) {
            viewDataBinding!!.suspendedLL.visibility = View.VISIBLE
        }
        else{
            viewDataBinding!!.suspendedLL.visibility = View.GONE
        }

        // this week balance
        val weekEarning = PreferenceManager.currency + " " + detailData.total_balance
        viewDataBinding!!.txtTotalWeekEarning.text = weekEarning
        CommonUtils.setBalanceTextColor(viewDataBinding!!.txtTotalWeekEarning, "" + detailData.total_balance)

        // Current Balance
        val currBalance = PreferenceManager.currency + " " + detailData.current_account_balance
        viewDataBinding!!.currentBalanceValue.text = currBalance
        CommonUtils.setBalanceTextColor(viewDataBinding!!.currentBalanceValue, "" + detailData.current_account_balance)

        // Shopping Earning
        val shoppingEarning = PreferenceManager.currency + " " + detailData.total_shopping_earning
        viewDataBinding!!.txtShoppingEarningsValue.text = shoppingEarning
        CommonUtils.setBalanceTextColor(viewDataBinding!!.txtShoppingEarningsValue, "" + detailData.total_shopping_earning)

        // Delivery Earning
        val deliveryEarning = PreferenceManager.currency + " " + detailData.total_delivery_earning
        viewDataBinding!!.txtDeliveryEarningsValue.text = deliveryEarning
        CommonUtils.setBalanceTextColor(viewDataBinding!!.txtDeliveryEarningsValue, "" + detailData.total_delivery_earning)

        // Bonus
        val bonus = PreferenceManager.currency + " " + detailData.total_bonus
        viewDataBinding!!.txtBonusEarningsValue.text = bonus
        CommonUtils.setBalanceTextColor(viewDataBinding!!.txtBonusEarningsValue, "" + detailData.total_bonus)

        // Deductions
        val deductions = PreferenceManager.currency + " " + detailData.total_deduction
        viewDataBinding!!.txtBonusDeductionsValue.text = deductions
        CommonUtils.setBalanceTextColor(viewDataBinding!!.txtBonusDeductionsValue, "" + detailData.total_deduction)

        // weekly earning
        val earning = PreferenceManager.currency + " " + detailData.total_earnings
        viewDataBinding!!.txtWeekEarningValue.text = earning
        CommonUtils.setBalanceTextColor(viewDataBinding!!.txtWeekEarningValue, "" + detailData.total_earnings)

        // Collected from customer
        val collected = PreferenceManager.currency + " " + detailData.total_collected
        viewDataBinding!!.txtCollectionValue.text = collected
        CommonUtils.setBalanceTextColor(viewDataBinding!!.txtCollectionValue, "" + detailData.total_collected)

        val extra = detailData.total_extra_amount_with_shopper.toDouble()
        val extraEarning = PreferenceManager.currency + " " + detailData.total_extra_amount_with_shopper
        when {
            extra < 0 -> {
    //            val str = baseActivity?.resources?.getString(R.string.your_own_basket) + " " + PreferenceManager.currency + " " + detailData.total_extra_amount_with_shopper
    //            viewDataBinding!!.txtExtra.text = str
    //
    //            val startIdx = baseActivity?.resources?.getString(R.string.your_own_basket)!!.length + 1
    //            val endIdx = startIdx + PreferenceManager.currency!!.length + detailData.total_extra_amount_with_shopper.length + 1
    //
    //            val wordToSpan = SpannableString(str)
    //            wordToSpan.setSpan(ForegroundColorSpan(baseActivity?.resources?.getColor(R.color.item_not_found_color)!!), startIdx, endIdx, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
    //            viewDataBinding!!.txtExtra.text = wordToSpan

                viewDataBinding!!.txtExtraTitle.text = baseActivity!!.resources.getString(R.string.your_own_basket)
                viewDataBinding!!.txtExtra.text = extraEarning
                CommonUtils.setBalanceTextColor(viewDataBinding!!.txtExtra, "" + detailData.total_extra_amount_with_shopper)
            }
            extra > 0 -> {
    //            val str = baseActivity?.resources?.getString(R.string.baskets_own_you) + " " + PreferenceManager.currency + " " + detailData.total_extra_amount_with_shopper
    //            viewDataBinding!!.txtExtra.text = str
    //
    //            val startIdx = baseActivity?.resources?.getString(R.string.baskets_own_you)!!.length + 1
    //            val endIdx = startIdx + PreferenceManager.currency!!.length + detailData.total_extra_amount_with_shopper.length + 1
    //
    //            val wordToSpan = SpannableString(str)
    //            wordToSpan.setSpan(ForegroundColorSpan(baseActivity?.resources?.getColor(R.color.colorPrimary)!!), startIdx, endIdx, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
    //            viewDataBinding!!.txtExtra.text = wordToSpan

                viewDataBinding!!.txtExtraTitle.text = baseActivity!!.resources.getString(R.string.baskets_own_you)
                viewDataBinding!!.txtExtra.text = extraEarning
                CommonUtils.setBalanceTextColor(viewDataBinding!!.txtExtra, "" + detailData.total_extra_amount_with_shopper)
            }
            else -> {
    //            val str = baseActivity?.resources?.getString(R.string.baskets_own_you) + " " + PreferenceManager.currency + " " + detailData.total_extra_amount_with_shopper
    //            viewDataBinding!!.txtExtra.text = str
    //
    //            val startIdx = baseActivity?.resources?.getString(R.string.baskets_own_you)!!.length + 1
    //            val endIdx = startIdx + PreferenceManager.currency!!.length + detailData.total_extra_amount_with_shopper.length + 1
    //
    //            val wordToSpan = SpannableString(str)
    //            wordToSpan.setSpan(ForegroundColorSpan(baseActivity?.resources?.getColor(R.color.colorBlack33)!!), startIdx, endIdx, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
    //            viewDataBinding!!.txtExtra.text = wordToSpan

                viewDataBinding!!.txtExtraTitle.text = baseActivity!!.resources.getString(R.string.baskets_own_you)
                viewDataBinding!!.txtExtra.text = extraEarning
                CommonUtils.setBalanceTextColor(viewDataBinding!!.txtExtra, "" + detailData.total_extra_amount_with_shopper)
            }
        }

        // Distance
        val tk = detailData.total_travel_distance
        val tkDouble = tk.toDoubleOrNull()
        if (tkDouble != null){
            viewDataBinding!!.txtDeliveryEarningsKm.text = String.format(Locale.ENGLISH, "(%.2f KM)", tkDouble)
        }

        // Total Items
        val items = detailData.total_delivered_items + " " + baseActivity?.resources?.getString(R.string.items)
        viewDataBinding!!.txtShoppingEarningsItems.text = String.format(Locale.ENGLISH, "(%s)", items)

        // Get review list
        reportViewArray = detailData.report_view

        // Refresh weekly list
        updateDailyEarnings()
    }

    // Refresh Weekly Earning List
    private fun updateDailyEarnings(){
        viewDataBinding!!.recyclerView.adapter = reportViewAdapter
        reportViewAdapter.replace(reportViewArray)
    }

    // Call the support team
    private fun getHelp(){
        val builder: AlertDialog.Builder = AlertDialog.Builder(requireContext())
        builder.setTitle("")
        builder.setMessage(baseActivity?.resources?.getString(R.string.support_call))
            .setCancelable(false)
            .setPositiveButton(
                getString(R.string.ok_btn_txt)
            ) { _, _ -> //do things
                callSupportTeam()

            }.setNegativeButton(
                getString(R.string.cancel_btn_txt)
            ) { _, _ ->
                //do things
            }
        val alert: AlertDialog = builder.create()
        alert.show()
    }

    // Call the support team
    @SuppressLint("CheckResult")
    private fun callSupportTeam(){
        val number = String.format(Locale("en"), "tel:%s", AppConstants.SUPPORT_PHONE_NUMBER)
        RxPermissions(this).request(
            Manifest.permission.CALL_PHONE
        ).observeOn(AndroidSchedulers.mainThread())
            .subscribe { granted ->
                if (granted) {
                    val intent = Intent(Intent.ACTION_CALL, Uri.parse(number))
                    startActivity(intent)
                }
                else{
                    Toast.makeText(baseActivity, baseActivity?.resources?.getString(R.string.error_no_call_permission), Toast.LENGTH_SHORT).show()
                }
            }
    }


}
