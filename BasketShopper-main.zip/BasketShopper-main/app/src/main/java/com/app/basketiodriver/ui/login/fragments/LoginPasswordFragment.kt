package com.app.basketiodriver.ui.login.fragments

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.text.method.PasswordTransformationMethod
import android.transition.TransitionManager
import android.view.*
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import bloder.com.blitzcore.enableWhen
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.Login
import com.app.basketiodriver.databinding.FragLoginPasswordBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.home.HomeActivity
import com.app.basketiodriver.ui.login.LoginActivity
import com.app.basketiodriver.ui.login.LoginViewModel
import com.app.basketiodriver.utils.*
import com.freshchat.consumer.sdk.Freshchat
import com.freshchat.consumer.sdk.FreshchatConfig
import com.google.i18n.phonenumbers.NumberParseException
import com.google.i18n.phonenumbers.PhoneNumberUtil
import com.google.i18n.phonenumbers.Phonenumber
import com.mukesh.countrypicker.Country
import com.mukesh.countrypicker.CountryPicker
import com.mukesh.countrypicker.OnCountryPickerListener
import com.tbruyelle.rxpermissions2.RxPermissions
import io.reactivex.android.schedulers.AndroidSchedulers
import jo.basket.utils.KeyboardUtils
import pl.aprilapps.easyphotopicker.DefaultCallback
import pl.aprilapps.easyphotopicker.MediaFile
import pl.aprilapps.easyphotopicker.MediaSource


class LoginPasswordFragment : BaseFragment<FragLoginPasswordBinding?, LoginViewModel>(),
    OnCountryPickerListener,
    Injectable {


    override val layoutId: Int
        get() = R.layout.frag_login_password

    override val viewModel: LoginViewModel
        get() {
            return getViewModel(baseActivity as FragmentActivity, LoginViewModel::class.java)
        }

    /**
     *  country picker dialog
     */
    var mCountryPicker: CountryPicker? = null

    /**
     * Phone Number Util
     */
    private var phoneUtil: PhoneNumberUtil? = null

    /**
     * Show the password
     */
    private var isShowingPassword: Boolean = false

    private var isChangedTextByUser: Boolean = true
    private var countryCode = "+962"
    private val countryNameCode = "JO"
    private var strMobile: String = ""
    private var maxLength = 15

    val fArray = arrayOfNulls<InputFilter>(1)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.sign_in))
        initFreshChat()
//        validation()
        setListener()

        initMobileInput()

        viewDataBinding!!.edMobileNumber.setPadding(getPixelSizeInDp(6), 0,getPixelSizeInDp(6),0)

    }

//    private fun validation() {
//        viewDataBinding!!.btnNext.enableWhen {
//            viewDataBinding!!.edMobileNumber.isPhoneNumber() onValidationSuccess {
////                viewDataBinding!!.edMobileNumber.onSuccess()
//            } onValidationError {
////                viewDataBinding!!.edMobileNumber.onError()
//            }
//        }
//    }

    override fun onResume() {
        super.onResume()

        initTextInputLayouts()
    }

    private fun initTextInputLayouts(){
        /**
         * Mobile TextInputLayout
         */
//        viewDataBinding!!.inputMobileNumber.viewTreeObserver.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
//            override fun onPreDraw(): Boolean {
//                // Wait for the first draw to be sure the view is completely measured
//                if (viewDataBinding!!.inputMobileNumber.height > 0) {
//                    viewDataBinding!!.inputMobileNumber.viewTreeObserver.removeOnPreDrawListener(this)
//                    updateHintPosition(viewDataBinding!!.edMobileNumber.hasFocus(), !viewDataBinding!!.edMobileNumber.text.isNullOrEmpty(), false)
//                    return false
//                }
//                return true
//            }
//        })
//
        // Set the padding to Mobile Number
        viewDataBinding!!.edMobileNumber.setOnFocusChangeListener { _, hasFocus ->
            updateHintPosition(hasFocus, !viewDataBinding!!.edMobileNumber.text.isNullOrEmpty(), false)
        }

        // Set the padding to Password
        viewDataBinding!!.edPassword.setOnFocusChangeListener { _, hasFocus ->
            updatePasswordHintPosition(hasFocus, !viewDataBinding!!.edPassword.text.isNullOrEmpty(), true)
        }

        if (viewDataBinding!!.edPassword.text.isNullOrEmpty()){
            viewDataBinding!!.edPassword.setPadding(getPixelSizeInDp(16), 0, getPixelSizeInDp(16), getPasswordTextInputLayoutTopSpace())
        }
        else{
            viewDataBinding!!.edPassword.setPadding(getPixelSizeInDp(16), getPixelSizeInDp(6), getPixelSizeInDp(16), getPasswordTextInputLayoutTopSpace())
        }

        /**
         * Password TextInputLayout
         */
        viewDataBinding!!.inputLayoutPassword.viewTreeObserver.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                // Wait for the first draw to be sure the view is completely measured
                if (viewDataBinding!!.inputLayoutPassword.height > 0) {
                    viewDataBinding!!.inputLayoutPassword.viewTreeObserver.removeOnPreDrawListener(this)
                    updatePasswordHintPosition(viewDataBinding!!.edPassword.hasFocus(), !viewDataBinding!!.edPassword.text.isNullOrEmpty(), false)
                    return false
                }
                return true
            }
        })
//
//        viewDataBinding!!.edPassword.setOnFocusChangeListener { _, hasFocus ->
//            updatePasswordHintPosition(hasFocus, !viewDataBinding!!.edPassword.text.isNullOrEmpty(), true)
//        }
    }

    private fun getPixelSizeInDp(dpSize : Int) : Int{
        val density = baseActivity?.resources?.displayMetrics!!.density
        return (dpSize * density + 0.5f).toInt()
    }

    private fun updateHintPosition(hasFocus: Boolean, hasText: Boolean, animate: Boolean) {
        if (animate) {
            TransitionManager.beginDelayedTransition(viewDataBinding!!.inputMobileNumber)
        }

        val padding = getPixelSizeInDp(6)
        if (hasFocus || hasText) {
            viewDataBinding!!.edMobileNumber.setPadding(padding, padding, padding, 0)
        } else {
            viewDataBinding!!.edMobileNumber.setPadding(padding, 0, padding, getTextInputLayoutTopSpace())
        }
    }

    private fun getTextInputLayoutTopSpace(): Int {
        var currentView: View = viewDataBinding!!.edMobileNumber
        var space = 0
        do {
            space += currentView.top
            currentView = currentView.parent as View
        } while (currentView.id != viewDataBinding!!.inputMobileNumber.id)
        return space
    }

    /**
     * Password TextInputLayout
     */
    private fun updatePasswordHintPosition(hasFocus: Boolean, hasText: Boolean, animate: Boolean) {
        if (animate) {
            TransitionManager.beginDelayedTransition(viewDataBinding!!.inputLayoutPassword)
        }
        if (hasFocus || hasText) {
            viewDataBinding!!.edPassword.setPadding(getPixelSizeInDp(16), getPixelSizeInDp(6), getPixelSizeInDp(16), 0)
        } else {
            viewDataBinding!!.edPassword.setPadding(getPixelSizeInDp(16), 0, getPixelSizeInDp(16), getPasswordTextInputLayoutTopSpace())
        }
    }

    private fun getPasswordTextInputLayoutTopSpace(): Int {
        var currentView: View = viewDataBinding!!.edPassword
        var space = 0
        do {
            space += currentView.top
            currentView = currentView.parent as View
        } while (currentView.id != viewDataBinding!!.inputLayoutPassword.id)
        return space
    }

    private fun initMobileInput() {

        // Password field
        try{
            viewDataBinding?.ivShowPassword!!.setOnClickListener {
                isShowingPassword = !isShowingPassword
                if (isShowingPassword){
                    viewDataBinding?.edPassword!!.transformationMethod = null
                    viewDataBinding?.ivShowPassword!!.setImageResource(R.drawable.ic_see)
                }
                else{
                    viewDataBinding?.edPassword!!.transformationMethod = PasswordTransformationMethod()
                    viewDataBinding?.ivShowPassword!!.setImageResource(R.drawable.ic_see_closed)
                }
            }
        }
        catch (e : Exception){
            e.printStackTrace()
        }

        // Mobile Number
        val editTextMobile = viewDataBinding?.edMobileNumber!!

        editTextMobile.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                // Reformat mobile number with spacings
                if(isChangedTextByUser){
                    reformatMobileNumber(editTextMobile)
                    isChangedTextByUser = true

                    validateNextButton()

                    fArray[0] = InputFilter.LengthFilter(maxLength)
                    editTextMobile.filters = fArray
                }

            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }
        })

        Handler().postDelayed({
            editTextMobile.requestFocus()
            KeyboardUtils.showKeyboard(baseActivity as Activity, editTextMobile)
        }, 200)
    }

    private fun reformatMobileNumber(editTextMobile: EditText) {

        val phoneNumberUtil: PhoneNumberUtil = PhoneNumberUtil.getInstance()
        var phoneNumberPN: Phonenumber.PhoneNumber? = null

        try {
            phoneNumberPN = phoneNumberUtil.parse(countryCode + editTextMobile.text.toString(), countryNameCode)
            val phoneNumber = phoneNumberUtil.formatByPattern(
                phoneNumberPN,
                PhoneNumberUtil.PhoneNumberFormat.NATIONAL,
                FormatterUtils.mobileNumberFormatterList()
            )
            isChangedTextByUser = false
            editTextMobile.setText(phoneNumber)
            strMobile = phoneNumber.replace("""[$, ]""".toRegex(), "")

            val pos = editTextMobile.text!!.length
            editTextMobile.setSelection(pos)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Validate 'Next' button with mobile number content
    private fun validateNextButton() {
        maxLength = if (isValidFullNumber()){
            viewDataBinding!!.btnNext.isEnabled = true
            viewDataBinding!!.edMobileNumber.text.toString().trim().length
        }else{
            viewDataBinding!!.btnNext.isEnabled = false
            15
        }
    }

    private fun isValidFullNumber(): Boolean{
        return try {
            (((strMobile.startsWith("78") && strMobile.length == 9) || (strMobile.startsWith("078") && strMobile.length == 10) )
                    || getPhoneUtil()!!.isValidNumber(getPhoneUtil()!!.parse(countryCode + strMobile, countryNameCode)))
        }catch (e: NumberParseException){
            false
        }
    }

    /**
     * Used for set actions listener
     */
    @SuppressLint("CheckResult")
    private fun setListener() {
        val builder = CountryPicker.Builder().with(baseActivity!!)
            .listener(this)

        mCountryPicker = builder.build()

        viewDataBinding!!.countryCodeLayout.setOnClickListener {
            run {
                mCountryPicker!!.showDialog(baseActivity!!)
            }
        }

//        viewDataBinding!!.btnLoginWithSms.setOnClickListener {
//            navigate(LoginPasswordFragmentDirections.actionLoginPasswordFragmentToLoginSmsFragment())
//        }

        // Forgot password
        viewDataBinding!!.btnForgotPassword.setOnClickListener {
            navigate(LoginPasswordFragmentDirections.actionLoginPasswordFragmentToForgetPasswordFragment())
        }

        // Call Support
        viewDataBinding!!.btnCallSupport.setOnClickListener {
            (baseActivity as LoginActivity).callSupport()
        }
        viewDataBinding!!.supportChat.setOnClickListener {
            Freshchat.showConversations(requireContext())
        }

        // Tap the Login button
        viewDataBinding!!.btnNext.setOnClickListener {
            run {
                hideKeyboard()

                if (!isNetworkConnected){
                    Toast.makeText(baseActivity, baseActivity?.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_SHORT).show()
                    return@run
                }

                val code = viewDataBinding!!.countryCodeTex.text.toString()
                val mobile = viewDataBinding!!.edMobileNumber.text.toString()
                var password = viewDataBinding!!.edPassword.text.toString()

                if (!ViewUtils.isValidMobile(mobile)){
                    Toast.makeText(baseActivity, R.string.err_mobile, Toast.LENGTH_LONG).show()

                    return@run
                }

                if (!ViewUtils.isValidPassword(password)) {
                    Toast.makeText(baseActivity, R.string.err_password, Toast.LENGTH_LONG).show()

                    return@run
                }

                var userMobile = code + strMobile

                // Call login api
                viewModel.loginWithPassword(PreferenceManager.currentUserLanguage, userMobile, password, object : HandleResponse<Login>{
                    override fun handleErrorResponse(error: ErrorResponse?) {
                        AppLogger.d("<===== Failed to login with password")
                        if (isNetworkConnected){
                            Toast.makeText(baseActivity, error?.message, Toast.LENGTH_LONG).show()
                        }else{
                            Toast.makeText(baseActivity, baseActivity?.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                        }
                        AppLogger.d(error?.message)
                    }

                    override fun handleSuccessResponse(successResponse: Login) {
                        AppLogger.d("<===== Succeeded to login with password")

                        // Go to Dashboard page
//                        navigate(LoginPasswordFragmentDirections.actionLoginPasswordFragmentToPinVerificationFragment())
//
                        val loginResponse = successResponse.response
                        if (loginResponse?.httpCode == 200) {

                            // Update the shopper info in local
                            viewModel.updateShopperInfo(loginResponse)

                            // Save the login status
                            PreferenceManager.isLoggedIn = true

                            // Go to Home page
                            startActivity(HomeActivity.newIntent(context))
                            baseActivity!!.finish()
                        }
                        else{
                            Toast.makeText(baseActivity, loginResponse?.message, Toast.LENGTH_LONG).show()
                        }
                    }
                })
            }
        }
    }

    private fun initFreshChat(){
        // Initialization Config Options
        val config = FreshchatConfig(AppConstants.FRESH_CHAT_APP_ID, AppConstants.FRESH_CHAT_APP_KEY)
        config.domain = AppConstants.FRESH_CHAT_CONFIG_DOMAIN
        config.isCameraCaptureEnabled = true
        config.isGallerySelectionEnabled = true
        config.isResponseExpectationEnabled = true
        Freshchat.getInstance(requireContext()).init(config)
    }

    private fun getPhoneUtil(): PhoneNumberUtil? {
        if (phoneUtil == null) {
            phoneUtil = PhoneNumberUtil.getInstance()
        }
        return phoneUtil
    }

    override fun onSelectCountry(country: Country?) {
        viewDataBinding!!.countryCodeTex.text = country?.dialCode ?: ""
        countryCode = country?.dialCode ?: ""
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

    }
}
