package com.app.basketiodriver.data.model.api.response

import com.app.basketiodriver.data.model.api.response.Base.BaseResponse
import com.google.gson.annotations.SerializedName


/**
Created by ibraheem lubbad on 4/11/20.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class ShopperAppConfigResponse : BaseResponse() {


    @SerializedName("data")
    var shopperAppConfig: ShopperAppConfig? = null

    class ShopperAppConfig(
        @SerializedName("Languages") val languages: ArrayList<LanguageData>,
        @SerializedName("Country") val countries: ArrayList<CountryData>
    )

    class LanguageData(
        @SerializedName("id") val id: Int,
        @SerializedName("name") val name: String,
        @SerializedName("language_code") val language_code: String,
        @SerializedName("status") val status: Int,
        @SerializedName("created_at") val created_at: String,
        @SerializedName("updated_at") val updated_at: String
    )

    class CountryData(
        @SerializedName("id") val id: Int,
        @SerializedName("currency_id") val currency_id: Int,
        @SerializedName("url_index") val url_index: String,
        @SerializedName("ios_code") val ios_code: String,
        @SerializedName("alpha_code") val alpha_code: String,
        @SerializedName("country_isd_code") val country_isd_code: String,
        @SerializedName("country_status") val country_status: Int,
        @SerializedName("created_at") val created_at: String,
        @SerializedName("updated_at") val updated_at: String
    )
}