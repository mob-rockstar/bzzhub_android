package com.app.basketiodriver.ui.dashbaord

import android.app.Application
import com.app.basketiodriver.data.DataManager
import com.app.basketiodriver.ui.base.BaseNavigator
import com.app.basketiodriver.ui.base.BaseViewModel

class StoreInstructionsViewModel constructor(application: Application, dataManager: DataManager
) : BaseViewModel<BaseNavigator?>(application, dataManager) {

}