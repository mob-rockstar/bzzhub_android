package com.app.basketiodriver.data.model.api.response

import com.app.basketiodriver.data.model.api.response.Base.BaseResponse
import com.app.basketiodriver.data.model.api.ShoppperDocument
import com.google.gson.annotations.SerializedName

/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class UploadDocumentResponse :
    BaseResponse() {

    @SerializedName("data")
    val shoppperDocument: ShoppperDocument? = null

    override fun toString(): String {
        return "UploadDocumentResponse(shoppperDocument=$shoppperDocument)"
    }


}