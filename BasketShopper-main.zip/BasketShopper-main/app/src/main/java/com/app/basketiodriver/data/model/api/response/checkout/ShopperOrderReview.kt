package com.app.basketiodriver.data.model.api.response.checkout

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class ShopperOrderReview {

    @SerializedName("response")
    @Expose
    val responseOrderReview: ResponseOrderReview? = null

    inner class ResponseOrderReview {
        @SerializedName("httpCode")
        @Expose
        val httpCode: Int? = null

        @SerializedName("Message")
        @Expose
        val message: String = ""

        @SerializedName("outlet_order")
        @Expose
        val outletOrder: OutletOrder? = null

        @SerializedName("user_details")
        @Expose
        val userDetails: UserDetails? = null

        @SerializedName("outlet_details")
        @Expose
        val outletDetails: OutletDetails? = null
    }

}