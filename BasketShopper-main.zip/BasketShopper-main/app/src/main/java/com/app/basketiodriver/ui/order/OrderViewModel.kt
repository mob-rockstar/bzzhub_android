package com.app.basketiodriver.ui.order

import android.app.Application
import androidx.annotation.NonNull
import com.app.basketiodriver.data.DataManager
import com.app.basketiodriver.ui.base.BaseNavigator
import com.app.basketiodriver.ui.base.BaseViewModel

/**
 * Created by ibraheem lubbad on 2020-01-22.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class OrderViewModel constructor(@NonNull application: Application, dataManager: DataManager) :
    BaseViewModel<BaseNavigator?>(application, dataManager)


