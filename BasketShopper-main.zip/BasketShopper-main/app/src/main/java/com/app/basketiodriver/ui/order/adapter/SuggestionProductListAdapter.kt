package com.app.basketiodriver.ui.order.adapter

import android.text.Html
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.order.SimilarProduct
import com.app.basketiodriver.databinding.ItemBasketSuggestionListBinding
import com.app.basketiodriver.utils.BaseRecyclerViewAdapter
import com.app.basketiodriver.utils.GlideApp
import com.app.basketiodriver.utils.price.PriceConstructor
import com.app.basketiodriver.utils.price.PriceConstructorNew

class SuggestionProductListAdapter(val activity : FragmentActivity, val listItems : List<SimilarProduct>, val listener : SuggestionProductClickListener?) : BaseRecyclerViewAdapter<SimilarProduct, ItemBasketSuggestionListBinding> (){

    override val layoutId: Int
        get() = R.layout.item_basket_suggestion_list

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return SuggestionProductViewHolder(createBindView(parent))
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val holder = holder as SuggestionProductViewHolder
        val item = listItems[position]

        holder.binding.itemProduct.orderItemTitle.text = (item.productName ?: "") // + " " + item.departmentName ?: ""

        holder.binding.itemProduct.orderCost.text = Html.fromHtml(PriceConstructorNew.getFormatPrice(item, PriceConstructor.LabelType.SIMPLE))

        if (item.productImage != null){
            GlideApp.with(activity).load(item.productImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(holder.binding.itemProduct.orderItemImage)
        }

        val params = holder.itemView.layoutParams as RecyclerView.LayoutParams
        params.topMargin = 5
        holder.itemView.layoutParams = params

        if (item.upcType == 2) {
            holder.binding.btnScanAsReplace.setText(R.string.replace)
        }
        else{
            holder.binding.btnScanAsReplace.setText(R.string.scan_to_replace)
        }

        if (item.getDescriptionLabel().isEmpty()){
            holder.binding.itemProduct.tvPriceDescription.visibility = View.GONE
        }
        else{
            holder.binding.itemProduct.tvPriceDescription.visibility = View.VISIBLE
            holder.binding.itemProduct.tvPriceDescription.text = item.getDescriptionLabel()
        }

        // Scan As replace
        holder.binding.btnScanAsReplace.setOnClickListener {
            listener?.onProductClicked(item)
        }

        // Tap the item
        holder.binding.itemSuggestionList.setOnClickListener{
            listener?.onProductClicked(item)
        }

    }

    interface SuggestionProductClickListener {
        fun onProductClicked(item : SimilarProduct)
    }

    override fun getItemCount(): Int {
        return listItems.size
    }

    inner class SuggestionProductViewHolder(val binding: ItemBasketSuggestionListBinding) :
        RecyclerView.ViewHolder(binding.root)
}