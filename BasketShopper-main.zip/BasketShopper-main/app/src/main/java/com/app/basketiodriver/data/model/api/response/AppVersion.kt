package com.app.basketiodriver.data.model.api.response

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName

class AppVersion {

    @SerializedName("response")
    @Expose
    val response: VersionData? = null

    inner class VersionData {
        @SerializedName("httpCode")
        @Expose
        val httpCode : Int = 0

        @SerializedName("Message")
        @Expose
        val message: String? = null

        @SerializedName("permission")
        @Expose
        val permission: Int = 0

        @SerializedName("version_url")
        @Expose
        val versionUrl: String? = null

        @SerializedName("version_test2222")
        @Expose
        val version_test2222: String? = null

        @SerializedName("shopper_location_update")
        @Expose
        val shopper_location_update : String = "20"
    }
}