package com.app.basketiodriver.data.model.api.response

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
sealed class LoginRequest {


    data class ShopperLoginRequest(
        @field:SerializedName("id") @field:Expose val shopperId: String?,
        @field:SerializedName("password") @field:Expose val password: String?,
        @field:SerializedName("device_id") @field:Expose val device_id: String?,
        @field:SerializedName("device_token") @field:Expose val device_token: String?
    )

    data class ShopperLoginPasswordRequest(
        @field:SerializedName("id") @field:Expose val shopperId: Int?,
        @field:SerializedName("password") @field:Expose val password: String?,
        @field:SerializedName("device_id") @field:Expose val device_id: String?,
        @field:SerializedName("device_token") @field:Expose val device_token: String?,
        @field:SerializedName("login_platform") @field:Expose val login_platform: String= "Android"
    )


    data class CheckShopperOTPRequest(
        @field:SerializedName("id") @field:Expose val shopperId: Int?,
        @field:SerializedName("otp") @field:Expose val otp: String?,
        @field:SerializedName("device_id") @field:Expose val device_id: String?,
        @field:SerializedName("device_token") @field:Expose val device_token: String?,
        @field:SerializedName("login_platform") @field:Expose val login_platform: String= "Android"
    )
data class ResetShopperPasswordRequest(
        @field:SerializedName("password") @field:Expose val password: String?,
        @field:SerializedName("password_confirmation") @field:Expose val password_confirmation: String?
    )

    data class ForegetShopperPasswordRequest(
        @field:SerializedName("mobile") @field:Expose val mobile: String?,
        @field:SerializedName("country_code") @field:Expose val code: String?

    )


}