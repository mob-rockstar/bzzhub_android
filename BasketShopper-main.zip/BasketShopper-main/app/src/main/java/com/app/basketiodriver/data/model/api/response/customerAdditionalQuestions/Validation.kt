package com.app.basketiodriver.data.model.api.response.customerAdditionalQuestions

data class Validation(
    val max: Int,
    val min: Int,
    val repeat: Int,
    val required: Boolean
)