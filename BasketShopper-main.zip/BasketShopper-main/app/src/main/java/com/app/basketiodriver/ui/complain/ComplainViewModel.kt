package com.app.basketiodriver.ui.complain

import android.app.Application
import com.app.basketiodriver.data.DataManager
import com.app.basketiodriver.mvvm.ui.login.LoginNavigator
import com.app.basketiodriver.ui.base.BaseViewModel


class ComplainViewModel(
    application: Application,
    dataManager: DataManager
) :
    BaseViewModel<LoginNavigator?>(application, dataManager) {
}