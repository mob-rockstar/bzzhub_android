package com.app.basketiodriver.ui.batches.fragments

import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import androidx.fragment.app.Fragment
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentArrivedAtTheStoreBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.home.HomeViewModel


/**
 * A simple [Fragment] subclass.
 */
class ArrivedAtTheStoreFragment : BaseFragment<FragmentArrivedAtTheStoreBinding?, HomeViewModel>(),
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_arrived_at_the_store

    override val viewModel: HomeViewModel
        get() {
            return getViewModel(requireActivity(), HomeViewModel::class.java)
        }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewDataBinding?.slideview?.addSlideListener {
            navigate(
                ArrivedAtTheStoreFragmentDirections.actionArrivedAtTheStoreFragmentToInformationFragment()
            )
        }

        viewDataBinding?.btnBack?.setOnClickListener {
            navController().popBackStack()
        }

    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_info, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item.itemId) {
            R.id.btnInfo -> {
                navigate(
                    ArrivedAtTheStoreFragmentDirections.actionArrivedAtTheStoreFragmentToInformationFragment()
                )
            }
        }
        return super.onOptionsItemSelected(item)
    }

    fun showTip() {

        //ViewUtils.showAvailableAtTooltip(requireContext(),null,null,"Tap to see delivery address")

    }

}
