package com.app.basketiodriver.ui.order.adapter

import android.annotation.SuppressLint
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.databinding.ItemEnterQuantityWeightListBinding
import com.app.basketiodriver.ui.dialogs.AmountDialogFragment
import com.app.basketiodriver.utils.BaseRecyclerViewAdapter
import com.app.basketiodriver.utils.GlideApp
import timber.log.Timber
import java.util.*

class EnterQuantityWeightOrdersItemListAdapter (val activity : FragmentActivity, val products : ArrayList<OrdersItem>, val fragment : DialogFragment)
    : BaseRecyclerViewAdapter<OrdersItem, ItemEnterQuantityWeightListBinding>(){

    override val layoutId: Int
        get() = R.layout.item_enter_quantity_weight_list

    override fun getItemCount(): Int {
        return products.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return EnterQuantityWeightViewHolder(createBindView(parent))
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val holder = holder as EnterQuantityWeightViewHolder
        val item = products[position]

        // Product Title
        holder.binding.tvItemTitle.text = item.productName

        // Price
        holder.binding.tvPrice.text = String.format(Locale.ENGLISH, "%s %s", activity.resources.getString(R.string.currency_jd), item.ourSellingPrice) //PriceConstructorNew.getFormatPrice(item, PriceConstructor.LabelType.SIMPLE)

        // Product Image
        if (item.productImage != null){
            GlideApp.with(activity).load(item.productImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(holder.binding.ivOrderItem)
        }

        // Quantity and Weight
        holder.binding.tvUnit.text = item.unit
        holder.binding.tvAmount.text = "1"
        holder.binding.etWeight.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL

        if (item.soldPer == 2){
            holder.binding.amountLayout.visibility = View.GONE
            holder.binding.weightLayout.visibility = View.VISIBLE

            (fragment as AmountDialogFragment).updateItemQuantity(item, 0)
        }
        else{
            if (item.soldPer == 3) {
                holder.binding.amountLayout.visibility = View.VISIBLE
                holder.binding.weightLayout.visibility = View.VISIBLE
            }
            else{
                holder.binding.amountLayout.visibility = View.VISIBLE
                holder.binding.weightLayout.visibility = View.GONE
            }
        }

        // Increase the Quantity
        holder.binding.ivAdd.setOnClickListener {
            val currQuantity = holder.binding.tvAmount.text.toString().toIntOrNull() ?: 0
            holder.binding.tvAmount.text = (currQuantity + 1).toString()

            holder.binding.ivRemove.setImageResource(R.drawable.ic_minus_green)

            (fragment as AmountDialogFragment).updateItemQuantity(item, currQuantity + 1)
        }

        // Decrease the Quantity
        holder.binding.ivRemove.setOnClickListener {
            val currQuantity = holder.binding.tvAmount.text.toString().toIntOrNull() ?: 0
            if (currQuantity > 1) {
                if (currQuantity == 2){
                    holder.binding.ivRemove.setImageResource(R.drawable.ic_delete_red)
                }

                holder.binding.tvAmount.text = (currQuantity - 1).toString()
                (fragment as AmountDialogFragment).updateItemQuantity(item, currQuantity - 1)
            }
            else{
                // Remove the product from list
                (fragment as AmountDialogFragment).removeItemFromReplacementList(item)

                products.remove(item)
                notifyDataSetChanged()
            }
        }

        // Weight Listener
        holder.binding.etWeight.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                // Has focus on Weight field
            }
            else {
                // Lost the focus on Weight field
                val enteredWeight = holder.binding.etWeight.text.toString().toDoubleOrNull() ?: 0.0
                Timber.d("Entered weight : " + enteredWeight)

                (fragment as AmountDialogFragment).updateItemWeight(item, enteredWeight)
            }
        }

        if (position == itemCount - 1) {
            holder.binding.bottomLines.visibility = View.GONE
        }
        else{
            holder.binding.bottomLines.visibility = View.VISIBLE
        }
    }


    // ViewHolder
    inner class EnterQuantityWeightViewHolder(val binding: ItemEnterQuantityWeightListBinding) :
        RecyclerView.ViewHolder(binding.root)
}