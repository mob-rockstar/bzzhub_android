package com.app.basketiodriver.ui.howdoing.adapters

import android.content.Context
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.howamidoing.RIRecords
import com.app.basketiodriver.databinding.ItemRiTitleBinding
import com.app.basketiodriver.utils.BaseRecyclerViewAdapter
import com.app.basketiodriver.utils.DateUtils
import java.util.*

class RIHistoryAdapter(val mContext : FragmentActivity) : BaseRecyclerViewAdapter<RIRecords, ItemRiTitleBinding>() {

    override val layoutId: Int
        get() = R.layout.item_ri_title

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return RIViewHolder(createBindView(parent))
    }

    var mExpandedPosition = -1

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val rvHolder = holder as RIViewHolder
        val record = items[position]

        // Group Title
        rvHolder.binding.txtTitle.text = DateUtils.getRIDate(record.created_on)

        // Child Title & Description
        rvHolder.binding.txtReason.text = String.format(Locale("en"), "%s %s", record.reliability_incident_reason, DateUtils.getRIDateTime(record.created_on))

        // Detail
        rvHolder.binding.txtDetail.text = record.reliability_incident_description

        val isExpanded = position == mExpandedPosition
        holder.binding.detailsView.visibility = if (isExpanded) View.VISIBLE else View.GONE

        // Dropdown icon
        if (isExpanded){
            holder.binding.ivArrow.setImageResource(R.drawable.ic_arrow_up)
        }
        else{
            holder.binding.ivArrow.setImageResource(R.drawable.ic_arrow_down)
        }

        holder.binding.itemView.setOnClickListener {
            mExpandedPosition = if (isExpanded) -1 else position
            notifyItemChanged(position)
        }
    }

    inner class RIViewHolder (val binding: ItemRiTitleBinding) : RecyclerView.ViewHolder(binding.root)
}