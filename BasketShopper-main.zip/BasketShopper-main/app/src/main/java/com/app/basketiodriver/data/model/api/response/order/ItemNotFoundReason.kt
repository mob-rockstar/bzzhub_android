package com.app.basketiodriver.data.model.api.response.order

import com.google.gson.annotations.SerializedName




class ItemNotFoundReason {
    @SerializedName("id")
    val id: Int = 0

    @SerializedName("reason")
    val reason: String = ""

    @SerializedName("description")
    val description: String = ""
}