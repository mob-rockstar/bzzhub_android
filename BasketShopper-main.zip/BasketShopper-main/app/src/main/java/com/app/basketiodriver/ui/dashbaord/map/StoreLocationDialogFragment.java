package com.app.basketiodriver.ui.dashbaord.map;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.app.basketiodriver.R;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.Objects;


public class StoreLocationDialogFragment extends DialogFragment {

    SupportMapFragment dialogMap;
    TextView txtStoreAddress, txtAddressTitle;
    Button btn_agree;

    private String title;
    private String address;
    private LatLng focusPosition;

    private Circle circle;
    private Circle shadowOne;
    private Circle shadowTwo;

    public StoreLocationDialogFragment() {
        // Required empty public constructor
    }

    public static StoreLocationDialogFragment newInstance(String title, String address, LatLng focusPosition) {
        StoreLocationDialogFragment fragment = new StoreLocationDialogFragment();
        fragment.title = title;
        fragment.address = address;
        fragment.focusPosition = focusPosition;
        return fragment;
    }

    public void updateValue(String title, String address, LatLng focusPosition) {
        this.title = title;
        this.address = address;
        this.focusPosition = focusPosition;
    }

    @SuppressLint("WrongConstant")
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setStyle(DialogFragment.STYLE_NORMAL, R.style.LocationDialogStyle);
    }

    @Override
    public void onStart() {
        super.onStart();

        try{
            getDialog().getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_store_location_dialog, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        findViews(view);
        initView();
    }

    private void findViews(View v) {
        dialogMap = ((SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.dialogMap));
        txtStoreAddress = v.findViewById(R.id.txtStoreAddress);
        txtAddressTitle = v.findViewById(R.id.txtAddressTitle);
        btn_agree = v.findViewById(R.id.btn_agree);

        btn_agree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }

    private void initView() {
        Log.d("TAG", ".toString()===>: "+focusPosition.latitude+"====>"+focusPosition.longitude+"=====>"+address.toString());
        txtStoreAddress.setText(address);
        txtAddressTitle.setText(title);

        try{
            dialogMap.getMapAsync(map -> {
                addMarker(map, focusPosition, "Store Location");
                addCircle(map);

                map.setOnCameraIdleListener(() -> {
                    if (circle == null)
                        return;
                    double radius = Math.pow(2, (14 - map.getCameraPosition().zoom)) * Math.pow(5, -3);
                    circle.setRadius(radius * 6000);
                    shadowTwo.setRadius(radius * 13500);
                    shadowOne.setRadius(radius * 21000);
                });
            });
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    public void addMarker(GoogleMap googleMap, LatLng position, String title) {
        try {
            MarkerOptions markerOptions = new MarkerOptions();
            markerOptions.position(position);
            markerOptions.icon(BitmapDescriptorFactory.fromBitmap(getBitmapFromVectorDrawable(R.drawable.ic_marker)));
            markerOptions.title(title);
            googleMap.addMarker(markerOptions);
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    public Bitmap getBitmapFromVectorDrawable(int drawableId) {
        Drawable drawable = ContextCompat.getDrawable(requireActivity(), drawableId);
        assert drawable != null;
        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(),
                drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);

        return bitmap;
    }

    public void addCircle(GoogleMap googleMap) {

        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(
                new LatLng(focusPosition.latitude, focusPosition.longitude), 17.0f));

        double radius = Math.pow(2, (14 - googleMap.getCameraPosition().zoom)) * Math.pow(5, -3);

        double latitude = focusPosition.latitude;
        double longitude = focusPosition.longitude;
        CircleOptions optionsShadow1 = new CircleOptions()
                .radius(radius * 10000)
                .fillColor(getResources().getColor(R.color.colorMapAlpha))
                .strokeWidth(0)
                .center(new LatLng(latitude, longitude));
        shadowTwo = googleMap.addCircle(optionsShadow1);
        CircleOptions optionsShadow2 = new CircleOptions()
                .radius(radius * 7000)
                .fillColor(getResources().getColor(R.color.colorMapAlphaOne))
                .strokeWidth(0)
                .center(new LatLng(latitude, longitude));
        shadowOne = googleMap.addCircle(optionsShadow2);
        CircleOptions options = new CircleOptions()
                .radius(radius * 3000)
                .fillColor(getResources().getColor(R.color.colorPrimary))
                .strokeColor(getResources().getColor(R.color.colorWhite))
                .strokeWidth(1.5f)
                .center(new LatLng(latitude, longitude));
        circle = googleMap.addCircle(options);
    }

    @Override
    public void onDestroyView() {
        try {
            if (dialogMap != null)
                if (isAdded() && getActivity() != null){
                    getActivity().getSupportFragmentManager().beginTransaction().remove(dialogMap).commit();
                }
        } catch (Exception e) {
            e.printStackTrace();
        }

        super.onDestroyView();
    }

    @Override
    public void onPause() {
        super.onPause();

    }
}