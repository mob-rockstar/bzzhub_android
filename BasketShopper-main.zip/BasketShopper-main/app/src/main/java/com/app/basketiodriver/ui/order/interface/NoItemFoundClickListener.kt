package com.app.basketiodriver.ui.order.`interface`

import com.app.basketiodriver.data.model.api.response.order.ItemNotFoundReason

interface NoItemFoundClickListener {
    fun onItemClick(reasonItem : ItemNotFoundReason)
}