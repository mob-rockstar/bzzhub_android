package com.app.basketiodriver.ui.order.product

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.SearchView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import app.basket.scanner.BasketScanner
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.general.SimpleResponse
import com.app.basketiodriver.data.model.api.response.order.SimilarProduct
import com.app.basketiodriver.data.model.api.response.order.SimilarResponse
import com.app.basketiodriver.data.remote.socket.SystemMessage
import com.app.basketiodriver.data.remote.socket.SystemMessageReq
import com.app.basketiodriver.databinding.ActivitySearchForSimilarBinding
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.app.basketiodriver.ui.dialogs.AmountDialogFragment
import com.app.basketiodriver.ui.order.adapter.SimilarProductListAdapter
import com.app.basketiodriver.utils.AppConstants
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import io.reactivex.Observable
import io.reactivex.ObservableEmitter
import io.reactivex.ObservableOnSubscribe
import java.util.concurrent.TimeUnit
import javax.inject.Inject


class AddBySearchActivity : BaseActivity<ActivitySearchForSimilarBinding, OrderDetailsViewModel>(),
    HasAndroidInjector, SimilarProductListAdapter.SimilarProductItemClickListener,
    SearchView.OnQueryTextListener,
    ObservableOnSubscribe<String>, AmountDialogFragment.AmountDialogOnClickListener {
    override val layoutId: Int
        get() = R.layout.activity_search_for_similar

    override val viewModel: OrderDetailsViewModel
        get() {
            return getViewModel(OrderDetailsViewModel::class.java)
        }

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    val BARCODE_ACTIVITY = 541

    var orderId: Long = 0
    var itemId: Long = 0

    // search result
    var itemsList: ArrayList<SimilarProduct> = arrayListOf()
    lateinit var mAdapter: SimilarProductListAdapter

    lateinit var searchObservable: Observable<String>
    lateinit var mEmitter: ObservableEmitter<String>

    private var onItemClick = false
    private var amountDialog: AmountDialogFragment? = null

    // selected product
    private var selected: SimilarProduct? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Init toolbar
        initToolBar()

        viewDataBinding!!.rvReplaceItem.layoutManager = LinearLayoutManager(this)
        viewDataBinding!!.rvReplaceItem.setHasFixedSize(true)

        if (intent.extras != null) {
            orderId = intent.extras!!.getLong("ARG_ORDER_ID")
            itemId = intent.extras!!.getLong("ARG_ITEM_ID")
        }

        initViews()

        initSearchView()
    }

    private fun initToolBar() {
        initToolbar(getString(R.string.search_products),
            true, viewDataBinding!!.layoutToolBar.toolbar,
            View.OnClickListener {
                run {
                    onBackPressed()
                }
            })
    }

    private fun initViews() {
        // Scan to Add
        viewDataBinding!!.txtScanItem.setOnClickListener {
            // Go to Barcode reader activity
//            val intent = Intent(this, BarcodeReaderActivity::class.java)
//            startActivityForResult(intent, BARCODE_ACTIVITY)
//             start new scanner library
            startScanner()
        }

        viewDataBinding!!.tvBarcodeDone.setOnClickListener {
            val etBarcode = viewDataBinding!!.etManuallyBarcode.text.toString().trim()
            if (etBarcode.isNotEmpty()){
                val resultIntent = Intent()
                resultIntent.putExtra("ARG_BARCODE", etBarcode)
                setResult(RESULT_OK, resultIntent)
                finish()
            }else{
                Toast.makeText(this@AddBySearchActivity ,resources.getString(R.string.plz_enter_barcode_manually),Toast.LENGTH_SHORT).show()
            }

        }
    }

    private fun startScanner() {
        BasketScanner.scan(onSuccess = {
            Toast.makeText(
                this@AddBySearchActivity,
                it,
                Toast.LENGTH_SHORT
            ).show()

            val resultIntent = Intent()
// TODO Add extras or a data URI to this intent as appropriate.
// TODO Add extras or a data URI to this intent as appropriate.
            resultIntent.putExtra("ARG_BARCODE", it)
            setResult(RESULT_OK, resultIntent)
            finish()

        }, onCanceled = {}, onEmptyResult = {}, onFailure = {
            Toast.makeText(this@AddBySearchActivity, it.message + "", Toast.LENGTH_LONG).show()
        })

    }

    // Initialize the SearchView
    @SuppressLint("CheckResult")
    private fun initSearchView() {
        viewDataBinding!!.searchView.isIconifiedByDefault = false
        viewDataBinding!!.searchView.setOnQueryTextListener(this)

        viewDataBinding!!.searchView.queryHint = getString(R.string.search_item_hint)

        searchObservable = getCurrentSearchObservable()
        searchObservable.debounce(1, TimeUnit.SECONDS).subscribe(this::getProducts)
    }

    private fun getCurrentSearchObservable(): Observable<String> {
        return Observable.create(this)
    }

    // Set the product list adapter
    private fun setAdapter() {
        mAdapter = SimilarProductListAdapter(this, itemsList, this, 0)
        viewDataBinding!!.rvReplaceItem.adapter = mAdapter
    }

    private fun showAmountDialog(product: SimilarProduct) {
        amountDialog = AmountDialogFragment.newInstance(product, 1.0)
        amountDialog!!.show(supportFragmentManager, AmountDialogFragment.javaClass.name)
        amountDialog!!.setAmountNextClickListener(this)
    }

    // Get the product list by search key
    private fun getProducts(search: String) {
        runOnUiThread { viewDataBinding!!.progress.visibility = View.VISIBLE }

        viewModel.shopperAddProductList(itemId, search, object :
            HandleResponse<SimilarResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                runOnUiThread { viewDataBinding!!.progress.visibility = View.GONE }
                if (isNetworkConnected) {
                    Toast.makeText(this@AddBySearchActivity, error?.message, Toast.LENGTH_LONG)
                        .show()
                } else {
                    Toast.makeText(
                        this@AddBySearchActivity,
                        resources?.getString(R.string.no_internet_conn_msg_txt),
                        Toast.LENGTH_LONG
                    ).show()
                }
            }

            override fun handleSuccessResponse(successResponse: SimilarResponse) {
                runOnUiThread { viewDataBinding!!.progress.visibility = View.GONE }

                val data = successResponse.response
                if (data != null) {
                    if (data.httpCode == 200) {
                        onSuccess(data.similarProducts)
                    } else {
                        Toast.makeText(this@AddBySearchActivity, data.message, Toast.LENGTH_SHORT)
                            .show()
                    }
                } else {
                    Toast.makeText(
                        this@AddBySearchActivity,
                        R.string.error_server_return_null,
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        })
    }

    // Process the search result
    private fun onSuccess(list: ArrayList<SimilarProduct>) {
        itemsList = list
        setAdapter()

        if (itemsList.size > 0) {
            viewDataBinding!!.txtNoResultFound.visibility = View.GONE
        } else {
            viewDataBinding!!.txtNoResultFound.visibility = View.VISIBLE
        }
    }

    /**
     * SimilarProductList ClickListener
     */
    override fun onClickSimilarProduct(item: SimilarProduct) {
        if (!onItemClick) {
            onItemClick = true
            selected = item
            showAmountDialog(item)

            onItemClick = false
        }
    }

    /**
     * Observable Subscriber
     */
    override fun subscribe(emitter: ObservableEmitter<String>) {
        mEmitter = emitter
    }

    /**
     * SearchView QueryTextListener
     */
    override fun onQueryTextSubmit(query: String?): Boolean {
        if (query == null || query.isEmpty()) {
            mAdapter = SimilarProductListAdapter(this, arrayListOf(), this)
            viewDataBinding!!.rvReplaceItem.adapter = mAdapter
        } else {
            getProducts(query)
        }

        return false
    }

    override fun onQueryTextChange(newText: String?): Boolean {
        if (newText == null || newText.isEmpty()) {
            mAdapter = SimilarProductListAdapter(this, arrayListOf(), this)
            viewDataBinding!!.rvReplaceItem.adapter = mAdapter
        } else {
            mEmitter.onNext(newText)
        }

        return true
    }

    /**
     * AmountNewDialog ClickListener
     */
    override fun onNextClick(amount: Double) {

        viewModel.addItemByBarcode(
            orderId,
            selected!!.barCode ?: "",
            amount,
            0,
            object : HandleResponse<SimpleResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (isNetworkConnected) {
                        Toast.makeText(this@AddBySearchActivity, error?.message, Toast.LENGTH_LONG)
                            .show()
                    } else {
                        Toast.makeText(
                            this@AddBySearchActivity,
                            resources?.getString(R.string.no_internet_conn_msg_txt),
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

                override fun handleSuccessResponse(successResponse: SimpleResponse) {
                    if (successResponse.response != null) {
                        Toast.makeText(
                            this@AddBySearchActivity,
                            successResponse.response.message,
                            Toast.LENGTH_SHORT
                        ).show()
                        if (successResponse.response.httpCode == 200) {

                            val message: String =
                                AppConstants.MESSAGE_TYPE_ADD + " " + PreferenceManager.currentShopperFirstName + " " + resources.getString(
                                    R.string.added
                                ) + " " + selected!!.productName

                            val systemMessageReq =
                                SystemMessageReq(orderId.toString(), "text", message!!)
                            sendSysteMessage(systemMessageReq)
                        }
                    } else {
                        Toast.makeText(
                            this@AddBySearchActivity,
                            R.string.error_server_return_null,
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            })
    }


    fun sendSysteMessage(systemMessageReq: SystemMessageReq) {
        viewModel.sendSystemMessage(systemMessageReq, object : HandleResponse<SystemMessage> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                onAfterSendSystemMessage()
            }

            override fun handleSuccessResponse(successResponse: SystemMessage) {
                onAfterSendSystemMessage()
            }
        })
    }

    private fun onAfterSendSystemMessage() {
        try {
            runOnUiThread {
                // Dismiss the Amount popup
                if (amountDialog != null)
                    amountDialog!!.dismissAllowingStateLoss()

                finish()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


    override fun onNextClick(itemId: Long, amount: Double) {

    }

    override fun onNextClick(amount: Double, weight: Double) {

        viewModel.addItemByBarcode(
            orderId,
            selected!!.barCode ?: "",
            amount,
            0,
            object : HandleResponse<SimpleResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (isNetworkConnected) {
                        Toast.makeText(this@AddBySearchActivity, error?.message, Toast.LENGTH_LONG)
                            .show()
                    } else {
                        Toast.makeText(
                            this@AddBySearchActivity,
                            resources?.getString(R.string.no_internet_conn_msg_txt),
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

                override fun handleSuccessResponse(successResponse: SimpleResponse) {
                    if (successResponse.response != null) {
                        Toast.makeText(
                            this@AddBySearchActivity,
                            successResponse.response.message,
                            Toast.LENGTH_SHORT
                        ).show()
                        if (successResponse.response.httpCode == 200) {

                            runOnUiThread {
                                if (amountDialog != null)
                                    amountDialog!!.dismissAllowingStateLoss()

                                finish()
                            }
                        }
                    } else {
                        Toast.makeText(
                            this@AddBySearchActivity,
                            R.string.error_server_return_null,
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            })
    }

    override fun onNextClick(itemId: Long, amount: Double, weight: Double) {

    }

    /**
     * OnActivityResult
     */
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == BARCODE_ACTIVITY) {
            if (resultCode == Activity.RESULT_OK) {
                setResult(Activity.RESULT_OK, data)
                finish()
            }
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    override fun onBackPressed() {
//        super.onBackPressed()
        hideKeyboard()
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()

        mEmitter.onComplete()
    }

    override fun onResume() {
        super.onResume()

        onItemClick = false
    }

    override fun onStart() {
        super.onStart()

        onItemClick = false
    }

}