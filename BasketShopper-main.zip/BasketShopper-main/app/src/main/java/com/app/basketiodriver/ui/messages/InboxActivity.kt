package com.app.basketiodriver.ui.messages

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.ActivityInboxBinding
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.chat.ChatViewModel

class InboxActivity : BaseActivity<ActivityInboxBinding?, ChatViewModel>() {


    override val layoutId: Int
        get() = R.layout.activity_inbox

    override val viewModel: ChatViewModel
        get() {
            return getViewModel(ChatViewModel::class.java)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        initToolbar(
            "Inbox",
            true, viewDataBinding!!.toolbarLayout.toolbar,
            View.OnClickListener {
                run {
                    finish()
                }
            })


    }

    companion object {
        fun newIntent(context: Context?): Intent {
            return Intent(context, InboxActivity::class.java)
        }
    }


}
