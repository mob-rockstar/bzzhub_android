package com.app.basketiodriver.data.model.api.requests

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

/**
 * Created by ibraheem lubbad on 2020-02-11.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 */
data class EarningReportDetailRequest(
    @field:SerializedName("shopper_id") @field:Expose val shopper_id: Int,
    @field:SerializedName("language_id") @field:Expose val language_id: Int,
    @field:SerializedName("type") @field:Expose val type: String,
    @field:SerializedName("year") @field:Expose val year: Int,
    @field:SerializedName("month") @field:Expose val month: Int,
    @field:SerializedName("week") @field:Expose val week: Int,
    @field:SerializedName("day") @field:Expose val day: Int


)