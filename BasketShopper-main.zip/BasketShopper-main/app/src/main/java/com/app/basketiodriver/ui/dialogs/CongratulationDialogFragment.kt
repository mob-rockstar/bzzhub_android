package com.app.basketiodriver.ui.dialogs

import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentCongratulationDialogBinding
import com.app.basketiodriver.ui.base.BaseDialogFragment
import com.app.basketiodriver.ui.home.HomeViewModel
import java.util.*

class CongratulationDialogFragment : BaseDialogFragment<FragmentCongratulationDialogBinding, HomeViewModel> (){
    override val layoutId: Int
        get() = R.layout.fragment_congratulation_dialog

    override val viewModel: HomeViewModel
        get() {
            return getViewModel(baseActivity, HomeViewModel::class.java)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    // Set Full screen
    override fun getTheme(): Int {
        return R.style.MyDialogWhite
    }

    var orderId : Long = 0

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        /**
         * get params
         */
        arguments?.let {
            orderId = it.getLong(KEY_ORDER_ID)

            initViews()
        }
    }

    private fun initViews(){
        viewDataBinding!!.txtOrder.text = String.format(Locale.ENGLISH, "%s %d %s", getString(R.string.order_number), orderId, getString(R.string.order_successfully_completed))
        viewDataBinding!!.ivClose.setOnClickListener {
            dismiss()
        }
    }

    companion object {
        const val KEY_ORDER_ID        = "order_id"

        fun newInstance(
            orderId : Long
        ): CongratulationDialogFragment {
            val fragment = CongratulationDialogFragment()

            val data = Bundle()
            data.putLong(KEY_ORDER_ID, orderId)

            fragment.arguments = data

            return fragment
        }
    }
}