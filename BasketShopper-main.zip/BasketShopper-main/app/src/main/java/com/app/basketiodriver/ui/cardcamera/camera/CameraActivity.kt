package com.app.basketiodriver.ui.cardcamera.camera

import android.Manifest
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.SurfaceHolder
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.ActivityCameraBinding
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.cardcamera.CameraViewModel
import com.app.basketiodriver.utils.AppConstants
import com.app.basketiodriver.utils.AppLogger
import com.app.basketiodriver.utils.CommonUtils.isFastClick
import com.app.basketiodriver.utils.FileUtils.createOrExistsDir
import com.app.basketiodriver.utils.ImageUtils.getBitmapFromByte
import com.app.basketiodriver.utils.ImageUtils.save
import com.app.basketiodriver.utils.PermissionUtils
import com.app.basketiodriver.utils.ScreenUtils
//import com.google.android.gms.vision.CameraSource
//import com.google.android.gms.vision.Detector
//import com.google.android.gms.vision.Detector.Detections
//import com.google.android.gms.vision.barcode.Barcode
//import com.google.android.gms.vision.barcode.BarcodeDetector
import com.theartofdev.edmodo.cropper.CropImageView
import com.theartofdev.edmodo.cropper.CropImageView.OnCropImageCompleteListener
import java.io.IOException


class CameraActivity : BaseActivity<ActivityCameraBinding?, CameraViewModel>(),
    View.OnClickListener, CropImageView.OnSetImageUriCompleteListener,
    OnCropImageCompleteListener {


    override val layoutId: Int
        get() = R.layout.activity_camera

    override val viewModel: CameraViewModel
        get() {
            return getViewModel(CameraViewModel::class.java)
        }
    private var mCropBitmap: Bitmap? = null
    /*  private var mCropImageView: CropImageView? = null

      private var mCameraPreview: CameraPreview? = null
      private var mLlCameraCropContainer: View? = null
      private var mIvCameraCrop: ImageView? = null
      private var mIvCameraFlash: ImageView? = null
      private var mLlCameraOption: View? = null
      private var mLlCameraResult: View? = null
      private var mViewCameraCropBottom: TextView? = null
      private var mFlCameraOption: FrameLayout? = null
      private var mViewCameraCropLeft: View? = null*/

//    var cameraSource: CameraSource? = null


    private var mType = 0
    private var isToast = true
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val checkPermissionFirst = PermissionUtils.checkPermissionFirst(
            this,
            IDCardCamera.PERMISSION_CODE_FIRST,
            arrayOf(
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.CAMERA
            )
        )
        if (checkPermissionFirst) {
            init()
        }
    }


    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        var isPermissions = true
        for (i in permissions.indices) {
            if (grantResults[i] == PackageManager.PERMISSION_DENIED) {
                isPermissions = false
                if (!ActivityCompat.shouldShowRequestPermissionRationale(
                        this,
                        permissions[i]
                    )
                ) {
                    if (isToast) {
                        Toast.makeText(
                            this,
                            "الرجاء فتح الأذونات المطلوبة من قبل التطبيق يدويًا\n",
                            Toast.LENGTH_SHORT
                        ).show()
                        isToast = false
                    }
                }
            }
        }
        isToast = true
        if (isPermissions) {
            Log.d("onRequestPermission", "onRequestPermissionsResult: ")
            init()
        } else {
            Log.d("onRequestPermission", "onRequestPermissionsResult: ")
            finish()
        }
    }

    private fun initBarCode() {
//        val barcodeDetector = BarcodeDetector.Builder(this)
//            .setBarcodeFormats(Barcode.QR_CODE) //QR_CODE)
//            .build()
//
//        cameraSource = CameraSource.Builder(this, barcodeDetector)
//            .setRequestedPreviewSize(640, 480)
//            .build()
//
//
//
//        viewDataBinding!!.cameraPreview.holder.addCallback(object : SurfaceHolder.Callback {
//            override fun surfaceCreated(holder: SurfaceHolder) {
//                try {
//                    cameraSource!!.start(viewDataBinding!!.cameraPreview.holder)
//                } catch (ie: IOException) {
//                    Log.e("CAMERA SOURCE", ie.message)
//                }
//            }
//
//            override fun surfaceChanged(
//                holder: SurfaceHolder,
//                format: Int,
//                width: Int,
//                height: Int
//            ) {
//            }
//
//            override fun surfaceDestroyed(holder: SurfaceHolder) {
//                cameraSource!!.stop()
//            }
//        })
//
//
//        barcodeDetector.setProcessor(object : Detector.Processor<Barcode> {
//            override fun release() {}
//            override fun receiveDetections(detections: Detections<Barcode>) {
//                val barcodes = detections.detectedItems
//                if (barcodes.size() != 0) {
//                    // barcodes.valueAt(0).displayValue
//                }
//            }
//        })
    }

    private fun init() {
        //  setContentView(R.layout.activity_camera)
        mType = intent.getIntExtra(IDCardCamera.TAKE_TYPE, 0)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        initView()
        initListener()
    }

    private fun initView() {

        val screenMinSize =
            ScreenUtils.getScreenWidth(this).coerceAtMost(ScreenUtils.getScreenHeight(this))
                .toFloat()

        val screenMaxSize =
            ScreenUtils.getScreenWidth(this).coerceAtLeast(ScreenUtils.getScreenHeight(this))
                .toFloat()


        val width: Float = ((screenMaxSize * 0.75f))
        val height: Float = (width * 75.0f / 47.0f)

        val flCameraOptionWidth = (screenMaxSize - width) / 2
        val flCameraOptionHeight = (screenMaxSize - height) / 2
        val containerParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        val cropParams = LinearLayout.LayoutParams(width.toInt(), height.toInt())
        val cameraOptionParams = RelativeLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT

        )
        viewDataBinding!!.llCameraCropContainer.layoutParams = containerParams
        viewDataBinding!!.ivCameraCrop.layoutParams = cropParams
        viewDataBinding!!.flCameraOption.layoutParams = cameraOptionParams
        when (mType) {
            //     IDCardCamera.TYPE_IDCARD_FRONT ->  viewDataBinding!!.ivCameraCrop!!.setImageResource(R.mipmap.camera_idcard_front)
            //  IDCardCamera.TYPE_IDCARD_BACK -> mIvCameraCrop!!.setImageResource(R.mipmap.camera_idcard_back)
        }
        Handler()
            .postDelayed({
                runOnUiThread {
                    viewDataBinding!!.cameraPreview.visibility = View.VISIBLE
                }
            }, 500)
    }

    private fun initListener() {
        viewDataBinding!!.cameraPreview.setOnClickListener(this)
        viewDataBinding!!.ivCameraFlash.setOnClickListener(this)
        findViewById<View>(R.id.iv_camera_close).setOnClickListener(this)
        findViewById<View>(R.id.iv_camera_take).setOnClickListener(this)
        findViewById<View>(R.id.iv_camera_result_ok).setOnClickListener(this)
        findViewById<View>(R.id.iv_camera_result_cancel).setOnClickListener(this)

        viewDataBinding!!.cropImageView.setOnSetImageUriCompleteListener(this)
        viewDataBinding!!.cropImageView.setOnCropImageCompleteListener(this)
    }

    override fun onClick(v: View) {
        val id = v.id
        if (id == R.id.camera_preview) {
            viewDataBinding!!.cameraPreview.focus()
        } else if (id == R.id.iv_camera_close) {
            finish()
        } else if (id == R.id.iv_camera_take) {
            if (!isFastClick()) {
                takePhoto()
            }
        } else if (id == R.id.iv_camera_flash) {
            if (CameraUtils.hasFlash(this)) {
                val isFlashOn = viewDataBinding!!.cameraPreview.switchFlashLight()
                viewDataBinding!!.ivCameraFlash.setImageResource(if (isFlashOn) R.mipmap.camera_flash_on else R.mipmap.camera_flash_off)
            } else {
                Toast.makeText(this, R.string.no_flash, Toast.LENGTH_SHORT).show()
            }
        } else if (id == R.id.iv_camera_result_ok) {
            confirm()
        } else if (id == R.id.iv_camera_result_cancel) {
            viewDataBinding!!.cameraPreview.isEnabled = true
            viewDataBinding!!.cameraPreview.addCallback()
            viewDataBinding!!.cameraPreview.startPreview()
            viewDataBinding!!.ivCameraFlash.setImageResource(R.mipmap.camera_flash_off)
            setTakePhotoLayout()
        }
    }


    private fun takePhoto() {
        viewDataBinding!!.cameraPreview.isEnabled = false
        CameraUtils.camera!!.setOneShotPreviewCallback { bytes, camera ->


            //   startActivity(PreviewCameraActivity.newIntent(this,camera.parameters.previewSize,bytes))
            val size =
                camera.parameters.previewSize
            camera.stopPreview()

            Thread(Runnable {
                val w = size.width
                val h = size.height
                val bitmap = getBitmapFromByte(bytes, w, h)
                cropImage(bitmap)
            }).start()
        }
    }


    private fun cropImage(bitmap: Bitmap?) {


        try {


            mCropBitmap = bitmap!!
            /*     Bitmap.createBitmap(
                     bitmap!!,
                     (leftProportion * bitmap.width.toFloat()).toInt(),
                     (topProportion * bitmap.height.toFloat()).toInt(),
                     ((rightProportion - leftProportion) * bitmap.width.toFloat()).toInt(),
                     ((bottomProportion - topProportion) * bitmap.height.toFloat()).toInt()
                 )*/
            runOnUiThread {
                /* viewDataBinding!!.cropImageView.layoutParams = LinearLayout.LayoutParams(
                       viewDataBinding!!.ivCameraCrop.width,
                       viewDataBinding!!.ivCameraCrop.height
                   )*/
                setCropLayout()
                viewDataBinding!!.cropImageView.setImageBitmap(bitmap)
            }


        } catch (ex: Exception) {
            AppLogger.d("CameraActivity Exception    ${ex.message}")

        }
    }


    private fun setCropLayout() {
        viewDataBinding!!.ivCameraCrop.visibility = View.GONE
        viewDataBinding!!.cameraPreview.visibility = View.GONE
        viewDataBinding!!.llCameraOption.visibility = View.GONE
        viewDataBinding!!.cropImageView.visibility = View.VISIBLE
        viewDataBinding!!.llCameraResult.visibility = View.VISIBLE
        viewDataBinding!!.viewCameraCropBottom.text = ""
        AppLogger.d("setCropLayout ${viewDataBinding!!.llCameraResult.visibility}")
    }


    private fun setTakePhotoLayout() {
        viewDataBinding!!.ivCameraCrop.visibility = View.VISIBLE
        viewDataBinding!!.cameraPreview.visibility = View.VISIBLE
        viewDataBinding!!.llCameraOption.visibility = View.VISIBLE
        viewDataBinding!!.cropImageView.visibility = View.GONE
        viewDataBinding!!.llCameraResult.visibility = View.GONE
        viewDataBinding!!.viewCameraCropBottom.text = getString(R.string.touch_to_focus)
        viewDataBinding!!.cameraPreview.focus()
    }


    private fun confirm() {

        viewDataBinding!!.cropImageView.getCroppedImageAsync();

   /*     viewDataBinding!!.cropImageView.setOnCropImageCompleteListener { _: CropImageView, cropResult: CropImageView.CropResult ->
            if(cropResult.isSuccessful){
                intent.putExtra(IDCardCamera.IMAGE_PATH,  cropResult.originalUri.path)
                setResult(IDCardCamera.RESULT_CODE, intent)
                finish()
            }else{
                Toast.makeText(this,cropResult.error.message,Toast.LENGTH_SHORT).show()
            }

        }*/


        /*
             viewDataBinding!!.cropImageView.crop(object : CropListener {
                 override fun onFinish(bitmap: Bitmap?) {
                     if (bitmap == null) {
                         Toast.makeText(
                             applicationContext,
                             getString(R.string.crop_fail),
                             Toast.LENGTH_SHORT
                         ).show()
                         finish()
                     }
                     if (createOrExistsDir(
                             AppConstants.DIR_ROOT
                         )
                     ) {
                         val buffer = StringBuffer()
                         var imagePath = ""
                         if (mType == IDCardCamera.TYPE_IDCARD_FRONT) {
                             imagePath =
                                 buffer.append(AppConstants.DIR_ROOT).append(AppConstants.APP_NAME)
                                     .append(".").append("idCardFrontCrop.jpg").toString()
                         } else if (mType == IDCardCamera.TYPE_IDCARD_BACK) {
                             imagePath =
                                 buffer.append(AppConstants.DIR_ROOT).append(AppConstants.APP_NAME)
                                     .append(".").append("idCardBackCrop.jpg").toString()
                         }
                         if (save(bitmap!!, imagePath, Bitmap.CompressFormat.JPEG)) {
                             val intent = Intent()
                             intent.putExtra(IDCardCamera.IMAGE_PATH, imagePath)
                             setResult(IDCardCamera.RESULT_CODE, intent)
                             finish()
                         }
                     }
                 }

             }, true)*/
    }

    override fun onStart() {
        super.onStart()
        if (viewDataBinding!!.cameraPreview != null) {
            viewDataBinding!!.cameraPreview.onStart()
        }
    }

    override fun onStop() {
        super.onStop()
        if (viewDataBinding!!.cameraPreview != null) {
            viewDataBinding!!.cameraPreview.onStop()
        }
    }

    override fun onSetImageUriComplete(
        view: CropImageView?,
        uri: Uri?,
        error: java.lang.Exception?
    ) {
        TODO("Not yet implemented")
    }

    override fun onCropImageComplete(view: CropImageView?, result: CropImageView.CropResult?) {
        AppLogger.d("onCropImageComplete isSuccessful ${result!!.isSuccessful}")
        AppLogger.d("onCropImageComplete error ${result.error}")
     /*   if (result.isSuccessful) {

            val intent = Intent()
            intent.putExtra(IDCardCamera.IMAGE_PATH, result.uri.path)
            setResult(IDCardCamera.RESULT_CODE, intent)
            finish()


        }else{
            Toast.makeText(
                applicationContext,
                getString(R.string.crop_fail),
                Toast.LENGTH_SHORT
            ).show()
            finish()

        }*/
 AppLogger.d("onCropImageComplete ")
        if (createOrExistsDir(AppConstants.DIR_ROOT)) {
            val buffer = StringBuffer()
            var imagePath = ""
            imagePath =
                buffer
                    .append(AppConstants.DIR_ROOT)
                    .append(AppConstants.APP_NAME)
                    .append(".")
                    .append("${System.currentTimeMillis()}.jpg")
                    .toString()


            if (save(result!!.bitmap!!, imagePath, Bitmap.CompressFormat.JPEG)) {
                val intent = Intent()
                intent.putExtra(IDCardCamera.IMAGE_PATH, imagePath)
                setResult(IDCardCamera.RESULT_CODE, intent)
                finish()
            }
        }
    }
}