package com.app.basketiodriver.ui.chat.adapter

import android.graphics.Color
import android.media.AudioManager
import android.media.MediaPlayer
import android.opengl.Visibility
import android.os.Handler
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.View.GONE
import android.view.ViewGroup
import android.widget.SeekBar
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.SimpleColorFilter
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.chat.ChatMessage
import com.app.basketiodriver.data.model.api.chat.User
import com.bumptech.glide.load.engine.DiskCacheStrategy
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.HashMap
import com.app.basketiodriver.data.remote.socket.SocketManager
import com.app.basketiodriver.data.remote.socket.SocketManager.Companion.CHAT_MESSAGE_TYPE_VIDEO
import com.app.basketiodriver.databinding.*
import com.app.basketiodriver.utils.FormatterUtils
import com.app.basketiodriver.utils.GlideApp
import com.vanniktech.emoji.EmojiUtils
import timber.log.Timber


class ChatMessagesAdapter(
    private var messages: List<ChatMessage>,
    private val onRead: (chatMessage: ChatMessage) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var listener: OnItemSelectListener? = null
    private var dateParser = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.getDefault())

    private var mediaPlayers = HashMap<Int, MediaPlayer?>()
    private var playingVoicePosition = -1
    private var playingVoiceViewHolder: VoiceViewHolder? = null
    private var playingUserVoiceViewHolder : UserVoiceViewHolder? = null
    private val voicePlayingHandler = Handler()
    private val voicePlayingRunnable = object: Runnable {
        override fun run() {
//            if (playingVoicePosition > -1)
//                playingVoiceViewHolder?.binding?.seekbar?.progress = mediaPlayers[playingVoicePosition]?.currentPosition ?: 0
//            voicePlayingHandler.postDelayed(this, 100)

            if (playingVoicePosition > -1) {
                if (getItemViewType(playingVoicePosition) == CHAT_TYPE_MY_VOICE) {
                    playingVoiceViewHolder?.binding?.seekbar?.progress =
                        mediaPlayers[playingVoicePosition]?.currentPosition ?: 0
                }
                else if (getItemViewType(playingVoicePosition) == CHAT_TYPE_USER_VOICE) {
                    playingUserVoiceViewHolder?.binding?.seekbar?.progress =
                        mediaPlayers[playingVoicePosition]?.currentPosition ?: 0
                }
            }
            voicePlayingHandler.postDelayed(this, 100)
        }
    }

    private var isTyping = false
    private var mapAudioPrepared = HashMap<Int, Boolean>()


    init {
        dateParser.timeZone = TimeZone.getTimeZone("UTC")
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            CHAT_TYPE_NOTIFY -> {
                NotifyViewHolder(
                    DataBindingUtil.inflate(LayoutInflater.from(viewGroup.context), R.layout.item_chat_notify, viewGroup, false)
                )
            }
            CHAT_TYPE_TYPING -> {
                TypingViewHolder(
                    DataBindingUtil.inflate(LayoutInflater.from(viewGroup.context), R.layout.item_chat_typing, viewGroup, false)
                )
            }
            CHAT_TYPE_IMAGE -> ImageViewHolder(
                DataBindingUtil.inflate(LayoutInflater.from(viewGroup.context), R.layout.item_chat_image, viewGroup, false)
            )
            CHAT_TYPE_VIDEO -> VideoViewHolder(
                DataBindingUtil.inflate(LayoutInflater.from(viewGroup.context), R.layout.item_chat_video, viewGroup, false)
            )
            CHAT_TYPE_MY_VOICE -> VoiceViewHolder(
                DataBindingUtil.inflate(LayoutInflater.from(viewGroup.context), R.layout.item_chat_voice, viewGroup, false)
            )
            CHAT_TYPE_USER_VOICE -> UserVoiceViewHolder(
                DataBindingUtil.inflate(LayoutInflater.from(viewGroup.context), R.layout.item_chat_user_voice, viewGroup, false)
            )
            else -> MessageViewHolder(
                DataBindingUtil.inflate(LayoutInflater.from(viewGroup.context), R.layout.item_chat_message, viewGroup, false)
            )
        }
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val context = viewHolder.itemView.context
        // update typing status view
        if (getItemViewType(position) == CHAT_TYPE_TYPING) {
            val holder = viewHolder as TypingViewHolder
            holder.binding.tvMessage.visibility = if (isTyping) View.VISIBLE else View.INVISIBLE
            holder.binding.tvMessage.text = context.getString(R.string.str_typing, "User")
            return
        }

        val chatMessage = messages[position]
        if (getItemViewType(position) != CHAT_TYPE_NOTIFY) {
            onRead(chatMessage)
        }

        var isFirstMessage = isFirstMessageOfDay(position)
        val sendDate = getSendDate(chatMessage)
        val sendTime = getSendTime(chatMessage)

        when {
            getItemViewType(position) == CHAT_TYPE_NOTIFY -> {
                try{
                    val holder = viewHolder as NotifyViewHolder
                    holder.binding.run {

                        val contentText = chatMessage.content!!.split(":")
                        if (contentText.size == 2){
                            tvMessage.text = contentText[1]

                            ivNotify.setImageResource(when (contentText[0]) {
                                "shopping start" -> R.drawable.ic_notify_notification
                                "replace item" -> R.drawable.ic_notify_replaced
                                "refund item" -> R.drawable.ic_notify_refunded
                                "checkout order" -> R.drawable.ic_notify_checked
                                "start delivery" -> R.drawable.ic_notify_delivering
                                "order delivered" -> R.drawable.ic_notify_delivered
                                "driver joint" -> R.drawable.ic_notify_joined
                                else -> R.drawable.ic_notify_notification
                            })
                        }else{
                            tvMessage.text = chatMessage.content
                        }
                    }
                }
                catch (e : Exception) {
                    e.printStackTrace()
                }
            }
            getItemViewType(position) == CHAT_TYPE_IMAGE -> {
                val holder = viewHolder as ImageViewHolder
                holder.binding.run {
                    GlideApp.with(context).load(chatMessage.content).diskCacheStrategy(
                        DiskCacheStrategy.ALL).fitCenter().placeholder(R.drawable.placeholder300x300).error(R.drawable.placeholder300x300).into(ivContent)
                    tvDate.visibility = if (isFirstMessage) View.VISIBLE else View.GONE
                    tvDate.text = sendDate
                    tvTime.text = sendTime

                    if (isMine(chatMessage)) {
                        layoutContent.gravity = Gravity.END
                        imageContainer.setBackgroundResource(R.drawable.bg_chat_image)
                        tvTime.setTextColor(Color.WHITE)
                        ivTick.visibility = if (chatMessage.isReceived) View.VISIBLE else View.GONE
                        ivTick.setImageResource(if (chatMessage.isRead) R.drawable.ic_chat_double_tick else R.drawable.ic_chat_tick)
                    } else {
                        layoutContent.gravity = Gravity.START
                        imageContainer.setBackgroundResource(R.drawable.bg_round_chat_white_15dp)
                        tvTime.setTextColor(Color.BLACK)
                        ivTick.visibility = View.GONE
                    }
                    ivContent.setOnClickListener {
                        if (chatMessage.content != null) {
                            listener?.onImageSelected(chatMessage.content!!)
                            stopCurrentPlayingVoice(isMine(chatMessage))
                        }
                    }
                }
            }
            getItemViewType(position) == CHAT_TYPE_VIDEO -> {
                val holder = viewHolder as VideoViewHolder
                holder.binding.run {
                    tvUserName.visibility = View.GONE
                    GlideApp.with(context).load(chatMessage.content).fitCenter().into(ivContent)
                    tvDate.visibility = if (isFirstMessage) View.VISIBLE else View.GONE
                    tvDate.text = sendDate
                    tvTime.text = sendTime

                    if (isMine(chatMessage)) {
                        layoutContent.gravity = Gravity.END
                        videoContainer.setBackgroundResource(R.drawable.bg_chat_image)
                        tvTime.setTextColor(Color.WHITE)
                        ivTick.visibility = if (chatMessage.isReceived) View.VISIBLE else View.GONE
                        ivTick.setImageResource(if (chatMessage.isRead) R.drawable.ic_chat_double_tick else R.drawable.ic_chat_tick)
                    } else {
                        layoutContent.gravity = Gravity.START
                        ivTick.visibility = View.GONE
                        videoContainer.setBackgroundResource(R.drawable.bg_round_chat_white_15dp)
                        tvTime.setTextColor(Color.BLACK)
                    }
                    ivPlay.setOnClickListener {
                        if (chatMessage.content != null) {
                            listener?.onVideoSelected(chatMessage.content!!)
                            stopCurrentPlayingVoice(isMine(chatMessage))
                        }
                    }
                }
            }
            getItemViewType(position) == CHAT_TYPE_MY_VOICE -> {
                val holder = viewHolder as VoiceViewHolder
                updateVoiceViewHolder(holder, position)
            }
            getItemViewType(position) == CHAT_TYPE_USER_VOICE -> {
                val holder = viewHolder as UserVoiceViewHolder
                updateUserVoiceViewHolder(holder, position)
            }
            getItemViewType(position) == CHAT_TYPE_MESSAGE  -> {
                val holder = viewHolder as MessageViewHolder
                holder.binding.run {
                    tvMessage.text = chatMessage.content
                    tvDate.visibility = if (isFirstMessage) View.VISIBLE else View.GONE
                    tvDate.text = sendDate
                    tvTime.text = sendTime

                    if (isMine(chatMessage)) {
                        layoutMessage.gravity = Gravity.END
                        chatContentView.setBackgroundResource(R.drawable.bg_chat_image)
                        tvTime.setTextColor(Color.WHITE)
                        ivTick.visibility = if (chatMessage.isReceived) View.VISIBLE else View.GONE
                        ivTick.setImageResource(if (chatMessage.isRead) R.drawable.ic_chat_double_tick else R.drawable.ic_chat_tick)

                        tvMessage.run {
                            setTextColor(Color.WHITE)
//                            setBackgroundResource(R.drawable.bg_round_chat_green_6dp)
                        }
                    } else {
                        layoutMessage.gravity = Gravity.START
                        ivTick.visibility = View.GONE
                        tvTime.setTextColor(Color.BLACK)
                        chatContentView.setBackgroundResource(R.drawable.bg_round_chat_white_15dp)

                        tvMessage.run {
                            setTextColor(Color.BLACK)
//                            setBackgroundResource(R.drawable.bg_round_grey_light_3dp)
                        }
                    }
                }
            }
        }
    }

    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        if (holder == playingVoiceViewHolder) {
            playingVoiceViewHolder = null // should be reset if view holder is recycled for another item
        }
        else if (holder == playingUserVoiceViewHolder) {
            playingUserVoiceViewHolder = null
        }
        super.onViewRecycled(holder)
    }

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)
        voicePlayingHandler.postDelayed(voicePlayingRunnable, 100)
    }

    override fun onDetachedFromRecyclerView(recyclerView: RecyclerView) {
        // release all media players
        for ((position, player) in mediaPlayers) {
            player?.stop()
            player?.release()
        }
        voicePlayingHandler.removeCallbacks(voicePlayingRunnable)

        super.onDetachedFromRecyclerView(recyclerView)
    }

    override fun getItemCount(): Int {
        return messages.size + 1
    }
    override fun getItemViewType(position: Int): Int {
//        return when {
//            position == messages.size -> CHAT_TYPE_TYPING
//            messages[position]
//                .by?.type == User.TYPE_SYSTEM -> CHAT_TYPE_NOTIFY
//            else -> {
//                when (messages[position].type) {
//                    SocketManager.CHAT_MESSAGE_TYPE_IMAGE -> CHAT_TYPE_IMAGE
//                    SocketManager.CHAT_MESSAGE_TYPE_VIDEO -> CHAT_TYPE_VIDEO
//                    SocketManager.CHAT_MESSAGE_TYPE_VOICE -> CHAT_TYPE_VOICE
//                    SocketManager.CHAT_MESSAGE_TYPE_TEXT -> CHAT_TYPE_MESSAGE
//                    else -> CHAT_TYPE_INVALID
//                }
//            }
//        }

        if (position == messages.size){
            return CHAT_TYPE_TYPING
        }
        else{
            if (messages[position].type == SocketManager.CHAT_MESSAGE_TYPE_IMAGE){
                return CHAT_TYPE_IMAGE
            }
            else if (messages[position].type == SocketManager.CHAT_MESSAGE_TYPE_VIDEO){
                return CHAT_TYPE_VIDEO
            }
            else if (messages[position].type == SocketManager.CHAT_MESSAGE_TYPE_VOICE) {
                if (isMine(messages[position])) {
                    return CHAT_TYPE_MY_VOICE
                } else {
                    return CHAT_TYPE_USER_VOICE
                }
            }
            else if (messages[position].type == SocketManager.CHAT_MESSAGE_TYPE_TEXT) {
                return if (messages[position].by != null && messages[position].by!!.type != null && messages[position].by!!.type == User.TYPE_SYSTEM){
                    CHAT_TYPE_NOTIFY
                }
                else{
                    CHAT_TYPE_MESSAGE
                }
            }
            else{
                return CHAT_TYPE_INVALID
            }
        }
    }


    fun setListener(l: OnItemSelectListener) {
        listener = l
    }

    fun setTypingStatus(typing: Boolean) {
        isTyping = typing
        notifyDataSetChanged()
    }

    /**
     * Set the message history
     */
    fun setMessageHistory(messageList: List<ChatMessage>){
        this.messages = messageList
    }

    private fun isFirstMessageOfDay(position: Int): Boolean {
        var isFirstMessage = true
        if (position > 0) {
            val prevMessage = messages[position-1]
            val currentMessage = messages[position]

            val prevMessageType = getItemViewType(position-1)
            val currentMessageType = getItemViewType(position)
            try {
                // Set date text
                val prevSendAt = dateParser.parse(prevMessage.send_at ?: "")
                val sendAt = dateParser.parse(currentMessage.send_at ?: "")
                val format = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)

                if (prevMessageType == currentMessageType) {
                    isFirstMessage = format.format(prevSendAt) != format.format(sendAt)
                }
                else{
                    isFirstMessage = prevMessageType == CHAT_TYPE_NOTIFY && (currentMessageType != CHAT_TYPE_NOTIFY && currentMessageType != CHAT_TYPE_TYPING)
                }
            }
            catch (e: ParseException) {
                e.printStackTrace()
                isFirstMessage = false
            }
        }
        return isFirstMessage
    }

    private fun getSendDate(chatMessage: ChatMessage): String {
        var sendTime = ""
        try {
            // Set date text
            val sendAt = dateParser.parse(chatMessage.send_at ?: "")
            val formatter = SimpleDateFormat("EEEE, MMMM dd", Locale.getDefault())
            sendTime = formatter.format(sendAt)
        } catch (e: ParseException) {
            e.printStackTrace()
            sendTime = ""
        }
        return sendTime
    }

    private fun getSendTime(chatMessage: ChatMessage): String {
        var sendTime = ""
        sendTime = try {
            // Set date text
            val sendAt = dateParser.parse(chatMessage.send_at ?: "")
            val formatter = SimpleDateFormat("hh:mm a", Locale.ENGLISH)
            formatter.format(sendAt)
        } catch (e: ParseException) {
            e.printStackTrace()
            ""
        }
        return sendTime
    }

    private fun isMine(chatMessage: ChatMessage): Boolean {
        return chatMessage.by?.id == PreferenceManager.currentShopperId.toString()
    }

    private fun updateVoiceViewHolder(holder: VoiceViewHolder, position: Int) {
        val context = holder.itemView.context
        val chatMessage = messages[position]

        val isFirstMessage = isFirstMessageOfDay(position)
        val sendDate = getSendDate(chatMessage)
        val sendTime = getSendTime(chatMessage)

        if (position == playingVoicePosition) {
            playingVoiceViewHolder = holder
        }

        holder.binding.run {
            tvUserName.visibility = View.GONE
            tvDuration.text = ""

            var player = mediaPlayers[position]
            if (player == null) {
                player = MediaPlayer()
                player.apply {
                    setAudioStreamType(AudioManager.STREAM_MUSIC)
                    setDataSource(chatMessage.content)
                    prepareAsync()
                }
                mediaPlayers[position] = player
            }

            tvDate.visibility = if (isFirstMessage) View.VISIBLE else View.GONE
            tvDate.text = sendDate
            tvTime.text = sendTime

            if (isMine(chatMessage)) {
                layoutContent.gravity = Gravity.END
                ivTick.visibility = if (chatMessage.isReceived) View.VISIBLE else View.GONE
                ivTick.setImageResource(if (chatMessage.isRead) R.drawable.ic_chat_double_tick else R.drawable.ic_chat_tick)

//                layoutWrapper.setBackgroundResource(R.drawable.bg_round_chat_green_6dp)
//                ivPlay.setColorFilter(Color.DKGRAY)
                ivPlay.setImageResource(R.drawable.ic_play_white)
                tvDuration.setTextColor(Color.WHITE)
                tvTime.setTextColor(Color.WHITE)
                voiceContainer.setBackgroundResource(R.drawable.bg_chat_image)
                //   progressBar.indeterminateDrawable.setTint(Color.DKGRAY)
            } else {
                layoutContent.gravity = Gravity.START
                ivTick.visibility = View.GONE

//                layoutWrapper.setBackgroundResource(R.drawable.bg_round_grey_light_3dp)
//                ivPlay.setColorFilter(Color.BLACK)
                ivPlay.setImageResource(R.drawable.ic_play_green)
                tvDuration.setTextColor(Color.BLACK)
                tvTime.setTextColor(Color.BLACK)
                voiceContainer.setBackgroundResource(R.drawable.bg_round_chat_white_15dp)
                //    progressBar.indeterminateDrawable.setTint(context.getColor(R.color.accent))
            }
            // set color filter for lottie view
//            val filter = SimpleColorFilter(if (isMine(chatMessage)) Color.DKGRAY else Color.BLACK)
//            seekbar.thumb.colorFilter = filter

            seekbar.thumb.alpha = 0
            seekbar.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) player.seekTo(seekbar.progress)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {
                }
                override fun onStopTrackingTouch(seekBar: SeekBar?) {
                }
            })

            // update UI by player status
            if (mapAudioPrepared[position] == true) {
                tvDuration.text = FormatterUtils.formatDuration(player.duration.toLong())
                layoutControls.visibility = View.VISIBLE
                progressBar.visibility = View.GONE
                seekbar.max = player.duration

                if (player.isPlaying) {
                    seekbar.progress = player.currentPosition
                    seekbarMask.visibility = View.GONE // seekbar.isEnabled shows unlike UI
                    ivPlay.setImageResource(if (isMine(chatMessage)) R.drawable.ic_pause_white else R.drawable.ic_pause_green)
                } else {
                    seekbar.progress = 0
                    seekbarMask.visibility = View.VISIBLE
                    ivPlay.setImageResource(if (isMine(chatMessage)) R.drawable.ic_play_white else R.drawable.ic_play_green)
                }
            } else {
                layoutControls.visibility = View.INVISIBLE
                if (progressBar.visibility == GONE){
                    progressBar.visibility = View.VISIBLE
                }
                player.setOnPreparedListener{
                    mapAudioPrepared[position] = true
                    tvDuration.text = FormatterUtils.formatDuration(player.duration.toLong())
                    layoutControls.visibility = View.VISIBLE
                    progressBar.visibility = View.GONE
                    seekbar.max = player.duration
                    seekbar.progress = 0
                    seekbarMask.visibility = View.VISIBLE
                    ivPlay.setImageResource(if (isMine(chatMessage)) R.drawable.ic_play_white else R.drawable.ic_play_green)
                }
            }

            ivPlay.setOnClickListener {
                if (!player.isPlaying) {
                    if (playingVoicePosition != position && mediaPlayers[playingVoicePosition] != null && mediaPlayers[playingVoicePosition]!!.isPlaying) {
                        stopCurrentPlayingVoice(isMine(chatMessage))
                    }
                    player.start()
                    playingVoicePosition = position
                    playingVoiceViewHolder = holder
                    seekbarMask.visibility = View.GONE
                    ivPlay.setImageResource(if (isMine(chatMessage)) R.drawable.ic_pause_white else R.drawable.ic_pause_green)
                } else {
                    player.pause()
                    ivPlay.setImageResource(if (isMine(chatMessage)) R.drawable.ic_play_white else R.drawable.ic_play_green)
                }
            }

            player.setOnCompletionListener {
                ivPlay.setImageResource(if (isMine(chatMessage)) R.drawable.ic_play_white else R.drawable.ic_play_green)
                player.seekTo(0)
                seekbarMask.visibility = View.VISIBLE
            }
        }
    }

    /**
     * User VoiceViewHolder
     */
    private fun updateUserVoiceViewHolder(holder: UserVoiceViewHolder, position: Int) {
        val context = holder.itemView.context
        val chatMessage = messages[position]

        val isFirstMessage = isFirstMessageOfDay(position)
        val sendDate = getSendDate(chatMessage)
        val sendTime = getSendTime(chatMessage)

        if (position == playingVoicePosition) {
            playingUserVoiceViewHolder = holder
        }

        holder.binding.run {
            tvUserName.visibility = View.GONE
            tvDuration.text = ""

            var player = mediaPlayers[position]
            if (player == null) {
                player = MediaPlayer()
                player.apply {
                    setAudioStreamType(AudioManager.STREAM_MUSIC)
                    setDataSource(chatMessage.content)
                    prepareAsync()
                }
                mediaPlayers[position] = player
            }

            tvDate.visibility = if (isFirstMessage) View.VISIBLE else View.GONE
            tvDate.text = sendDate
            tvTime.text = sendTime

            if (isMine(chatMessage)) {
                layoutContent.gravity = Gravity.END
                ivTick.visibility = if (chatMessage.isReceived) View.VISIBLE else View.GONE
                ivTick.setImageResource(if (chatMessage.isRead) R.drawable.ic_chat_double_tick else R.drawable.ic_chat_tick)

//                layoutWrapper.setBackgroundResource(R.drawable.bg_round_chat_green_6dp)
//                ivPlay.setColorFilter(Color.DKGRAY)
                ivPlay.setImageResource(R.drawable.ic_play_white)
                tvDuration.setTextColor(Color.WHITE)
                tvTime.setTextColor(Color.WHITE)
                voiceContainer.setBackgroundResource(R.drawable.bg_chat_image)
                //   progressBar.indeterminateDrawable.setTint(Color.DKGRAY)
            } else {
                layoutContent.gravity = Gravity.START
                ivTick.visibility = View.GONE

//                layoutWrapper.setBackgroundResource(R.drawable.bg_round_grey_light_3dp)
//                ivPlay.setColorFilter(Color.BLACK)
                ivPlay.setImageResource(R.drawable.ic_play_green)
                tvDuration.setTextColor(Color.BLACK)
                tvTime.setTextColor(Color.BLACK)
                voiceContainer.setBackgroundResource(R.drawable.bg_round_chat_white_15dp)
                //    progressBar.indeterminateDrawable.setTint(context.getColor(R.color.accent))
            }
            // set color filter for lottie view
//            val filter = SimpleColorFilter(if (isMine(chatMessage)) Color.DKGRAY else Color.BLACK)
//            seekbar.thumb.colorFilter = filter

            seekbar.thumb.alpha = 0
            seekbar.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) player.seekTo(seekbar.progress)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {
                }
                override fun onStopTrackingTouch(seekBar: SeekBar?) {
                }
            })

            // update UI by player status
            if (mapAudioPrepared[position] == true) {
                tvDuration.text = FormatterUtils.formatDuration(player.duration.toLong())
                layoutControls.visibility = View.VISIBLE
                progressBar.visibility = View.GONE
                seekbar.max = player.duration

                if (player.isPlaying) {
                    seekbar.progress = player.currentPosition
                    seekbarMask.visibility = View.GONE // seekbar.isEnabled shows unlike UI
                    ivPlay.setImageResource(if (isMine(chatMessage)) R.drawable.ic_pause_white else R.drawable.ic_pause_green)
                } else {
                    seekbar.progress = 0
                    seekbarMask.visibility = View.VISIBLE
                    ivPlay.setImageResource(if (isMine(chatMessage)) R.drawable.ic_play_white else R.drawable.ic_play_green)
                }
            } else {
                layoutControls.visibility = View.INVISIBLE
                progressBar.visibility = View.VISIBLE

                player.setOnPreparedListener{
                    mapAudioPrepared[position] = true
                    tvDuration.text = FormatterUtils.formatDuration(player.duration.toLong())
                    layoutControls.visibility = View.VISIBLE
                    progressBar.visibility = View.GONE
                    seekbar.max = player.duration
                    seekbar.progress = 0
                    seekbarMask.visibility = View.VISIBLE
                    ivPlay.setImageResource(if (isMine(chatMessage)) R.drawable.ic_play_white else R.drawable.ic_play_green)
                }
            }

            ivPlay.setOnClickListener {
                if (!player.isPlaying) {
                    if (playingVoicePosition != position && mediaPlayers[playingVoicePosition] != null && mediaPlayers[playingVoicePosition]!!.isPlaying) {
                        stopCurrentPlayingVoice(isMine(chatMessage))
                    }
                    player.start()
                    playingVoicePosition = position
                    playingUserVoiceViewHolder = holder
                    seekbarMask.visibility = View.GONE
                    ivPlay.setImageResource(if (isMine(chatMessage)) R.drawable.ic_pause_white else R.drawable.ic_pause_green)
                } else {
                    player.pause()
                    ivPlay.setImageResource(if (isMine(chatMessage)) R.drawable.ic_play_white else R.drawable.ic_play_green)
                }
            }

            player.setOnCompletionListener {
                ivPlay.setImageResource(if (isMine(chatMessage)) R.drawable.ic_play_white else R.drawable.ic_play_green)
                player.seekTo(0)
                seekbarMask.visibility = View.VISIBLE
            }
        }
    }

    // stop last playing voice
    private fun stopCurrentPlayingVoice(isMineMessage : Boolean) {
        mediaPlayers[playingVoicePosition]?.pause()
        mediaPlayers[playingVoicePosition]?.seekTo(0)
        if (playingVoiceViewHolder != null) {
            playingVoiceViewHolder!!.binding.run {
                seekbar.progress = 0
                seekbarMask.visibility = View.VISIBLE
                ivPlay.setImageResource(R.drawable.ic_play_white)
            }
        }

        if (playingUserVoiceViewHolder != null){
            playingUserVoiceViewHolder!!.binding.run {
                seekbar.progress = 0
                seekbarMask.visibility = View.VISIBLE
                ivPlay.setImageResource(R.drawable.ic_play_green)
            }
        }
//        notifyDataSetChanged()
    }


    inner class NotifyViewHolder(val binding: ItemChatNotifyBinding) : RecyclerView.ViewHolder(binding.root)
    inner class MessageViewHolder(val binding: ItemChatMessageBinding) : RecyclerView.ViewHolder(binding.root)
    inner class ImageViewHolder(val binding: ItemChatImageBinding) : RecyclerView.ViewHolder(binding.root)
    inner class VideoViewHolder(val binding: ItemChatVideoBinding) : RecyclerView.ViewHolder(binding.root)
    inner class VoiceViewHolder(val binding: ItemChatVoiceBinding) : RecyclerView.ViewHolder(binding.root)
    inner class UserVoiceViewHolder(val binding: ItemChatUserVoiceBinding) : RecyclerView.ViewHolder(binding.root)
    inner class TypingViewHolder(val binding: ItemChatTypingBinding) : RecyclerView.ViewHolder(binding.root)

    interface OnItemSelectListener {
        fun onImageSelected(url: String)
        fun onVideoSelected(url: String)
    }

    companion object {
        var CHAT_TYPE_NOTIFY = 1
        var CHAT_TYPE_MESSAGE = 2
        var CHAT_TYPE_IMAGE = 3
        var CHAT_TYPE_VIDEO = 4
        var CHAT_TYPE_MY_VOICE = 5
        var CHAT_TYPE_USER_VOICE = 6
        var CHAT_TYPE_TYPING = 7
        var CHAT_TYPE_INVALID = 8
    }

}