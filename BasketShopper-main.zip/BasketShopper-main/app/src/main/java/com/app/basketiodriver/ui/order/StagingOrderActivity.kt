package com.app.basketiodriver.ui.order

import android.os.Bundle
import android.view.View
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.checkout.OutletOrder
import com.app.basketiodriver.databinding.ActivityStagingOrderBinding
import com.app.basketiodriver.di.Navigators
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.app.basketiodriver.ui.dashbaord.OrdersManager
import com.app.basketiodriver.ui.dialogs.DialogOrderCompleted
import com.app.basketiodriver.ui.dialogs.DialogOrderInfo
import com.app.basketiodriver.utils.SwipeManyStateButton
//import kotlinx.android.synthetic.main.app_bar_with_support.view.*
import java.util.*

class StagingOrderActivity : BaseActivity<ActivityStagingOrderBinding, OrderDetailsViewModel>(), SwipeManyStateButton.OnStateChangeListener{
    override val layoutId: Int
        get() = R.layout.activity_staging_order

    override val viewModel: OrderDetailsViewModel
        get() {
            return getViewModel(OrderDetailsViewModel::class.java)
        }

    var order : OutletOrder? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        initToolbar(getString(R.string.fab_staging_order),
            true, viewDataBinding!!.layoutToolBar.toolbar,
            View.OnClickListener {
                run {
                    onBackPressed()
                }
            })

        // Get the order id
        if (intent.extras != null) {
            order = intent.extras!!.getSerializable("ARG_ORDER") as? OutletOrder
        }

        initViews()
    }

    private fun initViews(){
        // Swipe button
        viewDataBinding!!.orderDetailsSwipeButton.state = 15
        viewDataBinding!!.orderDetailsSwipeButton.setOnStateChangeListener(this)

        // Info button
        viewDataBinding!!.layoutToolBar.ivInfo.setOnClickListener {
            showOrderInfoDialog()
        }
    }

    // Show the order info popup
    private fun showOrderInfoDialog(){
        if (order != null){
            DialogOrderInfo.openDialog(this, order!!)
        }
    }

    // Dismiss the order complete dialog
    private fun dismissOrderCompleteDialog(){
        DialogOrderCompleted.dismissDialog()

        // Go to Dashboard
        onBackPressed()
    }

    override fun onBackPressed() {
//        super.onBackPressed()

        // Go to Dashboard
        Navigators.goToDashboard(this)
    }

    /**
     * SwipeManyStateButton Listener
     */
    override fun onChangeState(state: Int?) {
        val orderId : Long = if (order == null) 0 else (order!!.orderId ?: 0)

        // Show the order complete dialog
        DialogOrderCompleted.openDialog(this, orderId, this::dismissOrderCompleteDialog)
    }
}