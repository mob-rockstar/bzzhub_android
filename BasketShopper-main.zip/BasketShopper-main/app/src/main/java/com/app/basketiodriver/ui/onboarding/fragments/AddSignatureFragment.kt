package com.app.basketiodriver.ui.onboarding.fragments


import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import bloder.com.blitzcore.enableWhen
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.Base.BaseResponse
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.databinding.DialogCongratulationBinding
import com.app.basketiodriver.databinding.FragmentAddSignatureBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.home.HomeActivity
import com.app.basketiodriver.ui.onboarding.OnBoardingViewModel
import com.app.basketiodriver.utils.AppLogger
import com.github.gcacace.signaturepad.views.SignaturePad
//import kotlinx.android.synthetic.main.fragment_add_signature.*


/**
 * Created by ibraheem lubbad on 2020-01-22.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class AddSignatureFragment : BaseFragment<FragmentAddSignatureBinding?, OnBoardingViewModel>(),
    Injectable {

    override val layoutId: Int
        get() = R.layout.fragment_add_signature

    override val viewModel: OnBoardingViewModel
        get() {
            return getViewModel(requireActivity(), OnBoardingViewModel::class.java)
        }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.sign_the_contract))
        setListener()
    }

    private fun setListener() {
        viewDataBinding!!.signaturePad.setOnSignedListener(object : SignaturePad.OnSignedListener {
            override fun onStartSigning() { //Event triggered when the pad is touched
            }

            override fun onSigned() { //Event triggered when the pad is signed
                viewDataBinding!!.btnClear.visibility = View.VISIBLE
                viewDataBinding!!.tvDesc.visibility = View.GONE
            }

            override fun onClear() { //Event triggered when the pad is cleared

                viewDataBinding!!.tvDesc.visibility = View.VISIBLE
                viewDataBinding!!.btnClear.visibility = View.GONE
            }
        })

        viewDataBinding!!.btnClear.setOnClickListener { viewDataBinding!!.signaturePad.clear() }

        viewDataBinding!!.btnAddSignature.enableWhen {
            viewDataBinding!!.signaturePad.isPadDirty()
        }


        viewDataBinding!!.btnAddSignature.setOnClickListener {
            run {

                viewModel.uploadSignatureRequest(
                    viewDataBinding!!.signaturePad!!.transparentSignatureBitmap!!,
                    object : HandleResponse<BaseResponse> {
                        override fun handleErrorResponse(error: ErrorResponse?) {
                            AppLogger.d("handleErrorResponse  ${error}")

                        }

                        override fun handleSuccessResponse(successResponse: BaseResponse) {
                            showDashboard()
                        }

                    })

            }
        }
    }


    fun showDashboard() {
        val dialog = Dialog(requireContext(), R.style.PauseDialog)
        val binding = DialogCongratulationBinding.inflate(LayoutInflater.from(requireContext()))
        dialog.setContentView(binding.root)
        dialog.setCanceledOnTouchOutside(true)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        binding.btnGoToDashbaord.setOnClickListener {

            startActivity(Intent(requireContext(), HomeActivity.javaClass))
            dialog.dismiss()
        }

        dialog.show()
    }

}
