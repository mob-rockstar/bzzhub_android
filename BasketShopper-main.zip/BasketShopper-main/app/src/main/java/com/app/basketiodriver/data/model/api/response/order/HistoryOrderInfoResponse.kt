package com.app.basketiodriver.data.model.api.response.order
import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName

class HistoryOrderInfoResponse {

    @SerializedName("response")
    @Expose
    val response: Response? = null

    inner class Response{
        @SerializedName("httpCode")
        @Expose
        val httpCode: Int? = null

        @SerializedName("Message")
        @Expose
        val message: String? = null

        @SerializedName("order_outlet_detail")
        @Expose
        val orderOutletDetail: OrderInfo? = null

        @SerializedName("shopper_order")
        @Expose
        val shopperOrder: List<Product> = arrayListOf()
    }
}