package com.app.basketiodriver.data.local.prefs

import com.app.basketiodriver.data.DataManager.LoggedInMode
import com.app.basketiodriver.data.model.api.User

/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
interface PreferencesHelper {
    var accessToken: String?
    var currentUserLanguage: String
    var deviceId: String?
    var deviceToken: String?
    fun getCurrentUserLoggedInMode(): Int
    fun setCurrentUserLoggedInMode(mode: LoggedInMode)
    var currentUser: User?
}