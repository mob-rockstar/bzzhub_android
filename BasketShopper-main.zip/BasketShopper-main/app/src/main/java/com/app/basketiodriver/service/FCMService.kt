package com.app.basketiodriver.service

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationCompat.*
import androidx.core.content.ContextCompat
import com.app.basketiodriver.R
import com.app.basketiodriver.ShopperApp
import com.app.basketiodriver.utils.AppConstants
import com.app.basketiodriver.utils.AppLogger
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.ui.chat.ChatActivity
import com.app.basketiodriver.ui.home.HomeActivity
import com.app.basketiodriver.ui.notifications.NotificationsActivity
import com.app.basketiodriver.utils.MessageEvent

import com.app.basketiodriver.utils.NotificationUtils
import org.greenrobot.eventbus.EventBus
import org.json.JSONObject
import timber.log.Timber
import zendesk.chat.PushData
import java.io.IOException
import java.net.URL
import kotlin.math.log

//Firebase Messaging Service class
class FCMService : FirebaseMessagingService() {

    var notificationType : String = ""
    var orderId : Long = 0
    var paymentMethodName = ""

    // Called whenever receive the notification
    @SuppressLint("UnspecifiedImmutableFlag")
    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)

        Timber.tag(TAG).e("onMessageReceived()")

        if (remoteMessage.data.isNotEmpty()) {
            Timber.tag(TAG).e("Notification data is not null")

            try {
                if (remoteMessage.data[KEY_PAYLOAD] != null) {
                    Timber.tag(TAG).e(remoteMessage.data.toString())
                     Log.d(TAG, "NotificationsActivity: 1")


                        var intent = Intent(this, NotificationsActivity::class.java)
                        val payloadJson = JSONObject(remoteMessage.data[KEY_PAYLOAD]!!)

                        var image: String? = null

                        val title   = remoteMessage.data[KEY_TITLE] ?: ""
                        val message = remoteMessage.data[KEY_BODY] ?: ""
                        val badge   = remoteMessage.data[KEY_BADGE] ?: "0"

                        if (payloadJson.has(KEY_TYPE)){
                            val type = payloadJson.getString(KEY_TYPE)
                            Timber.tag(TAG).e("Notification Type : " + type)


                            // Save the notification type
                            notificationType = type

                            Log.d(TAG, "onMessageReceived: "+notificationType)
                            // Get order id
                            if (payloadJson.has(KEY_ORDER_OUTLET_ID))
                                orderId = payloadJson.getLong(KEY_ORDER_OUTLET_ID)

                            // check if there is image in content
                            if (remoteMessage.data[KEY_IMAGE] != null){
                                image = remoteMessage.data[KEY_IMAGE]
                            }

                            // check if message_type is image
                            if (payloadJson.has(KEY_MESSAGE_TYPE)){
                                val msgType = payloadJson.getString(KEY_MESSAGE_TYPE)

                                if (msgType.equals(KEY_IMAGE, true)){
                                    if (payloadJson.has(KEY_MESSAGE_CONTENT)){
                                        image = payloadJson.getString(KEY_MESSAGE_CONTENT)
                                    }
                                }
                            }

                            // Check if payment method name exist
                            if (payloadJson.has(KEY_PAYMENT_METHOD_NAME)) {
                                paymentMethodName = payloadJson.getString(KEY_PAYMENT_METHOD_NAME)
                            }

                            when (type) {
                // ******   Notification from the Admin Panel   ******* //
                                NOTIFICATION_TYPE_ADMIN -> {
                                    // Go to notification list
                                    Log.d(TAG, "NotificationsActivity:2")
                                    intent = Intent(this, NotificationsActivity::class.java)
                                }

                // ******   Order Updates, Assign Order, Canceled Order, Shopper Booking, Payment Changed   ****** //
                                NOTIFICATION_TYPE_ORDER_UPDATES,
                                NOTIFICATION_TYPE_ASSIGN_ORDER,
                                NOTIFICATION_TYPE_CANCELLED_ORDER,
                                NOTIFICATION_TYPE_PAYMENT_METHOD_CHANGED,
                                NOTIFICATION_TYPE_SHOPPER_BOOKING -> {
                                    // Go to dashboard
                                    intent = Intent(this, HomeActivity::class.java)
                                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                                }

                // ******   Application Status   ****** //
                                NOTIFICATION_TYPE_APPLICATION_STATUS -> {
                                    val appStatus = payloadJson.getInt(KEY_APP_STATUS) ?: 1 // 3 : reject, 1 : review
                                    Log.d(TAG, "NotificationsActivity:3")
                                    // Go to Review progress page
                                    intent = Intent(this, NotificationsActivity::class.java)
                                }

                // ******   New Message   ****** //
                                NOTIFICATION_TYPE_NEW_MESSAGE -> {
                                    val orderOutletId = payloadJson.getString(KEY_ORDER_ID)
                                    val mType = payloadJson.getString(KEY_MESSAGE_TYPE)
                                    val userId = payloadJson.getJSONObject("by").getString("user_id")
                                    val userName = payloadJson.getJSONObject("by").getString("user_name")
                                    val userImage = payloadJson.getJSONObject("by").getString("user_photo")

                                    // Go to Chat Activity
                                    intent = Intent(this, ChatActivity::class.java)
                                    intent.putExtra("KEY_ORDER_OUTLET_ID", orderOutletId.toLongOrNull() ?: 0L)
                                    intent.putExtra("KEY_USER_ID", userId)
                                    intent.putExtra("KEY_USER_NAME", userName)
                                    intent.putExtra("KEY_USER_IMAGE", userImage)
                                }
                            }
                        }

                        // Create the pending intent
                        val contentIntent: PendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

                        // Check if there is image
                        if (image != null && image.isNotEmpty()) {
                            try {
                                val url = URL(image)
                                val bitmapIcon = BitmapFactory.decodeStream(url.openConnection().getInputStream())
                                Log.d(TAG, "showNotificationWithIcon1")
                                // Show the notification
                                showNotificationWithIcon(title, message, badge, contentIntent, bitmapIcon)
                            }
                            catch (e: IOException) {
                                val bitmapIcon = BitmapFactory.decodeResource(resources, R.drawable.ic_profile_green)
                                Log.d(TAG, "showNotificationWithIcon2")
                                // Show the notification
                                showNotificationWithIcon(title, message, badge, contentIntent, bitmapIcon)
                                println(e)
                            }
                        }
                        else{
                            Log.d(TAG, "showNotificationWithIcon3")
                            // Show the notification without image
                            showNotificationWithIcon(title, message, badge, contentIntent, null)
                        }
                }
                else{
                    if (ShopperApp.Instance.pushProvider != null){ // Zendesk push data
                        val pushData = ShopperApp.Instance.pushProvider!!.processPushNotification(remoteMessage.data)

                        when (pushData?.type) {
                            PushData.Type.MESSAGE -> {
                                val author = pushData.author
                                val contents = pushData.message

                                val intent = Intent(this, HomeActivity::class.java)
                                intent.putExtra("NotificationType", NOTIFICATION_TYPE_ZENDESK)
                                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                                val contentIntent: PendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)
                                Log.d(TAG, "showNotificationWithIcon4")
                                // Show the notification without image
                                showNotificationWithIcon(author, contents, "0", contentIntent, null)
                            }
                            PushData.Type.END -> {
                                // End message
                                AppLogger.e(TAG, "Received End message from zendesk")

                                val author = pushData.author
                                val contents = pushData.message

                                val intent = Intent(this, HomeActivity::class.java)
                                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                                val contentIntent: PendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)
                                Log.d(TAG, "showNotificationWithIcon5")
                                // Show the notification without image
                                showNotificationWithIcon(author, contents, "0", contentIntent, null)
                            }
                            else -> {
                                // Unknown
                                AppLogger.e("Received Unknown message from zendesk")
                            }
                        }
                    }
                }
            }
            catch (e: Exception) {
                Timber.tag(TAG).d(e)
                e.printStackTrace()
            }
        }
        else{
            AppLogger.e("Notification data is null...")
        }
    }

    // New token generated from the Firebase
    override fun onNewToken(newToken: String) {
        super.onNewToken(newToken)
        PreferenceManager.fcmToken = newToken
        AppLogger.d("<===== FCM Token : " + newToken)
    }

    private fun showNotificationWithIcon(title: String?, content: String?, badge : String, pendingIntent: PendingIntent?, bitmap: Bitmap?){
        val builder = Builder(this, BASKET_CHANNEL_NAME).setSmallIcon(R.drawable.ic_notifications)
            .setColor(ContextCompat.getColor(applicationContext, R.color.colorPrimary))
            .setContentTitle(title)
            .setContentText(content)
            .setPriority(PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setDefaults(DEFAULT_SOUND or DEFAULT_LIGHTS or DEFAULT_VIBRATE)
            .setAutoCancel(true)
            .setNumber(badge.toIntOrNull() ?: 0)

        if (bitmap != null){
            builder.setLargeIcon(bitmap)
        }

        try{
            NotificationUtils.displayNotification(this, builder)
            Log.d(TAG, "notificationType===>: "+notificationType.toString());
            // Check if notification type is Assign_Order
            if (notificationType.isNotEmpty()){
                if (notificationType == NOTIFICATION_TYPE_ASSIGN_ORDER ){ // Assigned order
                    Timber.tag(TAG).d("Starting buzzer sound...")
                    // Sound the custom sound
                    ShopperApp.Instance.startNotificationSound(this)
                }else if (notificationType == NOTIFICATION_TYPE_CANCELLED_ORDER){ // Cancelled order
                    Timber.tag(TAG).d("Received order cancel notification...")
                    if (orderId != 0L)
                        ShopperApp.Instance.notifyOrderCancel(orderId)
                    else
                        Timber.tag(TAG).d("No order id in notification data")
                }
                else if (notificationType == NOTIFICATION_TYPE_PAYMENT_METHOD_CHANGED) { // Payment Changed
                    Timber.tag(TAG).d("Received payment changed notification...")
//                    ShopperApp.Instance.notifyPaymentMethodChanged(paymentMethodName, orderId)
                }
            }
        }
        catch (e : Exception){
            Log.d(TAG, "showNotificationWithIcon: "+e.message.toString())
            e.printStackTrace()
        }
    }


    companion object {
        const val BASKET_CHANNEL_NAME = "Basket Shopper Notification Channel"
        const val BASKET_NOTIFICATION_NAME = "Basket"

        const val BASKET_LOCAL_CHANNEL_NAME = "Basket Local Notification Channel"
        const val BASKET_LOCAL_NOTIFICATION_NAME = "Basket Local"

        const val KEY_PAYLOAD           = "payload"
        const val KEY_BODY              = "body"
        const val KEY_TITLE             = "title"
        const val KEY_BADGE             = "badge"
        const val KEY_IMAGE             = "image"
        const val KEY_MESSAGE_TYPE      = "message_type"
        const val KEY_MESSAGE_CONTENT   = "message_content"
        const val KEY_TYPE              = "type"
        const val KEY_APP_STATUS        = "application_status"
        const val KEY_ORDER_ID          = "order_id"
        const val KEY_ORDER_OUTLET_ID   = "orders_outlets_id"
        const val KEY_PAYMENT_METHOD_NAME = "payment_method_name"

        const val NOTIFICATION_TYPE_ORDER_UPDATES       = "order_updates"
        const val NOTIFICATION_TYPE_ASSIGN_ORDER        = "assign_order"
        const val NOTIFICATION_TYPE_SHOPPER_BOOKING     = "shopper_booking"
        const val NOTIFICATION_TYPE_ADMIN               = "admin"
        const val NOTIFICATION_TYPE_APPLICATION_STATUS  = "application_status"
        const val NOTIFICATION_TYPE_NEW_MESSAGE         = "new_message"
        const val NOTIFICATION_TYPE_CANCELLED_ORDER     = "cancel_order"
        const val NOTIFICATION_TYPE_COMPLETE_ORDER     = "complete_order"
        const val NOTIFICATION_TYPE_PAYMENT_METHOD_CHANGED = "update_payment_method"
        const val NOTIFICATION_TYPE_ZENDESK             = "zendesk"

        const val TAG = "FCMService"
    }
}