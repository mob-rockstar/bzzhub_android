package com.app.basketiodriver.ui.manager;

import android.annotation.SuppressLint;
import android.os.SystemClock;
//import android.text.format.DateFormat;
import android.widget.Chronometer;
import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.Locale;

public class ShopTimerManager {
    private final Chronometer chronometer;
    private TimerFinishListener listener;

    public ShopTimerManager(TimerFinishListener listener, Chronometer chronometer) {
        this.chronometer = chronometer;
        this.listener = listener;
    }

    @SuppressLint("SetTextI18n")
    public void init(final long startTime, final long shoppingGoal) {
        chronometer.setFormat(String.format(Locale.ENGLISH, "%s", "00:00"));
        chronometer.setBase(SystemClock.elapsedRealtime() - startTime);
        chronometer.setOnChronometerTickListener(chronometer -> {
            long elapsedMillis = SystemClock.elapsedRealtime() - chronometer.getBase();
            final int H = 1000 * 60 * 60;
            if (elapsedMillis < H) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("mm:ss", Locale.ENGLISH);
                String timeString = dateFormat.format(new Date(elapsedMillis));
                chronometer.setText(timeString);
            }
            if (elapsedMillis > shoppingGoal) {
                listener.onFinished();
            }
        });
        chronometer.start();
    }

    public interface TimerFinishListener {
        void onFinished();
    }
}
