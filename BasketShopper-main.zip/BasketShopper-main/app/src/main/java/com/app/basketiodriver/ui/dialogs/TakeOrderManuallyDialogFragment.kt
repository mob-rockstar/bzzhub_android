package com.app.basketiodriver.ui.dialogs

import android.Manifest
import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.model.api.response.order.HandoverCodeResponse
import com.app.basketiodriver.data.model.api.response.order.SimilarProduct
import com.app.basketiodriver.databinding.FragmentTakeOrderManuallyDialogBinding
import com.app.basketiodriver.ui.base.BaseDialogFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.home.HomeActivity
import com.app.basketiodriver.ui.home.HomeViewModel
import com.app.basketiodriver.utils.AppConstants
import com.app.basketiodriver.utils.MessageEvent
import com.google.zxing.BarcodeFormat
import com.google.zxing.Result
import com.tbruyelle.rxpermissions2.RxPermissions
import me.dm7.barcodescanner.zxing.ZXingScannerView
import org.greenrobot.eventbus.EventBus

class TakeOrderManuallyDialogFragment : BaseDialogFragment<FragmentTakeOrderManuallyDialogBinding, HomeViewModel>(), ZXingScannerView.ResultHandler{
    override val layoutId: Int
        get() = R.layout.fragment_take_order_manually_dialog

    override val viewModel: HomeViewModel
        get() {
            return getViewModel(requireActivity(), HomeViewModel::class.java)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    // Set Full screen
    override fun getTheme(): Int {
        return R.style.MyDialogWhite
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initViews()
    }

    private fun initViews(){
        // Verify handover code
        viewDataBinding!!.btnOkay.setOnClickListener {
            if (viewDataBinding!!.edtAmount.text.toString().isNotEmpty()){
                verifyHandoverCode(viewDataBinding!!.edtAmount.text.toString())
            }
            else{
                viewDataBinding!!.edtAmount.error = getString(R.string.please_enter_valid_handover)
            }
        }

        setScannerProperties()
    }

    private fun setScannerProperties(){
        val formats : MutableList<BarcodeFormat> = arrayListOf()
        formats.add(BarcodeFormat.QR_CODE)

        viewDataBinding!!.qrCodeScanner.setFormats(formats)
        viewDataBinding!!.qrCodeScanner.setAutoFocus(true)
        viewDataBinding!!.qrCodeScanner.setLaserColor(R.color.colorPrimary)
        viewDataBinding!!.qrCodeScanner.setMaskColor(R.color.colorPrimary)
    }

    // Verify the code
    private fun verifyHandoverCode(code : String){
        viewModel.verifyHandoverCode(code, object : HandleResponse<HandoverCodeResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                Toast.makeText(activity, error?.message, Toast.LENGTH_SHORT).show()
            }

            override fun handleSuccessResponse(successResponse: HandoverCodeResponse) {
                if (successResponse.status == 200){

                    EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_VERIFIED_HANDOVER))

                    // Close
                    dismiss()
                }
                else{
                    Toast.makeText(activity, successResponse.message, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    // Check if permission is granted
    @SuppressLint("MissingPermission", "CheckResult")
    private fun grantCameraPermission(){
        val permissions = RxPermissions(this)
        permissions.request(Manifest.permission.CAMERA)
            .subscribe { granted: Boolean ->
                if (granted) {
                    viewDataBinding!!.qrCodeScanner.startCamera()
                    viewDataBinding!!.qrCodeScanner.setResultHandler(this)
                }
            }
    }

    /**
     * ZXingScannerView ResultHandler
     */


    override fun onPause(){
        super.onPause()

        viewDataBinding!!.qrCodeScanner.stopCamera()
    }

    override fun handleResult(result: Result?) {
        if (result != null){
            viewDataBinding!!.edtAmount.setText(result.text)
            viewDataBinding!!.qrCodeScanner.stopCamera()
        }
    }

    override fun onResume() {
        super.onResume()

        grantCameraPermission()
    }

    companion object {
        fun newInstance(
        ): TakeOrderManuallyDialogFragment {
            val fragment = TakeOrderManuallyDialogFragment()

            return fragment
        }
    }
}