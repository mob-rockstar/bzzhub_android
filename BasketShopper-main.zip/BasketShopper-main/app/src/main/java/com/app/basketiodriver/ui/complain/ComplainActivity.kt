package com.app.basketiodriver.ui.complain

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.ActivityComplainBinding
import com.app.basketiodriver.ui.base.BaseActivity
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import javax.inject.Inject


class ComplainActivity : BaseActivity<ActivityComplainBinding?, ComplainViewModel>(), HasAndroidInjector {

    override val layoutId: Int
        get() = R.layout.activity_complain
    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null

    override val viewModel: ComplainViewModel
        get() {
            return getViewModel(ComplainViewModel::class.java)
        }
    private val afterLollipop: ValueCallback<Array<Uri>>? = null
    private val mUploadMessage: ValueCallback<Uri>? = null
    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewDataBinding!!.webview.apply {
            this.settings.loadsImagesAutomatically = true
            this.settings.javaScriptEnabled = true

            viewDataBinding!!.webview.settings.javaScriptEnabled = true
            viewDataBinding!!.webview.settings.allowFileAccess = true

//            viewDataBinding!!.webview.settings.cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK
//            viewDataBinding!!.webview.settings.domStorageEnabled = true

            viewDataBinding!!.webview.scrollBarStyle = View.SCROLLBARS_INSIDE_OVERLAY
            viewDataBinding!!.webview.webViewClient = WebViewClient()
            //load webview Url
            viewDataBinding!!.webview.loadUrl("https://basket-help.freshdesk.com/support/tickets/new")
//            viewDataBinding!!.webview.loadUrl("https://www.google.co.uk/")
            viewDataBinding!!.webview.webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    // Check if callback is null or not
                    if (filePathCallback == null) return false

                    // Create an intent for file selection
                    val intent = Intent(Intent.ACTION_GET_CONTENT)
                    intent.addCategory(Intent.CATEGORY_OPENABLE)
                    intent.type = "*/*" // You can set specific mime types if needed

                    // Start an activity to select a file
                    startActivityForResult(intent, 12)

                    // Save the callback for later use
                    fileUploadCallback = filePathCallback

                    return true
                }
            }

        }

        viewDataBinding!!.webview.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                viewDataBinding!!.progressBar.visibility = View.VISIBLE
                viewDataBinding!!.webview.visibility = View.GONE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                Log.d("TAG", "onPageFinished===>")
                viewDataBinding!!.webview.visibility = View.VISIBLE
                viewDataBinding!!.progressBar.visibility = View.INVISIBLE
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 12) {
            if (resultCode == Activity.RESULT_OK) {
                // Get the selected file's URI
                val result = data?.data
                val resultsArray = if (result != null) arrayOf(result) else null

                // Call the callback with the selected file URI
                fileUploadCallback?.onReceiveValue(resultsArray)

                // Reset the callback
                fileUploadCallback = null
            } else {
                // Handle the case where file selection was canceled
                fileUploadCallback?.onReceiveValue(null)
                fileUploadCallback = null
            }
        }
    }

    companion object {
        fun newIntent(context: Context?): Intent {
            return Intent(context, ComplainActivity::class.java)
        }
    }
}