package com.app.basketiodriver.data.model.api.response.earning.bonus

import com.app.basketiodriver.data.model.api.response.earning.payout.ShopperPayoutCreditData
import com.google.gson.annotations.SerializedName

class ShopperBonusDeductionsResponse {
    @SerializedName("data")
    val data: ShopperBonusDeductionsData? = null

    @SerializedName("message")
    val message: String = ""
}