package com.app.basketiodriver.ui.notifications

import android.app.Application
import com.app.basketiodriver.data.DataManager
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.hours.BookingReportResponse
import com.app.basketiodriver.data.model.api.response.notification.NotificationResponse
import com.app.basketiodriver.data.remote.APIManager
import com.app.basketiodriver.mvvm.ui.login.LoginNavigator
import com.app.basketiodriver.ui.base.BaseNavigator
import com.app.basketiodriver.ui.base.BaseViewModel
import com.app.basketiodriver.ui.base.HandleResponse
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class NotificationsViewModel constructor(application: Application, dataManager: DataManager
) : BaseViewModel<BaseNavigator?>(application, dataManager) {

    /**
     * Method to get notification list
     */
    fun getNotificationList(
        handleResponse: HandleResponse<NotificationResponse>
    ) {
//        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperNotification(PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
//                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }

                    },
                    { x ->
                        run {
//                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }
}