package com.app.basketiodriver.ui.order.product

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.Html
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import app.basket.scanner.BasketScanner
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.checkout.CustomerInfo
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.model.api.response.order.CommonResponse
import com.app.basketiodriver.data.model.api.response.order.ItemResponse
import com.app.basketiodriver.data.model.api.response.order.ReplacementOrdersItemRequest
import com.app.basketiodriver.data.model.api.response.order.SimilarProduct
import com.app.basketiodriver.data.remote.socket.ChatMessageHelper
import com.app.basketiodriver.data.remote.socket.SystemMessage
import com.app.basketiodriver.data.remote.socket.SystemMessageReq
import com.app.basketiodriver.databinding.ActivityBasketSuggestionListBinding
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.app.basketiodriver.ui.dashbaord.OrdersManager
import com.app.basketiodriver.ui.dialogs.AmountDialogFragment
import com.app.basketiodriver.ui.dialogs.IncorrectItemDialogFragment
import com.app.basketiodriver.ui.dialogs.RefundDialogFragment
import com.app.basketiodriver.ui.dialogs.ReplaceQuantityDialogFragment
import com.app.basketiodriver.ui.order.adapter.SuggestionProductListAdapter
import com.app.basketiodriver.ui.order.product.ItemDetails.Companion.SCAN_ACTIVITY
import com.app.basketiodriver.utils.AppConstants
import com.app.basketiodriver.utils.AppConstants.FROM_REVIEW_CHANGE
import com.app.basketiodriver.utils.GlideApp
import com.app.basketiodriver.utils.price.PriceConstructor
import com.app.basketiodriver.utils.price.PriceConstructorNew
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import javax.inject.Inject

class BasketSuggestionListActivity : BaseActivity<ActivityBasketSuggestionListBinding, OrderDetailsViewModel>(),
    HasAndroidInjector, SuggestionProductListAdapter.SuggestionProductClickListener, AmountDialogFragment.AmountDialogOnClickListener{

    override val layoutId: Int
        get() = R.layout.activity_basket_suggestion_list

    override val viewModel: OrderDetailsViewModel
        get() {
            return getViewModel(OrderDetailsViewModel::class.java)
        }

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>
    override fun androidInjector() = dispatchingAndroidInjector

    // Properties
    var isScanToReplace = false
    var isEnterOwnReplacement = false

    var itemsList : ArrayList<SimilarProduct> = arrayListOf()

    var orderId : Long = 0
    var oldItemId : Long = 0
    var searchId : Long = 0
    var originalItemQty : Double = 0.0

    var ordersItem : OrdersItem? = null
    var info : CustomerInfo? = null

    var actionFrom = 1

    // Adapter
    lateinit var listAdapter : SuggestionProductListAdapter

    // Refund dialog
    var refundDialogFragment : RefundDialogFragment? = null

    var item : SimilarProduct? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Init toolbar
        initToolBar()

        viewDataBinding!!.rvReplaceItem.layoutManager = LinearLayoutManager(this)
        viewDataBinding!!.rvReplaceItem.setHasFixedSize(true)

        if (intent.extras != null){
            ordersItem  = intent.extras!!.getSerializable(ARG_ORDER_ITEM) as? OrdersItem
            info        = intent.extras!!.getSerializable(ARG_INFO) as? CustomerInfo
            actionFrom  = intent.getIntExtra(ACTION_FROM, 1)

            orderId     = intent.extras!!.getLong(ARG_ORDER_ID)
            oldItemId   = intent.extras!!.getLong(ARG_ITEM_ID)
            searchId    = intent.extras!!.getLong(ARG_SEARCH_ID)
            originalItemQty = intent.extras!!.getDouble(ARG_ORIGINAL_ITEM_QTY)

            itemsList   = intent.extras!!.getSerializable(ARG_ITEMS_ARRAY) as ArrayList<SimilarProduct>

            setAdapter()

            setItem()

            if (actionFrom == FROM_REVIEW_CHANGE && (ordersItem!!.customerSuggestionType == 3 || ordersItem!!.customerSuggestionType == 2)){
                setReplacementView(1)
            }
            else {
                setReplacementView(ordersItem!!.customerSuggestionType)
            }

            setCustomerReplaceItemData()

            // Own Replacement
            viewDataBinding!!.txtOwnReplacement.setOnClickListener {
                if (!isEnterOwnReplacement) {
                    isEnterOwnReplacement = true

                    // Go to SearchSimilarProduct activity
                    val intent = Intent(this, SearchForSimilarActivity::class.java)
                    intent.putExtra("ARG_ORDER_ID", orderId)
                    intent.putExtra("ARG_ITEM_ID", oldItemId)
                    intent.putExtra("ARG_SEARCH_ID", searchId)
                    intent.putExtra("ARG_ORIGINAL_ITEM_QTY", originalItemQty)
                    intent.putExtra("ARG_ORDER_ITEM", ordersItem)
                    intent.putExtra("ARG_INFO", info)
                    intent.putExtra("ACTION_FROM", actionFrom)
                    intent.putExtra("ARG_IS_REPLACEMENT", 1)
                    startActivityForResult(intent, BASKET_SUGGESTION_LIST_REQ)
                }
            }

            // Refund
            viewDataBinding!!.txtRefund.setOnClickListener {
                try{
                    refundDialogFragment = RefundDialogFragment.newInstance(ordersItem!!, orderId, actionFrom)
                    refundDialogFragment!!.show(supportFragmentManager, RefundDialogFragment.javaClass.name)
                }
                catch (e : Exception){
                    e.printStackTrace()
                }
            }
        }
    }

    private fun initToolBar(){
        initToolbar(getString(R.string.replacement),
            true, viewDataBinding!!.layoutToolBar.toolbar,
            View.OnClickListener {
                run {
                    finish()
                }
            })
    }

    private fun setAdapter(){
        listAdapter = SuggestionProductListAdapter(this, itemsList, this)
        viewDataBinding!!.rvReplaceItem.adapter = listAdapter
    }

    private fun setCustomerReplaceItemData(){
        if (ordersItem!!.replacementRequested != null && ordersItem!!.replacementRequested == 1 && ordersItem!!.customerSuggestionType == 2) {
            viewDataBinding!!.txtTitleSuggestion.visibility = View.VISIBLE
            viewDataBinding!!.rvReplaceItem.visibility = View.VISIBLE

            viewDataBinding!!.txtYourRep.visibility = View.VISIBLE
            viewDataBinding!!.txtYourRep.setText(R.string.item_details)

            viewDataBinding!!.oldItemView.visibility = View.VISIBLE
            viewDataBinding!!.txtCusTitle.setText(R.string.suggested_replacement_by_you)
            viewDataBinding!!.txtTitleSuggestion.setText(R.string.customer_replacement_suggestion)

            viewDataBinding!!.txtOwnReplacement.visibility = View.GONE

            // product image
            if (ordersItem!!.oldProductImage != null){
                GlideApp.with(this).load(ordersItem!!.oldProductImage).fitCenter()
                    .placeholder(R.drawable.placeholder)
                    .error(R.drawable.placeholder).into(viewDataBinding!!.oldItemProduct.orderItemImage)
            }

            // product name
            viewDataBinding!!.oldItemProduct.txtTitle.text = ordersItem!!.oldProductName

            // description
            if (ordersItem!!.getDescriptionLabelOld().isEmpty()){
                viewDataBinding!!.oldItemProduct.tvPriceDescription.visibility = View.GONE
            }
            else{
                viewDataBinding!!.oldItemProduct.tvPriceDescription.text = ordersItem!!.getDescriptionLabelOld()
                viewDataBinding!!.oldItemProduct.tvPriceDescription.visibility = View.VISIBLE
            }

            // cost
            viewDataBinding!!.oldItemProduct.txtPricePerUnit.text = Html.fromHtml(PriceConstructor.getFormatPrice(ordersItem!!, PriceConstructor.LabelType.SIMPLE, PreferenceManager.currency, false))

        }
    }

    private fun setItem(){
        if (ordersItem != null) {

            // product image
            if (ordersItem!!.productImage != null){
                GlideApp.with(this).load(ordersItem!!.productImage).fitCenter()
                    .placeholder(R.drawable.placeholder)
                    .error(R.drawable.placeholder).into(viewDataBinding!!.newItemProduct.orderItemImage)
            }

            // product name
            viewDataBinding!!.newItemProduct.txtTitle.text = ordersItem!!.productName

            // description
            if (ordersItem!!.getDescriptionLabel().isEmpty()){
                viewDataBinding!!.newItemProduct.tvPriceDescription.visibility = View.GONE
            }
            else{
                viewDataBinding!!.newItemProduct.tvPriceDescription.text = ordersItem!!.getDescriptionLabelNew()
                viewDataBinding!!.newItemProduct.tvPriceDescription.visibility = View.VISIBLE
            }

            // cost
            viewDataBinding!!.newItemProduct.txtPricePerUnit.text = Html.fromHtml(PriceConstructorNew.getFormatPrice(ordersItem!!, PriceConstructor.LabelType.SIMPLE, true))
        }
    }

    private fun setReplacementView(suggestion : Int){
        when (suggestion){
            1-> setViewForBestMatch()
            2-> setViewForSpecific()
            3-> setViewForRefund()
        }
    }

    private fun setViewForBestMatch(){
        if (ordersItem!!.item_type != null && ordersItem!!.item_type != 2){
            viewDataBinding!!.txtOwnReplacement.visibility = View.VISIBLE
        }
        else{
            viewDataBinding!!.txtOwnReplacement.visibility = View.GONE
        }

        viewDataBinding!!.txtTitleSuggestion.visibility = View.GONE
        viewDataBinding!!.rvReplaceItem.visibility = View.GONE

        if (ordersItem!!.upcType != null && ordersItem!!.upcType == 2){
            viewDataBinding!!.txtRefund.visibility = View.VISIBLE
        }
        else{
            viewDataBinding!!.txtRefund.visibility = View.VISIBLE
        }

        if (actionFrom == FROM_REVIEW_CHANGE) {
            viewDataBinding!!.txtRefund.visibility = View.VISIBLE
        }

    }

    private fun setViewForSpecific(){
        viewDataBinding!!.txtOwnReplacement.visibility = View.GONE
        viewDataBinding!!.txtTitleSuggestion.visibility = View.VISIBLE
        viewDataBinding!!.rvReplaceItem.visibility = View.VISIBLE
        viewDataBinding!!.txtRefund.visibility = View.VISIBLE
    }

    private fun setViewForRefund(){
        viewDataBinding!!.txtOwnReplacement.visibility = View.GONE
        viewDataBinding!!.txtTitleSuggestion.visibility = View.GONE
        viewDataBinding!!.rvReplaceItem.visibility = View.GONE
        viewDataBinding!!.txtRefund.visibility = View.VISIBLE
//        viewDataBinding!!.txtAroundPrice.visibility = View.GONE
        viewDataBinding!!.txtCusTitle.setText(R.string.customer_wants_refund)
        viewDataBinding!!.txtRefund.performClick()
    }

    fun finishWithRefund(){
        setResult(8)
        finish()
    }

    /**
     * Suggestion Product ClickListener
     */
    override fun onProductClicked(_item: SimilarProduct) {
        if (!isScanToReplace){
            isScanToReplace = true
            if (_item.upcType == 2){
                // replace item
                replaceItem(orderId, _item, 2)
            }
            else{
                // Go to ScanAsReplaceActivity
//                val intent = Intent(this, ScanAsReplaceItemActivity::class.java)
//                intent.putExtra("ARG_ITEM_DETAIL", item)
//                intent.putExtra("ARG_ORDER_OUTLET_ID", orderId)
//                intent.putExtra("ARG_ITEM_ID", oldItemId)
//                intent.putExtra("ARG_AUTO_FOCUS", true)
//                intent.putExtra("ARG_INFO", info)
//                intent.putExtra("ARG_ORDER_ITEM", ordersItem)
//                intent.putExtra("ARG_ACTION_FROM", 2)
//                intent.putExtra("ARG_IS_REPLACEMENT", 1)
//                startActivityForResult(intent, SCAN_ACTIVITY)
                 // redirect to new scanning SDK
                item=_item
                startScanner()

            }
        }
    }
    private fun startScanner() {
        BasketScanner.scan(onSuccess = {
            checkBarcode(it)
        }, onCanceled = {}, onEmptyResult = {}, onFailure = {
            Toast.makeText(this@BasketSuggestionListActivity, it.message + "", Toast.LENGTH_LONG).show()
        })
    }
    private fun checkBarcode(barcode : String){
//        viewDataBinding!!.txtLoadingView.visibility = View.VISIBLE

        val orderItemId : Long = ordersItem!!.ordersOutletsItemsId ?: 0
        val replaceItemId : Long = (item!!.outletItemId ?: 0).toLong()
        viewModel.checkBarcode(orderItemId, barcode, 1, replaceItemId, object  :
            HandleResponse<CommonResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                 Toast.makeText(this@BasketSuggestionListActivity, error?.message, Toast.LENGTH_SHORT).show()
            }

            override fun handleSuccessResponse(successResponse: CommonResponse) {
                 val response = successResponse.data

                if (successResponse != null) {
                    Toast.makeText(this@BasketSuggestionListActivity, successResponse.message, Toast.LENGTH_SHORT).show()

                    if (successResponse.status == 200){
                        if (item!!.soldPer != 3 && item!!.soldPer != 2){
                            replaceItem()
                        }
                        else{
                            showAmountDialog()
                        }
                    }
                    else {
                        showProduct(barcode)
                    }
                }
                else{
                    Toast.makeText(this@BasketSuggestionListActivity, R.string.error_check_barcode, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }
    private fun showProduct(barcode : String){
        viewModel.getProductByBarcode(orderId, barcode, object : HandleResponse<ItemResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                Toast.makeText(this@BasketSuggestionListActivity, error?.message, Toast.LENGTH_SHORT).show()
            }

            override fun handleSuccessResponse(successResponse: ItemResponse) {
                if (successResponse.response != null){
                    if (successResponse.response.httpCode == 200 && successResponse.response.itemDetails != null){
                        // Show the IncorrectItemDialogFragment
                        try{
                            val incorrectFragment = IncorrectItemDialogFragment.newInstance(successResponse.response.itemDetails, item!!)
                            incorrectFragment.show(supportFragmentManager, IncorrectItemDialogFragment.javaClass.name)
                        }
                        catch (e : Exception){
                            e.printStackTrace()
                        }
                    }
                    else{
                        Toast.makeText(this@BasketSuggestionListActivity, successResponse.response.message, Toast.LENGTH_SHORT).show()
                    }
                }
                else{
                    Toast.makeText(this@BasketSuggestionListActivity, R.string.error_server_return_null, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }
    private fun showAmountDialog(){
        try{
            val amountDialog = AmountDialogFragment.newInstance(item!!, 1.0)
            amountDialog.show(supportFragmentManager, AmountDialogFragment.javaClass.name)
            amountDialog.setAmountNextClickListener(this)
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    private fun replaceItem(){
        if (ordersItem!!.soldPer == 2){
            replaceQuantityDialog(ordersItem!!, item!!, ordersItem!!.itemQty ?: 0.0)
        }
        else if (ordersItem!!.soldPer == 3){
            replaceQuantityDialog(ordersItem!!, item!!, ordersItem!!.approxWeight)
        }
        else if (ordersItem!!.itemQty != null && ordersItem!!.itemQty!! >= 1){
            replaceQuantityDialog(ordersItem!!, item!!, ordersItem!!.itemQty!!)
        }
        else{
            foundResult(1.0)
        }
    }
    private fun replaceItem(orderId: Long, item : SimilarProduct, actionFrom : Int){
        viewModel.shopperReplaceItem(1.0, oldItemId, (item.outletItemId ?: 0).toLong(), orderId, actionFrom, object : HandleResponse<CommonResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                Toast.makeText(this@BasketSuggestionListActivity, error?.message, Toast.LENGTH_SHORT).show()
            }

            override fun handleSuccessResponse(successResponse: CommonResponse) {
                if (successResponse.status == 200){
                    var message = ""
                    message = if (ordersItem!!.replacementRequested != null && ordersItem!!.replacementRequested == 1){
                        AppConstants.MESSAGE_TYPE_REPLACED + " " + PreferenceManager.currentShopperFirstName + " " + getString(R.string.replaced) + "," + getString(R.string.item) + " " + ordersItem!!.oldProductName + ", " + getString(R.string.with_1) + ", " + getString(R.string.item) + " " + item.productName+"."
                    } else{
                        AppConstants.MESSAGE_TYPE_REPLACED + " " + PreferenceManager.currentShopperFirstName + " " + getString(R.string.replaced) + "," + getString(R.string.item) + " " + ordersItem!!.productName + ", " + getString(R.string.with_1) + ", " + getString(R.string.item) + " " + item.productName+"."
                    }

                    ////////////////////
                    // ChatMessageHelper
                    // Send message
                    val systemMessageReq = SystemMessageReq(orderId.toString(), "text", message!!)
                    sendSysteMessage(systemMessageReq, item, successResponse.message)
                }
                else{
                    Toast.makeText(this@BasketSuggestionListActivity, successResponse.message, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    fun sendSysteMessage(systemMessageReq: SystemMessageReq, item : SimilarProduct, message: String){
        viewModel.sendSystemMessage(systemMessageReq, object : HandleResponse<SystemMessage> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                initRedirection(item, message)
            }

            override fun handleSuccessResponse(successResponse: SystemMessage) {
                initRedirection(item, message)
            }
        })
    }

    private fun initRedirection(item : SimilarProduct, message:String){

        if (ordersItem!!.soldPer == 2){
            replaceQuantityDialog(ordersItem!!, item, ordersItem!!.itemQty ?: 0.0, actionFrom)
        }
        else if (ordersItem!!.soldPer == 3){
            replaceQuantityDialog(ordersItem!!, item, ordersItem!!.approxWeight, actionFrom)
        }
        else if (ordersItem!!.itemQty != null && ordersItem!!.itemQty!! > 1){
            replaceQuantityDialog(ordersItem!!, item, ordersItem!!.itemQty!!, actionFrom)
        }
        else{
            Toast.makeText(this@BasketSuggestionListActivity, message, Toast.LENGTH_SHORT).show()
            setResult(Activity.RESULT_OK)
            finish()
        }
    }
    private fun replaceQuantityDialog(ordersItem: OrdersItem, similarProduct: SimilarProduct, quantity : Double){
        // Show the ReplaceQuantityDialog
        try{
            val orgOrderId = if (ordersItem.replacementRequested != null && ordersItem.replacementRequested == 1) (ordersItem.oldOutletItemId ?: "0").toInt() else ordersItem.outletItemId ?: 0
            val replaceQtyDialogFragment = ReplaceQuantityDialogFragment.newInstance(orderId, ordersItem, similarProduct, quantity, orgOrderId, actionFrom)
            replaceQtyDialogFragment.show(supportFragmentManager, ReplaceQuantityDialogFragment.javaClass.name)
            replaceQtyDialogFragment.clickListener = this
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    private fun replaceQuantityDialog(ordersItem: OrdersItem, similarProduct: SimilarProduct, quantity : Double, action : Int){
        // Show the ReplaceQuantityDialog
        try{
            val orgOrderId = if (ordersItem.replacementRequested != null && ordersItem.replacementRequested == 1) (ordersItem.oldOutletItemId ?: "0").toInt() else ordersItem.outletItemId ?: 0
            val replaceQtyDialogFragment = ReplaceQuantityDialogFragment.newInstance(orderId, ordersItem, similarProduct, quantity, orgOrderId, action)
            replaceQtyDialogFragment.show(supportFragmentManager, ReplaceQuantityDialogFragment.javaClass.name)
            replaceQtyDialogFragment.clickListener = this
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    override fun onResume() {
        super.onResume()

        isScanToReplace = false
        isEnterOwnReplacement = false
    }

    /**
     * AmountDialog ClickListener
     */
    override fun onNextClick(requestItems : ArrayList<ReplacementOrdersItemRequest>){
        setResult(Activity.RESULT_OK)
        finish()
    }

    override fun onNextClick(amount: Double) {
        setResult(Activity.RESULT_OK)
        finish()
    }

    override fun onNextClick(itemId: Long, amount: Double) {
        setResult(Activity.RESULT_OK)
        finish()
    }

    override fun onNextClick(amount: Double, weight: Double) {
        setResult(Activity.RESULT_OK)
        finish()
    }

    override fun onNextClick(itemId: Long, amount: Double, weight: Double) {
        setResult(Activity.RESULT_OK)
        finish()
    }
    private fun foundResult(amount: Double){
        val intent = Intent()
        intent.putExtra(ScanItem.ITEM_AMOUNT, amount)
        setResult(Activity.RESULT_OK, intent)
        finish()
    }

    /**
     * ActivityResult
     */
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {

        if (requestCode == SCAN_ACTIVITY){
            if (resultCode == RESULT_OK) {
                setResult(RESULT_OK)
                finish()
            }
        }

        if (requestCode == BASKET_SUGGESTION_LIST_REQ) {
            isEnterOwnReplacement = false

            if (resultCode == RESULT_OK) {
                setResult(RESULT_OK)
                finish()
            }
        }

        super.onActivityResult(requestCode, resultCode, data)
    }

    companion object{
        const val ARG_ITEMS_ARRAY   = "similar_items_list"
        const val ARG_ORDER_ID      = "order_id"
        const val ARG_ITEM_ID       = "item_id"
        const val ARG_SEARCH_ID     = "item_search_id"
        const val ARG_ORIGINAL_ITEM_QTY = "original_qty"

        const val ARG_ORDER_ITEM    = "order_item"

        const val ARG_INFO          = "customer_info"
        const val ACTION_FROM       = "action_from"

        const val BASKET_SUGGESTION_LIST_REQ = 24
    }
}