package com.app.basketiodriver.ui.dashbaord.map

import android.Manifest
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.location.Location
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat
import com.app.basketiodriver.R
import com.app.basketiodriver.ShopperApp
import com.app.basketiodriver.data.SupportMenuManager
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.dashboard.ShopperOrder
import com.app.basketiodriver.data.model.api.response.dashboard.ShopperOrderByIDResponse
import com.app.basketiodriver.data.model.api.response.directions.ServerAnswer
import com.app.basketiodriver.data.model.api.response.general.SimpleResponse
import com.app.basketiodriver.data.remote.socket.SystemMessage
import com.app.basketiodriver.data.remote.socket.SystemMessageReq
import com.app.basketiodriver.databinding.ActivityLocationMapBinding
import com.app.basketiodriver.di.Navigators
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_ARRIVED_TO_CUSTOMER
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_ARRIVED_TO_SHOP
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_ARRIVING_TO_SHOP
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_DELIVERY
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_ORDER_FINISHED
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_SLIDE_START_DELIVERY
import com.app.basketiodriver.ui.dialogs.DialogCustomerInfo
import com.app.basketiodriver.utils.AppConstants
import com.app.basketiodriver.utils.GlideApp
import com.app.basketiodriver.utils.SwipeManyStateButton
import com.google.android.gms.maps.CameraUpdate
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.*
import com.google.maps.android.PolyUtil
import com.tbruyelle.rxpermissions2.RxPermissions
import io.reactivex.android.schedulers.AndroidSchedulers
import java.util.*


class LocationMapActivity : BaseActivity<ActivityLocationMapBinding, LocationMapViewModel>() , SwipeManyStateButton.OnStateChangeListener{
    override val layoutId: Int
        get() = R.layout.activity_location_map

    override val viewModel: LocationMapViewModel
        get() {
            return getViewModel(LocationMapViewModel::class.java)
        }

    private var isMapLoaded = false
    private var map: GoogleMap? = null

    private var focusPosition : LatLng? = null
    private var focusName : String = ""
    private var focusAddress : String = ""
    private var focusImageUrl : String = ""

    private var orderStatus = 0
    private var orderId : Long = 0
    private var orderTotal : Double = 0.0
    private var arrivedAtStoreDistanceConfig = 0.0

    lateinit var shopperOrder : ShopperOrder

//    private lateinit var gpsTracker : GPSTrackService

    private var circle : Circle? = null
    private var shadowOne : Circle? = null
    private var shadowTwo : Circle? = null

    private var storeLocationDialogFragment : StoreLocationDialogFragment?= null

    private lateinit var supportMenuManager : SupportMenuManager

    private var hasData = false

    private var isPermissionGranted : Boolean = false
    private var isMapReady : Boolean = false

    // Check if Express Store
    private var isExpressStore = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize the Toolbar
        initToolbar(getString(R.string.dashboard),
            true, viewDataBinding!!.layoutToolBar.toolbar,
            View.OnClickListener {
                run {
                    onBackPressed()
                }
            })

        // Init the GPS Tracker
//        gpsTracker = GPSTrackService(this)

        // get order id
        orderId = intent.getLongExtra("ARG_ORDER_ID", 0)
        isExpressStore = intent.getIntExtra("ARG_IS_EXPRESS", 0)

        initUI()

        // Request the location permissions
        requestPermissions()

        // Init the GoogleMaps
        initMap()
    }

    override fun onBackPressed() {

        // Stop the location update
//        if (gpsTracker != null)
//            gpsTracker.stopUsingGPS()

        Navigators.goToDashboard(this)
    }

    private fun initUI(){
        // Hide the bottom view
        viewDataBinding!!.lvBottom.visibility = View.GONE

        viewDataBinding!!.ivMyLocation.visibility = View.GONE
        viewDataBinding!!.ivMyLocation.setOnClickListener {
            // go to my location
            toCurrentLocation()
        }

        viewDataBinding!!.ivGoogleMap.visibility = View.GONE
        viewDataBinding!!.ivGoogleMap.setOnClickListener {
            // Go to GoogleMaps
            gotoGoogleMap()
        }

        initSupportMenu()
    }

    // Init the support toolbar
    private fun initSupportMenu(){
        val support = viewDataBinding!!.layoutToolBar.support
        supportMenuManager = SupportMenuManager(support)
        support.setOnClickListener {
            supportMenuManager.showSupportMenu()
        }
    }

    private fun initMap(){
        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment

        try{
            mapFragment.getMapAsync { googleMap ->
                isMapReady = true

                googleMap.uiSettings.isMapToolbarEnabled = false
                this.map = googleMap

                if (this.map != null && checkPermission()){
                    this.map!!.isMyLocationEnabled = false
                }
                else{
                    this.requestPermissions()
                }

                if (hasData) {
                    setDataToView()
                    setDataToMap()
                }
                else{
                    if (orderId > 0){
                        getOrderDetailFromServer()
                    }
                }
            }
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    // Check if location permission is granted
    private fun checkPermission() : Boolean {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            isPermissionGranted = false
        }

        return isPermissionGranted
    }

    // Start the location service
    private fun startLocationService(){
        try{
            ShopperApp.Instance.startLocationService(this)
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    // Stop the location service
    private fun stopLocationService(){
        try{
            ShopperApp.Instance.stopLocationService(this)
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    private fun showCustomerInfoDialog(){
        DialogCustomerInfo.openDialog(this, shopperOrder.userImage,
            String.format(Locale.ENGLISH, "%s %s", shopperOrder.userFirstName, shopperOrder.userLastName),
            shopperOrder.userLocation,
            shopperOrder.deliverySlot,
            shopperOrder.userAddress,
            shopperOrder.userAddressType,
            shopperOrder.department,
            shopperOrder.info,
            shopperOrder.landmark){
            Log.d("TAG", "gotoArrivedCustomer====>: ")
            gotoArrivedCustomer()
        }
    }

    // Go to Arrived to Customer page
    private fun gotoArrivedCustomer(){
        // Send message
        val message = AppConstants.MESSAGE_TYPE_DELIVERED.toString() + "" + PreferenceManager.currentShopperFirstName + " " + resources.getString(R.string.delivered_order)

        val systemMessageReq = SystemMessageReq(orderId.toString(), "text", message)
        sendSysteMessage(systemMessageReq){
//            if (orderTotal != 0.0){
                if (shopperOrder != null)
                    Navigators.goToArrivedCustomerActivity(this, orderId, STATUS_ARRIVED_TO_CUSTOMER, orderTotal, shopperOrder.isExpress)
                else
                    Navigators.goToArrivedCustomerActivity(this, orderId, STATUS_ARRIVED_TO_CUSTOMER, orderTotal, isExpressStore)
//            }
//            else{
//                Navigators.goToDashboard(this)
//            }
        }
    }

    // Open the google maps
    private fun gotoGoogleMap(){
        if (focusPosition != null){
            try {
                val gmmIntentUri: Uri = Uri.parse("google.navigation:q=" + focusPosition!!.latitude + "," + focusPosition!!.longitude)
                val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
                mapIntent.setPackage("com.google.android.apps.maps")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    startActivity(mapIntent)
                } else {
                    if (mapIntent.resolveActivity(packageManager) != null){
                        startActivity(mapIntent)
                    } else{
                        Toast.makeText(this, "Google map is not installed in your device.", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: ActivityNotFoundException) {
                e.printStackTrace()
            }
        }
    }

    @SuppressLint("MissingPermission", "CheckResult")
    private fun requestPermissions() {
        RxPermissions(this).request(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe { granted ->
                if (granted) {
                    if (map != null)
                        map!!.isMyLocationEnabled = false
                    isPermissionGranted = true
                    viewDataBinding!!.ivMyLocation.visibility = View.VISIBLE

                    try {
                        if (ShopperApp.Instance.mCurrentLocation == null){
                            ShopperApp.Instance.startLocationService(this)
                        }
                    }
                    catch (e : Exception){
                        e.printStackTrace()
                    }
                }
            }
    }

    // Move the camera to current location
    @SuppressLint("CheckResult")
    private fun toCurrentLocation(){
        var currentLatLng : LatLng? = null
        if (ShopperApp.Instance.mCurrentLocation != null) {
            currentLatLng = LatLng(ShopperApp.Instance.mCurrentLocation!!.latitude, ShopperApp.Instance.mCurrentLocation!!.longitude)

            // Add marker
            addMarker(currentLatLng, getString(R.string.your_location))

            // Move the camera to current position
            map!!.moveCamera(CameraUpdateFactory.newLatLng(currentLatLng))
        }
        else{
            // Show the error toast
            Toast.makeText(this, R.string.current_location_is_null, Toast.LENGTH_SHORT).show()
        }
    }

    // Add marker to location
    private fun addMarker(position : LatLng, title:String){
        if (map != null){
            val markerOption = MarkerOptions()
            markerOption.position(position)
            markerOption.icon(BitmapDescriptorFactory.fromBitmap(getBitmapFromDrawable(R.drawable.ic_marker)))
            markerOption.title(title)

            map!!.addMarker(markerOption)
        }
    }

    private fun getBitmapFromDrawable(drawableId : Int) : Bitmap{
        var drawable = ContextCompat.getDrawable(this, drawableId)

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            drawable = DrawableCompat.wrap(drawable!!).mutate()
        }

        val bitmap = Bitmap.createBitmap(
            drawable!!.intrinsicWidth,
            drawable!!.intrinsicHeight, Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(bitmap)
        drawable!!.setBounds(0, 0, canvas.getWidth(), canvas.getHeight())
        drawable!!.draw(canvas)

        return bitmap
    }

    // Get order details from server
    private fun getOrderDetailFromServer(){
        viewModel.getOrderDetailsByID(orderId, object:HandleResponse<ShopperOrderByIDResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Toast.makeText(this@LocationMapActivity, error?.message, Toast.LENGTH_SHORT).show()
                }else{
                    Toast.makeText(this@LocationMapActivity, resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }
                finish()
            }

            override fun handleSuccessResponse(successResponse: ShopperOrderByIDResponse) {
                val response = successResponse.response
                if (response != null){
                    if (response.httpCode == 200){
                        shopperOrder = response.shopperOrder!!
                        processShopperOrder()
                    }
                    else{
                        Toast.makeText(this@LocationMapActivity, response.message, Toast.LENGTH_LONG).show()
                        finish()
                    }
                }
                else{
                    Toast.makeText(this@LocationMapActivity, getString(R.string.error_server_return_null), Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
        })
    }

    // Update the UI
    private fun processShopperOrder(){
        // Mayank
        orderStatus = shopperOrder.orderStatus!!
//        orderStatus = 10
        orderTotal = shopperOrder.overallTotal ?: 0.0
        arrivedAtStoreDistanceConfig = shopperOrder.arrivedAtStoreDistanceConfig ?: 0.0

        if (orderStatus < STATUS_SLIDE_START_DELIVERY) {
            focusPosition = LatLng(shopperOrder.outletLatitude!!, shopperOrder.outletLongitude!!)
            focusAddress  = shopperOrder.outletContactAddress ?: ""
            focusName     = shopperOrder.outletName ?: ""
            focusImageUrl = shopperOrder.logoImage ?: ""

            var chatOption: Boolean
            var numberOption : Boolean
            if (orderStatus <= STATUS_ARRIVED_TO_SHOP) {
                chatOption = false
                numberOption = false
            }
            else{
                chatOption = true
                numberOption = true
            }

            // Check if it's express store
            if (shopperOrder.isExpress == 1){
                chatOption = false
            }

            // init SupportManager
            supportMenuManager.initConsumerNumber(shopperOrder.callBeforeCheckout, true, shopperOrder.userMobile, chatOption, numberOption)
        }
        else{
            focusPosition = LatLng(shopperOrder.userLatitude!!, shopperOrder.userLongitude!!)
            focusAddress  = shopperOrder.userAddress ?: ""
            focusName     = shopperOrder.userFirstName + " " + shopperOrder.userLastName
            focusImageUrl = shopperOrder.userImage ?: ""

            // init SupportManager
            if (shopperOrder.isExpress == 1){
                supportMenuManager.initConsumerNumber(shopperOrder.callBeforeCheckout, true, shopperOrder.userMobile, false, true)
            }
            else{
                supportMenuManager.initConsumerNumber(shopperOrder.callBeforeCheckout, true, shopperOrder.userMobile, true, true)
            }
        }

        hasData = true

        // Set the user data
        setDataToView()

        // Set the data to Map
        setDataToMap()

        // Process the special status
        doIfSpecialState(orderStatus, isFirstLoad = true)

        // Info button
        viewDataBinding!!.layoutToolBar.info.setOnClickListener {
            showCustomerInfoDialog()
        }

    }

    private fun setDataToView(){
        // mayank
        viewDataBinding!!.btnSwipe.state     = orderStatus
        viewDataBinding!!.tvUserName.text    = focusName
        viewDataBinding!!.tvUserAddress.text = focusAddress

        if (focusImageUrl != "") {
            GlideApp.with(applicationContext).load(focusImageUrl).fitCenter()
                .placeholder(R.drawable.ic_avatar)
                .error(R.drawable.ic_avatar).into(viewDataBinding!!.ivUser)
        }

        if (orderStatus == STATUS_ARRIVING_TO_SHOP || (orderStatus >= STATUS_SLIDE_START_DELIVERY && orderStatus < STATUS_ORDER_FINISHED)){
            // hide the scroll
            hideScroll()

            // start the location service
            startLocationService()
        }
        else{
            // draw the polyline on the map
            if (ShopperApp.Instance.mCurrentLocation != null)
                drawPolyline()
        }
    }

    private fun setDataToMap(){
        // Move the camera to current location
        toCurrentLocation()

        // Customer location
        addMarker(focusPosition!!, getString(R.string.customer_location))

        // add circle
        if (ShopperApp.Instance.mCurrentLocation != null)
            addCircleToMap()

        map!!.setOnCameraIdleListener {
            if (circle == null) return@setOnCameraIdleListener
            val radius = Math.pow(2.0, (14 - map!!.cameraPosition.zoom).toDouble()) * Math.pow(5.0, -3.0)
            circle!!.radius = radius * 6000
            shadowTwo!!.radius = radius * 13500
            shadowOne!!.radius = radius * 21000
        }
    }

    // Process the special status
    private fun doIfSpecialState(state : Int, isFirstLoad : Boolean = false){

        if (state == STATUS_ARRIVED_TO_SHOP) {
            // Go to order details
            Navigators.goToLockOrderDetails(this, orderId, state)
            finish()
            return
        }

        if (state == STATUS_DELIVERY){
            Log.e("LocationMap", "Starting updating shopper location...")
            // Start sending shopper location
            PreferenceManager.shouldStopLocation = false

            // Send message
            if (PreferenceManager.driverName != null){
                val message: String = AppConstants.MESSAGE_TYPE_DRIVER_JOINT + " " + PreferenceManager.driverName!! + " " + resources.getString(R.string.has_joint_chat)
                val systemMessageReq = SystemMessageReq(orderId.toString(), "text", message)
                sendSysteMessage(systemMessageReq){
                }
            }

            val message = AppConstants.MESSAGE_TYPE_DELIVERY_STARTED.toString() + " " + PreferenceManager.currentShopperFirstName + " " + resources.getString(R.string.began_delivering_order)
            val systemMessageReq = SystemMessageReq(orderId.toString(), "text", message)
            sendSysteMessage(systemMessageReq){
            }
        }

        if (state == STATUS_ARRIVED_TO_CUSTOMER) {
            if (!isFirstLoad) {
                // Show the user address popup
                showCustomerInfoDialog()
            }
            else {
                gotoArrivedCustomer()
            }
        }
    }


    fun sendSysteMessage(systemMessageReq: SystemMessageReq, onAfterSystemMessage: ()-> Unit){
        viewModel.sendSystemMessage(systemMessageReq, object : HandleResponse<SystemMessage> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                onAfterSystemMessage()
            }

            override fun handleSuccessResponse(successResponse: SystemMessage) {
                onAfterSystemMessage()
            }
        })
    }

    // Add circle to map
    private fun addCircleToMap(){
        if (map == null)
            return

        val radius = Math.pow(2.0, (14 - map!!.cameraPosition.zoom).toDouble()) * Math.pow(5.0, -3.0)

        val location = ShopperApp.Instance.mCurrentLocation
        if (location != null) {
            val latitude: Double = location.latitude
            val longitude: Double = location.longitude
            val optionsShadow2: CircleOptions = CircleOptions()
                .radius(radius * 21000)
                .fillColor(resources.getColor(R.color.colorMapAlpha))
                .strokeWidth(0f)
                .center(LatLng(latitude, longitude))
            shadowTwo = map!!.addCircle(optionsShadow2)

            val optionsShadow1: CircleOptions = CircleOptions()
                .radius(radius * 13500)
                .fillColor(resources.getColor(R.color.colorMapAlphaOne))
                .strokeWidth(0f)
                .center(LatLng(latitude, longitude))
            shadowOne = map!!.addCircle(optionsShadow1)

            val options: CircleOptions = CircleOptions()
                .radius(radius * 6000)
                .fillColor(resources.getColor(R.color.colorPrimary))
                .strokeColor(resources.getColor(R.color.colorWhite))
                .strokeWidth(1.5f)
                .center(LatLng(latitude, longitude))
            circle = map!!.addCircle(options)
        }
    }

    private fun hideScroll(){
        viewDataBinding!!.lvBottom.visibility = View.VISIBLE

        if (orderStatus == STATUS_DELIVERY || orderStatus == STATUS_ARRIVING_TO_SHOP){
            viewDataBinding!!.ivGoogleMap.visibility = View.VISIBLE
        }

        drawPolyline()
        viewDataBinding!!.btnSwipe.setOnStateChangeListener(this@LocationMapActivity)

        // Set animation for name and address
        // ... ... ...

    }

    private fun drawPolyline(){
        if (map == null)
            return

        val location = ShopperApp.Instance.mCurrentLocation
        if (location != null) {
            // Get directions
            viewModel.getDirections(LatLng(location.latitude, location.longitude), focusPosition!!, getString(R.string.directions_api_key), object : HandleResponse<ServerAnswer>{
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (isNetworkConnected){
                        Toast.makeText(this@LocationMapActivity, error?.message, Toast.LENGTH_SHORT).show()
                    }else{
                        Toast.makeText(this@LocationMapActivity, resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                    }
                }

                override fun handleSuccessResponse(successResponse: ServerAnswer) {
                    if (successResponse.routes != null){
                        val routeArray = successResponse.routes
                        for (route in routeArray) {
                            for (leg in route.legs) {
                                for (step in leg.steps) {
                                    val line = PolylineOptions()
                                    line.width(4f).color(getResources().getColor(R.color.colorPrimary))
                                    line.addAll(PolyUtil.decode(step.polyline!!.points))
                                    map!!.addPolyline(line)
                                }
                            }
                        }

                        if (isMapReady)
                            setCameraBounds()
                    }
                    else{
                        Toast.makeText(this@LocationMapActivity, getString(R.string.error_server_return_null), Toast.LENGTH_SHORT).show()
                    }
                }
            })
        }
    }

    // Set the camera bounds
    private fun setCameraBounds(){
        val location = ShopperApp.Instance.mCurrentLocation
        if (location != null && map != null) {
            val builder: LatLngBounds.Builder = LatLngBounds.Builder()
            builder.include(focusPosition!!)
            builder.include(LatLng(location.latitude, location.longitude))
            val bounds = builder.build()

            val width = resources.displayMetrics.widthPixels
            val height = resources.displayMetrics.heightPixels
            var cu: CameraUpdate = CameraUpdateFactory.newLatLngBounds(bounds, width, height, 0)
            map!!.moveCamera(cu)

            cu = CameraUpdateFactory.zoomBy(-0.7f)
            map!!.moveCamera(cu)
        }
    }

    // SwipeButton StateChangeListener
    override fun onChangeState(state: Int?) {
        Log.d("TAG", "onChangeState: "+state.toString())
//        var state = 10
        if (state!! == STATUS_ARRIVED_TO_SHOP) {
            val dec: Float = distance() //getDistance()
            var km = 0
            if (dec > 0) {
                //km = 5000;
                km = (dec / 1000).toInt()
            }
            if (km > arrivedAtStoreDistanceConfig) {
                viewDataBinding!!.btnSwipe.previousState()
                showValidationDialog()
//                Toast.makeText(this, getString(R.string.too_far_from_store), Toast.LENGTH_LONG).show()
            }
            else {
                tryUpdateStatus(state)
                orderStatus = state
                if (orderStatus == STATUS_DELIVERY || orderStatus == STATUS_ARRIVING_TO_SHOP) {
                    viewDataBinding!!.ivGoogleMap.visibility = View.VISIBLE
                }
            }
        } else {
            tryUpdateStatus(state)

            orderStatus = state
            if (orderStatus == STATUS_DELIVERY || orderStatus == STATUS_ARRIVING_TO_SHOP) {
                viewDataBinding!!.ivGoogleMap.visibility = View.VISIBLE
            }
        }
    }

    // Get distance between current location and customer location
    private fun getDistance() : Float{
        // https://stackoverflow.com/questions/8049612/calculating-distance-between-two-geographic-locations
        try {
            val location = ShopperApp.Instance.mCurrentLocation
            val locationB = Location("point B")
            if (focusPosition != null && location != null) {
                locationB.latitude = focusPosition!!.latitude
                locationB.longitude = focusPosition!!.longitude

                return location.distanceTo(locationB)
            } else {
                return 0f
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return 0f
        }
    }

    fun distance(): Float {
        try {
            val location = ShopperApp.Instance.mCurrentLocation
            val locationB = Location("point B")
            if (focusPosition != null && location != null) {
                locationB.latitude = focusPosition!!.latitude
                locationB.longitude = focusPosition!!.longitude

                val earthRadius = 3958.75
                val latDiff = Math.toRadians(locationB.latitude - location.latitude)
                val lngDiff = Math.toRadians(locationB.longitude - location.longitude)
                val a = Math.sin(latDiff / 2) * Math.sin(latDiff / 2) +
                        Math.cos(Math.toRadians(location.latitude)) * Math.cos(Math.toRadians(locationB.latitude)) *
                        Math.sin(lngDiff / 2) * Math.sin(lngDiff / 2)
                val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
                val distance = earthRadius * c
                val meterConversion = 1609
                return (distance * meterConversion.toFloat()).toFloat()
            }
            else {
                return 0f
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return 0f
        }


    }

    // Update the order status
    private fun tryUpdateStatus(state : Int){
        viewModel.updateOrderStatus(state, orderId, object:HandleResponse<SimpleResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Toast.makeText(this@LocationMapActivity, error?.message, Toast.LENGTH_SHORT).show()
                }else{
                    Toast.makeText(this@LocationMapActivity, resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }
                viewDataBinding!!.btnSwipe.previousState()
            }

            override fun handleSuccessResponse(successResponse: SimpleResponse) {
                val response = successResponse.response
                if (response != null){
                    if (response.httpCode == 200){
                        if (orderStatus == STATUS_DELIVERY) {
                            gotoGoogleMap()
                        }
                        doIfSpecialState(state)
                    }
                    else{
                        Toast.makeText(this@LocationMapActivity, response.message, Toast.LENGTH_SHORT).show()
                        viewDataBinding!!.btnSwipe.previousState()
                    }
                }
                else{
                    Toast.makeText(this@LocationMapActivity, getString(R.string.error_update_status), Toast.LENGTH_SHORT).show()
                    viewDataBinding!!.btnSwipe.previousState()
                }
            }
        })
    }

    // Show the validation dialog
    private fun showValidationDialog(){
        try{
            if (storeLocationDialogFragment != null) {
                if (storeLocationDialogFragment!!.isAdded) {
                    storeLocationDialogFragment!!.dismiss()
                }
            }
            storeLocationDialogFragment = StoreLocationDialogFragment.newInstance(focusName, focusAddress, focusPosition)
            storeLocationDialogFragment!!.show(supportFragmentManager, StoreLocationDialogFragment::class.java.name)
            storeLocationDialogFragment!!.isCancelable = false
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    // Open chat page
    fun openChatActivity(){
        Navigators.gotoChatActivity(this@LocationMapActivity, orderId, shopperOrder.userId?.toString()!!, shopperOrder.userFirstName ?: "", shopperOrder.userImage ?: "")
    }

    companion object {
        fun newIntent(context: Context?): Intent {
            return Intent(context, LocationMapActivity::class.java)
        }
    }
}