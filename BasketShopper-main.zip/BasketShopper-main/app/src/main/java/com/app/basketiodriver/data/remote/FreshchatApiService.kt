package com.app.basketiodriver.data.remote

import android.content.Context
import com.app.basketiodriver.BuildConfig
import com.app.basketiodriver.BuildConfig.BASE_URL
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.ticket.TicketFieldsData
import io.reactivex.Single
import com.google.gson.GsonBuilder
import com.google.gson.JsonObject
import com.jakewharton.retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import okhttp3.Cache
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.File
import java.util.Objects
import java.util.concurrent.TimeUnit

object FreshchatApiService {

    val FRESHCHAT_BASE_URL = "https://basket-help.freshdesk.com/api/v2/"
    val user = "cCXIMBC8l9CiugEpWwZj"
    val password = "Basket@1234"

    private lateinit var apiInterface: FreshchatApiInterface

    fun init(context : Context) {
        // BasicAuthInterceptor to OkHttp client
        val client =  OkHttpClient.Builder()
            .addInterceptor(BasicAuthInterceptor(user, password))
            .connectTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .readTimeout(50, TimeUnit.SECONDS)
            .build()

        val gson = GsonBuilder()
            .setLenient()
            .create()

        // add OkHttp client to Retrofit instance
        apiInterface = Retrofit.Builder()
            .baseUrl(FRESHCHAT_BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
            .build()
            .create(FreshchatApiInterface::class.java)
    }

    // Get type list
    fun getTicketTypes() : Single<ArrayList<TicketFieldsData>>{
        return apiInterface.getTicketFields()
    }

    fun createTicket(type : String, bid : Long, subject : String, description : String, priority : Int, status : Int, attach : File?) : Single<JsonObject>{
        val requestBody : HashMap<String, Any>  = HashMap<String, Any>()
        requestBody["description"] = description
        requestBody["email"] = PreferenceManager.currentShopperEmail ?: ""
        requestBody["priority"] = priority
        requestBody["status"] = status
        requestBody["type"] = type
        requestBody["subject"] = subject

        val customFieldsJson = HashMap<String, Any>()
        customFieldsJson["cf_bid"] = bid
        customFieldsJson["cf_shopper_id"] = PreferenceManager.currentShopperId ?: 0L
        requestBody["custom_fields"] = customFieldsJson

//        val emailBody = (PreferenceManager.currentShopperEmail ?: "").toRequestBody("text/plain".toMediaTypeOrNull())
//        val descriptionBody = description.toRequestBody("text/plain".toMediaTypeOrNull())
//        val typeBody = type.toRequestBody("text/plain".toMediaTypeOrNull())
//        val priorityBody = priority.toString().toRequestBody("text/plain".toMediaTypeOrNull())
//        val statusBody = status.toString().toRequestBody("text/plain".toMediaTypeOrNull())
//        val customFieldsBody = customFieldsJson.toString().toRequestBody("text/plain".toMediaTypeOrNull())

//        var image: MultipartBody.Part? = null
//        if (attach != null) {
//            val requestFile: RequestBody = attach.asRequestBody("image/*".toMediaTypeOrNull())
//            image = MultipartBody.Part.createFormData("attachments[]", attach.name, requestFile)
//        }

        return apiInterface.createTicket(requestBody)
    }
}