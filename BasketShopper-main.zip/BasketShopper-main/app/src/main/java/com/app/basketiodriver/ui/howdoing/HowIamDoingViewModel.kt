package com.app.basketiodriver.ui.howdoing

import android.app.Application
import com.app.basketiodriver.data.DataManager
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.howamidoing.HowAmIDoingDetailResponse
import com.app.basketiodriver.data.model.api.response.howamidoing.HowAmIDoingResponse
import com.app.basketiodriver.data.model.api.response.howamidoing.ShopperRatingResponse
import com.app.basketiodriver.data.model.api.response.shopper.ShopperResponse
import com.app.basketiodriver.data.remote.APIManager
import com.app.basketiodriver.mvvm.ui.login.LoginNavigator
import com.app.basketiodriver.ui.base.BaseViewModel
import com.app.basketiodriver.ui.base.HandleResponse
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers


/**
Created by ibraheem lubbad on 2020-02-18.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class HowIamDoingViewModel(
    application: Application,
    dataManager: DataManager
) :
    BaseViewModel<LoginNavigator?>(application, dataManager) {
    /**
     * Method to get the How am I doing
     * @param langCode current language code , 1 : EN
     * @param shopperId current shopper ID
     * @param token access token
     * @param handleResponse HandleResponse<ShopperResponse>
     */
    fun getHowAmIDoing(handleResponse: HandleResponse<HowAmIDoingResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperHowAmIDoing(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }


                    }
                )
        )
    }

    // How Am I Doing Details
    fun getHowAmIDoingDetails(action : String, handleResponse: HandleResponse<HowAmIDoingDetailResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperHowAmIDoingDetails(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, action)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    // Shopper Rating Details
    fun getShopperRatingDetails(ratingType : String, handleResponse: HandleResponse<ShopperRatingResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperRatingDetails(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, ratingType)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }
}