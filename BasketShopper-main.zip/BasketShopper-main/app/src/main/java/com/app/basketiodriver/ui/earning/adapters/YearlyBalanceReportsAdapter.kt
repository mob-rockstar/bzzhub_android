package com.app.basketiodriver.ui.earning.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.earning.YearlyBalanceReportItem
import com.app.basketiodriver.databinding.ItemShopperEarningsBinding
import com.app.basketiodriver.ui.base.DataListAdapter
import com.app.basketiodriver.ui.base.DataViewHolder
import com.app.basketiodriver.utils.CommonUtils
import com.app.basketiodriver.utils.OnItemClickedListener

class YearlyBalanceReportsAdapter (val mContext : Context, val listener: OnItemClickedListener<YearlyBalanceReportItem>) :
    DataListAdapter<YearlyBalanceReportItem, ItemShopperEarningsBinding>(){

    override fun createBinding(inflater: LayoutInflater, parent: ViewGroup? ): ItemShopperEarningsBinding {
        return DataBindingUtil.inflate(inflater, R.layout.item_shopper_earnings, parent, false)
    }

    override fun onBindViewHolder(holder: DataViewHolder<ItemShopperEarningsBinding>, position: Int) {
        super.onBindViewHolder(holder, position)
        holder.binding.root.setOnClickListener { listener.onClicked(holder.binding.yearlyBalanceReport!!) }
    }

    override fun bind(binding: ItemShopperEarningsBinding?, item: YearlyBalanceReportItem) {
        binding!!.yearlyBalanceReport = item

        // Month Name
        binding.monthTV.text = item.monthName

        // Amount
        val amount = PreferenceManager.currency + " " + item.monthBalance
        binding.amountTV.text = amount
        CommonUtils.setBalanceTextColor(binding.amountTV, "" + item.monthBalance)

        // Year
        val year = mContext.getString(R.string.year) + " " + item.year
        binding.txtYear.text = year

        binding.ldHeader.visibility = View.VISIBLE

        val position = getItems().indexOf(item)
        if (position > 0){
            if (item.year.equals(getItems()[position - 1].year, true)) {
                binding.ldHeader.visibility = View.GONE
            }
            else{
                binding.ldHeader.visibility = View.VISIBLE
            }
        }
    }

}