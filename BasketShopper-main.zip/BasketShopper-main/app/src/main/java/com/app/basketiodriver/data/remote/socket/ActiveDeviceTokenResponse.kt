package com.app.basketiodriver.data.remote.socket

data class ActiveDeviceTokenResponse(
    var `data`: ArrayList<ActiveDeviceToken>,
    var message: String,
    var status: Int
)