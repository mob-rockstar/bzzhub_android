package com.app.basketiodriver.data.model.api.response.directions

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class Leg {
    @SerializedName("distance")
    @Expose
    val distance: Distance? = null

    @SerializedName("duration")
    @Expose
    val duration: Duration? = null

    @SerializedName("end_address")
    @Expose
    val endAddress: String? = null

    @SerializedName("end_location")
    @Expose
    val endLocation: EndLocation? = null

    @SerializedName("start_address")
    @Expose
    val startAddress: String? = null

    @SerializedName("start_location")
    @Expose
    val startLocation: StartLocation? = null

    @SerializedName("steps")
    @Expose
    val steps: List<Step> = arrayListOf()

    @SerializedName("traffic_speed_entry")
    @Expose
    val trafficSpeedEntry: List<Any>? = null

    @SerializedName("via_waypoint")
    @Expose
    val viaWaypoint: List<Any>? = null
}