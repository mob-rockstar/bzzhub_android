
package com.app.basketiodriver.di.component

import com.app.basketiodriver.ShopperApp
import com.app.basketiodriver.di.builder.ActivityBuilder
import com.app.basketiodriver.di.module.AppModule
import dagger.BindsInstance
import dagger.Component
import dagger.android.AndroidInjectionModule
import javax.inject.Singleton


/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/

@Singleton
@Component(modules = [AndroidInjectionModule::class, AppModule::class, ActivityBuilder::class])
interface AppComponent {

    @Component.Builder
    interface Builder {
        @BindsInstance
        fun application(application: ShopperApp): Builder
        fun build(): AppComponent
    }


    fun inject(app: ShopperApp)

}