package com.app.basketiodriver.data.model.api.response.hours

import com.app.basketiodriver.data.model.api.response.Base.BaseResponse
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class RateCardResponse : BaseResponse() {
    @SerializedName("data")
    val data: RateDetailData? = null

    inner class RateDetailData {
        @SerializedName("shopping_per_order_earning")
        @Expose
        val shopping_per_order_earning: String? = null

        @SerializedName("shopping_per_item_earning")
        @Expose
        val shopping_per_item_earning: String? = null

        @SerializedName("shopper_minimum_fee")
        @Expose
        val shopper_minimum_fee: String? = null

        @SerializedName("delivery_per_order_earning")
        @Expose
        val delivery_per_order_earning: String? = null

        @SerializedName("delivery_per_km")
        @Expose
        val delivery_per_km: String? = null

        @SerializedName("delivery_minimum_earning")
        @Expose
        val delivery_minimum_earning: String? = null

        @SerializedName("full_service_per_order")
        @Expose
        val full_service_per_order: String? = null

        @SerializedName("full_service_per_item")
        @Expose
        val full_service_per_item: String? = null

        @SerializedName("full_service_per_km")
        @Expose
        val full_service_per_km: String? = null

        @SerializedName("full_min_service_fee")
        @Expose
        val full_min_service_fee: String? = null

        @SerializedName("is_peak_hour_10")
        @Expose
        val is_peak_hour_10 = 0

        @SerializedName("is_peak_hour_20")
        @Expose
        val is_peak_hour_20 = 0
    }
}