package com.app.basketiodriver.data.model.api.response.notification

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName

class NotificationListResponse {
    @SerializedName("httpCode")
    @Expose
    val httpCode: Int? = null

    @SerializedName("Message")
    @Expose
    val message: String? = null

    @SerializedName("notification_list")
    @Expose
    val notificationListData: List<NotificationListData>? = null
}