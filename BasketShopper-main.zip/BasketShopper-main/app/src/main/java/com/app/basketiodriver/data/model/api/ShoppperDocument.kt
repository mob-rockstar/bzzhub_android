package com.app.basketiodriver.data.model.api

import com.google.gson.annotations.SerializedName

/**
 * Created by ibraheem lubbad on 2020-02-10.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 */
data class ShoppperDocument(
    @SerializedName("id") val id: Int,
    @SerializedName("file_type") val file_type: String,
    @SerializedName("file") val file: String,
    @SerializedName("status") val status: String,
    @SerializedName("created_at") val created_at: String,
    @SerializedName("updated_at") val updated_at: String,
    @SerializedName("type") val type: String,
    @SerializedName("file") val path: String,
    @SerializedName("order") val order: Int,
    @SerializedName("file_url") val file_url: String,
    @SerializedName("review_note") val review_note: String

)

