package com.app.basketiodriver.ui.checkout.orderdetails

import android.app.Application
import android.util.Log
import com.app.basketiodriver.data.DataManager
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.checkout.ShopperOrderDetail
import com.app.basketiodriver.data.model.api.response.checkout.ShopperOrderReview
import com.app.basketiodriver.data.model.api.response.checkout.ShopperOrderTimer
import com.app.basketiodriver.data.model.api.response.general.SimpleResponse
import com.app.basketiodriver.data.model.api.response.order.*
import com.app.basketiodriver.data.remote.APIManager
import com.app.basketiodriver.data.remote.socket.SystemMessage
import com.app.basketiodriver.data.remote.socket.SystemMessageReq
import com.app.basketiodriver.ui.base.BaseNavigator
import com.app.basketiodriver.ui.base.BaseViewModel
import com.app.basketiodriver.ui.base.HandleResponse
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import java.io.File

class OrderDetailsViewModel constructor(application: Application, dataManager: DataManager): BaseViewModel<BaseNavigator?>(application, dataManager) {

    /**
     * Replacement limit count
     */
    var replaceLimitCount : Int = 1

    /**
     * Method to get order details
     */
    fun shopperOrderDetailRequest(orderOutletId : String, fastestRoute : String, handleResponse: HandleResponse<ShopperOrderDetail>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperOrderDetailRequest(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, orderOutletId, fastestRoute)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    fun sendSystemMessage(message: SystemMessageReq, handleResponse: HandleResponse<SystemMessage>){
        setIsLoading(true)
        compositeDisposable.add(APIManager.sendSystemMessage(message)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessResponse(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            )
        )
    }

    /**
     * Method to get order review(detail)
     */
    fun getShopperOrderReview(orderId : Long, handleResponse: HandleResponse<ShopperOrderReview>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperOrderReview(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, orderId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to get order timer
     */
    fun getOrderTimer(orderId : Long, handleResponse: HandleResponse<ShopperOrderTimer>){
        compositeDisposable.add(
            APIManager.shopperOrderTimerRequest(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, orderId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {

                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {

                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to get dashboard order info
     */
    fun getDashboardOrderInfo(orderId : Long, handleResponse: HandleResponse<DashboardOrderInfoResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.getDashboardOrderInfo(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, orderId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to get history order info
     */
    fun getHistoryOrderInfo(orderId : Long, handleResponse: HandleResponse<HistoryOrderInfoResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.getHistoryOrderInfo(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, orderId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to update the shopper order status
     */
    fun updateOrderStatus(orderStatus : Int, orderId : Long, handleResponse: HandleResponse<SimpleResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.updateOrderStatus(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, PreferenceManager.shopperStatus, orderStatus, orderId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to get reason list
     */
    fun getCanNotFindItemReasons(handleResponse: HandleResponse<CommonResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.getCanNotFindItemReasonList(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to replace the item
     */
    fun confirmReplacedItem(itemId : Long, quantity : Double, handleResponse: HandleResponse<SimpleResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.confirmReplacedItem(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, itemId, quantity)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to confirm the item qty difference
     */
    fun confirmItemQtyDifference(itemId : Long, handleResponse: HandleResponse<SimpleResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.confirmItemQtyDifference(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, itemId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to cancel the replaced item
     */
    fun cancelReplacedItem(itemId : Long, handleResponse: HandleResponse<SimpleResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.cancelReplacedItem(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, itemId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to mark as found
     */
    fun markAsFound(id : Long, isFound : Boolean, isQtyDiff : Boolean, handleResponse: HandleResponse<SimpleResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperMarkItemAsFound(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, id, isFound, isQtyDiff)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to update the item quantity
     */
    fun updateItemQuantity(id : Long, qty : Double, handleResponse: HandleResponse<SimpleResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.updateItemQty(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, id, qty)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to cancel item qty difference
     */
    fun cancelItemQtyDiff(id : Long, handleResponse: HandleResponse<SimpleResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.cancelItemQtyDifference(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, id)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to cancel refund
     */
    fun cancelRefund(id : Long, handleResponse: HandleResponse<SimpleResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.cancelRefund(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, id)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to update the item weight
     */
    fun updateItemWeight(id : Long, weight : Double, qty: Double, handleResponse: HandleResponse<SimpleResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.updateItemWeight(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, id, weight, qty)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to set the reason for not found item
     */
    fun setItemNotFoundReason(id : Long, outletId : Long, orderItemId : Int, reasonId : Int, handleResponse: HandleResponse<CommonResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.setItemNotFoundReason(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, id, outletId, orderItemId, reasonId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to get suggestion product list
     */
    fun shopperSuggestionProductList(itemId : Long, orderId: Long, search : String?, handleResponse: HandleResponse<SuggestionResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperSuggestionProductList(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, itemId, orderId, search)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to get add product list by searching
     */
    fun shopperAddProductList(itemId : Long, search : String, handleResponse: HandleResponse<SimilarResponse>){
//        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperAddProductList(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, itemId, search)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
//                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
//                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }


    /**
     * Method to get similar product list
     */
    fun shopperSimilarProductList(itemId : Long, isCustom: Int, search : String, handleResponse: HandleResponse<SimilarResponse>){
//        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperSimilarProductList(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, itemId, isCustom, search)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
//                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
//                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Replace the multiple ordersItems
     */
    fun replaceMultipleOrdersItems(oldItemId : Long, orderId: Long, items: ArrayList<ReplacementOrdersItemRequest>, actionFrom : Int, handleResponse: HandleResponse<CommonResponse>){
        val jsonObject = JsonObject()
        val replaceItemsJsonArray = JsonArray()
        for (item in items) {
            val itemJson = JsonObject()
            itemJson.addProperty("item_id", item.product!!.outletItemId)
            itemJson.addProperty("item_qty", item.quantity)
            itemJson.addProperty("item_weight", item.weight)

            replaceItemsJsonArray.add(itemJson)
        }

        jsonObject.addProperty("shopper_id", PreferenceManager.currentShopperId!!)
        jsonObject.addProperty("token", PreferenceManager.accessToken!!)
        jsonObject.addProperty("orders_outlet_id", orderId)
        jsonObject.addProperty("original_item_id", oldItemId)
        jsonObject.addProperty("action_from", actionFrom)
        jsonObject.add("replacement_item", replaceItemsJsonArray)

        Log.d("EnterQuantityWeight", "Replace request json : " + jsonObject.toString())

        setIsLoading(true)
        compositeDisposable.add(APIManager.replaceMultipleItems(jsonObject)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessResponse(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                })
        )
    }

    /**
     * Replace the multiple items
     */
    fun replaceMultipleItems (oldItemId : Long, orderId: Long, items: ArrayList<ReplacementSearchItemRequest>, actionFrom : Int, handleResponse: HandleResponse<CommonResponse>){
        val jsonObject = JsonObject()
        val replaceItemsJsonArray = JsonArray()
        for (item in items) {
            val itemJson = JsonObject()
            itemJson.addProperty("item_id", item.product!!.outletItemId)
            itemJson.addProperty("item_qty", item.quantity)
            itemJson.addProperty("item_weight", item.weight)

            replaceItemsJsonArray.add(itemJson)
        }

        jsonObject.addProperty("shopper_id", PreferenceManager.currentShopperId!!)
        jsonObject.addProperty("token", PreferenceManager.accessToken!!)
        jsonObject.addProperty("orders_outlet_id", orderId)
        jsonObject.addProperty("original_item_id", oldItemId)
        jsonObject.addProperty("action_from", actionFrom)
        jsonObject.add("replacement_item", replaceItemsJsonArray)

        Log.d("EnterQuantityWeight", "Replace request json : " + jsonObject.toString())

        setIsLoading(true)
        compositeDisposable.add(APIManager.replaceMultipleItems(jsonObject)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                    setIsLoading(false)
                    handleResponse.handleSuccessResponse(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                })
        )

    }

    /**
     * Method to replace the item to be done
     */
    fun shopperReplaceItemToDone(qty: Double, weight: Double, oldItemId : Long, newItemId : Long, orderId: Long, action : Int, handleResponse: HandleResponse<SimilarResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperReplaceItemToDone(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, qty, weight, oldItemId, newItemId, orderId, action)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to replace the item amount
     */
    fun shopperReplaceItem(qty: Double, oldItemId: Long, newItemId: Long, orderId: Long, action: Int, handleResponse: HandleResponse<CommonResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperReplaceItem(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, qty, oldItemId, newItemId, orderId, action)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to refund item
     */
    fun refundItem(itemId: Long, actionFrom : Int, handleResponse: HandleResponse<CommonResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.itemRefund(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, itemId, actionFrom)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to check the barcode of product
     */
    fun checkBarcode(itemId : Long, barcode : String, isReplacement : Int, replaceId : Long, handleResponse: HandleResponse<CommonResponse>) {
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.checkProductBarcode(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, itemId, barcode, isReplacement, replaceId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to upload captured image as found
     */
    fun addForceMarkAsFound(orderId : Long, orgItemId : Long, barcode : String, file : File, handleResponse: HandleResponse<SimpleDataResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.addForceMarkAsFound(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, orderId, orgItemId, barcode, file)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to get product details by using Barcode
     */
    fun getProductByBarcode(outletId: Long, barcode : String, handleResponse: HandleResponse<ItemResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.getProductByBarcode(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, outletId, barcode)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Check item barcode
     */
    fun getCheckItemByBarcode(orderId : Long, barcode : String, handleResponse: HandleResponse<SimpleResponse>) {
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.getCheckItemByBarcode(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, orderId, barcode)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to add item by barcode
     */
    fun addItemByBarcode(orderId : Long, barcode : String, qty : Double, isScanned : Int, handleResponse: HandleResponse<SimpleResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.addItemByBarcode(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, orderId, barcode, qty, isScanned)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to add the custom product
     */
    fun addCustomProduct(orderId : Long, barcode : String, name : String, file : File?, contain : Int, unit : String, count : Double, price : Double, handleResponse: HandleResponse<SimpleResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.addCustomProduct(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, orderId, barcode, name, file, contain, unit, count, price)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to replace the custom item
     */
    fun replaceCustomItem(orderId : Long, barcode : String, name : String, file : File?, contain : Int, unit : String, count : Double, price : Double, handleResponse: HandleResponse<SimpleResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.replaceCustomItem(PreferenceManager.currentUserLanguage, PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, orderId, barcode, name, file, contain, unit, count, price)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    /**
     * Method to flag item
     */
    fun shopperFlagItem(orderId : Long, reason : Int, handleResponse: HandleResponse<SimpleResponse>){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.shopperFlagItem(PreferenceManager.currentShopperId!!, PreferenceManager.accessToken!!, orderId, reason)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessResponse(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }
}