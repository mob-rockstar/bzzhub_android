package com.app.basketiodriver.data.model.api.response.earning.bonus

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class ShopperBonusDeductionsData {
    @SerializedName("bonus_deduction")
    @Expose
    val bonusDeductions: ArrayList<BonusDeductionsData> = arrayListOf()

    @SerializedName("contact_support_text")
    @Expose
    val contact_support_text: String = ""

    @SerializedName("current_account_balance")
    @Expose
    val current_account_balance: String = "0.00"

    @SerializedName("is_account_suspended")
    @Expose
    val is_account_suspended = false
}