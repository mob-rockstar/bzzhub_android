package com.app.basketiodriver.ui.home

//import kotlinx.android.synthetic.main.app_bar_with_support.view.*
//import kotlinx.android.synthetic.main.drawer_footer.view.*

import android.Manifest
import android.annotation.SuppressLint
import android.app.Dialog
import android.content.*
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.location.Location
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.util.Log
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ExpandableListView.OnChildClickListener
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.widget.Toolbar
import androidx.core.app.NotificationCompat
import androidx.core.view.GravityCompat
import androidx.lifecycle.Observer
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.app.basketiodriver.BuildConfig
import com.app.basketiodriver.R
import com.app.basketiodriver.ShopperApp
import com.app.basketiodriver.data.SupportMenuManager
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.chat.BaseResponse
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.dashboard.Order
import com.app.basketiodriver.data.model.api.response.general.SimpleResponse
import com.app.basketiodriver.data.model.api.ticket.TicketFieldsData
import com.app.basketiodriver.data.remote.socket.*
import com.app.basketiodriver.databinding.ActivityHomeBinding
import com.app.basketiodriver.databinding.DialogChangeLanguageBinding
import com.app.basketiodriver.databinding.DialogLogoutBinding
import com.app.basketiodriver.di.Navigators
import com.app.basketiodriver.mvvm.ui.login.LoginNavigator
import com.app.basketiodriver.service.FCMService
import com.app.basketiodriver.service.ForegroundOnlyLocationService
import com.app.basketiodriver.service.GPSTrackService
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.complain.ComplainActivity
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.PAYMENT_TYPE_BRING_CC
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.PAYMENT_TYPE_CREDIT
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_CHECKOUT
import com.app.basketiodriver.ui.dialogs.*
import com.app.basketiodriver.ui.earning.EarningActivity
import com.app.basketiodriver.ui.home.adapters.ExpandableListAdapter
import com.app.basketiodriver.ui.home.adapters.MenuModel
import com.app.basketiodriver.ui.hours.HoursActivity
import com.app.basketiodriver.ui.howdoing.HowDoingActivity
import com.app.basketiodriver.ui.login.LoginActivity
import com.app.basketiodriver.ui.notifications.NotificationsActivity
import com.app.basketiodriver.ui.profile.ProfileActivity
import com.app.basketiodriver.ui.status.StatusActivity
import com.app.basketiodriver.utils.*
import com.freshchat.consumer.sdk.Freshchat
import com.freshchat.consumer.sdk.FreshchatConfig
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.tbruyelle.rxpermissions2.RxPermissions
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import io.reactivex.android.schedulers.AndroidSchedulers
import io.socket.client.Ack
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import org.json.JSONArray
import org.json.JSONObject
import timber.log.Timber
import zendesk.chat.*
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.*
import javax.inject.Inject


class HomeActivity : BaseActivity<ActivityHomeBinding?, HomeViewModel>(),
    LoginNavigator,
    HasAndroidInjector {


    override val layoutId: Int
        get() = R.layout.activity_home

    override val viewModel: HomeViewModel
        get() {
            return getViewModel(HomeViewModel::class.java)
        }

    private lateinit var supportMenuManager: SupportMenuManager

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    // Chat configuration for Zendesk
    var chatConfiguration: ChatConfiguration? = null

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        //  menuInflater.inflate(R.menu.home, menu)
        return true
    }

    private var navController: NavController? = null

    private var gpsTracker: GPSTrackService? = null
    lateinit var builder: NotificationCompat.Builder

    // Store instructions page
    var checkoutInstructionsDialog: CheckoutInstructionsDialogFragment? = null

    // Credit Card order page
    var cardInstructionsDialog: CardInstructionsDialogFragment? = null

    // Bring CC Machine Dialog
    var bringCCDialog : BringCCMachineDialogFragment? = null

    var reviewOrder: Order? = null

    // Location service intent
    var locationServiceIntent : Intent? = null

    @Inject
    lateinit var socketManager: SocketManager

    // Current location
    var location: Location? = null

    private var foregroundOnlyLocationServiceBound = false

    // Provides location updates for while-in-use feature.
    private var foregroundOnlyLocationService: ForegroundOnlyLocationService? = null

    // Listens for location broadcasts from ForegroundOnlyLocationService.
    private lateinit var foregroundOnlyBroadcastReceiver: ForegroundOnlyBroadcastReceiver

    // Monitors connection to the while-in-use service.
    private val foregroundOnlyServiceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, service: IBinder) {
            val binder = service as ForegroundOnlyLocationService.LocalBinder
            foregroundOnlyLocationService = binder.service
            foregroundOnlyLocationServiceBound = true
        }

        override fun onServiceDisconnected(name: ComponentName) {
            foregroundOnlyLocationService = null
            foregroundOnlyLocationServiceBound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState)
        viewModel.screenTitle.observe(this, Observer { toolbarTitle(it) })
        builder = NotificationCompat.Builder(this, FCMService.BASKET_CHANNEL_NAME)

        // Register EventBus
//        EventBus.getDefault().register(this)

        // Set the navigation tool bar
        setToolBar(viewDataBinding!!.layoutToolBar.toolbar)

        // Initialize the Location BroadcastReceiver
//        foregroundOnlyBroadcastReceiver = ForegroundOnlyBroadcastReceiver()

        navController = Navigation.findNavController(this, R.id.navHomeFragment)
        populateMenu()

        // Check if the location permission is granted
        requestPermissions()

        // Zendesk
//        initZendeskConfiguration()

        // Check actions
        if (savedInstanceState == null) {
            checkActions()
        }

        // Handover
        if (handover) {
            handover = false
            openHandoverDialog()
        }

        getSocketToken()
    }

    @SuppressLint("MissingPermission", "CheckResult")
    private fun requestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            RxPermissions(this).request(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.POST_NOTIFICATIONS,
                Manifest.permission.CAMERA,
                Manifest.permission.READ_MEDIA_IMAGES
            ).subscribe { granted ->
                if (granted) {
                    Timber.tag(TAG).d("===== Build.VERSION_CODES.TIRAMISU - All permissions are granted ...")
                    try {
                        // Init the GPS Tracker
                        gpsTracker = GPSTrackService(this)

                        initFreshChat()

                        // Start Location
                        ShopperApp.Instance.startLocationService(this)
                    }
                    catch (e : Exception){
                        e.printStackTrace()
                    }
                }
                else{
                    Timber.tag(TAG).d("===== Build.VERSION_CODES.TIRAMISU - All permissions are not granted ...")
                }
            }
        }
        else{
            RxPermissions(this).request(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.CAMERA,
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ).subscribe { granted ->
                if (granted) {
                    Timber.tag(TAG).d("===== All permissions are granted ...")
                    try {
                        // Init the GPS Tracker
                        gpsTracker = GPSTrackService(this)

                        // Start Location
                        ShopperApp.Instance.startLocationService(this)

                        initFreshChat()
                    }
                    catch (e : Exception){
                        e.printStackTrace()
                    }
                }
                else{
                    Timber.tag(TAG).d("===== All permissions are not granted ...")
                }
            }
        }


        // Check the Post Notification permission
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
//            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
//                // Do your task on permission granted
//            }
//            else if (shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
//                Toast.makeText(this@HomeActivity, getString(R.string.msg_grant_notification), Toast.LENGTH_SHORT).show()
//            }
//            else {
//                // Directly ask for the permission
//                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
//            }
//        }
    }

    private val requestPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
        if (isGranted) {
            // Notification Permission Granted
        }
        else {
            // Notification Permission Denied / Cancel
        }
    }

    fun getActiveTokenList() {
        viewModel.getTokenList(object : HandleResponse<ActiveDeviceTokenResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected) {
                    this@HomeActivity.handleError(error?.message ?: "Failed to get the chat token")
                } else {
                    this@HomeActivity.handleError(
                        resources?.getString(R.string.no_internet_conn_msg_txt) ?: ""
                    )
                }
            }

            override fun handleSuccessResponse(successResponse: ActiveDeviceTokenResponse) {
                if (successResponse.status == 200) {
                    PreferenceManager.userChatToken = String(
                        android.util.Base64.encode(
                            Gson().toJson(
                                successResponse.data
                            ).toByteArray(), android.util.Base64.DEFAULT
                        )
                    )

                    // Initialize the sockets
                    initSockets()

                    try{
                        if (gpsTracker != null && gpsTracker!!.canGetLocation && gpsTracker!!.mLocation != null){
                            // Upload the shopper location to server
                            postShopperLiveLocation(gpsTracker!!.mLocation!!.latitude, gpsTracker!!.mLocation!!.longitude, gpsTracker!!.mLocation!!)
                        }
                    }
                    catch (e : Exception){
                        e.printStackTrace()
                    }

//                    getSocketToken()
                }
            }
        })
    }

    fun initSockets(){
//        socketManager = SocketManager()
        socketManager.init(ShopperApp.Instance.newMessageCallback)
        ShopperApp.Instance.isInitiatedSocket = true

        if (socketManager.chatSocket != null || !socketManager.chatSocket!!.connected())
            socketManager.chatSocket?.connect()

        socketManager.basketLocationService?.connect()
    }

    private fun getSocketToken() {
        viewModel.getSocketToken(object : HandleResponse<SocketTokenResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected) {
                    this@HomeActivity.handleError(error?.message ?: "Failed to get the socket token")
                } else {
                    this@HomeActivity.handleError(
                        resources?.getString(R.string.no_internet_conn_msg_txt) ?: ""
                    )
                }
            }

            override fun handleSuccessResponse(successResponse: SocketTokenResponse) {
                if (successResponse.status == 200) {
                    PreferenceManager.socketToken = successResponse.data?.serviceToken
                    // Get the chat token
                    getActiveTokenList()
                }
            }
        })
    }

    override fun onDestroy() {
        super.onDestroy()
//        EventBus.getDefault().unregister(this)

    }

    override fun onStop(){
        super.onStop()
    }

    override fun onResume() {
        super.onResume()

//        registerLocationBroadcastReceiver()

        // Check if there are orders payment method was changed
//        ShopperApp.Instance.showNextPaymentChangedPopup()
    }

    override fun onStart() {
        super.onStart()

//        startForegroundLocationService()
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    override fun onMessageEvent(event: MessageEvent) {
        super.onMessageEvent(event)

        when (event.message) {
            AppConstants.MESSAGE_OPEN_STORE_INSTRUCTION -> {
                reviewOrder = event.data as Order
                showStoreInstructionsPage()
            }
            AppConstants.MESSAGE_OPEN_ORDER_REVIEW -> {
                val order = event.data as Order
                Navigators.gotoOrderInfoActivity(
                    this,
                    order.orderOutletId ?: 0,
                    order.orderStatus,
                    order
                )
            }
            AppConstants.MESSAGE_OPEN_ORDER_MAP -> {
                val orderId = event.data as Long
                Navigators.goToLocationMap(this, orderId, 0)
            }
            AppConstants.MESSAGE_POST_LOCATION->{
                val mCurrentLocation = event.data as Location
                postShopperLiveLocation(mCurrentLocation.latitude, mCurrentLocation.longitude, mCurrentLocation)
            }
            AppConstants.MESSAGE_LOCATION_SOCKET_CONNECTED->{
                if (ShopperApp.Instance.mCurrentLocation != null){
                    postShopperLiveLocation(ShopperApp.Instance.mCurrentLocation!!.latitude, ShopperApp.Instance.mCurrentLocation!!.longitude, ShopperApp.Instance.mCurrentLocation!!)
                }
            }
            AppConstants.MESSAGE_APP_IN_FOREGROUND->{ // Foreground
//                registerLocationBroadcastReceiver()
            }
            AppConstants.MESSAGE_APP_IN_BACKGROUND->{ // Background
//                unbindForegroundLocationService()
            }
            else -> {

            }
        }
    }

    /**
     * Register the LocationBroadcastReceiver
     */
    private fun registerLocationBroadcastReceiver(){
        LocalBroadcastManager.getInstance(this).registerReceiver(
            foregroundOnlyBroadcastReceiver,
            IntentFilter(
                ForegroundOnlyLocationService.ACTION_FOREGROUND_ONLY_LOCATION_BROADCAST)
        )
    }

    /**
     * Unbind the LocationService when app is in background mode
     */
    private fun unbindForegroundLocationService(){
        if (foregroundOnlyLocationServiceBound) {
            unbindService(foregroundOnlyServiceConnection)
            foregroundOnlyLocationServiceBound = false
        }
    }

    /**
     * Start the ForegroundLocationService
     */
    private fun startForegroundLocationService(){
        val serviceIntent = Intent(this, ForegroundOnlyLocationService::class.java)
        bindService(serviceIntent, foregroundOnlyServiceConnection, Context.BIND_AUTO_CREATE)
        Handler(Looper.getMainLooper()).postDelayed({
            startOrStopLocationService()
        }, 500)
    }

    /**
     * Stop the ForegroundLocationService
     */
    fun stopForegroundLocationService(){
        foregroundOnlyLocationService?.unsubscribeToLocationUpdates()
    }

    @SuppressLint("TimberArgCount", "CheckResult")
    fun startOrStopLocationService(){
        // TODO: Step 1.0, Review Permissions: Checks and requests if needed.
        RxPermissions(this).request(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe { granted ->
                if (granted) {
                    try {
                        // Start Location
                        foregroundOnlyLocationService?.subscribeToLocationUpdates()
                            ?: Timber.tag(TAG).d("Service is still not bound")
                    }
                    catch (e : Exception){
                        e.printStackTrace()
                    }
                } else {
                    PopupUtils.showConfirmDialog(
                        this,
                        getString(R.string.gps_title),
                        getString(R.string.gps_message)
                    ) {
                        val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                        startActivity(intent)
                    }
                }
            }
    }

    private fun checkActions() {
        val action = intent.action
        if (action != null && action == "Action_Congratulation") {
            showCongratulationDialog()
        }
    }

    // Show the Order complete dialog
    private fun showCongratulationDialog() {
        if (intent.extras != null) {
            val orderId = intent.extras!!.getLong("ARG_ORDER_ID")

            DialogOrderCompleted.openDialog(this, orderId, this::dismissOrderCompleteDialog)
        }
    }

    // Show the "This is the credit card order" page
    private fun showCCOrderTintPage() {
        try{
            runOnUiThread {
                cardInstructionsDialog = CardInstructionsDialogFragment.newInstance()
                cardInstructionsDialog!!.show(
                    supportFragmentManager,
                    CardInstructionsDialogFragment.javaClass.name
                )
                cardInstructionsDialog!!.listener = agreeCCOrderTintListener
            }
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    /**
     * Show the Bring CC Machine
     */
    private fun showBringCCMachineInstruction(){
        try{
            runOnUiThread {
                bringCCDialog = BringCCMachineDialogFragment.newInstance()
                bringCCDialog!!.show(
                    supportFragmentManager,
                    BringCCMachineDialogFragment.javaClass.name
                )
                bringCCDialog!!.listener = continueOrderListener
            }
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    /**
     * ContinueOrderListener
     */
    private val continueOrderListener: BringCCMachineDialogFragment.ContinueOrderListener =
        object : BringCCMachineDialogFragment.ContinueOrderListener {
            override fun onContinueOrder() {
                if (reviewOrder != null) {
                    // Go to Checkout page
                    Navigators.goToPaymentTypeActivity(
                        this@HomeActivity,
                        reviewOrder!!.orderOutletId ?: 0
                    )
                }
            }
        }

    /**
     * AgreeTermsListener
     */
    private val agreeStoreInstructionsListener: CheckoutInstructionsDialogFragment.AgreeTermsListener =
        object : CheckoutInstructionsDialogFragment.AgreeTermsListener {
            override fun onAgreed() {
//                if (checkoutInstructionsDialog != null)
//                    checkoutInstructionsDialog!!.dismiss()

                if (reviewOrder != null) {
                    if (reviewOrder!!.paymentGateway == PAYMENT_TYPE_CREDIT) { // Credit Card Order
                        // Show the Credit Card order page
                        showCCOrderTintPage()
                    }
                    else if(reviewOrder!!.paymentGateway == PAYMENT_TYPE_BRING_CC){ // Bring CC Order
                        // Go to Payment Method page
                        showBringCCMachineInstruction()
                    }
                    else { // COD order
                        // Go to Checkout page
                        Navigators.goToPaymentTypeActivity(
                            this@HomeActivity,
                            reviewOrder!!.orderOutletId ?: 0
                        )
                    }
                }

            }
        }

    private val agreeCCOrderTintListener: CheckoutInstructionsDialogFragment.AgreeTermsListener =
        object : CheckoutInstructionsDialogFragment.AgreeTermsListener {
            override fun onAgreed() {
//                if (cardInstructionsDialog != null)
//                    cardInstructionsDialog!!.dismiss()

                if (reviewOrder != null) {
                    // Go to Checkout page
                    Navigators.goToPaymentTypeActivity(
                        this@HomeActivity,
                        reviewOrder!!.orderOutletId ?: 0
                    )
                }
            }
        }

    // Show the store instructions page
    private fun showStoreInstructionsPage() {
        if (reviewOrder != null) {
            if (reviewOrder!!.otpConfirmed == 1) {
                setOrderStatusToCheckout()
            }
            else{
                if (reviewOrder!!.storeInstruction.isNotEmpty()) {
                    // Go to Store Instructions page
                    try{
                        runOnUiThread {
                            checkoutInstructionsDialog =
                                CheckoutInstructionsDialogFragment.newInstance(reviewOrder!!.storeInstruction)
                            checkoutInstructionsDialog!!.show(
                                supportFragmentManager,
                                CheckoutInstructionsDialogFragment.javaClass.name
                            )
                            checkoutInstructionsDialog!!.listener = agreeStoreInstructionsListener
                        }
                    }
                    catch (e : Exception){
                        e.printStackTrace()
                    }
                }
                else{
                    when (reviewOrder!!.paymentGateway) {
                        PAYMENT_TYPE_CREDIT -> { // Credit Card order
                            // Go to CC order instructions page
                            showCCOrderTintPage()
                        }
                        PAYMENT_TYPE_BRING_CC -> { // Bring CC Machine
                            // Go to Payment Method page(Bring CC Machine)
                            showBringCCMachineInstruction()
                        }
                        else -> { // Cash of delivery
                            // Go to Checkout page
                            Navigators.goToPaymentTypeActivity(
                                this@HomeActivity,
                                reviewOrder!!.orderOutletId ?: 0
                            )
                        }
                    }
                }
            }
        }
    }

    fun openMakeComplain() {
//        submitTicket()
        startActivity(ComplainActivity.newIntent(this))

    }

    private fun submitTicket(){
        viewModel.getTicketTypeList( object :HandleResponse<ArrayList<TicketFieldsData>>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Toast.makeText(this@HomeActivity, error?.message, Toast.LENGTH_SHORT).show()
                }else{
                    Toast.makeText(this@HomeActivity, this@HomeActivity!!.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }
            }

            override fun handleSuccessResponse(successResponse: ArrayList<TicketFieldsData>) {
                val choices = extractTicketTypes(successResponse)
                AppConstants.ticketTypes = choices

                val ticketDialog = CreateTicketDialogFragment.newInstance(AppConstants.ticketTypes)
                ticketDialog.show(supportFragmentManager, CreateTicketDialogFragment.javaClass.name)
            }
        })
    }

    private fun extractTicketTypes(fields : ArrayList<TicketFieldsData>) : ArrayList<String>{

        val typeArray : ArrayList<String> = arrayListOf()

        for (typeField in fields) {
            if (typeField.name != null && typeField.name == AppConstants.TICKET_NAME_TYPE) {
                if (typeField.choices != null) {
                    val types : ArrayList<String> = arrayListOf()
                    val choiceJsonString = Gson().toJson(typeField.choices)
                    try {
                        val choices : List<String> = Gson().fromJson(choiceJsonString, types.javaClass)
                        if (choices != null) {
                            typeArray.addAll(choices)
                            break
                        }
                    }
                    catch (e : Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }

        return typeArray
    }
    /**
     * Update the order status
     */
    // Update the order status
    private fun setOrderStatusToCheckout(){
        viewModel.updateOrderStatus(
            STATUS_CHECKOUT,
            reviewOrder!!.orderOutletId!!,
            object : HandleResponse<SimpleResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (isNetworkConnected) {
                        Toast.makeText(this@HomeActivity, error?.message, Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@HomeActivity, R.string.no_internet_conn_msg_txt, Toast.LENGTH_SHORT).show()
                    }
                }

                override fun handleSuccessResponse(successResponse: SimpleResponse) {
                    val response = successResponse.response
                    if (response != null) {
                        if (response.httpCode == 200) {
                            // Send message
                            val message: String = AppConstants.MESSAGE_TYPE_CHECKING_OUT_ORDER + " " + PreferenceManager.currentShopperFirstName + " " + getString(R.string.check_out_your_order)
                            val systemMessageReq = SystemMessageReq(reviewOrder!!.orderOutletId!!.toString(), "text", message)

                            sendSystemMessage(systemMessageReq) {
                                val orderPrice = reviewOrder!!.orderedSubtotal.toDoubleOrNull() ?: 0.0

                                // Go to the Receipt Information page
                                Navigators.goToReceiptInfoActivity(this@HomeActivity, reviewOrder!!.orderOutletId!!, orderPrice)
                            }
                        }
                        else {
                            Toast.makeText(this@HomeActivity, response.message, Toast.LENGTH_SHORT).show()
                        }
                    }
                    else {
                        Toast.makeText(this@HomeActivity, R.string.error_update_status, Toast.LENGTH_SHORT).show()
                    }
                }
            })
    }

    fun sendSystemMessage(systemMessageReq: SystemMessageReq, onAfterSystemMessage: () -> Unit){
        viewModel.sendSystemMessage(systemMessageReq, object : HandleResponse<SystemMessage> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                onAfterSystemMessage()
            }

            override fun handleSuccessResponse(successResponse: SystemMessage) {
                onAfterSystemMessage()
            }
        })
    }

    // Dismiss the order complete dialog
    private fun dismissOrderCompleteDialog() {
        DialogOrderCompleted.dismissDialog()
    }

    // Set tool bar
    private fun setToolBar(toolbar: Toolbar) {
        initToolbar(
            "",
            true, toolbar,
            View.OnClickListener {
                run {
                    openDrawer()
                }
            }, true
        )
    }

    /**
     * Initialize the Support MenuBar
     */
    fun initSupportMenu() {
        try{
            val support = viewDataBinding!!.layoutToolBar.support
            supportMenuManager = SupportMenuManager(support)

            support.setOnClickListener {
                supportMenuManager.showSupportMenu()
            }
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    // Get toolbar
    fun getSupportToolbar(): Toolbar? {
        if (viewDataBinding != null){
            return viewDataBinding!!.layoutToolBar.toolbar
        }
        else{
            return null
        }
    }

    fun showSupportMenuItems(isShow: Boolean) {
        if (viewDataBinding != null){
            viewDataBinding!!.layoutToolBar.supportLayout.visibility =
                if (isShow) View.VISIBLE else View.GONE
        }
    }

    // Update the order count number
    fun updateOrderCount(count: Int) {
        viewDataBinding!!.layoutToolBar.tvOrderCounts.text =
            String.format(Locale("en"), "%d", count)
    }

    private fun initFreshChat(){
        // Initialization Config Options
        val config = FreshchatConfig(AppConstants.FRESH_CHAT_APP_ID, AppConstants.FRESH_CHAT_APP_KEY)
        config.domain = AppConstants.FRESH_CHAT_CONFIG_DOMAIN
        config.isCameraCaptureEnabled = true
        config.isGallerySelectionEnabled = true
        config.isResponseExpectationEnabled = true
        Freshchat.getInstance(applicationContext).init(config)

        // Set the user data
        val freshchatUser = Freshchat.getInstance(applicationContext).user
        freshchatUser.firstName = PreferenceManager.currentShopperFirstName
        freshchatUser.lastName  = PreferenceManager.currentShopperLastName
        freshchatUser.email     = PreferenceManager.currentShopperEmail

        // Mobile
        var countryCode = "+962"
        var mobile = PreferenceManager.currentShopperMobile ?: ""
        if (mobile.isNotEmpty()){
            val index = mobile.indexOf('+')
            if (index >= 0 && mobile.length > 4){
                countryCode = mobile.substring(index, index + 4)
                mobile = mobile.substring(index + 4)
            }
            freshchatUser.setPhone(countryCode, mobile)
        }

        // Call setUser so that the user information is synced with Freshchat's servers
        Freshchat.getInstance(applicationContext).user = freshchatUser

    }

    // Configuring the conversation in Zendesk
//    private fun initZendeskConfiguration() {
//
//        // Configuring the conversation
//        AppConstants.chatConfiguration = ChatConfiguration.builder()
//            .withAgentAvailabilityEnabled(false)
//            .build()
//
//        // Setting information for the chat session
//        val profileProvider = Chat.INSTANCE.providers()!!.profileProvider()
//        val chatProvider = Chat.INSTANCE.providers()!!.chatProvider()
//
//        val visitorInfo = VisitorInfo.builder()
//            .withName(PreferenceManager.currentShopperFirstName + " " + PreferenceManager.currentShopperLastName)
//            .withEmail(PreferenceManager.currentShopperEmail)
//            .withPhoneNumber(PreferenceManager.currentShopperMobile) // numeric string
//            .build()
//
//
//        profileProvider.setVisitorInfo(visitorInfo, null)
//        chatProvider.setDepartment(AppConstants.DEPARTMENT_NAME, null)
//
//        // Registering push token
//        ShopperApp.Instance.pushProvider = Chat.INSTANCE.providers()!!.pushNotificationsProvider()
//        ShopperApp.Instance.pushProvider!!.registerPushToken(PreferenceManager.fcmToken ?: "")
//
//        if (intent != null){
//            val notiType = intent.getStringExtra("NotificationType")
//            if (notiType != null && notiType.equals(FCMService.NOTIFICATION_TYPE_ZENDESK)) {
//                // Open the Contact us page
//                chatWithSupport()
//            }
//        }
//    }

    // Starting a chat using Zendesk
    fun chatWithSupport() {
//        MessagingActivity.builder()
//            .withEngines(ChatEngine.engine())
//            .show(this@HomeActivity, AppConstants.chatConfiguration)

        Freshchat.showConversations(applicationContext)
    }

    // Show the logout confirm dialog
    private fun showDialogLogout() {
        val dialog = Dialog(this, R.style.PauseDialog)
        val binding = DialogLogoutBinding.inflate(LayoutInflater.from(this))
        dialog.setContentView(binding.root)
        dialog.setCanceledOnTouchOutside(false)
        dialog.setCancelable(false)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        binding.btnLogout.setOnClickListener {
            dialog.dismiss()

            logout()
        }
        binding.btnCancel.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    // Logout
    private fun logout() {
        PreferenceManager.isLoggedIn = false
        PreferenceManager.logout()

        val intent = LoginActivity.newIntent(this@HomeActivity)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
        finish()
    }

    // Navigation Drawer items
    private fun populateMenu() {
        val headerList: ArrayList<MenuModel> = ArrayList<MenuModel>()
        val headerListChildSetting: ArrayList<MenuModel> = ArrayList<MenuModel>()
        val headerListChildAccount: ArrayList<MenuModel> = ArrayList<MenuModel>()

        headerListChildSetting.add(
            MenuModel(
                "nav_profile",
                getString(R.string.nav_profile),
                R.drawable.ic_menu_profile,
                null
            )
        )
        headerListChildSetting.add(
            MenuModel(
                "nav_language",
                getString(R.string.select_language),
                R.drawable.ic_menu_language,
                null
            )
        )

        headerListChildSetting.add(
            MenuModel(
                "nav_logout",
                getString(R.string.log_out_btn_txt),
                R.drawable.ic_menu_logout,
                null
            )
        )

        // Earnings
        headerListChildAccount.add(
            MenuModel(
                "nav_earning",
                getString(R.string.fab_earnings),
                R.drawable.ic_menu_earnings,
                null
            )
        )

        // Working Hours
        headerListChildAccount.add(
            MenuModel(
                "nav_hours",
                getString(R.string.hours),
                R.drawable.ic_menu_hours,
                null
            )
        )

        // Cash on Hand
        headerListChildAccount.add(
            MenuModel(
                "nav_cash_hand",
                getString(R.string.cash_on_hand),
                R.drawable.ic_menu_cash_hand,
                null
            )
        )


        // How am I Doing?
        headerListChildAccount.add(
            MenuModel(
                "nav_how_i_m_doing",
                getString(R.string.menu_how_i_am_doing),
                R.drawable.ic_menu_how_doing,
                null
            )
        )


        headerList.add(
            MenuModel(
                "nav_dashboard",
                getString(R.string.fab_dashboard),
                R.drawable.ic_menu_dashboard,
                null
            )
        )

        headerList.add(
            MenuModel(
                "nav_setting",
                getString(R.string.fab_setting),
                R.drawable.ic_settings,
                headerListChildSetting
            )
        )

        headerList.add(
            MenuModel(
                "nav_account",
                getString(R.string.fab_accoutn),
                R.drawable.ic_account,
                headerListChildAccount
            )
        )


        // Tutorial
        headerList.add(
            MenuModel(
                "nav_tutorial",
                getString(R.string.tutorial),
                R.drawable.ic_menu_tutorial,
                null
            )
        )
        headerList.add(
            MenuModel(
                "nav_status",
                getString(R.string.status),
                R.drawable.status,
                null
            )
        )

        // Notifications
//        headerList.add(
//            MenuModel(
//                "nav_notifications",
//                getString(R.string.fab_notifications),
//                R.drawable.ic_menu_notification,
//                null
//            )
//        )

        // Support (chat with Basket support)
//        headerList.add(MenuModel("nav_support", getString(R.string.support), R.drawable.ic_help, null))

        // Logout


        val expandableListAdapter = ExpandableListAdapter(this, headerList)
        viewDataBinding!!.expandableListView.setAdapter(expandableListAdapter)
        viewDataBinding!!.expandableListView.setOnGroupClickListener { _, v, groupPosition, id ->
            if (headerList[groupPosition].subMenu == null) {
                onListItemSelected(headerList[groupPosition])
            }

            false
        }

        viewDataBinding!!.expandableListView.setOnChildClickListener(OnChildClickListener { parent, v, groupPosition, childPosition, id ->
            onListItemSelected(headerList[groupPosition].subMenu!![childPosition])
            false
        })

        val version = java.lang.String.format(
            "%s  -  Version %s",
            BuildConfig.BUILD_TYPE.toUpperCase(),
            BuildConfig.VERSION_NAME
        )

        // Show the Version
        viewDataBinding!!.footerLayout.txtVersion.text = version

        // Notification Center
        viewDataBinding!!.headerLayout.notificationLayout.setOnClickListener {
            // Check if no internet
            if (!isNetworkConnected){
                Toast.makeText(this, getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_SHORT).show()
            }
            else
            {
                closeDrawer()
                startActivity(NotificationsActivity.newIntent(this))
            }
        }
    }

    // show the change language dialog
    private fun showChangeLanguage() {
        val dialog = Dialog(this, R.style.PauseDialog)
        val binding = DialogChangeLanguageBinding.inflate(LayoutInflater.from(this))

        var isSelectedEnglish = true
        if (PreferenceManager.currentUserLanguage == 2) {
            isSelectedEnglish = false
        }

        dialog.setContentView(binding.root)
        dialog.setCanceledOnTouchOutside(false)
        dialog.setCancelable(false)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        // update UI
        updateSelectedLanguage(binding, isSelectedEnglish)

        // English
        binding.enLayout.setOnClickListener {
            isSelectedEnglish = true
            updateSelectedLanguage(binding, isSelectedEnglish)
        }

        // Arabic
        binding.arLayout.setOnClickListener {
            isSelectedEnglish = false
            updateSelectedLanguage(binding, isSelectedEnglish)
        }

        binding.btnCancel.setOnClickListener {
            dialog.dismiss()
        }
        binding.btnChange.setOnClickListener {
            dialog.dismiss()

            changeLanguage(isSelectedEnglish)
        }

        dialog.show()
    }

    /**
     * Method to post the shopper location by socket
     */
    @SuppressLint("TimberArgCount")
    private fun postShopperLiveLocation(lat: Double, lng: Double, currLocation: Location){
        if (PreferenceManager.isLoggedIn && !PreferenceManager.shouldStopLocation) {
            try{
                if (this::socketManager.isInitialized){
                    if (socketManager.basketLocationService != null && socketManager.basketLocationService!!.connected()){
                        Timber.tag(TAG).d("Sending the shopper location using socket...")
                        val jsonObject = JSONObject()

                        try {
                            jsonObject.put("shopper_id", PreferenceManager.currentShopperId!!.toString())
                            jsonObject.put("lat", lat)
                            jsonObject.put("lon", lng)
                            jsonObject.put("speed", currLocation.speed)
                            jsonObject.put("accuracy", currLocation.accuracy)
                            jsonObject.put("direction", currLocation.bearing)
                            jsonObject.put("measured_at", currLocation.time)
                        }
                        catch (e: Exception) {
                            Timber.tag(TAG).e("Failed to send the shopper location due to exception...")
                            e.printStackTrace()
                        }

                        appendJsonDataToFile("log.txt",jsonObject)

                        // Emit object
                        socketManager.basketLocationService!!.emit(
                            SocketManager.SOCKET_EVENT_UPDATE_LOCATION,
                            jsonObject,
                            Ack {
                                val baseResponseType = object : TypeToken<BaseResponse>() {}.type
                                val response = Gson().fromJson<BaseResponse>(it.first() as String, baseResponseType)

                                val callbackMsg = String.format(Locale.ENGLISH, "*** shopper:send:current:location : %s ***", response.message ?: "")
                                Timber.tag(TAG).e(callbackMsg)
                            }
                        )
                    }
                    else{
                        Timber.tag(TAG).e("Location Socket is not connected to submit...")
                    }
                }else{
                    Timber.tag(TAG).e("===== Socket Manager is not initiated...")
                }
            }
            catch (e : Exception){
                e.printStackTrace()
            }
        }
        else{
            Timber.tag(TAG).e("User didn't log in yet...")
        }
    }
    private fun appendJsonDataToFile(fileName: String, jsonData: JSONObject) {
        try {
            if (isExternalStorageWritable()) {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val file = File(filesDir, fileName)
                Log.d(TAG, "createTextFile=== "+file.absolutePath.toString());
                file.parentFile?.mkdirs()

                val existingData = readJsonDataFromFile(fileName)
                existingData.add(jsonData)


                val fos = FileOutputStream(file)
                val osw = OutputStreamWriter(fos)
                osw.write(JSONArray(existingData).toString(2))
                osw.close()
                fos.close()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    private fun readJsonDataFromFile(fileName: String): MutableList<JSONObject> {
        val dataList = mutableListOf<JSONObject>()

        try {
            // Check if external storage is available
            if (isExternalStorageReadable()) {
                // Get the "Downloads" directory
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)

                // Create a file in the "Downloads" directory
                val file = File(filesDir, fileName)

                // Read existing data from the file
                val fis = FileInputStream(file)
                val isr = InputStreamReader(fis)
                val bufferedReader = BufferedReader(isr)
                val stringBuilder = StringBuilder()
                var line: String?

                while (bufferedReader.readLine().also { line = it } != null) {
                    stringBuilder.append(line)
                }

                bufferedReader.close()
                isr.close()
                fis.close()

                // Parse the JSON array from the file content
                val jsonArray = JSONArray(stringBuilder.toString())

                // Convert the JSON array to a list of JSON objects
                for (i in 0 until jsonArray.length()) {
                    dataList.add(jsonArray.getJSONObject(i))
                }
            } else {
                // External storage is not available
                // Handle the situation accordingly (e.g., show a message to the user)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            // Handle exceptions (e.g., file I/O errors)
        }

        return dataList
    }

    private fun isExternalStorageReadable(): Boolean {
        val state = Environment.getExternalStorageState()
        return Environment.MEDIA_MOUNTED == state || Environment.MEDIA_MOUNTED_READ_ONLY == state
    }

    private fun isExternalStorageWritable(): Boolean {
        val state = Environment.getExternalStorageState()
        return Environment.MEDIA_MOUNTED == state
    }

    // Update UI of change language dialog
    private fun updateSelectedLanguage(binding: DialogChangeLanguageBinding, isEnglish: Boolean) {
        if (isEnglish) {
            binding.btnEnglish.setTextColor(resources.getColor(R.color.colorPrimary))
            binding.btnEnglish.setCompoundDrawablesWithIntrinsicBounds(
                null,
                null,
                resources.getDrawable(R.drawable.ic_check),
                null
            )
            binding.btnArabic.setTextColor(resources.getColor(R.color.colorBlack))
            binding.btnArabic.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null)
        } else {
            binding.btnArabic.setTextColor(resources.getColor(R.color.colorPrimary))
            binding.btnArabic.setCompoundDrawablesWithIntrinsicBounds(
                null,
                null,
                resources.getDrawable(R.drawable.ic_check),
                null
            )

            binding.btnEnglish.setTextColor(resources.getColor(R.color.colorBlack))
            binding.btnEnglish.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null)
        }
    }

    // Change the language
    private fun changeLanguage(isEnglish: Boolean) {
        if (isEnglish) {
            PreferenceManager.currentUserLanguage = 1
        } else {
            PreferenceManager.currentUserLanguage = 2
        }

        restartApp()
    }

    // Open the handover dialog
    private fun openHandoverDialog() {
        try{
            val takeOrderManuallyDialogFragment = TakeOrderManuallyDialogFragment.newInstance()
            takeOrderManuallyDialogFragment.show(
                supportFragmentManager,
                TakeOrderManuallyDialogFragment.javaClass.name
            )
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    // Restart Application
    private fun restartApp() {
        try {
            val homeIntent = Intent(applicationContext, HomeActivity::class.java)
            homeIntent.addCategory(Intent.CATEGORY_HOME)
            homeIntent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(homeIntent)
            finish()
//            EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_RESTART))
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }

    override fun onSupportNavigateUp() =
        Navigation.findNavController(this, R.id.navHomeFragment).popBackStack()

    // Close the Side Menu
    private fun closeDrawer() {
        if (viewDataBinding!!.drawerLayout.isDrawerOpen(GravityCompat.START)) {
            viewDataBinding!!.drawerLayout.closeDrawer(GravityCompat.START)
        }
    }

    // Open the Side Menu
    private fun openDrawer() {
        if (!viewDataBinding!!.drawerLayout.isDrawerOpen(GravityCompat.START)) {
            viewDataBinding!!.drawerLayout.openDrawer(GravityCompat.START)
            hideKeyboard()
        }
    }

    override fun onBackPressed() {
        try{
            if (viewDataBinding!!.drawerLayout.isDrawerOpen(GravityCompat.START)) {
                viewDataBinding!!.drawerLayout.closeDrawer(GravityCompat.START)
            }
            else {
//                super.onBackPressed()
            }
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }


    override fun handleError(error: String) {
    }

    override fun handleSuccess(success: String) {
    }

    override fun gotToNext() {
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item.itemId) {
            R.id.btnAbout -> {

            }
            R.id.btnMessage -> {
                navController!!.navigate(R.id.chatMessagesFragment)
            }
        }
        return super.onOptionsItemSelected(item)
    }

    // Go to Hours
    fun gotoHours() {
//        navController!!.navigate(R.id.hoursFragment)
        startActivity(HoursActivity.newIntent(this))
    }

    private fun onListItemSelected(p0: MenuModel): Boolean {
        when (p0.menuId) {

            "nav_dashboard" -> {
                // Check if no internet
                if (!isNetworkConnected){
                    Toast.makeText(this, getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_SHORT).show()
                    return true
                }

                navController!!.navigate(R.id.dashboardFragment)
            }

//            "nav_current_orders" -> {
//                navController!!.navigate(R.id.currentOrderFragment)
//
//            }

            // Support (chat with support)
            "nav_support" -> {
                // Check if no internet
                if (!isNetworkConnected){
                    Toast.makeText(this, getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_SHORT).show()
                    return true
                }

                chatWithSupport()
            }

            // Hours
            "nav_hours" -> {
//                gotoHours()

                // Check if no internet
                if (!isNetworkConnected){
                    Toast.makeText(this, getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_SHORT).show()
                    return true
                }

                startActivity(HoursActivity.newIntent(this))
            }

            // Earning
            "nav_earning" -> {
                // Check if no internet
                if (!isNetworkConnected){
                    Toast.makeText(this, getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_SHORT).show()
                    return true
                }

                startActivity(EarningActivity.newIntent(this))
            }

            // Profile
            "nav_profile" -> {
                // Check if no internet
                if (!isNetworkConnected){
                    Toast.makeText(this, getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_SHORT).show()
                    return true
                }

                startActivity(ProfileActivity.newIntent(this))
            }

            // Notification
            "nav_notifications" -> {
                // Check if no internet
                if (!isNetworkConnected){
                    Toast.makeText(this, getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_SHORT).show()
                    return true
                }

                startActivity(NotificationsActivity.newIntent(this))
            }

//            "nav_about" -> {
//                startActivity(OrderListActivity.newIntent(this))
//            }

            // How am I doing
            "nav_how_i_m_doing" -> {
                // Check if no internet
                if (!isNetworkConnected){
                    Toast.makeText(this, getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_SHORT).show()
                    return true
                }

                startActivity(HowDoingActivity.newIntent(this))
            }

            // Logout
            "nav_logout" -> {
                showDialogLogout()
            }

            // Select Language
            "nav_language" -> {
                showChangeLanguage()
            }

            // Cash On Hand
            "nav_cash_hand" -> {
                showPocketCashDialog(true)
            }

            // Tutorial
            "nav_tutorial" -> {
                openYoutube()
            }
            // Tutorial
            "nav_status" -> {
              startActivity(StatusActivity.newIntent(this))
            }

            else -> {

            }
        }

        closeDrawer()

        return true
    }

    private fun openYoutube() {
        val webIntent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse(AppConstants.YOUTUBE_LINK)
        )
        try {
            startActivity(webIntent)
        } catch (ex: ActivityNotFoundException) {
            ex.printStackTrace()
        }
    }

    // Check if youtube is installed or not
    private fun isYouTubeAppInstalled(packageName: String): Boolean {
        val mIntent = packageManager.getLaunchIntentForPackage(packageName)
        return mIntent != null
    }

    // Show the pocket money dialog
    fun showPocketCashDialog(isCancel: Boolean) {
        if (DialogCashAmount.isOpened){
            return
        }

        // Open the new dialog
        DialogCashAmount.openDialog(this, isCancel) { cashAmount ->
            addCashAmount(cashAmount)
        }
    }

    // Add cash amount
    private fun addCashAmount(amount: String) {
        if (amount.isEmpty() || (amount.toDoubleOrNull() ?: 0.0) <= 0.0) {
            DialogCashAmount.setErrorMessage(getString(R.string.err_cash_amount))
            return
        }

        // Call api
        viewModel.storePocketMoney(
            amount.toDoubleOrNull() ?: 0.0,
            object : HandleResponse<SimpleResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (isNetworkConnected) {
                        Toast.makeText(this@HomeActivity, error?.message, Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(
                            this@HomeActivity,
                            resources?.getString(R.string.no_internet_conn_msg_txt),
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

                override fun handleSuccessResponse(successResponse: SimpleResponse) {
                    if (successResponse.response != null) {
                        if (successResponse.response.httpCode == 200) {
                            val cdate = Calendar.getInstance().time
                            val csdate: String = DateUtils.getDatetoString(cdate)
                            PreferenceManager.pocketMoney = csdate

                            // dismiss dialog
                            DialogCashAmount.dismissDialog()
                        } else {
                            Toast.makeText(
                                this@HomeActivity,
                                successResponse.response.message,
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } else {
                        Toast.makeText(
                            this@HomeActivity,
                            getString(R.string.error_server_return_null),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            })
    }

    /**
     * Location BroadcastReceiver
     */
    private inner class ForegroundOnlyBroadcastReceiver : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            location = intent.getParcelableExtra<Location>(
                ForegroundOnlyLocationService.EXTRA_LOCATION
            )

            if (location != null) {
                postShopperLiveLocation(location!!.latitude, location!!.longitude, location!!)
            }
            else{
                Timber.tag(TAG).e("Shopper location is null")
            }
        }
    }

    companion object {
        const val TAG = "HomeActivity"
        var handover: Boolean = false
        fun newIntent(context: Context?): Intent {
            return Intent(context, HomeActivity::class.java)
        }

        private var instance: HomeActivity? = null

        val Instance: HomeActivity
            get() {
                if (instance == null) {
                    instance = HomeActivity()
                }
                return instance!!
            }
    }
}


