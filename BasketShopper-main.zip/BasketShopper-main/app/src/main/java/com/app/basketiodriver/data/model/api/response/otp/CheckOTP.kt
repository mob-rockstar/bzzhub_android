package com.app.basketiodriver.data.model.api.response.otp

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class CheckOTP {
    @SerializedName("response")
    @Expose
    val response: ResponseOTP? = null
}