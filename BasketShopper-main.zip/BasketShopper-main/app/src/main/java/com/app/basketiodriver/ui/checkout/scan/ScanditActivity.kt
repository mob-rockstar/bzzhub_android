package com.app.basketiodriver.ui.checkout.scan

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.app.basketiodriver.BuildConfig
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.ActivityScanditBinding
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.checkout.card.CheckoutCardViewModel
import com.app.basketiodriver.ui.order.product.ScanItem
import com.app.basketiodriver.utils.AppConstants
import com.tbruyelle.rxpermissions2.RxPermissions

/**
 * Scan the receipt barcode
 */
class ScanditActivity : BaseActivity<ActivityScanditBinding, CheckoutCardViewModel>()
//    ,OnScanListener
{
    override val layoutId: Int
        get() = R.layout.activity_scandit

    override val viewModel: CheckoutCardViewModel
        get() {
            return getViewModel(CheckoutCardViewModel::class.java)
        }

    var autoFocus : Boolean = true

//    var picker : BarcodePicker? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize the Toolbar
        initToolbar(getString(R.string.scan),
            true, viewDataBinding!!.layoutToolBar.toolbar,
            View.OnClickListener {
                run {
                    finish()
                }
            })


        // Setup views
        initViews()
    }

    private fun initViews(){

//        if (BuildConfig.BUILD_TYPE.equals("release", true)) {
//            if (isCarrifourMall(AppConstants.outletId)){
//                viewDataBinding!!.btnUnableScan.visibility = View.GONE
//            }
//            else{
//                viewDataBinding!!.btnUnableScan.visibility = View.VISIBLE
//            }
//        }

        // Unable Scan
        viewDataBinding!!.btnUnableScan.setOnClickListener {
//            if (picker != null)
//                picker!!.stopScanning()

            val intent = Intent()
            intent.putExtra("UnableScan", 1)
            setResult(Activity.RESULT_CANCELED, intent)
            finish()
        }

        // Setup barcode reader
//        initBarcodeReader()
    }

    // Initialize the Barcode Reader
//    private fun initBarcodeReader(){
//        ScanditLicense.setAppKey(ScanItem.SCANDIT_APP_KEY)
//        val settings : ScanSettings = ScanSettings.create()
//
//        for (sym in Barcode.ALL_SYMBOLOGIES) {
//            settings.setSymbologyEnabled(sym, true)
////            settings.isRestrictedAreaScanningEnabled = true
////            settings.isForce2dRecognitionEnabled = true
////            settings.scanningHotSpotHeight = 0.05f
//        }
//
//        picker = BarcodePicker(this, settings)
//        picker!!.setOnScanListener(this)
//
//        viewDataBinding!!.relativeCamera.addView(
//            picker, FrameLayout.LayoutParams(
//                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
//            )
//        )
//
//        // Start the scanning
//        picker!!.startScanning();
//    }

    private fun isCarrifourMall(outletId: Long): Boolean {

        val malls = ArrayList<Long>()
        malls.add(139L)
        malls.add(138L)
        malls.add(137L)
        malls.add(105L)
        malls.add(82L)
        malls.add(78L)
        malls.add(77L)
        malls.add(76L)
        malls.add(75L)
        malls.add(68L)
        malls.add(67L)

        return malls.contains(outletId)
    }

    // Check if permission is granted
//    @SuppressLint("MissingPermission", "CheckResult")
//    private fun grantCameraPermission(){
//        val permissions = RxPermissions(this)
//        permissions.request(Manifest.permission.CAMERA)
//            .subscribe { granted: Boolean ->
//                if (granted) {
//                    if (picker != null) {
//                        picker!!.startScanning()
//                    }
//                }
//            }
//    }

    /**
     * OnScanListener
     */
//    override fun didScan(scanSession: ScanSession?) {
//        if (scanSession != null && scanSession.newlyRecognizedCodes.size > 0) {
//            val barcode = scanSession.newlyRecognizedCodes[0].data
//
//            runOnUiThread {
//                if (picker != null) {
//                    picker!!.stopScanning()
//                }
//
//                val intent = Intent()
//                intent.putExtra("ScanResult", barcode)
//                setResult(Activity.RESULT_OK, intent)
//                finish()
//            }
//        }
//    }

    override fun onResume() {
        super.onResume()

//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
//            grantCameraPermission()
//        }
//        else{
//            if (picker != null){
//                picker!!.resumeScanning()
//            }
//        }
    }

    override fun onPause() {
//        if (picker != null)
//            picker!!.stopScanning()

        super.onPause()
    }
}