package com.app.basketiodriver.ui.dialogs

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.fragment.app.FragmentManager
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.terms.AgreeTermAndConditionResponse
import com.app.basketiodriver.data.model.api.response.terms.TermsAndConditionResponse
import com.app.basketiodriver.data.remote.APIManager
import com.app.basketiodriver.databinding.FragmentTermsConditionDialogBinding
import com.app.basketiodriver.ui.base.BaseDialogFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.app.basketiodriver.ui.home.HomeViewModel
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class TermsAndConditionDialogFragment : BaseDialogFragment<FragmentTermsConditionDialogBinding, HomeViewModel>() {

    override val layoutId: Int
        get() = R.layout.fragment_terms_condition_dialog

    override val viewModel: HomeViewModel
        get() {
            return getViewModel(baseActivity, HomeViewModel::class.java)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    // Set Full screen
    override fun getTheme(): Int {
        return R.style.MyDialogWhite
    }

    var listener : CheckoutInstructionsDialogFragment.AgreeTermsListener? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initToolbar(getString(R.string.terms_conditions_tit_txt))

        // Agree
        viewDataBinding!!.btnAgree.setOnClickListener {
            agreeTermsConditions()
        }

        // Get the terms & condition data
        getTermsConditions()
    }

    override fun show(manager: FragmentManager, tag: String?) {
        try {
            val ft = manager.beginTransaction()
            ft.add(this, tag)
            ft.commitAllowingStateLoss()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun initToolbar(title : String){
        viewDataBinding!!.layoutToolBar.toolBarTitle.text = title

        // Hide the back button
        viewDataBinding!!.layoutToolBar.btnBack.visibility = View.INVISIBLE
        viewDataBinding!!.layoutToolBar.btnBack.setOnClickListener {
            // no action
        }
    }

    @SuppressLint("CheckResult")
    private fun getTermsConditions(){
//        viewDataBinding!!.progress.visibility = View.VISIBLE

        viewModel.getTermsConditions(object : HandleResponse<TermsAndConditionResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
//                viewDataBinding!!.progress.visibility = View.GONE

                Toast.makeText(activity, error?.message, Toast.LENGTH_SHORT).show()
            }

            override fun handleSuccessResponse(successResponse: TermsAndConditionResponse) {
//                viewDataBinding!!.progress.visibility = View.GONE

                if (successResponse.status == 200){
                    initToolbar(successResponse.data!!.title ?: baseActivity.resources?.getString(R.string.terms_conditions_tit_txt)!!)
                    viewDataBinding!!.termsAndCondition.text = successResponse.data!!.description
                }
                else{
                    Toast.makeText(baseActivity, successResponse.message, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    // Shopper agreed Terms & Conditions
    private fun agreeTermsConditions(){
//        viewDataBinding!!.progress.visibility = View.VISIBLE

        viewModel.agreeTermsAndConditions(object : HandleResponse<AgreeTermAndConditionResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                viewDataBinding!!.progress.visibility = View.GONE

                Toast.makeText(baseActivity, error?.message, Toast.LENGTH_SHORT).show()
            }

            override fun handleSuccessResponse(successResponse: AgreeTermAndConditionResponse) {
//                viewDataBinding!!.progress.visibility = View.GONE

                if (successResponse.status == 200){
                    // Dismiss this page
                    if (isAdded)
                        dismissAllowingStateLoss()

                    if (listener != null)
                        listener!!.onAgreed()
                }
                else{
                    Toast.makeText(baseActivity, successResponse.message, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    companion object{

        fun newInstance() : TermsAndConditionDialogFragment {
            val fragment = TermsAndConditionDialogFragment()

            return fragment
        }
    }
}