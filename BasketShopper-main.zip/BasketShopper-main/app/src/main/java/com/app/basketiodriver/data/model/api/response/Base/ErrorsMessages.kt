package com.app.basketiodriver.data.model.api.response.Base

import android.annotation.SuppressLint
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import java.util.*

@SuppressLint("ParcelCreator")
class ErrorsMessages {
    @SerializedName("first_name")
    @Expose
    var first_name: ArrayList<String>? = null

    @SerializedName("last_name")
    @Expose
    var last_name: ArrayList<String>? = null

    @SerializedName("name")
    @Expose
    var name: ArrayList<String>? = null

    @SerializedName("email")
    @Expose
    var email: ArrayList<String>? = null

    @SerializedName("mobile")
    @Expose
    var mobile: ArrayList<String>? = null
    @SerializedName("password")
    @Expose
    var password: ArrayList<String>? = null

    @SerializedName("country_code")
    @Expose
    var country_code: ArrayList<String>? = null


}