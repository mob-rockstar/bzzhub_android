package com.app.basketiodriver.di.builder

import com.app.basketiodriver.ui.dialogs.CreateTicketDialogFragment
import com.app.basketiodriver.ui.earning.fragments.*
import dagger.Module
import dagger.android.ContributesAndroidInjector


/**
Created by ibraheem lubbad on 2020-02-16.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/

@Module
abstract class FragmentEarningModule {
    @ContributesAndroidInjector
    abstract fun contributeBatchFragment(): BatchFragment

    @ContributesAndroidInjector
    abstract fun contributeDayEarningFragment(): DayEarningFragment

    @ContributesAndroidInjector
    abstract fun contributeWeekEarningFragment(): WeekEarningFragment

    @ContributesAndroidInjector
    abstract fun contributeSummaryFragment(): SummaryFragment

    @ContributesAndroidInjector
    abstract fun contributeMonthlyEarningFragment(): MonthlyEarningFragment

    @ContributesAndroidInjector
    abstract fun contributeMonthlyEarningDetailFragment(): MonthlyEarningDetailFragment

    @ContributesAndroidInjector
    abstract fun contributeEarningsCreditFragment(): EarningsCreditFragment

    @ContributesAndroidInjector
    abstract fun contributeBonusDeductionsFragment(): BonusDeductionsFragment

    @ContributesAndroidInjector
    abstract fun contributeEarningsOrderDetailFragment(): EarningsOrderDetailFragment

    @ContributesAndroidInjector
    abstract fun contributeCreateTicketDialogFragment(): CreateTicketDialogFragment

}
