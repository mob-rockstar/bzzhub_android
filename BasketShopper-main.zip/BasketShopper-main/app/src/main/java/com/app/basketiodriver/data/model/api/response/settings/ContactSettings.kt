package com.app.basketiodriver.data.model.api.response.settings

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class ContactSettings {
    @SerializedName("customer_care")
    @Expose
    val customerCare: String = ""

    @SerializedName("shopper_care")
    @Expose
    val shopperCare: String = ""

    @SerializedName("support_mail")
    @Expose
    val supportMail: String = ""

    @SerializedName("contact_mail")
    @Expose
    val contactMail: String = ""
}