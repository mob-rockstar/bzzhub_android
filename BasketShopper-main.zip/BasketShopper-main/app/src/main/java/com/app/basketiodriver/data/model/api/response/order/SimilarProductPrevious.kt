package com.app.basketiodriver.data.model.api.response.order

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName
import java.io.Serializable


class SimilarProductPrevious : Serializable{
    @SerializedName("outlet_id")
    @Expose
    val outletId: Long? = null

    @SerializedName("outlet_item_id")
    @Expose
    val outletItemId: Int? = null

    @SerializedName("product_name")
    @Expose
    val productName: String? = null

    @SerializedName("shopper_tips")
    @Expose
    val shopperTips: String? = null

    @SerializedName("department_name")
    @Expose
    val departmentName: String? = null

    @SerializedName("aisle_name")
    @Expose
    val aisleName: String? = null

    @SerializedName("sold_per")
    @Expose
    val soldPer: Int? = null

    @SerializedName("sold_per_label")
    @Expose
    val soldPerLabel: String? = null

    @SerializedName("label_value")
    @Expose
    val labelValue: String? = null

    @SerializedName("size_label")
    @Expose
    val sizeLabel: Int? = null

    @SerializedName("approx_weight")
    @Expose
    val approxWeight: Double? = null

    @SerializedName("each_suffix")
    @Expose
    val eachSuffix: Int? = null

    @SerializedName("our_selling_price")
    @Expose
    val ourSellingPrice: Double? = null

    @SerializedName("unit")
    @Expose
    val unit: String = ""

    @SerializedName("product_image")
    @Expose
    val productImage: String? = null

    @SerializedName("product_info_image")
    @Expose
    val productInfoImage: String? = null

    @SerializedName("upc")
    @Expose
    val barCode: String = ""

    @SerializedName("upc_type")
    @Expose
    val upcType = 0
}