package com.app.basketiodriver.ui.order.adapter

import android.graphics.PorterDuff
import android.os.Build
import android.text.Html
import android.text.Spanned
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.PopupMenu
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.order.Product
import com.app.basketiodriver.databinding.ItemListOrderDetailBinding
import com.app.basketiodriver.utils.BaseRecyclerViewAdapter
import com.app.basketiodriver.utils.GlideApp
import com.app.basketiodriver.utils.price.PriceConstructor
//import kotlinx.android.synthetic.main.item_product.view.*
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.*


class ProductListAdapter (val activity : FragmentActivity, val listItems : List<Product>, val userMobile : String, val orderId : Long, val isClickable : Boolean, private val isThreeDots : Boolean)
    : BaseRecyclerViewAdapter<Product, ItemListOrderDetailBinding>(){
    var symbols: DecimalFormatSymbols = DecimalFormatSymbols(Locale.US)
    var formatter: DecimalFormat = DecimalFormat(" #.## x ", symbols)
    var formatter1: DecimalFormat = DecimalFormat("#.## x ", symbols)

    override val layoutId: Int
        get() = R.layout.item_list_order_detail

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return ProductViewHolder(createBindView(parent))
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val holder = holder as ProductViewHolder
        val item = listItems[position]

        val price = PriceConstructor.getFormatPrice(
            item,
            PriceConstructor.LabelType.SIMPLE,
            PreferenceManager.currency,
            true
        )

        setOriginalView(holder, item)

//        if (item.quantityDifference == 1)
//            holder.binding.frameLayout2.order_item_title.text = String.format(Locale("en"), "%s%s", formatter.format(item.itemShoppedQty), item.itemProductName)
//
//        else if (item.replacementRequested == 1)
//            if (item.itemStatus == 2) {
//                holder.binding.frameLayout2.order_item_title.text = item.itemProductName
//            } else {
//                holder.binding.frameLayout2.order_item_title.text = String.format(Locale("en"), "%s%s", formatter.format(item.itemShoppedQty), item.itemProductName)
//
//        } else
//            holder.binding.frameLayout2.order_item_title.text = String.format(Locale("en"), "%s%s", formatter.format(item.itemShoppedQty), item.itemProductName)
//
//
//        holder.binding.frameLayout2.order_cost.text = getHtmlString(price)

        if (item.getDescriptionLabel().isEmpty()) {
            holder.binding.layoutNewProduct.tvPriceDescription.visibility = View.GONE
        } else {
            holder.binding.layoutNewProduct.tvPriceDescription.visibility = View.VISIBLE
            holder.binding.layoutNewProduct.tvPriceDescription.text = item.getDescriptionLabel()
        }

        if (item.itemProductImage != null) {
            GlideApp.with(activity).load(item.itemProductImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(holder.binding.layoutNewProduct.orderItemImage)
        }

        val status: Int = setItemStatusLabel(holder, item)

        if (isClickable) {
//            holder.binding.frameLayout2.order_item_layout.setOnClickListener {
//            }
        }

        if (!isThreeDots){
//            holder.binding.frameLayout2.three_dot.visibility = View.INVISIBLE
        }

        if (orderId != 0L){
            initThreeDotIfNeed(holder, position, status)
        }
    }

    private fun setOriginalView(holder : ProductViewHolder, item : Product) {
        if (item.replacementRequested != null && item.replacementRequested == 1){
            holder.binding.originalProduct.visibility = View.VISIBLE

            // product image
            if (item.repItemProductImage != null) {
                GlideApp.with(activity).load(item.repItemProductImage).fitCenter()
                    .placeholder(R.drawable.placeholder)
                    .error(R.drawable.placeholder).into(holder.binding.ivOriginalProductImg)
            }

            // Quantity, Product name
            val replaceQty = if (item.repItemOrderedQty == null && item.repItemOrderedQty == "") "0" else item.repItemOrderedQty
            holder.binding.tOriginalProductName.text = formatter1.format(replaceQty) + item.repItemProductName

            // Price
            val price = PriceConstructor.getFormatPrice(item, PriceConstructor.LabelType.SIMPLE, PreferenceManager.currency, false)
            holder.binding.tvOriginalPrice.text = getHtmlString(price)

            // Product Description
            if (item.getDescriptionLabel().isEmpty()){
                holder.binding.tvOriginalPriceDescription.visibility = View.GONE
            }
            else{
                holder.binding.tvOriginalPriceDescription.text = item.getDescriptionLabel()
                holder.binding.tvOriginalPriceDescription.visibility = View.VISIBLE
            }
        }
        else{
            holder.binding.originalProduct.visibility = View.GONE
        }
    }

    private fun setItemStatusLabel(holder : ProductViewHolder, item : Product) : Int{
        holder.binding.layoutNewProduct.orderItemImage.alpha = 1f
        if (item.itemStatus == 1) {
            holder.binding.itemStatus.visibility = View.GONE
//            holder.binding.borderView.visibility = View.GONE

            return 1
        }
        else if (item.itemStatus == 2){
            holder.binding.itemStatus.visibility = View.VISIBLE
//            holder.binding.borderView.visibility = View.VISIBLE

            if (item.replacementRequested != null && item.replacementRequested == 1){
                holder.binding.itemStatus.text = activity.getString(R.string.replaced)
                holder.binding.itemStatus.background.setColorFilter(activity.resources.getColor(R.color.colorItemReplaced), PorterDuff.Mode.SRC_IN)
                return 5
            }

            if (item.quantityDifference == 1){
                holder.binding.itemStatus.text = getHtmlString("<font>" + activity.getString(R.string.qty_diff) + formatter.format(item.itemOrderedQty ?: 0))
                holder.binding.itemStatus.background.setColorFilter(activity.resources.getColor(R.color.colorItemDifferent), PorterDuff.Mode.SRC_IN)
                return 3
            }

            holder.binding.itemStatus.setText(R.string.not_found)
            holder.binding.itemStatus.background.setColorFilter(activity.resources.getColor(R.color.colorItemNotFound), PorterDuff.Mode.SRC_IN)
            return 2
        }
        else{
            holder.binding.itemStatus.visibility = View.VISIBLE
//            holder.binding.borderView.visibility = View.VISIBLE

            if (item.returnItem != null && item.returnItem == 1){
                holder.binding.itemStatus.setText(R.string.refund)
                holder.binding.itemStatus.background.setColorFilter(activity.resources.getColor(R.color.colorItemRefund), PorterDuff.Mode.SRC_IN)
                holder.binding.layoutNewProduct.orderItemImage.alpha = 0.5f

                return 9
            }
            else if (item.replacementRequested != null && item.replacementRequested == 1){
                holder.binding.itemStatus.setText(R.string.replaced)
                holder.binding.itemStatus.background.setColorFilter(activity.resources.getColor(R.color.colorItemReplaced), PorterDuff.Mode.SRC_IN)

                return 9
            }
            else if (item.quantityDifference == 1) {
                holder.binding.itemStatus.text = getHtmlString("<font>" + activity.getString(R.string.qty_diff) + formatter.format(item.itemOrderedQty ?: 0))
                holder.binding.itemStatus.background.setColorFilter(activity.resources.getColor(R.color.colorItemDifferent), PorterDuff.Mode.SRC_IN)

                return 9
            }
            else {
                holder.binding.itemStatus.visibility = View.INVISIBLE

                return 9
            }
        }
    }

    // Init more popup menu
    private fun initThreeDotIfNeed(holder : ProductViewHolder, position: Int, status : Int){
        val menuId = getMenuId(status)
        if (menuId > 0) {
            initPopupMenu(holder, position, menuId)

//            holder.binding.frameLayout2.three_dot.visibility = View.GONE
//            holder.binding.frameLayout2.three_dot.setOnClickListener {
//                holder.popupMenu?.show()
//            }
        }
        else{
//            val params : ViewGroup.LayoutParams = holder.binding.frameLayout2.three_dot.layoutParams
//            params.width = 1
//            holder.binding.frameLayout2.three_dot.layoutParams = params
//            holder.binding.frameLayout2.three_dot.visibility = View.GONE
        }
    }

    private fun initPopupMenu(holder : ProductViewHolder, position: Int, menuType : Int){
        val ordersItem = listItems[position]
//        holder.popupMenu = PopupMenu(activity, holder.binding.frameLayout2.three_dot)

        val inflater = holder.popupMenu!!.menuInflater
        inflater.inflate(menuType, holder.popupMenu!!.menu)
        holder.popupMenu!!.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.item_menu_replace -> onClickReplace(ordersItem)
                R.id.item_menu_refund -> onClickRefund(ordersItem)
                R.id.item_menu_confirm -> onClickConfirm(ordersItem)
                R.id.item_menu_put_back -> onClickPutBack(ordersItem)
                R.id.item_menu_replace_to_original -> onClickReplaceToOriginal(ordersItem)
//                R.id.item_menu_flag -> onClickFlagItem(ordersItem)
            }
            false
        }
    }

    private fun onClickReplace(ordersItem: Product){
        // Show the ReplaceMenuDialog
        /////////////////////////////
    }

    private fun onClickRefund(ordersItem: Product){

    }

    private fun onClickConfirm(ordersItem: Product){
        confirmChangedQty(ordersItem.ordersOutletsItemsId ?: 0)
    }

    private fun onClickPutBack(ordersItem: Product){
        if (ordersItem.returnItem != null && ordersItem.returnItem == 1){
            cancelRefund(ordersItem.ordersOutletsItemsId ?: 0)
            return
        }

        if (ordersItem.replacementFullfilled != null && ordersItem.replacementFullfilled == 1){
            cancelReplaced(ordersItem.ordersOutletsItemsId ?: 0)
            return
        }

        if (ordersItem.quantityDifferenceApproved != null && ordersItem.quantityDifferenceApproved == 1){
            cancelQtyDiff(ordersItem.ordersOutletsItemsId ?: 0)
            return
        }

        markAsNotFound(ordersItem.ordersOutletsItemsId ?: 0)
    }

    private fun onClickReplaceToOriginal(ordersItem: Product){
        cancelReplaced(ordersItem.ordersOutletsItemsId ?: 0)
    }

    // Mark as not found
    private fun markAsNotFound(itemId: Long){
        // Call api
        ///////////////////////
        ///////////////////////
    }

    // Confirm Qty Difference
    private fun confirmChangedQty(itemId : Long){

    }

    // Cancel ReplaceItem
    private fun cancelReplaced(itemId : Long){

    }

    // Cancel Quantity Difference
    private fun cancelQtyDiff(itemId : Long){

    }

    // Cancel ReplaceItem
    private fun cancelRefund(itemId : Long){
        // Call api
        ///////////////
        ///////////////
    }

    private fun getMenuId(status : Int) : Int {
        return when (status) {
            2 -> {
                R.menu.item_not_found_menu
            }
            3 -> {
                R.menu.item_qty_diff
            }
            5 -> {
                R.menu.item_replaced
            }
            9 -> {
                R.menu.item_refund
            }
            else -> {
                0
            }
        }
    }

    private fun getHtmlString(str : String) : Spanned {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            // FROM_HTML_MODE_LEGACY is the behaviour that was used for versions below android N
            // we are using this flag to give a consistent behaviour
            return Html.fromHtml(str, Html.FROM_HTML_MODE_LEGACY)
        } else {
            return Html.fromHtml(str)
        }
    }

    override fun getItemCount(): Int {
        return listItems.size
    }

    inner class ProductViewHolder(val binding: ItemListOrderDetailBinding) :
        RecyclerView.ViewHolder(binding.root){
        var popupMenu : PopupMenu? = null
    }
}