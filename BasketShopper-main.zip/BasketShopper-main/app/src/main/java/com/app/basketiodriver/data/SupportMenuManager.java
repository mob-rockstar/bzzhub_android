package com.app.basketiodriver.data;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.view.menu.MenuBuilder;
import androidx.appcompat.view.menu.MenuPopupHelper;
import androidx.appcompat.widget.PopupMenu;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.app.basketiodriver.R;
import com.app.basketiodriver.ShopperApp;
import com.app.basketiodriver.data.local.prefs.PreferenceManager;
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsActivity;
import com.app.basketiodriver.ui.dashbaord.map.LocationMapActivity;
import com.app.basketiodriver.ui.home.HomeActivity;
import com.app.basketiodriver.ui.order.ArrivedToCustomerActivity;
import com.app.basketiodriver.ui.order.review.OrderReviewActivity;
import com.app.basketiodriver.utils.AppConstants;
import com.freshchat.consumer.sdk.Freshchat;
import com.tbruyelle.rxpermissions2.RxPermissions;

import io.reactivex.android.schedulers.AndroidSchedulers;
import timber.log.Timber;
import zendesk.chat.ChatEngine;
import zendesk.messaging.MessagingActivity;

public class SupportMenuManager {

    private MenuPopupHelper menuHelper = null;
    private PopupMenu popupMenu = null;
    private String consumerNumber;

    @SuppressLint("RestrictedApi")
    public SupportMenuManager(View view) {
        try{
            final Activity activity = (Activity) view.getContext();
            final String supportNumber = PreferenceManager.INSTANCE.getSupportNumber();

            Timber.tag("SupportMenuManager").e("Support Phone Number:");
            Timber.tag("SupportMenuManager").d(supportNumber);

            popupMenu = new PopupMenu(activity, view);
            popupMenu.inflate(R.menu.support_menu);
            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    switch (item.getItemId()) {
                        case R.id.support_call:
                            String number = String.format("tel:%s", supportNumber);
                            startCallWithSupport(activity, number);
                            break;

                        case R.id.enable_user_call:
                            enableCallCustomer(activity);
                            return true;

                        case R.id.disable_user_call:
                            disabledCallCustomer(activity);
                            return true;

                        case R.id.enable_button_call:
                            enableButtonCall(activity);
                            return true;
                        case R.id.support_chat:
//                            openZendeskChat(activity);
                            chatWithSupport(activity);
                            return true;

                        case R.id.make_complain:
                            if (activity instanceof HomeActivity) {
                                ((HomeActivity) activity).openMakeComplain();
                            }
                            return true;

                        case R.id.customer_chat:
                            if (activity instanceof OrderDetailsActivity) {
                                ((OrderDetailsActivity) activity).openChatActivity();
                            } else if (activity instanceof ArrivedToCustomerActivity)
                                ((ArrivedToCustomerActivity) activity).openChatActivity();
                            else if (activity instanceof LocationMapActivity)
                                ((LocationMapActivity) activity).openChatActivity();
                            else if (activity instanceof OrderReviewActivity)
                                ((OrderReviewActivity) activity).openChatActivity();
                            else if (activity instanceof LocationMapActivity)
                                ((LocationMapActivity) activity).openChatActivity();
                            break;
                    }
                    return true;
                }
            });
            menuHelper = new MenuPopupHelper(activity, (MenuBuilder) popupMenu.getMenu(), view);
            menuHelper.setGravity(Gravity.NO_GRAVITY);
//        if (PreferenceManager.INSTANCE.getCurrentUserLanguage() == 1)
            menuHelper.setForceShowIcon(true);
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    // Chat with support
    private void chatWithSupport(Activity activity){
        Freshchat.showConversations(activity.getApplicationContext());
    }

    private void openZendeskChat(Activity activity){
        if (AppConstants.INSTANCE.getChatConfiguration() != null){
            MessagingActivity.builder()
                    .withEngines(ChatEngine.engine())
                    .show(activity, AppConstants.INSTANCE.getChatConfiguration());
        }
        else{
            MessagingActivity.builder()
                    .withEngines(ChatEngine.engine())
                    .show(activity);
        }

    }

    private void enableCallCustomer(Activity activity) {
        new AlertDialog.Builder(activity).setMessage(activity.getString(R.string.customer_number) + " " + consumerNumber)
                .setPositiveButton(R.string.call, (dialog, which) -> {
                    String number;
                    if (consumerNumber != null) {
                        number = String.format("tel:%s", consumerNumber);
                        startCallWithSupport(activity, number);
                    }
                })
                .setNegativeButton(R.string.screen_over_lay_cancel_btn_txt, (dialog, which) -> {
                }).create().show();
    }

    private void disabledCallCustomer(Activity activity) {
        new AlertDialog.Builder(activity).setMessage(activity.getString(R.string.msg_no_call_customer))
                .setNegativeButton(R.string.screen_over_lay_cancel_btn_txt, (dialog, which) -> {
                }).create().show();
    }


    private void enableButtonCall(Activity activity) {
        new AlertDialog.Builder(activity).setMessage(activity.getString(R.string.customer_number) + " " + consumerNumber)
                .setPositiveButton(R.string.call, (dialog, which) -> {
                    String number;
                    if (consumerNumber != null) {
                        number = String.format("tel:%s", consumerNumber);
                        startCallWithSupport(activity, number);
                    }
                })
                .setNegativeButton(R.string.screen_over_lay_cancel_btn_txt, (dialog, which) -> {
                }).create().show();
    }

    // Start the phone call with support
    @SuppressLint("CheckResult")
    private void startCallWithSupport(Activity activity, String number){

        try{
            RxPermissions rxPermissions = new RxPermissions((FragmentActivity) activity);
            rxPermissions
                    .request(Manifest.permission.CALL_PHONE)
                    .subscribe(granted -> {
                        if (granted) {
                            activity.startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(number)));
                        }
                        else { // Permission is denied
                            Toast.makeText(activity, activity.getString(R.string.error_no_call_permission), Toast.LENGTH_SHORT).show();
                        }
                    });
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    @SuppressLint("RestrictedApi")
    public void showSupportMenu() {
        menuHelper.tryShow();
    }

    public void initConsumerNumber(int callCustomerStatus, boolean enableCall, String consumerNumber, boolean chat, boolean number) {
        try{
            this.consumerNumber = consumerNumber;
            if (callCustomerStatus == 1) {
                MenuItem item = popupMenu.getMenu().findItem(R.id.enable_user_call);
                item.setVisible(number);
                MenuItem item2 = popupMenu.getMenu().findItem(R.id.customer_chat);
                item2.setVisible(chat);

            } else if ((callCustomerStatus == 0) && enableCall) {
                MenuItem itemUser = popupMenu.getMenu().findItem(R.id.enable_user_call);
                itemUser.setVisible(number);

            } else {
                MenuItem item = popupMenu.getMenu().findItem(R.id.disable_user_call);
                item.setVisible(true);
            }

            // chat with customer option
            MenuItem chatItem = popupMenu.getMenu().findItem(R.id.customer_chat);
            chatItem.setVisible(chat);
        }
        catch (Exception e){
            e.printStackTrace();
        }

    }

}
