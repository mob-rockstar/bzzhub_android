package com.app.basketiodriver.ui.dialogs

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.Window
import androidx.databinding.DataBindingUtil
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.checkout.CustomerInfo
import com.app.basketiodriver.data.model.api.response.checkout.OutletOrder
import com.app.basketiodriver.databinding.DialogCustomerInfoBinding
import com.app.basketiodriver.databinding.DialogOrderInfoBinding
import com.app.basketiodriver.utils.GlideApp
import com.app.basketiodriver.utils.PopupUtils
import java.util.*

class DialogOrderInfo {
    var dialog: Dialog? = null

    fun openDialog(context: Context, order : OutletOrder) {
        dialog = Dialog(context)

        val binding: DialogOrderInfoBinding = DataBindingUtil.inflate(
            LayoutInflater.from(context),
            R.layout.dialog_order_info,
            null,
            false
        )

        dialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog?.setContentView(binding.root)
        dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog?.window?.setGravity(Gravity.CENTER)

        // User Avatar
        GlideApp.with(context).load(order.userImage).fitCenter()
            .placeholder(R.drawable.ic_avatar)
            .error(R.drawable.ic_avatar).into(binding.ivUser)

        // User Name
        binding.tvUserName.text = order.userFirstName

        // User Address
        binding.tvUserAddress.text = String.format(Locale.ENGLISH, "%s, %s", order.userLocation, order.userGoogleAddress)

        // BID
        binding.tvBatchId.text = String.format(Locale.ENGLISH, "%s", order.outletId)

        // Order Id
        binding.tvOrderId.text = String.format(Locale.ENGLISH, "%s", order.orderId)

        // Item count
        binding.tvItemCount.text = String.format(Locale.ENGLISH, "%d", order.totalItemsCount)

        // Total price
        val totalPrice = (order.itemTotalAmount ?: "0.0").toDouble()
        binding.tvTotalPrice.text = String.format(
            Locale("en"),
            "%.2f",
            totalPrice
        )

        // Customer Phone Number
        binding.tvUserPhone.text = order.userMobile

        // Ok button
        binding.btnOk.setOnClickListener {
            dialog?.dismiss()
        }

        // show the dialog
        PopupUtils.setDefaultDialogProperty(dialog!!)
        dialog?.show()
    }

    fun dismissDialog(){
        if (dialog != null) dialog!!.dismiss()
    }

    companion object {
        private var instance: DialogOrderInfo? = null
        private val Instance: DialogOrderInfo
            get() {
                if (instance == null) {
                    instance = DialogOrderInfo()
                }
                return instance!!
            }

        fun openDialog(context: Context, order : OutletOrder) {
            Instance.openDialog(context, order)
        }

        fun dismissDialog(){
            Instance.dismissDialog()
        }
    }
}