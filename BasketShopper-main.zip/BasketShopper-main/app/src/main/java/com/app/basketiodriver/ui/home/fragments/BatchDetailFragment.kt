package com.app.basketiodriver.ui.home.fragments

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentBatchDetailBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.home.HomeViewModel
//import com.app.basketiodriver.ui.home.fragments.full0rder.OrderStatusDoneFragment
//import com.app.basketiodriver.ui.home.fragments.full0rder.OrderStatusInreviewFragment
//import com.app.basketiodriver.ui.home.fragments.full0rder.OrderToDoFragment
import com.app.basketiodriver.ui.utils.ViewPagerAdapter

/**
 * A simple [Fragment] subclass.
 * Use the [BatchDetailFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class BatchDetailFragment : BaseFragment<FragmentBatchDetailBinding?, HomeViewModel>(),
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_batch_detail

    override val viewModel: HomeViewModel
        get() {
            return getViewModel(requireActivity(), HomeViewModel::class.java)
        }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle("SHIRRLEY's  Order")

        val viewPagerAdapter = ViewPagerAdapter(childFragmentManager)
        //Order Type tabs
//        viewPagerAdapter.setFragments(
//            OrderToDoFragment(),
//            OrderStatusInreviewFragment(),
//            OrderStatusDoneFragment()
//        )

        viewPagerAdapter.setTitles(
            "5 To-Do",
            "In Review",
            "Done"

        )

        viewDataBinding!!.viewPager.adapter = viewPagerAdapter
        viewDataBinding!!.tabLayout.setupWithViewPager(viewDataBinding!!.viewPager)
    }

}
