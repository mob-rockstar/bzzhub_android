package com.app.basketiodriver.di.builder

import com.app.basketiodriver.ui.weekhours.fragments.*
import dagger.Module
import dagger.android.ContributesAndroidInjector

/**
 * Created by ibraheem lubbad on 2020-02-12.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 */
@Module
abstract class FragmentHoursScheduleModule {
    @ContributesAndroidInjector
    abstract fun contributeCancelWorkingHoursFragment(): CancelWorkingHoursFragment

    @ContributesAndroidInjector
    abstract fun contributeChooseWorkingHoursFragment(): ChooseWorkingHoursFragment

    @ContributesAndroidInjector
    abstract fun contributeEndHoursEarlyFragment(): EndHoursEarlyFragment

    @ContributesAndroidInjector
    abstract fun contributePastHoursFragment(): PastHoursFragment

    @ContributesAndroidInjector
    abstract fun contributeTodayRatesFragment(): TodayRatesFragment


}
