package com.app.basketiodriver.ui.earning.adapters

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseExpandableListAdapter
import androidx.databinding.DataBindingUtil
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.earning.YearEarningsData
import com.app.basketiodriver.data.model.api.response.earning.YearlyBalanceReportItem
import com.app.basketiodriver.databinding.ItemYearEarningsChildBinding
import com.app.basketiodriver.databinding.ItemYearEarningsGroupBinding
import com.app.basketiodriver.utils.CommonUtils
//import kotlinx.android.synthetic.main.item_year_earnings_child.view.*
import java.util.*
import kotlin.collections.ArrayList

class YearEarningsExpandableListAdapter(private val context: Context, private val listItems: ArrayList<YearEarningsData>) :
    BaseExpandableListAdapter(){

    override fun getChild(groupPosition: Int, childPosition: Int): YearlyBalanceReportItem {
        val childItems : ArrayList<YearlyBalanceReportItem> = listItems[groupPosition].items
        return childItems[childPosition]
    }

    override fun getChildId(groupPosition: Int, childPosition: Int): Long {
        return childPosition.toLong()
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    override fun getChildView(groupPosition: Int, childPosition: Int, isLastChild: Boolean, convertView: View?, parent: ViewGroup): View {

        val v = if (convertView == null) {
            DataBindingUtil.inflate(
                context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
                , R.layout.item_year_earnings_child, parent, false
            )
        } else {
            convertView.tag as ItemYearEarningsChildBinding
        }

        v.root.tag = v

        val item = getChild(groupPosition, childPosition)

        // Month Name
        v.tvMonth.text = item.monthName

        // Amount
        val amount = PreferenceManager.currency + " " + item.monthBalance
        v.tvAmount.text = amount
        CommonUtils.setBalanceTextColor(v.tvAmount, "" + item.monthBalance)

        // Set the background
        if (childPosition == getChildrenCount(groupPosition) - 1) {
            v.lvChild.background = context.getDrawable(R.drawable.bg_round_bottom_corners)
        }
        else{
            v.lvChild.background = context.getDrawable(R.drawable.bg_rectangle_white)
        }

        return v.root
    }

    override fun getChildrenCount(groupPosition: Int): Int {
        return listItems[groupPosition].items.size
    }

    override fun getGroup(groupPosition: Int): YearEarningsData {
        return listItems[groupPosition]
    }

    override fun getGroupCount(): Int {
        return listItems.size
    }

    override fun getGroupId(groupPosition: Int): Long {
        return groupPosition.toLong()
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    override fun getGroupView(groupPosition: Int, isExpanded: Boolean, convertView: View?, parent: ViewGroup): View {

        val v = if (convertView == null) {
            DataBindingUtil.inflate(
                context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
                , R.layout.item_year_earnings_group, parent, false
            )

        } else {
            convertView.tag as ItemYearEarningsGroupBinding
        }

        v.root.tag = v
        v.tvYear.text = String.format(Locale("en"), "%s %s", context.getString(R.string.year), getGroup(groupPosition).year)
        if (isExpanded){
            v.ivDropdown.setImageResource(R.drawable.ic_arrow_up)
            v.lvHeader.background = context.getDrawable(R.drawable.bg_round_top_corners)
        }
        else{
            v.ivDropdown.setImageResource(R.drawable.ic_arrow_down)
            v.lvHeader.background = context.getDrawable(R.drawable.bg_pickup_hours)
        }

        return v.root
    }

    override fun isChildSelectable(groupPosition: Int, childPosition: Int): Boolean {
        return true
    }

    override fun hasStableIds(): Boolean {
        return false
    }

    override fun areAllItemsEnabled(): Boolean {
        return true
    }
}