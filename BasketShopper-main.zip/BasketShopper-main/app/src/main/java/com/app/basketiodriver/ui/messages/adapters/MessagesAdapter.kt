package com.app.basketiodriver.ui.messages.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.NonNull
import androidx.recyclerview.widget.RecyclerView
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.ChatMessage

/**
 * Created by ibraheem lubbad on 5/10/20.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 */
class MessagesAdapter internal constructor(
    data: List<ChatMessage>,
    private val mItemAction: ItemAction
) :
    RecyclerView.Adapter<RecyclerView.ViewHolder?>() {
    //  var data: List<ChatMessage> = data
    var data: List<ChatMessage> = data
    override fun getItemViewType(position: Int): Int {
        val chatDataModel: ChatMessage = data[position]
        return if (chatDataModel.sender == 2 && chatDataModel.messageTextType == 1) {
            VIEW_MESSAGE_OUTGOING
        } else if (chatDataModel.sender == 1 && chatDataModel.messageTextType == 1) {
            VIEW_MESSAGE_INCOMING
        } else {
            VIEW_MESSAGE_ABNORMAL
        }
    }


    interface ItemAction {
        fun clickOnItem()
    }


    @NonNull
    override fun onCreateViewHolder(
        @NonNull viewGroup: ViewGroup,
        viewType: Int
    ): RecyclerView.ViewHolder {
        when (viewType) {
            VIEW_MESSAGE_INCOMING -> return MessageInHolder(
                LayoutInflater.from(viewGroup.context).inflate(
                    R.layout.item_message_incoming,
                    viewGroup,
                    false
                )
            )
            VIEW_MESSAGE_OUTGOING -> return MessageOutGoingHolder(
                LayoutInflater.from(viewGroup.context).inflate(
                    R.layout.item_message_outgoing,
                    viewGroup,
                    false
                )
            )
            VIEW_MESSAGE_ABNORMAL -> return MessageAbnormalHolder(
                LayoutInflater.from(viewGroup.context).inflate(
                    R.layout.item_chat_abnormal,
                    viewGroup,
                    false
                )
            )
            else -> return MessageInHolder(
                LayoutInflater.from(viewGroup.context).inflate(
                    R.layout.item_chat_incoming,
                    viewGroup,
                    false
                )
            )
        }

    }


    override fun onBindViewHolder(@NonNull viewHolder: RecyclerView.ViewHolder, pos: Int) {
        val baseHolder = viewHolder as BaseHolder
        baseHolder.bindView(data[pos])
        mItemAction.let {
            it.clickOnItem()
        }
    }

    override fun getItemCount(): Int {
        return data.size
    }

    internal abstract class BaseHolder(@NonNull itemView: View) :
        RecyclerView.ViewHolder(itemView) {
        var txtMessage: TextView? = null
        abstract fun bindView(chatDataModel: ChatMessage)
    }

    internal class MessageInHolder(@NonNull itemView: View) :
        BaseHolder(itemView) {
        override fun bindView(chatDataModel: ChatMessage) {
            val message: String = chatDataModel.content!!
            //txtMessage.setText(URLDecoder.decode(message, "UTF-8"));
            //  txtMessage!!.text = message
        }

        init {
            txtMessage = itemView.findViewById(R.id.txtMessage)
        }
    }

    internal class MessageOutGoingHolder(@NonNull itemView: View) :
        BaseHolder(itemView) {
        override fun bindView(chatDataModel: ChatMessage) {
            try {
                val message: String = chatDataModel.content!!
                //txtMessage.setText(URLDecoder.decode(message, "UTF-8"));
                txtMessage!!.text = message
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        init {
            txtMessage = itemView.findViewById(R.id.txtMessage)
        }
    }

    internal class MessageAbnormalHolder(@NonNull itemView: View) : BaseHolder(itemView) {
        var imgMessageType: ImageView
        override fun bindView(chatDataModel: ChatMessage) {
            txtMessage!!.text = chatDataModel.content
            when (chatDataModel.messageTextType) {
                MESSAGE_TYPE_SHOPPING_STARTED, MESSAGE_TYPE_CHEK_IN_OUT_ORDER -> imgMessageType.setImageDrawable(
                    imgMessageType.context
                        .resources.getDrawable(R.drawable.ic_chat_notification)
                )
                MESSAGE_TYPE_ITEM_REPLACED -> imgMessageType.setImageDrawable(
                    imgMessageType.context
                        .resources.getDrawable(R.drawable.ic_chat_replace)
                )
                MESSAGE_TYPE_ITEM_REFUNDED -> imgMessageType.setImageDrawable(
                    imgMessageType.context
                        .resources.getDrawable(R.drawable.ic_chat_refund)
                )
                MESSAGE_TYPE_SHOPING_FINISH -> imgMessageType.setImageDrawable(
                    imgMessageType.context
                        .resources.getDrawable(R.drawable.ic_chat_exit)
                )
                MESSAGE_TYPE_DELIVERY_STARTED -> imgMessageType.setImageDrawable(
                    imgMessageType.context
                        .resources.getDrawable(R.drawable.ic_chat_deliver)
                )
                MESSAGE_TYPE_DELIVERED -> imgMessageType.setImageDrawable(
                    imgMessageType.context
                        .resources.getDrawable(R.drawable.swipe_drawable)
                )
                MESSAGE_TYPE_APPROVED -> imgMessageType.setImageDrawable(
                    imgMessageType.context
                        .resources.getDrawable(R.drawable.ic_chat_done)
                )
            }
        }

        init {
            txtMessage = itemView.findViewById(R.id.txtMessage)
            imgMessageType = itemView.findViewById(R.id.img_message_type)
        }
    }

    companion object {
        private const val VIEW_MESSAGE_INCOMING = 1
        private const val VIEW_MESSAGE_OUTGOING = 2
        private const val VIEW_MESSAGE_ABNORMAL = 3
        private const val VIEW_MESSAGE_UNKNOWN = 4
        private const val MESSAGE_TYPE_SHOPPING_STARTED = 2
        private const val MESSAGE_TYPE_ITEM_REPLACED = 3
        private const val MESSAGE_TYPE_ITEM_REFUNDED = 4
        private const val MESSAGE_TYPE_SHOPING_FINISH = 5
        private const val MESSAGE_TYPE_CHEK_IN_OUT_ORDER = 6
        private const val MESSAGE_TYPE_DELIVERY_STARTED = 7
        private const val MESSAGE_TYPE_DELIVERED = 8
        private const val MESSAGE_TYPE_APPROVED = 9
    }

}