package com.app.basketiodriver.ui.onboarding.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.Trace
//import kotlinx.android.synthetic.main.item_review_stage.view.*
import java.util.*

class TraceAdapter(
    context: Context?,
    traceList: List<Trace>
) : RecyclerView.Adapter<RecyclerView.ViewHolder?>() {
    private val inflater: LayoutInflater
    private var traceList: List<Trace> = ArrayList<Trace>(1)


    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val itemHolder =
            holder as ViewHolder

        itemHolder.bindHolder(traceList[position])

        if (position == itemCount - 1) {
            itemHolder.tvLine.visibility = View.GONE
        } else {
            itemHolder.tvLine.visibility = View.VISIBLE
        }
    }


    override fun getItemViewType(position: Int): Int {
        return if (position == 0) {
            TYPE_TOP
        } else TYPE_NORMAL
    }

    inner class ViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {
        val tvTitle: TextView
        val tvLine: TextView
        val tvDot: ImageView
        fun bindHolder(trace: Trace) {
            tvTitle.text = trace.title
            tvLine.text = trace.acceptStation
        }

        init {
            tvTitle = itemView.findViewById<View>(R.id.tvTitle) as TextView
            tvLine = itemView.findViewById<View>(R.id.tvLine) as TextView
            tvDot = itemView.findViewById<View>(R.id.tvDot) as ImageView
        }
    }

    companion object {
        private const val TYPE_TOP = 0x0000
        private const val TYPE_NORMAL = 0x0001
    }

    init {
        inflater = LayoutInflater.from(context)
        this.traceList = traceList
    }


    override fun getItemCount(): Int {
        return traceList.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return ViewHolder(
            inflater.inflate(
                R.layout.item_review_stage,
                parent,
                false
            )
        )
    }
}