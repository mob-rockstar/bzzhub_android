package com.app.basketiodriver.ui.dialogs

import android.os.Bundle
import android.view.View
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentCardInstructionsDialogBinding
import com.app.basketiodriver.databinding.FragmentCheckoutInstructionsDialogBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseDialogFragment
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel

class CardInstructionsDialogFragment : BaseDialogFragment<FragmentCardInstructionsDialogBinding?, OrderDetailsViewModel>(),
    Injectable {

    var listener : CheckoutInstructionsDialogFragment.AgreeTermsListener? = null

    override val layoutId: Int
        get() = R.layout.fragment_card_instructions_dialog

    override val viewModel: OrderDetailsViewModel
        get() {
            return getViewModel(baseActivity, OrderDetailsViewModel::class.java)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    // Set Full screen
    override fun getTheme(): Int {
        return R.style.MyDialogWhite
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initToolbar()

        viewDataBinding!!.btnAgree.setOnClickListener {
            dismiss()

            if (listener != null){
                listener!!.onAgreed()
            }
        }
    }

    private fun initToolbar(){
        viewDataBinding!!.layoutToolBar.toolBarTitle.setText(R.string.payment_method)
        viewDataBinding!!.layoutToolBar.btnBack.setOnClickListener {
            dismiss()
        }
    }

    companion object{

        fun newInstance() : CardInstructionsDialogFragment {
            val fragment = CardInstructionsDialogFragment()

            return fragment
        }
    }
}