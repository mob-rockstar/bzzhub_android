package com.app.basketiodriver.ui.ShareDialog.Utils;

/**
 * Created by ogiba on 27.03.2017.
 */

public enum DisplayType {
    HORIZONTAL,
    LIST,
    DEFAULT
}
