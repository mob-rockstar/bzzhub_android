package com.app.basketiodriver.data.model.api.response.earning.monthly

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parceler
import kotlinx.android.parcel.Parcelize

@Parcelize
class ShopperDetailsReportData : Parcelable {
    /**
     * total_balance : 0
     * total_shopping_earning : 27.85
     * total_delivered_items : 468
     * total_delivery_earning : 42.94
     * total_travel_distance : 146.32
     * total_bonus : 0
     * total_deduction : 0
     * total_earnings : 0
     * total_collected : 75.56
     * report_view : [{"day_name":"Fri, Feb 15","day_balance":0},{"day_name":"Sat, Feb 16","day_balance":0},{"day_name":"Sun, Feb 17","day_balance":0},{"day_name":"Mon, Feb 18","day_balance":0},{"day_name":"Tue, Feb 19","day_balance":0},{"day_name":"Wed, Feb 20","day_balance":0},{"day_name":"Thu, Feb 21","day_balance":0}]
     * total_extra_amount_with_shopper : JOD 4.77
     * contact_support_text : If you have any billing issues, please contact shopper support line
     * current_account_balance : 0
     * is_account_suspended : false
     */
    @SerializedName("total_balance")
    val total_balance: String = "0.00"

    @SerializedName("total_shopping_earning")
    val total_shopping_earning: String = "0.00"

    @SerializedName("total_delivered_items")
    val total_delivered_items: String = "0.00"

    @SerializedName("total_delivery_earning")
    val total_delivery_earning: String = "0.00"

    @SerializedName("total_travel_distance")
    val total_travel_distance: String = "0.00"

    @SerializedName("total_bonus")
    val total_bonus: String = "0.00"

    @SerializedName("total_deduction")
    val total_deduction: String = "0.00"

    @SerializedName("total_earnings")
    val total_earnings: String = "0.00"

    @SerializedName("total_collected")
    val total_collected : String = "0.00"

    @SerializedName("total_extra_amount_with_shopper")
    val total_extra_amount_with_shopper: String = "0.00"

    @SerializedName("contact_support_text")
    val contact_support_text: String = ""

    @SerializedName("current_account_balance")
    val current_account_balance: String = "0.00"

    @SerializedName("is_account_suspended")
    val is_account_suspended : Boolean = false

    @SerializedName("report_view")
    val report_view: ArrayList<ReportView> = arrayListOf()
}