package com.app.basketiodriver.data.model.api.response

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class LoginResponse {
    @SerializedName("httpCode")
    @Expose
    val httpCode: Int? = null

    @SerializedName("Message")
    @Expose
    var message: String? = null

    @SerializedName("shopper_id")
    @Expose
    val shopperId: Long? = null

    @SerializedName("token")
    @Expose
    val token: String? = null

    @SerializedName("email")
    @Expose
    val email: String? = null

    @SerializedName("mobile")
    @Expose
    val mobile: String? = null

    @SerializedName("first_name")
    @Expose
    val firstName: String = ""

    @SerializedName("last_name")
    @Expose
    val lastName: String = ""

    @SerializedName("mobile_verified")
    @Expose
    val mobileVerified: Int = 0

    @SerializedName("application_status")
    @Expose
    val applicationStatus: Int = 0

    /**
     * 0 = Not uploaded = You will redirect to Upload document screen
     * 1 = In Review = Same here you will move to In Review Screen which omar give you
     * 2 = Approved = Ok fine
     * 3 = Rejected = Not allow to move forward
     */
    @SerializedName("training_status")
    @Expose
    val trainingStatus: Int = 0

    // Currency
    @SerializedName("currency_symbol")
    @Expose
    val currencySymbol: String = "JD"

}