package com.app.basketiodriver.mvvm.ui.login

import com.app.basketiodriver.ui.base.BaseNavigator


/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
interface LoginNavigator : BaseNavigator