package com.app.basketiodriver.ui.order.adapter

import android.text.Html
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.order.SimilarProduct
import com.app.basketiodriver.databinding.ItemSimilarProductBinding
import com.app.basketiodriver.ui.order.product.SearchForSimilarActivity
import com.app.basketiodriver.utils.BaseRecyclerViewAdapter
import com.app.basketiodriver.utils.GlideApp
import com.app.basketiodriver.utils.price.PriceConstructor
import com.app.basketiodriver.utils.price.PriceConstructorNew

class SimilarProductListAdapter(val activity : FragmentActivity, val listItems : List<SimilarProduct>, val listener : SimilarProductItemClickListener?, val isReplace : Int = 0) : BaseRecyclerViewAdapter<SimilarProduct, ItemSimilarProductBinding>() {

    override val layoutId: Int
        get() = R.layout.item_similar_product

    override fun getItemCount(): Int {
        return listItems.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return SimilarProductViewHolder(createBindView(parent))
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val holder = holder as SimilarProductViewHolder
        val item = listItems[position]

        // Hide the quantity field
        holder.binding.orderItemQuantity.visibility = View.GONE

        holder.binding.orderItemTitle.text = (item.productName ?: "") + " " + item.departmentName ?: ""
//        holder.binding.orderItemDesc.text = item.departmentName ?: ""
        holder.binding.orderCost.text = Html.fromHtml(PriceConstructorNew.getFormatPrice(item, PriceConstructor.LabelType.SIMPLE))

        if (item.productImage != null){
            GlideApp.with(activity).load(item.productImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(holder.binding.orderItemImage)
        }

        if (item.getDescriptionLabel().isEmpty()){
            holder.binding.tvPriceDescription.visibility = View.GONE
        }
        else{
            holder.binding.tvPriceDescription.visibility = View.VISIBLE
            holder.binding.tvPriceDescription.text = item.getDescriptionLabel()
        }

        // Item ClickListener
        if (isReplace != 1) {
            holder.binding.checkbox.visibility = View.GONE
            holder.binding.orderItemLayout.setOnClickListener {
                listener?.onClickSimilarProduct(item)
            }
        }
        else{
            holder.binding.checkbox.visibility = View.VISIBLE

            // Checkbox ClickListener
            holder.binding.checkbox.setOnCheckedChangeListener { buttonView, isChecked ->
                val parentActivity = activity as SearchForSimilarActivity
                if (isChecked) {
                    parentActivity.selectedItemsForReplace.add(item)
                }
                else{
                    if (parentActivity.selectedItemsForReplace.contains(item)) {
                        parentActivity.selectedItemsForReplace.remove(item)
                    }
                }
            }
        }
    }

    inner class SimilarProductViewHolder(val binding: ItemSimilarProductBinding) :
        RecyclerView.ViewHolder(binding.root)

    interface SimilarProductItemClickListener {
        fun onClickSimilarProduct(item : SimilarProduct)
    }
}