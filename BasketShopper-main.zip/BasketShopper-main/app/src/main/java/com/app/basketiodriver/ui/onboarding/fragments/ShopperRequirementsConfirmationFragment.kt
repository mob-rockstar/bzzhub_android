package com.app.basketiodriver.ui.onboarding.fragments


import android.os.Bundle
import android.view.View
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentShopperRequirementsConfirmationBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.onboarding.OnBoardingViewModel


/**
 * Created by ibraheem lubbad on 2020-01-22.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class ShopperRequirementsConfirmationFragment :
    BaseFragment<FragmentShopperRequirementsConfirmationBinding?, OnBoardingViewModel>(),
    Injectable, View.OnClickListener {


    override val layoutId: Int
        get() = R.layout.fragment_shopper_requirements_confirmation

    override val viewModel: OnBoardingViewModel
        get() {
            return getViewModel(requireActivity(), OnBoardingViewModel::class.java)
        }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.shopper_requirements))


        viewDataBinding!!.btnMeet.setOnClickListener(this)
        viewDataBinding!!.btnNotMeet.setOnClickListener(this)

    }

    fun onMeetAction() {

        navigate(
            ShopperRequirementsConfirmationFragmentDirections
                .actionShopperRequirementsConfirmationFragmentToFragmentCarConfirmation()
        )


    }

    fun onNotMeetAction() {

        showAlertMessages(
            getString(R.string.shopper_requirements),
            getString(R.string.meet_requirements_message)
        )

    }

    override fun onClick(p0: View?) {
        when (p0!!.id) {
            R.id.btnMeet -> {
                onMeetAction()
            }

            R.id.btnNotMeet -> {
                onNotMeetAction()
            }
        }
    }


}
