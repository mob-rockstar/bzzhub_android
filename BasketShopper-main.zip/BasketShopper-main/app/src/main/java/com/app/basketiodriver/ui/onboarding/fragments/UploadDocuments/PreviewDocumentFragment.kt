package com.app.basketiodriver.ui.onboarding.fragments.UploadDocuments


import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.DocumentsResponse
import com.app.basketiodriver.data.model.api.response.ShopperDocumentsResponse
import com.app.basketiodriver.databinding.FragmentDocumentPreviewBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.cardcamera.camera.IDCardCamera
import com.app.basketiodriver.ui.onboarding.OnBoardingViewModel
import com.app.basketiodriver.ui.onboarding.adapters.UploadedFilesAdapter
import com.app.basketiodriver.utils.AppLogger
import com.app.basketiodriver.utils.OnItemClickedListener
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import java.io.File


/**
 * Created by ibraheem lubbad on 2020-01-22.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/


class PreviewDocumentFragment :
    BaseFragment<FragmentDocumentPreviewBinding?, OnBoardingViewModel>(),
    Injectable, View.OnClickListener ,OnItemClickedListener<DocumentsResponse.OnbaordingDocumentEntity>{

    override val layoutId: Int
        get() = R.layout.fragment_document_preview

    override val viewModel: OnBoardingViewModel
        get() {
            return getViewModel(requireActivity(), OnBoardingViewModel::class.java)
        }

    var selectedEntity = 0


    lateinit var adapter: UploadedFilesAdapter;

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.preview))

        viewDataBinding!!.btnUpload.setOnClickListener(this)


        viewDataBinding!!.rvItems.setHasFixedSize(true)
        viewDataBinding!!.rvItems.layoutManager =LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false)

        adapter = UploadedFilesAdapter(this);

        adapter.replace(viewModel.currentOnbaordingDocument!!.documentEntities)

        viewDataBinding!!.rvItems.adapter = adapter


    }

    override fun onClick(p0: View?) {
        when (p0!!.id) {
            R.id.btnUpload -> {

                val builder = MultipartBody.Builder()
                builder.setType(MultipartBody.FORM)
                viewModel.currentOnbaordingDocument!!.documentEntities?.forEachIndexed { index, entity ->
                    run {

                        builder.addFormDataPart("items[$index][document_entity_id]", "1")
                        builder.addFormDataPart(
                            "items[$index][file]", entity.file_type,
                            RequestBody.create(
                                "image/*".toMediaTypeOrNull(),
                                File(entity.fileLocalPath)
                            )
                        )
                    }
                }
                val requestBody = builder.build()

                viewModel.storeShopperDocuments(
                    requestBody,
                    object : HandleResponse<ShopperDocumentsResponse> {
                        override fun handleErrorResponse(error: ErrorResponse?) {
                            AppLogger.d("handleErrorResponse  ${error}")

                        }

                        override fun handleSuccessResponse(successResponse: ShopperDocumentsResponse) {
                            popNavigate(R.id.reviewProgressFragment)

                        /*    navigate(
                               PreviewDocumentFragmentDirections.actionFragmentDocumentPreviewToReviewApplicationFragment()
                           )*/
                        }


                    });
            }
        }


    }



    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {


        if (resultCode == IDCardCamera.RESULT_CODE) {
            val path = IDCardCamera.getImagePath(data)



            viewModel.currentOnbaordingDocument!!.documentEntities!!.map {

                if (it.id==selectedEntity){
                    it.fileLocalPath=path;
                }
            }
            adapter.notifyDataSetChanged()



        }
    }

    override fun onClicked(item: DocumentsResponse.OnbaordingDocumentEntity) {
        selectedEntity = item.id


        IDCardCamera.create(this).openCamera(IDCardCamera.TYPE_IDCARD_BACK)
    }

}
