package com.app.basketiodriver.data.model.api.response.howamidoing

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class ReliabilityIncident {
    @SerializedName("incident")
    @Expose
    var incident = 0

    @SerializedName("incident_text")
    @Expose
    var incident_text: String = ""
}