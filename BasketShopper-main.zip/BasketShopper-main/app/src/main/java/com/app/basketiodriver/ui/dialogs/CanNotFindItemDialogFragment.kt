package com.app.basketiodriver.ui.dialogs

import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.fragment.app.FragmentManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.checkout.CustomerInfo
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.model.api.response.order.CommonResponse
import com.app.basketiodriver.data.model.api.response.order.ItemNotFoundReason
import com.app.basketiodriver.data.model.api.response.order.SimilarProduct
import com.app.basketiodriver.data.model.api.response.order.SuggestionResponse
import com.app.basketiodriver.databinding.FragmentCanNotFindItemDialogBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.di.Navigators
import com.app.basketiodriver.ui.base.BaseDialogFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.app.basketiodriver.ui.order.adapter.NoItemFoundReasonAdapter
import com.app.basketiodriver.utils.AppConstants.FROM_TODO
import com.google.gson.Gson

class CanNotFindItemDialogFragment : BaseDialogFragment<FragmentCanNotFindItemDialogBinding?, OrderDetailsViewModel>(),
    Injectable {

    var orderId : Long = 0L
    var item : OrdersItem? = null
    var info : CustomerInfo? = null

    var replaceLimit : Int = 1

    private var itemNotFoundReasons : ArrayList<ItemNotFoundReason> = arrayListOf()
    lateinit var listAdapter : NoItemFoundReasonAdapter

    // Selected reason
    var selectedReason : ItemNotFoundReason? = null

    override val layoutId: Int
        get() = R.layout.fragment_can_not_find_item_dialog

    override val viewModel: OrderDetailsViewModel
        get() {
            return getViewModel(baseActivity, OrderDetailsViewModel::class.java)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    // Set Full screen
    override fun getTheme(): Int {
        return R.style.LocationDialogStyle
    }

    override fun onStart() {
        super.onStart()

        try {
            dialog!!.window!!.setLayout(
                RelativeLayout.LayoutParams.MATCH_PARENT,
                RelativeLayout.LayoutParams.MATCH_PARENT
            )
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initToolbar()

        viewDataBinding?.recyclerView?.layoutManager = LinearLayoutManager(activity)
        viewDataBinding?.recyclerView?.setHasFixedSize(true)

        // Close
        viewDataBinding!!.ivClose.setOnClickListener {
            dismissAllowingStateLoss()
        }

        // Next
        viewDataBinding!!.tvNext.setOnClickListener {
            if (selectedReason != null)
                setReason(selectedReason!!)
        }

        /**
         * get params
         */
        arguments?.let {
            orderId = it.getLong(KEY_ORDER_ID)
            item = it.getSerializable(KEY_ORDER_ITEM) as? OrdersItem
            info = it.getSerializable(KEY_CUSTOMER_INFO) as? CustomerInfo
            replaceLimit = it.getInt(KEY_REPLACEMENT_LIMIT)

            getReasons()
        }
    }

    override fun show(manager: FragmentManager, tag: String?) {
        try {
            val ft = manager.beginTransaction()
            ft.add(this, tag)
            ft.commitAllowingStateLoss()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun initToolbar(){
//        viewDataBinding?.layoutToolBar?.toolBarTitle?.text = getString(R.string.can_not_find_item)
//        viewDataBinding?.layoutToolBar?.btnBack?.setOnClickListener {
//            dismiss()
//        }
    }

    // Get reason list
    private fun getReasons(){
        try {
            viewModel.getCanNotFindItemReasons(object : HandleResponse<CommonResponse>{
                override fun handleErrorResponse(error: ErrorResponse?) {
                    Toast.makeText(baseActivity, error?.message, Toast.LENGTH_SHORT).show()
                }

                override fun handleSuccessResponse(successResponse: CommonResponse) {
                    val response = successResponse.data
                    if (successResponse != null) {
                        if (successResponse.status == 200){
                            val jsonArray = successResponse.data!!.asJsonArray
                            for (i in 0 until jsonArray.size()) {
                                val gson = Gson()
                                val item : ItemNotFoundReason = gson.fromJson(jsonArray[i], ItemNotFoundReason::class.java)
                                itemNotFoundReasons.add(item)
                            }

                            try{
                                // Initialize the list adapter
                                listAdapter = NoItemFoundReasonAdapter(baseActivity, itemNotFoundReasons, {item -> onReasonItemClick(item)})
                                viewDataBinding?.recyclerView?.adapter = listAdapter
                            }
                            catch (e : Exception) {
                                e.printStackTrace()
                            }
                        }
                        else{
                            Toast.makeText(baseActivity, successResponse.message, Toast.LENGTH_SHORT).show()
                        }
                    }
                    else{
                        Toast.makeText(baseActivity, R.string.error_server_return_null, Toast.LENGTH_SHORT).show()
                    }
                }
            })
        }
        catch (e : Exception){
            e.printStackTrace()
        }

    }

    // OnItemClickListener
    fun onReasonItemClick(reasonItem : ItemNotFoundReason) {
        selectedReason = reasonItem

//        setReason(reasonItem)
    }


    private fun openSimilarList(){
        try{
            viewModel.shopperSuggestionProductList(item!!.ordersOutletsItemsId ?: 0, orderId, null, object : HandleResponse<SuggestionResponse>{
                override fun handleErrorResponse(error: ErrorResponse?) {
                    Toast.makeText(baseActivity, error?.message, Toast.LENGTH_SHORT).show()
                }

                override fun handleSuccessResponse(successResponse: SuggestionResponse) {
                    if (successResponse != null){
                        if (isAdded)
                            dismissAllowingStateLoss()

                        if (successResponse.httpCode == 200){
                            changeOldItem(successResponse, item!!)

                            if (item != null && item!!.customerSuggestionType == 3 || item!!.item_type == 2) {
                                openRefundDialog(item!!, FROM_TODO)
                            }
                            else{
                                val products = arrayListOf<SimilarProduct>()
                                products.addAll(successResponse.similarProducts!!)
                                Navigators.goToSuggestionProductListActivity(baseActivity, products, orderId,
                                    if (item!!.replacementRequested != null && item!!.replacementRequested == 1) ((item!!.oldOutletItemId ?: "0").toLongOrNull() ?: 0) else (item!!.outletItemId ?: 0).toLong(),
                                    item!!.ordersOutletsItemsId ?: 0, item!!.itemQty ?: 0.0, item!!, info!!, FROM_TODO)
                            }
                        }
                        else{
                            if (item != null && item!!.customerSuggestionType == 3 || item!!.item_type == 2) {
                                openRefundDialog(item!!, FROM_TODO)
                            }
                            else{
                                val products = arrayListOf<SimilarProduct>()
                                Navigators.goToSuggestionProductListActivity(baseActivity, products, orderId,
                                    if (item!!.replacementRequested != null && item!!.replacementRequested == 1) (item!!.oldOutletItemId ?: "0.0").toLong() else (item!!.outletItemId ?: 0.0).toLong(),
                                    item!!.ordersOutletsItemsId ?: 0, item!!.itemQty ?: 0.0, item!!, info!!, FROM_TODO)
                            }
                        }
                    }
                    else{
                        Toast.makeText(baseActivity, R.string.error_server_return_null, Toast.LENGTH_SHORT).show()
                    }
                }
            })
        }
        catch ( e : Exception){
            e.printStackTrace()
        }

    }

    // Open the Refund dialog
    private fun openRefundDialog(item : OrdersItem, actionFrom : Int){
        // RefundFragmentDialog
        val refundDialogFragment = RefundDialogFragment.newInstance(item, orderId, actionFrom)
        refundDialogFragment.show(baseActivity.supportFragmentManager, RefundDialogFragment.javaClass.name)
    }

    // Change the old item
    private fun changeOldItem(suggestionResponse : SuggestionResponse, item : OrdersItem) : OrdersItem{
        if (suggestionResponse.similarProducts != null && suggestionResponse.similarProducts.isNotEmpty()){
            val firstItem = suggestionResponse.similarProducts[0]
            if (firstItem.previousShopperSuggestedItem != null && firstItem.previousShopperSuggestedItem.isNotEmpty()){
                val similarProductPrevious = firstItem.previousShopperSuggestedItem[0]
                item.outletItemId = similarProductPrevious.outletItemId
                item.productName = similarProductPrevious.productName
                item.shopperTips = similarProductPrevious.shopperTips
                item.departmentName = similarProductPrevious.departmentName
                item.aisleName = similarProductPrevious.aisleName
                item.soldPer = similarProductPrevious.soldPer ?: 0
                item.soldPerLabel = similarProductPrevious.soldPerLabel
                item.labelValue = similarProductPrevious.labelValue
                item.sizeLabel = similarProductPrevious.sizeLabel
                item.approxWeight = similarProductPrevious.approxWeight ?: 0.0
                item.eachSuffix = similarProductPrevious.eachSuffix
                item.ourSellingPrice = similarProductPrevious.ourSellingPrice ?: 0.0
                item.unit = similarProductPrevious.unit
                item.productImage = similarProductPrevious.productImage
                item.productInfoImage = similarProductPrevious.productInfoImage
                item.barCode = similarProductPrevious.barCode ?: ""
                item.upcType = similarProductPrevious.upcType
            }
        }

        return item
    }

    // Set the reason
    private fun setReason(reason : ItemNotFoundReason){
        try {
            viewModel.setItemNotFoundReason(orderId, orderId, item!!.outletItemId ?: 0, reason.id, object : HandleResponse<CommonResponse>{
                override fun handleErrorResponse(error: ErrorResponse?) {
                    Toast.makeText(baseActivity, error?.message, Toast.LENGTH_SHORT).show()

                    openSimilarList()
                }

                override fun handleSuccessResponse(successResponse: CommonResponse) {
                    val responseData = successResponse.data

                    if (successResponse != null) {
                        if (successResponse.status == 200 && responseData != null){
//                            openSimilarList()
                        }
                        else{
                            Toast.makeText(baseActivity, successResponse.message, Toast.LENGTH_SHORT).show()
                        }
                    }
                    else{
                        Toast.makeText(baseActivity, R.string.error_server_return_null, Toast.LENGTH_SHORT).show()
                    }

                    openSimilarList()
                }
            })
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    companion object {
        const val KEY_ORDER_ITEM      = "orders_item"
        const val KEY_CUSTOMER_INFO   = "customer_info"
        const val KEY_ORDER_ID        = "order_id"
        const val KEY_REPLACEMENT_LIMIT = "replacement_limit"


        fun newInstance(
            item : OrdersItem,
            info : CustomerInfo,
            orderId : Long,
            replaceLimit : Int
        ): CanNotFindItemDialogFragment {
            val fragment = CanNotFindItemDialogFragment()

            val data = Bundle()

            data.putSerializable(KEY_ORDER_ITEM, item)
            data.putSerializable(KEY_CUSTOMER_INFO, info)
            data.putLong(KEY_ORDER_ID, orderId)
            data.putInt(KEY_REPLACEMENT_LIMIT, replaceLimit)

            fragment.arguments = data

            return fragment
        }
    }
}