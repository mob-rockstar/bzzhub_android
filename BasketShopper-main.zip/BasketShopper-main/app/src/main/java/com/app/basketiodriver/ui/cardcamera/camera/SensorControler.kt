package com.app.basketiodriver.ui.cardcamera.camera

import android.app.Activity
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.util.Log
import java.util.*

class SensorControler private constructor(context: Context) : SensorEventListener {
    private val mSensorManager: SensorManager
    private val mSensor: Sensor
    private var mX = 0
    private var mY = 0
    private var mZ = 0
    private var lastStaticStamp: Long = 0
    var mCalendar: Calendar? = null
    private var foucsing = 1
    var isFocusing = false
    var canFocusIn = false
    var canFocus = false
    private var STATUE = STATUS_NONE
    fun onStart() {
        restParams()
        canFocus = true
        mSensorManager.registerListener(
            this, mSensor,
            SensorManager.SENSOR_DELAY_NORMAL
        )
    }

    fun onStop() {
        mCameraFocusListener = null
        mSensorManager.unregisterListener(this, mSensor)
        canFocus = false
    }

    override fun onAccuracyChanged(
        sensor: Sensor,
        accuracy: Int
    ) {
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor == null) {
            return
        }
        if (isFocusing) {
            restParams()
            return
        }
        if (event.sensor.type == Sensor.TYPE_ACCELEROMETER) {
            val x = event.values[0].toInt()
            val y = event.values[1].toInt()
            val z = event.values[2].toInt()
            mCalendar = Calendar.getInstance()
            val stamp = mCalendar!!.timeInMillis // 1393844912
            val second = mCalendar!!.get(Calendar.SECOND) // 53
            if (STATUE != STATUS_NONE) {
                val px = Math.abs(mX - x)
                val py = Math.abs(mY - y)
                val pz = Math.abs(mZ - z)
                val value =
                    Math.sqrt(px * px + py * py + (pz * pz).toDouble())
                if (value > 1.4) {
                    STATUE = STATUS_MOVE
                } else {
                    if (STATUE == STATUS_MOVE) {
                        lastStaticStamp = stamp
                        canFocusIn = true
                    }
                    if (canFocusIn) {
                        if (stamp - lastStaticStamp > DELEY_DURATION) {
                            if (!isFocusing) {
                                canFocusIn = false
                                //
                                if (mCameraFocusListener != null) {
                                    mCameraFocusListener!!.onFocus()
                                }
                            }
                        }
                    }
                    STATUE = STATUS_STATIC
                }
            } else {
                lastStaticStamp = stamp
                STATUE = STATUS_STATIC
            }
            mX = x
            mY = y
            mZ = z
        }
    }

    private fun restParams() {
        STATUE = STATUS_NONE
        canFocusIn = false
        mX = 0
        mY = 0
        mZ = 0
    }

    val isFocusLocked: Boolean
        get() = if (canFocus) {
            foucsing <= 0
        } else false

    fun lockFocus() {
        isFocusing = true
        foucsing--
        Log.i(TAG, "lockFocus")
    }

    fun unlockFocus() {
        isFocusing = false
        foucsing++
        Log.i(TAG, "unlockFocus")
    }

    fun restFoucs() {
        foucsing = 1
    }

    private var mCameraFocusListener: CameraFocusListener? = null

    interface CameraFocusListener {
        fun onFocus()
    }

    fun setCameraFocusListener(mCameraFocusListener: CameraFocusListener?) {
        this.mCameraFocusListener = mCameraFocusListener
    }

    companion object {
        const val TAG = "SensorControler"
        const val DELEY_DURATION = 500
        private var mInstance: SensorControler? = null
        const val STATUS_NONE = 0
        const val STATUS_STATIC = 1
        const val STATUS_MOVE = 2
        fun getInstance(context: Context): SensorControler? {
            if (mInstance == null) {
                mInstance = SensorControler(context)
            }
            return mInstance
        }
    }

    init {
        mSensorManager = context.getSystemService(Activity.SENSOR_SERVICE) as SensorManager
        mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)!! // TYPE_GRAVITY
    }
}