package com.app.basketiodriver.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.IBinder
import timber.log.Timber

class NotificationSoundService : Service() {

    // MediaPlayer
    private var mediaPlayer : MediaPlayer? = null

    private var isPlayingSound : Boolean = false

    override fun onBind(p0: Intent?): IBinder? {
        return null
    }

    override fun onCreate() {
        Timber.d("NotificationSoundService: onCreate")

        super.onCreate()
    }

    override fun onStartCommand(intent: Intent, flags: Int, startId: Int): Int {
        Timber.d("NotificationSoundService: onStartCommand")

        if (!isPlayingSound) {
            if (intent.extras != null) {
                initMediaPlayer(intent)
            }
        }

        return START_NOT_STICKY
    }

    override fun onDestroy() {
        Timber.d("NotificationSoundService: onDestroy")

        // Stop the sound
        stopSound()

        super.onDestroy()
    }


    /**
     * Function to initialize the MediaPlayer
     */
    private fun initMediaPlayer(intent: Intent){
        mediaPlayer = MediaPlayer().apply {
            Timber.d("NotificationSoundService: initMediaPlayer")

            // Set OnPreparedListener
            setOnPreparedListener {
                start()
                isLooping = true
                isPlayingSound = true
            }

            // Set OnCompletionListener
            setOnCompletionListener {
                if (isPlayingSound){
                    start()
                    isLooping = true
                }
            }

            try {
                isLooping = true
                setDataSource(this@NotificationSoundService, Uri.parse(intent.getStringExtra(SOUND_URI_KEY)))
                prepareAsync()
            }
            catch (e: Exception) {
                e.printStackTrace()

                Timber.d("NotificationSoundService: playingException")

                isPlayingSound = false

                // log exceptions
                stopSelf()
            }
        }
    }

    /**
     * Start the playing
     */
    private fun startSound(){
        if (mediaPlayer != null) {
            mediaPlayer!!.start()
        }
    }

    /**
     * Stop the playing
     */
    private fun stopSound(){
        Timber.d("NotificationSoundService: stopSound")

        isPlayingSound = false

        if (mediaPlayer != null){
            mediaPlayer!!.stop()
            mediaPlayer!!.isLooping = false
        }
    }

    /**
     * Function to check Buzzer sound is playing
     * @return boolean
     */
    fun isPlayingBuzzer(): Boolean {
        return this.isPlayingSound
    }

    companion object{
        const val SOUND_URI_KEY = "KEY_BUZZER_URI"
    }
}