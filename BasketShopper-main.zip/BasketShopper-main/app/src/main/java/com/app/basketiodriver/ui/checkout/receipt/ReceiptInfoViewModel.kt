package com.app.basketiodriver.ui.checkout.receipt

import android.app.Application
import com.app.basketiodriver.data.DataManager
import com.app.basketiodriver.ui.base.BaseNavigator
import com.app.basketiodriver.ui.base.BaseViewModel

class ReceiptInfoViewModel constructor(application: Application, dataManager: DataManager): BaseViewModel<BaseNavigator?>(application, dataManager) {
}