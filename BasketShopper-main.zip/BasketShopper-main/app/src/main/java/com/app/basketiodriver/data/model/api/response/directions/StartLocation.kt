package com.app.basketiodriver.data.model.api.response.directions

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class StartLocation {
    @SerializedName("lat")
    @Expose
    val lat: Double? = null

    @SerializedName("lng")
    @Expose
    val lng: Double? = null
}