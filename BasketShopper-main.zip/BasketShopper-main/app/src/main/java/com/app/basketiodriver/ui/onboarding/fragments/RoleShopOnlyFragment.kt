package com.app.basketiodriver.ui.onboarding.fragments


import android.os.Bundle
import android.view.View
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentRoleShopOnlyBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.onboarding.OnBoardingViewModel
import com.app.basketiodriver.ui.onboarding.OnJoinWaitListNavigator
import com.app.basketiodriver.utils.AppConstants

/**
 * Created by ibraheem lubbad on 2020-01-22.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class RoleShopOnlyFragment(val onJoinWaitListNavigator: OnJoinWaitListNavigator) :
    BaseFragment<FragmentRoleShopOnlyBinding?, OnBoardingViewModel>(),
    Injectable {

    override val layoutId: Int
        get() = R.layout.fragment_role_shop_only

    override val viewModel: OnBoardingViewModel
        get() {
            return getViewModel(requireActivity(), OnBoardingViewModel::class.java)
        }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewDataBinding!!.btnJoinWaitList.setOnClickListener {
            /**
             * change current user type to shop only service
             */
            viewModel.DOC_SELECTED_ROLE = AppConstants.KEY_SHOP_ONLY
            onJoinWaitListNavigator.goToJoin()
        }
    }
}

