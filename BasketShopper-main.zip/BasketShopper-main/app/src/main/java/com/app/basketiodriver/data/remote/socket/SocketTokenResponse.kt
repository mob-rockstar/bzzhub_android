package com.app.basketiodriver.data.remote.socket

open class SocketTokenResponse(
    var `data`: SocketTokenData? = null,
    var message: String = "",
    var status: Int = 0
)