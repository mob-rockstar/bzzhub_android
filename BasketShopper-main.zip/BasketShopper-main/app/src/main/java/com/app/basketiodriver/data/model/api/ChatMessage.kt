package com.app.basketiodriver.data.model.api

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


/**
Created by ibraheem lubbad on 2/25/20.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class ChatMessage {

    @SerializedName("sender")
    @Expose
    var sender: Int? = null

    @SerializedName("receiver")
    @Expose
    var receiver: Int? = null

    @SerializedName("content")
    @Expose
    var content: String? = null

    @SerializedName("img")
    @Expose
    var img: String? = null

    @SerializedName("vid")
    @Expose
    var vid: String? = null

    @SerializedName("viewed")
    @Expose
    var viewed: Int? = null

    @SerializedName("message_text_type")
    @Expose
    var messageTextType: Int? = null

    @SerializedName("createdat")
    @Expose
    var createdat: String? = null

    constructor(
        sender: Int?,
        receiver: Int?,
        content: String?,
        img: String?,
        vid: String?,
        viewed: Int?,
        messageTextType: Int?,
        createdat: String?
    ) {
        this.sender = sender
        this.receiver = receiver
        this.content = content
        this.img = img
        this.vid = vid
        this.viewed = viewed
        this.messageTextType = messageTextType
        this.createdat = createdat
    }


    companion object {
        fun getCopy(): ChatMessage {

            return ChatMessage(1, 2, "Dummmy", "rerer", "1212", 123123, 1, "23e23e23e2e")
        }
    }
}