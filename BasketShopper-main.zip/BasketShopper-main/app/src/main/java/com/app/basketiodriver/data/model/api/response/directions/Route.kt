package com.app.basketiodriver.data.model.api.response.directions

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class Route {
    @SerializedName("bounds")
    @Expose
    val bounds: Bounds? = null

    @SerializedName("copyrights")
    @Expose
    val copyrights: String? = null

    @SerializedName("legs")
    @Expose
    val legs: List<Leg> = arrayListOf()

    @SerializedName("overview_polyline")
    @Expose
    val overviewPolyline: OverviewPolyline? = null

    @SerializedName("summary")
    @Expose
    val summary: String? = null

    @SerializedName("warnings")
    @Expose
    val warnings: List<Any>? = null

    @SerializedName("waypoint_order")
    @Expose
    val waypointOrder: List<Any>? = null
}