package com.app.basketiodriver.data.model.api.response.customerAdditionalQuestions

class AdditionalRequest : ArrayList<AdditionalRequestItem>()