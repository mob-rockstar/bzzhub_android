package com.app.basketiodriver.data.model.api.response.shopper

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName


class ShopperData {
    @SerializedName("first_name")
    @Expose
    val firstName: String = ""

    @SerializedName("last_name")
    @Expose
    val lastName: String = ""

    @SerializedName("email")
    @Expose
    val email: String = ""

    @SerializedName("id")
    @Expose
    val id: Long? = 0

    @SerializedName("mobile")
    @Expose
    val mobile: String = ""

    @SerializedName("image")
    @Expose
    val image: String = ""

    @SerializedName("updated_date")
    @Expose
    val updatedDate: String = ""

    @SerializedName("gender")
    @Expose
    val gender: String = ""

    @SerializedName("shopper_type")
    @Expose
    val shopperType: String = ""

    @SerializedName("shopper_type_id")
    @Expose
    val shopperTypeId: Int = 0

    @SerializedName("shopper_online_status")
    @Expose
    val online: Int = 0

    @SerializedName("is_terms_agreed")
    @Expose
    val isTermsAgreed: Int = 0

    @SerializedName("country_id")
    @Expose
    val countryId: Int = 0

    @SerializedName("city_id")
    @Expose
    val cityId: Int = 0
}