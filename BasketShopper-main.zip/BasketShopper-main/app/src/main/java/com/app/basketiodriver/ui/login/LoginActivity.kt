
package com.app.basketiodriver.ui.login

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.navigation.Navigation.findNavController
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.ActivityLoginBinding
import com.app.basketiodriver.mvvm.ui.login.LoginNavigator
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.utils.CommonUtils
//import com.google.firebase.iid.FirebaseInstanceId
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.utils.AppConstants
import com.tbruyelle.rxpermissions2.RxPermissions
import io.reactivex.android.schedulers.AndroidSchedulers
import java.util.*
import javax.inject.Inject


/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class LoginActivity : BaseActivity<ActivityLoginBinding?, LoginViewModel>(), LoginNavigator,
    HasAndroidInjector {


    /**
     * bind layout with current screen
     */
    override val layoutId: Int
        get() = R.layout.activity_login

    override val viewModel: LoginViewModel
        get() {
            return getViewModel(LoginViewModel::class.java)
        }


    /**
     *  perform injection fragments for current  activity
     */
    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewModel.setNavigator(this)

        initLoginToolbar(
            getString(R.string.login),
            true,
            viewDataBinding!!.toolbarLayout.toolbar,
            View.OnClickListener {
                run {
                    when {
                        !findNavController(this, R.id.navHostLoginFragments).popBackStack() -> {
                            finishAffinity()
                        }
                    }
                }
            })

        // Check if no internet
        if (!isNetworkConnected){
            Toast.makeText(this, getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_SHORT).show()
            return
        }


        gettingDeviceId()
    }


    // getting device  firebase token
    private fun gettingDeviceId() {

    }

    /**
     * Call the support
     */
    @SuppressLint("CheckResult")
    fun callSupport(){
        try {
            val number = String.format(Locale.ENGLISH, "tel:%s", AppConstants.SUPPORT_PHONE_NUMBER)
            RxPermissions(this).request(
                Manifest.permission.CALL_PHONE
            ).observeOn(AndroidSchedulers.mainThread())
                .subscribe { granted ->
                    if (granted) {
                        val intent = Intent(Intent.ACTION_CALL, Uri.parse(number))
                        startActivity(intent)
                    }
                    else{
                        Toast.makeText(this, getString(R.string.error_no_call_permission), Toast.LENGTH_SHORT).show()
                    }
                }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onBackPressed() {
        when {
            !findNavController(this, R.id.navHostLoginFragments).popBackStack() -> {
                finishAffinity()
            }
        }

//        val alertDialogBuilder = AlertDialog.Builder(this)
//            .setTitle("")
//            .setMessage(getString(R.string.log_out_or_exit_txt))
//            .setCancelable(true)
//            .setPositiveButton(getString(R.string.ok_btn_txt)) { dialog, _ ->
//                finish()
//                application.onTerminate()
//            }.setNegativeButton(getString(R.string.cancel_btn_txt)) { dialog, _ ->
//                dialog.dismiss()
//            }
//
//        alertDialogBuilder.show()
    }

    companion object {
        const val KEY_MOBILE_NUMBER: String = "mobile"
        const val KEY_MOBILE_CODE_NUMBER: String = "mobile_code"

        fun newIntent(context: Context?): Intent {
            return Intent(context, LoginActivity::class.java)
        }
    }

    override fun gotToNext() {
    }

    override fun handleError(error: String) {
    }

    override fun handleSuccess(success: String) {
    }
}