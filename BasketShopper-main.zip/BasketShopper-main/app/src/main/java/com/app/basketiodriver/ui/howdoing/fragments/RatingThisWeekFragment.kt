package com.app.basketiodriver.ui.howdoing.fragments

import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.howamidoing.ShopperRatingResponse
import com.app.basketiodriver.databinding.FragmentRatingThisWeekBinding
import com.app.basketiodriver.databinding.FragmentRatingsBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.howdoing.HowIamDoingViewModel
import com.app.basketiodriver.ui.weekhours.fragments.HoursWeekFragment
import com.app.basketiodriver.utils.AppLogger
import java.util.*

class RatingThisWeekFragment: BaseFragment<FragmentRatingThisWeekBinding?, HowIamDoingViewModel>(),
    Injectable {
    override val layoutId: Int
        get() = R.layout.fragment_rating_this_week

    override val viewModel: HowIamDoingViewModel
        get() {
            return getViewModel(requireActivity(), HowIamDoingViewModel::class.java)
        }

    // Rating Type : Week , Last Month
    private var ratingType = "Week"

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        /**
         * get current rating type
         */
        arguments?.let {
            ratingType = it.getString(RatingThisWeekFragment.KEY_RATING_TYPE)!!

            AppLogger.d("Rating Type -> ${ratingType}")

            // Get the ratings
            getRatings()
        }

    }

    companion object {
        const val KEY_RATING_TYPE  = "rating_type"

        fun newInstance(
            ratingType: String?
        ): RatingThisWeekFragment{
            val fragment = RatingThisWeekFragment()

            val data = Bundle()
            data.putString(KEY_RATING_TYPE, ratingType)
            fragment.arguments = data

            return fragment
        }
    }

    private fun getRatings(){
        viewModel.getShopperRatingDetails(ratingType, object:HandleResponse<ShopperRatingResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Toast.makeText(baseActivity, error?.message, Toast.LENGTH_LONG).show()
                }
                else{
                    Toast.makeText(baseActivity, baseActivity?.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }
            }

            override fun handleSuccessResponse(successResponse: ShopperRatingResponse) {
                if (successResponse.data != null){
                    updateRatingView(successResponse.data)
                }
                else{
                    Toast.makeText(baseActivity, successResponse.message, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    // Update Rating View
    private fun updateRatingView(data : ShopperRatingResponse.RatingDetailData){
        viewDataBinding!!.txtFromToDate.text = String.format(Locale("en"), "%s - %s", data.fromDate, data.toDate)
        viewDataBinding!!.txtRatings.text = data.rating
        viewDataBinding!!.txtRatingSmall.text = String.format(Locale("en"), "%s %s", data.totalRatingReceived, baseActivity?.resources?.getString(R.string.total_rating_received))
    }
}