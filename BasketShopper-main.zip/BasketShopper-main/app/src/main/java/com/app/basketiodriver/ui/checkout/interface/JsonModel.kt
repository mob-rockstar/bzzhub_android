package com.app.basketiodriver.ui.checkout.`interface`

import org.json.JSONObject




interface JsonModel {
    fun fromJson(json: JSONObject)
    fun toJson(): JSONObject
}