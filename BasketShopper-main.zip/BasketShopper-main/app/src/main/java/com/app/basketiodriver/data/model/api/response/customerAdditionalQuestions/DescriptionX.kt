package com.app.basketiodriver.data.model.api.response.customerAdditionalQuestions

data class DescriptionX(
    val lang: String,
    val text: String
)