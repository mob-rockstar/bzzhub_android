package com.app.basketiodriver.ui.dialogs

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Adapter
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentManager
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.model.api.response.earning.monthly.ShopperDetailsReportResponse
import com.app.basketiodriver.databinding.DialogCreateTicketBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseDialogFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.app.basketiodriver.ui.earning.EarningViewModel
import com.app.basketiodriver.utils.GlideApp
import com.google.gson.JsonObject
import com.tbruyelle.rxpermissions2.RxPermissions
import io.reactivex.android.schedulers.AndroidSchedulers
import pl.aprilapps.easyphotopicker.DefaultCallback
import pl.aprilapps.easyphotopicker.EasyImage
import pl.aprilapps.easyphotopicker.MediaFile
import pl.aprilapps.easyphotopicker.MediaSource
import java.io.File

class CreateTicketDialogFragment : BaseDialogFragment<DialogCreateTicketBinding, EarningViewModel> (), Injectable {
    override val layoutId: Int
        get() = R.layout.dialog_create_ticket

    override val viewModel: EarningViewModel
        get() {
            return getViewModel(baseActivity as FragmentActivity, EarningViewModel::class.java)
        }

    var parentActivity : FragmentActivity? = null
    var orderId : Long? = null
    var choices : ArrayList<String> = arrayListOf()


    var ticketType : String = ""

    // Image File
    var imageFile : File? = null
    private lateinit var easyImage: EasyImage

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        parentActivity = baseActivity as FragmentActivity
    }

    override fun getTheme(): Int {
        return R.style.LocationDialogStyle
    }

    override fun onStart() {
        super.onStart()

        try {
            dialog!!.window!!.setLayout(
                RelativeLayout.LayoutParams.MATCH_PARENT,
                RelativeLayout.LayoutParams.MATCH_PARENT
            )
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }

    override fun show(manager: FragmentManager, tag: String?) {
        try {
            val ft = manager.beginTransaction()
            ft.add(this, tag)
            ft.commitAllowingStateLoss()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize the Easy Image
        easyImage =
            EasyImage.Builder(baseActivity as Activity).setCopyImagesToPublicGalleryFolder(false)
                .allowMultiple(false)
                .build()

        // Back
        viewDataBinding!!.layoutToolBar.btnBack.setOnClickListener {
            dismissAllowingStateLoss()
        }

        /**
         * get params
         */
        arguments?.let {
            choices = it.getSerializable(KEY_CHOICE_LIST) as ArrayList<String>

            initViews()
        }
    }

    private fun initViews(){
        if (parentActivity != null) {
            val adapter = ArrayAdapter(parentActivity!!, android.R.layout.simple_spinner_dropdown_item, choices)
            viewDataBinding!!.spinnerType.adapter = adapter

            viewDataBinding!!.spinnerType.onItemSelectedListener = object :
                AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>,
                                            view: View, position: Int, id: Long) {
                    Toast.makeText(baseActivity,
                        "Selected type :" + " " +
                                "" + choices[position], Toast.LENGTH_SHORT).show()
                    ticketType = choices[position]
                }

                override fun onNothingSelected(parent: AdapterView<*>) {
                    // write code to perform some action
                }
            }
        }

        // capture image
        viewDataBinding!!.imgAdd.setOnClickListener {
            pickUpImage()
        }

        // Remove the captured image
        viewDataBinding!!.ivRemovePhoto.setOnClickListener {
            viewDataBinding!!.photoView.visibility = View.GONE
            viewDataBinding!!.imgAdd.visibility = View.VISIBLE
            imageFile = null
        }

        viewDataBinding!!.btnSubmit.setOnClickListener {
            createTicket()
        }
    }

    // Create ticket
    private fun createTicket(){
        val bid = viewDataBinding!!.etBid.text.toString().trim()
        if (bid.isEmpty() || (bid.toLongOrNull() ?: 0L) == 0L) {
            Toast.makeText(baseActivity, baseActivity.resources.getString(R.string.msg_invalid_bid), Toast.LENGTH_SHORT).show()
            return
        }

        val subject = viewDataBinding!!.etSubject.text.toString().trim()
        if (subject.isEmpty()) {
            Toast.makeText(baseActivity, baseActivity.resources.getString(R.string.enter_subject), Toast.LENGTH_SHORT).show()
            return
        }

        // type : String, bid : Long, description : String, priority : Int, status : Int, attach : File?
        viewModel.createTicket(ticketType, (bid.toLongOrNull() ?: 0L), subject, viewDataBinding!!.etDescription.text.toString().trim(), 1, 2, imageFile, object : HandleResponse<JsonObject>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Log.e("Ticket", "Creating Ticket Error : " + error?.message)
                    Toast.makeText(baseActivity, error?.message, Toast.LENGTH_LONG).show()
                }else{
                    Toast.makeText(baseActivity, baseActivity.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }
            }

            override fun handleSuccessResponse(successResponse: JsonObject) {
                Toast.makeText(baseActivity, baseActivity.resources?.getString(R.string.msg_create_ticket_success), Toast.LENGTH_LONG).show()

                // Close the dialog
                dismissAllowingStateLoss()
            }
        })
    }

    // pick up the image
    private fun pickUpImage(){
        if (imageFile != null){
            imageFile!!.deleteOnExit()
            imageFile = null
        }

        openImagePicker()
    }

    // Open Image Picker to select the profile image
    @SuppressLint("CheckResult")
    private fun openImagePicker() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            RxPermissions(this).request(
                Manifest.permission.CAMERA, Manifest.permission.READ_MEDIA_IMAGES)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe { granted ->
                    if (granted) {
                        Log.e("Ticket", "permission is granted...")
                        easyImage.openChooser(this)
                    }
                    else{
                        Log.e("Ticket", "permission is not granted...")
                    }
                }
        }
        else{
            RxPermissions(this).request(
                Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe { granted ->
                    if (granted) {
                        Log.e("Ticket", "permission is granted...")
                        easyImage.openChooser(this)
                    }
                    else{
                        Log.e("Ticket", "permission is not granted...")
                    }
                }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Picked image
        easyImage.handleActivityResult(requestCode, resultCode, data, baseActivity as Activity, object :
            DefaultCallback() {
            override fun onMediaFilesPicked(imageFiles: Array<MediaFile>, source: MediaSource) {
                imageFile = imageFiles.first().file
                if (imageFile != null){
                    viewDataBinding!!.photoView.visibility = View.VISIBLE
                    viewDataBinding!!.imgAdd.visibility = View.GONE

                    GlideApp.with(baseActivity as Activity).load(imageFile?.absolutePath).fitCenter()
                        .placeholder(R.drawable.bg_photo_green_round_4x)
                        .error(R.drawable.bg_photo_green_round_4x).into(viewDataBinding!!.ivCapturedPhoto)

//                    val srcBitmap = BitmapFactory.decodeFile(imageFile.absolutePath)
//
//                    // Get the scaled image path
//                    val dstImagePath = saveImage(srcBitmap)
//                    if (dstImagePath != null) {
//                        imageFile = File(dstImagePath)
//                    }
                }
                else{
                    viewDataBinding!!.photoView.visibility = View.GONE
                    viewDataBinding!!.imgAdd.visibility = View.VISIBLE
                }

            }
        })
    }

    companion object {
        const val KEY_CHOICE_LIST    = "key_choice_list"
        const val KEY_ORDER_ID       = "key_order_id"

        fun newInstance (choices : ArrayList<String>) : CreateTicketDialogFragment {
            val fragment = CreateTicketDialogFragment()

            val data = Bundle()
            data.putSerializable(KEY_CHOICE_LIST, choices)

            fragment.arguments = data

            return fragment
        }
    }
}