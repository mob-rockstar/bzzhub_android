package com.app.basketiodriver.ui.dialogs

import android.os.Bundle
import android.text.Html
import android.view.View
import androidx.fragment.app.FragmentActivity
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.model.api.response.order.SimilarProduct
import com.app.basketiodriver.databinding.FragmentIncorrectItemDialogBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseDialogFragment
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.app.basketiodriver.ui.order.product.ScanItem
import com.app.basketiodriver.utils.GlideApp
import com.app.basketiodriver.utils.price.PriceConstructor
import com.app.basketiodriver.utils.price.PriceConstructorNew


class IncorrectItemDialogFragment : BaseDialogFragment<FragmentIncorrectItemDialogBinding?, OrderDetailsViewModel>(),
    Injectable {

    override val layoutId: Int
        get() = R.layout.fragment_incorrect_item_dialog

    override val viewModel: OrderDetailsViewModel
        get() {
            return getViewModel(baseActivity, OrderDetailsViewModel::class.java)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        parentActivity = requireActivity()
    }

    // Set Full screen
    override fun getTheme(): Int {
        return R.style.MyDialogWhite
    }

    var parentActivity : FragmentActivity? = null
    var item : OrdersItem? = null
    var similarProduct : SimilarProduct? = null

    var type = 0

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        /**
         * get params
         */
        arguments?.let {

            item = it.getSerializable(KEY_ORDER_ITEM) as? OrdersItem
            similarProduct = it.getSerializable(KEY_SIMILAR_ITEM) as? SimilarProduct
            type = it.getInt(KEY_TYPE, 0)

            initToolbar()

            initViews()
        }
    }

    // Init the Toolbar
    private fun initToolbar(){

        viewDataBinding!!.layoutToolBar.toolBarTitle.text = getString(R.string.incorrect_item)
        viewDataBinding!!.layoutToolBar.btnBack.setOnClickListener {
            dismiss()
        }
    }

    private fun initViews(){
        // Try again
        viewDataBinding!!.btnRetry.setOnClickListener {
            if (activity is ScanItem) (activity as ScanItem).resumeScan()
            dismiss()
        }

        // Show the item details
        if (type == 0){
            setSimilarExisting() // show the item customer requested
            setOrderFound() // show the item I found
        }
        else{
            setOrderExisting() // show the item customer requested
            setSimilarFound() // show the item I found
        }
    }

    private fun setSimilarExisting(){
        if (similarProduct != null){
            val product = similarProduct!!

            GlideApp.with(this).load(product.productImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(viewDataBinding!!.orderItemImageCR)

            viewDataBinding!!.txtTitleCR.text = product.productName
            if (product.getDescriptionLabel().isEmpty()){
                viewDataBinding!!.tvPriceDescriptionCR.visibility = View.GONE
            }
            else{
                viewDataBinding!!.tvPriceDescriptionCR.visibility = View.VISIBLE
                viewDataBinding!!.tvPriceDescriptionCR.text = product.getDescriptionLabel()
            }

            viewDataBinding!!.txtPricePerUnitCR.setText(Html.fromHtml(PriceConstructorNew.getFormatPrice(product, PriceConstructor.LabelType.SIMPLE)))
        }
    }

    private fun setOrderFound(){
        if (item != null){
            val product = item!!

            GlideApp.with(this).load(product.productImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(viewDataBinding!!.foundProduct.orderItemImage)

            viewDataBinding!!.foundProduct.txtTitle.text = product.productName
            if (product.getDescriptionLabel().isEmpty()){
                viewDataBinding!!.foundProduct.tvPriceDescription.visibility = View.GONE
            }
            else{
                viewDataBinding!!.foundProduct.tvPriceDescription.visibility = View.VISIBLE
                viewDataBinding!!.foundProduct.tvPriceDescription.text = product.getDescriptionLabel()
            }

            viewDataBinding!!.foundProduct.txtPricePerUnit.setText(Html.fromHtml(PriceConstructorNew.getFormatPrice(product, PriceConstructor.LabelType.SIMPLE, true)))
        }
    }

    private fun setOrderExisting(){
        if (item != null){
            val product = item!!

            GlideApp.with(this).load(product.productImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(viewDataBinding!!.orderItemImageCR)

            viewDataBinding!!.txtTitleCR.text = product.productName
            if (product.getDescriptionLabel().isEmpty()){
                viewDataBinding!!.tvPriceDescriptionCR.visibility = View.GONE
            }
            else{
                viewDataBinding!!.tvPriceDescriptionCR.visibility = View.VISIBLE
                viewDataBinding!!.tvPriceDescriptionCR.text = product.getDescriptionLabel()
            }

            viewDataBinding!!.txtPricePerUnitCR.setText(Html.fromHtml(PriceConstructorNew.getFormatPrice(product, PriceConstructor.LabelType.SIMPLE, true)))
        }
    }

    private fun setSimilarFound(){
        if (similarProduct != null){
            val product = similarProduct!!

            GlideApp.with(this).load(product.productImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(viewDataBinding!!.foundProduct.orderItemImage)

            viewDataBinding!!.foundProduct.txtTitle.text = product.productName
            if (product.getDescriptionLabel().isEmpty()){
                viewDataBinding!!.foundProduct.tvPriceDescription.visibility = View.GONE
            }
            else{
                viewDataBinding!!.foundProduct.tvPriceDescription.visibility = View.VISIBLE
                viewDataBinding!!.foundProduct.tvPriceDescription.text = product.getDescriptionLabel()
            }

            viewDataBinding!!.foundProduct.txtPricePerUnit.setText(Html.fromHtml(PriceConstructorNew.getFormatPrice(product, PriceConstructor.LabelType.SIMPLE)))
        }
    }

    companion object {
        const val KEY_ORDER_ITEM      = "orders_item"
        const val KEY_SIMILAR_ITEM    = "similar_item"
        const val KEY_TYPE            = "type"


        fun newInstance(
            item : OrdersItem,
            similarProduct : SimilarProduct
        ): IncorrectItemDialogFragment {
            val fragment = IncorrectItemDialogFragment()

            val data = Bundle()

            data.putSerializable(KEY_ORDER_ITEM, item)
            data.putSerializable(KEY_SIMILAR_ITEM, similarProduct)
            data.putInt(KEY_TYPE, 0)

            fragment.arguments = data

            return fragment
        }

        fun newInstance(
            similarProduct : SimilarProduct,
            item : OrdersItem
        ): IncorrectItemDialogFragment {
            val fragment = IncorrectItemDialogFragment()

            val data = Bundle()

            data.putSerializable(KEY_ORDER_ITEM, item)
            data.putSerializable(KEY_SIMILAR_ITEM, similarProduct)
            data.putInt(KEY_TYPE, 1)

            fragment.arguments = data

            return fragment
        }
    }
}