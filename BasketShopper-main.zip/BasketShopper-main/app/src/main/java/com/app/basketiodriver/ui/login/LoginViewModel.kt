package com.app.basketiodriver.ui.login

import android.app.Application
import com.app.basketiodriver.data.DataManager
import com.app.basketiodriver.data.model.api.response.Base.BaseResponse
import com.app.basketiodriver.data.model.api.response.CheckMobileResponse
import com.app.basketiodriver.data.model.api.response.Login
import com.app.basketiodriver.data.model.api.response.LoginRequest
import com.app.basketiodriver.data.model.api.response.LoginResponse
import com.app.basketiodriver.data.model.api.response.general.SimpleResponse
import com.app.basketiodriver.data.model.api.response.otp.CheckOTP
import com.app.basketiodriver.data.remote.APIManager
import com.app.basketiodriver.mvvm.ui.login.LoginNavigator
import com.app.basketiodriver.ui.base.BaseViewModel
import com.app.basketiodriver.ui.base.HandleResponse
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import com.app.basketiodriver.data.local.prefs.PreferenceManager

/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class LoginViewModel(
    application: Application,
    dataManager: DataManager
) :
    BaseViewModel<LoginNavigator?>(application, dataManager) {

    var countDownTime: Long = 30000
    var mobileNumber: String = ""
    var codeMobileNumber: String = "+962"
    var userId: Int = 0


    init {
        //remove current session
        dataManager.setUserAsLoggedOut()

    }

    /**
     *  validate shopper's mobile number
     * @param codeMobileNumber String
     * @param mobileNumber String
     * @param handleResponse HandleResponse<CheckMobileResponse>
     */
    fun validateMobileNumber(
        codeMobileNumber: String,
        mobileNumber: String,
        handleResponse: HandleResponse<CheckMobileResponse>
    ) {

    }

    /**
     * Method to call forget password  API
     * @param mobileNumber String
     * @param handleResponse HandleResponse<SimpleResponse>
     */
    fun shopperForgetPassword(
        mobileNumber: String,
        handleResponse: HandleResponse<SimpleResponse>
    ) {

        setIsLoading(true)
        compositeDisposable.add(APIManager.forgotPassword(PreferenceManager.currentUserLanguage, mobileNumber)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)

                        handleResponse.handleSuccessResponse(result)
                    }

                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            )
        )

    }

    /**
     * Method to verify otp code
     * @param mobile Shopper Mobile
     * @param otp OTP code
     */
    fun verifyOTP(mobile : String, otp:String, handleResponse: HandleResponse<CheckOTP>){
        setIsLoading(true)
        compositeDisposable.add(APIManager.checkOTPRequest(PreferenceManager.currentUserLanguage, mobile, otp)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessResponse(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            )
        )
    }

    /**
     * Method to login using  sms code
     * @param request CheckShopperOTPRequest login request parameters
     * @param handleResponse HandleResponse<LoginResponse>
     */
    fun loginByOtp(
        request: LoginRequest.CheckShopperOTPRequest,
        handleResponse: HandleResponse<LoginResponse>
    ) {

//        setIsLoading(true)
//        compositeDisposable.add(dataManager.checkShopperOtp(request)
//            .subscribeOn(Schedulers.io())
//            .observeOn(AndroidSchedulers.mainThread())
//            .subscribe(
//
//                { result ->
//                    run {
//                        setIsLoading(false)
//                        handleResponse.handleSuccessResponse(result)
////                        dataManager.updateUserInfo(result.data?.apiToken,result.data?.user)
//
//                    }
//                },
//                { x ->
//                    run {
//                        setIsLoading(false)
//                        handleResponse.handleErrorResponse(getThrowableError(x))
//                    }
//
//
//                }
//            ))
    }

    /**
     * Method to login using  password
     * @param langCode current language code , 1 : EN
     * @param mobile shopper mobile number
     * @param password password
     * @param handleResponse HandleResponse<LoginResponse>
     */
    fun loginWithPassword(langCode : Int, mobile:String, password:String, handleResponse: HandleResponse<Login>){
        setIsLoading(true)
        compositeDisposable.add(APIManager.loginWithPassword(langCode, mobile, password)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
//                        dataManager.updateUserInfo(result.data?.apiToken,result.data?.user)

                        handleResponse.handleSuccessResponse(result)
                    }

                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }


                }
            )
        )
    }


    /**
     * Method to login using  password
     * @param mobile shopper mobile number
     * @param password New Password
     * @param confirmPass Confirm Password
     * @param handleResponse HandleResponse<SimpleResponse>
     */
    fun setNewPassword(mobile:String, password : String, confirmPass : String, handleResponse: HandleResponse<SimpleResponse>){
        setIsLoading(true)
        compositeDisposable.add(APIManager.setNewPassword(PreferenceManager.currentUserLanguage, mobile, password, confirmPass)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessResponse(result)
                    }

                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            )
        )
    }


    /**
     * Method to update shopper information
     * @param loginResponse LoginResponse
     */
    fun updateShopperInfo(loginResponse : LoginResponse) {
        PreferenceManager.currentShopperId          = loginResponse.shopperId
        PreferenceManager.accessToken               = loginResponse.token
        PreferenceManager.currentShopperEmail       = loginResponse.email
        PreferenceManager.currentShopperMobile      = loginResponse.mobile
        PreferenceManager.currentShopperFirstName   = loginResponse.firstName
        PreferenceManager.currentShopperLastName    = loginResponse.lastName
        PreferenceManager.shopperMobileVerified     = loginResponse.mobileVerified
        PreferenceManager.applicationStatus         = loginResponse.applicationStatus
        PreferenceManager.currency                  = loginResponse.currencySymbol
    }

    /**
     * Method to update sho
     * @param mobileNumber String
     * @param pinCode String
     * @param handleResponse HandleResponse<BaseResponse>
     */
    fun updatePassword(
         request: LoginRequest.ResetShopperPasswordRequest,
        handleResponse: HandleResponse<BaseResponse>
    ) {

    }
}