package com.app.basketiodriver.data.model.api.chat

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

open class StatusMessage {

    @SerializedName("message_id")
    @Expose
    var id: String = ""

    @SerializedName("is_typing")
    @Expose
    var isTyping: Boolean = false

    @SerializedName("by")
    @Expose
    var user: User? = null

}