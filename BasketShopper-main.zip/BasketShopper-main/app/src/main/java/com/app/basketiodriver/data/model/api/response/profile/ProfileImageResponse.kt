package com.app.basketiodriver.data.model.api.response.profile

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName



class ProfileImageResponse {
    @SerializedName("data")
    @Expose
    val data: List<Any>? = null

    @SerializedName("message")
    @Expose
    val message: String = ""

    @SerializedName("status")
    @Expose
    val status: Int = -1
}