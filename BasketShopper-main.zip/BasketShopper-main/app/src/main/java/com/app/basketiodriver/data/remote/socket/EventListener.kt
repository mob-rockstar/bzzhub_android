package com.app.basketiodriver.data.remote.socket

import com.app.basketiodriver.data.model.api.ChatMessage


/**
Created by ibraheem lubbad on 2/25/20.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
interface EventListener {

    fun onConnect()

    fun onConnectionError()

    fun onReconnect()

    fun onDisconnect()

    fun onNewMessage(message: ChatMessage?)

}