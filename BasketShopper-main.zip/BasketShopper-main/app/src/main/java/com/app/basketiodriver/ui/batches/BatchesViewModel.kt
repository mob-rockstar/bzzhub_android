package com.app.basketiodriver.ui.batches

import android.app.Application
import com.app.basketiodriver.data.DataManager
import com.app.basketiodriver.ui.base.BaseNavigator
import com.app.basketiodriver.ui.base.BaseViewModel


/**
Created by ibraheem lubbad on 2020-02-06.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/

class BatchesViewModel constructor(application: Application, dataManager: DataManager) :
    BaseViewModel<BaseNavigator?>(application, dataManager)


