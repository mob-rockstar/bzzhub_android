package com.app.basketiodriver.ui.dialogs

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Html
import android.text.InputType
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.model.api.response.order.CommonResponse
import com.app.basketiodriver.data.model.api.response.order.ReplacementSearchItemRequest
import com.app.basketiodriver.data.model.api.response.order.SimilarProduct
import com.app.basketiodriver.data.model.api.response.order.SimilarResponse
import com.app.basketiodriver.data.remote.socket.SystemMessage
import com.app.basketiodriver.data.remote.socket.SystemMessageReq
import com.app.basketiodriver.databinding.FragmentReplaceQuantityDialogBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseDialogFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.app.basketiodriver.ui.order.adapter.EnterQuantityWeightListAdapter
import com.app.basketiodriver.utils.AppConstants
import com.app.basketiodriver.utils.GlideApp
import com.app.basketiodriver.utils.price.PriceConstructor
import com.app.basketiodriver.utils.price.PriceConstructorNew
import java.io.Serializable
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.*


class ReplaceQuantityDialogFragment: BaseDialogFragment<FragmentReplaceQuantityDialogBinding?, OrderDetailsViewModel>(),
    Injectable {

    override val layoutId: Int
        get() = R.layout.fragment_replace_quantity_dialog

    override val viewModel: OrderDetailsViewModel
        get() {
            return getViewModel(baseActivity, OrderDetailsViewModel::class.java)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    // Set Full screen
    override fun getTheme(): Int {
        return R.style.MyDialogWhite
    }

    var symbols: DecimalFormatSymbols = DecimalFormatSymbols(Locale.ENGLISH)
    var formatter: DecimalFormat = DecimalFormat(" #.## ", symbols)

    var clickListener : AmountDialogFragment.AmountDialogOnClickListener?= null

    var actionFrom : Int = 1

    var orderId : Long = 0L
    var orgOrderId : Int = 0
    var item : OrdersItem? = null
    var similarProduct : SimilarProduct?= null
    var similarProductArray : ArrayList<SimilarProduct>? = null

    var replaceRequestItems : ArrayList<ReplacementSearchItemRequest> = arrayListOf()

    var quantity : Double = 1.0

    lateinit var linearLayoutManager: LinearLayoutManager
    lateinit var replacementProductListAdapter : EnterQuantityWeightListAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initToolbar()

        /**
         * get params
         */
        arguments?.let {
            quantity        = it.getDouble(KEY_QUANTITY, 1.0)
            item            = it.getSerializable(KEY_ORDER_ITEM) as? OrdersItem
            similarProduct  = it.getSerializable(KEY_SIMILAR_PRODUCT) as? SimilarProduct

            actionFrom      = it.getInt(KEY_ACTION_FROM, 1)

            orderId         = it.getLong(KEY_ORDER_ID)
            orgOrderId      = it.getInt(KEY_ORIGINAL_ORDER_ID)

            similarProductArray = it.getSerializable(KEY_SIMILAR_PRODUCTS) as? ArrayList<SimilarProduct>

            initViews()
        }
    }

    private fun initToolbar(){
        viewDataBinding!!.layoutToolBar.toolBarTitle.setText(R.string.enter_quantity_weight)
        viewDataBinding!!.layoutToolBar.btnBack.setOnClickListener {
            dismiss()
        }
    }

    @SuppressLint("SetTextI18n")
    private fun initViews(){
        // Set the LayoutManager of the product list
        linearLayoutManager = LinearLayoutManager(activity)
        viewDataBinding!!.rvReplacement.layoutManager = linearLayoutManager

        // Found Item
        viewDataBinding!!.btnFoundItem.setOnClickListener {
            foundItem()
        }

        if (item != null){
            setOldDataToView()
        }

        if (similarProductArray != null) { // Multiple replacement
            viewDataBinding!!.rvReplacement.visibility = View.VISIBLE
            viewDataBinding!!.replaceItemLayout.visibility = View.GONE
            viewDataBinding!!.cardView3.visibility = View.GONE
            viewDataBinding!!.cardView4.visibility = View.GONE

            // Suggested replacement
            viewDataBinding!!.tvReplaceTint.text = baseActivity.getString(R.string.suggested_replacement)

            // Initialize the replacing product list
            replacementProductListAdapter = EnterQuantityWeightListAdapter(baseActivity, similarProductArray!!, this)
            viewDataBinding!!.rvReplacement.adapter = replacementProductListAdapter

            for (product in similarProductArray!!){
                val requestItem = ReplacementSearchItemRequest()
                requestItem.product = product

                replaceRequestItems.add(requestItem)
            }
        }
        else if (similarProduct != null) { // Single replacement
            viewDataBinding!!.rvReplacement.visibility = View.GONE
            viewDataBinding!!.replaceItemLayout.visibility = View.VISIBLE

            // Replace with
            viewDataBinding!!.tvReplaceTint.text = baseActivity.getString(R.string.replace_with)

            if (similarProduct!!.soldPer == 2){
                viewDataBinding!!.amountEditText.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                viewDataBinding!!.txtPricePerUnitWith.text = baseActivity.getString(R.string.supposed_weight) + " " + formatter.format(similarProduct!!.approxWeight) + " " + similarProduct!!.unit

                viewDataBinding!!.cardView3.visibility = View.GONE
                viewDataBinding!!.cardView4.visibility = View.VISIBLE
            }
            else{
                viewDataBinding!!.amountEditText.inputType = InputType.TYPE_CLASS_NUMBER
                viewDataBinding!!.txtPricePerUnitWith.visibility = View.INVISIBLE

                if (similarProduct!!.soldPer == 3) {
                    viewDataBinding!!.cardView3.visibility = View.VISIBLE
                    viewDataBinding!!.cardView4.visibility = View.VISIBLE
                }
                else{
                    viewDataBinding!!.cardView3.visibility = View.VISIBLE
                    viewDataBinding!!.cardView4.visibility = View.GONE
                }
            }

            setReplacingDataToView()

            // Item unit
            viewDataBinding!!.txtQuantity.text = ""
            viewDataBinding!!.txtQuantity.text = baseActivity.resources?.getString(R.string.items)

        }
    }

    /**
     * Update the item quantity
     */
    fun updateItemQuantity(item : SimilarProduct, qty : Int) {
        for (requestItem in replaceRequestItems){
            if (requestItem.product!! == item) {
                requestItem.quantity = qty.toDouble()
                break
            }
        }
    }

    /**
     * Update the item weight
     */
    fun updateItemWeight(item : SimilarProduct, weight: Double){
        for (requestItem in replaceRequestItems){
            if (requestItem.product!! == item) {
                requestItem.weight = weight
                break
            }
        }
    }

    /**
     *  Remove the item from replacement list
      */
    fun removeItemFromReplacementList(item : SimilarProduct){
        for (requestItem in replaceRequestItems){
            if (requestItem.product!! == item) {
                replaceRequestItems.remove(requestItem)
                break
            }
        }

        similarProductArray!!.remove(item)

        // Hide the FoundItem button if no items in list
        if (similarProductArray!!.size == 0) {
            viewDataBinding!!.bottomLayout.visibility = View.GONE
        }
        else{
            viewDataBinding!!.bottomLayout.visibility = View.VISIBLE
        }
    }

    /**
     * Found Item
     */
    private fun foundItem(){
        if (similarProduct != null) {
            if (clickListener != null){
                if (validateAmount() && validateWeight()) {
                    viewDataBinding!!.amountEditText.error = null

                    val amountStr = viewDataBinding!!.amountEditText.text.toString()
                    val weightStr = viewDataBinding!!.weightEditText.text.toString()
                    if (amountStr.isNotEmpty() && weightStr.isNotEmpty()) {
                        // replace item
                        replaceItem((similarProduct!!.outletItemId ?: 0).toLong(), amountStr.toDouble(), weightStr.toDouble(), actionFrom)
                    }
                    else if (amountStr.isNotEmpty()){
                        // replace item
                        replaceItem((similarProduct!!.outletItemId ?: 0).toLong(), amountStr.toDouble(), actionFrom)
                    }
                    else if (weightStr.isNotEmpty()){
                        // replace item
                        replaceItem((similarProduct!!.outletItemId ?: 0).toLong(), weightStr.toDouble(), actionFrom)
                    }
                }
                else{
                    if (!validateAmount()){
//                        Toast.makeText(activity, R.string.err_msg_invalid_amount, Toast.LENGTH_SHORT).show()
                        viewDataBinding!!.amountEditText.error = getString(R.string.err_msg_invalid_amount)
                    }
                }
            }
        }
        else if (similarProductArray != null) {
            // Replace the multiple items
            viewModel.replaceMultipleItems(orgOrderId.toLong(), orderId, replaceRequestItems, actionFrom, object : HandleResponse<CommonResponse>{
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (activity != null)
                        Toast.makeText(activity, error?.message, Toast.LENGTH_SHORT).show()
                }

                override fun handleSuccessResponse(successResponse: CommonResponse) {
                    if (successResponse.status == 200) {
                        var message = ""
                        message = if (item!!.replacementRequested != null && item!!.replacementRequested == 1){
                            AppConstants.MESSAGE_TYPE_REPLACED + " " + PreferenceManager.currentShopperFirstName + " " + getString(R.string.replaced) + "," + getString(R.string.item) + " "+ item!!.oldProductName + ", " + getString(R.string.with_1) + ", "+ getString(R.string.item) + " " + similarProductArray!![0].productName+"."
                        } else{
                            AppConstants.MESSAGE_TYPE_REPLACED + " " + PreferenceManager.currentShopperFirstName + " " + getString(R.string.replaced) + ","+ getString(R.string.item) + " " + item!!.productName + ", " + getString(R.string.with_1) + ", " + getString(R.string.item) + " "+ similarProductArray!![0].productName+"."
                        }

                        // Send system message to user
                        val systemMessageReq = SystemMessageReq(orderId.toString(), "text", message)
                        sendSystemMessage(systemMessageReq){
                            // Go to previous page
                            if (clickListener != null)
                                clickListener?.onNextClick(orgOrderId.toLong(), 0.0, 0.0)
                        }
                    }
                    else{
                        if (activity != null)
                            Toast.makeText(activity, successResponse.message, Toast.LENGTH_SHORT).show()
                    }
                }
            })
        }
    }

    // Replace item with Quantity & Weight
    private fun replaceItem(itemId : Long, amount : Double, weight : Double, actionFrom : Int){
        // Call api
        viewModel.shopperReplaceItemToDone(amount, weight, orgOrderId.toLong(), itemId, orderId, actionFrom, object : HandleResponse<SimilarResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (activity != null)
                Toast.makeText(activity, error?.message, Toast.LENGTH_SHORT).show()
            }

            override fun handleSuccessResponse(successResponse: SimilarResponse) {
                val data = successResponse.response
                if (data != null){
                    if (data.httpCode == 200){
                        var message = ""
                        message = if (item!!.replacementRequested != null && item!!.replacementRequested == 1){
                            AppConstants.MESSAGE_TYPE_REPLACED + " " + PreferenceManager.currentShopperFirstName + " " + getString(R.string.replaced) + ", "+ getString(R.string.item) + " " + item!!.oldProductName + ", " + getString(R.string.with_1) + ", " + getString(R.string.item) + " "+ similarProduct!!.productName+"."
                        } else{
                            AppConstants.MESSAGE_TYPE_REPLACED + " " + PreferenceManager.currentShopperFirstName + " " + getString(R.string.replaced) + ", "+ getString(R.string.item) + " " + item!!.productName + ", " + getString(R.string.with_1) + ", " + getString(R.string.item) + " "+ similarProduct!!.productName+"."
                        }

                        // Send message
                        val systemMessageReq = SystemMessageReq(orderId.toString(), "text", message)
                        sendSystemMessage(systemMessageReq){
                            if (clickListener != null)
                                clickListener?.onNextClick(amount, weight)
                        }
                    }
                    else{
                        if (activity != null)
                        Toast.makeText(activity, data.message, Toast.LENGTH_SHORT).show()
                    }
                }
                else{
                    if (activity != null)
                    Toast.makeText(activity, R.string.error_server_return_null, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    // Replace the item with Quantity/Weight
    private fun replaceItem(itemId : Long, qty : Double, actionFrom: Int){
        // Call api
        viewModel.shopperReplaceItem(qty, orgOrderId.toLong(), itemId, orderId, actionFrom, object : HandleResponse<CommonResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (activity != null)
                    Toast.makeText(activity, error?.message, Toast.LENGTH_SHORT).show()
            }

            override fun handleSuccessResponse(successResponse: CommonResponse) {
                if (successResponse.status == 200){
                    var message = ""
                    if (item!!.replacementRequested != null && item!!.replacementRequested == 1){
                        message = AppConstants.MESSAGE_TYPE_REPLACED + " " + PreferenceManager.currentShopperFirstName + " " + getString(R.string.replaced) + "," + getString(R.string.item) + " " + item!!.oldProductName + ", " + getString(R.string.with_1) + ", " + similarProduct!!.productName+"."
                    }
                    else{
                        message = AppConstants.MESSAGE_TYPE_REPLACED + " " + PreferenceManager.currentShopperFirstName + " " + getString(R.string.replaced) + ","+ getString(R.string.item) + " "  + item!!.productName + ", " + getString(R.string.with_1) + ", " + similarProduct!!.productName+"."
                    }

                    // Send message
                    val systemMessageReq = SystemMessageReq(orderId.toString(), "text", message!!)
                    sendSystemMessage(systemMessageReq){
                        if (clickListener != null){
                            val amountStr = viewDataBinding!!.amountEditText.text.toString()
                            val weightStr = viewDataBinding!!.weightEditText.text.toString()
                            if (amountStr.isNotEmpty())
                                clickListener?.onNextClick(amountStr.toDoubleOrNull() ?: 0.0)
                            else if (weightStr.isNotEmpty())
                                clickListener?.onNextClick(weightStr.toDoubleOrNull() ?: 0.0)
                        }
                    }
                }
                else{
                    if (activity != null)
                        Toast.makeText(activity, successResponse.message, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    private fun sendSystemMessage(systemMessageReq: SystemMessageReq, onAfterSystemMessageClicked: ()->Unit){
        viewModel.sendSystemMessage(systemMessageReq, object : HandleResponse<SystemMessage> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                onAfterSystemMessageClicked()
            }

            override fun handleSuccessResponse(successResponse: SystemMessage) {
                onAfterSystemMessageClicked()
            }
        })
    }

    // Display the replacing product details
    @SuppressLint("SetTextI18n")
    private fun setOldDataToView(){
        // product image
        if (item!!.productImage != null){
            GlideApp.with(requireActivity()).load(item!!.productImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(viewDataBinding!!.oldProduct.orderItemImage)
        }

        val formatter = DecimalFormat("#.## x ", symbols)

        // Item title
        if (item!!.quantityDifference == 1) {
            viewDataBinding!!.oldProduct.txtTitle.text =
                formatter.format(item!!.actualQty) + item!!.productName
        }
        else if (item!!.replacementRequested != null && item!!.replacementRequested == 1) {
            if (item!!.itemStatus == 2) {
                viewDataBinding!!.oldProduct.txtTitle.text = item!!.oldProductName
            } else {
                viewDataBinding!!.oldProduct.txtTitle.text = formatter.format(item!!.actualQty) + item!!.oldProductName
            }

            if (item!!.oldProductImage != null) {
                GlideApp.with(requireActivity()).load(item!!.oldProductImage).fitCenter()
                    .placeholder(R.drawable.placeholder)
                    .error(R.drawable.placeholder).into(viewDataBinding!!.oldProduct.orderItemImage)
            }
        }
        else {
            viewDataBinding!!.oldProduct.txtTitle.text = formatter.format(item!!.itemQty ?: 0) + (item!!.productName ?: "")// + item!!.aisleName
        }

        // Description
        if (item!!.getDescriptionLabel().isEmpty()) {
            viewDataBinding!!.oldProduct.tvPriceDescription.visibility = View.GONE
        } else {
            viewDataBinding!!.oldProduct.tvPriceDescription.visibility = View.VISIBLE
            viewDataBinding!!.oldProduct.tvPriceDescription.text = item!!.getDescriptionLabel()
        }

        // Unit
        viewDataBinding!!.oldProduct.txtPricePerUnit.text = Html.fromHtml(PriceConstructor.getFormatPrice(item, PriceConstructor.LabelType.SIMPLE, PreferenceManager.currency, true))
    }

    // Display the new product details
    private fun setReplacingDataToView(){
        // product image
        if (similarProduct!!.productImage != null){
            GlideApp.with(requireActivity()).load(similarProduct!!.productImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(viewDataBinding!!.orderItemImageWith)
        }

        // Name
        viewDataBinding!!.txtTitleWith.text = "? " + similarProduct!!.productName

        // Description
        if (similarProduct!!.getDescriptionLabelNew() == ""){
            viewDataBinding!!.tvPriceDescriptionWith.visibility = View.GONE
        }
        else{
            viewDataBinding!!.tvPriceDescriptionWith.visibility = View.VISIBLE
            viewDataBinding!!.tvPriceDescriptionWith.text = similarProduct!!.getDescriptionLabelNew()
        }

        viewDataBinding!!.txtPricePerUnitWith.visibility = View.VISIBLE
        viewDataBinding!!.txtPricePerUnitWith.text = PriceConstructorNew.getFormatPrice(similarProduct!!, PriceConstructor.LabelType.SIMPLE)
    }

    private fun validateAmount() : Boolean {
        when(similarProduct!!.soldPer){
            1,4 -> return if (viewDataBinding!!.amountEditText.text.isEmpty()) false else
                try {
                    viewDataBinding!!.amountEditText.text.toString().toDouble() > 0
                } catch (e : Exception){
                    false
                }
            2 -> return if (viewDataBinding!!.weightEditText.text.isEmpty()) false else
                try {
                    viewDataBinding!!.weightEditText.text.toString().toDouble() > 0
                }
                catch (e : Exception) {
                    false
                }
            3 -> return if (viewDataBinding!!.amountEditText.text.isEmpty() && viewDataBinding!!.weightEditText.text.isEmpty()) false else
                try {
                    return viewDataBinding!!.amountEditText.text.toString().toDouble() > 0 && viewDataBinding!!.weightEditText.text.toString().toDouble() > 0
                }
                catch (e : Exception){
                    false
                }

        }

        return true
    }

    private fun validateWeight() : Boolean {
        return try {
            if (viewDataBinding!!.cardView4.visibility != View.VISIBLE) return true
            var weight = 0.0

            val weightVal = viewDataBinding!!.weightEditText.text != null && !viewDataBinding!!.weightEditText.text.toString().trim().isEmpty()
                    && java.lang.Double.parseDouble(viewDataBinding!!.weightEditText.text.toString()) > 0
            if (!weightVal)
            {
//                Toast.makeText(activity, R.string.err_msg_invalid_weight, Toast.LENGTH_SHORT).show()
            }
            else if (similarProduct!!.soldPer == 3)
            {
                if (validateAmount()) {
                    val qua = viewDataBinding!!.amountEditText.text.toString().toDoubleOrNull()
//                    weight = similarProduct!!.approxWeight

                    if (qua != null){
//                        if (weight < 0.1)
//                            weight = 1.0

                        weight = similarProduct!!.approxWeight * qua

                        val per20 = weight / 100.0f * 20
                        val maxWeight = weight + per20
                        val minWeight = weight - per20

                        if (java.lang.Double.valueOf(viewDataBinding!!.weightEditText.text.toString()) > maxWeight ||
                            java.lang.Double.valueOf(viewDataBinding!!.weightEditText.text.toString()) < minWeight) {
//                            Toast.makeText(activity, R.string.err_msg_invalid_weight, Toast.LENGTH_SHORT).show()
                            return false
                        }
                    }
                    else false
                }
                else false
            }

            return weightVal
        }
        catch (e: Exception) {
//            Toast.makeText(activity, R.string.err_msg_invalid_weight, Toast.LENGTH_SHORT).show()
            false
        }
    }

    companion object {
        const val KEY_ORDER_ITEM      = "orders_item"
        const val KEY_SIMILAR_PRODUCT = "similar_product"
        const val KEY_SIMILAR_PRODUCTS = "similar_product_array"
        const val KEY_QUANTITY        = "key_qty"
        const val KEY_ACTION_FROM     = "action_from"
        const val KEY_ORDER_ID        = "order_id"
        const val KEY_ORIGINAL_ORDER_ID = "original_order_id"


        fun newInstance(
            orderId : Long,
            item : OrdersItem,
            similarProduct: SimilarProduct,
            qty : Double,
            orgOrderId : Int,
            action : Int
        ): ReplaceQuantityDialogFragment {
            val fragment = ReplaceQuantityDialogFragment()

            val data = Bundle()

            data.putSerializable(KEY_ORDER_ITEM, item)
            data.putSerializable(KEY_SIMILAR_PRODUCT, similarProduct)
            data.putDouble(KEY_QUANTITY, qty)
            data.putLong(KEY_ORDER_ID, orderId)
            data.putInt(KEY_ORIGINAL_ORDER_ID, orgOrderId)
            data.putInt(KEY_ACTION_FROM, action)

            fragment.arguments = data

            return fragment
        }

        fun newInstance(
            orderId : Long,
            item : OrdersItem,
            similarProducts: List<SimilarProduct>,
            qty : Double,
            orgOrderId : Int,
            action : Int
        ): ReplaceQuantityDialogFragment {
            val fragment = ReplaceQuantityDialogFragment()

            val data = Bundle()

            data.putSerializable(KEY_ORDER_ITEM, item)
            data.putSerializable(KEY_SIMILAR_PRODUCTS, similarProducts as Serializable)
            data.putDouble(KEY_QUANTITY, qty)
            data.putLong(KEY_ORDER_ID, orderId)
            data.putInt(KEY_ORIGINAL_ORDER_ID, orgOrderId)
            data.putInt(KEY_ACTION_FROM, action)

            fragment.arguments = data

            return fragment
        }
    }
}