package com.app.basketiodriver.ui.cardcamera

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import com.app.basketiodriver.data.DataManager
import com.app.basketiodriver.ui.base.BaseNavigator
import com.app.basketiodriver.ui.base.BaseViewModel
import com.app.basketiodriver.ui.cardcamera.cropper2.CropDemoPreset

/**
 * Created by ibraheem lubbad on 2020-02-09.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 */
class CameraViewModel constructor(application: Application, dataManager: DataManager) :
    BaseViewModel<BaseNavigator?>(application, dataManager) {
    var previewParameter: CropDemoPreset = CropDemoPreset.RECT
    var mCropImageUri: Uri? = null
    var mPickedImageUri: Bitmap? = null


}