package com.app.basketiodriver.ui.order.adapter

import android.util.Log
import android.view.ViewGroup
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.checkout.CustomerInfo
import com.app.basketiodriver.data.model.api.response.checkout.Department
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.databinding.ItemOrderReviewListBinding
import com.app.basketiodriver.databinding.ItemReviewChangesBinding
import com.app.basketiodriver.ui.checkout.adapter.InreviewAdapter
import com.app.basketiodriver.utils.BaseRecyclerViewAdapter
import com.app.basketiodriver.utils.GlideApp

open class OrderReviewListAdapter(val activity : FragmentActivity, val listItems : List<OrdersItem>)
    : BaseRecyclerViewAdapter<OrdersItem, ItemOrderReviewListBinding>() {

    override val layoutId: Int
        get() = R.layout.item_order_review_list

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return OrderReviewHolder(createBindView(parent))
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val holder = holder as OrderReviewHolder
        val item = listItems[position]

        // Display the product image
        if (item.productImage != null) {
            GlideApp.with(activity).load(item.productImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(holder.binding.ivItem)
        }
        else{
            Log.d("OrderReview", "********** Product Image is Null *************")
        }
    }

    override fun getItemCount(): Int {
        return listItems.size
    }

    inner class OrderReviewHolder(val binding: ItemOrderReviewListBinding) :
        RecyclerView.ViewHolder(binding.root)
}