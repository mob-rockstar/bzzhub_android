package com.app.basketiodriver.data.remote

import com.app.basketiodriver.BuildConfig
import com.app.basketiodriver.data.model.api.requests.ProfileRequest
import com.app.basketiodriver.data.model.api.response.*
import com.app.basketiodriver.data.model.api.response.Base.BaseResponse
import com.app.basketiodriver.data.model.api.response.checkout.ShopperOrderDetail
import com.app.basketiodriver.data.model.api.response.checkout.ShopperOrderReview
import com.app.basketiodriver.data.model.api.response.checkout.ShopperOrderTimer
import com.app.basketiodriver.data.model.api.response.dashboard.OrderResponse
import com.app.basketiodriver.data.model.api.response.dashboard.ShopperOrderByIDResponse
import com.app.basketiodriver.data.model.api.response.earning.ShopperYearlyResponse
import com.app.basketiodriver.data.model.api.response.earning.bonus.ShopperBonusDeductionsResponse
import com.app.basketiodriver.data.model.api.response.earning.monthly.ShopperDetailsReportResponse
import com.app.basketiodriver.data.model.api.response.earning.monthly.ShopperMonthlySummaryResponse
import com.app.basketiodriver.data.model.api.response.earning.order.ShopperOrderDetailResponse
import com.app.basketiodriver.data.model.api.response.earning.payout.ShopperPayoutCreditResponse
import com.app.basketiodriver.data.model.api.response.general.SimpleResponse
import com.app.basketiodriver.data.model.api.response.hours.BookingReportResponse
import com.app.basketiodriver.data.model.api.response.hours.RateCardResponse
import com.app.basketiodriver.data.model.api.response.howamidoing.HowAmIDoingDetailResponse
import com.app.basketiodriver.data.model.api.response.howamidoing.HowAmIDoingResponse
import com.app.basketiodriver.data.model.api.response.howamidoing.ShopperRatingResponse
import com.app.basketiodriver.data.model.api.response.notification.NotificationResponse
import com.app.basketiodriver.data.model.api.response.order.*
import com.app.basketiodriver.data.model.api.response.otp.CheckOTP
import com.app.basketiodriver.data.model.api.response.profile.ProfileImageResponse
import com.app.basketiodriver.data.model.api.response.settings.SettingsResponse
import com.app.basketiodriver.data.model.api.response.shopper.ShopperResponse
import com.app.basketiodriver.data.model.api.response.terms.AgreeTermAndConditionResponse
import com.app.basketiodriver.data.model.api.response.terms.TermsAndConditionResponse
import com.app.basketiodriver.data.remote.socket.ActiveDeviceTokenResponse
import com.app.basketiodriver.data.remote.socket.SocketTokenResponse
import com.app.basketiodriver.data.remote.socket.SystemMessage
import com.app.basketiodriver.data.remote.socket.SystemMessageReq
import com.google.gson.JsonObject
import io.reactivex.Single
import okhttp3.MultipartBody
import okhttp3.RequestBody
import org.json.JSONObject
import retrofit2.http.*


/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
interface ApiInterface { /*   */
    /**
     * all api are uesed in application
     */

    @GET("config/all")
    fun getAppConfig(): Single<ShopperAppConfigResponse>

    @POST("shoppers/login")
    @FormUrlEncoded
    fun checkShopperMobile(
        @Field("mobile") number: String,
        @Field("country_code") country_code: String,
        @Field("is_otp") is_otp: Int
    ): Single<CheckMobileResponse>


    @POST("shoppers/verify/otp")
    fun verifyShopperOtp(@Body request: LoginRequest.CheckShopperOTPRequest): Single<LoginResponse>


    @POST("shoppers/login/password")
    fun verifyShopperPassword(@Body request: LoginRequest.ShopperLoginPasswordRequest): Single<LoginResponse>

    @POST("shoppers/forget/password")
    fun shopperForgetPassword(@Body request: LoginRequest.ForegetShopperPasswordRequest): Single<BaseResponse>




    @POST("shoppers/rest/password")
    fun resetShopperPassword(
        @Body request: LoginRequest.ResetShopperPasswordRequest
    ): Single<BaseResponse>


    @POST("shoppers/signup")
    fun shopperRegistration(@Body request: RegistrationRequest): Single<LoginResponse>

    @POST("shoppers/update/profile")
    fun shopperUpdateProfile(@Body request: ProfileRequest): Single<LoginResponse>

    @GET("shoppers/my/info")
    fun shopperGetInfo(): Single<LoginResponse>


    @POST("shoppers/update/password")
    @FormUrlEncoded
    fun updatePassword(
        @Field("old_password") old_password: String,
        @Field("password") password: String,
        @Field("password_confirmation") password_confirmation: String
    ): Single<BaseResponse>

    //Shopper documents
    @GET("shoppers/documents")
    fun getShopperDocuments(): Single<ShopperDocumentsResponse>


    @POST("shoppers/documents")
    fun storeShopperDocuments(@Body files: RequestBody): Single<ShopperDocumentsResponse>


    @GET("shoppers/documents/{id}")
    fun getShopperDocument(@Path("id") id: Int): Single<ShopperDocumentsResponse>

    @POST("upload-signature")
    @Multipart
    fun uploadSignature(
        @Part("shopper_id") shopper_id: RequestBody,
        @Part("token") token: RequestBody,
        @Part("signature\"; filename=\"pp.png\" ") signature: RequestBody
    ): Single<UploadDocumentResponse>

    @POST("upload-licence")
    fun uploadLicence(
        @Part("shopper_id") shopper_id: RequestBody,
        @Part("token") token: RequestBody,
        @Part("licence\"; filename=\"pp.png\" ") licence: RequestBody,
        @Part("side") side: RequestBody
    ): Single<UploadDocumentResponse>

    @POST("upload-id")
    fun uploadDocumentId(
        @Part("shopper_id") shopper_id: RequestBody,
        @Part("token") token: RequestBody,
        @Part("id_document\"; filename=\"pp.png\" ") id_document: RequestBody,
        @Part("side") side: RequestBody//required|in('front','back')
    ): Single<UploadDocumentResponse>


    @GET("shopper/nda-details")
    fun getNdaDetails(): Single<NDAResponse>


    @POST("manage_shopper_booking")
    @FormUrlEncoded
    fun shopperManageBooking(
        @Field("shopper_id") shopper_id: Long,
        @Field("token") token: String,
        @Field("selected_date") selected_date: String?,
        @Field("selected_slots") selected_slots: String?,
        @Field("action") action: String
    ): Single<ManageBookingSlotsResponse>


    @POST("shopper/earnings/details-report")
    @FormUrlEncoded
    fun earningReportDetails(
        @Field("shopper_id") shopper_id: Int,
        @Field("language_id") language_id: Int,
        @Field("type") type: String,
        @Field("year") year: Int,
        @Field("month") month: Int,
        @Field("week") week: Int,
        @Field("day") day: Int
    ): Single<EarningReportResponse>


    @FormUrlEncoded
    @POST("get_past_hours")
    fun shopperPastHourReport(
        @Field("shopper_id") shopper_id: Long,
        @Field("token") token: String,
        @Field("from_date") from_date: String,
        @Field("to_date") to_date: String
    ): Single<PastHourReportResponse>

    @POST("shopper_booking_report")
    @FormUrlEncoded
    fun shopperShiftBookingReport(
        @Field("shopper_id") shopper_id: Long,
        @Field("token") token: String,
        @Field("from_date") from_date: String,
        @Field("to_date") to_date: String
    ): Single<BookingReportResponse>

//    @POST("get_shopper_booking_slots")
//    @FormUrlEncoded
//    fun getShopperBookingSlots(
//        @Field("shopper_id") shopper_id: Long,
//        @Field("token") token: String,
//        @Field("selected_date") selected_date: String
//    ): Single<BookingSlotsResponse>


    @FormUrlEncoded
    @POST("set_shopper_vacation")
    fun setShopperVacation(
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("from_date") fromDate: String?,
        @Field("to_date") toDate: String?
    ): Single<ShopperBookingSlotsResponse>

    @POST("get_shopper_booking_slots")
    @FormUrlEncoded
    fun shopperBookingSlots(
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("selected_date") selected_date: String?,
        @Field("shopper_zone_id") shopper_zone_id: Int?
    ): Single<BookingSlotsResponse>

    @POST("get_shopper_booking_slots")
    @FormUrlEncoded
    fun shopperBookingSlots(
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("selected_date") selected_date: String?
    ): Single<BookingSlotsResponse>


    ////////////////////////////////////////////////////////////////
    // Login with password
    @FormUrlEncoded
    @POST("shopper-login")
    fun loginWithPassword(
                          @Field("language") langCode: Int,
                          @Field("mobile") mobile: String,
                          @Field("password") password: String,
                          @Field("device_id") deviceId: String,
                          @Field("device_token") token: String
    ) : Single<Login>

    // Reset Password
    @FormUrlEncoded
    @POST("shopper-forgot-password")
    fun sendForgotPasswordRequest(
        @Field("language") langCode: Int,
        @Field("mobile") mobile: String
    ) : Single<SimpleResponse>

    // Verify OTP
    @FormUrlEncoded
    @POST("check-shopper-otp")
    fun verifyOTP(
        @Field("language") langCode: Int,
        @Field("mobile") mobile: String,
        @Field("otp") otp: String
    ) : Single<CheckOTP>

    // Set new password
    @FormUrlEncoded
    @POST("change-shopper-pwd")
    fun changeShopperPassword(
        @Field("language") langCode: Int,
        @Field("mobile") mobile: String,
        @Field("password") password: String,
        @Field("password_confirmation") confirmPassword: String
    ) : Single<SimpleResponse>

    // Update password
    @FormUrlEncoded
    @POST("update-shopper-pwd")
    fun updateShopperPassword(
        @Field("language") langCode: Int,
        @Field("mobile") mobile: String,
        @Field("old_password") oldPassword: String,
        @Field("password") password: String,
        @Field("password_confirmation") confirmPassword: String,
        @Field("shopper_id") shopperId: Long,
        @Field("token") token: String
    ) : Single<SimpleResponse>

    // Shopper Details
    @FormUrlEncoded
    @POST("new_shopper_detail")
    fun shopperDetailRequest(
        @Field("language") langCode: Int,
        @Field("shopper_id") shopperId: Long,
        @Field("token") token: String
    ) : Single<ShopperResponse>

    // Update Profile Image
    @Multipart
    @POST("update-shopper-profile-image")
    fun shopperUpdateProfileImage(
        @Part("language") langCode: RequestBody?,
        @Part("shopper_id") shopperId: RequestBody?,
        @Part("token") token: RequestBody?,
        @Part image : MultipartBody.Part?
    ) : Single<ProfileImageResponse>

    // Get ShopperBookingReport
    @FormUrlEncoded
    @POST("shopper_booking_report")
    fun shopperBookingReport(
        @Field("language_id") language_id: Int,
        @Field("shopper_id") shopperId: Long,
        @Field("token") token: String,
        @Field("from_date") fromDate: String,
        @Field("to_date") toDate: String
    ): Single<BookingReportResponse>

    // Get ShopperPastHoursReport
    @FormUrlEncoded
    @POST("get_past_hours")
    fun getShopperPastHourReport(
        @Field("language_id") language_id: Int,
        @Field("shopper_id") shopperId: Long,
        @Field("token") token: String,
        @Field("from_date") fromDate: String,
        @Field("to_date") toDate: String?
    ): Single<PastHourReportResponse>


    // Get shopper BookingSlots
    @FormUrlEncoded
    @POST("get_shopper_booking_slots")
    fun getShopperBookingSlots(
        @Field("language_id") language_id: Int,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("selected_date") selectedDate: String?
    ): Single<BookingSlotsResponse>

    // Get shopper BookingSlots
    @FormUrlEncoded
    @POST("get_shopper_booking_slots")
    fun getShopperBookingSlotsWithZone(
        @Field("language_id") language_id: Int,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("selected_date") selectedDate: String?,
        @Field("shopper_zone_id") zoneId: String?
    ): Single<BookingSlotsResponse>

    // Get Zones
    @FormUrlEncoded
    @POST("get_shopper_zones")
    fun getShopperZones(
        @Field("language_id") language_id: Int,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("selected_date") selectedDate: String?
    ): Single<ShopperZonesResponse>

    // Get Shopper Rate
    @FormUrlEncoded
    @POST("get_shopper_rate_card")
    open fun getShopperRateCard(
        @Field("language_id") language_id: Int,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("rate_date") selectedDate: String?
    ): Single<RateCardResponse>

    // Update the Shopper Booking
    @FormUrlEncoded
    @POST("manage_shopper_booking")
    fun manageShopperBooking(
        @Field("language_id") language_id: Int,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("selected_date") selectedDate: String?,
        @Field("selected_slots") selectedSlots: String?,
        @Field("action") action: String?
    ): Single<ManageBookingSlotsResponse>

    // Shopper Yearly Balance
    @FormUrlEncoded
    @POST("shopper_yearly_account_report")
    fun shopperYearlyAccountBalanceReport(
        @Field("language_id") language_id: Int,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("num_record") numbOfRecord: Int,
        @Field("year") year: Int
    ): Single<ShopperYearlyResponse>

    // Shopper Monthly Balance
    @FormUrlEncoded
    @POST("shopper_monthly_account_report")
    fun shopperMonthlyAccountReport(
        @Field("language_id") language_id: Int,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("month") month: Int,
        @Field("year") year: Int
    ): Single<ShopperMonthlySummaryResponse>

    // Shopper Monthly Details Report
    @FormUrlEncoded
    @POST("shopper_details_report")
    fun shopperDetailsReport(
        @Field("language_id") language_id: Int,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("report_type") report_type: String?,
        @Field("week_or_day_number") week_or_day_number: Int,
        @Field("month") month: Int,
        @Field("year") year: Int
    ): Single<ShopperDetailsReportResponse>

    // Payout & Credit details
    @FormUrlEncoded
    @POST("get_shopper_payout_credit_details")
    fun getShopperPayoutCreditDetails(
        @Field("language_id") language_id: Int,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("request_type") type: String?,
        @Field("month") month: Int,
        @Field("year") year: Int
    ): Single<ShopperPayoutCreditResponse>

    // Bonus & Deductions
    @FormUrlEncoded
    @POST("get_shopper_bonus_deduction_details")
    fun getShopperBonusDeductionDetails(
        @Field("language_id") language_id: Int,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("request_type") type: String?,
        @Field("month") month: Int,
        @Field("year") year: Int
    ): Single<ShopperBonusDeductionsResponse>

    @FormUrlEncoded
    @POST("get_shopper_order_details")
    fun getShopperOrderDetailsReport(
        @Field("language_id") language_id: Int,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("order_outlet_id") orderId: String?,
        @Field("month") month: Int,
        @Field("year") year: Int
    ): Single<ShopperOrderDetailResponse>

    // How am I doing
    @FormUrlEncoded
    @POST("how_am_i_doing")
    fun howAmIDoing(
        @Field("language_id") language_id: Int,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?
    ): Single<HowAmIDoingResponse>

    // How am I doing Details
    @FormUrlEncoded
    @POST("how_am_i_doing_details")
    fun howAmIDoingDetails(
        @Field("language_id") language_id: Int,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("detail_tab") action: String?
    ): Single<HowAmIDoingDetailResponse>

    // Shopper Rating Details
    @FormUrlEncoded
    @POST("shopper_rating_details")
    fun shopperRatingDetails(
        @Field("language_id") language_id: Int,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("detail_tab") type: String?
    ): Single<ShopperRatingResponse>

    // Shopper Service Token
    @FormUrlEncoded
    @POST("shopper/get-service-app-token")
    fun getServiceAppToken(
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?
    ): Single<ServerTokenResponse>

    // Change the shopper status
    @FormUrlEncoded
    @POST("new_shopper_update_online_status")
    fun shopperChangeOnlineStatus(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("shopper_online_status") status: Int?,
        @Field("is_start_early") is_start_early: Int?
    ): Single<SimpleResponse>

    // Order list
    @FormUrlEncoded
    @POST("shopper-order-dashboard")
    fun getOrders(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("limit") count: Int?,
        @Field("offset") page: Int?
    ): Single<OrderResponse>


    @FormUrlEncoded
    @POST("shopper-map-order-detail")
    fun getShopperOrdersById(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("order_outlet_id") orderId: Long?
    ): Single<ShopperOrderByIDResponse>

    // Shopper Update Status
    @FormUrlEncoded
    @POST("shopper-update-order-status")
    fun shopperUpdateStatusRequest(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("shopper_status") shopperStatus: Int?,
        @Field("order_status") orderStatus: Int?,
        @Field("order_outlet_id") orderId: Long?
    ): Single<SimpleResponse>

    // Shopper Order Details
    @FormUrlEncoded
    @POST("shopper-order-detail")
    fun shopperOrdersDetailRequest(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("order_outlet_id") orderId: String?,
        @Field("fastest_route") fastest_route: String?
    ): Single<ShopperOrderDetail>

    // Shopper Order Timer
    @FormUrlEncoded
    @POST("shopper-order-timer")
    fun shopperOrderTimerRequest(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("order_outlet_id") orderId: Long?
    ): Single<ShopperOrderTimer>

    // Shopper Order Review(Detail)
    @FormUrlEncoded
    @POST("shopper-order-review")
    fun getShopperOrderReview(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("order_outlet_id") orderOutletId: Long?
    ): Single<ShopperOrderReview>

    // Dashboard order review
    @FormUrlEncoded
    @POST("shopper-order-dashboard-info")
    fun getDashboardOrderInfo(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("order_outlet_id") orderId: Long?
    ): Single<DashboardOrderInfoResponse>

    @FormUrlEncoded
    @POST("shopper-order-history-info")
    fun getHistoryOrderInfo(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("order_outlet_id") OrderId: Long?
    ): Single<HistoryOrderInfoResponse>

    @FormUrlEncoded
    @POST("shopper_item_not_found_reasons")
    fun getCanNotFindItemReasonList(
        @Field("language_id") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?
    ): Single<CommonResponse>

    @FormUrlEncoded
    @POST("shopper-replace-fulfillment-status")
    fun requestConfirmReplacedItem(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("orders_outlets_items_id") itemsId: Long?,
        @Field("quantity") qty: Double?
    ): Single<SimpleResponse>

    @FormUrlEncoded
    @POST("shopper-remove-replacement-item")
    fun requestCancelReplacedItem(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("orders_outlets_items_id") itemsId: Long?
    ): Single<SimpleResponse>

    // Mark as found
    @FormUrlEncoded
    @POST("shopper-find-item")
    fun shopperMarkItemAsFound(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("orders_outlets_items_id") itemsId: Long?,
        @Field("found_status") foundStatus: Int?,
        @Field("qty_status") qtyStatus: Int?,
        @Field("price_status") priceStatus: Int?
    ): Single<SimpleResponse>

    // Update the item qty
    @FormUrlEncoded
    @POST("shopper-update-item-qty")
    fun requestUpdateItemQty(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("orders_outlets_items_id") itemsId: Long?,
        @Field("qty") qty: Double?
    ): Single<SimpleResponse>

    @FormUrlEncoded
    @POST("shopper-approve-item-qty-diff")
    fun requestItemConfirmQtyDifference(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("orders_outlets_items_id") itemsId: Long?
    ): Single<SimpleResponse>

    @FormUrlEncoded
    @POST("shopper-unapprove-item-qty-diff")
    fun requestCancelItemQtyDifference(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("orders_outlets_items_id") itemsId: Long?
    ): Single<SimpleResponse>

    @FormUrlEncoded
    @POST("shopper-unremove-item")
    fun requestCancelRefund(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("orders_outlets_items_id") itemsId: Long?
    ): Single<SimpleResponse>

    // Update the item weight
    @FormUrlEncoded
    @POST("shopper-update-actual-weight")
    fun updateActualWeight(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("orders_outlets_items_id") itemsId: Long?,
        @Field("actual_weight") weight: Double?,
        @Field("actual_qty") qty: Double?
    ): Single<SimpleResponse>

    // set the item not found reason
    @FormUrlEncoded
    @POST("shopper_order_item_reason")
    fun setItemNotFoundReason(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("order_id") orderId: Long?,
        @Field("order_outlet_id") orderOutletId: Long?,
        @Field("order_item_id") OrderItemId: Int?,
        @Field("reason_id") reasonId: Int?
    ): Single<CommonResponse>

    // Get suggested product list
    @FormUrlEncoded
    @POST("similar_products_basket_suggestion")
    fun shopperSuggestionProductList(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("orders_outlet_item_id") itemsId: Long?,
        @Field("orders_outlet_id") orderId: Long?,
        @Field("product_search") search: String?
    ): Single<SuggestionResponse>

    // Refund item
    @FormUrlEncoded
    @POST("refund_item_from_order")
    fun itemRefund(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("orders_outlets_items_id") itemsId: Long?,
        @Field("action_from") action: Int
    ): Single<CommonResponse>

    @FormUrlEncoded
    @POST("check_product_barcode")
    fun checkProductBarcode(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("orders_outlets_items_id") itemsId: Long?,
        @Field("bar_code") barcode: String?,
        @Field("is_replacement_item") isReplace: Int?, //
        @Field("replacement_outlet_item_id") replacementItemId: Long?
    ): Single<CommonResponse>

    @Multipart
    @POST("shopper/send-force-mark-as-found-detail")
    fun addForceMarkAsFound(
        @Part("language_id") lang_code : RequestBody?,
        @Part("shopper_id")  shopperId : RequestBody?,
        @Part("token")  token : RequestBody?,
        @Part("order_outlet_id")  orderOutletId : RequestBody?,
        @Part("original_item_id")  originalItemId : RequestBody?,
        @Part("scanned_upc")  barcode : RequestBody?,
        @Part image : MultipartBody.Part?
    ):Single<SimpleDataResponse>

    // Similar product list
    @FormUrlEncoded
    @POST("similar-product-list")
    fun shopperSimilarProductList(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("orders_outlets_items_id") itemsId: Long?,
        @Field("is_custom_item") isCustomItem: Int?,
        @Field("product_search") search: String?
    ): Single<SimilarResponse>

    // Add product list by searching
    @FormUrlEncoded
    @POST("similar-product-list")
    fun shopperAddProductList(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("orders_outlets_items_id") itemsId: Long?,
        @Field("product_search") search: String?
    ): Single<SimilarResponse>

    // Replace Item to be done
    @FormUrlEncoded
    @POST("shopper-replace-item-to-done")
    open fun shopperReplaceItemToDone(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("orders_outlet_id") orderId: Long?,
        @Field("item_qty") qty: Double?,
        @Field("item_weight") weight: Double?,  //optional
        @Field("original_item_id") oldItemId: Long?,
        @Field("replacement_item_id") newItemId: Long?,
        @Field("action_from") actionFrom: Int?
    ): Single<SimilarResponse>

    @FormUrlEncoded
    @POST("replace_item_from_order")
    fun shopperReplaceItem(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("item_qty") qty: Double?,
        @Field("original_item_id") oldItemId: Long?,
        @Field("replacement_item_id") newItemId: Long?,
        @Field("orders_outlet_id") orderId: Long?,
        @Field("action_from") actionFrom: Int?
    ): Single<CommonResponse>

    // Multiple replacement
    @POST("replace_multiple_items_from_order")
    fun shopperReplaceMultipleItems(@Body params : JsonObject): Single<CommonResponse>

    @FormUrlEncoded
    @POST("outlet-item-by-upc")
    fun getProductByBarcode(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("order_outlet_id") orderOutletId: Long?,
        @Field("bar_code") barcode: String?
    ): Single<ItemResponse>

    @FormUrlEncoded
    @POST("check-custom-item-by-shopper")
    fun getCheckItemByBarcode(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("order_outlet_id") OrderId: Long?,
        @Field("bar_code") barcode: String?
    ): Single<SimpleResponse>

    @FormUrlEncoded
    @POST("add-item-by-shopper")
    fun addItemByBarcode(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("order_outlet_id") orderId: Long?,
        @Field("bar_code") barcode: String?,
        @Field("quantity") qty: Double?,
        @Field("item_by_scan") isScan: Int?
    ): Single<SimpleResponse>

    @Multipart
    @POST("add-custom-item-by-shopper")
    fun addCustomProduct(
        @Part("language") lang_code: RequestBody?,
        @Part("shopper_id") shopperId: RequestBody?,
        @Part("token") token: RequestBody?,
        @Part("order_outlet_id") OrderId: RequestBody?,
        @Part("bar_code") barcode: RequestBody?,
        @Part("product_name") name: RequestBody?,
        @Part image: MultipartBody.Part?,
        @Part("does_not_contain") isContain: RequestBody?,
        @Part("product_sold_type") sold_type: RequestBody?,
        @Part("units") unit: RequestBody?,
        @Part("price_per_unit") pricePerUnit: RequestBody?
    ): Single<SimpleResponse>

    @Multipart
    @POST("replace-custom-item-by-shopper")
    fun replaceCustomProduct(
        @Part("language") lang_code: RequestBody?,
        @Part("shopper_id") shopperId: RequestBody?,
        @Part("token") token: RequestBody?,
        @Part("orders_outlets_items_id") OrderId: RequestBody?,
        @Part("bar_code") barcode: RequestBody?,
        @Part("product_name") name: RequestBody?,
        @Part image: MultipartBody.Part?,
        @Part("does_not_contain") isContain: RequestBody?,
        @Part("product_sold_type") sold_type: RequestBody?,
        @Part("units") unit: RequestBody?,
        @Part("price_per_unit") pricePerUnit: RequestBody?
    ): Single<SimpleResponse>

    @FormUrlEncoded
    @POST("shopper-flag-item")
    fun shopperFlagItemRequest(
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("outlet_item_id") orderId: Long?,
        @Field("reason") reason: Int?
    ): Single<SimpleResponse>

    @FormUrlEncoded
    @POST("shopper-update-sub-total")
    fun shopperUpdateSubtotalRequest(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("orders_outlet_id") orderId: Long?,
        @Field("sub_total") subtotal: Double?
    ): Single<SimpleResponse>

    @Multipart
    @POST("shopper_add_order_receipt")
    fun shopperSendOrderReceiptNew(
        @Part("language") lang_code: RequestBody?,
        @Part("shopper_id") shopperId: RequestBody?,
        @Part("token") token: RequestBody?,
        @Part("orders_outlet_id") orderId: RequestBody?,
        @Part image: Array<MultipartBody.Part?>?,
        @Part("store_receipt_number") store_receipt_number: RequestBody?
    ): Single<CommonResponse>

    @FormUrlEncoded
    @POST("shopper/update-handover-code-to-order")
    fun updateHandOverCode(
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("order_id") orderId: Long?,
        @Field("orders_outlet_id") orderOutletId: Long?
    ): Single<HandoverCodeResponse>

    @FormUrlEncoded
    @POST("shopper/verify-code-for-handover-order")
    fun verifyHandOverCode(
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("handover_code") handOverCode: String?
    ): Single<HandoverCodeResponse>

    @FormUrlEncoded
    @POST("order-amount-from-customer")
    fun amountFromCustomer(
        @Field("language") lang_code: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("order_outlet_id") orderOutletId: Long?,
        @Field("received_by_customer") receivedByCustomer: Double?,
        @Field("returned_to_customer") returnedToCustomer: Double?
    ): Single<SimpleResponse>

    @FormUrlEncoded
    @POST("shopper/get-terms-condition-details")
    fun shopperTermsAndCondition(
        @Field("language_id") language_id: Int,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?
    ): Single<TermsAndConditionResponse>

    @FormUrlEncoded
    @POST("shopper/agree-terms-condition-details")
    fun agreeTermsAndCondition(
        @Field("language_id") language_id: Int,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?
    ): Single<AgreeTermAndConditionResponse>

    @FormUrlEncoded
    @POST("shopper/store_pocket_money")
    fun storePocketMoney(
        @Field("language_id") language_id: Int,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("pocket_money") pocketMoney: Double?
    ): Single<SimpleResponse>

    @FormUrlEncoded
    @POST("get-user-device-information")
    fun getDeviceTokenList(
        @Field("language") languageId: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("user_type") userType: String
    ): Single<ActiveDeviceTokenResponse>

    @FormUrlEncoded
    @POST("shopper/get-service-app-token")
    fun getSocketToken(
        @Field("language") languageId: Int?,
        @Field("shopper_id") userId: Long,
        @Field("token") token: String
    ): Single<SocketTokenResponse>

    @POST("${BuildConfig.CHAT_SERVER_URL}/v1.0/upload")
    @Multipart
    fun uploadChatAttachment(
        @Header("Authorization") token: String,
        @Part attachment: MultipartBody.Part?,
        @Part("file_type") messageType: RequestBody?,
        @Part("order_id") orderId: RequestBody?,
        @Part("user_type") userType: RequestBody?,
        @Part("user_id") userId: RequestBody?
    ): Single<com.app.basketiodriver.data.model.api.chat.BaseResponse>

    @POST("${BuildConfig.CHAT_SERVER_URL}/v1.0/chat/system/message")
    fun sendSystemMessage(
        @Body  systemMessageReq : SystemMessageReq, @Header("Authorization")  token :String
    ): Single<SystemMessage>

    @FormUrlEncoded
    @POST("check-app-version")
    fun checkAppVersion(
        @Field("language") langCode: Int?,
        @Field("device") device: String?,
        @Field("version_number") versionNumber: String?,
        @Field("build_number") buildNumber: String?,
        @Field("app_id") appId: String?
    ): Single<AppVersion>

    @FormUrlEncoded
    @POST("shopper/notifications")
    fun shopperNotification(
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?
    ): Single<NotificationResponse>

    // Get order otp
    @FormUrlEncoded
    @POST("get-order-otp")
    fun getOrderOTP(
        @Field("language") langCode: Int?,
        @Field("shopper_id") shopperId: Long?,
        @Field("token") token: String?,
        @Field("order_outlet_id") orderOutletId: Long?
    ): Single<OrderOTPResponse>

    // Get the contact settings
    @GET("contact-settings")
    fun getContactSettings(
        @Query("country_id") countryId : Int,
        @Query("city_id") cityId : Int
    ) : Single<SettingsResponse>
}