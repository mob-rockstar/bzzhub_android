package com.app.basketiodriver.ui.howdoing

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.Navigation
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.ActivityHowDoingBinding
import com.app.basketiodriver.ui.base.BaseActivity
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import javax.inject.Inject

class HowDoingActivity : BaseActivity<ActivityHowDoingBinding?, HowIamDoingViewModel>(),

    HasAndroidInjector {


    override val layoutId: Int
        get() = R.layout.activity_how_doing

    override val viewModel: HowIamDoingViewModel
        get() {
            return getViewModel(HowIamDoingViewModel::class.java)
        }


    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initToolbar(getString(R.string.how_i_am_doing),
            true, viewDataBinding!!.layoutToolBar.toolbar,
            View.OnClickListener {
                run {
                    if (!Navigation.findNavController(this, R.id.navHowIamDoing).popBackStack()
                    ) {
                        finish()
                    }
                }
            })
    }

    companion object {
        fun newIntent(context: Context?): Intent {
            return Intent(context, HowDoingActivity::class.java)
        }
    }

}
