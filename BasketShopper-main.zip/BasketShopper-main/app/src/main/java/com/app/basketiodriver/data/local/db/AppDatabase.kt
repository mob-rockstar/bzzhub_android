
package com.app.basketiodriver.data.local.db

import androidx.room.Database
import androidx.room.RoomDatabase
import com.app.basketiodriver.data.local.db.dao.OnbaordingStagesDao
import com.app.basketiodriver.data.local.db.dao.UserDao
import com.app.basketiodriver.data.model.api.User
import com.app.basketiodriver.data.model.db.OnbaordingStages
import com.app.basketiodriver.utils.AppConstants

/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
@Database(entities = [User::class,OnbaordingStages::class], version = AppConstants.DB_VERSION )
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun onbaordingStagesDao(): OnbaordingStagesDao
}