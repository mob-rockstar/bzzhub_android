package com.app.basketiodriver.data.model.api.response.order

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName
import java.io.Serializable
import java.util.*


class SimilarProduct : Serializable {
    @SerializedName("outlet_id")
    @Expose
    val outletId: Long? = null

    @SerializedName("outlet_item_id")
    @Expose
    val outletItemId: Int? = null

    @SerializedName("product_name")
    @Expose
    val productName: String? = null

    @SerializedName("shopper_tips")
    @Expose
    val shopperTips: String? = null

    @SerializedName("department_name")
    @Expose
    val departmentName: String? = null

    @SerializedName("aisle_name")
    @Expose
    val aisleName: String? = null

    @SerializedName("sold_per")
    @Expose
    val soldPer: Int = 0

    @SerializedName("sold_per_label")
    @Expose
    val soldPerLabel: String? = null

    @SerializedName("label_value")
    @Expose
    val labelValue: String = ""

    @SerializedName("size_label")
    @Expose
    val sizeLabel: Int? = null

    @SerializedName("approx_weight")
    @Expose
    val approxWeight: Double = 0.0

    @SerializedName("each_suffix")
    @Expose
    val eachSuffix: Int = 0

    @SerializedName("our_selling_price")
    @Expose
    val ourSellingPrice: Double = 0.0

    @SerializedName("unit")
    @Expose
    val unit: String = ""

    @SerializedName("product_image")
    @Expose
    val productImage: String? = null

    @SerializedName("product_info_image")
    @Expose
    val productInfoImage: String? = null

    @SerializedName("bar_code")
    @Expose
    val barCode: String? = null


    @SerializedName("upc_type")
    @Expose
    val upcType = 0

    @SerializedName("previous_shopper_suggested_item")
    @Expose
    val previousShopperSuggestedItem: List<SimilarProductPrevious>? = null

    fun getDescriptionLabel() : String {
        return when (soldPer) {
            1 -> String.format(
                Locale.ENGLISH,
                "%s %s",
                labelValue.trim(),
                unit.trim()
            )
            2 -> ""
            3 -> String.format(
                Locale.ENGLISH,
                "%s %s each",
                approxWeight,
                unit.trim()
            )
            else -> "each"
        }
    }

    fun getDescriptionLabelNew() : String {
        return when (soldPer) {
            1 -> String.format(
                Locale.ENGLISH,
                "%s %s each",
                labelValue.trim(),
                unit.trim()
            )
            2 -> ""
            3 -> String.format(
                Locale.ENGLISH,
                "around %s %s each",
                approxWeight,
                unit.trim()
            )
            else -> "each"
        }
    }
}