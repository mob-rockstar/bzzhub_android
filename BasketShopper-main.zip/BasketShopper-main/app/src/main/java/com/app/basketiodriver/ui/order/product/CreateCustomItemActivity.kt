package com.app.basketiodriver.ui.order.product

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Parcelable
import android.provider.MediaStore
import android.text.Editable
import android.text.InputType.TYPE_CLASS_NUMBER
import android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.core.net.toFile
import androidx.fragment.app.Fragment
import app.basket.scanner.BasketScanner
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.general.SimpleResponse
import com.app.basketiodriver.data.remote.socket.ChatMessageHelper
import com.app.basketiodriver.data.remote.socket.SystemMessage
import com.app.basketiodriver.data.remote.socket.SystemMessageReq
import com.app.basketiodriver.databinding.ActivityCreateCustomItemBinding
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.app.basketiodriver.ui.dashbaord.OrdersManager
import com.app.basketiodriver.utils.AppConstants
import com.app.basketiodriver.utils.GlideApp
import com.tbruyelle.rxpermissions2.RxPermissions
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import io.reactivex.android.schedulers.AndroidSchedulers
import pl.aprilapps.easyphotopicker.DefaultCallback
import pl.aprilapps.easyphotopicker.EasyImage
import pl.aprilapps.easyphotopicker.MediaFile
import pl.aprilapps.easyphotopicker.MediaSource
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.*
import javax.inject.Inject


open class CreateCustomItemActivity :
    BaseActivity<ActivityCreateCustomItemBinding, OrderDetailsViewModel>(),
    HasAndroidInjector {
    override val layoutId: Int
        get() = R.layout.activity_create_custom_item

    override val viewModel: OrderDetailsViewModel
        get() {
            return getViewModel(OrderDetailsViewModel::class.java)
        }

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    val IMAGE_DIRECTORY: String = android.os.Environment.DIRECTORY_DCIM

    var symbols: DecimalFormatSymbols = DecimalFormatSymbols(Locale.ENGLISH)
    var formatter: DecimalFormat = DecimalFormat("#.## ", symbols)

    var barcode: String = ""
    var orderId: Long = 0

    // Image File
    var imageFile: File? = null

    val BARCODE_ACTIVITY = 541

    private lateinit var easyImage: EasyImage

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (intent.extras != null) {
            orderId = intent.extras!!.getLong("ARG_ORDER_ID")
            barcode = intent.extras!!.getString("ARG_BARCODE", "")
        }

        // Init toolbar
        initToolBar()

        initView()

        // Initialize the EasyImage Instance
        easyImage = EasyImage.Builder(this).setCopyImagesToPublicGalleryFolder(false)
            .allowMultiple(false)
            .build()
    }

    private fun initToolBar() {
        initToolbar(getString(R.string.other_replacement),
            true, viewDataBinding!!.layoutToolBar.toolbar,
            View.OnClickListener {
                run {
                    onBackPressed()
                }
            })
    }

    private fun initView() {
        // set the barcode
        viewDataBinding!!.tvBarcode.setText(barcode)

        // Set the corner-rounded image
        viewDataBinding!!.ivCapturedPhoto.clipToOutline = true

        // currency
        viewDataBinding!!.titlePr.text = PreferenceManager.currency

        if (viewDataBinding!!.rbUnit.isChecked) {
            viewDataBinding!!.rbKg.isChecked = true
            viewDataBinding!!.etCount.setHint(R.string.how_much_weight)
            viewDataBinding!!.etPrice.setHint(R.string.price_per_kg)
            viewDataBinding!!.etCount.inputType = TYPE_CLASS_NUMBER or TYPE_NUMBER_FLAG_DECIMAL
        } else {
            viewDataBinding!!.rbUnit.isChecked = true
            viewDataBinding!!.etCount.setHint(R.string.how_many_unit)
            viewDataBinding!!.etPrice.setHint(R.string.price_per_unit)
            viewDataBinding!!.etCount.inputType = TYPE_CLASS_NUMBER
        }

        // capture image
        viewDataBinding!!.imgAdd.setOnClickListener {
            pickUpImage()
        }

        // Remove the captured image
        viewDataBinding!!.ivRemovePhoto.setOnClickListener {
            viewDataBinding!!.photoView.visibility = View.GONE
            viewDataBinding!!.imgAdd.visibility = View.VISIBLE
        }

        // Add item
        viewDataBinding!!.btAddItem.setOnClickListener {
            add()
        }

        // Unit
        viewDataBinding!!.rbUnit.setOnClickListener {
            clickedUnit()
        }

        // Kg
        viewDataBinding!!.rbKg.setOnClickListener {
            clickedKg()
        }


        // Text change listener for count & price
        viewDataBinding!!.etCount.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Calculate the total price
                calculateTotal()
            }
        })

        viewDataBinding!!.etPrice.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Calculate the total price
                calculateTotal()
            }
        })

        // Found item
        viewDataBinding!!.txtFoundItem.setOnClickListener {
            scan()
        }
    }

    // pick up the image
    private fun pickUpImage() {
        if (imageFile != null) {
            imageFile!!.deleteOnExit()
            imageFile = null
        }

//        val galleryIntent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
//        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
//
//        val chooserIntent: Intent = Intent.createChooser(galleryIntent, getString(R.string.select_image))
//        chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(cameraIntent))
//        startActivityForResult(chooserIntent, ARG_IMAGE_REQ)

        openImagePicker()
    }

    // Open Image Picker to select the profile image
    @SuppressLint("CheckResult")
    private fun openImagePicker() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            RxPermissions(this).request(
                Manifest.permission.CAMERA, Manifest.permission.READ_MEDIA_IMAGES
            )
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe { granted ->
                    if (granted) {
                        easyImage.openChooser(this)
                    }
                }
        } else {
            RxPermissions(this).request(
                Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe { granted ->
                    if (granted) {
                        easyImage.openChooser(this)
                    }
                }
        }


    }

    // add item
    private fun add() {
        if (!validateName(false))
            return
        if (!validateCount(false))
            return
        if (!validatePrice(false))
            return

        // Dismiss the keyboard
        hideKeyboard()

        val count = getDouble(viewDataBinding!!.etCount)
        val price = getDouble(viewDataBinding!!.etPrice)
        val name = viewDataBinding!!.etName.text.toString()

//        val doesNotContain = if (viewDataBinding!!.swContain.isChecked) 1 else 0
        val unit =
            if (viewDataBinding!!.rbUnit.isChecked) getString(R.string.unit) else getString(R.string.kg)

        // add product to server
        addProductToServer(orderId, barcode, name, imageFile, 0, unit, count, price)
    }

    // Add product to server
    private fun addProductToServer(
        orderId: Long,
        barcode: String,
        name: String,
        file: File?,
        contain: Int,
        unit: String,
        count: Double,
        price: Double
    ) {
        viewModel.addCustomProduct(
            orderId,
            barcode,
            name,
            file,
            contain,
            unit,
            count,
            price,
            object : HandleResponse<SimpleResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    Toast.makeText(
                        this@CreateCustomItemActivity,
                        error?.message,
                        Toast.LENGTH_SHORT
                    ).show()
                }

                override fun handleSuccessResponse(successResponse: SimpleResponse) {
                    val response = successResponse.response
                    if (response != null) {
                        Toast.makeText(
                            this@CreateCustomItemActivity,
                            response.message,
                            Toast.LENGTH_SHORT
                        ).show()

                        if (response.httpCode == 200) {
                            // ChatMessageHelper
                            // Send message
                            ////////////////////
                            val message =
                                AppConstants.MESSAGE_TYPE_ADD + " " + PreferenceManager.currentShopperFirstName + " " + getString(
                                    R.string.added
                                ) + " " + name
                            val systemMessageReq =
                                SystemMessageReq(orderId.toString(), "text", message!!)
                            sendSysteMessage(systemMessageReq)
                        }
                    } else {
                        Toast.makeText(
                            this@CreateCustomItemActivity,
                            R.string.cant_add_product,
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            })
    }

    fun sendSysteMessage(systemMessageReq: SystemMessageReq) {
        viewModel.sendSystemMessage(systemMessageReq, object : HandleResponse<SystemMessage> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                onAfterSendSystemMessage()
            }

            override fun handleSuccessResponse(successResponse: SystemMessage) {
                onAfterSendSystemMessage()
            }
        })
    }

    private fun onAfterSendSystemMessage() {
        try {
            if (imageFile != null)
                imageFile!!.delete()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Close the current page
        finish()
    }

    // Validate name
    fun validateName(focus: Boolean): Boolean {
        if (!focus && viewDataBinding!!.etName.text != null) {
            if (viewDataBinding!!.etName.text.toString().isEmpty()) {
//                viewDataBinding!!.etName.setError(getString(R.string.empty_name))
                Toast.makeText(this, R.string.empty_name, Toast.LENGTH_SHORT).show()
                return false
            } else if (viewDataBinding!!.etName.text.toString().length <= 3) {
//                viewDataBinding!!.etName.setError(getString(R.string.small_name))
                Toast.makeText(this, R.string.small_name, Toast.LENGTH_SHORT).show()
                return false
            } else {
//                viewDataBinding!!.etName.setError(null)
            }
        }
        return true
    }

    // Validate count
    fun validateCount(focus: Boolean): Boolean {
        if (!focus && viewDataBinding!!.etCount.text != null) {
            if (viewDataBinding!!.etCount.text.toString().isEmpty()) {
//                viewDataBinding!!.etCount.setError(getString(R.string.empty_count))
                Toast.makeText(this, R.string.empty_count, Toast.LENGTH_SHORT).show()
                return false
            } else {
                try {
                    getDouble(viewDataBinding!!.etCount)
//                    viewDataBinding!!.etCount.setError(null)
                } catch (e: Exception) {
//                    viewDataBinding!!.etCount.setError(getString(R.string.incorrect_count))
                    Toast.makeText(this, R.string.incorrect_count, Toast.LENGTH_SHORT).show()
                    return false
                }

            }

            calculateTotal()
        }
        return true
    }

    // Validate price
    fun validatePrice(focus: Boolean): Boolean {
        if (!focus && viewDataBinding!!.etPrice.text != null) {
            if (viewDataBinding!!.etPrice.text.toString().isEmpty()) {
//                viewDataBinding!!.etPrice.setError(getString(R.string.empty_price))
                Toast.makeText(this, R.string.empty_price, Toast.LENGTH_SHORT).show()
                return false
            } else {
                try {
                    val p = getDouble(viewDataBinding!!.etPrice)
//                    viewDataBinding!!.etPrice.setError(null)

                    val c = getDouble(viewDataBinding!!.etCount)
                    if (c <= 0) {
//                        viewDataBinding!!.etCount.error = getString(R.string.enter_correct_value)
                        Toast.makeText(this, R.string.enter_correct_value, Toast.LENGTH_SHORT)
                            .show()
                        return false
                    }

                    if (p <= 0) {
//                        viewDataBinding!!.etPrice.error = getString(R.string.incorrect_price)
                        Toast.makeText(this, R.string.incorrect_price, Toast.LENGTH_SHORT).show()
                        return false
                    }
                } catch (e: Exception) {
//                    viewDataBinding!!.etPrice.setError(getString(R.string.incorrect_price))
                    Toast.makeText(this, R.string.incorrect_price, Toast.LENGTH_SHORT).show()
                    return false
                }
            }

            calculateTotal()
        }
        return true
    }

    // Calculate the total price whenever changed the price or count
    private fun calculateTotal() {
        if (viewDataBinding!!.etPrice.text != null && viewDataBinding!!.etPrice.text.toString()
                .isNotEmpty() &&
            viewDataBinding!!.etCount.text != null && viewDataBinding!!.etCount.text.toString()
                .isNotEmpty()
        ) {
            try {
                val count = getDouble(viewDataBinding!!.etCount)
                val price = getDouble(viewDataBinding!!.etPrice)

                viewDataBinding!!.tvTotal.text = String.format(
                    Locale.US,
                    "%s %.2f",
                    PreferenceManager.currency,
                    (formatter.format(count * price).toDoubleOrNull() ?: 0.00)
                )
            } catch (e: Exception) {
                viewDataBinding!!.tvTotal.text =
                    String.format(Locale.US, "%s 0.00", PreferenceManager.currency)
            }
        } else {
            viewDataBinding!!.tvTotal.text =
                String.format(Locale.US, "%s 0.00", PreferenceManager.currency)
        }
    }

    // Get double value from edit text
    fun getDouble(view: EditText): Double {
        return view.text.toString().toDoubleOrNull() ?: 0.0
    }

    // Clicked the Unit field
    private fun clickedUnit() {
        if (viewDataBinding!!.rbUnit.isChecked) {
            viewDataBinding!!.rbKg.isChecked = false
            viewDataBinding!!.etCount.setHint(R.string.how_many_unit)
            viewDataBinding!!.etPrice.setHint(R.string.price_per_unit)

            viewDataBinding!!.etCount.inputType = TYPE_CLASS_NUMBER
        } else {
            viewDataBinding!!.rbUnit.isChecked = false
            viewDataBinding!!.etCount.setHint(R.string.how_much_weight)
            viewDataBinding!!.etPrice.setHint(R.string.price_per_kg)

            viewDataBinding!!.etCount.inputType = TYPE_CLASS_NUMBER or TYPE_NUMBER_FLAG_DECIMAL
        }
    }

    // Clicked Kg
    private fun clickedKg() {
        if (viewDataBinding!!.rbUnit.isChecked) {
            viewDataBinding!!.rbKg.isChecked = false
            viewDataBinding!!.etCount.setHint(R.string.how_many_unit)
            viewDataBinding!!.etPrice.setHint(R.string.price_per_unit)

            viewDataBinding!!.etCount.inputType = TYPE_CLASS_NUMBER
        } else {
            viewDataBinding!!.rbUnit.isChecked = false
            viewDataBinding!!.etCount.setHint(R.string.how_much_weight)
            viewDataBinding!!.etPrice.setHint(R.string.price_per_kg)

            viewDataBinding!!.etCount.inputType = TYPE_CLASS_NUMBER or TYPE_NUMBER_FLAG_DECIMAL
        }
    }

    // Scan
    private fun scan() {
        // Go to Barcode reader activity
//        val intent = Intent(this, BarcodeReaderActivity::class.java)
//        startActivityForResult(intent, BARCODE_ACTIVITY)
        // start new scanner sdk
        startScanner()
    }

    private fun startScanner() {
        BasketScanner.scan(onSuccess = {
            setScannedBarcode(it)
        }, onCanceled = {}, onEmptyResult = {}, onFailure = {
            Toast.makeText(this@CreateCustomItemActivity, it.message + "", Toast.LENGTH_LONG).show()
        })
    }

    // Set the barcode
    private fun setScannedBarcode(barcode: String) {
        this.barcode = barcode
        viewDataBinding!!.tvBarcode.setText(barcode)
    }

    // Get file path from bitmap
    private fun getFromCamera(bitmap: Bitmap) {
        val path = saveImage(bitmap)
        if (path != null)
            imageFile = File(path)
    }

    // Get image uri
    private fun getImageUri(): Uri? {
        var outputUri: Uri? = null
        try {
            val wallpaperDirectory = File(
                Environment.getExternalStorageDirectory().toString() + "/" + IMAGE_DIRECTORY + "/"
            )
            val f =
                File(wallpaperDirectory, Calendar.getInstance().timeInMillis.toString() + ".jpg")
            f.createNewFile()

            outputUri = Uri.fromFile(f)

        } catch (e: Exception) {
            e.printStackTrace()
        }

        return outputUri
    }

    // Get file path from uri
    private fun getFromGallery(uri: Uri) {
        val projection = arrayOf(MediaStore.Images.Media.DATA)
        val cursor = contentResolver.query(uri, projection, null, null, null) ?: return
        val column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
        cursor.moveToFirst()
        val s = cursor.getString(column_index)
        cursor.close()

        val path = saveImage(BitmapFactory.decodeFile(s))
        if (path != null)
            imageFile = File(path)
    }

    // Save bitmap to local
    private fun saveImage(bmp: Bitmap): String? {
        var savedImagePath: String? = null
        try {
            val bytes = ByteArrayOutputStream()
            val newBmp = Bitmap.createScaledBitmap(bmp, 800, 600, false)
            newBmp.compress(Bitmap.CompressFormat.JPEG, 90, bytes)

            val wallpaperDirectory = File(
                Environment.getExternalStorageDirectory().toString() + "/" + IMAGE_DIRECTORY + "/"
            )
            val f =
                File(wallpaperDirectory, Calendar.getInstance().timeInMillis.toString() + ".jpg")
            f.createNewFile()

            val fo = FileOutputStream(f)
            fo.write(bytes.toByteArray())
            MediaScannerConnection.scanFile(
                this,
                arrayOf<String>(f.path),
                arrayOf("image/jpeg"),
                null
            )
            fo.close()
            savedImagePath = f.absolutePath

            // Clear the bitmap from Memory
            newBmp.recycle()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return savedImagePath
    }

    /**
     * ActivityResult
     */
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        if (requestCode == BARCODE_ACTIVITY){
//            if (resultCode == Activity.RESULT_OK) {
//                setScannedBarcode(data?.getStringExtra("ARG_BARCODE") ?: "")
//            }
//        }
//        else if (requestCode == ARG_IMAGE_REQ){
//            if (resultCode == Activity.RESULT_OK) {
//                if (data != null && data.extras != null){ // From Camera
//                    getFromCamera(data.extras!!.get("data") as Bitmap)
//                }
//                else if (data != null && data.data != null){ // From Gallery
//                    getFromGallery(data.data!!)
//                }
//                else{
//                    Log.d("CreateCustomItem", "Image data is null")
//                }
//
//                if (imageFile != null){
//                    viewDataBinding!!.ivImage.visibility = View.VISIBLE
//                    GlideApp.with(this).load(imageFile).fitCenter()
//                        .placeholder(R.drawable.placeholder)
//                        .error(R.drawable.placeholder).into(viewDataBinding!!.ivImage)
//                }
//                else{
//                    viewDataBinding!!.ivImage.visibility = View.GONE
//                }
//            }
//        }

        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == BARCODE_ACTIVITY) {
            if (resultCode == Activity.RESULT_OK) {
                setScannedBarcode(data?.getStringExtra("ARG_BARCODE") ?: "")
            }
        } else {
            // Picked image
            easyImage.handleActivityResult(
                requestCode,
                resultCode,
                data,
                this,
                object : DefaultCallback() {
                    override fun onMediaFilesPicked(
                        imageFiles: Array<MediaFile>,
                        source: MediaSource
                    ) {
                        imageFile = imageFiles.first().file

                        val srcImageFile = imageFiles.first().file

                        if (srcImageFile != null) {
//                        viewDataBinding!!.ivImage.visibility = View.VISIBLE
                            viewDataBinding!!.photoView.visibility = View.VISIBLE
                            viewDataBinding!!.imgAdd.visibility = View.GONE

                            GlideApp.with(this@CreateCustomItemActivity).load(srcImageFile)
                                .fitCenter()
                                .placeholder(R.drawable.placeholder)
                                .error(R.drawable.placeholder)
                                .into(viewDataBinding!!.ivCapturedPhoto)

                            val srcBitmap = BitmapFactory.decodeFile(srcImageFile.absolutePath)

                            // Get the scaled image path
                            val dstImagePath = saveImage(srcBitmap)
                            if (dstImagePath != null) {
                                imageFile = File(dstImagePath)
                            }
                        } else {
                            viewDataBinding!!.photoView.visibility = View.GONE
                            viewDataBinding!!.imgAdd.visibility = View.VISIBLE
                        }
                    }
                })
        }
    }

    override fun onBackPressed() {
//        super.onBackPressed()
        hideKeyboard()
        finish()
    }

    companion object {
        // Request code
        const val ARG_IMAGE_REQ = 354
        const val ARG_AUDIO_REQ = 355
        const val ARG_VIDEO_REQ = 356
        const val ARG_VIDEO_RECORD_REQ = 357
    }

}