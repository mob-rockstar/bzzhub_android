package com.app.basketiodriver.data.model.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName


/**
Created by ibraheem lubbad on 4/25/20.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/

@Entity(tableName = "onbaording_stages")
data class OnbaordingStages(
    @PrimaryKey
    @SerializedName("userId") val userId: Int,
    @SerializedName("isBasicInfoDone") val isBasicInfoDone: Boolean,
    @SerializedName("isCarInfoDone") val isCarInfoDone: Boolean,
    @SerializedName("isTakeSelDonef") val isTakeSelfDone: Boolean
)