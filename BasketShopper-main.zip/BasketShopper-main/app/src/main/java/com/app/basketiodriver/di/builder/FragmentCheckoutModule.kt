package com.app.basketiodriver.di.builder

import com.app.basketiodriver.ui.checkout.fragments.*
import com.app.basketiodriver.ui.dialogs.*
import dagger.Module
import dagger.android.ContributesAndroidInjector


/**
Created by ibraheem lubbad on 2020-02-12.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/

@Module
abstract class FragmentCheckoutModule {

    @ContributesAndroidInjector
    abstract fun contributeToDo(): ToDo

    @ContributesAndroidInjector
    abstract fun contributePending(): Pending

    @ContributesAndroidInjector
    abstract fun contributeDone(): Done

    @ContributesAndroidInjector
    abstract fun contributeToDo1(): ToDo1

    @ContributesAndroidInjector
    abstract fun contributeCanNotFindItemDialogFragment(): CanNotFindItemDialogFragment

    @ContributesAndroidInjector
    abstract fun contributeCheckoutInstructionsDialogFragment(): CheckoutInstructionsDialogFragment

    @ContributesAndroidInjector
    abstract fun contributeBringCCMachineDialogFragment(): BringCCMachineDialogFragment

    @ContributesAndroidInjector
    abstract fun contributeCardInstructionsDialogFragment(): CardInstructionsDialogFragment

//    @ContributesAndroidInjector
//    abstract fun contributeReviewChangesOptionDialogFragment(): ReviewChangesOptionDialogFragment

    @ContributesAndroidInjector
    abstract fun contributeFlagItemDialogFragment(): FlagItemDialogFragment

    @ContributesAndroidInjector
    abstract fun contributeSelectReplacementDialogFragment(): SelectReplacementDialogFragment

    @ContributesAndroidInjector
    abstract fun contributeTotalConfirmDialogFragment(): TotalConfirmDialogFragment

    @ContributesAndroidInjector
    abstract fun contributeRefundDialogFragment(): RefundDialogFragment

    @ContributesAndroidInjector
    abstract fun contributeAmountDialogFragment(): AmountDialogFragment

}
