package com.app.basketiodriver.ui.order.adapter

import android.annotation.SuppressLint
import android.view.ViewGroup
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.checkout.CustomerInfo
import com.app.basketiodriver.data.model.api.response.checkout.Department
import com.app.basketiodriver.databinding.ItemArrivedCustomerProductListBinding
import com.app.basketiodriver.ui.checkout.adapter.OrderDetailItemAdapter
import com.app.basketiodriver.utils.BaseRecyclerViewAdapter

class ArrivedToCustomerProductListAdapter (val activity : FragmentActivity, val list : List<Department>, val userMobile : String, val outletId : Long, val info : CustomerInfo, val dots:Boolean, val isClick : Boolean, val isExpress : Int)
    : BaseRecyclerViewAdapter<Department, ItemArrivedCustomerProductListBinding>() {

    override val layoutId: Int
        get() = R.layout.item_arrived_customer_product_list

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return DepartmentViewHolder(createBindView(parent))
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val holder = holder as DepartmentViewHolder
        val item = list[position]

        // Department name
        holder.binding.tvDepartment.isAllCaps = true
        if (item.departmentName == "Custom_Item")
        {
            holder.binding.tvDepartment.text = activity.getString(R.string.custom_department)
        }
        else{
            holder.binding.tvDepartment.text = item.departmentName
        }

        // Set the LayoutManager
        holder.binding.rvItems.setHasFixedSize(true)
        holder.binding.rvItems.layoutManager = LinearLayoutManager(activity)

        if (holder.binding.rvItems.adapter == null){
            holder.binding.rvItems.adapter = OrderDetailItemAdapter(activity, list[position].items, userMobile, outletId, info, isClick, dots, isExpress)
        }
        else {
            val itemAdapter = holder.binding.rvItems.adapter as OrderDetailItemAdapter
            itemAdapter.listItem = list[position].items
            itemAdapter.notifyDataSetChanged()
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    inner class DepartmentViewHolder(val binding: ItemArrivedCustomerProductListBinding) :
        RecyclerView.ViewHolder(binding.root)
}