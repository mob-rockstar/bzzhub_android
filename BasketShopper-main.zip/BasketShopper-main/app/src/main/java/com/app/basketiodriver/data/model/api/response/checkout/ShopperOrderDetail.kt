package com.app.basketiodriver.data.model.api.response.checkout

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class ShopperOrderDetail {
    @SerializedName("response")
    @Expose
    val response: ResponseOrderDetail? = null
}