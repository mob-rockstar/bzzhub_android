
package com.app.basketiodriver.data.remote

/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
interface ApiHelper {
    val apiHeader: ApiHeader?
}