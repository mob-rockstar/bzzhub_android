package com.app.basketiodriver.data.model.api.response.notification

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName

class NotificationListData {
    @SerializedName("id")
    @Expose
    var id: Long? = null

    @SerializedName("title")
    @Expose
    var title: String? = null

    @SerializedName("body")
    @Expose
    var body: String? = null

    @SerializedName("type")
    @Expose
    var type: Int? = null

    @SerializedName("image")
    @Expose
    var image: String? = null

    @SerializedName("type_label")
    @Expose
    var type_label: String? = null

    @SerializedName("orders_outlets_id")
    @Expose
    var orders_outlets_id: String? = null

    @SerializedName("read_status")
    @Expose
    var read_status: String? = null

    @SerializedName("created_date")
    @Expose
    var created_date: String? = null

    @SerializedName("sent_before")
    @Expose
    var sent_before: String? = null

    @SerializedName("expire_date")
    @Expose
    var expire_date: String? = null
}