package com.app.basketiodriver.ui.login.fragments

import android.os.Bundle
import android.view.View
import bloder.com.blitzcore.enableWhen
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragPinVerificationBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.login.LoginViewModel


/**
Created by ibraheem lubbad on 2020-01-15.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class PinVerificationFragment : BaseFragment<FragPinVerificationBinding?, LoginViewModel>(),
    Injectable {


    override val layoutId: Int
        get() = R.layout.frag_pin_verification

    override val viewModel: LoginViewModel
        get() {
            return getViewModel(requireActivity(), LoginViewModel::class.java)
        }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.sign_to_continue))

        validation()
        setListener()

    }


    /**
     * set actions listener
     */
    private fun setListener() {

        viewDataBinding!!.btnForgetPassword.setOnClickListener {
            run {
                navigate(
                    PinVerificationFragmentDirections.actionPinVerificationFragmentToForgetPasswordFragment()
                )
            }
        }

        viewDataBinding!!.btnLoginWithSms.setOnClickListener {
            navigate(PinVerificationFragmentDirections.actionPinVerificationFragmentToLoginSmsFragment())
        }

        viewDataBinding!!.btnLogin.setOnClickListener {
            run {
                hideKeyboard()
//                viewModel.loginByPassword(
//                    LoginRequest.ShopperLoginPasswordRequest(
//                        viewModel.userId,
//                        viewDataBinding!!.edPassword.text.toString(),
//                        viewModel.dataManager.deviceId,
//                        viewModel.dataManager.deviceToken
//
//                    ), object : HandleResponse<LoginResponse> {
//                        override fun handleErrorResponse(error: ErrorResponse?) {
//                            viewDataBinding!!.tvError.text = error?.message
//                        }
//
//                        override fun handleSuccessResponse(successResponse: LoginResponse) {

                            // Save user information
//                            successResponse.data?.user?.let {
//                                PreferenceManager.currentUserFirstName = successResponse.data.user.first_name
//                                PreferenceManager.currentUserLastName = successResponse.data.user.last_name
//                                PreferenceManager.currentUserMobile = successResponse.data.user.mobile
//                                PreferenceManager.currentUserEmail = successResponse.data.user.email
//                            }
//
//                            if (successResponse.data?.user?.is_verified==1){
//                                startActivity(HomeActivity.newIntent(context))
//                            }else{
//                                startActivity(OnBoardingActivity.newIntent(context))
//                            }
//
//                            requireActivity().finish()
//                        }
//                    })
                // }
            }
        }


    }

    /**
     * validate form data
     */
    private fun validation() {

        viewDataBinding!!.btnLogin.enableWhen {
            viewDataBinding!!.edPassword.isPassword() onValidationSuccess {
                if (viewDataBinding!!.tvError.text.toString().equals(getString(R.string.err_password))) {
                    viewDataBinding!!.tvError.text = null
                }
                viewDataBinding!!.edPassword.onSuccess()

            } onValidationError {
                viewDataBinding!!.tvError.text = getString(R.string.err_password)
                viewDataBinding!!.edPassword.onError()
            }
        }
    }


}
