
package com.app.basketiodriver.data.local.db.dao

import androidx.room.*
import com.app.basketiodriver.data.model.api.User
import com.app.basketiodriver.data.model.db.OnbaordingStages
import io.reactivex.Single


/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
@Dao
interface OnbaordingStagesDao {
    @Query("SELECT * FROM onbaording_stages")
    fun loadAll(): List<OnbaordingStages?>?

    @Delete
    fun delete(onbaordingStages: OnbaordingStages?)

    @Query("SELECT * FROM onbaording_stages WHERE userId  LIKE :userId LIMIT 1")
    fun findByUserId(userId: Int?): Single<OnbaordingStages?>?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(onbaordingStages: OnbaordingStages?)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(onbaordingStages: List<OnbaordingStages?>?)

}