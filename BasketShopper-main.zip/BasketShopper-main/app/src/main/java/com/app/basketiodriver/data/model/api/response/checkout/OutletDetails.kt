package com.app.basketiodriver.data.model.api.response.checkout

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName

class OutletDetails {
    @SerializedName("vendor_id")
    @Expose
    val vendor_id: Long? = null

    @SerializedName("outlet_id")
    @Expose
    val outlet_id: Int? = null

    @SerializedName("outlet_name")
    @Expose
    val outlet_name: String? = null

    @SerializedName("outlet_city")
    @Expose
    val outlet_city: String? = null

    @SerializedName("outlet_location")
    @Expose
    val outlet_location: String? = null

    @SerializedName("outlet_latitude")
    @Expose
    val outlet_latitude: String? = null

    @SerializedName("outlet_longitude")
    @Expose
    val outlet_longitude: String? = null

    @SerializedName("outlet_google_address")
    @Expose
    val outlet_google_address: String? = null

    @SerializedName("vendor_logo")
    @Expose
    val vendor_logo: String? = null

    @SerializedName("loyalty_card_number")
    @Expose
    val loyalty_card_number: Long? = null

    @SerializedName("loyalty_card_image")
    @Expose
    val loyalty_card_image: String? = null

    @SerializedName("loyalty_card_number_needed")
    @Expose
    val loyalty_card_number_needed: Int = 0

    @SerializedName("cashier_confirmed")
    @Expose
    val cashierConfirmed: Int? = null
}