package com.app.basketiodriver.data.model.api.response.order

import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem

class ReplacementOrdersItemRequest {
    var product : OrdersItem? = null
    var quantity : Double = 1.0
    var weight : Double = 0.0
}