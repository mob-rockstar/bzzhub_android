package com.app.basketiodriver.ui.order

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.Navigation
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.ActivityOrderListBinding
import com.app.basketiodriver.ui.base.BaseActivity
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import javax.inject.Inject

class OrderListActivity : BaseActivity<ActivityOrderListBinding?, OrderViewModel>(),
    HasAndroidInjector {


    override val layoutId: Int
        get() = R.layout.activity_order_list

    override val viewModel: OrderViewModel
        get() {
            return getViewModel(OrderViewModel::class.java)
        }

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initToolbar(
            "Order",
            true, viewDataBinding!!.toolbarLayout.toolbar,
            View.OnClickListener {
                run {
                    if (!Navigation.findNavController(
                            this,
                            R.id.navHostOrderListFragments
                        ).popBackStack()
                    ) {
                        finish()
                    }
                }
            })

    }

    companion object {
        fun newIntent(context: Context?): Intent {
            return Intent(context, OrderListActivity::class.java)
        }
    }
}
