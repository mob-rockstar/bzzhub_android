package com.app.basketiodriver.data.model.api.response.howamidoing

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName


class HowAmIDoingDetail {
    @SerializedName("avarage_rating")
    @Expose
    val averageRating: AverageRating? = null

    @SerializedName("reliability_incident")
    @Expose
    val reliabilityIncident: ReliabilityIncident? = null
}