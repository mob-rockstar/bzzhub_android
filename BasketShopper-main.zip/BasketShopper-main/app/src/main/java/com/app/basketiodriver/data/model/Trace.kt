package com.app.basketiodriver.data.model


/**
Created by ibraheem lubbad on 2020-02-04.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
data class Trace(
    /** 时间  */
    val acceptTime: String? = null,
    /** 描述  */
    val acceptStation: String? = null,
    val title: String? = null

)