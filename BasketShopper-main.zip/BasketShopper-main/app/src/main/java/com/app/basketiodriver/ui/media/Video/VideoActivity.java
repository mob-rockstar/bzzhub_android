package com.app.basketiodriver.ui.media.Video;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;

import com.app.basketiodriver.R;
import com.app.basketiodriver.data.remote.socket.SocketManager;
import com.app.basketiodriver.ui.media.FileProcessing;
import com.app.basketiodriver.ui.media.Image.ImageActivity;
import com.app.basketiodriver.ui.media.Image.ImageTags;
import com.app.basketiodriver.ui.media.Utility;

import java.io.File;
import java.io.Serializable;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class VideoActivity extends AppCompatActivity {

    private File destination;
    private Uri mVideoUri;
    private VideoConfig mVideoConfig;
    private List<String> mListOfVideos;
    private AlertDialog alertDialog;

    public static Intent getCallingIntent(Context activity, VideoConfig videoConfig) {
        Intent intent = new Intent(activity, VideoActivity.class);
        intent.putExtra(VideoTags.Tags.IMG_CONFIG, videoConfig);
        return intent;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        if (intent != null) {
            mVideoConfig = (VideoConfig) intent.getSerializableExtra(VideoTags.Tags.IMG_CONFIG);
        }

        if (savedInstanceState == null) {
            pickVideoWrapper();
            mListOfVideos = new ArrayList<>();
        }
        if (mVideoConfig.debug)
            Log.d(VideoTags.Tags.TAG, mVideoConfig.toString());
    }

    @Override
    protected void onPause() {
        if (alertDialog != null)
            alertDialog.dismiss();
        super.onPause();
    }

    private void pickVideo() {
        Utility.createFolder(mVideoConfig.directory);
        destination = new File(mVideoConfig.directory, Utility.getRandomString() + mVideoConfig.extension.getValue());
        switch (mVideoConfig.mode) {
            case CAMERA:
                startActivityFromCamera();
                break;
            case GALLERY:
                if (mVideoConfig.allowMultiple)
                    startActivityFromGalleryMultiImg();
                else
                    startActivityFromGallery();
                break;
            case CAMERA_AND_GALLERY:
                showFromCameraOrGalleryAlert();
                break;
            default:
                break;
        }
    }

    private void showFromCameraOrGalleryAlert() {
        alertDialog = new AlertDialog.Builder(this)
                .setTitle(getString(R.string.media_picker_select_from))
                .setPositiveButton(getString(R.string.media_picker_camera), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (mVideoConfig.debug)
                            Log.d(VideoTags.Tags.TAG, "Alert Dialog - Start From Camera");
                        startActivityFromCamera();
                        alertDialog.dismiss();
                    }
                })
                .setNegativeButton(getString(R.string.media_picker_gallery), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (mVideoConfig.debug)
                            Log.d(VideoTags.Tags.TAG, "Alert Dialog - Start From Gallery");
                        if (mVideoConfig.allowMultiple)
                            startActivityFromGalleryMultiImg();
                        else
                            startActivityFromGallery();
                        alertDialog.dismiss();
                    }
                })
                .setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialogInterface) {
                        if (mVideoConfig.debug)
                            Log.d(VideoTags.Tags.TAG, "Alert Dialog - Canceled");
                        alertDialog.dismiss();
                        finish();
                    }
                }).create();
        alertDialog.show();

    }

    private void startActivityFromGallery() {
        mVideoConfig.isImgFromCamera = false;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"video/*"});
        startActivityForResult(intent, VideoTags.IntentCode.REQUEST_CODE_SELECT_PHOTO);
//
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    private void startActivityFromGalleryMultiImg() {
        mVideoConfig.isImgFromCamera = false;
        Intent photoPickerIntent = new Intent();
        photoPickerIntent.putExtra(Intent.EXTRA_LOCAL_ONLY, true);
        photoPickerIntent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        photoPickerIntent.setAction(Intent.ACTION_GET_CONTENT);
        photoPickerIntent.setType("video/*.mp4");
        startActivityForResult(Intent.createChooser(photoPickerIntent, "Select Picture"), VideoTags.IntentCode.REQUEST_CODE_SELECT_MULTI_PHOTO);
        if (mVideoConfig.debug)
            Log.d(VideoTags.Tags.TAG, "Gallery Start with Multiple videos mode");
    }

    private void startActivityFromCamera() {
        mVideoConfig.isImgFromCamera = true;
        Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        startActivityForResult(intent, ImageTags.IntentCode.CAMERA_REQUEST);
//        mVideoUri = FileProvider.getUriForFile(this, this.getApplicationContext().getPackageName() + ".photopicker.fileprovider", destination);
//        intent.putExtra(MediaStore.EXTRA_OUTPUT, mVideoUri);
//        startActivityForResult(Intent.createChooser(intent, "Select Video"), VideoTags.IntentCode.CAMERA_REQUEST);
        if (mVideoConfig.debug)
            Log.d(VideoTags.Tags.TAG, "Camera Start");

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (mVideoUri != null) {
            outState.putString(VideoTags.Tags.CAMERA_IMAGE_URI, mVideoUri.toString());
            outState.putSerializable(VideoTags.Tags.IMG_CONFIG, mVideoConfig);
        }
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        if (savedInstanceState.containsKey(VideoTags.Tags.CAMERA_IMAGE_URI)) {
            mVideoUri = Uri.parse(savedInstanceState.getString(VideoTags.Tags.CAMERA_IMAGE_URI));
            destination = new File(mVideoUri.getPath());
            mVideoConfig = (VideoConfig) savedInstanceState.getSerializable(VideoTags.Tags.IMG_CONFIG);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (mVideoConfig.debug)
            Log.d(VideoTags.Tags.TAG, "onActivityResult() called with: " + "requestCode = [" + requestCode + "], resultCode = [" + resultCode + "], data = [" + data + "]");
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case VideoTags.IntentCode.CAMERA_REQUEST:
                    Uri selectVideo = data.getData();
                    String inputUri = selectVideo.toString();
                    String outputPath = convertUriToPath(inputUri);

                    if (outputPath != null) {

                        new CompresVideoTask(outputPath, mVideoConfig
                                , VideoActivity.this).execute();
                        System.out.println("Converted path: " + outputPath);
                    } else {
                        System.out.println("Failed to convert URI to path.");
                    }

                    break;
                case VideoTags.IntentCode.REQUEST_CODE_SELECT_PHOTO:
                    processOneVideo(data);
                    break;
                case VideoTags.IntentCode.REQUEST_CODE_SELECT_MULTI_PHOTO:
                    //Check if the intent contain only one image
                    if (data.getClipData() == null) {
                        processOneVideo(data);
                    } else {
                        //intent has multi images
                        mListOfVideos = VideoProcessing.processMultiVideos(this, data);
                        new CompresVideoTask(mListOfVideos,
                                mVideoConfig, VideoActivity.this).execute();
                    }
                    break;
                default:
                    break;
            }
        } else {
            Intent intent = new Intent();
            intent.putExtra(VideoTags.Tags.PICK_ERROR, "user did not select any videos");
            sendBroadcast(intent);
            finish();
        }
    }

    private void processOneVideo(Intent data) {
        try {
            Uri selectedVideo = data.getData();
            String path = FileProcessing.getPath(VideoActivity.this, selectedVideo);
            new VideoActivity.CompresVideoTask(path,
                    mVideoConfig, VideoActivity.this).execute();

        } catch (Exception ex) {
            Intent intent = new Intent();
            intent.putExtra(VideoTags.Tags.PICK_ERROR, "Issue with video path: " + ex.getMessage());
            sendBroadcast(intent);
            setResult(RESULT_CANCELED, intent);
            finish();
        }

    }

    private void finishActivity(List<String> path) {
        Intent intent = new Intent();
        intent.putExtra(VideoTags.Tags.VIDEO_PATH, (Serializable) path);
        sendBroadcast(intent);

        Intent resultIntent = new Intent();
        resultIntent.putExtra(VideoPicker.EXTRA_VIDEO_PATH, (Serializable) path);
        setResult(RESULT_OK, resultIntent);
        finish();
    }

    private void pickVideoWrapper() {
        if (Build.VERSION.SDK_INT >= 23) {
            List<String> permissionsNeeded = new ArrayList<>();

            final List<String> permissionsList = new ArrayList<>();
            if ((mVideoConfig.mode == VideoPicker.Mode.CAMERA || mVideoConfig.mode == VideoPicker.Mode.CAMERA_AND_GALLERY) && !addPermission(permissionsList, Manifest.permission.CAMERA))
                permissionsNeeded.add(getString(R.string.media_picker_camera));
            if (!addPermission(permissionsList, Manifest.permission.WRITE_EXTERNAL_STORAGE))
                permissionsNeeded.add(getString(R.string.media_picker_read_Write_external_storage));

            if (permissionsList.size() > 1) {
                if (permissionsNeeded.size() > 1) {
                    // Need Rationale
                    StringBuilder message = new StringBuilder(getString(R.string.media_picker_you_need_to_grant_access_to) + permissionsNeeded.get(0));
                    for (int i = 1; i < permissionsNeeded.size(); i++)
                        message.append(", ").append(permissionsNeeded.get(i));
                    showMessageOKCancel(message.toString(),
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    ActivityCompat.requestPermissions(VideoActivity.this, permissionsList.toArray(new String[permissionsList.size()]),
                                            VideoTags.IntentCode.REQUEST_CODE_ASK_PERMISSIONS);
                                }
                            });
                    return;
                }
                ActivityCompat.requestPermissions(VideoActivity.this, permissionsList.toArray(new String[permissionsList.size()]),
                        VideoTags.IntentCode.REQUEST_CODE_ASK_PERMISSIONS);
                return;
            }

            pickVideo();
        } else {
            pickVideo();
        }
    }

    private void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener) {
        new AlertDialog.Builder(VideoActivity.this)
                .setMessage(message)
                .setPositiveButton(getString(R.string.positive_button), okListener)
                .setNegativeButton(getString(R.string.media_picker_cancel), null)
                .create()
                .show();
    }

    private boolean addPermission(List<String> permissionsList, String permission) {
        if (ActivityCompat.checkSelfPermission(VideoActivity.this, permission) != PackageManager.PERMISSION_GRANTED) {
            permissionsList.add(permission);
            // Check for Rationale Option
            return ActivityCompat.shouldShowRequestPermissionRationale(VideoActivity.this, permission);
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case VideoTags.IntentCode.REQUEST_CODE_ASK_PERMISSIONS:
                Map<String, Integer> perms = new HashMap<String, Integer>();
                // Initial
                perms.put(Manifest.permission.CAMERA, PackageManager.PERMISSION_GRANTED);
                perms.put(Manifest.permission.WRITE_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
                // Fill with results
                for (int i = 0; i < permissions.length; i++)
                    perms.put(permissions[i], grantResults[i]);
                // Check for ACCESS_FINE_LOCATION
                if (perms.get(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                        || perms.get(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                    // All Permissions Granted
                    pickVideo();
                } else {
                    // Permission Denied
                    Toast.makeText(VideoActivity.this, getString(R.string.media_picker_some_permission_is_denied), Toast.LENGTH_SHORT)
                            .show();
                }

                break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    private static class CompresVideoTask extends AsyncTask<Void, Void, Void> {

        private final VideoConfig mVideoConfig;
        private final List<String> listOfImgs;
        private List<String> destinationPaths;
        private WeakReference<VideoActivity> mContext;


        CompresVideoTask(List<String> listOfImgs, VideoConfig videoConfig, VideoActivity context) {
            this.listOfImgs = listOfImgs;
            this.mContext = new WeakReference<>(context);
            this.mVideoConfig = videoConfig;
            this.destinationPaths = new ArrayList<>();
        }

        CompresVideoTask(String absolutePath, VideoConfig videoConfig, VideoActivity context) {
            List<String> list = new ArrayList<>();
            list.add(absolutePath);
            this.listOfImgs = list;
            this.mContext = new WeakReference<>(context);
            this.destinationPaths = new ArrayList<>();
            this.mVideoConfig = videoConfig;
        }


        @Override
        protected Void doInBackground(Void... params) {
            for (String mPath : listOfImgs) {
                File file = new File(mPath);
                File destinationFile;
//                destinationFile = file;
//                FileProcessing.copyDirectory(file, destinationFile);

                destinationFile = new File(mVideoConfig.directory, Utility.getRandomString() + mVideoConfig.extension.getValue());
//                if (mVideoConfig.isImgFromCamera) {
//                    destinationFile = file;
//                } else {
//                    destinationFile = new File(mVideoConfig.directory, Utility.getRandomString() + mVideoConfig.extension.getValue());
//                    FileProcessing.copyDirectory(file, destinationFile);
//                }
                destinationPaths.add(destinationFile.getAbsolutePath());

            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            VideoActivity context = mContext.get();
            if (context != null) {
                context.finishActivity(destinationPaths);

            }
        }
    }
    public static String convertUriToPath(String uriString) {
        Uri uri = Uri.parse(uriString);

        // Assuming the URI follows the pattern /external_primary/video/media/...
        String mediaId = uri.getLastPathSegment();

        // Assuming the destination path pattern is /storage/emulated/0/DCIM/Camera/VID_YYYYMMDD_HHMMSS.mp4
        long currentTime = System.currentTimeMillis();
        String destinationPath = "/storage/emulated/0/DCIM/Camera/VID_" + formatTimestamp(currentTime) + "_" + mediaId + ".mp4";

        return destinationPath;
    }

    public static String formatTimestamp(long timestamp) {
        java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.getDefault());
        return dateFormat.format(timestamp);
    }

}