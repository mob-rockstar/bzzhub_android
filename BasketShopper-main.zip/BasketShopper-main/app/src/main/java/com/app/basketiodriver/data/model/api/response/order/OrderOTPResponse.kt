package com.app.basketiodriver.data.model.api.response.order

import com.google.gson.JsonElement
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class OrderOTPResponse {

    @SerializedName("data")
    @Expose
    val data: List<OrderOtpData> = arrayListOf()

    @SerializedName("message")
    @Expose
    val message: String = ""

    @SerializedName("status")
    @Expose
    val status: Int = 0

    inner class OrderOtpData {
        @SerializedName("cc_order_otp")
        @Expose
        val otp: String = ""
    }
}