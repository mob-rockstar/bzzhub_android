package com.app.basketiodriver.data.model.api.response.hours

import com.app.basketiodriver.data.model.api.response.Base.BaseResponse
import com.google.gson.annotations.SerializedName


/**
Created by ibraheem lubbad on 2020-02-11.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class BookingReportResponse : BaseResponse() {

    @SerializedName("data")
    var data: ShopperBookingDetailData? = null
}