package com.app.basketiodriver.data.model.api.response.checkout

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class ShopperOrderTimer {
    @SerializedName("response")
    @Expose
    val response: ResponseOrderTimer? = null
}