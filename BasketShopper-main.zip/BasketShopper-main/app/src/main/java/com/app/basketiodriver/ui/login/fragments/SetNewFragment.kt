package com.app.basketiodriver.ui.login.fragments

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.general.SimpleResponse
import com.app.basketiodriver.databinding.FragNewPinBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.login.LoginActivity
import com.app.basketiodriver.ui.login.LoginViewModel
import com.app.basketiodriver.utils.ViewUtils


/**
Created by ibraheem lubbad on 2020-01-15.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class SetNewFragment : BaseFragment<FragNewPinBinding?, LoginViewModel>(), Injectable {


    override val layoutId: Int
        get() = R.layout.frag_new_pin


    override val viewModel: LoginViewModel
        get() {
            return getViewModel(requireActivity(), LoginViewModel::class.java)
        }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.set_new_password))

        validation()
        setListener()
    }


    /**
     * set actions listener
     */
    private fun setListener() {

        // Tap the set new password button
        viewDataBinding!!.btnLogin.setOnClickListener {
            run {

                hideKeyboard()

                val passwordCode = viewDataBinding!!.edPasswordCode.text.toString()
                val passwordConfirmCode = viewDataBinding!!.edPasswordConfirmCode.text.toString()

                // Password Validation
                if (passwordCode.isEmpty() || passwordConfirmCode.isEmpty()) {
                    viewDataBinding!!.tvError.text = getString(R.string.all_fields_required)
//                    Toast.makeText(requireActivity(), getString(R.string.all_fields_required), Toast.LENGTH_SHORT).show()
                    return@run
                }

                if (!ViewUtils.isValidPassword(passwordCode)) {
                    viewDataBinding!!.tvError.text = getString(R.string.err_password)
//                    Toast.makeText(requireActivity(), getString(R.string.err_password), Toast.LENGTH_LONG).show()

                    return@run
                }

                if (passwordCode != passwordConfirmCode) {
                    viewDataBinding!!.tvError.text = getString(R.string.err_password_confirmation)
//                    Toast.makeText(requireActivity(), getString(R.string.err_password_confirmation), Toast.LENGTH_SHORT).show()
                    return@run
                }

                val userMobile = viewModel.codeMobileNumber.plus(viewModel.mobileNumber)
                viewModel.setNewPassword(userMobile, passwordCode, passwordConfirmCode, object:HandleResponse<SimpleResponse>{
                    override fun handleErrorResponse(error: ErrorResponse?) {
                        viewDataBinding!!.tvError.text = error?.message
                    }

                    override fun handleSuccessResponse(successResponse: SimpleResponse) {
                        val updateResponse = successResponse.response
                        if (updateResponse != null){
                            Toast.makeText(baseActivity, updateResponse.message, Toast.LENGTH_SHORT).show()

                            if (updateResponse.httpCode == 200) {

                                // Go to Login page
                                gotoLoginPage()
                            }
                        }
                        else{
                            Toast.makeText(baseActivity, baseActivity?.resources?.getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show()
                        }
                    }
                })
            }
        }
    }

    // Go to login page
    private fun gotoLoginPage(){
        val intent = LoginActivity.newIntent(baseActivity)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
        requireActivity().finish()
    }

    /**
     * validate form data
     */
    private fun validation() {
        viewDataBinding!!.edPasswordCode.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                val password = viewDataBinding!!.edPasswordCode.text.toString().trim()
                if (password.isEmpty()) {

                } else {
                    // Hide error message
                    viewDataBinding!!.tvError.text = null
                }
            }

            override fun afterTextChanged(s: Editable) {}
        })

        viewDataBinding!!.edPasswordConfirmCode.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                val password = viewDataBinding!!.edPasswordConfirmCode.text.toString().trim()
                if (password.isEmpty()) {

                } else {
                    // Hide error message
                    viewDataBinding!!.tvError.text = null
                }
            }

            override fun afterTextChanged(s: Editable) {}
        })


//        viewDataBinding!!.btnLogin.enableWhen {
//            viewDataBinding!!.edPasswordCode.isPassword() onValidationSuccess {
//                viewDataBinding!!.tvError.text = null
//                viewDataBinding!!.edPasswordCode.onSuccess()
//            } onValidationError {
////                viewDataBinding!!.tvError.text = getString(R.string.err_password)
//                viewDataBinding!!.edPasswordCode.onError()
//            }
//            viewDataBinding!!.edPasswordConfirmCode.confitmPassword(viewDataBinding!!.edPasswordCode) onValidationSuccess {
//                viewDataBinding!!.tvError.text = null
//                viewDataBinding!!.edPasswordConfirmCode.onSuccess()
//            } onValidationError {
////                viewDataBinding!!.tvError.text = getString(R.string.err_password_confirmation)
//                viewDataBinding!!.edPasswordConfirmCode.onError()
//
//
//            }
//        }
    }


}
