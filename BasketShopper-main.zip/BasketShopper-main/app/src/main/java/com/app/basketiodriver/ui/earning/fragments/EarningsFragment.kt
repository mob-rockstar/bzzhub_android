package com.app.basketiodriver.ui.earning.fragments

import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.View
import androidx.fragment.app.Fragment
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentEarningsBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.earning.EarningViewModel


/**
 * A simple [Fragment] subclass.
 */
class EarningsFragment : BaseFragment<FragmentEarningsBinding?, EarningViewModel>(),
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_earnings

    override val viewModel: EarningViewModel
        get() {
            return getViewModel(requireActivity(), EarningViewModel::class.java)
        }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.earnings))

    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_info, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }
}
