package com.app.basketiodriver.ui.dialogs

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.Window
import androidx.databinding.DataBindingUtil
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.checkout.CustomerInfo
import com.app.basketiodriver.databinding.DialogCustomerInfoBinding
import com.app.basketiodriver.utils.GlideApp
import com.app.basketiodriver.utils.PopupUtils
import java.util.*

class DialogCustomerInfo {

    var dialog: Dialog? = null

    fun openDialog(context: Context, info : CustomerInfo, onConfirm :() -> Unit){
        dialog = Dialog(context)

        val binding: DialogCustomerInfoBinding = DataBindingUtil.inflate(
            LayoutInflater.from(context),
            R.layout.dialog_customer_info,
            null,
            false
        )

        dialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog?.setContentView(binding.root)
        dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog?.window?.setGravity(Gravity.CENTER)

        // Avatar image
        GlideApp.with(context).load(info.image).fitCenter()
            .placeholder(R.drawable.ic_avatar)
            .error(R.drawable.ic_avatar).into(binding.ivCustomerImage)

        // Name
        binding.tvCustomerName.text = info.name

        // Area
//        binding.tvArea.text = info.area

        // Time
        binding.tvTime.text = if (info.time.isEmpty()) "N/A" else info.time

        // Address
        binding.tvGoogleAddress.text = String.format(Locale.ENGLISH, "%s - %s", info.area, info.address)

        // Type
        binding.tvAddressType.text = if (info.type.isEmpty()) "N/A" else info.type

        // Department building
        binding.tvDepBuilding.text = if (info.depBuilding.isEmpty()) "N/A" else info.depBuilding


        // Address Information
        binding.tvAddInfo.text = if (info.addInfo.isEmpty()) "N/A" else info.addInfo

        // Landmark
        binding.tvLandmark.text = if (info.landmark.isEmpty()) "N/A" else info.landmark

        // Ok button
        binding.btOk.setOnClickListener {
            onConfirm()
            dialog?.dismiss()
        }

        // show the dialog
        PopupUtils.setDefaultDialogProperty(dialog!!)
        dialog?.show()

    }

    fun dismissDialog(){
        if (dialog != null) dialog!!.dismiss()
    }

    companion object {
        private var instance: DialogCustomerInfo? = null
        private val Instance: DialogCustomerInfo
            get() {
                if (instance == null) {
                    instance = DialogCustomerInfo()
                }
                return instance!!
            }

        fun openDialog(context: Context, info : CustomerInfo, onConfirm :() -> Unit) {
            Instance.openDialog(context, info, onConfirm)
        }

        fun openDialog(context: Context,
                       image : String?,
                       name : String?,
                       area : String?,
                       time : String?,
                       address : String?,
                       type : String?,
                       depBuilding : String?,
                       addInfo : String?,
                       landmark : String?,
                       onConfirm :() -> Unit) {
            val info = CustomerInfo(image ?: "", name ?: "",area ?: "", time ?: "", address ?: "", type ?: "",depBuilding ?: "", addInfo ?: "", landmark ?: "N/A")

            Instance.openDialog(context, info, onConfirm)
        }

        fun dismissDialog(){
            Instance.dismissDialog()
        }
    }
}