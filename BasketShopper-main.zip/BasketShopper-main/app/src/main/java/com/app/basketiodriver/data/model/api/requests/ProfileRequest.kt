package com.app.basketiodriver.data.model.api.requests

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

/**
 * Created by ibraheem lubbad on 2020-02-11.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 */
class ProfileRequest {
    @field:SerializedName("dob")
    @field:Expose
    var dob: String? = null;

    @field:SerializedName("gender")
    @field:Expose
    var gender: Int? = null;

    @field:SerializedName("national_id_number")
    @field:Expose
    var national_id_number: String? = null;

    @field:SerializedName("nationality")
    @field:Expose
    var nationality: String? = null;

    @field:SerializedName("vehicle_manufacture_date")
    @field:Expose
    var vehicle_manufacture_date: String? = null;

    @field:SerializedName("vehicle_brand")
    @field:Expose
    var vehicle_brand: String? = null;

    @field:SerializedName("has_vehicle")
    @field:Expose
    var has_vehicle: Int? = null;

    @field:SerializedName("vehicle_expire_date")
    @field:Expose
    var vehicle_expire_date: String? = null;
}