package com.app.basketiodriver.ui.checkout.receipt

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import com.app.basketiodriver.BuildConfig
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.general.SimpleResponse
import com.app.basketiodriver.data.model.api.response.order.CommonResponse
import com.app.basketiodriver.databinding.ActivityUploadReceiptInfoBinding
import com.app.basketiodriver.di.Navigators
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.checkout.adapter.PhotoAdapter
import com.app.basketiodriver.ui.checkout.card.CheckoutCardViewModel
import com.app.basketiodriver.ui.dashbaord.OrdersManager
import com.app.basketiodriver.ui.order.product.OpenCameraActivity
import com.app.basketiodriver.utils.AppConstants
import com.tbruyelle.rxpermissions2.RxPermissions
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class UploadReceiptInfoActivity : BaseActivity<ActivityUploadReceiptInfoBinding, CheckoutCardViewModel>(), PhotoAdapter.AddImageClickListener {
    override val layoutId: Int
        get() = R.layout.activity_upload_receipt_info

    override val viewModel: CheckoutCardViewModel
        get() {
            return getViewModel(CheckoutCardViewModel::class.java)
        }
    private val MY_PERMISSIONS_REQUEST_STORAGE_PERMISSIONS = 10

    val uploadImage = "upload_image"
    var mCurrentPhotoPaths : MutableList<String> = arrayListOf()
    var mCurrentPhotoPath : String? = null

    var orderId : Long = 0
    var receiptNo : String = ""

    var openCamera : Boolean = false

    // Photo Adapter
    lateinit var photoAdapter : PhotoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize the Toolbar
        initToolbar(getString(R.string.charge_card),
            true, viewDataBinding!!.layoutToolBar.toolbar,
            View.OnClickListener {
                run {
                    onBackPressed()
                }
            })

        // Get params
        receiptNo  = intent.getStringExtra("ARG_RECEIPT_NO") ?: ""
        orderId    = intent.getLongExtra("ARG_ORDER_ID", 0)

        // Setup views
        initViews()
    }

    private fun initViews(){
        viewDataBinding!!.recyclerView.layoutManager = GridLayoutManager(this, 3)

        mCurrentPhotoPaths.add(uploadImage)
        photoAdapter = PhotoAdapter(this, mCurrentPhotoPaths)
        photoAdapter.listener = this

        viewDataBinding!!.recyclerView.adapter = photoAdapter

        setListeners()
    }

    private fun setListeners(){
        viewDataBinding!!.btnUploadReceipt.setOnClickListener {
            if (mCurrentPhotoPaths.size > 1){
                mCurrentPhotoPaths.removeAt(mCurrentPhotoPaths.size - 1)

                // upload the receipt image
                uploadImageToServer()
            }
            else{
                if (mCurrentPhotoPaths.size == 1 && mCurrentPhotoPaths[0] != uploadImage){
                    // upload the receipt image
                    uploadImageToServer()
                }
                else{
                    Toast.makeText(this, R.string.please_capture_receipt_image, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // Upload image to server
    private fun uploadImageToServer(){
        if (receiptNo.isNotEmpty()){
            sendReceiptPhoto(receiptNo, mCurrentPhotoPaths)
        }
    }

    private fun sendReceiptPhoto(storeReceiptNo : String, photoPaths: List<String>){
        viewModel.shopperSendOrderReceipt(orderId, storeReceiptNo, photoPaths, object : HandleResponse<CommonResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Toast.makeText(this@UploadReceiptInfoActivity, error?.message, Toast.LENGTH_SHORT).show()
                }else{
                    Toast.makeText(this@UploadReceiptInfoActivity, resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }
            }

            override fun handleSuccessResponse(successResponse: CommonResponse) {
                if (successResponse.status == 200){

                    // Update the order status
                    changeStatus()

                    // Delete the photos in local
                    for (i in mCurrentPhotoPaths.indices) {
                        val file = File(mCurrentPhotoPaths[i])
                        file.deleteOnExit()
                    }
                }
                else{
                    Toast.makeText(this@UploadReceiptInfoActivity, successResponse.message, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    // Update the order status
    private fun changeStatus(){
        viewModel.updateOrderStatus(OrdersManager.STATUS_SLIDE_START_DELIVERY, orderId, object : HandleResponse<SimpleResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Toast.makeText(this@UploadReceiptInfoActivity, error?.message, Toast.LENGTH_SHORT).show()
                }else{
                    Toast.makeText(this@UploadReceiptInfoActivity, resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }
            }

            override fun handleSuccessResponse(successResponse: SimpleResponse) {
                val response = successResponse.response
                if (response != null){
                    if (response.httpCode == 200){
                        // Go to AssignmentActivity
                        Navigators.goToLocationMap(this@UploadReceiptInfoActivity, orderId, 0)
                    }
                    else{
                        Toast.makeText(this@UploadReceiptInfoActivity, response.message, Toast.LENGTH_SHORT).show()
                    }
                }
                else{
                    Toast.makeText(this@UploadReceiptInfoActivity, getString(R.string.error_update_status), Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    private fun createCameraIntent(){
        val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (takePictureIntent.resolveActivity(packageManager) != null) {
            var photoFile : File? = null
            try {
                photoFile = createImageFile()
                val photoURI: Uri = FileProvider.getUriForFile(
                    this,
                    """${BuildConfig.APPLICATION_ID}.photopicker.fileprovider""",
                    photoFile!!
                )
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                startActivityForResult(takePictureIntent, OpenCameraActivity.REQUEST_TAKE_PHOTO)
            } catch (ex: IOException) {
                println("Error: " + ex.message)
            }
        }
    }

    @Throws(IOException::class)
    private fun createImageFile(): File? {
        val timeStamp: String =  SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ENGLISH).format(Date())
        val imageFileName = "JPEG_" + timeStamp + "_"
        val storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        val image = File.createTempFile(imageFileName, ".jpg", storageDir)
        mCurrentPhotoPath = image.absolutePath
        return image
    }

    // Show the error dialog
    private fun showErrorDialog(e: Exception) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.error))
            .setMessage(e.message + "\r\n" + getString(R.string.try_again))
            .setPositiveButton(getString(R.string.okay)) { _, _ ->
                //do things

            }
            .create().show()
    }

    // Compress the photo
    private fun compressPhoto(){
        try{
            val file = File(mCurrentPhotoPath!!)

            mCurrentPhotoPaths.removeAt(mCurrentPhotoPaths.size - 1)
            mCurrentPhotoPaths.add(file.absolutePath)
            mCurrentPhotoPaths.add(uploadImage)

            var options = BitmapFactory.Options()
            options.inJustDecodeBounds = true
            BitmapFactory.decodeFile(file.absolutePath, options)
            val k = Math.min(options.outHeight, options.outWidth) / 720
            options = BitmapFactory.Options()
            if (k > 1) options.inSampleSize = k

            val matrix = Matrix()
            matrix.postRotate(90f)

            val out = BitmapFactory.decodeFile(file.absolutePath, options)
            val rotatedBitmap =
                Bitmap.createBitmap(out, 0, 0, out.width, out.height, matrix, true)
            val stream = FileOutputStream(file.absolutePath)

            rotatedBitmap.compress(Bitmap.CompressFormat.JPEG, 50, stream)
        }
        catch (e : Exception){
            e.printStackTrace()
        }

    }

    // Set the captured image
    private fun setBitmapToView(){
//        photoAdapter = PhotoAdapter(this, mCurrentPhotoPaths)
//        photoAdapter.listener = this
//
//        viewDataBinding!!.recyclerView.adapter = photoAdapter
//        photoAdapter.notifyDataSetChanged()

        photoAdapter.setPhotos(mCurrentPhotoPaths)
    }

    /**
     * AddImageClickListener
     */
    @SuppressLint("MissingPermission", "CheckResult")
    override fun onClickAddImage() {
        if (!openCamera){


            if (isStoragePermisssionGranted()){
                openCamera = true
                createCameraIntent()
            }else{
                requestCameraPermission()
            }
//            val permissions = RxPermissions(this)
//            permissions.request(Manifest.permission.CAMERA)
//                .subscribe { granted: Boolean ->
//                    if (granted) {
//
//                    }else{
//                        requestCameraPermission()
//                    }
//                }

        }
    }
    private fun requestCameraPermission() {
        val permissions = arrayOf(
            Manifest.permission.CAMERA
        )
        ActivityCompat.requestPermissions(
            this,
            permissions,
            MY_PERMISSIONS_REQUEST_STORAGE_PERMISSIONS
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == MY_PERMISSIONS_REQUEST_STORAGE_PERMISSIONS ){
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera = true
                createCameraIntent()
            }else{
                Toast.makeText(this@UploadReceiptInfoActivity,resources.getString(R.string.plz_allow_permission),Toast.LENGTH_SHORT).show()
            }

        }
    }

    private fun isStoragePermisssionGranted(): Boolean {
        var granted = false
        granted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
        }
        return granted
    }
    override fun onClickRemovePhoto(photoUrl: String) {
        // Remove the photo from photo array
        mCurrentPhotoPaths.remove(photoUrl)

        // Refresh the photo list
        photoAdapter.setPhotos(mCurrentPhotoPaths)
    }

    /**
     * OnActivityResult
     */
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        openCamera = false

        if (resultCode == RESULT_OK) {
            if (requestCode == OpenCameraActivity.REQUEST_TAKE_PHOTO){
                try {
                    if (mCurrentPhotoPath == null && mCurrentPhotoPath == ""){
                        showErrorDialog(Exception(getString(R.string.file_not_found)))
                        return
                    }

                    compressPhoto()
                    setBitmapToView()
//                    uploadPhoto()
                }
                catch (e : Exception){
                    showErrorDialog(e)
                }

            }
        }
    }

    override fun onBackPressed() {
//        super.onBackPressed()
        finish()
    }

    override fun onResume() {
        super.onResume()

        openCamera = false
    }

    override fun onStart() {
        super.onStart()

        openCamera = false
    }

    override fun onStop() {
        super.onStop()

        openCamera = false
    }

}