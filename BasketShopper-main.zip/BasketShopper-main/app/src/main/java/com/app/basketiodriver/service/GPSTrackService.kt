package com.app.basketiodriver.service

import android.Manifest
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import androidx.core.content.ContextCompat
import com.app.basketiodriver.ShopperApp
import com.app.basketiodriver.utils.PopupUtils

import timber.log.Timber
import java.util.concurrent.TimeUnit

// Service to get Users Location
class GPSTrackService(private val context: Context) : Service() {
    private val TAG : String = "GPSTracker"
    companion object {
        // The minimum distance to change Updates in meters
        private val MIN_DISTANCE_CHANGE_FOR_UPDATES: Float = 0.0F // 0 meters

        // The minimum time between updates in milliseconds
        private val MIN_TIME_BW_UPDATES = TimeUnit.SECONDS.toMillis(5) // update the location every 5 seconds
    }

    // Flag for GPS status
    internal var isGPSEnabled = false

    // Flag for network status
    internal var isNetworkEnabled = false

    // Flag for GPS status
    internal var canGetLocation = false

    internal var mLocation: Location? = null // Location
    internal var latitude: Double = 0.0 // Latitude
    internal var longitude: Double = 0.0 // Longitude

    // Declaring a Location Manager
    var locationManager: LocationManager? = null

    // interface
    var gpsTrackerListener : GPSTrackerListener? = null

    private val mLocationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {

            if (location != null) {
                Timber.tag(TAG).d("===== onLocationChanged() : changed the current location...")
                mLocation = location
                latitude = location.latitude
                longitude = location.longitude

                Timber.tag(TAG).d("===== shopper latitude : %s", latitude)
                Timber.tag(TAG).d("===== shopper longitude : %s", longitude)

                ShopperApp.Instance.mCurrentLocation = location

                if (gpsTrackerListener != null){
                    gpsTrackerListener!!.didGetCurrentLocation()
                }
            }
            else{
                Timber.tag(TAG).d("===== onLocationChanged() : location is null...")
            }
        }

        override fun onStatusChanged(provider: String, status: Int, extras: Bundle) {
            Timber.tag(TAG).d("===== onStatusChanged()")
        }

        override fun onProviderEnabled(provider: String) {
            Timber.tag(TAG).d("===== onProviderEnabled()")
        }

        override fun onProviderDisabled(provider: String) {
            Timber.tag(TAG).d("===== onProviderDisabled()")
        }
    }

    init {
        getLocation()
    }

    private fun getLocation(): Location? {
        Timber.tag(TAG).d("===== getLocation()")

        try {
            locationManager = context.getSystemService(LOCATION_SERVICE) as LocationManager

            // Getting GPS status
            isGPSEnabled = locationManager!!.isProviderEnabled(LocationManager.GPS_PROVIDER)

            // Getting network status
            isNetworkEnabled = locationManager!!.isProviderEnabled(LocationManager.NETWORK_PROVIDER)

            if (!isGPSEnabled && !isNetworkEnabled) {
                // No network provider is enabled
            } else {
                this.canGetLocation = true

                if (isGPSEnabled){
                    if (mLocation == null){
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                            this.canGetLocation = false

                            Timber.tag(TAG).d("===== getLocation() : Permissions are not granted")
                        }
                        else {
                            locationManager!!.requestLocationUpdates(
                                LocationManager.GPS_PROVIDER,
                                MIN_TIME_BW_UPDATES,
                                MIN_DISTANCE_CHANGE_FOR_UPDATES,
                                mLocationListener
                            )

                            Timber.tag(TAG).d("===== getLocation() : try to get location by using GPS provider")

                            mLocation = locationManager!!.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                            if (mLocation != null) {
                                latitude = mLocation!!.latitude
                                longitude = mLocation!!.longitude

                                Timber.tag(TAG).d("===== shopper latitude : %s", mLocation!!.latitude)
                                Timber.tag(TAG).d("===== shopper longitude : %s", mLocation!!.longitude)

                                ShopperApp.Instance.mCurrentLocation = mLocation
                            }
                        }
                    }
                    else{
                        Timber.tag(TAG).d("===== shopper latitude : %s", mLocation!!.latitude)
                        Timber.tag(TAG).d("===== shopper longitude : %s", mLocation!!.longitude)
                    }
                }
                else if (isNetworkEnabled) {
                    if (mLocation == null) {

                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                        {
                            this.canGetLocation = false
                            Timber.tag(TAG).d("===== getLocation() : Permissions are not granted")
                        }
                        else {
                            locationManager!!.requestLocationUpdates(
                                LocationManager.NETWORK_PROVIDER,
                                MIN_TIME_BW_UPDATES,
                                MIN_DISTANCE_CHANGE_FOR_UPDATES, mLocationListener
                            )

                            Timber.tag(TAG).d("===== getLocation() : try to get location by using Network provider")

                            mLocation = locationManager!!.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                            if (mLocation != null) {
                                latitude = mLocation!!.latitude
                                longitude = mLocation!!.longitude

                                Timber.tag(TAG).d("===== shopper latitude : %s", mLocation!!.latitude)
                                Timber.tag(TAG).d("===== shopper longitude : %s", mLocation!!.longitude)

                                ShopperApp.Instance.mCurrentLocation = mLocation
                            }
                        }
                    }
                    else{
                        Timber.tag(TAG).d("===== shopper latitude : %s", mLocation!!.latitude)
                        Timber.tag(TAG).d("===== shopper longitude : %s", mLocation!!.longitude)
                    }
                }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }

        return mLocation
    }


    /**
     * Stop using GPS listener
     * Calling this function will stop using GPS in your app.
     */
    fun stopUsingGPS() {
        if (locationManager != null) {
            locationManager!!.removeUpdates(mLocationListener)
            locationManager = null
        }
    }

    /**
     * Function to get latitude
     */
    fun getLatitude(): Double {
        if (mLocation != null) {
            latitude = mLocation!!.latitude
        }

        // return latitude
        return latitude
    }


    /**
     * Function to get longitude
     */
    fun getLongitude(): Double {
        if (mLocation != null) {
            longitude = mLocation!!.longitude
        }

        // return longitude
        return longitude
    }

    /**
     * Function to check GPS/Wi-Fi enabled
     * @return boolean
     */
    fun canGetLocation(): Boolean {
        return this.canGetLocation
    }


    /**
     * Function to show settings alert dialog.
     * On pressing the Settings button it will launch Settings Options.
     */
    fun showSettingsAlert() {
        PopupUtils.showConfirmDialog(
            context,
            "GPS is settings",
            "GPS is not enabled. Do you want to go to settings menu?"
        ) {
            val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            context.startActivity(intent)
        }
    }


    override fun onBind(arg0: Intent): IBinder? {
        return null
    }

    // Interface to notify LocationChangedStatus
    interface GPSTrackerListener {
        fun didGetCurrentLocation()
    }
}