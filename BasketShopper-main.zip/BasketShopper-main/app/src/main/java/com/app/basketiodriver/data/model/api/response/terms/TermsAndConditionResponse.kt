package com.app.basketiodriver.data.model.api.response.terms

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName


class TermsAndConditionResponse {

    @SerializedName("data")
    @Expose
    var data: TermsAndConditionData? = null

    @SerializedName("message")
    @Expose
    var message: String? = null

    @SerializedName("status")
    @Expose
    var status = 0

    inner class TermsAndConditionData {
        @SerializedName("title")
        @Expose
        var title: String? = null

        @SerializedName("description")
        @Expose
        var description: String? = null
    }
}