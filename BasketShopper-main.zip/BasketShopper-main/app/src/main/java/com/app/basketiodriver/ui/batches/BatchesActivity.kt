package com.app.basketiodriver.ui.batches

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import androidx.fragment.app.Fragment
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.ActivityBatchesBinding
import com.app.basketiodriver.databinding.DailogArriveAtStoreTipBinding
//import com.app.basketiodriver.databinding.DialogNotBasketPoweredLocationBinding
import com.app.basketiodriver.databinding.DialogWhatIncludedMessageBinding
import com.app.basketiodriver.ui.availablebatches.AvailableBatchesViewModel
import com.app.basketiodriver.ui.base.BaseActivity
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import javax.inject.Inject


class BatchesActivity : BaseActivity<ActivityBatchesBinding?, AvailableBatchesViewModel>(),
    HasAndroidInjector {


    override val layoutId: Int
        get() = R.layout.activity_batches

    override val viewModel: AvailableBatchesViewModel
        get() {
            return getViewModel(AvailableBatchesViewModel::class.java)
        }

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>
    override fun androidInjector() = dispatchingAndroidInjector

    private var navController: NavController? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        navController = Navigation.findNavController(this, R.id.navBatches)


//        showDialogNotBasketPoweredLocation()
        showDailogArriveAtStoreTipBinding()
    }

    companion object {
        fun newIntent(context: Context?): Intent {
            return Intent(context, BatchesActivity::class.java)
        }
    }


    override fun onSupportNavigateUp() =
        navController!!.popBackStack()


    fun showWhatIncludedMessages() {
        val dialog = Dialog(this, R.style.PauseDialog)
        val binding = DialogWhatIncludedMessageBinding.inflate(LayoutInflater.from(this))
        dialog.setContentView(binding.root)
        dialog.setCanceledOnTouchOutside(true)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        binding.btnOkay.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }


//    fun showDialogNotBasketPoweredLocation() {
//        val dialog = Dialog(this, R.style.PauseDialog)
//        val binding = DialogNotBasketPoweredLocationBinding.inflate(LayoutInflater.from(this))
//        dialog.setContentView(binding.root)
//        dialog.setCanceledOnTouchOutside(true)
//        binding.btnLocations.setOnClickListener { dialog.dismiss() }
//        binding.btnOkay.setOnClickListener { dialog.dismiss() }
//
//        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//        dialog.show()
//    }

    fun showDailogArriveAtStoreTipBinding() {
        val dialog = Dialog(this, R.style.PauseDialog)
        val binding = DailogArriveAtStoreTipBinding.inflate(LayoutInflater.from(this))
        dialog.setContentView(binding.root)
        dialog.setCanceledOnTouchOutside(true)
        binding.btnOk.setOnClickListener { dialog.dismiss() }
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
    }


}
