package com.app.basketiodriver.ui.onboarding

import android.app.Application
import android.graphics.Bitmap
import androidx.annotation.NonNull
import androidx.lifecycle.MutableLiveData
import com.app.basketiodriver.R
import com.app.basketiodriver.data.DataManager
import com.app.basketiodriver.data.model.api.requests.ProfileRequest
import com.app.basketiodriver.data.model.api.response.Base.BaseResponse
import com.app.basketiodriver.data.model.api.response.DocumentsResponse
import com.app.basketiodriver.data.model.api.response.ShopperDocumentsResponse
import com.app.basketiodriver.data.model.db.OnbaordingStages
import com.app.basketiodriver.ui.base.BaseViewModel
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.onboarding.data.Stage
import com.app.basketiodriver.utils.AppConstants.KEY_FULL_SERVICE
import com.app.basketiodriver.utils.AppLogger
import io.reactivex.Single
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import okhttp3.RequestBody
import java.io.File

/**
 * Created by ibraheem lubbad on 2020-01-22.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class OnBoardingViewModel constructor(@NonNull application: Application, dataManager: DataManager) :
    BaseViewModel<OnBoardingNavigator?>(application, dataManager) {

    /**
     * Property to check shopper user has car or not
     */
    var isHasCar = false

    /**
     * property for current user service type
     */
    var DOC_SELECTED_ROLE = KEY_FULL_SERVICE


    var ndaContract = MutableLiveData<String>()

    /**
     * property for  hold uploaded documents
     */
    var currentOnbaordingDocument: DocumentsResponse.OnbaordingDocument? = null


    /**
     * onbaording reviewing  stages
     */
    val listItems = kotlin.collections.mutableListOf<Stage>()
    val basicListItems = kotlin.collections.mutableListOf<Stage>()
    var currentOnbaordingConfig:Single<OnbaordingStages?>? =null

    fun initStages() {

        basicListItems.addAll(
            mutableSetOf(
                Stage(
                    "personal_data",
                    application.getString(R.string.personal_data),
                    false,
                    true,
                    listOf(
                        DocumentsResponse.OnbaordingDocument(
                            1,
                            application.getString(R.string.basic_info),
                            application.getString(R.string.basic_info),
                            null,
                            null,
                            null
                        ),
                        DocumentsResponse.OnbaordingDocument(
                            1,
                            application.getString(R.string.take_self),
                            application.getString(R.string.take_self),
                            null,
                            null,
                            null
                        )
                    )
                ),
                Stage(
                    application.getString(R.string.car_info),
                    application.getString(R.string.car_info),
                    false,
                    true,
                    listOf(
                        DocumentsResponse.OnbaordingDocument(
                            1,
                            application.getString(R.string.car_info),
                            application.getString(R.string.vehicle_info),
                            null, null, null
                        )

                    )
                )
            )
        )
        listItems.addAll(basicListItems)


    }

    /**
     * upload shopper signature
     * @param signature Bitmap signature image
     * @param handleResponse HandleResponse<BaseResponse>
     */
    fun shopperUpdateProfile(
        profileRequest: ProfileRequest,
        handleResponse: HandleResponse<BaseResponse>
    ) {


    }
    /**
     * upload shopper signature
     * @param signature Bitmap signature image
     * @param handleResponse HandleResponse<BaseResponse>
     */
    fun getCurrentUserOnbaordingConfig(
        id: Int,
        handleResponse: HandleResponse<OnbaordingStages>
    ) {

        setIsLoading(true)
        val currentUserOnbaordingConfig = dataManager.findCurrentUserOnbaordingConfig(1)

        currentUserOnbaordingConfig?.subscribeOn(Schedulers.io())
            ?.observeOn(AndroidSchedulers.mainThread())
            ?.subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        currentOnbaordingConfig = currentUserOnbaordingConfig
                        AppLogger.d("")
                        handleResponse.handleSuccessResponse(result!!)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }


                }
            )?.let {
                compositeDisposable.add(
                    it
                )
            }
    }

    fun uploadSignatureRequest(signature: Bitmap, handleResponse: HandleResponse<BaseResponse>) {

//        setIsLoading(true)
//
//        val file = convertBitmapToFile(application, signature, "signature")
//
//        compositeDisposable.add(dataManager.uploadSignatureRequest(
//                UploadDocumentRequest.UploadSignatureRequest(
//                    "9".toRequestBody("text/plain".toMediaTypeOrNull()),
//                    accessToken.toRequestBody("text/plain".toMediaTypeOrNull()),
//                    file.asRequestBody("image/*".toMediaTypeOrNull())
//                )
//            )
//            .subscribeOn(Schedulers.io())
//            .observeOn(AndroidSchedulers.mainThread())
//            .subscribe(
//                { result ->
//                    run {
//                        setIsLoading(false)
//                        handleResponse.handleSuccessResponse(result)
//                    }
//                },
//                { x ->
//                    run {
//                        setIsLoading(false)
//                        handleResponse.handleErrorResponse(getThrowableError(x))
//                    }
//
//
//                }
//            ))
    }

    fun storeShopperDocuments(
        request: RequestBody,
        handleResponse: HandleResponse<ShopperDocumentsResponse>
    ) {

//        setIsLoading(true)
//
//        compositeDisposable.add(dataManager.storeShopperDocuments(request)
//            .subscribeOn(Schedulers.io())
//            .observeOn(AndroidSchedulers.mainThread())
//            .subscribe(
//                { result ->
//                    run {
//                        setIsLoading(false)
//                        handleResponse.handleSuccessResponse(result)
//                    }
//                },
//                { x ->
//                    run {
//                        setIsLoading(false)
//                        AppLogger.d("${x.message}")
//                        parseError(x)
//                        handleResponse.handleErrorResponse(getThrowableError(x))
//                    }
//
//
//                }
//            ))
    }


    fun uploadUserImage(
        file: File,
        handleResponse: HandleResponse<BaseResponse>
    ) {
//        setIsLoading(true)
//        compositeDisposable.add(dataManager.updateProfileImage(
//                file.asRequestBody("image/*".toMediaTypeOrNull()))
//            .subscribeOn(Schedulers.io())
//            .observeOn(AndroidSchedulers.mainThread())
//            .subscribe(
//                { result ->
//                    run {
//                        setIsLoading(false)
//                        handleResponse.handleSuccessResponse(result)
//                    }
//                },
//                { x ->
//                    run {
//                        setIsLoading(false)
//                        AppLogger.d("${x.message}")
//                        parseError(x)
//                        handleResponse.handleErrorResponse(getThrowableError(x))
//                    }
//
//
//                }
//            ))
    }


    /**
     * Method to call api to upload  shopper National Id  for two type
     * @param signature Bitmap
     * @param side String
     * @param handleResponse HandleResponse<BaseResponse>
     */
    fun uploadDocumentIdPRequest(
        signature: Bitmap,
        side: String,
        handleResponse: HandleResponse<BaseResponse>
    ) {
//        setIsLoading(true)
//
//        val file = convertBitmapToFile(application, signature, "DocumentId")
//        compositeDisposable.add(dataManager.uploadDocumentIdPRequest(
//                UploadDocumentRequest.UploadDocumentIdPRequest(
//                    "9".toRequestBody("text/plain".toMediaTypeOrNull()),
//                    accessToken.toRequestBody("text/plain".toMediaTypeOrNull()),
//                    file.asRequestBody("image/*".toMediaTypeOrNull()),
//                    side.toRequestBody("text/plain".toMediaTypeOrNull())
//                )
//            )
//            .subscribeOn(Schedulers.io())
//            .observeOn(AndroidSchedulers.mainThread())
//            .subscribe(
//                { result ->
//                    run {
//                        setIsLoading(false)
//                        handleResponse.handleSuccessResponse(result)
//                    }
//                },
//                { x ->
//                    run {
//                        setIsLoading(false)
//                        handleResponse.handleErrorResponse(getThrowableError(x))
//                    }
//
//
//                }
//            ))
    }

    /**
     * Method to call api to upload Licence documents
     * @param signature Bitmap
     * @param side String
     * @param handleResponse HandleResponse<BaseResponse>
     */
    fun uploadLicenceRequest(
        signature: Bitmap,
        side: String,
        handleResponse: HandleResponse<BaseResponse>
    ) {


//        setIsLoading(true)
//
//        val file = convertBitmapToFile(application, signature, "licence")
//        compositeDisposable.add(dataManager.uploadLicenceRequest(
//                UploadDocumentRequest.UploadLicenceRequest(
//                    "591".toRequestBody("text/plain".toMediaTypeOrNull()),
//                    accessToken.toRequestBody("text/plain".toMediaTypeOrNull()),
//                    file.asRequestBody("image/*".toMediaTypeOrNull()),
//                    side.toRequestBody("text/plain".toMediaTypeOrNull())
//                )
//            )
//            .subscribeOn(Schedulers.io())
//            .observeOn(AndroidSchedulers.mainThread())
//            .subscribe(
//                { result ->
//                    run {
//                        setIsLoading(false)
//                        AppLogger.d("Response " + result)
//                        handleResponse.handleSuccessResponse(result)
//                    }
//                },
//                { x ->
//                    run {
//                        setIsLoading(false)
//                        handleResponse.handleErrorResponse(getThrowableError(x))
//                    }
//
//
//                }
//            ))
    }


    fun getNDAContract(
    ) {

//        setIsLoading(true)
//        compositeDisposable.add(dataManager.NDAResponse()
//            .subscribeOn(Schedulers.io())
//            .observeOn(AndroidSchedulers.mainThread())
//            .subscribe(
//                { result ->
//                    run {
//                        setIsLoading(false)
//                        ndaContract.value = result.content
//                        //  handleResponse.handleSuccessResponse(result)
//                    }
//                },
//                { x ->
//                    run {
//                        setIsLoading(false)
//                        //  parseError(x)
//                    }
//
//
//                }
//            ))
    }

    fun getOnbaordingDocumentList(
        handleResponse: HandleResponse<DocumentsResponse>
    ) {


//        setIsLoading(true)
//        compositeDisposable.add(dataManager.getOnbaordingDocumentList()
//            .subscribeOn(Schedulers.io())
//            .observeOn(AndroidSchedulers.mainThread())
//            .subscribe(
//                { result ->
//                    run {
//                        setIsLoading(false)
//                        listItems.clear()
//                        listItems.addAll(basicListItems)
//
//                        AppLogger.d("result ${result} ")
//                        handleResponse.handleSuccessResponse(result)
//
//
//                        val groupBy = result.onbaordingDocumentLists!!.groupBy {
//                            it.superDocumentType!!.name
//                        }
//
//                        groupBy.forEach {
//                            listItems.add(
//                                Stage(
//                                    it.key,
//                                    it.key,
//                                    false,
//                                    true,
//                                    it.value
//                                )
//                            )
//                        }
//
//
//                    }
//                },
//                { x ->
//                    run {
//                        AppLogger.d("error ${x.message}")
//                        setIsLoading(false)
//                        //  parseError(x)
//                    }
//
//
//                }
//            ))
    }


    /**
     * Class to hold all documents types
     * @property type String
     * @property side String
     * @property path String
     * @constructor
     */
    data class Documents(val type: String, val side: String, val path: String)


}


