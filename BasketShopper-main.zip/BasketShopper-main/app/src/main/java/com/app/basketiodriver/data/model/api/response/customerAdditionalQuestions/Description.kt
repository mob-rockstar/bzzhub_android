package com.app.basketiodriver.data.model.api.response.customerAdditionalQuestions

data class Description(
    val lang: String,
    val text: String
)