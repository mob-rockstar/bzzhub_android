package com.app.basketiodriver.ui.onboarding.fragments


import android.os.Bundle
import android.view.View
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentRoleShopAndDriveBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.onboarding.OnBoardingViewModel
import com.app.basketiodriver.ui.onboarding.OnJoinWaitListNavigator
import com.app.basketiodriver.utils.AppConstants

/**
 * Created by ibraheem lubbad on 2020-01-22.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class RoleShopAndDriveFragment(private val onJoinWaitListNavigator: OnJoinWaitListNavigator) :
    BaseFragment<FragmentRoleShopAndDriveBinding?, OnBoardingViewModel>(),
    Injectable {

    override val layoutId: Int
        get() = R.layout.fragment_role_shop_and_drive

    override val viewModel: OnBoardingViewModel
        get() {
            return getViewModel(requireActivity(), OnBoardingViewModel::class.java)
        }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.review_in_progress))

        viewDataBinding!!.btnJoinWaitList.setOnClickListener {
            /**
             * change current user type to full  service
             */
            viewModel.DOC_SELECTED_ROLE = AppConstants.KEY_FULL_SERVICE
            onJoinWaitListNavigator.goToJoin()
        }
    }

}


