package com.app.basketiodriver.data.remote

import android.content.Context
import com.app.basketiodriver.BuildConfig
import com.app.basketiodriver.data.model.api.response.directions.ServerAnswer
import com.google.android.gms.maps.model.LatLng
import com.google.gson.GsonBuilder
import com.jakewharton.retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import io.reactivex.Single
import okhttp3.Cache
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.File
import java.util.concurrent.TimeUnit

object GoogleAPIManager {
    private lateinit var apiInterface: GoogleAPIInterface
    private const val CACHE_FILE_NAME = "basket_google_http_cache"
    private const val GOOGLE_BASE_URL = "https://maps.googleapis.com/maps/api/"

    fun init(context: Context) {
        // cache
        val cacheFile = File(context.cacheDir, GoogleAPIManager.CACHE_FILE_NAME)
        cacheFile.mkdir()
        val cache = Cache(cacheFile, 10 * 1000 * 1000)

        // OKHttp
        val okHttpClient = OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .readTimeout(50, TimeUnit.SECONDS)
            .addInterceptor(LoggingInterceptor())
            .cache(cache)
            .build()

        // Retrofit
        val retrofit = Retrofit.Builder()
            .baseUrl(GOOGLE_BASE_URL)
            .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
            .addConverterFactory(
                GsonConverterFactory.create(
                    GsonBuilder()
                        .setLenient()
                        .create()
                )
            )
            .client(okHttpClient).build()

        apiInterface = retrofit.create(GoogleAPIInterface::class.java)
    }

    fun getDirections(from : LatLng, to : LatLng, apiKey : String) : Single<ServerAnswer>{
        val origin = "" + from.latitude + "," + from.longitude
        val dest = "" + to.latitude + "," + to.longitude
        return apiInterface.getDirections(origin, dest, apiKey, "driving")
    }
}