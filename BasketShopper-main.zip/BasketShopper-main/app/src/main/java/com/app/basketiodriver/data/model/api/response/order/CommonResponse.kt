package com.app.basketiodriver.data.model.api.response.order

import com.google.gson.JsonElement
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class CommonResponse {
    @SerializedName("data")
    @Expose
    val data: JsonElement? = null

    @SerializedName("message")
    @Expose
    val message: String = ""

    @SerializedName("status")
    @Expose
    val status: Int = 0
}