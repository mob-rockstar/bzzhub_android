package com.app.basketiodriver.di.builder

//import com.app.basketiodriver.ui.home.fragments.full0rder.OrderStatusDoneFragment
//import com.app.basketiodriver.ui.home.fragments.full0rder.OrderStatusInreviewFragment
//import com.app.basketiodriver.ui.home.fragments.full0rder.OrderToDoFragment
//import com.app.basketiodriver.ui.home.fragments.full0rder.fragments.CanNotFindItemFragment
//import com.app.basketiodriver.ui.home.fragments.full0rder.fragments.OrderDetailFragment
import dagger.Module
import dagger.android.ContributesAndroidInjector

/**
 * Created by ibraheem lubbad on 2020-02-24.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 */
@Module
abstract class FragmentOrderListModule {

    /*  @ContributesAndroidInjector
      abstract fun contributeOrderListStatusFragment(): OrderListStatusFragment
  */
//    @ContributesAndroidInjector
//    abstract fun contributeOrderStatusDoneFragment(): OrderStatusDoneFragment
//
//    @ContributesAndroidInjector
//    abstract fun contributeOrderStatusInreviewFragment(): OrderStatusInreviewFragment
//
//    @ContributesAndroidInjector
//    abstract fun contributeOrderToDoFragment(): OrderToDoFragment
//
//    @ContributesAndroidInjector
//    abstract fun contributeCanNotFindItemFragment(): CanNotFindItemFragment

//    @ContributesAndroidInjector
//    abstract fun contributeOrderDetailFragment(): OrderDetailFragment


}
