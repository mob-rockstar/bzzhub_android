package com.app.basketiodriver.ui.earning.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.earning.monthly.ReportView
import com.app.basketiodriver.databinding.ItemOrderEarningsBinding
import com.app.basketiodriver.ui.base.DataListAdapter
import com.app.basketiodriver.ui.base.DataViewHolder
import com.app.basketiodriver.utils.CommonUtils
import com.app.basketiodriver.utils.GlideApp
import com.app.basketiodriver.utils.OnItemClickedListener
import java.util.*

class OrderEarningsAdapter(val mContext : Context, val listener: OnItemClickedListener<ReportView>) :
    DataListAdapter<ReportView, ItemOrderEarningsBinding>() {

    override fun createBinding(inflater: LayoutInflater, parent: ViewGroup? ): ItemOrderEarningsBinding {
        return DataBindingUtil.inflate(inflater, R.layout.item_order_earnings, parent, false)
    }

    override fun onBindViewHolder(holder: DataViewHolder<ItemOrderEarningsBinding>, position: Int) {
        super.onBindViewHolder(holder, position)
        holder.binding.root.setOnClickListener { listener.onClicked(holder.binding.reportItem!!) }
    }

    override fun bind(binding: ItemOrderEarningsBinding?, item: ReportView) {
        binding!!.reportItem = item

        // Vendor Title
        binding.txtTitle.text = item.vendor_name

        // Start Address
        binding.txtStartAddress.text = item.vendor_address

        // Items Count
        val items = item.ordered_item_count + " " + mContext.getString(R.string.items)
        binding.txtItems.text = items

        // Destination
        val name = item.first_name + " " + item.last_name
        binding.txtDestination.text = name

        // Destination Address
        binding.txtDestinationAddress.text = item.customer_address

        // Service
        binding.txtService.text = item.service_type

        // Order Value
        val totalAmount = String.format(Locale("en"), "%s %s", PreferenceManager.currency, item.order_total_amount)
        binding.txtOrderValue.text = totalAmount

        CommonUtils.setBalanceTextColor(binding.txtOrderValue, "" + item.order_total_amount)

        // Distance
        binding.txtTotalKm.text = String.format(Locale("en"), "%s %s", item.distance_in_km, mContext.getString(R.string.km_label))

        if (item.service_type_flag == 1){
            binding.txtService.setTextColor(mContext.resources.getColor(R.color.colorPrimary))
        }
        else if (item.service_type_flag == 2){
            binding.txtService.setTextColor(mContext.resources.getColor(R.color.colorItemDifferent))
        }
        else{
            binding.txtService.setTextColor(mContext.resources.getColor(R.color.colorDisabledButton))
        }

        // Load images
        if (item.vendor_image != null){
            GlideApp.with(mContext).load(item.vendor_image).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(binding.imgVender)
        }
    }
}