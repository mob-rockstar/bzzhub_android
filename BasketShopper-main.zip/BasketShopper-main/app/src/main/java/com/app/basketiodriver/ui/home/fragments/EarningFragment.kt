package com.app.basketiodriver.ui.home.fragments


import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.requests.EarningReportDetailRequest
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.EarningReportResponse
import com.app.basketiodriver.databinding.FragmentEarningBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.home.HomeViewModel


/**
 * A simple [Fragment] subclass.
 */
class EarningFragment : BaseFragment<FragmentEarningBinding?, HomeViewModel>(),
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_earning

    override val viewModel: HomeViewModel
        get() {
            return getViewModel(requireActivity(), HomeViewModel::class.java)
        }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        val request = EarningReportDetailRequest(22, 1, "weekly", 202, 3, 1, 2)

        viewModel.getEarningReportDetails(
            request,
            object : HandleResponse<EarningReportResponse.EarningReportData?> {

                override fun handleErrorResponse(error: ErrorResponse?) {

                }

                override fun handleSuccessResponse(successResponse: EarningReportResponse.EarningReportData?) {
                    viewDataBinding!!.tvCurrentBalance.formatPrice(successResponse!!.current_account_balance)

                    successResponse.current_account_balance
                }
            })
    }


}
