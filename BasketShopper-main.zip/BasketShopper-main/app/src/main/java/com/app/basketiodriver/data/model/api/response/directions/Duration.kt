package com.app.basketiodriver.data.model.api.response.directions

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class Duration {
    @SerializedName("text")
    @Expose
    val text: String? = null

    @SerializedName("value")
    @Expose
    val value: Int? = null
}