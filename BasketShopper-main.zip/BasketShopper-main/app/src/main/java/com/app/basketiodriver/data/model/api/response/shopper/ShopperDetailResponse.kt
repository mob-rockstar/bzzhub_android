package com.app.basketiodriver.data.model.api.response.shopper

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName


class ShopperDetailResponse {
    @SerializedName("httpCode")
    @Expose
    val httpCode: Int = 200

    @SerializedName("Message")
    @Expose
    val message: String? = ""

    @SerializedName("shopper_data")
    @Expose
    val shopperData: ShopperData? = null
}