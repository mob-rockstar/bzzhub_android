package com.app.basketiodriver.data.remote.socket


/**
Created by ibraheem lubbad on 2/25/20.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class NullSocketException : Exception("Trying to use socket with a null pointer")
