package com.app.basketiodriver.ui.base


import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.EditText
import android.widget.TextView
import androidx.annotation.LayoutRes
import androidx.appcompat.widget.AppCompatSpinner
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.NavDirections
import androidx.navigation.fragment.NavHostFragment.findNavController
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.ErrorDailogBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.utils.BR
import com.app.basketiodriver.utils.ViewModelProviderFactory
import com.google.android.material.textfield.TextInputEditText
import dagger.android.support.AndroidSupportInjection
import javax.inject.Inject

/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
abstract class BaseFragment<T : ViewDataBinding?, V : BaseViewModel<*>?> : Fragment(), Injectable {

    /**
     *  inject factory to bind view model current fragments
     */
    @Inject
    lateinit var viewModelFactory: ViewModelProviderFactory

    var baseActivity: BaseActivity<*, *>? = null
        private set


    private var mRootView: View? = null


    var viewDataBinding: T? = null
        private set

    private var mViewModel: V? = null
    /**
     * Override for set binding variable
     *
     * @return variable id
     */
    private val bindingVariable: Int = BR._all

    /**
     * @return layout resource id
     */
    @get:LayoutRes
    abstract val layoutId: Int

    /**
     * Override for set view model
     *
     * @return view model instance
     */
    abstract val viewModel: V

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is BaseActivity<*, *>) {
            val activity = context
            baseActivity = activity
            activity.onFragmentAttached()
        }
    }

    protected open fun <T : ViewModel> getViewModel(cls: Class<T>): T {
        return ViewModelProviders.of(this, viewModelFactory)[cls]
    }

    protected open fun <T : ViewModel> getViewModel(
        fregmentActivity: FragmentActivity,
        cls: Class<T>
    ): T {
        return ViewModelProviders.of(fregmentActivity, viewModelFactory)[cls]
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        performDependencyInjection()
        super.onCreate(savedInstanceState)
        mViewModel = viewModel
        setHasOptionsMenu(false)

    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        viewDataBinding = DataBindingUtil.inflate<T>(inflater, layoutId, container, false)
        mRootView = viewDataBinding!!.root
        return mRootView
    }

//    override fun onDetach() {
//        baseActivity = null
//        super.onDetach()
//    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewDataBinding!!.setVariable(bindingVariable, mViewModel)
        viewDataBinding!!.lifecycleOwner = this
        viewDataBinding!!.executePendingBindings()
    }

    fun hideKeyboard() {
        if (baseActivity != null) {
            baseActivity!!.hideKeyboard()
        }
    }

    val isNetworkConnected: Boolean
        get() = baseActivity != null && baseActivity!!.isNetworkConnected


    /**
     * preform jnjection  for current fragment
     */
    private fun performDependencyInjection() {
        AndroidSupportInjection.inject(this)
    }

    interface Callback {
        fun onFragmentAttached()
        fun onFragmentDetached(tag: String?)
    }


    /**
     *
     * @param successView View
     * @param errorView View
     */
    private fun showSuccessCaseFor(successView: View, errorView: View) {
        successView.visibility = View.VISIBLE
        errorView.visibility = View.GONE
    }


    private fun showErrorCaseFor(successView: View, errorView: View) {
        successView.visibility = View.GONE
        errorView.visibility = View.VISIBLE
    }

    /**
     * Created to be able to override in tests
     */
    fun navController() = findNavController(this)


    /**
     * navigate to next fragments
     * @param destination NavDirections
     * @return Unit?
     */
    fun navigate(destination: NavDirections) = with(navController()) {

        currentDestination?.getAction(destination.actionId)
            ?.let {
                navigate(destination)

            }
    }


    /**
     * navigate to previous fragments
     * @param destination NavDirections
     * @return Unit?
     */
    fun popNavigate() = with(navController()) {
        popBackStack()
    }
    /**
     * navigate to previous selected fragments
     * @param destination NavDirections
     * @return Unit?
     */
    fun popNavigate(id:Int) = with(navController()) {
        popBackStack(id,true)
    }


    /**
     * Change edit text style to success style when input valid
     * @receiver EditText
     */
    fun EditText.onSuccess() {
        this.setCompoundDrawablesWithIntrinsicBounds(
            null,
            null,
            resources.getDrawable(R.drawable.ic_success_message),
            null
        )
    }

    /**
     * Change  input edit text style to success style when input valid
     * @receiver EditText
     */

    fun TextInputEditText.onSuccess() {
        this.setCompoundDrawablesWithIntrinsicBounds(
            null,
            null,
            resources.getDrawable(R.drawable.ic_success_message),
            null
        )
    }

    /**
     * Change  AppCompatSpinner style to success style when input valid
     * @receiver EditText
     */

    fun AppCompatSpinner.onSuccess() {

        this.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p0: AdapterView<*>?) {
            }

            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                if (view != null && view is TextView) {
                    (view as TextView).setCompoundDrawablesWithIntrinsicBounds(
                        null,
                        null,
                        resources.getDrawable(R.drawable.ic_success_message),
                        null
                    )
                }
            }
        }

    }

    /**
     * Change AppCompatSpinner style to success style when input valid
     * @receiver EditText
     */

    fun AppCompatSpinner.onError() {

        this.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p0: AdapterView<*>?) {
            }

            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                if (view != null && view is TextView) {
                    (view as TextView).setCompoundDrawablesWithIntrinsicBounds(
                        null,
                        null,
                        resources.getDrawable(R.drawable.ic_error_message),
                        null
                    )
                }
            }
        }

    }

    /**
     * Change edit ext style to error style when input invalid
     * @receiver EditText
     */
    fun EditText.onError() {
        this.setCompoundDrawablesWithIntrinsicBounds(
            null,
            null,
            resources.getDrawable(R.drawable.ic_error_message),
            null
        )
    }

    /**
     * change input edit text style to error style when input invalid
     * @receiver TextInputEditText
     */
    fun TextInputEditText.onError() {
        this.setCompoundDrawablesWithIntrinsicBounds(
            null,
            null,
            resources.getDrawable(R.drawable.ic_error_message),
            null
        )
    }


    /**
     * Show dialog  Alert Dialog
     *
     * @param title String
     * @param messages String
     * @param listener OnDismissListener?
     */
    fun showAlertMessages(
        title: String,
        messages: String,
        listener: DialogInterface.OnDismissListener? = null
    ) {


        requireActivity().runOnUiThread {
            if (!activity!!.isFinishing) {
                try {

                    val dialog = Dialog(context!!, R.style.PauseDialog)
                    val binding = ErrorDailogBinding.inflate(LayoutInflater.from(context))
                    dialog.setContentView(binding.root)
                    dialog.setCanceledOnTouchOutside(true)
                    dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                    binding.tvErrorMessages.text = messages
                    binding.tvTitle.text = title
                    binding.btnOkay.setOnClickListener {
                        dialog.dismiss()
                    }
                    if (listener != null) {
                        dialog.setOnDismissListener { listener }
                    }

                    dialog.show()
                } catch (e: Exception) {

                }

            }
        }

    }

    fun TextView.formatPrice(price: Double) {
        this.text = "JOD $price"
    }

    /**
     * Set title for current screen
     * @param title String
     */
    fun setTitle(title: String) {
        viewModel!!.screenTitle.value = title
    }


}