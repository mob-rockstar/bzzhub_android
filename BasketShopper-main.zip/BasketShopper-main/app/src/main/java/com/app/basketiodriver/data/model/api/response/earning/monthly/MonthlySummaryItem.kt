package com.app.basketiodriver.data.model.api.response.earning.monthly

import com.google.gson.annotations.SerializedName


class MonthlySummaryItem {
    @SerializedName("previous_month_balance")
    var previousMonthBalance: Double = 0.0

    @SerializedName("total_month_earnings")
    var totalMonthEarnings: Double = 0.0

    @SerializedName("total_month_bonus_deduction")
    var totalMonthBonusDeduction: Double = 0.0

    @SerializedName("total_month_payout_credits")
    var totalMonthPayoutCredits: Double = 0.0

    @SerializedName("total_end_of_month_balance")
    var totalEndOfMonthBalance: Double = 0.0

    @SerializedName("total_month_collected")
    var totalMonthCollected: Double = 0.0

    @SerializedName("contact_support_text")
    var contactSupportText: String = ""

    @SerializedName("current_account_balance")
    var currentAccountBalance: Double = 0.0

    @SerializedName("is_account_suspended")
    var isAccountSuspended: Boolean = false

    @SerializedName("total_month_promo")
    var total_month_promo: Boolean = false

    @SerializedName("total_month_payout")
    var total_month_payout: Double = 0.0

    @SerializedName("total_month_credits")
    var total_month_credits: Double = 0.0

    @SerializedName("total_month_bonus")
    var total_month_bonus: Double = 0.0

    @SerializedName("total_month_deduction")
    var total_month_deduction: Double = 0.0
}