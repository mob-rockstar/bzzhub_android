package com.app.basketiodriver.ui.cardcamera.camera

import android.app.Activity
import android.content.Intent
import androidx.fragment.app.Fragment
import java.lang.ref.WeakReference

class IDCardCamera private constructor(
    activity: Activity?,
    fragment: Fragment? = null
) {
    private val mActivity: WeakReference<Activity?>
    private val mFragment: WeakReference<Fragment?>

    private constructor(fragment: Fragment) : this(
        fragment.activity,
        fragment
    )

    /**
     * open Camera screen according required direction
     * @param IDCardDirection Int
     */
    fun openCamera(IDCardDirection: Int) {
        val activity = mActivity.get()
        val fragment = mFragment.get()
        val intent = Intent(activity, CameraActivity::class.java)
        intent.putExtra(TAKE_TYPE, IDCardDirection)
        if (fragment != null) {
            fragment.startActivityForResult(intent, IDCardDirection)
        } else {
            activity!!.startActivityForResult(intent, IDCardDirection)
        }
    }

    companion object {
        const val TYPE_IDCARD_FRONT = 1
        const val TYPE_IDCARD_BACK = 2
        const val RESULT_CODE = 0X11
        const val PERMISSION_CODE_FIRST = 0x12
        const val TAKE_TYPE = "take_type"
        const val IMAGE_PATH = "image_path"
        fun create(activity: Activity?): IDCardCamera {
            return IDCardCamera(activity)
        }

        fun create(fragment: Fragment): IDCardCamera {
            return IDCardCamera(fragment)
        }

        fun getImagePath(data: Intent?): String {
            return if (data != null) {
                data.getStringExtra(IMAGE_PATH) ?: ""
            } else ""
        }
    }

    init {
        mActivity = WeakReference<Activity?>(activity)
        mFragment = WeakReference<Fragment?>(fragment)
    }
}