package com.app.basketiodriver.ui.home

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.ActivityEnableLocationBinding
import com.app.basketiodriver.ui.base.BaseActivity

class EnableLocationActivity : BaseActivity<ActivityEnableLocationBinding?, HomeViewModel>(){


    override val layoutId: Int
        get() = R.layout.activity_enable_location

    override val viewModel: HomeViewModel
        get() {
            return getViewModel(HomeViewModel::class.java)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewDataBinding?.btnEnablelocation?.setOnClickListener { finish() }
        viewDataBinding?.btnNotNow?.setOnClickListener { finish() }
    }

    companion object {
        fun newIntent(context: Context?): Intent {
            return Intent(context, EnableLocationActivity::class.java)
        }
    }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.home, menu)
        return true
    }

}