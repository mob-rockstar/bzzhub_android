package com.app.basketiodriver.ui.order.product

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.app.basketiodriver.BuildConfig
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.checkout.CustomerInfo
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.databinding.ActivityBarcodeReaderBinding
import com.app.basketiodriver.databinding.ActivityScanItemBinding
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.tbruyelle.rxpermissions2.RxPermissions

class BarcodeReaderActivity : BaseActivity<ActivityBarcodeReaderBinding, OrderDetailsViewModel>()
//    , OnScanListener
{

    override val layoutId: Int
        get() = R.layout.activity_barcode_reader

    override val viewModel: OrderDetailsViewModel
        get() {
            return getViewModel(OrderDetailsViewModel::class.java)
        }

//    var picker : BarcodePicker?= null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Init the Barcode Reader
//        initBarcodeReader()
    }

    // Initialize the Barcode Reader
//    private fun initBarcodeReader(){
//        ScanditLicense.setAppKey(BuildConfig.SCANDIT_KEY)
//        val settings : ScanSettings = ScanSettings.create()
//        val symbolsToEnable = intArrayOf(
//            Barcode.SYMBOLOGY_EAN13,
//            Barcode.SYMBOLOGY_EAN8,
//            Barcode.SYMBOLOGY_UPCA,
//            Barcode.SYMBOLOGY_CODE39,
//            Barcode.SYMBOLOGY_CODE128
//        )
//        for (sym in symbolsToEnable) {
//            settings.setSymbologyEnabled(sym, true)
//        }
//        picker = BarcodePicker(this, settings)
//        picker!!.setOnScanListener(this)
//        viewDataBinding!!.cameraLayout.addView(
//            picker, FrameLayout.LayoutParams(
//                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
//            )
//        )
//    }
    // Check if permission is granted
//    @SuppressLint("MissingPermission", "CheckResult")
//    private fun grantCameraPermission(){
//        val permissions = RxPermissions(this)
//        permissions.request(Manifest.permission.CAMERA)
//            .subscribe { granted: Boolean ->
//                if (granted) {
//                    if (picker != null) {
//                        picker!!.startScanning()
//                    }
//                }
//            }
//    }


    /**
     * OnScanListener
     */
//    override fun didScan(scanSession: ScanSession?) {
//        if (scanSession != null && scanSession.newlyRecognizedCodes.size > 0) {
//            val barcode = scanSession.newlyRecognizedCodes[0].data
//
//            Log.d("TAG", "didScan: "+barcode.toString())
//            runOnUiThread {
//                if (picker != null) {
//                    picker!!.stopScanning()
//                }
//
//                val intent = Intent()
//                intent.putExtra("ARG_BARCODE", barcode)
//                setResult(Activity.RESULT_OK, intent)
//                finish()
//            }
//        }
//    }

    override fun onResume() {
        super.onResume()

//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
//            grantCameraPermission()
//        }
//        else{
//            if (picker != null){
//                picker!!.startScanning()
//            }
//        }
    }

    override fun onPause() {
//        if (picker != null)
//            picker!!.stopScanning()

        super.onPause()
    }
}