package com.app.basketiodriver.ui.notifications.adapter

import android.text.Html
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.notification.NotificationListData
import com.app.basketiodriver.databinding.ItemNotificationListBinding
import com.app.basketiodriver.utils.BaseRecyclerViewAdapter

class NotificationListAdapter(val activity : FragmentActivity, val notifications : List<NotificationListData>)
    : BaseRecyclerViewAdapter<NotificationListData, ItemNotificationListBinding>() {

    override val layoutId: Int
        get() = R.layout.item_notification_list

    override fun getItemCount(): Int {
        return notifications.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return NotificationViewHolder(createBindView(parent))
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val holder = holder as NotificationViewHolder
        val item = notifications[position]

        // title
        holder.binding.txtTitle.text = item.title ?: ""

        // description
        holder.binding.txtDesc.text = item.body ?: ""
    }

    inner class NotificationViewHolder(val binding: ItemNotificationListBinding) : RecyclerView.ViewHolder(binding.root)
}