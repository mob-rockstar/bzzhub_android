package com.app.basketiodriver.data.model.api.response.order

import java.io.Serializable

class ReplacementSearchItemRequest : Serializable {
    var product : SimilarProduct? = null
    var quantity : Double = 1.0
    var weight : Double = 0.0
}