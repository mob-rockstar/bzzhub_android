package com.app.basketiodriver.data.model.api.response.earning.order

import com.google.gson.annotations.SerializedName




class ShopperOrderDetailResponse {

    @SerializedName("data")
    val data: ShopperOrderDetailData? = null

    @SerializedName("message")
    val message: String = ""
}