package com.app.basketiodriver.ui.order.product

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.general.SimpleResponse
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.utils.AppConstants
import java.io.File

class ReplaceCustomItemActivity : CreateCustomItemActivity() {

    private var itemId : Long = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        initToolbar(getString(R.string.replace_custom_item),
            true, viewDataBinding!!.layoutToolBar.toolbar,
            View.OnClickListener {
                run {
                    onBackPressed()
                }
            })

        if (intent.extras != null) {
            itemId = intent.extras!!.getLong("ARG_OUTLET_ID")
        }

        viewDataBinding!!.btAddItem.setOnClickListener {
            add()
        }
    }

    private fun add(){
        if (!validateName(false))
            return
        if (!validateCount(false))
            return
        if (!validatePrice(false))
            return

        // Dismiss the keyboard
        hideKeyboard()

        val count = getDouble(viewDataBinding!!.etCount)
        val price = getDouble(viewDataBinding!!.etPrice)
        val name  = viewDataBinding!!.etName.text.toString()

//        val doesNotContain = if (viewDataBinding!!.swContain.isChecked) 1 else 0
        val unit = if (viewDataBinding!!.rbUnit.isChecked) getString(R.string.unit) else getString(R.string.kg)

        // add product to server
        replaceItem(itemId, barcode, name, imageFile, 0, unit, count, price)
    }

    private fun replaceItem(itemId : Long, barcode : String, name : String, file : File?, contain : Int, unit : String, count : Double, price : Double){
        viewModel.replaceCustomItem(itemId, barcode, name, file, contain, unit, count, price, object :
            HandleResponse<SimpleResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                Toast.makeText(this@ReplaceCustomItemActivity, error?.message, Toast.LENGTH_SHORT).show()
            }

            override fun handleSuccessResponse(successResponse: SimpleResponse) {
                val response = successResponse.response
                if (response != null){
                    Toast.makeText(this@ReplaceCustomItemActivity, response.message, Toast.LENGTH_SHORT).show()

                    if (response.httpCode == 200){

                        // Close the current page
                        setResult(Activity.RESULT_OK)
                        finish()
                    }
                }
                else{
                    Toast.makeText(this@ReplaceCustomItemActivity, R.string.cant_add_product, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }
}