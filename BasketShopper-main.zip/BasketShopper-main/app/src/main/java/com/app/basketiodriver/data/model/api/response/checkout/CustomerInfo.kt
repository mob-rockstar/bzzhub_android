package com.app.basketiodriver.data.model.api.response.checkout

import com.app.basketiodriver.ui.checkout.`interface`.JsonModel
import org.json.JSONObject
import java.io.Serializable

class CustomerInfo : Serializable{

    var image : String = ""

    var name : String = ""

    var area : String = ""

    var time : String = ""

    var address : String = ""

    var type : String = ""

    var depBuilding : String = ""

    var addInfo : String = ""

    var landmark : String = ""

    constructor(){

    }

    constructor(
        image: String,
        name: String,
        area: String,
        time: String,
        address: String,
        type: String,
        depBuilding: String,
        addInfo: String,
        landmark: String
    ) {
        this.image = image
        this.name = name
        this.area = area
        this.time = time
        this.address = address
        this.type = type
        this.depBuilding = depBuilding
        this.addInfo = addInfo
        this.landmark = landmark
    }

    fun fromJson(json: JSONObject) {
        try {
            image       = json.getString("image")
            name        = json.getString("name")
            area        = json.getString("area")
            time        = json.getString("time")
            address     = json.getString("address")
            type        = json.getString("type")
            depBuilding = json.getString("depBuilding")
            addInfo     = json.getString("addInfo")
            landmark    = json.getString("landmark")
        } catch (e : Exception) {
            e.printStackTrace()
        }
    }

    fun toJson(): JSONObject {
        val jsonObject : JSONObject = JSONObject()

        try {
            jsonObject.put("image", image)
            jsonObject.put("name", name)
            jsonObject.put("area", area)
            jsonObject.put("time", time)
            jsonObject.put("address", address)
            jsonObject.put("type", type)
            jsonObject.put("depBuilding", depBuilding)
            jsonObject.put("addInfo", addInfo)
            jsonObject.put("landmark", landmark)
        } catch (e : Exception) {
            e.printStackTrace()
        }

        return jsonObject
    }
}