package com.app.basketiodriver.di.scoup


import java.lang.annotation.Retention
import java.lang.annotation.RetentionPolicy
import javax.inject.Qualifier

/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
@Qualifier
@Retention(RetentionPolicy.RUNTIME)
annotation class ApiInfo