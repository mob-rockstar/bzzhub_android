package com.app.basketiodriver.di.module

import android.content.Context
import androidx.room.Room
import com.app.basketiodriver.BuildConfig
import com.app.basketiodriver.R
import com.app.basketiodriver.ShopperApp
import com.app.basketiodriver.data.AppDataManager
import com.app.basketiodriver.data.DataManager
import com.app.basketiodriver.data.local.db.AppDatabase
import com.app.basketiodriver.data.local.db.AppDbHelper
import com.app.basketiodriver.data.local.db.DbHelper
import com.app.basketiodriver.data.local.prefs.AppPreferencesHelper
import com.app.basketiodriver.data.local.prefs.PreferencesHelper
import com.app.basketiodriver.data.remote.socket.SocketManager
import com.app.basketiodriver.data.remote.socket.SocketService
import com.app.basketiodriver.di.scoup.ApiInfo
import com.app.basketiodriver.di.scoup.DatabaseInfo
import com.app.basketiodriver.di.scoup.PreferenceInfo
import com.app.basketiodriver.utils.AppConstants
import com.app.basketiodriver.utils.rx.AppSchedulerProvider
import com.app.basketiodriver.utils.rx.SchedulerProvider
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import dagger.Module
import dagger.Provides
import io.github.inflationx.calligraphy3.CalligraphyConfig
import io.reactivex.disposables.CompositeDisposable
import javax.inject.Singleton


/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/

@Module(includes = [NetworkModule::class])
class AppModule {

    @Provides
    @ApiInfo
    fun provideApiKey(): String {
        return BuildConfig.API_KEY
    }


    @Provides
    @Singleton
    fun provideAppDatabase(@DatabaseInfo dbName: String, context: Context): AppDatabase {
        return Room.databaseBuilder(context, AppDatabase::class.java, dbName)
            .fallbackToDestructiveMigration()
            .build()
    }


    @Provides
    @Singleton
    fun provideCalligraphyDefaultConfig(): CalligraphyConfig {
        return CalligraphyConfig.Builder()
            .setDefaultFontPath("fonts/OpenSans-Regular.ttf")
            .setFontAttrId(R.attr.fontPath)
            .build()
    }

    @Provides
    @Singleton
    fun provideContext(application: ShopperApp): Context {
        return application
    }


    @Provides
    @Singleton
    fun provideDataManager(appDataManager: AppDataManager): DataManager {
        return appDataManager
    }


    @Provides
    @Singleton
    fun provideCompositeDisposable(): CompositeDisposable{
        return CompositeDisposable()
    }

    @Provides
    @DatabaseInfo
    fun provideDatabaseName(): String {
        return AppConstants.DB_NAME
    }

    @Provides
    @Singleton
    fun provideDbHelper(appDbHelper: AppDbHelper): DbHelper {
        return appDbHelper
    }

    @Provides
    @Singleton
    fun provideGson(): Gson? {
        return GsonBuilder().excludeFieldsWithoutExposeAnnotation().create()
    }

    @Provides
    @PreferenceInfo
    fun providePreferenceName(): String {
        return AppConstants.PREF_NAME
    }

    @Provides
    @Singleton
    fun providePreferencesHelper(appPreferencesHelper: AppPreferencesHelper): PreferencesHelper {
        return appPreferencesHelper
    }


    @Provides
    fun provideSchedulerProvider(): SchedulerProvider {
        return AppSchedulerProvider()
    }

    @Provides
    fun provideSocketService(): SocketService {
        return SocketService()
    }

    @Provides
    @Singleton
    fun provideSocketManager(): SocketManager {
        return SocketManager()
    }
}