package com.app.basketiodriver.ui.cardcamera.camera

import android.content.Context
import android.content.Intent
import android.hardware.Camera
import android.net.Uri
import android.os.Bundle
import android.os.Parcel
import android.os.Parcelable
import android.os.PersistableBundle
import android.view.Menu
import android.view.MenuItem
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.ActivityPreviewCameraBinding
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.cardcamera.CameraViewModel
import com.app.basketiodriver.ui.cardcamera.cropper2.CropDemoPreset
import com.app.basketiodriver.ui.cardcamera.cropper2.CropImageViewOptions
import com.app.basketiodriver.utils.ImageUtils
import kotlinx.android.parcel.Parcelize

class PreviewCameraActivity : BaseActivity<ActivityPreviewCameraBinding?, CameraViewModel>() {

    @Parcelize
    data class PreviewParameter(val demoPreset: CropDemoPreset, val uri: Uri) : Parcelable

    override val layoutId: Int
        get() = R.layout.activity_preview_camera

    override val viewModel: CameraViewModel
        get() {
            return getViewModel(CameraViewModel::class.java)
        }

    override fun onCreate(savedInstanceState: Bundle?, persistentState: PersistableBundle?) {
        super.onCreate(savedInstanceState, persistentState)


        viewModel.mPickedImageUri = ImageUtils.getBitmapFromByte(
            intent.getByteArrayExtra(KEY_ARRAY)!!,
            intent.getIntExtra(KEY_W, 0),
            intent.getIntExtra(KEY_H, 0)
        )
    }


    private var mCropImageViewOptions: CropImageViewOptions = CropImageViewOptions()
    fun setCurrentOptions(options: CropImageViewOptions) {
        mCropImageViewOptions = options

    }   // endregion

    private var mCurrentFragment: CameraFragment? = null
    private val mCropImageUri: Uri? = null
    fun setCurrentFragment(fragment: CameraFragment) {
        mCurrentFragment = fragment
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return if (mCurrentFragment != null && mCurrentFragment!!.onOptionsItemSelected(item!!)) {
            true
        } else super.onOptionsItemSelected(item)
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) {
            setMainFragmentByPreset()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.menu_camera_preview, menu)
        return true
    }

    private fun setMainFragmentByPreset() {
        val fragmentManager = supportFragmentManager
        fragmentManager
            .beginTransaction()
            .replace(R.id.container, CameraFragment.newInstance())
            .commit()
    }


    companion object {
        const val KEY_W = "width"
        const val KEY_H = "hight"
        const val KEY_ARRAY = "img"

        fun newIntent(context: Context?, size: Camera.Size, bytes: ByteArray): Intent {
            val intent = Intent(context, PreviewCameraActivity::class.java)
            intent.putExtra(KEY_W, size.width)
            intent.putExtra(KEY_H, size.height)
            intent.putExtra(KEY_ARRAY, bytes)


            return intent
        }
    }
}
