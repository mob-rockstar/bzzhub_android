package com.app.basketiodriver.ui.onboarding.adapters

import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.DocumentsResponse
import com.app.basketiodriver.databinding.ItemUploadedFileBinding
import com.app.basketiodriver.ui.base.DataListAdapter
import com.app.basketiodriver.utils.OnItemClickedListener

class UploadedFilesAdapter(val listener: OnItemClickedListener<DocumentsResponse.OnbaordingDocumentEntity>):
    DataListAdapter<DocumentsResponse.OnbaordingDocumentEntity, ItemUploadedFileBinding>() {

    override fun createBinding(
        inflater: LayoutInflater,
        parent: ViewGroup?
    ): ItemUploadedFileBinding {
        return DataBindingUtil.inflate(inflater, R.layout.item_uploaded_file, parent, false)
    }


    override fun bind(binding: ItemUploadedFileBinding?, item: DocumentsResponse.OnbaordingDocumentEntity) {

        binding!!.tvTitle.text = item.title
        binding.ivRetakeFrontPhoto.setImageBitmap(BitmapFactory.decodeFile(item.fileLocalPath))
        binding.btnRetakeFrontPhoto.setOnClickListener { listener.onClicked(item) }

    }


}
