package com.app.basketiodriver.ui.onboarding.fragments


import android.os.Bundle
import android.view.View
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.DocumentsResponse
import com.app.basketiodriver.databinding.FragmentReviewApplicationBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.onboarding.OnBoardingViewModel
import com.app.basketiodriver.ui.onboarding.adapters.StagesAdapter
import com.app.basketiodriver.utils.AppLogger

/**
 * Created by ibraheem lubbad on 2020-01-22.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
class ReviewApplicationFragment :
    BaseFragment<FragmentReviewApplicationBinding?, OnBoardingViewModel>(), View.OnClickListener,
    Injectable {

    override val layoutId: Int
        get() = R.layout.fragment_review_application

    override val viewModel: OnBoardingViewModel
        get() {
            return getViewModel(requireActivity(), OnBoardingViewModel::class.java)
        }


    var stagesAdapter: StagesAdapter? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.review_application))


        stagesAdapter = StagesAdapter(requireContext(), viewModel.listItems)


        /*     viewModel.getCurrentUserOnbaordingConfig(1,   object : HandleResponse<OnbaordingStages> {
                 override fun handleErrorResponse(error: ErrorResponse?) {
                     AppLogger.d("handleErrorResponse  ${error}")
                 }

                 override fun handleSuccessResponse(successResponse: OnbaordingStages) {
                 }

             })*/
        viewDataBinding!!.exListStages.setAdapter(stagesAdapter)

     //   viewDataBinding!!.exListStages.setOnGroupClickListener { _, _, i, _ -> !viewModel.listItems[i].isEnabled}

        viewDataBinding!!.exListStages.setOnChildClickListener { parent, v, groupPosition, childPosition, _ ->
            viewModel.currentOnbaordingDocument =viewModel.listItems[groupPosition].userDcouments[childPosition]
            gotToFlowForm(viewModel.listItems[groupPosition].userDcouments[childPosition])
            false
        }


        viewModel.getOnbaordingDocumentList(
            object : HandleResponse<DocumentsResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    AppLogger.d("handleErrorResponse $error")

                }

                override fun handleSuccessResponse(successResponse: DocumentsResponse) {
                    AppLogger.d("handleSuccessResponse $successResponse")
                    stagesAdapter?.notifyDataSetChanged()

                }

            }
        )





        viewDataBinding!!.btnNext.setOnClickListener(this)

    }



    fun gotToFlowForm(docId: DocumentsResponse.OnbaordingDocument) {
        navigate(
            when (docId.name) {
                getString(R.string.basic_info) -> ReviewApplicationFragmentDirections.actionReviewApplicationFragmentToAdditionalInfoFragment()
                getString(R.string.car_info) -> ReviewApplicationFragmentDirections.actionReviewApplicationFragmentToVehicleInfoFragment()
                getString(R.string.take_self) -> ReviewApplicationFragmentDirections.actionReviewApplicationFragmentToTakeSelfiFragment()
                else -> ReviewApplicationFragmentDirections.actionReviewApplicationFragmentToFragmentDocument()

            }
        )
    }

    override fun onClick(p0: View?) {
        when (p0!!.id) {
            R.id.btnNext -> {
                popNavigate(R.id.reviewProgressFragment)

            }

        }
    }
}


