package com.app.basketiodriver.data.model.api.response.order

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class SimilarResponse {
    @SerializedName("response")
    @Expose
    val response: Response? = null

    inner class Response {
        @SerializedName("httpCode")
        @Expose
        val httpCode: Int? = null

        @SerializedName("Message")
        @Expose
        val message: String = ""

        @SerializedName("similar_products")
        @Expose
        val similarProducts: ArrayList<SimilarProduct> = arrayListOf()
    }
}