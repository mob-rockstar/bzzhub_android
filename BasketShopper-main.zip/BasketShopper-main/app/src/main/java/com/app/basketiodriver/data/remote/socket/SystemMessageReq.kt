package com.app.basketiodriver.data.remote.socket

data class SystemMessageReq(val order_id: String, val message_type: String, val message_content: String)