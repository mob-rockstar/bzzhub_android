package com.app.basketiodriver.ui.earning.fragments


import android.Manifest
import android.R.attr.data
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.earning.monthly.ReportView
import com.app.basketiodriver.data.model.api.response.earning.monthly.ShopperDetailsReportData
import com.app.basketiodriver.data.model.api.response.earning.monthly.ShopperDetailsReportResponse
import com.app.basketiodriver.data.model.api.ticket.TicketFieldsData
import com.app.basketiodriver.databinding.FragmentDayEarningBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.dialogs.CreateTicketDialogFragment
import com.app.basketiodriver.ui.earning.EarningViewModel
import com.app.basketiodriver.ui.earning.adapters.OrderEarningsAdapter
import com.app.basketiodriver.ui.earning.fragments.DayEarningFragmentArgs.fromBundle
import com.app.basketiodriver.utils.AppConstants
import com.app.basketiodriver.utils.CommonUtils
import com.app.basketiodriver.utils.InfoHelp
import com.app.basketiodriver.utils.OnItemClickedListener
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonParser
import com.tbruyelle.rxpermissions2.RxPermissions
import io.reactivex.android.schedulers.AndroidSchedulers
import org.json.JSONTokener
import java.util.*
import kotlin.collections.ArrayList


/**
 * A simple [Fragment] subclass.
 */
class DayEarningFragment : BaseFragment<FragmentDayEarningBinding?, EarningViewModel>(),
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_day_earning

    override val viewModel: EarningViewModel
        get() {
            return getViewModel(baseActivity as FragmentActivity, EarningViewModel::class.java)
        }

    // Yearly Balance Report
    val yearReportItem by lazy {
        fromBundle(requireArguments()).shopperReportItem
    }

    // Review item
    private val reviewItem by lazy {
        fromBundle(requireArguments()).reportViewItem
    }

    // Day Number
    var dayNum = 1

    var reportViewArray : ArrayList<ReportView> = arrayListOf()
    private lateinit var reportViewAdapter : OrderEarningsAdapter


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize the UI
        initUI()

        getShopperDailyReportDetail()
    }

    private fun initUI(){
        // Set title
        dayNum = reviewItem.day_name.substring(9,11).toInt()
        setTitle(reviewItem.day_name)

        // Set tooltips
        viewDataBinding!!.txtBonusLabel.setOnClickListener {
            InfoHelp.showHelpDialog(it, baseActivity?.resources?.getString(R.string.total_bonuses_get)!!, baseActivity as Activity, false)
        }

        viewDataBinding!!.txtDeductions.setOnClickListener {
            InfoHelp.showHelpDialog(it, baseActivity?.resources?.getString(R.string.total_deductions)!!, baseActivity as Activity, false)
        }

        viewDataBinding!!.txtDayEarning.setOnClickListener {
            InfoHelp.showHelpDialog(it, baseActivity?.resources?.getString(R.string.total_earning_this_day)!!, baseActivity as Activity, false)
        }

        viewDataBinding!!.txtCurrentBalance.setOnClickListener{
            InfoHelp.showHelpDialog(it, baseActivity?.resources?.getString(R.string.your_current_balance)!!, baseActivity as Activity, true)
        }

        // Init RecyclerManager
        val linearLayoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        viewDataBinding!!.recyclerView.layoutManager = linearLayoutManager
        viewDataBinding!!.recyclerView.setHasFixedSize(true)

        reportViewAdapter = OrderEarningsAdapter(requireContext(), object :
            OnItemClickedListener<ReportView> {
            override fun onClicked(item: ReportView) {
                // Go to order detail
                navigate(DayEarningFragmentDirections.actionDayEarningFragmentToEarningsOrderDetailFragment(yearReportItem, item.order_outlet_id ?: ""))
            }
        })

        // Get Help
        viewDataBinding!!.btnHelp.setOnClickListener {
//            getHelp()
            if (AppConstants.ticketTypes.isEmpty()) {
                submitTicket()
            }
            else{
                showCreateTicketDialog(AppConstants.ticketTypes)
            }
        }
    }

    /**
     * Create a ticket in Freshchat
     */
    private fun submitTicket(){
        viewModel.getTicketTypeList( object :HandleResponse<ArrayList<TicketFieldsData>>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                Log.d("DailyEarning", "Ticket api error : " + error?.message ?: "")
                if (isNetworkConnected){
                    Toast.makeText(baseActivity, error?.message, Toast.LENGTH_SHORT).show()
                }else{
                    Toast.makeText(baseActivity, baseActivity!!.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }
            }

            override fun handleSuccessResponse(successResponse: ArrayList<TicketFieldsData>) {
                Log.d("DailyEarning", "Ticket api success")
                val choices = extractTicketTypes(successResponse)
                AppConstants.ticketTypes = choices

                // Go to create ticket dialog
                showCreateTicketDialog(choices)
            }
        })
    }

    /**
     * Get the list of Ticket type
     */
    private fun extractTicketTypes(fields : ArrayList<TicketFieldsData>) : ArrayList<String>{

        val typeArray : ArrayList<String> = arrayListOf()

        for (typeField in fields) {
            if (typeField.name != null && typeField.name == AppConstants.TICKET_NAME_TYPE) {
                if (typeField.choices != null) {
                    val types : ArrayList<String> = arrayListOf()
                    val choiceJsonString = Gson().toJson(typeField.choices)
                    try {
                        val choices : List<String> = Gson().fromJson(choiceJsonString, types.javaClass)
                        if (choices != null) {
                            typeArray.addAll(choices)
                            break
                        }
                    }
                    catch (e : Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }

        return typeArray
    }

    private fun showCreateTicketDialog(choices : ArrayList<String>){
        try {
            val bid = (reviewItem.order_outlet_id ?: "0").toLong()
            Log.d("DailyEarning", "BID : " + bid)
            val ticketDialog = CreateTicketDialogFragment.newInstance(choices)
            ticketDialog.show(baseActivity!!.supportFragmentManager, CreateTicketDialogFragment.javaClass.name)
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    private fun getShopperDailyReportDetail(){
        val month : Int = if (yearReportItem != null) yearReportItem.monthNumber else Calendar.getInstance().get(
            Calendar.MONTH)
        val year : Int = if (yearReportItem != null) yearReportItem.year.toInt() else Calendar.getInstance().get(
            Calendar.YEAR)

        viewModel.getShopperDetailsReport(month, year, "daily", dayNum, object :
            HandleResponse<ShopperDetailsReportResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Toast.makeText(baseActivity, error?.message, Toast.LENGTH_SHORT).show()
                }else{
                    Toast.makeText(baseActivity, baseActivity!!.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }
            }

            override fun handleSuccessResponse(successResponse: ShopperDetailsReportResponse) {
                if (successResponse.data != null){
                    updateUI(successResponse.data)
                }
                else{
                    Toast.makeText(baseActivity, successResponse.message, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }


    // Update the reports
    private fun updateUI(detailData: ShopperDetailsReportData){
        if (detailData.is_account_suspended) {
            viewDataBinding!!.suspendedLL.visibility = View.VISIBLE
        }
        else{
            viewDataBinding!!.suspendedLL.visibility = View.GONE
        }

        // this day balance
        val dayEarning = PreferenceManager.currency + " " + detailData.total_balance
        viewDataBinding!!.txtTotalDayEarning.text = dayEarning
        CommonUtils.setBalanceTextColor(viewDataBinding!!.txtTotalDayEarning, "" + detailData.total_balance)

        // Current Balance
        val currBalance = PreferenceManager.currency + " " + detailData.current_account_balance
        viewDataBinding!!.currentBalanceValue.text = currBalance
        CommonUtils.setBalanceTextColor(viewDataBinding!!.currentBalanceValue, "" + detailData.current_account_balance)

        // Shopping Earning
        val shoppingEarning = PreferenceManager.currency + " " + detailData.total_shopping_earning
        viewDataBinding!!.txtShoppingEarningsValue.text = shoppingEarning
        CommonUtils.setBalanceTextColor(viewDataBinding!!.txtShoppingEarningsValue, "" + detailData.total_shopping_earning)

        // Delivery Earning
        val deliveryEarning = PreferenceManager.currency + " " + detailData.total_delivery_earning
        viewDataBinding!!.txtDeliveryEarningsValue.text = deliveryEarning
        CommonUtils.setBalanceTextColor(viewDataBinding!!.txtDeliveryEarningsValue, "" + detailData.total_delivery_earning)

        // Bonus
        val bonus = PreferenceManager.currency + " " + detailData.total_bonus
        viewDataBinding!!.txtBonusEarningsValue.text = bonus
        CommonUtils.setBalanceTextColor(viewDataBinding!!.txtBonusEarningsValue, "" + detailData.total_bonus)

        // Deductions
        val deductions = PreferenceManager.currency + " " + detailData.total_deduction
        viewDataBinding!!.txtDeductionsValue.text = deductions
        CommonUtils.setBalanceTextColor(viewDataBinding!!.txtDeductionsValue, "" + detailData.total_deduction)

        // Daily total earning
        val earning = PreferenceManager.currency + " " + detailData.total_earnings
        viewDataBinding!!.txtDayEarningValue.text = earning
        CommonUtils.setBalanceTextColor(viewDataBinding!!.txtDayEarningValue, "" + detailData.total_earnings)

        // Collected from customer
        val collected = PreferenceManager.currency + " " + detailData.total_collected
        viewDataBinding!!.txtCollectionValue.text = collected
        CommonUtils.setBalanceTextColor(viewDataBinding!!.txtCollectionValue, "" + detailData.total_collected)

        val extra = detailData.total_extra_amount_with_shopper.toDouble()
        val extraEarning = PreferenceManager.currency + " " + detailData.total_extra_amount_with_shopper
        when {
            extra < 0 -> {
    //            val str = baseActivity?.resources?.getString(R.string.your_own_basket) + " " + PreferenceManager.currency + " " + detailData.total_extra_amount_with_shopper
    //            viewDataBinding!!.txtExtra.text = str
    //
    //            val startIdx = baseActivity?.resources?.getString(R.string.your_own_basket)!!.length + 1
    //            val endIdx = startIdx + PreferenceManager.currency!!.length + detailData.total_extra_amount_with_shopper.length + 1
    //
    //            val wordToSpan = SpannableString(str)
    //            wordToSpan.setSpan(ForegroundColorSpan(baseActivity?.resources?.getColor(R.color.item_not_found_color)!!), startIdx, endIdx, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
    //            viewDataBinding!!.txtExtra.text = wordToSpan

                viewDataBinding!!.txtExtraTitle.text = baseActivity!!.resources.getString(R.string.your_own_basket)
                viewDataBinding!!.txtExtra.text = extraEarning
                CommonUtils.setBalanceTextColor(viewDataBinding!!.txtExtra, "" + detailData.total_extra_amount_with_shopper)
            }
            extra > 0 -> {
    //            val str = baseActivity?.resources?.getString(R.string.baskets_own_you) + " " + PreferenceManager.currency + " " + detailData.total_extra_amount_with_shopper
    //            viewDataBinding!!.txtExtra.text = str
    //
    //            val startIdx = baseActivity?.resources?.getString(R.string.baskets_own_you)!!.length + 1
    //            val endIdx = startIdx + PreferenceManager.currency!!.length + detailData.total_extra_amount_with_shopper.length + 1
    //
    //            val wordToSpan = SpannableString(str)
    //            wordToSpan.setSpan(ForegroundColorSpan(baseActivity?.resources?.getColor(R.color.colorPrimary)!!), startIdx, endIdx, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
    //            viewDataBinding!!.txtExtra.text = wordToSpan

                viewDataBinding!!.txtExtraTitle.text = baseActivity!!.resources.getString(R.string.baskets_own_you)
                viewDataBinding!!.txtExtra.text = extraEarning
                CommonUtils.setBalanceTextColor(viewDataBinding!!.txtExtra, "" + detailData.total_extra_amount_with_shopper)
            }
            else -> {
    //            val str = baseActivity?.resources?.getString(R.string.baskets_own_you) + " " + PreferenceManager.currency + " " + detailData.total_extra_amount_with_shopper
    //            viewDataBinding!!.txtExtra.text = str
    //
    //            val startIdx = baseActivity?.resources?.getString(R.string.baskets_own_you)!!.length + 1
    //            val endIdx = startIdx + PreferenceManager.currency!!.length + detailData.total_extra_amount_with_shopper.length + 1
    //
    //            val wordToSpan = SpannableString(str)
    //            wordToSpan.setSpan(ForegroundColorSpan(baseActivity?.resources?.getColor(R.color.colorBlack33)!!), startIdx, endIdx, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
    //            viewDataBinding!!.txtExtra.text = wordToSpan

                viewDataBinding!!.txtExtraTitle.text = baseActivity!!.resources.getString(R.string.baskets_own_you)
                viewDataBinding!!.txtExtra.text = extraEarning
                CommonUtils.setBalanceTextColor(viewDataBinding!!.txtExtra, "" + detailData.total_extra_amount_with_shopper)
            }
        }

        // Distance
        val tk = detailData.total_travel_distance
        val tkDouble = tk.toDoubleOrNull()
        if (tkDouble != null){
            viewDataBinding!!.txtDeliveryEarningsKm.text = String.format(Locale.ENGLISH, "(%.2f KM)", tkDouble)
        }

        // Total Items
        val items = detailData.total_delivered_items + " " + baseActivity?.resources?.getString(R.string.items)
        viewDataBinding!!.txtShoppingEarningsItems.text = String.format(Locale.ENGLISH, "(%s)", items)

        // Get review list
        reportViewArray = detailData.report_view

        // Refresh weekly list
        updateDailyEarnings()
    }

    // Refresh Weekly Earning List
    private fun updateDailyEarnings(){
        viewDataBinding!!.recyclerView.adapter = reportViewAdapter
        reportViewAdapter.replace(reportViewArray)

//        if (reportViewArray.size > 0) {
//            viewDataBinding!!.txtNoDataFound.visibility = View.GONE
//        }
//        else{
//            viewDataBinding!!.txtNoDataFound.visibility = View.VISIBLE
//        }
    }

    // Create the ticket
    private fun getHelp(){
        val builder: AlertDialog.Builder = AlertDialog.Builder(requireContext())
        builder.setTitle("")
        builder.setMessage(getString(R.string.support_call))
            .setCancelable(false)
            .setPositiveButton(
                getString(R.string.ok_btn_txt)
            ) { _, _ -> //do things
                callSupportTeam()

            }.setNegativeButton(
                getString(R.string.cancel_btn_txt)
            ) { _, _ ->
                //do things
            }
        val alert: AlertDialog = builder.create()
        alert.show()
    }

    // Call the support team
    @SuppressLint("CheckResult")
    private fun callSupportTeam(){
        val number = String.format(Locale("en"), "tel:%s", AppConstants.SUPPORT_PHONE_NUMBER)
        RxPermissions(this).request(
            Manifest.permission.CALL_PHONE
        ).observeOn(AndroidSchedulers.mainThread())
            .subscribe { granted ->
                if (granted) {
                    val intent = Intent(Intent.ACTION_CALL, Uri.parse(number))
                    startActivity(intent)
                }
                else{
                    Toast.makeText(baseActivity, getString(R.string.error_no_call_permission), Toast.LENGTH_SHORT).show()
                }
            }
    }
}
