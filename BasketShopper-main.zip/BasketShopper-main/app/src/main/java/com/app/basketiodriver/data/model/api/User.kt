package com.app.basketiodriver.data.model.api

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName


/**
Created by ibraheem lubbad on 2020-01-19.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/

@Entity(tableName = "users")
data class User(
    /*
           "shopper_id": 1,
            "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOjEsImlzcyI6Imh0dHBzOi8vYXBpLmRldi1iYXNrZXQuY29tL2FwaS92NS9yZXdvcmsvY2hlY2stc2hvcHBlci1vdHAiLCJpYXQiOjE1ODA4NTIxMzYsImV4cCI6NDE3Mjg1MjEzNiwibmJmIjoxNTgwODUyMTM2LCJqdGkiOiJLT2huRmRhblUzT2QwRVNuIn0.v02ry5kdq6DWmuqtsXWl6QwWO3Py9mQOAN9Fjlxgh6c",
            "email": "omar@basket.jo",
            "mobile": "+962799200400",
            "first_name": "Omar",
            "last_name": "Akel",
            "shopper_type": 1,
            "shopper_online_status": 1,
            "active_status": "",
            "is_verified": 1
     */
    @PrimaryKey
    @SerializedName("id") val id: Int,
    @SerializedName("first_name") val first_name: String,
    @SerializedName("last_name") val last_name: String,
    @SerializedName("email") val email: String,
    @SerializedName("mobile") val mobile: String,
    @SerializedName("avatar") val avatar: String,
    @SerializedName("gender") val gender: Int,
    @SerializedName("shopper_type") val shopper_type: Int,
    @SerializedName("active_status") val active_status: Int,
    @SerializedName("is_verified") val is_verified: Int,
    @SerializedName("shopper_online_status") val shopper_online_status: Int,
    @SerializedName("email_verified_at") val email_verified_at: String,
    @SerializedName("mobile_verified_at") val mobile_verified_at: String,
    @SerializedName("country_id") val country_id: Int,
    @SerializedName("language_id") val language_id: Int,
    @SerializedName("login_type") val login_type: Int

)