package com.app.basketiodriver.ui.dialogs

import android.os.Bundle
import android.text.Html
import android.view.View
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentManager
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.model.api.response.order.CommonResponse
import com.app.basketiodriver.data.remote.socket.ChatMessageHelper
import com.app.basketiodriver.data.remote.socket.SystemMessage
import com.app.basketiodriver.data.remote.socket.SystemMessageReq
import com.app.basketiodriver.databinding.FragmentRefundDialogBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseDialogFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsActivity
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsViewModel
import com.app.basketiodriver.ui.dashbaord.OrdersManager
import com.app.basketiodriver.ui.order.product.BasketSuggestionListActivity
import com.app.basketiodriver.ui.order.product.ItemDetails
import com.app.basketiodriver.utils.AppConstants
import com.app.basketiodriver.utils.GlideApp
import com.app.basketiodriver.utils.MessageEvent
import com.app.basketiodriver.utils.price.PriceConstructor
import com.app.basketiodriver.utils.price.PriceConstructorNew
import org.greenrobot.eventbus.EventBus
import java.util.*


class RefundDialogFragment: BaseDialogFragment<FragmentRefundDialogBinding?, OrderDetailsViewModel>(),
    Injectable {

    var orderId : Long = 0L
    var item : OrdersItem? = null
    var actionFrom = 1

    var parentActivity : FragmentActivity? = null

    override val layoutId: Int
        get() = R.layout.fragment_refund_dialog

    override val viewModel: OrderDetailsViewModel
        get() {
            return getViewModel(baseActivity as FragmentActivity, OrderDetailsViewModel::class.java)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        parentActivity = baseActivity as FragmentActivity
    }

    // Set Full screen
    override fun getTheme(): Int {
        return R.style.LocationDialogStyle
    }

    override fun onStart() {
        super.onStart()

        try {
            dialog!!.window!!.setLayout(
                RelativeLayout.LayoutParams.MATCH_PARENT,
                RelativeLayout.LayoutParams.MATCH_PARENT
            )
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        /**
         * get params
         */
        arguments?.let {
            orderId = it.getLong(KEY_ORDER_ID)
            item = it.getSerializable(KEY_ORDER_ITEM) as? OrdersItem
            actionFrom = it.getInt(KEY_ACTION_FROM, 1)

            if (item != null && item!!.customerSuggestionType != null && item!!.customerSuggestionType == 3)
                actionFrom = 2

//            initToolbar()

            initViews()
        }
    }

    override fun show(manager: FragmentManager, tag: String?) {
        try {
            val ft = manager.beginTransaction()
            ft.add(this, tag)
            ft.commitAllowingStateLoss()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun initToolbar(){
//        if (item != null && item!!.productName != null){
//            viewDataBinding!!.layoutToolBar.toolBarTitle.text = String.format(Locale.US, "%s %s", resources.getString(R.string.select_replacement_for), item!!.productName)
//        }

//        viewDataBinding!!.layoutToolBar.toolBarTitle.text = getString(R.string.refund_item)
//
//        viewDataBinding!!.layoutToolBar.btnBack.setOnClickListener {
//            dismissAllowingStateLoss()
//        }
    }

    private fun initViews(){

        // Back
        viewDataBinding!!.ivBack.setOnClickListener {
            dismissAllowingStateLoss()
        }

        if (item != null){
//            if (item!!.customerSuggestionType != 3) {
//                viewDataBinding!!.txtRefundNote.setText(R.string.replace_confirm)
//            }

            if (item!!.productImage != null){
                GlideApp.with(this).load(item!!.productImage).fitCenter()
                    .placeholder(R.drawable.placeholder)
                    .error(R.drawable.placeholder).into(viewDataBinding!!.productLayout.orderItemImage)
            }

            viewDataBinding!!.productLayout.txtTitle.text = item!!.productName

            if (item!!.getDescriptionLabel() == ""){
                viewDataBinding!!.productLayout.tvPriceDescription.visibility = View.GONE
            }
            else{
                viewDataBinding!!.productLayout.tvPriceDescription.visibility = View.VISIBLE
                viewDataBinding!!.productLayout.tvPriceDescription.text = item!!.getDescriptionLabelNew()
            }

            viewDataBinding!!.productLayout.txtPricePerUnit.text = Html.fromHtml(PriceConstructorNew.getFormatPrice(item!!, PriceConstructor.LabelType.SIMPLE, true))

            viewDataBinding!!.btnRefund.setOnClickListener {
                onClickedRefund(item!!, actionFrom)
            }
        }
    }

    private fun onClickedRefund(ordersItem: OrdersItem, actionFrom : Int){
        viewModel.refundItem(ordersItem.ordersOutletsItemsId ?: 0, actionFrom, object  : HandleResponse<CommonResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (parentActivity != null)
                    Toast.makeText(parentActivity, error?.message, Toast.LENGTH_SHORT).show()
            }

            override fun handleSuccessResponse(successResponse: CommonResponse) {
                val response = successResponse.data
                if (successResponse != null) {
                    if (successResponse.status == 200){
                        if (parentActivity != null && !parentActivity!!.isFinishing && !parentActivity!!.isDestroyed && isAdded) {
                            val message: String = "refund item: " + PreferenceManager.currentShopperFirstName + " " + parentActivity!!.resources.getString(R.string.refunded).toLowerCase() + " " + ordersItem.productName!!

                            // Send message
                            val systemMessageReq = SystemMessageReq(orderId.toString(), "text", message)
                            sendSystemMessage(systemMessageReq){
                                // To do something after sent message

                                try{
                                    // Dismiss the popup
                                    dismissAllowingStateLoss()

                                    if (parentActivity is OrderDetailsActivity){
                                        (parentActivity as OrderDetailsActivity).queryShopperOrders()
                                    }

                                    if (parentActivity is ItemDetails){
                                        (parentActivity as ItemDetails).queryShopperOrders()
                                    }

                                    if (parentActivity is BasketSuggestionListActivity){
                                        (parentActivity as BasketSuggestionListActivity).finishWithRefund()
                                    }
                                }
                                catch (e : Exception){
                                    e.printStackTrace()
                                }
                            }
                        }
                        else{
                            if (parentActivity != null)
                                Toast.makeText(parentActivity, successResponse.message, Toast.LENGTH_SHORT).show()
                        }
                    }
                    else{
                        if (parentActivity != null)
                            Toast.makeText(parentActivity, successResponse.message, Toast.LENGTH_SHORT).show()
                    }
                }
                else{
                    if (parentActivity != null)
                        Toast.makeText(parentActivity, parentActivity!!.resources.getString(R.string.error_server_return_null), Toast.LENGTH_SHORT).show()
                }
            }
        })
    }


    private fun sendSystemMessage(systemMessageReq: SystemMessageReq, onAfterSystemMessageClicked: ()->Unit){
        viewModel.sendSystemMessage(systemMessageReq, object : HandleResponse<SystemMessage> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                onAfterSystemMessageClicked()
            }

            override fun handleSuccessResponse(successResponse: SystemMessage) {
                onAfterSystemMessageClicked()
            }
        })
    }

    companion object {
        const val KEY_ORDER_ITEM      = "orders_item"
        const val KEY_ORDER_ID        = "order_id"
        const val KEY_ACTION_FROM     = "action_from"


        fun newInstance(
            item : OrdersItem,
            orderId : Long,
            actionFrom : Int
        ): RefundDialogFragment {
            val fragment = RefundDialogFragment()

            val data = Bundle()

            data.putSerializable(KEY_ORDER_ITEM, item)
            data.putLong(KEY_ORDER_ID, orderId)
            data.putInt(KEY_ACTION_FROM, actionFrom)

            fragment.arguments = data

            return fragment
        }
    }
}