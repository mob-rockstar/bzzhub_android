package com.app.basketiodriver.ui.dashbaord

import android.os.Bundle
import android.view.View
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentLocationInstructionBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.earning.fragments.WeekEarningFragmentArgs
import com.app.basketiodriver.ui.home.HomeActivity
import com.app.basketiodriver.ui.home.HomeViewModel

class LocationInstructionFragment : BaseFragment<FragmentLocationInstructionBinding?, HomeViewModel>(),
    Injectable {
    override val layoutId: Int
        get() = R.layout.fragment_location_instruction

    override val viewModel: HomeViewModel
        get() {
            return getViewModel(requireActivity(), HomeViewModel::class.java)
        }

    val instruction by lazy {
        LocationInstructionFragmentArgs.fromBundle(arguments!!).storeInstruction
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        hideSupportMenuItems()
        setTitle(getString(R.string.store_instructions))
    }

    // Show the support toolbar
    private fun hideSupportMenuItems(){
        try {
            (requireActivity() as HomeActivity).showSupportMenuItems(false)
        }
        catch (exception : Exception){
            print(exception.printStackTrace())
        }
    }
}