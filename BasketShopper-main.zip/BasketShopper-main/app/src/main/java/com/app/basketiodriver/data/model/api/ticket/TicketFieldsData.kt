package com.app.basketiodriver.data.model.api.ticket

import com.google.gson.JsonObject
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class TicketFieldsData {
    @SerializedName("id")
    @Expose
    val id: Long = 0

    @SerializedName("name")
    @Expose
    val name: String? = null

    @SerializedName("label")
    @Expose
    val label: String? = null

    @SerializedName("description")
    @Expose
    val description: String? = null

    @SerializedName("position")
    @Expose
    val position: Int = 0

    @SerializedName("type")
    @Expose
    val type: String = ""

    @SerializedName("default")
    @Expose
    val default: Boolean = true

    @SerializedName("label_for_customers")
    @Expose
    val labelForCustomers: String = ""

    @SerializedName("required_for_customers")
    @Expose
    val requiredForCustomers: Boolean = false

    @SerializedName("displayed_to_customers")
    @Expose
    val displayedForCustomers: Boolean = false

    @SerializedName("created_at")
    @Expose
    val createdAt: String? = null

    @SerializedName("updated_at")
    @Expose
    val updatedAt: String? = null

    @SerializedName("choices")
    val choices : Any? = null


//    {
//        "id": 150000025304,
//        "name": "ticket_type",
//        "label": "Type",
//        "description": "Ticket type",
//        "position": 3,
//        "required_for_closure": false,
//        "required_for_agents": true,
//        "type": "default_ticket_type",
//        "default": true,
//        "customers_can_edit": true,
//        "customers_can_filter": false,
//        "label_for_customers": "Type",
//        "required_for_customers": false,
//        "displayed_to_customers": true,
//        "created_at": "2022-07-17T08:01:11Z",
//        "updated_at": "2023-10-29T20:21:05Z",
//        "choices": [
//        "Shopper Earnings",
//        "Food",
//        "Promo Code",
//        "Compensation",
//        "Complaint",
//        "Transfer",
//        "Other",
//        "Refund",
//        "Customer"
//        ]
//    }
}