package com.app.basketiodriver.ui.dashbaord

import androidx.fragment.app.FragmentActivity
import androidx.viewpager.widget.ViewPager
import com.app.basketiodriver.ShopperApp
import com.app.basketiodriver.data.model.api.response.dashboard.Order
import com.app.basketiodriver.ui.customView.NonSwipeViewPager
import com.app.basketiodriver.ui.utils.ViewPagerAdapter
import com.app.basketiodriver.utils.SwipeManyStateButton
import java.util.*


class OrdersManager(val mContext: FragmentActivity, var pager : NonSwipeViewPager) {

    var allOrders : ArrayList<Order> = arrayListOf()
    var acknowledgeOrders : ArrayList<Order> = arrayListOf()
    var incomingOrders : ArrayList<Order> = arrayListOf()
    lateinit var incoming : AcknowledgeFragment
    lateinit var acknowledge : AcknowledgeFragment
    private var orderTitles: List<String> = arrayListOf()

    lateinit var pagerAdapter : ViewPagerAdapter

    var isExist : Boolean = false

    var listener: SwipeManyStateButton.SwipeTouchListener = object : SwipeManyStateButton.SwipeTouchListener {
        override fun startTouch() {

        }
        override fun endTouch() {

        }
    }

    /**
     * method to add orders
     * @param orders
     */
    fun setShopperOrder(orders : ArrayList<Order>){
        allOrders = orders
    }

    /**
     * method to add pages titles
     * @param titles
     */
    fun setTitles(vararg titles: String?) {
        orderTitles = Arrays.asList<String>(*titles)
    }

    fun setShowSwipeOnIncoming(show : Boolean){
        if (incoming != null){
            incoming.setSwipeEnabled(show)
        }
    }

    /**
     * method to get the count of acknowledge orders
     */
    fun getAcknowledgeOrdersCount () : Int{
        if (acknowledge != null && acknowledge.getItemsCount() > 0){
            return acknowledge.getItemsCount()
        }
        else{
            return 0
        }
    }

    fun clear(){
        pager.adapter = null
    }

    fun loadData() : NonSwipeViewPager{
        pagerAdapter = ViewPagerAdapter(mContext.supportFragmentManager)
        splitOrders()

        // set titles
        pagerAdapter.setTitles(orderTitles[0], orderTitles[1])

        // set pager adapter
        if (allOrders.size == 0){
            pager.adapter = pagerAdapter
        }

        var haveOrders : Boolean = true
        if (incomingOrders.size == 0 && acknowledgeOrders.size == 0) {
            haveOrders = false
        }

        try{
            if (incomingOrders.size == 0){
                // Stop buzzer sound
                ShopperApp.Instance.stopNotificationSound(mContext)
            }
        }
        catch (e : Exception){
            e.printStackTrace()
        }

        // set orders to fragment
        incoming = AcknowledgeFragment.newInstance(incomingOrders, true, haveOrders)
        incoming.setLoadMore(true)
        incoming.setSwipeTouchListener(listener)

        acknowledge = AcknowledgeFragment.newInstance(acknowledgeOrders, true, haveOrders)
        acknowledge.setLoadMore(false)
        acknowledge.setSwipeTouchListener(listener)

        // set fragments to pager adapter
        pagerAdapter.setFragments(incoming, acknowledge)

        pager.adapter = pagerAdapter
        pagerAdapter.notifyDataSetChanged()

        // show the acknowledge tab as default
        if (!acknowledgeOrders.isEmpty()){
            pager.currentItem = 1
        }

        return pager
    }

    /**
     * Method to add more orders
     */
    fun addMore(list : List<Order>){
        val data: List<List<Order>> = splitOrders(list)
        incoming.addDataList(data[0])
        acknowledge.addDataList(data[1])
    }


    /**
     * method to split by order type
     */
    private fun splitOrders(){
        isExist = false

        incomingOrders.clear()
        acknowledgeOrders.clear()

        if (allOrders.size > 0){
            for (order in allOrders) {
                if (order.orderStatus < STATUS_START) {
                    incomingOrders.add(order)
                } else {
                    acknowledgeOrders.add(order)
                    isExist = true
                }
            }
        }
    }

    private fun splitOrders(list : List<Order>) : ArrayList<List<Order>>{
        val out: ArrayList<List<Order>> = arrayListOf()

        val incomingOrders: ArrayList<Order> = arrayListOf()
        val acknowledgeOrders: ArrayList<Order> = arrayListOf()
        for (order in list) {
            if (order.orderStatus < STATUS_START) {
                incomingOrders.add(order)
            } else {
                acknowledgeOrders.add(order)
                isExist = true
            }
        }

        out.add(incomingOrders)
        out.add(acknowledgeOrders)

        return out
    }

    companion object{
        const val STATUS_SLIDE_ACKNOWLEDGE_ORDER = 3
        const val STATUS_START = 4
        const val STATUS_ARRIVING_TO_SHOP = 5
        const val STATUS_ARRIVED_TO_SHOP = 6
        const val STATUS_SHOPPING = 7
        const val STATUS_ORDER_REVIEW = 8
        const val STATUS_CHECKOUT = 9
        const val STATUS_SLIDE_START_DELIVERY = 10
        const val STATUS_DELIVERY = 11
        const val STATUS_ARRIVED_TO_CUSTOMER = 12
        const val STATUS_ORDER_FINISHED = 13
        const val STATUS_ORDER_CANCELED = 14

        // Payment Type
        const val PAYMENT_TYPE_CASH_1 = 18
        const val PAYMENT_TYPE_CASH_2 = 26
        const val PAYMENT_TYPE_CREDIT = 24
        const val PAYMENT_TYPE_BRING_CC = 27
    }
}