package com.app.basketiodriver.data.model.api.response.directions

class Bounds {
}