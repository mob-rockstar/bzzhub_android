package com.app.basketiodriver.data.remote.socket

import android.util.Log
import com.app.basketiodriver.BuildConfig
import com.app.basketiodriver.data.model.api.ChatMessage
import com.app.basketiodriver.utils.BaseObservable

import com.google.gson.Gson
import io.reactivex.Single
import io.reactivex.SingleEmitter
import io.socket.client.IO
import io.socket.client.Socket
import io.socket.emitter.Emitter
import org.json.JSONObject
import java.net.URISyntaxException
import javax.inject.Singleton

@Singleton
class SocketService :
    BaseObservable<EventListener?>() {
    private var socket: Socket? = null
    private var userNickname: String? = null
    private val connectListener =
        Emitter.Listener { args: Array<Any?>? ->
            Log.d(TAG, "onConnect ...")
            socket!!.emit("add user", userNickname)
            for (listener in listeners) listener!!.onConnect()
        }
    private val reconnectListener =
        Emitter.Listener { args: Array<Any?>? ->
            Log.d(TAG, "onReconnect ...")
            for (listener in listeners) listener!!.onReconnect()
        }
    private val connectionErrorListener =
        Emitter.Listener { args: Array<Any?>? ->
            Log.d(TAG, "onConnectionError ...")
            for (listener in listeners) listener!!.onConnectionError()
        }
    private val disconnectListener =
        Emitter.Listener { args: Array<Any?>? ->
            Log.d(TAG, "onDisconnect ...")
            socket!!.off()
            for (listener in listeners) listener!!.onDisconnect()
        }
    private val newMessageListener =
        Emitter.Listener { args: Array<Any> ->
            val rawMessage = args[0].toString()
            val data = args[0] as JSONObject
            val gson = Gson()
            val dataModel =
                gson.fromJson(data.toString(), ChatMessage::class.java)
            for (listener in listeners) listener!!.onNewMessage(dataModel)
        }

    @Throws(URISyntaxException::class)
    fun startListening(userNickName: String?, user_id: Long, user_token: String) {
        userNickname = userNickName

        val opts: IO.Options = IO.Options()
        opts.query = "user_id=$user_id&user_token=$user_token&user_type=2"

        if (socket == null) socket =
            IO.socket(SOCKET_URL, opts)
        socket!!.on(EVENT_CONNECT, connectListener)
        socket!!.on(EVENT_DISCONNECT, disconnectListener)
        socket!!.on(EVENT_NEW_MESSAGE, newMessageListener)
        socket!!.on(EVENT_RECONNECT, reconnectListener)
        socket!!.on(EVENT_CONNECT_ERROR, connectionErrorListener)
        socket!!.connect()
    }

    fun stopListening() {
        if (socket != null) socket!!.disconnect()
    }

    fun sendMessage(chatMessage: ChatMessage?): Single<ChatMessage?> {
        return Single.create { singleEmitter: SingleEmitter<ChatMessage?> ->
            if (socket == null) singleEmitter.onError(NullSocketException())
            val gson = Gson()
            socket!!.emit(EVENT_SEND_MESSAGE, gson.toJson(chatMessage))
            singleEmitter.onSuccess(chatMessage!!)
        }
    }

    companion object {
        private val TAG = SocketService::class.java.simpleName
        private const val SOCKET_URL = BuildConfig.CHAT_SERVER_URL
        private const val EVENT_CONNECT =
            Socket.EVENT_CONNECT
        private const val EVENT_RECONNECT =
            Socket.EVENT_RECONNECT
        private const val EVENT_CONNECT_ERROR =
            Socket.EVENT_CONNECT_ERROR
        private const val EVENT_DISCONNECT =
            Socket.EVENT_DISCONNECT
        private const val EVENT_NEW_MESSAGE = "new_message"
        private const val EVENT_SEND_MESSAGE = "send_message"
        private const val EVENT_HISTORY = "history"
        private const val EVENT_ISSUE = "issue"
    }
}