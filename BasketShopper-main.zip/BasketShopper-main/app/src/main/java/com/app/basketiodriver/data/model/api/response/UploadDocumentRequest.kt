package com.app.basketiodriver.data.model.api.response

import okhttp3.RequestBody
import retrofit2.http.Field


/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
sealed class UploadDocumentRequest {


    data class UploadSignatureRequest(
        @Field("shopper_id") val shopper_id: RequestBody,
        @Field("token") val token: RequestBody,
        @Field("signature\"; filename=\"pp.png\" ") val signature: RequestBody
    )

    data class UploadLicenceRequest(
        @Field("shopper_id") val shopper_id: RequestBody,
        @Field("token") val token: RequestBody,
        @Field("licence\"; filename=\"pp.png\" ") val licence: RequestBody,
        @Field("side") val side: RequestBody//required|in('front','back')
    )


    data class UploadDocumentIdPRequest(
        @Field("shopper_id") val shopper_id: RequestBody,
        @Field("token") val token: RequestBody,
        @Field("id_document\"; filename=\"pp.png\" ") val id_document: RequestBody,
        @Field("side") val side: RequestBody//required|in('front','back')
    )


}