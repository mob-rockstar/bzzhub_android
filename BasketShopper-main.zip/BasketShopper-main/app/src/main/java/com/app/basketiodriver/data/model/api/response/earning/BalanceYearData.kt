package com.app.basketiodriver.data.model.api.response.earning

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
class BalanceYearData : Parcelable {
    @SerializedName("current_account_balance")
    val currentAccountBalance: String = "0.0"

    @SerializedName("is_account_suspended")
    val isAccountSuspended = false

    @SerializedName("yearly_balance_report")
    val yearlyBalanceReport: ArrayList<YearlyBalanceReportItem> = arrayListOf()

    @SerializedName("num_record")
    val numbOfRecord = 0
}