package com.app.basketiodriver.data.model.api.response.directions

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class ServerAnswer {
    @SerializedName("geocoded_waypoints")
    @Expose
    val geocodedWaypoints: List<GeocodedWaypoint>? = null

    @SerializedName("routes")
    @Expose
    val routes: List<Route>? = null

    @SerializedName("status")
    @Expose
    val status: String? = null
}