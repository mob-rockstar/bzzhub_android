package com.app.basketiodriver.ui.order.adapter

import android.view.ViewGroup
import android.widget.CheckBox
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.order.ItemNotFoundReason
import com.app.basketiodriver.databinding.ItemMessageOptionBinding
import com.app.basketiodriver.databinding.ItemReasonNotFoundBinding
import com.app.basketiodriver.utils.BaseRecyclerViewAdapter

class MessageOptionListAdapter(val activity : FragmentActivity, val detailsData : ArrayList<String>, val onSelectMessageOption: (item : String, status:Int)->Unit)
    : BaseRecyclerViewAdapter<String, ItemMessageOptionBinding>(){

    override val layoutId: Int
        get() = R.layout.item_message_option

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return MessageOptionHolder(createBindView(parent))
    }

    var lastChecked : CheckBox? = null
    var lastCheckedPos = 0

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val holder = holder as MessageOptionHolder
        val item = detailsData[position]

        holder.binding.messageOption.tag = position
        holder.binding.messageOption.text = item

        holder.binding.messageOption.setOnClickListener {
            val clickedPos = it.tag as Int
            if (holder.binding.messageOption.isChecked){
                if (lastChecked != null){
                    lastChecked!!.isChecked = false
                }

                lastChecked = it as CheckBox
                lastCheckedPos = clickedPos
            }
            else{
                lastChecked = null
            }

            val checkBox = it as CheckBox
            val status = if (checkBox.isChecked) 1 else 0
            onSelectMessageOption(detailsData[clickedPos], status)
        }
    }

    override fun getItemCount(): Int {
        return detailsData.size
    }

    inner class MessageOptionHolder(val binding: ItemMessageOptionBinding) :
        RecyclerView.ViewHolder(binding.root)

}