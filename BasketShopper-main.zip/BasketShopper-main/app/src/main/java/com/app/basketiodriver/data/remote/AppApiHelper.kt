package com.app.basketiodriver.data.remote

import javax.inject.Inject
import javax.inject.Singleton

/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
@Singleton
class AppApiHelper @Inject constructor(
    private val mApiHeader: ApiHeader,
    private val apiInterface: ApiInterface
) : ApiHelper {
    override val apiHeader: ApiHeader?
        get() = mApiHeader
}