package com.app.basketiodriver.ui.onboarding.fragments.UploadDriverDocument


import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.FragmentLicensePreviewBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.cardcamera.camera.IDCardCamera
import com.app.basketiodriver.ui.onboarding.OnBoardingViewModel
import com.app.basketiodriver.utils.AppConstants

/**
 * Created by ibraheem lubbad on 2020-01-22.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/


class DriverLicensePreviewFragment :
    BaseFragment<FragmentLicensePreviewBinding?, OnBoardingViewModel>(),
    Injectable, View.OnClickListener {

    override val layoutId: Int
        get() = R.layout.fragment_license_preview

    override val viewModel: OnBoardingViewModel
        get() {
            return getViewModel(requireActivity(), OnBoardingViewModel::class.java)
        }

    var selecteImageType = 0


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setTitle(getString(R.string.preview_license))

        viewDataBinding!!.btnUpload.setOnClickListener(this)
        viewDataBinding!!.btnRetakeBackPhoto.setOnClickListener(this)
        viewDataBinding!!.btnRetakeFrontPhoto.setOnClickListener(this)
        viewDataBinding!!.layoutFront.visibility = View.VISIBLE
        viewDataBinding!!.layoutBack.visibility = View.VISIBLE

     /*   viewModel.documentTypes.filter {
            it.type.equals(AppConstants.DOC_DRIVER_LICENSE)
        }.forEach {

            if (it.side.equals(AppConstants.SIDE_BACK)) {
                viewDataBinding!!.ivRetakeBackPhoto.setImageBitmap(
                    BitmapFactory.decodeFile(
                        it.path
                    )
                )

            } else {

                viewDataBinding!!.ivRetakeFrontPhoto.setImageBitmap(
                    BitmapFactory.decodeFile(
                        it.path
                    )
                )
            }
        }*/



    }

    override fun onClick(p0: View?) {
        when (p0!!.id) {
            R.id.btnRetakeBackPhoto -> {
                selecteImageType = 0
                IDCardCamera.create(this).openCamera(IDCardCamera.TYPE_IDCARD_BACK)
            }
            R.id.btnRetakeFrontPhoto -> {
                selecteImageType = 1
                IDCardCamera.create(this).openCamera(IDCardCamera.TYPE_IDCARD_BACK)
            }
            R.id.btnUpload -> {

            /*    navigate(
                    DriverLicensePreviewFragmentDirections.actionDriverLicensePreviewFragmentToVehicleInfoFragment()
                )*/
                /*  with(viewModel.currentDocumentTitle.value) {
                      when (this) {
                          AppConstants.DOC_DRIVER_LICENSE -> {
                             goTo(
                                 DriverLicenseUploadDirections.actionGlobalVehicleInfoFragment()
                             )
                              viewModel.currentDocumentTitle.value = AppConstants.DOC_PASSPORT

                           }
                          AppConstants.DOC_PASSPORT -> {

                            goTo(  PassportUploadDirections.actionGlobalNationalIdUpload()
                            )
                              viewModel.currentDocumentTitle.value = AppConstants.DOC_NATIONAL_ID


                          }
                          AppConstants.DOC_NATIONAL_ID -> {

                             goTo(
                                 NationalIdUploadDirections.actionGlobalTakeSelfiFragment()
                             )

                          }
                      }
                  }*/

            }


        }


    }


    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        if (resultCode == IDCardCamera.RESULT_CODE) {
            val path = IDCardCamera.getImagePath(data)
            if (selecteImageType == 0) {
                if (!TextUtils.isEmpty(path)) {
                    if (requestCode == IDCardCamera.TYPE_IDCARD_FRONT) {
                        viewDataBinding!!.ivRetakeBackPhoto.setImageBitmap(
                            BitmapFactory.decodeFile(
                                path
                            )
                        )
                    } else if (requestCode == IDCardCamera.TYPE_IDCARD_BACK) {
                        viewDataBinding!!.ivRetakeBackPhoto.setImageBitmap(
                            BitmapFactory.decodeFile(
                                path
                            )
                        )
                    }
                }
            } else {
                if (!TextUtils.isEmpty(path)) {
                    if (requestCode == IDCardCamera.TYPE_IDCARD_FRONT) {
                        viewDataBinding!!.ivRetakeFrontPhoto.setImageBitmap(
                            BitmapFactory.decodeFile(
                                path
                            )
                        )
                    } else if (requestCode == IDCardCamera.TYPE_IDCARD_BACK) {
                        viewDataBinding!!.ivRetakeFrontPhoto.setImageBitmap(
                            BitmapFactory.decodeFile(
                                path
                            )
                        )
                    }
                }
            }

        }
    }

}
