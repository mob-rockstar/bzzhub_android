package com.app.basketiodriver.data.model.api.response.earning

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class YearlyBalanceReportItem (
    @SerializedName("month_name")
    val monthName: String = "",

    @SerializedName("month_balance")
    val monthBalance: String = "",

    @SerializedName("month_number")
    val monthNumber : Int = 0,

    @SerializedName("year")
    val year: String = ""
) : Parcelable