package com.app.basketiodriver.ui.base

import android.annotation.TargetApi
import android.app.*
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.location.Location
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.LayoutRes
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProviders
import com.app.basketiodriver.BR
import com.app.basketiodriver.R
import com.app.basketiodriver.ShopperApp
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.chat.User
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.dashboard.Order
import com.app.basketiodriver.databinding.ErrorDailogBinding
import com.app.basketiodriver.di.Navigators
import com.app.basketiodriver.service.FCMService
import com.app.basketiodriver.ui.chat.ChatActivity
import com.app.basketiodriver.utils.*
import com.google.android.material.textfield.TextInputEditText
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.reflect.TypeToken
import dagger.android.AndroidInjection
import io.github.inflationx.viewpump.ViewPumpContextWrapper
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import org.json.JSONObject
import timber.log.Timber
import javax.inject.Inject

/**
 * Created by ibraheem lubbad on 2020-01-07.
 * Copyright (c) 2020 Basket.jo. All rights reserved.
 **/

/**
 *
 * @param T : ViewDataBinding?
 * @param V : BaseViewModel<*>
 * @property layoutId Int  bind layout view
 * @property viewModel V bind ViewModel to current with screen
 */
abstract class BaseActivity<T : ViewDataBinding?, V : BaseViewModel<*>> : AppCompatActivity(),
    BaseFragment.Callback {


    @Inject
    lateinit var viewModelFactory: ViewModelProviderFactory


    // this can probably depend on isLoading variable of BaseViewModel,
    // since its going to be common for all the activities
    private var mProgressDialog: ProgressDialog? = null
    var viewDataBinding: T? = null
        private set

    private var mViewModel: V? = null
    /**
     * Override for set binding variable
     *
     * @return variable id
     */
    private val bindingVariable: Int = BR._all

    /**
     * @return layout resource id
     */
    @get:LayoutRes
    abstract val layoutId: Int

    /**
     * Override for set view model
     *
     * @return view model instance
     */
    abstract val viewModel: V

    // Device id
    private var deviceID: String =""


    override fun onFragmentAttached() {}
    override fun onFragmentDetached(tag: String?) {}
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase))
    }


    protected open fun <T : ViewModel> getViewModel(cls: java.lang.Class<T>): T {
        return ViewModelProviders.of(this, viewModelFactory)[cls]
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        performDependencyInjection()
        setLocale()

        super.onCreate(savedInstanceState)
        performDataBinding()

        // Register EventBus
        EventBus.getDefault().register(this)

        // Get device id and save it in local
        deviceID = getDeviceID()
        PreferenceManager.deviceId = deviceID

        // Check if no internet
        if (!isNetworkConnected){
            Toast.makeText(this, getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()

        ShopperApp.Instance.setCurrentActivity(this)
    }

    override fun onPause() {
        clearReferences()
        super.onPause()
    }

    override fun onDestroy() {
        clearReferences()
        super.onDestroy()

        // Register EventBus
        EventBus.getDefault().unregister(this)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    open fun onMessageEvent(event: MessageEvent) {
        Timber.tag("BaseActivity").e("onMessageEvent()")
        when (event.message) {
            AppConstants.MESSAGE_RECEIVED_CHAT_MESSAGE -> {
                Timber.tag("BaseActivity").e("MESSAGE_RECEIVED_CHAT_MESSAGE")

                val chatContent = event.data as JSONObject

                // Show the notification
                showInAppMessagingNotification(
                    chatContent.get("message").toString(),
                    chatContent.get("order_id").toString(),
                    chatContent.get("user_id").toString(),
                    chatContent.get("user_name").toString(),
                    chatContent.get("user_photo").toString(),
                )
            }
        }
    }

    private fun clearReferences(){
        val currActivity = ShopperApp.Instance.getCurrentActivity()
        try{
            if (currActivity != null){
                if (this == currActivity)
                    ShopperApp.Instance.setCurrentActivity(null)
            }
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    @TargetApi(Build.VERSION_CODES.M)
    fun hasPermission(permission: String?): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                permission?.let { checkSelfPermission(it) } == PackageManager.PERMISSION_GRANTED
    }

    fun hideKeyboard() {
        val view = this.currentFocus
        if (view != null) {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(view.windowToken, 0)

        }
    }


    /**
     * hide loading dialog
     */
    fun hideLoading() {
        if (mProgressDialog != null && mProgressDialog!!.isShowing) {
            mProgressDialog!!.cancel()
        }
    }

    val isNetworkConnected: Boolean
        get() = NetworkUtils.isNetworkConnected(applicationContext)


    fun performDependencyInjection() {
        AndroidInjection.inject(this)
    }

    @TargetApi(Build.VERSION_CODES.M)
    fun requestPermissionsSafely(permissions: Array<String?>?, requestCode: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            permissions?.let { requestPermissions(it, requestCode) }
        }
    }

    /**
     * show loading dialog while  long processing
     */
    fun showLoading() {
        hideLoading()
        mProgressDialog = CommonUtils.showLoadingDialog(this)
    }

    private fun performDataBinding() {
        viewDataBinding = DataBindingUtil.setContentView<T>(this, layoutId)
        mViewModel = if (mViewModel == null) viewModel else mViewModel
        viewDataBinding!!.setVariable(bindingVariable, mViewModel)
        viewDataBinding!!.executePendingBindings()
        mViewModel?.isLoading!!.observe(this, Observer { consumeResponse(it) })

//        mViewModel?.errorResLiveData?.observeForever {
//
//            if (it != null) {
//                showErrorMessages(it)
//            }
//        }
//
//        if (NetworkUtils.isNetworkConnected(this)) {
//            //showErrorMessages(getString(R.string.no_internet))
//        }
    }

    /**
     * monitor isloading  live data  to show dialog or dismiss
     * @param o Boolean
     */
    open fun consumeResponse(o: Boolean) {
        if (o) {
            showLoading()
        } else {
            hideLoading()
        }
    }

    /**
     *
     * Method to show  toolbar  for current activity and enable toolbar options
     *
     * @param title String
     * @param showBack Boolean
     * @param toolbar Toolbar
     * @param click OnClickListener? optional
     * @param isHasMenu Boolean optional
     */
    var mToolbar: Toolbar? = null

    /**
     * Init the login toolbar
     */
    protected fun initLoginToolbar(
        title: String,
        showBack: Boolean,
        toolbar: Toolbar,
        click: View.OnClickListener?,
        isHasMenu: Boolean = false
    ) {
        mToolbar = toolbar

        if (supportActionBar == null) {
            setSupportActionBar(toolbar)

        }
        if (showBack) {
            toolbar.navigationIcon = resources.getDrawable(R.drawable.ic_new_back)
            if (isHasMenu) {
                /*  toolbar.findViewById<AppCompatImageView>(R.id.btnBack)
                      .setImageResource(R.drawable.ic_menu_green)*/
                toolbar.navigationIcon = resources.getDrawable(R.drawable.ic_humberger_menu)
            }
            //    toolbar.findViewById<AppCompatImageView>(R.id.btnBack).visibility = View.GONE
            //    toolbar.findViewById<AppCompatImageView>(R.id.btnBack)?.setOnClickListener(click)
            //  supportActionBar?.setDisplayHomeAsUpEnabled(true);
            supportActionBar?.setDisplayShowHomeEnabled(true)
            //   toolbar.navigationIcon = resources.getDrawable(R.drawable.icons_back)
            toolbar.setNavigationOnClickListener(click)

        }

        /// here monitor any change title coming from fragments
        viewModel.screenTitle.observe(this, Observer {
            toolbarTitle(it)
        })

        // Set the title
        toolbarTitle(title)

        // Set the title color
        findViewById<TextView>(R.id.toolBarTitle)?.setTextColor(resources.getColor(R.color.colorWhite))
    }


    protected fun initToolbar(
        title: String,
        showBack: Boolean,
        toolbar: Toolbar,
        click: View.OnClickListener?,
        isHasMenu: Boolean = false
    ) {
        mToolbar = toolbar

        if (supportActionBar == null) {
            setSupportActionBar(toolbar)

        }
        if (showBack) {
            toolbar.navigationIcon = resources.getDrawable(R.drawable.ic_back_black)
            if (isHasMenu) {
                /*  toolbar.findViewById<AppCompatImageView>(R.id.btnBack)
                      .setImageResource(R.drawable.ic_menu_green)*/
                toolbar.navigationIcon = resources.getDrawable(R.drawable.ic_side_menu)
            }
            //    toolbar.findViewById<AppCompatImageView>(R.id.btnBack).visibility = View.GONE
            //    toolbar.findViewById<AppCompatImageView>(R.id.btnBack)?.setOnClickListener(click)
            //  supportActionBar?.setDisplayHomeAsUpEnabled(true);
            supportActionBar?.setDisplayShowHomeEnabled(true)
            //   toolbar.navigationIcon = resources.getDrawable(R.drawable.icons_back)
            toolbar.setNavigationOnClickListener(click)

        }


        /// here monitor any change title coming from fragments
        viewModel.screenTitle.observe(this, Observer {
            toolbarTitle(it)
        })


        // toolbar.findViewById<TextView>(R.id.toolBarTitle)?.text = title

        toolbarTitle(title)

    }

    protected fun toolbarTitle(title: String) {
        findViewById<TextView>(R.id.toolBarTitle)?.text = title
    }


    /**
     * Change edit text style to success style when input valid
     * @receiver EditText
     */
    fun EditText.onSuccess() {
        this.setCompoundDrawablesWithIntrinsicBounds(
            null,
            null,
            resources.getDrawable(R.drawable.ic_success_message),
            null
        )
    }

    /**
     * Change  input edit text style to success style when input valid
     * @receiver EditText
     */

    fun TextInputEditText.onSuccess() {
        this.setCompoundDrawablesWithIntrinsicBounds(
            null,
            null,
            resources.getDrawable(R.drawable.ic_success_message),
            null
        )
    }

    /**
     * Change edit ext style to error style when input invalid
     * @receiver EditText
     */
    fun EditText.onError() {
        this.setCompoundDrawablesWithIntrinsicBounds(
            null,
            null,
            resources.getDrawable(R.drawable.ic_error_message),
            null
        )
    }

    /**
     * change input edit text style to error style when input invalid
     * @receiver TextInputEditText
     */
    fun TextInputEditText.onError() {
        this.setCompoundDrawablesWithIntrinsicBounds(
            null,
            null,
            resources.getDrawable(R.drawable.ic_error_message),
            null
        )
    }


    /**
     * Show dialog  for all errors coming from API
     *
     * @param title String
     * @param messages String
     * @param listener OnDismissListener?
     */
    fun showErrorMessages(messages: ErrorResponse) {
        val listToString = viewModel.parseFieldErorrs(messages)
        val dialog = Dialog(this, R.style.PauseDialog)
        val binding = ErrorDailogBinding.inflate(LayoutInflater.from(this))
        dialog.setContentView(binding.root)
        dialog.setCanceledOnTouchOutside(true)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        binding.tvErrorMessages.text = listToString
        binding.btnOkay.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    fun showErrorMessages(messages: String) {
        val dialog = Dialog(this, R.style.PauseDialog)
        val binding = ErrorDailogBinding.inflate(LayoutInflater.from(this))
        dialog.setContentView(binding.root)
        dialog.setCanceledOnTouchOutside(true)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        binding.tvErrorMessages.text = messages
        binding.btnOkay.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    // Show the order cancelled dialog
    fun showOrderCancelledDialog(){
        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder.setCancelable(false)
        builder.setMessage(resources.getString(R.string.msg_order_cancelled))
            .setPositiveButton(R.string.ok_btn_txt) { dialog, which ->
                dialog.dismiss()
            }.create().show()
    }

    // Get device id
    fun getDeviceID() : String{
        if (deviceID.isEmpty()){
            deviceID = Settings.Secure.getString(this.contentResolver,
                Settings.Secure.ANDROID_ID)
        }

        return deviceID
    }

    fun setLocale() {
        if (PreferenceManager.currentUserLanguage == 2) {
            CommonUtils.setLocale(this, AppConstants.ARABIC)
        } else {
            CommonUtils.setLocale(this, AppConstants.ENGLISH)
        }
    }

    // Show the dialog to let user to install the updated version
    fun gotoNextVersion(appUrl : String, activity: Activity){
        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder.setCancelable(false)
        builder.setMessage(resources.getString(R.string.check_update_label))
            .setPositiveButton(R.string.ok_btn_txt) { dialog, which ->
                try {
                    activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(appUrl)))
                } catch (e: ActivityNotFoundException) {
                    activity.startActivity(
                        Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("http://shoppers.basket.jo//download")
                        )
                    )
                }
            }.setNegativeButton(R.string.cancel_btn_txt) { dialog, which ->
                finish()
                moveTaskToBack(true)
            }.create().show()
    }

    /**
     * Show the in-app messaging notification
     */
    private fun showInAppMessagingNotification(message : String, orderId : String, customerId : String?, customerName : String?, customerImage : String?){

        val intent = Intent(this, ChatActivity::class.java)
        intent.putExtra("KEY_ORDER_OUTLET_ID", orderId.toLongOrNull() ?: 0L)
        intent.putExtra("KEY_USER_ID", customerId ?: "")
        intent.putExtra("KEY_USER_NAME", customerName ?: "")
        intent.putExtra("KEY_USER_IMAGE", customerImage ?: "")

        val contentIntent: PendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)

        val builder = NotificationCompat.Builder(this, FCMService.BASKET_LOCAL_CHANNEL_NAME).setSmallIcon(R.drawable.ic_notifications)
            .setColor(ContextCompat.getColor(applicationContext, R.color.colorPrimary))
            .setContentTitle(null)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(contentIntent)
            .setDefaults(NotificationCompat.DEFAULT_SOUND or NotificationCompat.DEFAULT_LIGHTS or NotificationCompat.DEFAULT_VIBRATE)
            .setAutoCancel(true)

        try{
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(FCMService.BASKET_LOCAL_CHANNEL_NAME, FCMService.BASKET_LOCAL_NOTIFICATION_NAME, NotificationManager.IMPORTANCE_HIGH)
                manager.createNotificationChannel(channel)
            }

            manager.notify(AppConstants.BASKET_LOCAL_CHANNEL_ID, builder.build())
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    /**
     * Create the notification channel
     */
    private fun createNotificationChannel(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val notificationChannel = NotificationChannel(
                FCMService.BASKET_CHANNEL_NAME,
                FCMService.BASKET_NOTIFICATION_NAME,
                NotificationManager.IMPORTANCE_HIGH
            )
            notificationChannel.enableLights(true)
            notificationChannel.lightColor = Color.RED
            notificationChannel.enableVibration(true)
            notificationChannel.describeContents()
            notificationChannel.setShowBadge(true)

            notificationManager.createNotificationChannel(notificationChannel)
        }
    }

}