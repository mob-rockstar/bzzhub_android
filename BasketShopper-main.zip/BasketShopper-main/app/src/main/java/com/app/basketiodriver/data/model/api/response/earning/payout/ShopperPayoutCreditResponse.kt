package com.app.basketiodriver.data.model.api.response.earning.payout

import com.google.gson.annotations.SerializedName




class ShopperPayoutCreditResponse {
    @SerializedName("data")
    val data: ShopperPayoutCreditData? = null

    @SerializedName("message")
    val message: String = ""
}