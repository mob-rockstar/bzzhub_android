package com.app.basketiodriver.ui.availablebatches

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.ActivityAvailableBatchesBinding
import com.app.basketiodriver.databinding.DailogAccessToBatchesBinding
import com.app.basketiodriver.ui.availablebatches.adapters.ItemAvailableBatchAdapter
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.batches.BatchesActivity

class AvailableBatchesActivity : BaseActivity<ActivityAvailableBatchesBinding?, AvailableBatchesViewModel>(){


    override val layoutId: Int
        get() = R.layout.activity_available_batches

    override val viewModel: AvailableBatchesViewModel
        get() {
            return getViewModel(AvailableBatchesViewModel::class.java)
        }

    lateinit var itemAvailableBatchAdapter: ItemAvailableBatchAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        initToolbar(getString(R.string.available_batches),
            true, viewDataBinding!!.toolbarLayout.toolbar,
            View.OnClickListener {
                run {

                    finish()
                }
            })

        itemAvailableBatchAdapter =
            ItemAvailableBatchAdapter(this, object : ItemAvailableBatchAdapter.ItemAction {
                override fun clickOnItem() {
                    startActivity(BatchesActivity.newIntent(baseContext))
                }
            })
        val words = listOf("pen", "cup", "dog", "spectacles")
        itemAvailableBatchAdapter.replace(words)

        viewDataBinding!!.rvItems.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        viewDataBinding!!.rvItems.adapter = itemAvailableBatchAdapter


        showTips()


    }

    companion object {
        fun newIntent(context: Context?): Intent {
            return Intent(context, AvailableBatchesActivity::class.java)
        }
    }


    fun showTips() {
        val dialog = Dialog(this, R.style.PauseDialog)
        val binding = DailogAccessToBatchesBinding.inflate(LayoutInflater.from(this))
        dialog.setContentView(binding.root)
        binding.btnNextTip1.setOnClickListener {

            binding.layoutTip1.animate()
                .translationY(binding.layoutTip1.height.toFloat())
                .alpha(0.0f)
                .setDuration(300)
                .setListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        super.onAnimationEnd(animation)
                        binding.layoutTip1.visibility = View.GONE
                        binding.layoutTip2.visibility = View.VISIBLE
                    }
                })

        }
        binding.btnNextTip2.setOnClickListener {

            binding.layoutTip2.animate()
                .translationY(binding.layoutTip2.height.toFloat())
                .alpha(0.0f)
                .setDuration(300)
                .setListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        super.onAnimationEnd(animation)
                        binding.layoutTip2.visibility = View.GONE
                        binding.layoutTip3.visibility = View.VISIBLE
                    }
                })

        }
        binding.btnNextTip3.setOnClickListener {

            binding.layoutTip3.animate()
                .translationY(binding.layoutTip3.height.toFloat())
                .alpha(0.0f)
                .setDuration(300)
                .setListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        super.onAnimationEnd(animation)
                        binding.layoutTip3.visibility = View.GONE
                        binding.layoutTip4.visibility = View.VISIBLE
                    }
                })

        }
        binding.btnStartShopping.setOnClickListener {
            dialog.dismiss()
        }
        dialog.setOnDismissListener {

            if (itemAvailableBatchAdapter.itemCount == 0) {
                finish()
            } else {

                dialog.dismiss()
            }

        }
        dialog.setCanceledOnTouchOutside(
            false
        )
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
    }
}
