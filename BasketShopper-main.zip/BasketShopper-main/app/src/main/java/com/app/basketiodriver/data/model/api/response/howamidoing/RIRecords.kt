package com.app.basketiodriver.data.model.api.response.howamidoing

import android.os.Parcelable
import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
class RIRecords : Parcelable {
    @SerializedName("reliability_incident_reason")
    @Expose
    var reliability_incident_reason: String = ""

    @SerializedName("reliability_incident_description")
    @Expose
    var reliability_incident_description: String = ""

    @SerializedName("created_on")
    @Expose
    var created_on: String? = null
}