package com.app.basketiodriver.ui.order

import android.content.res.Resources
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.app.basketiodriver.R
import com.app.basketiodriver.ShopperApp
import com.app.basketiodriver.data.SupportMenuManager
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.checkout.*
import com.app.basketiodriver.data.model.api.response.general.SimpleResponse
import com.app.basketiodriver.databinding.ActivityArrivedToCustomerBinding
import com.app.basketiodriver.di.Navigators
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.checkout.adapter.DepartmentAdapter
import com.app.basketiodriver.ui.dashbaord.OrdersManager
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.PAYMENT_TYPE_BRING_CC
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.PAYMENT_TYPE_CREDIT
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_ORDER_FINISHED
import com.app.basketiodriver.ui.dialogs.ConfirmPaymentDialogFragment
import com.app.basketiodriver.ui.dialogs.DialogCustomerInfo
import com.app.basketiodriver.ui.dialogs.DialogOrderCompleted
import com.app.basketiodriver.ui.dialogs.DialogPaymentStatus
import com.app.basketiodriver.ui.home.HomeViewModel
import com.app.basketiodriver.ui.order.adapter.ArrivedToCustomerProductListAdapter
import com.app.basketiodriver.ui.order.adapter.OrderReviewListAdapter
import com.app.basketiodriver.utils.AppUtils
import com.app.basketiodriver.utils.SwipeManyStateButton
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
//import kotlinx.android.synthetic.main.app_bar_order_review.view.*
//import kotlinx.android.synthetic.main.app_bar_with_support.view.*
//import kotlinx.android.synthetic.main.app_bar_with_support.view.tvOrderCounts
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.*
import javax.inject.Inject
import kotlin.collections.ArrayList

class ArrivedToCustomerActivity : BaseActivity<ActivityArrivedToCustomerBinding, HomeViewModel>(), SwipeManyStateButton.OnStateChangeListener,
    HasAndroidInjector {
    override val layoutId: Int
        get() = R.layout.activity_arrived_to_customer

    override val viewModel: HomeViewModel
        get() {
            return getViewModel(HomeViewModel::class.java)
        }

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    var orderId : Long = 0
    var orderStatus : Int = 0
    var totalAmount : Double = 0.0

    var orders : OutletOrder? = null

    private var allProductClick : Boolean = false
    private var openChatClick : Boolean = false

    // Support Manager
    lateinit var supportMenuManager : SupportMenuManager

    lateinit var reviewListAdapter : OrderReviewListAdapter

    var symbols: DecimalFormatSymbols = DecimalFormatSymbols(Locale.US)
    var formatter: DecimalFormat = DecimalFormat("#0.00", symbols)


    var userDetails : UserDetails? = null
    var deliverySlot : String? = null

    // Timer to get review status in every few seconds
    var reviewTimer : Timer? = null
    var isRunningTimer : Boolean = false

    // Check if Express Store
    private var isExpressStore = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        initToolbar(getString(R.string.arrived_to_customer_header),
            true, viewDataBinding!!.layoutToolBar.toolbar,
            View.OnClickListener {
                run {
                    onBackPressed()
                }
            })

        // Display the order count
        val count = PreferenceManager.orderCounterNumber
        viewDataBinding!!.layoutToolBar.tvOrderCounts.text = String.format(
            Locale("en"),
            "%d",
            count
        )

        // Get the order id
        if (intent.extras != null) {
            orderId     = intent.extras!!.getLong("ARG_ORDER_ID")
            orderStatus = intent.extras!!.getInt("ARG_ORDER_STATUS")
            totalAmount = intent.extras!!.getDouble("ARG_TOTAL")
            isExpressStore = intent.getIntExtra("ARG_IS_EXPRESS", 0)
        }

        initViews()

        // Get order review status
        setupData(false)
    }

    private fun initViews(){
        // Setup the Swipe button
        viewDataBinding!!.swipeButton.state = orderStatus
        viewDataBinding!!.swipeButton.setOnStateChangeListener(this)

        initSupportMenu()

        initRecyclerView()

        viewDataBinding!!.ivShowDetails.setOnClickListener {
            allProductClick = !allProductClick
            if (allProductClick) {
                viewDataBinding!!.ivShowDetails.setImageResource(R.drawable.ic_arrow_up)
                viewDataBinding!!.rv.visibility = View.GONE
                viewDataBinding!!.rvProducts.visibility = View.VISIBLE
            } else {
                viewDataBinding!!.ivShowDetails.setImageResource(R.drawable.ic_arrow_down)
                viewDataBinding!!.rv.visibility = View.VISIBLE
                viewDataBinding!!.rvProducts.visibility = View.GONE
            }
        }
    }

    private fun initRecyclerView(){
        viewDataBinding!!.rv.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL,false)

        viewDataBinding!!.rvProducts.layoutManager = LinearLayoutManager(this)
        viewDataBinding!!.rvProducts.setHasFixedSize(true)

        // Tap the product list
//        viewDataBinding!!.rv.setOnClickListener {
//            if (!allProductClick){
//                allProductClick = true
//
//                // Go to NewProductList page
//                Navigators.goToNewProductListActivity(this, ArrayList(orders!!.ordersItems))
//            }
//        }
    }

    private fun initSupportMenu(){
        // Count
        val count = PreferenceManager.orderCounterNumber
        viewDataBinding!!.layoutToolBar.tvOrderCounts.text = String.format(
            Locale("en"),
            "%d",
            count
        )
        viewDataBinding!!.layoutToolBar.tvOrderCounts.setOnClickListener {
            Navigators.goToDashboard(this)
        }

        val support = viewDataBinding!!.layoutToolBar.support
        supportMenuManager = SupportMenuManager(support)

        support.setOnClickListener {
            supportMenuManager.showSupportMenu()
        }

        // Info button
        viewDataBinding!!.layoutToolBar.info.setOnClickListener {
            showCustomerInfoDialog()
        }
    }

    private fun setListeners(orders: ArrayList<OrdersItem>){
//        viewDataBinding!!.allProduct.setOnClickListener {
//            if (!allProductClick){
//                allProductClick = true
//                Navigators.goToNewProductListActivity(this, orders)
//            }
//        }

//        viewDataBinding!!.swipeButton.setOnStateChangeListener(this)
    }

    // Start timer
    private fun startTimer(){
        val delay = 10000L // delay for 10 seconds.
        val period = 20000L // repeat every 20 seconds.

        // Create the timer instance
        reviewTimer = Timer()
        isRunningTimer = true

        reviewTimer!!.scheduleAtFixedRate(object : TimerTask() {
            override fun run() {
                //Call function
                runOnUiThread { if (!isDestroyed) setupData(true) }
            }
        }, delay, period)
    }

    private fun setupData(isAutoRefresh : Boolean){
        viewModel.getShopperOrderReview(orderId, object : HandleResponse<ShopperOrderReview> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected) {
                    Toast.makeText(this@ArrivedToCustomerActivity,error?.message,Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@ArrivedToCustomerActivity,resources?.getString(R.string.no_internet_conn_msg_txt),Toast.LENGTH_SHORT).show()
                }
            }

            override fun handleSuccessResponse(successResponse: ShopperOrderReview) {
                val response = successResponse.responseOrderReview
                if (response != null) {
                    if (response.httpCode != 200) {
                        Toast.makeText(this@ArrivedToCustomerActivity, response.message,Toast.LENGTH_SHORT).show()
                    }
                    else {
                        try{
                            orders = response.outletOrder!!
                            orders!!.id = orderId

                            userDetails = response.userDetails
                            deliverySlot = orders!!.deliverySlot

                            if (isAutoRefresh){
                                if (orders!!.paymentGatewayId == 24 && orders!!.paymentStatus != null && orders!!.paymentStatus == 1) { // Paid already
                                    // Stop the timer
                                    if (reviewTimer != null){
                                        reviewTimer!!.cancel()
                                    }
                                }
                            }
                            else{
                                // Setup RecyclerView
                                setupRecyclerViewData(orders!!.ordersItems)

                                // Init the Vertical product list
                                setupVerticalProductRV(ArrayList(orders!!.ordersItems))

                                // Display the order info
                                setupFieldData(orders!!.ordersItems.size)

                                // Set click listener
//                                setListeners(ArrayList(orders!!.ordersItems))

                                val showChat = !(orders!!.isExpress == 1 || isExpressStore == 1)
                                supportMenuManager.initConsumerNumber(
                                    0,
                                    true,
                                    response.userDetails!!.userMobile ?: "",
                                    showChat,
                                    true
                                )

                                // Auto-fresh for credit card order
                                if (orders!!.paymentGatewayId == 24 && orders!!.paymentStatus != null && orders!!.paymentStatus == 0){ // Unpaid
                                    if (!isRunningTimer){
                                        // start the timer
                                        startTimer()
                                    }
                                }
                            }
                        }
                        catch (e : Exception){
                            e.printStackTrace()
                        }
                    }
                } else {
                    Toast.makeText(this@ArrivedToCustomerActivity, R.string.error_load_info, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    // Setup the Vertical product list
    private fun setupVerticalProductRV(list : ArrayList<OrdersItem>){
        val departments = AppUtils.sortItems(list, 1)
        val listAdapter = ArrivedToCustomerProductListAdapter(this, departments, "", 0, CustomerInfo(), false, false, 0)

        viewDataBinding!!.rvProducts.adapter = listAdapter
    }

    // Setup RecyclerView
    private fun setupRecyclerViewData(ordersItem: List<OrdersItem>){
        reviewListAdapter = OrderReviewListAdapter(this, ordersItem)
        viewDataBinding!!.rv.adapter = reviewListAdapter
    }

    // Display the information
    private fun setupFieldData(itemsCount: Int){
        if (orders == null)
            return

        // Item count
        if (itemsCount > 1){
            viewDataBinding!!.itemCount.text = String.format(Locale.US, getString(R.string.order_item_count), itemsCount)
        }
        else{
            viewDataBinding!!.itemCount.text = String.format(Locale.US, getString(R.string.order_one_item_count), itemsCount)
        }

        // Subtotal
        viewDataBinding!!.subtotal.text = String.format(
            Locale.US, "%s %s", PreferenceManager.currency, formatter.format(
                orders!!.subtotal ?: 0.0
            )
        )

        // Discount
        viewDataBinding!!.discount.text = String.format(
            Locale.US, "%s %s", PreferenceManager.currency, formatter.format(
                orders!!.freeDeliveryDiscount ?: 0.0
            )
        )

        // Subtotal Adjustment
        if (orders!!.subtotalAdjustment != null && orders!!.subtotalAdjustment!! > 0){
            viewDataBinding!!.subtotalAdjustment.text = String.format(
                Locale.US, "%s %s", PreferenceManager.currency, formatter.format(
                    orders!!.subtotalAdjustment!!
                )
            )
        }
        else{
            viewDataBinding!!.subtotalAdjustmentRow.visibility = View.GONE
        }

        // delivery
        val deliveryAmount = orders!!.deliveryCharge ?: 0.0 + (orders!!.oneHrFee ?: 0.0) + (orders!!.underThresholdAmount ?: 0.0)
        viewDataBinding!!.delivery.text = String.format(
            Locale.US, "%s %s", PreferenceManager.currency, formatter.format(
                deliveryAmount
            )
        )

        // service fee
        viewDataBinding!!.serviceFee.text = String.format(
            Locale.US, "%s %s", PreferenceManager.currency, formatter.format(
                orders!!.service_fee ?: 0.0
            )
        )

        // total amount
        val totalAmount = formatter.format(orders!!.total ?: 0.0)
        viewDataBinding!!.total.text = String.format(
            Locale.US,
            "%s %s",
            PreferenceManager.currency,
            totalAmount
        )

        // promo amount
        val promoAmount = formatter.format(orders!!.promoTotalAmount ?: 0.0)
        viewDataBinding!!.promoCodeTV.text = String.format(
            Locale.US,
            "%s %s",
            PreferenceManager.currency,
            promoAmount
        )

        // delivery instructions
        viewDataBinding!!.deliveryInstructionsTV.text = orders!!.deliveryInstructions ?: ""

        if (orders!!.freeDeliveryDiscount != null && orders!!.freeDeliveryDiscount != 0.0){
            viewDataBinding!!.discountTR.visibility = View.VISIBLE
        }

        if (orders!!.promoTotalAmount != null && orders!!.promoTotalAmount != 0.0){
            viewDataBinding!!.promoCodeTR.visibility = View.VISIBLE
        }

        if (orders!!.deliveryInstructions != null && orders!!.deliveryInstructions != ""){
            viewDataBinding!!.deliveryInstructionsLL.visibility = View.VISIBLE
        }

        // Payment Method
        setupPaymentMethod()
    }

    // Setup payment method
    private fun setupPaymentMethod(){
        if (orders!!.paymentGatewayId == null) {
            return
        }

        // Payment Status
        if (orders!!.paymentStatus != null && orders!!.paymentStatus == 1){
            viewDataBinding!!.tvPaidStatus.text = getString(R.string.paid)
            viewDataBinding!!.tvPaidStatus.setTextColor(resources.getColor(R.color.colorPrimary))
        }
        else{
            viewDataBinding!!.tvPaidStatus.text = getString(R.string.not_paid)
            viewDataBinding!!.tvPaidStatus.setTextColor(resources.getColor(R.color.colorGray))
        }

        // Check the payment type
        when (orders!!.paymentGatewayId) {
            PAYMENT_TYPE_CREDIT -> {
                viewDataBinding!!.ivCard.setImageResource(R.drawable.ic_type_card)
                viewDataBinding!!.tvPaidStatus.visibility = View.VISIBLE
            }
            PAYMENT_TYPE_BRING_CC -> {
                viewDataBinding!!.ivCard.setImageResource(R.drawable.ic_pos)
                viewDataBinding!!.tvPaidStatus.visibility = View.GONE
            }
            else -> {
                viewDataBinding!!.ivCard.setImageResource(R.drawable.ic_type_cash)
                viewDataBinding!!.tvPaidStatus.visibility = View.GONE
            }
        }

        viewDataBinding!!.tvPaymentMethod.text = orders!!.paymentGatewayName


    }

    // create the customer info dialog
    private fun showCustomerInfoDialog(){
        // Show the customer info dialog if tap the info button
        DialogCustomerInfo.openDialog(this, userDetails?.userImage,
            String.format(Locale.ENGLISH, "%s %s", userDetails?.userFirstName, userDetails?.userLastName),
            userDetails?.userLocation,
            deliverySlot,
            userDetails?.userGoogleAddress,
            userDetails?.userAddressType,
            userDetails?.userDepartmentBuilding,
            userDetails?.userAdditionalInfo,
            userDetails?.userNearLandmark){
            // To Do
        }
    }

    // Update the status
    private fun tryUpdateStatus(state: Int){
        viewModel.updateOrderStatus(state, orderId, object : HandleResponse<SimpleResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected) {
                    Toast.makeText(this@ArrivedToCustomerActivity, error?.message,Toast.LENGTH_SHORT).show()
                }
                else {
                    Toast.makeText(this@ArrivedToCustomerActivity,resources?.getString(R.string.no_internet_conn_msg_txt),Toast.LENGTH_SHORT).show()
                }

                viewDataBinding!!.swipeButton.previousState()
            }

            override fun handleSuccessResponse(successResponse: SimpleResponse) {
                val response = successResponse.response
                if (response != null) {
                    if (response.httpCode == 200) {
                        doIfSpecialState(state)
                    } else {
                        Toast.makeText(this@ArrivedToCustomerActivity, response.message, Toast.LENGTH_SHORT).show()
                        viewDataBinding!!.swipeButton.previousState()
                    }
                }
                else {
                    Toast.makeText(this@ArrivedToCustomerActivity, getString(R.string.error_update_status), Toast.LENGTH_SHORT).show()
                    viewDataBinding!!.swipeButton.previousState()
                }
            }
        })
    }

    private fun doIfSpecialState(state: Int){
        if (state == STATUS_ORDER_FINISHED){
            ShopperApp.Instance.stopNotificationSound(this)
            if (orders != null && orders!!.paymentGatewayId != PAYMENT_TYPE_CREDIT && orders!!.paymentGatewayId != PAYMENT_TYPE_BRING_CC){ // If payment type is not credit order
                // Show the confirm dialog
                showConfirmPaymentDialog()
            }
            else{
                // Stop sending the shopper location
                Log.e("ArrivedToCustomer", "Stopping updating shopper location...")
                PreferenceManager.shouldStopLocation = true

                // Go to Dashboard
                Navigators.goToDashboardWithCongratulation(this, orderId)
            }
        }
    }

    private fun showConfirmPaymentDialog(){
        try{
            val confirmPaymentDialog = ConfirmPaymentDialogFragment.newInstance(orderId, totalAmount)
            confirmPaymentDialog.show(
                supportFragmentManager,
                ConfirmPaymentDialogFragment.javaClass.name
            )
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    // Show the payment status popup
    private fun showPaymentStatusDialog(){
        DialogPaymentStatus.openDialog(this)
    }

    // Chat Activity
    fun openChatActivity(){
        // Go to Chat page
        if (userDetails != null){
            Navigators.gotoChatActivity(this, orderId, userDetails?.userId.toString(), userDetails?.userFirstName ?: "", userDetails?.userImage ?: "")
        }
        else{
            Toast.makeText(this, "Sorry, failed to open the chat page because we couldn't get the user information.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onBackPressed() {
        // Go to Dashboard
        Navigators.goToDashboard(this)
    }

    override fun onResume() {
        super.onResume()

        allProductClick = false
        openChatClick = false

        if (orders != null && !isRunningTimer){
            if (orders!!.paymentGatewayId == 24 && orders!!.paymentStatus != null && orders!!.paymentStatus == 0) { // Not paid yet
                // Start the timer
                startTimer()
            }
        }
    }

    override fun onStart() {
        super.onStart()

        allProductClick = false
        openChatClick = false
    }

    override fun onStop() {
        super.onStop()

        if (reviewTimer != null){
            reviewTimer!!.cancel()
            isRunningTimer = false
        }
    }

    override fun onDestroy() {
        super.onDestroy()

        if (reviewTimer != null){
            reviewTimer!!.cancel()
            isRunningTimer = false
        }
    }

    /**
     * SwipeManyStateButton Listener
     */
    override fun onChangeState(state: Int?) {
        try{
            if (state != null){
                if (state == STATUS_ORDER_FINISHED && (orders != null && orders!!.paymentGatewayId != null && orders!!.paymentGatewayId == PAYMENT_TYPE_CREDIT)) { // Credit Card
                    if (orders!!.paymentStatus != null && orders!!.paymentStatus == 0) {
                        viewDataBinding!!.swipeButton.previousState()
                        showPaymentStatusDialog()
                    }
                    else {
                        tryUpdateStatus(state)
                    }
                }
                else {
                    tryUpdateStatus(state)
                }
            }
        }
        catch (e : Exception) {
            e.printStackTrace()
        }
    }
}