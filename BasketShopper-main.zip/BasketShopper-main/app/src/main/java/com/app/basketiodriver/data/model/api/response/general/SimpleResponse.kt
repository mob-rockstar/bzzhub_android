package com.app.basketiodriver.data.model.api.response.general

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class SimpleResponse {
    @SerializedName("response")
    @Expose
    val response: Response? = null
}