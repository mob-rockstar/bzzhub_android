package com.app.basketiodriver.service

import android.Manifest
import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.Location
import android.os.*
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import com.app.basketiodriver.R
import com.app.basketiodriver.ShopperApp
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.ui.home.HomeActivity
import com.app.basketiodriver.ui.splash.SplashActivity
import com.app.basketiodriver.utils.AppConstants
import com.app.basketiodriver.utils.MessageEvent
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.api.GoogleApiClient
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener
import com.google.android.gms.common.api.ResultCallback
import com.google.android.gms.common.api.Status
import com.google.android.gms.location.*
import org.greenrobot.eventbus.EventBus
import org.json.JSONObject
import timber.log.Timber
import java.util.*
import java.util.concurrent.TimeUnit

class LocationService : Service(), ConnectionCallbacks, OnConnectionFailedListener, LocationListener, ResultCallback<LocationSettingsResult> {
    private val TAG = "LocationService"
    private var mGoogleApiClient: GoogleApiClient? = null
    private var mLocationRequest: LocationRequest? = null
    private var mLocationSettingsRequest: LocationSettingsRequest? = null
    private var mCurrentLocation: Location? = null
    private var mRequestingLocationUpdates: Boolean? = null

    val CHANNEL_ID = "service_notification_channel_01"
    val CHANNEL_NAME = "service_notification_channel_name"

    // Location update thread
    private var thread: Thread? = null
    private var runnable: Runnable? = null
    private var threadDone = false
    private val mHandler = Handler()
//    private val socket: Socket? = null

    // Battery thread
    private var threadBattery: Thread? = null
    private var runnableBattery: Runnable? = null

    // Interval for updating the shopper location
    private val updateIntervalTime : Long = PreferenceManager.locationUpdateTime * 1000

    // Notification ID
    private val NOTIFICATION_CUSTOM_ID = 110011

    // Battery percent
    var batteryPct : Float = 0f
    var batteryIntent : Intent? = null

    private var isSentFirstLocation : Boolean = false

    override fun onBind(intent: Intent): IBinder? {
        return null
    }

    override fun onCreate() {
        super.onCreate()

        try {
            // Start the foreground service
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForeground(NOTIFICATION_CUSTOM_ID, notification)
            }
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        mRequestingLocationUpdates = false

        // Stop action if needs to stop
        try {
            if (intent != null && intent.action != null && intent.action == AppConstants.STOP_FOREGROUND_ACTION) {
                stopForeground(true)
                stopSelf()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Init Google API client
        buildGoogleApiClient()
        createLocationRequest()
        buildLocationSettingsRequest()
        checkLocationSettings()

        // Setup Thread
        runnable = Runnable {
            while (!threadDone) {
                try {
                    Thread.sleep(SOCKET_UPDATE_INTERVAL)
                    mHandler.post { sendShopperLiveLocation() }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

        // Start the thread
        if (thread == null) {
            thread = Thread(runnable)
            thread!!.start()
        }

        // Battery level (No need for now)
//        handleBatteryLevel()

        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        if (mGoogleApiClient != null) mGoogleApiClient!!.disconnect()

        done()

        // Stop service
        stopForeground(true)
        stopSelf()
    }

    override fun onTaskRemoved(rootIntent: Intent) {
        super.onTaskRemoved(rootIntent)

        stopSelf()
    }

    fun done() {
        threadDone = true
    }

    // Send the shopper location to server by socket
    private fun sendShopperLiveLocation() {
        try {
            if (mCurrentLocation != null) {

                val lat = mCurrentLocation!!.latitude
                val lng = mCurrentLocation!!.longitude

                Timber.tag(TAG).d("===== sendShopperLiveLocation() : Sending shopper location...")
                Timber.tag(TAG).d("===== shopper latitude : %s", lat)
                Timber.tag(TAG).d("===== shopper longitude : %s", lng)

                isSentFirstLocation = true

                // Upload the shopper location to server
                EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_POST_LOCATION, mCurrentLocation))
            }
            else if (ShopperApp.Instance.mCurrentLocation != null){
                Timber.tag(TAG).d("===== sendShopperLiveLocation() : Sending shopper location...")
                Timber.tag(TAG).d("===== shopper latitude : %s", ShopperApp.Instance.mCurrentLocation!!.latitude)
                Timber.tag(TAG).d("===== shopper longitude : %s", ShopperApp.Instance.mCurrentLocation!!.longitude)

                isSentFirstLocation = true

                // Upload the shopper location to server
                EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_POST_LOCATION, ShopperApp.Instance.mCurrentLocation))
            }
            else{
                Timber.tag(TAG).d("===== sendShopperLiveLocation() : Shopper location is null...")
            }
        } catch (ex: Exception) {
            ex.printStackTrace()
        }
    }

    // Start the location update
    private fun startLocationUpdates() {
        try {
            // Check if permission is granted
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
            ) {
                Log.d(TAG, "Location permission is not granted")
                return
            }

            if (mGoogleApiClient!!.isConnected && mLocationRequest != null) LocationServices.FusedLocationApi.requestLocationUpdates(
                mGoogleApiClient,
                mLocationRequest,
                this
            ).setResultCallback { status: Status? ->
                mRequestingLocationUpdates = true
            }
        } catch (ex: Exception) {
            ex.printStackTrace()
        }
    }

    /**
     * Handle the battery level and send it to server
     */
    private fun handleBatteryLevel(){
        runnableBattery = Runnable {
            while (!threadDone) {
                try {
                    Thread.sleep(BATTERY_UPDATE_INTERVAL)
                    mHandler.post { sendBatteryLevel() }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

        // Start the thread
        if (threadBattery == null) {
            threadBattery = Thread(runnableBattery)
            threadBattery!!.start()
        }
    }

    // Send the battery level to server
    private fun sendBatteryLevel(){
        try{
            if (batteryIntent != null){
                batteryPct = batteryIntent?.let { intent ->
                    val level: Int = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                    val scale: Int = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                    level * 100 / scale.toFloat()
                }!!

                ShopperApp.Instance.postBatteryLevel(batteryPct)
            }
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    /**
     * Initialize the Google API Client
     */
    @Synchronized
    private fun buildGoogleApiClient() {
        mGoogleApiClient = GoogleApiClient.Builder(this)
            .addConnectionCallbacks(this)
            .addOnConnectionFailedListener(this)
            .addApi(LocationServices.API)
            .build()

        // Connect
        if (!mGoogleApiClient!!.isConnected) mGoogleApiClient!!.connect()
    }

    // Create the location request by using interval
    private fun createLocationRequest() {
        mLocationRequest = LocationRequest()
        mLocationRequest!!.interval = LOCATION_UPDATE_INTERVAL
        mLocationRequest!!.priority = LocationRequest.PRIORITY_HIGH_ACCURACY
    }

    private fun buildLocationSettingsRequest() {
        val builder = LocationSettingsRequest.Builder()
        builder.addLocationRequest(mLocationRequest!!)
        mLocationSettingsRequest = builder.build()
    }

    private fun checkLocationSettings() {
        val result =
            LocationServices.SettingsApi.checkLocationSettings(
                mGoogleApiClient,
                mLocationSettingsRequest
            )
        result.setResultCallback(this)
    }

    /**
     * ResultCallback
     */
    override fun onResult(locationSettingsResult: LocationSettingsResult) {
        val status = locationSettingsResult.status
        when (status.statusCode) {
            LocationSettingsStatusCodes.SUCCESS -> {
                Timber.tag(TAG).d("===== onResult() : All location settings are satisfied...")
                if (mGoogleApiClient!!.isConnected) {
                    Timber.tag(TAG)
                        .d("===== onResult() : GoogleApiClient is connected ...")
                    Timber.tag(TAG)
                        .d("===== onResult() : starting location updates ...")
                    startLocationUpdates()
                }
                else
                    Timber.tag(TAG).d("===== onResult() : GoogleApiClient is not connected yet...")
            }

            LocationSettingsStatusCodes.RESOLUTION_REQUIRED ->
                Timber.tag(TAG).d("===== onResult() : Location settings are not satisfied...")

            LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE ->
                Timber.tag(TAG).d("===== onResult() : Location settings are inadequate...")
        }
    }


    /**
     * LocationListener
     */
    override fun onLocationChanged(location: Location) {
        // Set the location
        mCurrentLocation = location
        Timber.tag(TAG).d("===== onLocationChanged() : Location Updated ...")
        Timber.tag(TAG).d("===== Updated latitude : %s", location.latitude)
        Timber.tag(TAG).d("===== Updated longitude : %s", location.longitude)

        ShopperApp.Instance.mCurrentLocation = location

        // Send the shopper location
        if (!isSentFirstLocation)
            sendShopperLiveLocation()
    }

    /**
     * ConnectionCallback
     */
    override fun onConnected(bundle: Bundle?) {
        Timber.tag(TAG).d("===== onConnected : Connected to GoogleApiClient ...")
        if (mCurrentLocation != null) {
            // Check if permission is granted
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
            ) {
                return
            }

            // Start to update the location every update_interval
            startLocationUpdates()

            // Get the last location
            mCurrentLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient)

            if (mCurrentLocation != null){
                ShopperApp.Instance.mCurrentLocation = mCurrentLocation

                Timber.tag(TAG).d("===== shopper's last latitude : %s", mCurrentLocation!!.latitude)
                Timber.tag(TAG).d("===== shopper's last longitude : %s", mCurrentLocation!!.longitude)
            }

            // Send the shopper location
            if (mCurrentLocation != null || ShopperApp.Instance.mCurrentLocation != null){
                if (!isSentFirstLocation)
                    sendShopperLiveLocation()
            }
        }
        else{
            Timber.tag(TAG).d("===== onConnected : shopper location is null yet ...")
        }
    }

    override fun onConnectionSuspended(i: Int) {
        Timber.tag(TAG).d("===== onConnectionSuspended : Connection suspended ...")
    }

    override fun onConnectionFailed(connectionResult: ConnectionResult) {
        Timber.tag(TAG).d("===== onConnectionFailed : Connection failed ...")
        Timber.tag(TAG).d("===== onConnectionFailed : getErrorCode() = %d", connectionResult.errorCode)
    }


    /**
     * Custom Notification
     */
    @get:RequiresApi(api = Build.VERSION_CODES.O)
    private val notification: Notification
        get() {
            val notificationIntent = Intent(this, SplashActivity::class.java)
            val pendingIntent = PendingIntent.getActivity(
                this,
                0, notificationIntent, PendingIntent.FLAG_IMMUTABLE
            )

            var channel: NotificationChannel? = null
            channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_DEFAULT
            )

            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
            val builder = Notification.Builder(applicationContext, CHANNEL_ID)
                    .setAutoCancel(true)
                    .setContentTitle("Your Location is updating on Basket.jo")
                    .setSmallIcon(R.drawable.logo)
                    .setContentIntent(pendingIntent)
            return builder.build()
        }

    companion object {
        private var LOCATION_UPDATE_INTERVAL : Long = TimeUnit.SECONDS.toMillis(5) // update the location every 5 seconds

        private var SOCKET_UPDATE_INTERVAL : Long = TimeUnit.SECONDS.toMillis(5) // send the location every 5 secs via socket

        // Interval for posting the battery level
        private var BATTERY_UPDATE_INTERVAL : Long = TimeUnit.SECONDS.toMillis(5)

        // Keys for storing activity state in the Bundle.
        private const val KEY_REQUESTING_LOCATION_UPDATES = "requesting-location-updates"
        private const val KEY_LOCATION = "location"

        var customerId = 0L
        var orderOutletId = 0L
    }
}