package com.app.basketiodriver.ui.checkout.orderdetails

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Parcelable
import android.text.format.DateFormat
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.viewpager.widget.ViewPager.OnPageChangeListener
import com.app.basketiodriver.R
import com.app.basketiodriver.data.SupportMenuManager
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.chat.BaseResponse
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.checkout.OutletOrder
import com.app.basketiodriver.data.model.api.response.checkout.ShopperOrderDetail
import com.app.basketiodriver.data.model.api.response.checkout.ShopperOrderTimer
import com.app.basketiodriver.data.model.api.response.general.SimpleResponse
import com.app.basketiodriver.data.remote.socket.SocketManager
import com.app.basketiodriver.data.remote.socket.SystemMessage
import com.app.basketiodriver.data.remote.socket.SystemMessageReq
import com.app.basketiodriver.databinding.ActivityOrderDetailsBinding
import com.app.basketiodriver.di.Navigators
import com.app.basketiodriver.ui.base.BaseActivity
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.checkout.fragments.Done
import com.app.basketiodriver.ui.checkout.fragments.Pending
import com.app.basketiodriver.ui.checkout.fragments.ToDo
import com.app.basketiodriver.ui.checkout.fragments.ToDo1
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_ARRIVED_TO_CUSTOMER
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_ARRIVED_TO_SHOP
import com.app.basketiodriver.ui.dashbaord.OrdersManager.Companion.STATUS_SHOPPING
import com.app.basketiodriver.ui.dialogs.SwipeDialogFragment
import com.app.basketiodriver.ui.manager.ShopTimerManager
import com.app.basketiodriver.ui.manager.ShopTimerManager.TimerFinishListener
import com.app.basketiodriver.ui.utils.ViewPagerAdapter
import com.app.basketiodriver.utils.AppConstants
import com.app.basketiodriver.utils.MessageEvent
import com.app.basketiodriver.utils.SwipeManyStateButton.OnStateChangeListener
import com.app.basketiodriver.utils.order.OrderItemSingleton
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import io.socket.client.Ack
import io.socket.client.Socket
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import org.json.JSONObject
import timber.log.Timber
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import javax.inject.Inject


class OrderDetailsActivity : BaseActivity<ActivityOrderDetailsBinding, OrderDetailsViewModel>(),
    HasAndroidInjector {
    override val layoutId: Int
        get() = R.layout.activity_order_details

    override val viewModel: OrderDetailsViewModel
        get() {
            return getViewModel(OrderDetailsViewModel::class.java)
        }

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>
    override fun androidInjector() = dispatchingAndroidInjector

    @Inject
    lateinit var socketManager: SocketManager


    var orderId: Long = 0
    var orderStatus: Int = 0
    var isExpress: Int = 0

    var fastestRoute = "0"

    private lateinit var supportMenuManager: SupportMenuManager

    private lateinit var swipeDialog: SwipeDialogFragment

    // Order Item
    private var order: OutletOrder? = null

    // ViewPager Adapter
    private var adapter: ViewPagerAdapter? = null

    // Active page
    private var activePage: Int = 0

    // titles
    private var toDoTitle: String = ""
    private var pendingTitle: String = ""
    private var doneTitle: String = ""

    private var todo : Parcelable? = null
    private var todo1 : Parcelable? = null
    private var pending : Parcelable? = null
    private var done : Parcelable? = null

    private var isSlidedButton : Boolean = false

    // timer height
    private var orderTimerHeight = 50

    private var startTime : Long = 0

    // Timer
    private var timerHandler : Handler = Handler()
    private var timerRunnable: Runnable = object : Runnable {
        override fun run() {
            val millis: Long = System.currentTimeMillis() - startTime
            var seconds = (millis / 1000).toInt()
            val minutes = seconds / 60
            seconds %= 60

            val dateFormat = SimpleDateFormat("hh:mm:ss", Locale.ENGLISH)
            val timeString = dateFormat.format(Date(millis))

            viewDataBinding?.tvTimer?.text = timeString // String.format(Locale.ENGLISH, "%02d:%02d", minutes, seconds)
            timerHandler.postDelayed(this, 500)
        }
    }

    // Limit count to replace the items
    var replaceLimitCount = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (savedInstanceState != null){
            //  Restore the scroll data
            restoreScrollData(savedInstanceState)
        }

        // Register EventBus
//        EventBus.getDefault().register(this)

        // Initialize the Toolbar
        initToolbar(getString(R.string.nav_orders),
            true, viewDataBinding!!.layoutToolBar.toolbar,
            View.OnClickListener {
                run {
                    onBackPressed()
                }
            })

        // get order id
        orderId = intent.getLongExtra("KEY_ORDER_OUTLET_ID", 0)

        // get order status
        if (intent.hasExtra("KEY_ORDER_STATUS"))
            orderStatus = intent.getIntExtra("KEY_ORDER_STATUS", 0)

        initView()
    }

    override fun onDestroy() {
        super.onDestroy()

        isSlidedButton = false
//        EventBus.getDefault().unregister(this)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    override fun onMessageEvent(event: MessageEvent) {
        super.onMessageEvent(event)

        if (event.message == AppConstants.MESSAGE_ITEM_REFUNDED) {
            // Get shopper orders
            queryShopperOrders()
        }
    }

    override fun onBackPressed() {
//        super.onBackPressed()

        // Go to Dashboard
        Navigators.goToDashboard(this)
    }

    override fun onResume() {
        super.onResume()

        // Get orders
        queryShopperOrders()
    }

    override fun onSaveInstanceState(savedInstanceState: Bundle) {
        // Get the current active tab and save it
        if (viewDataBinding != null && viewDataBinding?.viewpager != null) {
            activePage = viewDataBinding?.viewpager!!.currentItem
            savedInstanceState.putInt(KEY_ACTIVE_PAGE, activePage)
        }

        if (viewDataBinding != null && adapter != null){
            if (adapter!!.getItem(0) is ToDo) {
                if (order != null && order!!.todoItemsCount != 0)
                    viewDataBinding?.rlSortTitle?.visibility = View.VISIBLE
                else
                    viewDataBinding?.rlSortTitle?.visibility = View.GONE

                todo = (adapter!!.getItem(0) as ToDo).getSaved()
                savedInstanceState.putParcelable(KEY_SAVED_TODO, todo)

                position = (adapter!!.getItem(0) as ToDo).getScroll()
                savedInstanceState.putIntArray(KEY_SAVED_SCROLL, position)
            }

            if (adapter!!.getItem(0) is ToDo1) {
                if (order != null && order!!.todoItemsCount != 0)
                    viewDataBinding?.rlSortTitle?.visibility = View.VISIBLE
                else
                    viewDataBinding?.rlSortTitle?.visibility = View.GONE

                todo1 = (adapter!!.getItem(0) as ToDo1).getSaved()
                savedInstanceState.putParcelable(KEY_SAVED_TODO1, todo1)

                position = (adapter!!.getItem(0) as ToDo1).getScroll()
                savedInstanceState.putIntArray(KEY_SAVED_SCROLL, position)
            }

            if (adapter!!.getItem(1) is Pending) {
                viewDataBinding?.rlSortTitle?.visibility = View.VISIBLE

                pending = (adapter!!.getItem(1) as Pending).getSaved()
                savedInstanceState.putParcelable(KEY_SAVED_PENDING, pending)
            }

            if (adapter!!.getItem(2) is Done) {
                viewDataBinding?.rlSortTitle?.visibility = View.GONE

                done = (adapter!!.getItem(2) as Done).getSaved()
                savedInstanceState.putParcelable(KEY_SAVED_DONE, done)
            }
        }

        super.onSaveInstanceState(savedInstanceState)

    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        activePage = savedInstanceState.getInt(KEY_ACTIVE_PAGE, 0)

        super.onRestoreInstanceState(savedInstanceState)
    }

    // Restore the saved instance
    private fun restoreScrollData(savedInstanceState: Bundle){
        position = savedInstanceState.getIntArray(KEY_SAVED_SCROLL) ?: intArrayOf()
        todo = savedInstanceState.getParcelable(KEY_SAVED_TODO)
        todo1 = savedInstanceState.getParcelable(KEY_SAVED_TODO1)
        pending = savedInstanceState.getParcelable(KEY_SAVED_PENDING)
        done = savedInstanceState.getParcelable(KEY_SAVED_DONE)
    }

    fun getTodo(): Parcelable? {
        return todo
    }

    fun getTodo1(): Parcelable? {
        return todo1
    }

    fun getPending(): Parcelable? {
        return pending
    }

    fun getDone(): Parcelable? {
        return done
    }

    private fun initView() {
        // Support Menu
        initSupportMenu()

        // Set the Uppercase texts
        viewDataBinding!!.tvTimerTitle.isAllCaps = true
        viewDataBinding!!.tvGoalTitle.isAllCaps = true

        viewDataBinding!!.viewpager.clipToPadding = false

        // Swipe Dialog
        initSwipeDialog()

        // Init Switch
        initSwitch()

        // Init ViewPager
        initViewPager()

        /**
         * Connect to socket and create the room
         */
        if (orderStatus == STATUS_ARRIVED_TO_SHOP) { // STATUS_ARRIVED_TO_SHOP
            Timber.tag(TAG_CHAT_ROOM).e("*** Order Status : STATUS_ARRIVED_TO_SHOP ***")
            initSocketEvent()
        }
//        else {
//            Timber.tag(TAG_CHAT_ROOM).e("*** Order status is not STATUS_ARRIVED_TO_SHOP ***")
//            if (socketManager.chatSocket != null) {
//                socketManager.chatSocket!!.run {
//                    Timber.tag(TAG_CHAT_ROOM).e("*** Connecting to chat socket ***")
//                    on(Socket.EVENT_CONNECT) {
//                        Timber.tag(TAG_CHAT_ROOM).e("*** Connected to chat socket ***")
//                    }
//                }
//            }
//        }

        // Chat Action
//        viewDataBinding!!.chatFloatingButton.setOnClickListener {
//            openChatActivity()
//        }
    }

    private fun initSocketEvent() {
        Timber.tag(TAG_CHAT_ROOM).e("*** Init Socket Event ***")
        if (socketManager.chatSocket != null && socketManager.chatSocket!!.connected()) {
            // Create the chat room
            createRoom()

            // Join into room
            joinRoom()

            // Open the room
            openRoom()
        }
        else{
            Timber.tag(TAG_CHAT_ROOM).e("*** Chat socket is not connected ***")

            if (socketManager.chatSocket != null){
                socketManager.chatSocket!!.run {
                    Timber.tag(TAG_CHAT_ROOM).e("*** Connecting to chat socket ***")

                    on(Socket.EVENT_CONNECT) {
                        Timber.tag(TAG_CHAT_ROOM).e("*** Connected to chat socket ***")

                        try{
                            Handler(Looper.getMainLooper()).post {
                                // Create the chat room
                                createRoom()

                                // Join into room
                                joinRoom()
                            }
                        }
                        catch (e : Exception){
                            e.printStackTrace()
                        }
                    }
                }
            }
        }
    }

    /**
     * Join into chat room
     */
    @SuppressLint("TimberArgCount")
    private fun joinRoom() {
        Timber.tag(TAG_CHAT_ROOM).d("*** Chat : JoinRoom ***")
        socketManager.chatSocket?.emit(
            SocketManager.CHAT_EVENT_JOIN_ROOM,
            JSONObject().apply {
                put(SocketManager.CHAT_KEY_ROOM_ID, orderId.toString())
            },
            Ack {
                val baseResponseType = object : TypeToken<BaseResponse>() {}.type
                val response = Gson().fromJson<BaseResponse>(it.first() as String, baseResponseType)

                val callbackMsg = String.format(Locale.ENGLISH, "*** chat:room:join : %s ***", response.message ?: "")
                Timber.tag(TAG_CHAT_ROOM).e(callbackMsg)
            }
        )
    }

    /**
     * Create the chat room
     */
    @SuppressLint("TimberArgCount")
    private fun createRoom() {
        Timber.tag(TAG_CHAT_ROOM).d("*** Chat : CreateRoom ***")
        socketManager.chatSocket?.emit(
            SocketManager.CHAT_EVENT_CREATE_ROOM,
            JSONObject().apply {
                put(SocketManager.CHAT_KEY_ROOM_ID, orderId.toString())
            },

            Ack {
                val baseResponseType = object : TypeToken<BaseResponse>() {}.type
                val response = Gson().fromJson<BaseResponse>(it.first() as String, baseResponseType)

                val callbackMsg = String.format(Locale.ENGLISH, "*** chat:room:create : %s ***", response.message ?: "")
                Timber.tag(TAG_CHAT_ROOM).e(callbackMsg)
            }
        )
    }

    /**
     * Open the chat room
     */
    @SuppressLint("TimberArgCount")
    private fun openRoom(){
        Timber.tag(TAG_CHAT_ROOM).d("*** Chat : OpenRoom ***")
        socketManager.chatSocket?.emit(
            SocketManager.CHAT_EVENT_OPEN_ROOM,
            JSONObject().apply {
                put(SocketManager.CHAT_KEY_ROOM_ID, orderId.toString())
            },

            Ack {
                val baseResponseType = object : TypeToken<BaseResponse>() {}.type
                val response = Gson().fromJson<BaseResponse>(it.first() as String, baseResponseType)

                val callbackMsg = String.format(Locale.ENGLISH, "*** chat:room:open : %s ***", response.message ?: "")
                Timber.tag(TAG_CHAT_ROOM).e(callbackMsg)
            }
        )
    }

    private fun initSupportMenu() {
        val support = viewDataBinding!!.layoutToolBar.support
        supportMenuManager = SupportMenuManager(support)

        support.setOnClickListener {
            supportMenuManager.showSupportMenu()
        }
    }

    private fun initSwipeDialog() {
        swipeDialog = SwipeDialogFragment()
        swipeDialog.setStateChangeListener(OnStateChangeListener { state: Int? -> })
    }

    private fun initSwitch() {
        viewDataBinding!!.switchSort.setOnCheckedChangeListener { button, selected ->
            if (selected) {
                fastestRoute = "1"
                queryShopperOrders()

                // update the switch text color
            } else {
                fastestRoute = "0"
                queryShopperOrders()

                // update the switch text color
            }
        }
    }

    private fun initViewPager() {
        viewDataBinding!!.viewpager.addOnPageChangeListener(object : OnPageChangeListener {
            override fun onPageScrolled(i: Int, v: Float, i1: Int) {
                if (i > 0) {
                    viewDataBinding!!.rlSortTitle.visibility = View.GONE
                } else {
                    if (order != null && order!!.todoItemsCount != 0 && !fastestRoute.equals("0"))
                        viewDataBinding!!.rlSortTitle.visibility = View.VISIBLE
                    else
                        viewDataBinding!!.rlSortTitle.visibility = View.GONE
                }
            }

            override fun onPageSelected(i: Int) {}
            override fun onPageScrollStateChanged(i: Int) {}
        })
    }

    fun updateViewpagerPadding(){

        val scale = resources.displayMetrics.density
        val paddingTop = (orderTimerHeight * scale + 0.5f).toInt()
        viewDataBinding!!.viewpager.setPadding(0, paddingTop, 0, 0)
    }

    // Init Timer
    private fun initTimer() {
        // Hide the Swipe button
        viewDataBinding!!.llBottomBar.visibility = View.GONE

        val timerFinishListener = TimerFinishListener {
//            viewDataBinding!!.timerBar.setBackgroundResource(R.color.colorTimerFinished)
        }

        // Call api to get order timer
        viewModel.getOrderTimer(orderId, object : HandleResponse<ShopperOrderTimer> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Toast.makeText(this@OrderDetailsActivity, error?.message, Toast.LENGTH_SHORT).show()
                }else{
                    Toast.makeText(this@OrderDetailsActivity, resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }
            }

            override fun handleSuccessResponse(successResponse: ShopperOrderTimer) {
                val response = successResponse.response
                if (response != null) {
                    if (response.httpCode == 200) {
                        startTime = response.timerNow!!

                        Timber.e("Shopping Start Time : %s", startTime)
                        val goalTime: Long = response.shoppingGoal!!
                        val orderTimeMillis = convertToTimeString(goalTime)

                        viewDataBinding!!.goal.text = orderTimeMillis
//                        ShopTimerManager(timerFinishListener, viewDataBinding!!.chronometer).init(
//                            timerNow,
//                            goalTime
//                        )

                        startShoppingTimer(startTime, goalTime)

                        updateViewpagerPadding()
                    }
                    else {
                        Toast.makeText(
                            this@OrderDetailsActivity,
                            response.message,
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    Toast.makeText(
                        this@OrderDetailsActivity,
                        getString(R.string.error_timer_request),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        })
    }

    /**
     * Start the shopping timer
     */
    private fun startShoppingTimer(startTime : Long, goalTime : Long){
        try {
            timerHandler.postDelayed(timerRunnable, 0)
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    private fun convertToTimeString(millis: Long): CharSequence {
        val dateFormat = SimpleDateFormat("mm:ss", Locale.ENGLISH)
        val startDate = Date(millis)
        return dateFormat.format(startDate)
//        return DateFormat.format("mm:ss", millis)
    }

    private fun showActions(): Boolean {
        val action = intent.action
        return if (action != null) {
            showSwipe()
            viewDataBinding!!.llHeader.isClickable = false
            false
        } else {
            // Show(1) and hind(0) the Timer Bar
            if(order?.isExpress == 1){
                viewDataBinding!!.timerBar.visibility = View.VISIBLE
                initTimer()
            }else{
                viewDataBinding!!.timerBar.visibility = View.GONE
            }

            viewDataBinding!!.llHeader.isClickable = true
            true
        }
    }

    // Show the swipe
    private fun showSwipe() {
        // Hide the Timer Bar
//        viewDataBinding!!.viewpager.setPadding(0, 0, 0, 0)
        viewDataBinding!!.timerBar.visibility = View.GONE

        // Show the Swipe button
        viewDataBinding!!.llBottomBar.visibility = View.VISIBLE
        viewDataBinding!!.swipeButton.state = orderStatus // intent.getIntExtra("KEY_ORDER_STATUS", 0)
        viewDataBinding!!.swipeButton.setOnStateChangeListener { state ->

            if (isSlidedButton) {
                // Go to previous state
                viewDataBinding!!.swipeButton.previousState()
                return@setOnStateChangeListener
            }

            orderStatus = state

            // update the order status
            if (orderId != 0L) {

                isSlidedButton = true
                viewModel.updateOrderStatus(
                    state,
                    orderId,
                    object : HandleResponse<SimpleResponse> {
                        override fun handleErrorResponse(error: ErrorResponse?) {
                            if (isNetworkConnected){
                                Toast.makeText(this@OrderDetailsActivity, error?.message, Toast.LENGTH_SHORT).show()
                            }else{
                                Toast.makeText(this@OrderDetailsActivity, resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                            }

                            // Go to previous state
                            viewDataBinding!!.swipeButton.previousState()
                            isSlidedButton = false
                        }

                        override fun handleSuccessResponse(successResponse: SimpleResponse) {
                            val response = successResponse.response
                            if (response != null) {
                                if (response.httpCode == 200) {

                                    var chatOption : Boolean = true
                                    var numberOption: Boolean = true
//                                    if (state <= STATUS_ARRIVED_TO_CUSTOMER && state >= STATUS_SHOPPING) {
//                                        numberOption = order!!.todoItemsCount == 0
//                                    }
//                                    else {
//                                        chatOption = false
//                                        numberOption = false
//                                    }

                                    // Hide the chat option for Express store
                                    if (order!!.isExpress == 1)
                                        chatOption = false

                                    // Menu Option
                                    supportMenuManager.initConsumerNumber(
                                        order!!.callBeforeCheckout,
                                        true,
                                        order!!.userMobile,
                                        chatOption,
                                        numberOption
                                    )

                                    // Send message
                                    val message =
                                        AppConstants.MESSAGE_TYPE_SHOPPING_STARTED + " " + PreferenceManager.currentShopperFirstName + " " + resources.getString(
                                            R.string.started_shopping
                                        )
                                    val systemMessageReq =
                                        SystemMessageReq(orderId.toString(), "text", message!!)
                                    sendSystemMessage(systemMessageReq)

                                    // Refresh this page
//                                    refreshPage()
                                } else {
                                    Toast.makeText(
                                        this@OrderDetailsActivity,
                                        response.message,
                                        Toast.LENGTH_SHORT
                                    ).show()

                                    // Go to previous state
                                    viewDataBinding!!.swipeButton.previousState()
                                    isSlidedButton = false
                                }
                            } else {
                                Toast.makeText(
                                    this@OrderDetailsActivity,
                                    getString(R.string.error_update_status),
                                    Toast.LENGTH_SHORT
                                ).show()

                                // Go to previous state
                                viewDataBinding!!.swipeButton.previousState()
                                isSlidedButton = false

                            }
                        }
                    })
            }
        }
    }

    fun sendSystemMessage(systemMessageReq: SystemMessageReq) {
        viewModel.sendSystemMessage(systemMessageReq, object : HandleResponse<SystemMessage> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                refreshPage()
                isSlidedButton = false
            }

            override fun handleSuccessResponse(successResponse: SystemMessage) {
                refreshPage()
                isSlidedButton = false
            }
        })
    }

    // Refresh current page
    fun refreshPage() {
        try {
            if (socketManager.chatSocket != null){
                socketManager.chatSocket!!.run {
                    Timber.tag(TAG_CHAT_ROOM).e("*** Removing the callback of chat socket ***")
                    off(Socket.EVENT_CONNECT) {
                        Timber.tag(TAG_CHAT_ROOM).e("*** Removed the callback of chat socket ***")
                    }
                }
            }

            // reload pages
            finish()
            Navigators.goToOrderDetails(this, orderId)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Confirm the replaced item
     */
    fun confirmReplaceItem(itemId : Long, qty : Double){
        try{
            viewModel.confirmReplacedItem(itemId, qty, object : HandleResponse<SimpleResponse>{
                override fun handleErrorResponse(error: ErrorResponse?) {
                    Toast.makeText(this@OrderDetailsActivity, error?.message, Toast.LENGTH_SHORT).show()
                }

                override fun handleSuccessResponse(successResponse: SimpleResponse) {
                    val response = successResponse.response
                    if (response != null){
                        Toast.makeText(this@OrderDetailsActivity, response.message, Toast.LENGTH_SHORT).show()

                        queryShopperOrders()
                    }
                    else{
                        Toast.makeText(this@OrderDetailsActivity, getString(R.string.error_server_return_null), Toast.LENGTH_SHORT).show()
                    }
                }
            })
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    // Setup ViewPager
    private fun setupViewPager() {
        try{
            adapter = ViewPagerAdapter(supportFragmentManager)

            val bundle = Bundle()
            bundle.putSerializable(KEY_LIST_ORDER, order)
            bundle.putBoolean(KEY_CLICKABLE, showActions())

            // set fragments to adapter
//            val pendingFragment = Pending()
            if (fastestRoute == "1") {
                adapter!!.setFragments(bundle, ToDo(), Pending(), Done())
            } else {
                adapter!!.setFragments(bundle, ToDo1(), Pending(), Done())
            }

            // set title
            setPageTitles(order!!, adapter!!)
            viewDataBinding!!.viewpager.adapter = adapter
            viewDataBinding!!.viewpager.currentItem = activePage

            // Setup the view pager to TabLayout
            viewDataBinding!!.tablayout.setupWithViewPager(viewDataBinding!!.viewpager)

            // update the viewpager padding
//            updateViewpagerPadding()
        }
        catch (e : Exception){
            e.printStackTrace()
        }
    }

    // Set TabLayout Titles
    private fun setPageTitles(order: OutletOrder, adapter: ViewPagerAdapter) {
        toDoTitle = String.format(Locale.ENGLISH, "(%s) %s", order.todoOrdersItems.size.toString(), getString(R.string.frag_todo))
        pendingTitle = String.format(Locale.ENGLISH, "(%s) %s", order.pendingOrdersItems.size.toString(), getString(R.string.frag_pending))
        doneTitle = String.format(Locale.ENGLISH, "(%s) %s", order.doneOrdersItems.size.toString(), getString(R.string.frag_done))

        adapter.setTitles(toDoTitle, pendingTitle, doneTitle)
    }

    private fun updateToolbarTitle(title: String) {
        initToolbar(title,
            true, viewDataBinding!!.layoutToolBar.toolbar,
            View.OnClickListener {
                run {
                    finish()
                }
            })
    }

    // Get orders
    fun queryShopperOrders() {
        Log.d("TAG", "queryShopperOrders: ")
        activePage = viewDataBinding!!.viewpager.currentItem

        // Save the current order id to singleton class
        OrderItemSingleton.currentOrderId = orderId

        viewModel.shopperOrderDetailRequest(
            orderId.toString(),
            fastestRoute,
            object : HandleResponse<ShopperOrderDetail> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                  //  viewDataBinding!!.refreshLayout.isRefreshing = false
                    EventBus.getDefault().post(MessageEvent(AppConstants.ORDER_LOAD_FINISHED))

                    if (isNetworkConnected){
                        Toast.makeText(this@OrderDetailsActivity, error?.message, Toast.LENGTH_SHORT).show()
                    }else{
                        Toast.makeText(this@OrderDetailsActivity, resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                    }
                }

                override fun handleSuccessResponse(successResponse: ShopperOrderDetail) {
               //     viewDataBinding!!.refreshLayout.isRefreshing = false
                    EventBus.getDefault().post(MessageEvent(AppConstants.ORDER_LOAD_FINISHED))
                    val response = successResponse.response
                    if (response != null) {
                        if (response.httpCode == 200) {
                            replaceLimitCount = response.replaceLimitCount
                            OrderItemSingleton.setReplacementLimit(response.replaceLimitCount)

                            processOrder(response.outletOrder!!)
                        }
                        else {
                            Toast.makeText(this@OrderDetailsActivity, response.message, Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Toast.makeText(this@OrderDetailsActivity, getString(R.string.error_load_shopper_detail), Toast.LENGTH_SHORT).show()
                    }
                }
            })
    }

    private fun processOrder(response: OutletOrder) {
        order = response


//        viewDataBinding!!.chatFloatingButton.visibility = View.VISIBLE

        // Save the outlet order id
        AppConstants.outletId = response.outletId!!
        response.outletId = orderId

        // Set the title
        updateToolbarTitle(String.format(Locale("en"), getString(R.string.order_name_format_text), response.userFirstName))

        // Hide the chat option if it's express store
        val showChatOption : Boolean = response.isExpress == 0

        // Set support menu items
        if (orderStatus == STATUS_ARRIVED_TO_SHOP) // STATUS_ARRIVED_TO_SHOP
            supportMenuManager.initConsumerNumber(
                response.callBeforeCheckout,
                true,
                response.userMobile,
                false,
                false
            )
//        else if (orderStatus > STATUS_ARRIVED_TO_SHOP && orderStatus <= STATUS_ARRIVED_TO_CUSTOMER && (order!!.todoItemsCount == 0))
//            supportMenuManager.initConsumerNumber(
//                response.callBeforeCheckout,
//                true,
//                response.userMobile,
//                showChatOption,
//                true
//            )
        else {
            val showCallOption = if (order!!.todoItemsCount == 0 && (order!!.pendingItemsCount > 0 || order!!.doneItemsCount > 0)) true else false
            supportMenuManager.initConsumerNumber(
                response.callBeforeCheckout,
                true,
                response.userMobile,
                showChatOption,
                true
            )
        }

        // Save the customer info
        PreferenceManager.setCustomerId(orderId.toString(), response.userId ?: "0")
        PreferenceManager.setCustomerName(orderId.toString(), response.userFirstName ?: "")
        PreferenceManager.setCustomerImage(orderId.toString(), response.userImage)

        if (response.isSortingEnable == 0) {
            viewDataBinding!!.rlSortTitle.visibility = View.GONE
            fastestRoute = "0"
        } else {
            viewDataBinding!!.rlSortTitle.visibility = View.VISIBLE
            fastestRoute = "1"
        }

        // Setup ViewPager
        setupViewPager()
    }

    // Go to Chat page
    fun openChatActivity() {
        // Go to Chat page
        Navigators.gotoChatActivity(
            this,
            orderId,
            order?.userId!!,
            order?.userFirstName ?: "",
            order?.userImage ?: ""
        )
    }


    // ActivityResult
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQ_DETAIL_PAGE) {
            if (resultCode == RESULT_OK) {
                Toast.makeText(this, R.string.replaced_customer_notified, Toast.LENGTH_SHORT).show()
            }

            if (resultCode == 7) { // Mark as found
                Toast.makeText(this, R.string.found_ex, Toast.LENGTH_SHORT).show()
            }

            if (resultCode == 8) { // Refunded
                Toast.makeText(this, R.string.refunded_customer_notified, Toast.LENGTH_SHORT).show()
            }
        }
    }

    companion object {
        const val KEY_LIST_ORDER = "key_list_order"
        const val KEY_CLICKABLE = "key_is_clickable"
        const val REQ_DETAIL_PAGE = 8

        const val KEY_SAVED_TODO = "saved_todo"
        const val KEY_SAVED_TODO1 = "saved_todo1"
        const val KEY_SAVED_PENDING = "saved_pending"
        const val KEY_SAVED_DONE = "saved_done"
        const val KEY_SAVED_SCROLL = "saved_scroll"

        const val KEY_ACTIVE_PAGE = "active_page"

        const val TAG_CHAT_ROOM = "ChatRoom"

        // Scroll position
        var position: IntArray = intArrayOf()
    }
}