package com.app.basketiodriver.ui.checkout.adapter

import android.annotation.SuppressLint
import android.util.Log
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.app.basketiodriver.R
import com.app.basketiodriver.databinding.ItemPhotoListBinding
import com.app.basketiodriver.utils.BaseRecyclerViewAdapter
import com.app.basketiodriver.utils.GlideApp
import java.io.File

class PhotoAdapter (val activity : FragmentActivity, var photoItems : List<String>) : BaseRecyclerViewAdapter<String, ItemPhotoListBinding>() {
    override val layoutId: Int
        get() = R.layout.item_photo_list

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return PhotoViewHolder(createBindView(parent))
    }

    var listener : AddImageClickListener? = null

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val holder = holder as PhotoViewHolder
        val item = photoItems[position]

        if (item.equals("upload_image", true)){
            holder.binding.imgAdd.visibility = View.VISIBLE
            holder.binding.photoView.visibility = View.GONE
        }
        else{
            holder.binding.imgAdd.visibility = View.GONE
            holder.binding.photoView.visibility = View.VISIBLE
        }

        // Set the corner radius
        try {
            holder.binding.imgTakenPic.clipToOutline = true
        }
        catch (e : Exception){
            e.printStackTrace()
        }

        // Display image
        GlideApp.with(activity).load(File(item))
            .placeholder(R.drawable.placeholder)
            .error(R.drawable.placeholder).into(holder.binding.imgTakenPic)

        holder.binding.imgAdd.setOnClickListener {
            listener?.onClickAddImage()
        }

        // Remove the capture photo
        holder.binding.ivRemovePhoto.setOnClickListener {
            listener?.onClickRemovePhoto(item)
        }
    }

    override fun getItemCount(): Int {
        return photoItems.size
    }

    @SuppressLint("NotifyDataSetChanged")
    fun setPhotos(photos: List<String>){
        this.photoItems = photos
        notifyDataSetChanged()
    }

    interface AddImageClickListener {
        fun onClickAddImage()
        fun onClickRemovePhoto(photoUrl : String)
    }

    inner class PhotoViewHolder(val binding: ItemPhotoListBinding) :
        RecyclerView.ViewHolder(binding.root)
}