package com.app.basketiodriver.data.model.api.response.Base

import com.google.gson.annotations.SerializedName


/**
Created by ibraheem lubbad on 2020-01-16.
Copyright (c) 2020 Basket.jo. All rights reserved.
 **/
open class BaseResponse {



    @field:SerializedName("message")
    var message: String? = null
    override fun toString(): String {
        return "BaseResponse(message=$message)"
    }


}
