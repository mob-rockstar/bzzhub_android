package com.app.basketiodriver.ui.checkout.adapter

import android.annotation.SuppressLint
import android.os.Build
import android.text.Html
import android.text.Spanned
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.widget.PopupMenu
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.app.basketiodriver.R
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.checkout.CustomerInfo
import com.app.basketiodriver.data.model.api.response.checkout.OrdersItem
import com.app.basketiodriver.data.model.api.response.general.SimpleResponse
import com.app.basketiodriver.databinding.ItemListOrderDetailBinding
import com.app.basketiodriver.di.Navigators
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.checkout.orderdetails.OrderDetailsActivity
import com.app.basketiodriver.ui.dialogs.FlagItemDialogFragment
import com.app.basketiodriver.ui.dialogs.RefundDialogFragment
import com.app.basketiodriver.ui.dialogs.SelectReplacementDialogFragment
import com.app.basketiodriver.ui.order.review.ReviewChangesLatestActivity
import com.app.basketiodriver.utils.AppConstants.FROM_TODO
import com.app.basketiodriver.utils.BaseRecyclerViewAdapter
import com.app.basketiodriver.utils.GlideApp
import com.app.basketiodriver.utils.price.PriceConstructor
import com.app.basketiodriver.utils.price.PriceConstructorNew
//import kotlinx.android.synthetic.main.item_product_new.view.*
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.*


class OrderDetailItemAdapter(val activity : FragmentActivity, var listItem : List<OrdersItem>, val userMobile : String, val orderId : Long, val info : CustomerInfo, val isClick : Boolean, val dots:Boolean, val isExpress : Int) : BaseRecyclerViewAdapter<OrdersItem, ItemListOrderDetailBinding>(){

    var symbols: DecimalFormatSymbols = DecimalFormatSymbols(Locale.US)
    var formatter: DecimalFormat = DecimalFormat("#.## x ", symbols)
    var formatter2: DecimalFormat = DecimalFormat("#.##", symbols)

    override val layoutId: Int
        get() = R.layout.item_list_order_detail

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return OrderDetailItemViewHolder(createBindView(parent))
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val holder = holder as OrderDetailItemViewHolder
        val item = listItem[position]
        Log.d("TAG", "customerItemNotes: "+item.customerItemNotes)

        // Price
        val price = PriceConstructorNew.getFormatPrice(item, PriceConstructor.LabelType.SIMPLE, true)

        if (item.customerItemNotes != null && item.customerItemNotes!!.isNotEmpty()){
            holder.binding.layoutNewProduct.ivInfo.visibility = View.VISIBLE
        }
        else{
            holder.binding.layoutNewProduct.ivInfo.visibility = View.GONE
        }

        // Product Name and Quantity
        holder.binding.layoutNewProduct.orderItemQuantity.visibility = View.VISIBLE

        if (item.quantityDifference == 1){
            holder.binding.layoutNewProduct.txtTitle.text = String.format(Locale("en"), "%s %s", item.productName, item.aisleName).replace("\n", "").replace("\r", "")
            holder.binding.layoutNewProduct.orderItemQuantity.text = formatter.format(item.actualQty)
        }
        else if (item.replacementRequested != null && item.replacementRequested == 1){
            if (item.itemStatus == 2) {
                holder.binding.layoutNewProduct.txtTitle.text = item.productName!!.replace("\n", "").replace("\r", "")
            }
            else{
                holder.binding.layoutNewProduct.txtTitle.text = item.productName!!.replace("\n", "").replace("\r", "")
                holder.binding.layoutNewProduct.orderItemQuantity.text = formatter.format(item.actualQty)
            }
        }
        else{
            holder.binding.layoutNewProduct.txtTitle.text = item.productName!!.replace("\n", "").replace("\r", "")
            if (item.soldPer == 2) {
                holder.binding.layoutNewProduct.orderItemQuantity.text = formatter2.format(item.itemQty ?: 1) + " kg x "
            }
            else{
                holder.binding.layoutNewProduct.orderItemQuantity.text = formatter.format(item.itemQty ?: 1)
            }
        }

        holder.binding.layoutNewProduct.txtPricePerUnit.text = getHtmlString(price)

        // Product description
        if (item.getDescriptionLabel().isEmpty()){
            holder.binding.layoutNewProduct.tvPriceDescription.visibility = View.GONE
        }
        else{
            holder.binding.layoutNewProduct.tvPriceDescription.visibility = View.VISIBLE
            holder.binding.layoutNewProduct.tvPriceDescription.text = item.getDescriptionLabel()
        }

        // Product Image
        if (item.productImage != null) {
            GlideApp.with(activity).load(item.productImage).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(holder.binding.layoutNewProduct.orderItemImage)
        }

        // Status
        val status = setItemStatusLabel(holder, item)

        if (isClick) {
            holder.binding.layoutNewProduct.rlProduct.setOnClickListener {
                holder.binding.layoutNewProduct.rlProduct.isClickable = false

                // Go to item detail
                Navigators.goToItemDetailsActivity(activity, item, userMobile, info, orderId, isExpress)

                holder.binding.layoutNewProduct.rlProduct.isClickable = true
            }
        }

        if (orderId != 0L){
            initThreeDotIfNeed(holder, position, status)
        }

        // Original Product
        setOriginalView(holder, item)
    }

    override fun getItemCount(): Int {
        return listItem.size
    }

    private fun setOriginalView(holder : OrderDetailItemViewHolder, item : OrdersItem) {
        if (item.replacementRequested != null && item.replacementRequested == 1){
            holder.binding.originalProduct.visibility = View.VISIBLE

            // product image
            if (item.oldProductImage != null) {
                GlideApp.with(activity).load(item.oldProductImage).fitCenter()
                    .placeholder(R.drawable.placeholder)
                    .error(R.drawable.placeholder).into(holder.binding.ivOriginalProductImg)
            }

            // Quantity
            holder.binding.tQuantity.text = formatter.format(item.itemQty ?: 0.0)

            // Product name
            holder.binding.tOriginalProductName.text = (item.oldProductName ?: "").replace("\n", "").replace("\r", "")

            // Price
            val price = PriceConstructorNew.getFormatPrice(item, PriceConstructor.LabelType.SIMPLE, false)
            holder.binding.tvOriginalPrice.text = getHtmlString(price)

            // Product Description
            if (item.getDescriptionLabel().isEmpty()){
                holder.binding.tvOriginalPriceDescription.visibility = View.GONE
            }
            else{
                holder.binding.tvOriginalPriceDescription.text = item.getDescriptionLabel()
                holder.binding.tvOriginalPriceDescription.visibility = View.VISIBLE
            }
        }
        else{
            holder.binding.originalProduct.visibility = View.GONE
        }
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    private fun setItemStatusLabel(holder : OrderDetailItemViewHolder, item : OrdersItem) : Int{
        holder.binding.layoutNewProduct.orderItemImage.alpha = 1f
        if (item.itemShoppingStatus == 1) {
            holder.binding.itemStatus.visibility = View.GONE
//            holder.binding.borderView.visibility = View.GONE

            return 0
        }
        else if (item.itemShoppingStatus == 2){
            holder.binding.itemStatus.visibility = View.VISIBLE
//            holder.binding.borderView.visibility = View.VISIBLE

            if (item.replacementRequested != null && item.replacementRequested == 1){
                holder.binding.itemStatus.text = activity.getString(R.string.replaced)
                return 5
            }

            if (item.quantityDifference == 1){
                holder.binding.itemStatus.text = getHtmlString("<font>" + activity.getString(R.string.qty_diff) + formatter.format(item.itemQty ?: 0))
                return 3
            }

            holder.binding.itemStatus.setText(R.string.not_found)
            return 2
        }
        else{
            holder.binding.itemStatus.visibility = View.VISIBLE
//            holder.binding.borderView.visibility = View.VISIBLE

            if (item.replacementRequested != null && item.replacementRequested == 1 && item.replacementFullfilled != null && item.replacementFullfilled == 1){
                holder.binding.itemStatus.setText(R.string.replaced)
//                holder.binding.borderView.setBackgroundColor(holder.binding.borderView.context.resources.getColor(R.color.colorItemDifferent))
                holder.binding.itemStatus.setCompoundDrawablesWithIntrinsicBounds(holder.binding.itemStatus.context.getDrawable(R.drawable.ic_replaced), null, null, null)
                holder.binding.txtReplacewithstatus.visibility = View.VISIBLE

                return 9
            }
            else if (item.returnItem != null && item.returnItem == 1){
                holder.binding.itemStatus.setText(R.string.refund)
//                holder.binding.borderView.setBackgroundColor(holder.binding.borderView.context.resources.getColor(R.color.textColor2))
                holder.binding.itemStatus.setCompoundDrawablesWithIntrinsicBounds(holder.binding.itemStatus.context.getDrawable(R.drawable.ic_refunded), null, null, null)
                holder.binding.txtReplacewithstatus.visibility = View.GONE

                return 9
            }
            else if (item.quantityDifference == 1) {
                holder.binding.itemStatus.text = getHtmlString("<font>" + activity.getString(R.string.qty_diff) + formatter.format(item.itemQty ?: 0))
//                holder.binding.borderView.setBackgroundColor(holder.binding.borderView.context.resources.getColor(R.color.textColor2))
                holder.binding.itemStatus.setCompoundDrawablesWithIntrinsicBounds(holder.binding.itemStatus.context.getDrawable(R.drawable.ic_refunded), null, null, null)
                holder.binding.txtReplacewithstatus.visibility = View.GONE

                return 9
            }
            else {
                holder.binding.itemStatus.setText(R.string.done)
//                holder.binding.borderView.setBackgroundColor(holder.binding.borderView.context.resources.getColor(R.color.primary_basket_green))
                holder.binding.itemStatus.setCompoundDrawablesWithIntrinsicBounds(holder.binding.itemStatus.context.getDrawable(R.drawable.ic_item_done), null, null, null)
                holder.binding.txtReplacewithstatus.visibility = View.GONE

                return 9
            }
        }
    }

    // Init more popup menu
    private fun initThreeDotIfNeed(holder : OrderDetailItemViewHolder, position: Int, status : Int){
        val menuId = getMenuId(status)
        if (menuId > 0) {
            initPopupMenu(holder, position, menuId)

//            holder.binding.frameLayout2.three_dot.visibility = View.GONE
//            holder.binding.frameLayout2.three_dot.setOnClickListener {
//                holder.popupMenu?.show()
//            }
        }
        else{
//            val params : ViewGroup.LayoutParams = holder.binding.frameLayout2.three_dot.layoutParams
//            params.width = 1
//            holder.binding.frameLayout2.three_dot.layoutParams = params
//            holder.binding.frameLayout2.three_dot.visibility = View.GONE
        }
    }

    private fun initPopupMenu(holder : OrderDetailItemViewHolder, position: Int, menuType : Int){
//        val ordersItem = listItem[position]
//        holder.popupMenu = PopupMenu(activity, holder.binding.frameLayout2.three_dot)
//        val inflater = holder.popupMenu!!.menuInflater
//        inflater.inflate(menuType, holder.popupMenu!!.menu)
//        holder.popupMenu!!.setOnMenuItemClickListener { item ->
//            when (item.itemId) {
//                R.id.item_menu_replace -> onClickReplace(ordersItem)
//                R.id.item_menu_refund -> onClickRefund(ordersItem)
//                R.id.item_menu_confirm -> onClickConfirm(ordersItem)
//                R.id.item_menu_put_back -> onClickPutBack(ordersItem)
//                R.id.item_menu_replace_to_original -> onClickReplaceToOriginal(ordersItem)
//                R.id.item_menu_flag -> onClickFlagItem(ordersItem)
//            }
//            false
//        }
    }

    private fun onClickFlagItem(ordersItem: OrdersItem){
        // Show the FlagItemDialog
//        val flagItemDialog = FlagItemDialogFragment.newInstance(orderId.toInt())
//        flagItemDialog.show(activity.supportFragmentManager, FlagItemDialogFragment.javaClass.name)
    }

    private fun onClickReplace(ordersItem: OrdersItem){
        // Show the ReplacementItemsDialog
        val selectReplacementDialog = SelectReplacementDialogFragment.newInstance(ordersItem, orderId)
        selectReplacementDialog.show(activity.supportFragmentManager, SelectReplacementDialogFragment.javaClass.name)
    }

    private fun onClickRefund(ordersItem: OrdersItem){
        // Show the Refund Dialog
        val refundDialog = RefundDialogFragment.newInstance(ordersItem, orderId, FROM_TODO)
        refundDialog.show(activity.supportFragmentManager, RefundDialogFragment.javaClass.name)
    }

    private fun onClickConfirm(ordersItem: OrdersItem){
        confirmChangedQty(ordersItem.ordersOutletsItemsId ?: 0)
    }

    private fun onClickPutBack(ordersItem: OrdersItem){
        if (ordersItem.returnItem != null && ordersItem.returnItem == 1){
            cancelRefund(ordersItem.ordersOutletsItemsId ?: 0)
            return
        }

        if (ordersItem.replacementFullfilled != null && ordersItem.replacementFullfilled == 1){
            cancelReplaced(ordersItem.ordersOutletsItemsId ?: 0)
            return
        }

        if (ordersItem.quantityDifferenceApproved != null && ordersItem.quantityDifferenceApproved == 1){
            cancelQtyDiff(ordersItem.ordersOutletsItemsId ?: 0)
            return
        }

        markAsNotFound(ordersItem.ordersOutletsItemsId ?: 0)
    }

    private fun onClickReplaceToOriginal(ordersItem: OrdersItem){
        cancelReplaced(ordersItem.ordersOutletsItemsId ?: 0)
    }

    // Mark as not found
    private fun markAsNotFound(itemId: Long){
        // Call api
        if (activity is OrderDetailsActivity) {
            (activity as OrderDetailsActivity).viewModel.markAsFound(itemId, false, false, object : HandleResponse<SimpleResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    Toast.makeText(activity, error?.message, Toast.LENGTH_SHORT).show()
                }

                override fun handleSuccessResponse(successResponse: SimpleResponse) {
                    val response = successResponse.response
                    if (response != null){

                        Toast.makeText(activity, response.message, Toast.LENGTH_SHORT).show()

                        if (response.httpCode == 200){
                            (activity as OrderDetailsActivity).queryShopperOrders()
                        }
                    }
                    else{
                        Toast.makeText(activity, R.string.error_server_return_null, Toast.LENGTH_SHORT).show()
                    }
                }
            })
        }
    }

    // Confirm Qty Difference
    private fun confirmChangedQty(itemId : Long){
        // Call api
        if (activity is OrderDetailsActivity) {
            (activity as OrderDetailsActivity).viewModel.confirmItemQtyDifference(itemId, object : HandleResponse<SimpleResponse>{
                override fun handleErrorResponse(error: ErrorResponse?) {
                    Toast.makeText(activity, error?.message, Toast.LENGTH_SHORT).show()
                }

                override fun handleSuccessResponse(successResponse: SimpleResponse) {
                    val response = successResponse.response
                    if (response != null){

                        Toast.makeText(activity, response.message, Toast.LENGTH_SHORT).show()

                        if (response.httpCode == 200){
                            (activity as OrderDetailsActivity).queryShopperOrders()
                        }
                    }
                    else{
                        Toast.makeText(activity, R.string.error_server_return_null, Toast.LENGTH_SHORT).show()
                    }
                }
            })
        }

    }

    // Cancel Refund
    private fun cancelRefund(itemId : Long){
        // Call api
        if (activity is OrderDetailsActivity) {
            (activity as OrderDetailsActivity).viewModel.cancelRefund(itemId, object : HandleResponse<SimpleResponse>{
                override fun handleErrorResponse(error: ErrorResponse?) {
                    Toast.makeText(activity, error?.message, Toast.LENGTH_SHORT).show()
                }

                override fun handleSuccessResponse(successResponse: SimpleResponse) {
                    val response = successResponse.response
                    if (response != null){
                        Toast.makeText(activity, response.message, Toast.LENGTH_SHORT).show()

                        if (response.httpCode == 200){
                            (activity as OrderDetailsActivity).queryShopperOrders()
                        }
                    }
                    else{
                        Toast.makeText(activity, R.string.error_server_return_null, Toast.LENGTH_SHORT).show()
                    }
                }
            })
        }
    }

    // Cancel ReplaceItem
    private fun cancelReplaced(itemId : Long){
        // Call api
        if (activity is OrderDetailsActivity) {
            (activity as OrderDetailsActivity).viewModel.cancelReplacedItem(itemId, object : HandleResponse<SimpleResponse>{
                override fun handleErrorResponse(error: ErrorResponse?) {
                    Toast.makeText(activity, error?.message, Toast.LENGTH_SHORT).show()
                }

                override fun handleSuccessResponse(successResponse: SimpleResponse) {
                    val response = successResponse.response
                    if (response != null){
                        Toast.makeText(activity, response.message, Toast.LENGTH_SHORT).show()

                        if (response.httpCode == 200){
                            (activity as OrderDetailsActivity).queryShopperOrders()
                        }
                    }
                    else{
                        Toast.makeText(activity, R.string.error_server_return_null, Toast.LENGTH_SHORT).show()
                    }
                }
            })
        }

    }

    // Cancel Quantity Difference
    private fun cancelQtyDiff(itemId : Long){
        // Call api
        if (activity is OrderDetailsActivity) {
            (activity as OrderDetailsActivity).viewModel.cancelItemQtyDiff(itemId, object : HandleResponse<SimpleResponse>{
                override fun handleErrorResponse(error: ErrorResponse?) {
                    Toast.makeText(activity, error?.message, Toast.LENGTH_SHORT).show()
                }

                override fun handleSuccessResponse(successResponse: SimpleResponse) {
                    val response = successResponse.response
                    if (response != null){
                        Toast.makeText(activity, response.message, Toast.LENGTH_SHORT).show()

                        if (response.httpCode == 200){
                            (activity as OrderDetailsActivity).queryShopperOrders()
                        }
                    }
                    else{
                        Toast.makeText(activity, R.string.error_server_return_null, Toast.LENGTH_SHORT).show()
                    }
                }
            })
        }
    }

    private fun getMenuId(status : Int) : Int {
        return when (status) {
            1 -> {
                R.menu.item_flag_item
            }
            2 -> {
                R.menu.item_not_found_menu
            }
            3 -> {
                R.menu.item_qty_diff
            }
            5 -> {
                R.menu.item_replaced
            }
            9 -> {
                R.menu.item_refund
            }
            else -> {
                0
            }
        }
    }

    private fun getHtmlString(str : String) : Spanned {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            // FROM_HTML_MODE_LEGACY is the behaviour that was used for versions below android N
            // we are using this flag to give a consistent behaviour
            Html.fromHtml(str, Html.FROM_HTML_MODE_LEGACY)
        } else {
            Html.fromHtml(str)
        }
    }

    inner class OrderDetailItemViewHolder(val binding: ItemListOrderDetailBinding) :
        RecyclerView.ViewHolder(binding.root){
        var popupMenu : PopupMenu? = null
    }

}