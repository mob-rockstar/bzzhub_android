package com.app.basketiodriver.data.remote.socket

interface SystemMessageListener {
    fun onResponse(systemMessage: SystemMessage?)
    fun onError(throwable: Throwable?)
}
