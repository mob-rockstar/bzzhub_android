package com.app.basketiodriver.data.model.api.response.dashboard

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class Order : Serializable{
    @SerializedName("order_id")
    @Expose
    val orderId: Long? = null

    @SerializedName("is_express")
    @Expose
    val isExpress: Int = 0

    @SerializedName("payment_gateway_id")
    @Expose
    val paymentGateway: Int = 18

    @SerializedName("order_outlet_id")
    @Expose
    val orderOutletId: Long? = null

    @SerializedName("ordered_item_count")
    @Expose
    val orderedItemCount: Int? = null

    @SerializedName("outlet_id")
    @Expose
    val outletId: Long? = null

    @SerializedName("order_status")
    @Expose
    val orderStatus: Int = 0

    @SerializedName("ordered_subtotal")
    @Expose
    val orderedSubtotal: String = "0.0"

    @SerializedName("promo_total_amount")
    @Expose
    val promoTotalAmount: String? = null

    @SerializedName("ordered_total_amount")
    @Expose
    val orderedTotalAmount: String? = null

    @SerializedName("ordered_date")
    @Expose
    val orderedDate: String? = null

    @SerializedName("ordered_time")
    @Expose
    val orderedTime: String? = null

    @SerializedName("delivery_date")
    @Expose
    val deliveryDate: String? = null

    @SerializedName("delivery_time")
    @Expose
    val deliveryTime: String? = null

    @SerializedName("delivery_instructions")
    @Expose
    val deliveryInstructions: String = ""

    @SerializedName("vendor_name")
    @Expose
    val storeName: String? = null

    @SerializedName("outlet_logo")
    @Expose
    val outletLogo: String? = null

    @SerializedName("outlet_address")
    @Expose
    val outletAddress: String? = null

    @SerializedName("outlet_latitude")
    @Expose
    val outletLatitude: String? = null

    @SerializedName("outlet_longitude")
    @Expose
    val outletLongitude: String? = null

    @SerializedName("outlet_location_city")
    @Expose
    val outletLocationCity: String? = null

    @SerializedName("outlet_location_area")
    @Expose
    val outletLocationArea: String? = null

    @SerializedName("customer_name")
    @Expose
    val customerName = ""

    @SerializedName("customer_address")
    @Expose
    val customerAddress: String? = null

    @SerializedName("customer_latitude")
    @Expose
    val customerLatitude: String? = null

    @SerializedName("customer_longitude")
    @Expose
    val customerLongitude: String? = null

    @SerializedName("customer_location_city")
    @Expose
    val customerLocationCity: String? = null

    @SerializedName("customer_location_area")
    @Expose
    val customerLocationArea: String? = null

    @SerializedName("customer_image")
    @Expose
    val customerImage: String? = null

    @SerializedName("socket_customer_id")
    @Expose
    val customerId: Long? = null

    @SerializedName("new")
    @Expose
    val isNewCustomer = 0

    @SerializedName("store_instruction")
    @Expose
    val storeInstruction: String = ""

    @SerializedName("store_location_instruction")
    @Expose
    val storeLocationInstruction: String? = null

    // OTP confirmed
    @SerializedName("otp_confirmed")
    @Expose
    val otpConfirmed: Int = 0 // 1: Confirmed, 0: Not confirmed

    @SerializedName("customer_completed_orders")
    @Expose
    val completedOrdersCount: Int = 0
}