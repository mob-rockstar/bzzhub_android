package com.app.basketiodriver.ui.earning.fragments

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.view.View
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import com.app.basketiodriver.R
import com.app.basketiodriver.data.local.prefs.PreferenceManager
import com.app.basketiodriver.data.model.api.response.Base.ErrorResponse
import com.app.basketiodriver.data.model.api.response.earning.order.ShopperOrderDetailData
import com.app.basketiodriver.data.model.api.response.earning.order.ShopperOrderDetailResponse
import com.app.basketiodriver.databinding.FragmentEarningsOrderDetailBinding
import com.app.basketiodriver.di.Injectable
import com.app.basketiodriver.ui.base.BaseFragment
import com.app.basketiodriver.ui.base.HandleResponse
import com.app.basketiodriver.ui.earning.EarningViewModel
import com.app.basketiodriver.ui.earning.fragments.EarningsOrderDetailFragmentArgs.fromBundle
import com.app.basketiodriver.utils.AppConstants
import com.app.basketiodriver.utils.CommonUtils
import com.app.basketiodriver.utils.GlideApp
import com.app.basketiodriver.utils.InfoHelp
import com.tbruyelle.rxpermissions2.RxPermissions
import io.reactivex.android.schedulers.AndroidSchedulers
import java.util.*

class EarningsOrderDetailFragment : BaseFragment<FragmentEarningsOrderDetailBinding?, EarningViewModel>(),
    Injectable {

    override val layoutId: Int
        get() = R.layout.fragment_earnings_order_detail

    override val viewModel: EarningViewModel
        get() {
            return getViewModel(baseActivity as FragmentActivity, EarningViewModel::class.java)
        }

    // Yearly Balance Report
    private val yearReportItem by lazy {
        fromBundle(requireArguments()).yearReportItem
    }

    var orderId : String = ""

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (arguments != null){
            orderId = fromBundle(requireArguments()).orderId
        }

        // Initialize the UI
        initUI()

        shopperOrderDetailsReport()
    }

    private fun initUI(){
        // Set the title
        setTitle(String.format(Locale("en"), "#%s", orderId))

        viewDataBinding!!.txtCurrentBalance.setOnClickListener{
            InfoHelp.showHelpDialog(it, baseActivity?.resources?.getString(R.string.your_current_balance)!!, baseActivity as Activity, true)
        }

        // Order Id
        viewDataBinding!!.txtOrderSummeryId.text = String.format(Locale("en"), "#%s", orderId)

        // Get Help
        viewDataBinding!!.btnHelp.setOnClickListener {
            getHelp()
        }
    }

    // Call the support team
    private fun getHelp(){
        val builder: AlertDialog.Builder = AlertDialog.Builder(requireContext())
        builder.setTitle("")
        builder.setMessage(baseActivity?.resources?.getString(R.string.support_call))
            .setCancelable(false)
            .setPositiveButton(
                getString(R.string.ok_btn_txt)
            ) { _, _ -> //do things
                callSupportTeam()

            }.setNegativeButton(
                getString(R.string.cancel_btn_txt)
            ) { _, _ ->
                //do things
            }
        val alert: AlertDialog = builder.create()
        alert.show()
    }

    // Call the support team
    @SuppressLint("CheckResult")
    private fun callSupportTeam(){
        val number = String.format(Locale("en"), "tel:%s", AppConstants.SUPPORT_PHONE_NUMBER)
        RxPermissions(this).request(
            Manifest.permission.CALL_PHONE
        ).observeOn(AndroidSchedulers.mainThread())
            .subscribe { granted ->
                if (granted) {
                    val intent = Intent(Intent.ACTION_CALL, Uri.parse(number))
                    startActivity(intent)
                }
                else{
                    Toast.makeText(baseActivity, baseActivity?.resources?.getString(R.string.error_no_call_permission), Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun shopperOrderDetailsReport(){
        val month : Int = if (yearReportItem != null) yearReportItem.monthNumber else Calendar.getInstance().get(
            Calendar.MONTH)
        val year : Int = if (yearReportItem != null) yearReportItem.year.toInt() else Calendar.getInstance().get(
            Calendar.YEAR)

        viewModel.getShopperOrderDetails(month, year, orderId, object :
            HandleResponse<ShopperOrderDetailResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (isNetworkConnected){
                    Toast.makeText(baseActivity, error?.message, Toast.LENGTH_SHORT).show()
                }else{
                    Toast.makeText(baseActivity, baseActivity!!.resources?.getString(R.string.no_internet_conn_msg_txt), Toast.LENGTH_LONG).show()
                }
            }

            override fun handleSuccessResponse(successResponse: ShopperOrderDetailResponse) {
                if (successResponse.data != null){
                    updateUI(successResponse.data)
                }
                else{
                    Toast.makeText(baseActivity, successResponse.message, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    private fun updateUI(data : ShopperOrderDetailData){
        viewDataBinding!!.txtTitle.text         = data.vendor_name
        viewDataBinding!!.txtStartAddress.text  = data.contact_address
        viewDataBinding!!.txtItems.text         = String.format(Locale("en"), "%s %s", data.total_delivered_items, baseActivity?.resources?.getString(R.string.items))

        viewDataBinding!!.txtOrderValue.text = String.format(Locale("en"), "%s %s", PreferenceManager.currency, data.total_amount)
        CommonUtils.setBalanceTextColor(viewDataBinding!!.txtOrderValue, "" + data.total_amount)
        viewDataBinding!!.txtService.text               = data.service_type
        viewDataBinding!!.txtDestination.text           = data.customer_name
        viewDataBinding!!.txtDestinationAddress.text    = data.customer_address
        viewDataBinding!!.txtCollectedFromCustomer.text = String.format(Locale.ENGLISH, "%s %s", PreferenceManager.currency, data.total_collected)

        try{
            if (data.vendor_image != null){
            GlideApp.with(baseActivity!!.applicationContext).load(data.vendor_image).fitCenter()
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.placeholder).into(viewDataBinding!!.imgVender)
            }
        }
        catch (e : Exception){
            e.printStackTrace()
        }

        val extra = data.total_extra_amount_with_shopper.toDouble()
        val extraEarning = PreferenceManager.currency + " " + data.total_extra_amount_with_shopper
        when {
            extra < 0 -> {
    //            val str = baseActivity?.resources?.getString(R.string.your_own_basket) + " " + baseActivity?.resources?.getString(R.string.jod) + " " + data.total_extra_amount_with_shopper
    //            viewDataBinding!!.txtExtra.text = str
    //
    //            val startIdx = baseActivity?.resources?.getString(R.string.your_own_basket)!!.length + 1
    //            val endIdx = startIdx + baseActivity?.resources?.getString(R.string.jod)!!.length + data.total_extra_amount_with_shopper.length + 1
    //
    //            val wordToSpan = SpannableString(str)
    //            wordToSpan.setSpan(ForegroundColorSpan(baseActivity?.resources?.getColor(R.color.item_not_found_color)!!), startIdx, endIdx, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
    //            viewDataBinding!!.txtExtra.text = wordToSpan

                viewDataBinding!!.txtExtraTitle.text = baseActivity!!.resources.getString(R.string.your_own_basket)
                viewDataBinding!!.txtExtra.text = extraEarning
                CommonUtils.setBalanceTextColor(viewDataBinding!!.txtExtra, "" + data.total_extra_amount_with_shopper)
            }
            extra > 0 -> {
    //            val str = baseActivity?.resources?.getString(R.string.baskets_own_you) + " " + baseActivity?.resources?.getString(R.string.jod) + " " + data.total_extra_amount_with_shopper
    //            viewDataBinding!!.txtExtra.text = str
    //
    //            val startIdx = baseActivity?.resources?.getString(R.string.baskets_own_you)!!.length + 1
    //            val endIdx = startIdx + baseActivity?.resources?.getString(R.string.jod)!!.length + data.total_extra_amount_with_shopper.length + 1
    //
    //            val wordToSpan = SpannableString(str)
    //            wordToSpan.setSpan(ForegroundColorSpan(baseActivity?.resources?.getColor(R.color.colorPrimary)!!), startIdx, endIdx, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
    //            viewDataBinding!!.txtExtra.text = wordToSpan

                viewDataBinding!!.txtExtraTitle.text = baseActivity!!.resources.getString(R.string.baskets_own_you)
                viewDataBinding!!.txtExtra.text = extraEarning
                CommonUtils.setBalanceTextColor(viewDataBinding!!.txtExtra, "" + data.total_extra_amount_with_shopper)
            }
            else -> {
    //            val str = baseActivity?.resources?.getString(R.string.baskets_own_you) + " " + baseActivity?.resources?.getString(R.string.jod) + " " + data.total_extra_amount_with_shopper
    //            viewDataBinding!!.txtExtra.text = str
    //
    //            val startIdx = baseActivity?.resources?.getString(R.string.baskets_own_you)!!.length + 1
    //            val endIdx = startIdx + baseActivity?.resources?.getString(R.string.jod)!!.length + data.total_extra_amount_with_shopper.length + 1
    //
    //            val wordToSpan = SpannableString(str)
    //            wordToSpan.setSpan(ForegroundColorSpan(baseActivity?.resources?.getColor(R.color.colorBlack33)!!), startIdx, endIdx, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
    //            viewDataBinding!!.txtExtra.text = wordToSpan

                viewDataBinding!!.txtExtraTitle.text = baseActivity!!.resources.getString(R.string.baskets_own_you)
                viewDataBinding!!.txtExtra.text = extraEarning
                CommonUtils.setBalanceTextColor(viewDataBinding!!.txtExtra, "" + data.total_extra_amount_with_shopper)
            }
        }

        // Current Balance
        val currBalance = PreferenceManager.currency + " " + data.current_account_balance
        viewDataBinding!!.currentBalanceValue.text = currBalance
        CommonUtils.setBalanceTextColor(viewDataBinding!!.currentBalanceValue, "" + data.current_account_balance)

        // Delivery Earning
        val deliveryEarning = PreferenceManager.currency + " " + data.delivery_earning
        viewDataBinding!!.txtDeliveryEarningsValue.text = deliveryEarning
        CommonUtils.setBalanceTextColor(viewDataBinding!!.txtDeliveryEarningsValue, "" + data.delivery_earning)

        // Shopping Earning
        val shoppingEarning = PreferenceManager.currency+ " " + data.shopping_earning
        viewDataBinding!!.txtShoppingEarningsValue.text = shoppingEarning
        CommonUtils.setBalanceTextColor(viewDataBinding!!.txtShoppingEarningsValue, "" + data.shopping_earning)

        // Total Earning
        val earning = PreferenceManager.currency + " " + data.total_earnings
        viewDataBinding!!.txtTotalEarningValue.text = earning
        CommonUtils.setBalanceTextColor(viewDataBinding!!.txtTotalEarningValue, "" + data.total_earnings)

        // Distance
        val tk = data.travel_distance
        val tkDouble = tk.toDoubleOrNull()
        if (tkDouble != null){
            viewDataBinding!!.txtTotalKm.text = String.format(Locale("en"), "%.2f KM", tkDouble)
        }

        when (data.service_type_flag) {
            1 -> {
                viewDataBinding!!.txtService.setTextColor(baseActivity?.resources?.getColor(R.color.colorPrimary)!!)
            }
            2 -> {
                viewDataBinding!!.txtService.setTextColor(baseActivity?.resources?.getColor(R.color.colorItemDifferent)!!)
            }
            else -> {
                viewDataBinding!!.txtService.setTextColor(baseActivity?.resources?.getColor(R.color.colorDisabledButton)!!)
            }
        }

    }
}