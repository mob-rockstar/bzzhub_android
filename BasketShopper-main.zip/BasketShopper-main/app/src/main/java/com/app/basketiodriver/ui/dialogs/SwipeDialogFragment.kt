package com.app.basketiodriver.ui.dialogs

import android.app.Dialog
import android.content.DialogInterface
import android.os.Bundle
import android.view.*
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import com.app.basketiodriver.R
import com.app.basketiodriver.di.Navigators
import com.app.basketiodriver.di.Navigators.goToDashboard
import com.app.basketiodriver.utils.SwipeManyStateButton
import com.app.basketiodriver.utils.SwipeManyStateButton.OnStateChangeListener

class SwipeDialogFragment : DialogFragment() {
    private lateinit var mSwipeManyStateButton: SwipeManyStateButton
    private var stateChangeListener: OnStateChangeListener? = null
    private var orderStatus: Int? = null

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val builder = AlertDialog.Builder(requireActivity(), R.style.DialogWithOut)
        val root: View = LayoutInflater.from(activity).inflate(R.layout.dialog_swipe, null)
        builder.setView(root)
        builder.setCancelable(false)
        builder.setOnKeyListener { dialog: DialogInterface?, keyCode: Int, event: KeyEvent -> keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP }
        val dialog = builder.create()
        dialog.setCanceledOnTouchOutside(false)

        setLayoutParams(dialog)

        mSwipeManyStateButton = root.findViewById(R.id.dialogSwipeButton)
        mSwipeManyStateButton.setOnStateChangeListener(stateChangeListener)
        dialog.setOnShowListener { dialog1: DialogInterface? ->
            mSwipeManyStateButton.getRootView().animate()
                .translationY(3 * resources.displayMetrics.density).duration = 1
        }
        if (orderStatus != null && orderStatus != 0)
            mSwipeManyStateButton.state = orderStatus!!
        else
            dialog.setOnShowListener { Navigators.goToDashboard(requireActivity())}

        return dialog
    }

    private fun setLayoutParams(dialog: AlertDialog) {
        val params = dialog.window!!.attributes
        dialog.window!!.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        params.gravity = Gravity.BOTTOM
        params.horizontalMargin = 0f
        params.verticalMargin = 0f
        dialog.window!!.attributes = params
    }

    fun setStateChangeListener(stateChangeListener: OnStateChangeListener): SwipeDialogFragment {
        this.stateChangeListener = stateChangeListener
        return this
    }

    fun setOrderState(orderStatus: Int): SwipeDialogFragment {
        this.orderStatus = orderStatus
        return this
    }

    fun getSwipeManyStateButton(): SwipeManyStateButton? {
        return mSwipeManyStateButton
    }
}