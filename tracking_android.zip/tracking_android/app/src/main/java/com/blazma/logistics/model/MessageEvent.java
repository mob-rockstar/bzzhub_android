package com.blazma.logistics.model;

public class MessageEvent {
    public MessageType messageType;
    public boolean isSuccess;
    public String sms;

    public enum MessageType {
    }
}
