package Utility;

public class GlobalVariable {
    public static boolean isFloatingDaily;
    public static String strDynamicLinkUserId;
    public static boolean isFromCamera;
}
