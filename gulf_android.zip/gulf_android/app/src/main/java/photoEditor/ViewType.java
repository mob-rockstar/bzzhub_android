package photoEditor;

public enum ViewType {

    BRUSH_DRAWING,
    TEXT,
    IMAGE,
    LOCATION,
    EMOJI;

}
