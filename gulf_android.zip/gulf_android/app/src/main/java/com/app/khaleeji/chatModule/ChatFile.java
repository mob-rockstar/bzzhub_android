package com.app.khaleeji.chatModule;

/**
 * Created by user47 on 13/12/17.
 */
//can you try connecting again

public class ChatFile {

    public static String passwordUser = "gulflink@123";
    public static String app_name = "gulflink";
    public static final String mServiceName = "13.233.127.158";  //chat  //localhost
    public static String Chat_Message_type;

}
