package com.app.khaleeji.Response;

/**
 * Created by Dcube on 20-07-2018.
 */

public class FetchUserDetailResponse {
}
