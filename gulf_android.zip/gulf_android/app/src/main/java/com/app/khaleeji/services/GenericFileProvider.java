package com.app.khaleeji.services;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {
}
