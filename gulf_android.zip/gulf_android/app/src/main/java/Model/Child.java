package Model;

/**
 * Created by Dcube on 11-06-2018.
 */

public class Child {

    String name;

    public Child(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

}
