package Model;

/**
 * Created by user on 19/9/17.
 */

public class onLaunchTab_selected {
    int  pos;

    public onLaunchTab_selected(int pos) {
        this.pos = pos;
    }

    public int getTabPos() {
        return pos;
    }

    public void setTabpos(int pos) {
        this.pos = pos;
    }
}
