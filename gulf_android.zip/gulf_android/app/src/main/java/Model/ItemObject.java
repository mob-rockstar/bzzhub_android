package Model;

/**
 * Created by Dcube on 08-06-2018.
 */

public class ItemObject {

    private String contents;
    public ItemObject(String contents) {
        this.contents = contents;
    }
    public String getContents() {
        return contents;
    }
}
