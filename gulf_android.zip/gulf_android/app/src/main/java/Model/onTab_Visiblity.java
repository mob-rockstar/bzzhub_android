package Model;

/**
 * Created by user on 19/9/17.
 */

public class onTab_Visiblity {

    boolean isShow_tab;

    public onTab_Visiblity(boolean ishow) {
        isShow_tab = ishow;
    }

    public boolean isShow_tab() {
        return isShow_tab;
    }

    public void setShow_tab(boolean show_tab) {
        isShow_tab = show_tab;
    }

}
