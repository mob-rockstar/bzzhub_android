package Model;

/**
 * Created by user on 25/12/17.
 */

public class RowItem {



    private String imageId;
    private String title;



    public String getImageId() {
        return imageId;
    }
    public void setImageId(String imageId) {
        this.imageId = imageId;
    }

    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }

}
