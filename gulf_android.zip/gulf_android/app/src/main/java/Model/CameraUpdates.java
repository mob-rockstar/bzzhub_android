package Model;

/**
 * Created by user on 18/12/17.
 */

public class CameraUpdates {
    boolean isCameraRefresh;

    public CameraUpdates(boolean isCameraRefresh) {
        this.isCameraRefresh = isCameraRefresh;

    }
}
