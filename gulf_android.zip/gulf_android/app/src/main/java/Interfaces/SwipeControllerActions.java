package Interfaces;

/**
 * Created by user on 23/1/18.
 */

public class SwipeControllerActions {

    public void onLeftClicked(int position) {}

    public void onRightClicked(int position) {}
}
