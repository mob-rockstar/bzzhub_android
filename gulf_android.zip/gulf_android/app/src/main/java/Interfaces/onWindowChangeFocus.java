package Interfaces;

/**
 * Created by user on 22/9/17.
 */

public interface onWindowChangeFocus {

    public void onWindowFocusChanged(boolean hasFocus);
}
