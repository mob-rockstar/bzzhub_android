package Interfaces;


import com.app.khaleeji.chatModule.ChatDbData;

/**
 * Created by user47 on 9/6/17.
 */
public interface DownloadViewInterface {
    public void downloadRow(ChatDbData chat);

}
