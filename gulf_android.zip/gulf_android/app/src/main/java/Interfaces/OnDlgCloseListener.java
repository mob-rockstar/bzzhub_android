package Interfaces;

public interface OnDlgCloseListener {
    void onClose();
}
