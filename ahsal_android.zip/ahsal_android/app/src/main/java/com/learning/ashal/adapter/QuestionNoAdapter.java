package com.learning.ashal.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.learning.ashal.R;
import com.learning.ashal.databinding.RowQuestionNoBinding;


public class QuestionNoAdapter extends RecyclerView.Adapter<QuestionNoAdapter.MyViewHolder>{

    private OnItemClickListener onItemClickListener;
    private int count = 0;
    private Context context;
    private boolean[] isSelectedQuestion;

    public QuestionNoAdapter(Context context, OnItemClickListener onItemClickListener){
        this.context = context;
        this.onItemClickListener = onItemClickListener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowQuestionNoBinding binding = DataBindingUtil.inflate( LayoutInflater.from(parent.getContext()), R.layout.row_question_no, parent, false);
        return new MyViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        if(isSelectedQuestion[position]){
            holder.binding.imgBk.setImageResource(R.color.colorTypeBk);
            holder.binding.txtNo.setTextColor(context.getResources().getColor(R.color.white));
        }else{
            holder.binding.txtNo.setTextColor(context.getResources().getColor(R.color.black));
            holder.binding.imgBk.setImageResource(R.color.white);
        }

        holder.binding.txtNo.setText(String.valueOf(position + 1));
//
//        holder.binding.rlRow.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                setSelectedFlag(position);
//                onItemClickListener.onClick(position);
//            }
//        });
    }

    public void setSelectedFlag(int pos){
        for(int i = 0 ; i < isSelectedQuestion.length; i++){
            isSelectedQuestion[i] = false;
        }

        isSelectedQuestion[pos] = true;
        notifyDataSetChanged();
    }

    public void setData(int count){
        this.count = count;
        if(this.count > 0){
            isSelectedQuestion = new boolean[count];
            isSelectedQuestion[0] = true;
        }
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return count;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private RowQuestionNoBinding binding;
        public MyViewHolder(RowQuestionNoBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public interface OnItemClickListener{
        void onClick(int no);
    }
}
