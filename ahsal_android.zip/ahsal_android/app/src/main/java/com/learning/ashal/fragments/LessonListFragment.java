package com.learning.ashal.fragments;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;

import com.google.android.material.button.MaterialButton;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.learning.ashal.R;
import com.learning.ashal.activities.LoginActivity;
import com.learning.ashal.activities.MainActivity;
import com.learning.ashal.activities.TeacherMainActivity;
import com.learning.ashal.adapter.MathAdapter;
import com.learning.ashal.custom.CustomInfoDlg;
import com.learning.ashal.custom.CustomQuestionDlg;
import com.learning.ashal.custom.CustomTextView;
import com.learning.ashal.custom.CustomVideoDownloadDlg;
import com.learning.ashal.custom.FileEnDecryptManager;
import com.learning.ashal.databinding.FragmentMathBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.interfaces.QuestionCallbackListener;
import com.learning.ashal.model.DownloadedVideoModel;
import com.learning.ashal.model.GradeModel;
import com.learning.ashal.model.LastCourseModel;
import com.learning.ashal.model.LessonModel;
import com.learning.ashal.model.MessageEvent;
import com.learning.ashal.model.NotificationModel;
import com.learning.ashal.model.UserModel;
import com.learning.ashal.model.VideoDownloadModel;
import com.learning.ashal.utilities.AnimationUtils;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import com.learning.ashal.utilities.SavePref;
import com.learning.ashal.utilities.TempStore;

import org.greenrobot.eventbus.EventBus;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Type;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import io.realm.Realm;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.learning.ashal.utilities.Constants.BASE_URL;

public class LessonListFragment extends BaseFragment {

    private String TAG = LessonListFragment.class.getSimpleName();
    private FragmentMathBinding mBinding;
    private MathAdapter mathAdapter;
    private String id;
    private List<LessonModel> lessonModels;
    private List<LessonModel> lessonFirstModels = new ArrayList<>();
    private List<LessonModel> lessonSecModels = new ArrayList<>();
    private String subjectName;
    private boolean isFromProfile;
    private LessonModel selectedLessonModel;
    private String courseImage;

    public LessonListFragment(){

    }

    public LessonListFragment(String subjectName, String id, String courseImage){
        this.id = id;
        this.subjectName = subjectName;
        this.courseImage = courseImage;
    }

    public LessonListFragment(String subjectName, String id, boolean isFromProfile, String courseImage){
        this.id = id;
        this.subjectName = subjectName;
        this.isFromProfile = isFromProfile;
        this.courseImage = courseImage;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_math, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }


    @Override
    public void updateUI() {
        if (!isFromProfile) {
            ((MainActivity)mActivity).setWhiteBk();
        }
    }

    private void initView() {
        updateUI();

        mBinding.txtSubject.setText(subjectName);

        mBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.back();
            }
        });

        CustomTextView txtTitle = mBinding.getRoot().findViewById(R.id.txtTitle);
        txtTitle.setText(getString(R.string.course_chat));
        MaterialButton btNext = mBinding.getRoot().findViewById(R.id.btNext);
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        mathAdapter = new MathAdapter(mActivity, isCoursePurchased,  new MathAdapter.OnItemClickListener() {
            @Override
            public void onClick(LessonModel lessonModel) {
                if(lessonModel.paid.equals("1")){
                    if(TempStore.isLoggedIn){
                        if(isCoursePurchased){
                            FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new LessonDetailFragment(subjectName, lessonModel, isFromProfile, id, courseImage), R.id.frameLayout);
                        }else{
                            openQuestionDlg(getResources().getString(R.string.msg_purchase_course),
                                    getString(R.string.buy_course), getString(R.string.cancel), new QuestionCallbackListener() {
                                        @Override
                                        public void onYes() {
                                            callGetCoursePerLesson(lessonModel);
                                        }

                                        @Override
                                        public void onNo() {

                                        }
                                    });
                        }
                    }else{
                        Intent intent = new Intent(mActivity, LoginActivity.class);
                        intent.putExtra("fromGuest", true);
                        startActivity(intent);
                    }
                }else{
                    FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new LessonDetailFragment(subjectName, lessonModel, isFromProfile, id, courseImage), R.id.frameLayout);
                }
            }

            @Override
            public void onDownload(LessonModel lessonModel) {
                if(TempStore.isLoggedIn){
                    if(lessonModel.paid.equals("1")){
                        if(isCoursePurchased){
                            selectedLessonModel = lessonModel;
                            if(checkAndRequestPermissions()){
                                callGetDownload(lessonModel);
                            }
                        }else{
                            CustomInfoDlg dlg = new CustomInfoDlg(mActivity, getString(R.string.msg_purchase_course_download));
                            dlg.showDialog();
                        }

                    }else{
                        selectedLessonModel = lessonModel;
                        if(checkAndRequestPermissions()){
                            callGetDownload(lessonModel);
                        }
                    }
                }else{
                    CustomQuestionDlg dlg = new CustomQuestionDlg(mActivity, getString(R.string.need_to_register),
                            getString(R.string.new_register), getString(R.string.cancel), new CustomQuestionDlg.ItemClickInterface() {
                        @Override
                        public void onOK() {
                            Intent intent = new Intent(mActivity, LoginActivity.class);
                            startActivity(intent);
                        }
                    });
                    dlg.showDialog();
                    dlg.setCanceledOnTouchOutside(false);
                }
            }
        });
        mBinding.rvMath.setAdapter(mathAdapter);

        mBinding.txtTabFistSem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setFirstSemTab();
            }
        });

        mBinding.txtTabSecSem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setSecSemTab();
            }
        });

        mBinding.etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(mathAdapter!=null) {
                    mathAdapter.getFilter().filter(charSequence);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        if(TempStore.isLoggedIn)
            callCheckCourse(id);
        callGetLessonList();
    }

    private void seperateData(){
        lessonFirstModels.clear();
        lessonSecModels.clear();
        if(lessonModels != null){
            for(LessonModel lessonModel: lessonModels){
                if(lessonModel.semester.equals("1")){
                    lessonFirstModels.add(lessonModel);
                }else{
                    lessonSecModels.add(lessonModel);
                }
            }
        }
    }

    private void setFirstSemTab(){
        mBinding.txtTabFistSem.setTextColor(getResources().getColor(R.color.colorPrimary));
        mBinding.txtTabFistSem.setCustomFont(mActivity, mActivity.getResources().getString(R.string.SFProDisplay_Bold));
        mBinding.txtTabSecSem.setTextColor(getResources().getColor(R.color.colorInactiveWord));
        mBinding.txtTabSecSem.setCustomFont(mActivity, mActivity.getResources().getString(R.string.SFProDisplay_Regular));
        if(mathAdapter!=null && lessonFirstModels.size() > 0) {
            realm = Realm.getDefaultInstance();
            String id;
            UserModel userModel = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel :
                    SavePref.getInstance(mActivity).getUserModel();
            if(userModel != null)
                for(LessonModel lessonModel:lessonFirstModels){
                    id = lessonModel.title + userModel.id + TempStore.gradeId;

                    DownloadedVideoModel result = realm.where(DownloadedVideoModel.class).equalTo("id", "."+id).findFirst();

                    if (result == null) {
                        lessonModel.alreadyDownloaded = false;
                    }else{
                        lessonModel.alreadyDownloaded = true;
                    }
                }

            mBinding.llNoData.setVisibility(View.GONE);
            mathAdapter.setData(lessonFirstModels);
        }else{
            mBinding.llNoData.setVisibility(View.VISIBLE);
            mathAdapter.setData(null);
        }
        AnimationUtils.animateSlideTopFromDown(mActivity, mBinding.rvMath);
    }

    private void setSecSemTab(){
        mBinding.txtTabSecSem.setTextColor(getResources().getColor(R.color.colorPrimary));
        mBinding.txtTabSecSem.setCustomFont(mActivity, mActivity.getResources().getString(R.string.SFProDisplay_Bold));
        mBinding.txtTabFistSem.setTextColor(getResources().getColor(R.color.colorInactiveWord));
        mBinding.txtTabFistSem.setCustomFont(mActivity, mActivity.getResources().getString(R.string.SFProDisplay_Regular));
        if(mathAdapter!=null && lessonSecModels.size() > 0) {
            realm = Realm.getDefaultInstance();
            String id;
            UserModel userModel = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel :
                    SavePref.getInstance(mActivity).getUserModel();
            if(userModel != null)
                for(LessonModel lessonModel:lessonSecModels){
                    id = lessonModel.title + userModel.id + TempStore.gradeId;

                    DownloadedVideoModel result = realm.where(DownloadedVideoModel.class).equalTo("id", "."+id).findFirst();

                    if(result == null) {
                        lessonModel.alreadyDownloaded = false;
                    }else{
                        lessonModel.alreadyDownloaded = true;
                    }
                }
            mBinding.llNoData.setVisibility(View.GONE);
            mathAdapter.setData(lessonSecModels);
        }else{
            mBinding.llNoData.setVisibility(View.VISIBLE);
            mathAdapter.setData(null);
        }
        AnimationUtils.animateSlideTopFromDown(mActivity, mBinding.rvMath);
    }

    private boolean checkAndRequestPermissions() {
        int permissionReadStorage = ContextCompat.checkSelfPermission(mActivity, Manifest.permission.READ_EXTERNAL_STORAGE);
        int permissionWriteStorage = ContextCompat.checkSelfPermission(mActivity, android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
        List<String> listPermissionsNeeded = new ArrayList<>();
        if (permissionWriteStorage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }

        if (permissionReadStorage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }

        if (!listPermissionsNeeded.isEmpty()) {
            this.requestPermissions(listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), 1);
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            Map<String, Integer> perms = new HashMap<>();
            perms.put(Manifest.permission.WRITE_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
            perms.put(Manifest.permission.READ_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
            if (grantResults.length > 0) {
                for (int i = 0; i < permissions.length; i++)
                    perms.put(permissions[i], grantResults[i]);
                if (perms.get(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                        && perms.get(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                    callGetDownload();
                }
            }
        }
    }

    private void callGetDownload(LessonModel lessonModel){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.downloadLink(lessonModel.vimeoId, id);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            if(!jsonObject.get("data").isJsonNull()){
                                Gson gson = new Gson();
                                Type type = new TypeToken<List<VideoDownloadModel>>() {}.getType();
                                try{
                                    List<VideoDownloadModel> videoDownloadModelList = gson.fromJson(jsonObject.get("data").getAsJsonArray(), type);
                                    CustomVideoDownloadDlg customVideoDownloadDlg = new CustomVideoDownloadDlg(mActivity,
                                            new CustomVideoDownloadDlg.ItemClickInterface() {
                                                @Override
                                                public void onSelect(VideoDownloadModel videoDownloadModel) {
                                                    downloadVideo(videoDownloadModel, lessonModel);
                                                }
                                            }, videoDownloadModelList);
                                    customVideoDownloadDlg.showDialog();
                                }catch (JsonSyntaxException ex){
                                    ex.printStackTrace();
                                }
                            }
                        }else{
                            if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private void callGetDownload(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.downloadLink(selectedLessonModel.vimeoId, id);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            if(!jsonObject.get("data").isJsonNull()){
                                Gson gson = new Gson();
                                Type type = new TypeToken<List<VideoDownloadModel>>() {}.getType();
                                try{
                                    List<VideoDownloadModel> videoDownloadModelList = gson.fromJson(jsonObject.get("data").getAsJsonArray(), type);
                                    CustomVideoDownloadDlg customVideoDownloadDlg = new CustomVideoDownloadDlg(mActivity,
                                            new CustomVideoDownloadDlg.ItemClickInterface() {
                                                @Override
                                                public void onSelect(VideoDownloadModel videoDownloadModel) {
                                                    downloadVideo(videoDownloadModel, selectedLessonModel);
                                                }
                                            }, videoDownloadModelList);
                                    customVideoDownloadDlg.showDialog();
                                }catch (JsonSyntaxException ex){
                                    ex.printStackTrace();
                                }
                            }
                        }else{
                            if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }


    private void callGetLessonList(){
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.lessonList(id);
        ProgressDialog.showProgress(mActivity);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<List<LessonModel>>() {}.getType();
                            try{
                                lessonModels = gson.fromJson(jsonObject.get("data").getAsJsonArray(), type);
                                mathAdapter.setData(lessonModels);
                                seperateData();
                                setFirstSemTab();
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private boolean isCoursePurchased;
    private void callCheckCourse(String id){
        if(!hasProfile()){
            return;
        }
        if(getStudentId() == null){
            Toast.makeText(mActivity, getString(R.string.select_default_student), Toast.LENGTH_SHORT).show();
            return;
        }
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.checkCourse(getStudentId(), id);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            if(!jsonObject.get("data").isJsonNull()){
                                isCoursePurchased = true;
                            }else{
                                isCoursePurchased = false;
                            }
                            mathAdapter.setCourseFlag(isCoursePurchased);
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private void callGetCoursePerLesson(LessonModel lessonModel){
        if(getStudentId() == null){
            Toast.makeText(mActivity, getString(R.string.select_default_student), Toast.LENGTH_SHORT).show();
            return;
        }
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.callGetCoursePerLesson(lessonModel.id, getStudentId());
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<LastCourseModel>() {}.getType();
                            try{
                                LastCourseModel lastCourseModel = gson.fromJson(jsonObject.get("data").getAsJsonObject(), type);
                                if(!TempStore.isLoggedIn){
                                    Toast.makeText(mActivity, getString(R.string.register_ashal), Toast.LENGTH_SHORT).show();
                                    return;
                                }
                                if(getStudentId() == null){
                                    Toast.makeText(mActivity, getString(R.string.select_default_student), Toast.LENGTH_SHORT).show();
                                    return;
                                }
                                //already exists in cart
                                for(LastCourseModel lastCourseModel1: TempStore.cartList){
                                    if(lastCourseModel.id.equals(lastCourseModel1.id)){
                                        FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new CheckoutFragment(lastCourseModel, isFromProfile), R.id.frameLayout);
                                        return;
                                    }
                                }
                                //newly
                                TempStore.cartList.add(lastCourseModel);
                                saveCartToLocalDB(lastCourseModel);
                                MessageEvent messageEvent = new MessageEvent();
                                messageEvent.messageType = MessageEvent.MessageType.CART_BADGE_SHOW;
                                EventBus.getDefault().post(messageEvent);
                                FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new CheckoutFragment(lastCourseModel, isFromProfile), R.id.frameLayout);
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private Realm realm;
    private void downloadVideo(VideoDownloadModel videoDownloadModel, LessonModel lessonModel){
        realm = Realm.getDefaultInstance();
        String id;
        UserModel userModel = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel :
                SavePref.getInstance(mActivity).getUserModel();
        id = lessonModel.title + userModel.id + videoDownloadModel.gradeModel.id;

//        DownloadedVideoModel result = realm.where(DownloadedVideoModel.class).equalTo("id", id).findFirst();

//        if (result == null) {
            new Thread(new Runnable() {
                public void run() {
                    runDownloadImageThread(lessonModel.cover, lessonModel.title);
                }
            }).start();

            new Thread(new Runnable() {
                public void run() {
                    runDownloadImageThread(courseImage, subjectName);
                }
            }).start();

            new Thread(new Runnable() {
                public void run() {
                    downloadVideoThread(videoDownloadModel, lessonModel.title, id);
                }
            }).start();
            Toast.makeText(mActivity, getString(R.string.downloading), Toast.LENGTH_SHORT).show();
//        }else {
//            Toast.makeText(mActivity, getString(R.string.already_downloaded), Toast.LENGTH_SHORT).show();
//        }
    }

    private void downloadVideoThread(VideoDownloadModel videoDownloadModel, String lessonName, String id){
        int count;

        try {
            URL url = new URL(videoDownloadModel.link);
            URLConnection connection = url.openConnection();
            connection.connect();
            int lefOfFile = connection.getContentLength();
            InputStream input = new BufferedInputStream(url.openStream());
            File storageDir = new File(Environment
                    .getExternalStorageDirectory() + "/ashal/");
            if (!storageDir.exists())
                storageDir.mkdirs();


            OutputStream output = new FileOutputStream(Environment
                    .getExternalStorageDirectory() + "/ashal/."+ id);

            byte data[] = new byte[1024];
            long total = 0;
            while ((count = input.read(data)) != -1) {
                total += count;
                Log.e("MediaDownProgress", "" + (int) ((total * 100) / lefOfFile));
                output.write(data, 0, count);
            }
            output.flush();
            output.close();
            input.close();

            FileEnDecryptManager.getInstance().doEncrypt(Environment.getExternalStorageDirectory() + "/ashal/."+ id);

            MessageEvent messageEvent = new MessageEvent();
            messageEvent.messageType = MessageEvent.MessageType.SHOW_DIALOG;
            messageEvent.isSuccess = true;
            EventBus.getDefault().post(messageEvent);

            createMetaFile(videoDownloadModel, lessonName, "."+id);

        } catch (Exception e) {
            MessageEvent messageEvent = new MessageEvent();
            messageEvent.messageType = MessageEvent.MessageType.SHOW_DIALOG;
            EventBus.getDefault().post(messageEvent);
        }
    }

    private void createMetaFile(VideoDownloadModel videoDownloadModel, String lessonName, String id){

        Date date = Calendar.getInstance().getTime();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);

        Realm realm = Realm.getDefaultInstance();

        realm.beginTransaction();
        DownloadedVideoModel result = realm.where(DownloadedVideoModel.class).equalTo("id", id).findFirst();
        if (result == null) {
            // Exists
            DownloadedVideoModel downloadedVideoModel = realm.createObject(DownloadedVideoModel.class);
            downloadedVideoModel.courseTitle = subjectName;
            downloadedVideoModel.lessonName = lessonName;
            downloadedVideoModel.date = sdf.format(date);
            UserModel userModel = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel : SavePref.getInstance(mActivity).getUserModel();
            downloadedVideoModel.userId = userModel.id;
            downloadedVideoModel.id = id;
            downloadedVideoModel.gradeId = videoDownloadModel.gradeModel.id;
            downloadedVideoModel.gradeArabicName = videoDownloadModel.gradeModel.arabicName;
            downloadedVideoModel.gradeEnglishName = videoDownloadModel.gradeModel.englishName;
        }
        realm.commitTransaction();

        Log.e("MediaDownloadService", "create meta file: "+ id);
    }

    private void runDownloadImageThread(String mediaUrl, String filename){
        int count;

        try {
            URL url = new URL(mediaUrl);
            URLConnection connection = url.openConnection();
            connection.connect();
            int lefOfFile = connection.getContentLength();
            InputStream input = new BufferedInputStream(url.openStream());
            File storageDir = new File(Environment
                    .getExternalStorageDirectory() + "/ashal/");
            if (!storageDir.exists())
                storageDir.mkdirs();


            OutputStream output = new FileOutputStream(Environment
                    .getExternalStorageDirectory() + "/ashal/"+ filename);

            byte data[] = new byte[1024];
            long total = 0;
            while ((count = input.read(data)) != -1) {
                total += count;
                Log.e("IamgeDownProgress", "" + (int) ((total * 100) / lefOfFile));
                output.write(data, 0, count);
            }
            output.flush();
            output.close();
            input.close();
        } catch (Exception e) {

        }
    }
}
