package com.learning.ashal.activities;

import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import androidx.databinding.DataBindingUtil;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.source.ProgressiveMediaSource;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.util.Util;
import com.learning.ashal.R;
import com.learning.ashal.custom.FileEnDecryptManager;
import com.learning.ashal.databinding.ActivityVideoPlayBinding;
import com.learning.ashal.utilities.LocaleHelper;
import com.learning.ashal.utilities.ProgressDialog;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class VideoPlayActivity extends BaseActivity {

    private ActivityVideoPlayBinding binding;
    private String strUri;
    private SimpleExoPlayer exoPlayer;
    private File destFile;
    private Handler mHandler = new Handler();
    private DataSource.Factory dataSourceFactory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = DataBindingUtil.setContentView(this, R.layout.activity_video_play);

        if(getIntent() != null){
            strUri = getIntent().getStringExtra("uri");
        }

        exoPlayer = new SimpleExoPlayer.Builder(this).build();
        binding.videoplayer.setPlayer(exoPlayer);
        dataSourceFactory = new DefaultDataSourceFactory(this,
                Util.getUserAgent(this, this.getString(R.string.app_name)));
        ProgressDialog.showProgress(this);
        Service service = new Service();
        service.execute();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        exoPlayer.release();
        if(destFile.exists())
            destFile.delete();
        LocaleHelper.onAttach(this);
    }

    public void copy(File src, File dst) throws IOException {
        try (InputStream in = new FileInputStream(src)) {
            try (OutputStream out = new FileOutputStream(dst)) {
                // Transfer bytes from in to out
                byte[] buf = new byte[1024];
                int len;
                while ((len = in.read(buf)) > 0) {
                    out.write(buf, 0, len);
                }
            }
        }
    }

    public class Service extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... f_url) {
            try {
                destFile = new File(getFilesDir(), ".temp");
                if(!destFile.exists())
                    destFile.createNewFile();
                copy(new File(strUri), destFile);
            } catch (IOException e) {
                e.printStackTrace();
            }

            FileEnDecryptManager.getInstance().doDecrypt(destFile.getAbsolutePath());

            return null;
        }

        protected void onProgressUpdate(String... progress) {
            Log.e("MediaDownProgress", progress[0]);
        }

        @Override
        protected void onPostExecute(String file_url) {
            ProgressDialog.hideprogressbar();
            ProgressiveMediaSource mediaSource = new ProgressiveMediaSource.Factory(dataSourceFactory).createMediaSource(Uri.parse(destFile.getAbsolutePath()));
            exoPlayer.prepare(mediaSource, true, false);
            exoPlayer.setPlayWhenReady(true);
        }
    }
}
