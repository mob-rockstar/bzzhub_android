package com.learning.ashal.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class FileModel {
    @SerializedName("id")
    @Expose
    public String id;

    @SerializedName("lessonId")
    @Expose
    public String lessonId;

    @SerializedName("title")
    @Expose
    public String title;

    @SerializedName("file")
    @Expose
    public String file;

    @SerializedName("status")
    @Expose
    public String status;

    @SerializedName("created_at")
    @Expose
    public String created_at;

    @SerializedName("updated_at")
    @Expose
    public String updated_at;

    @SerializedName("extension")
    @Expose
    public String extension;

    @SerializedName("savedFileId")
    @Expose
    public String savedFileId;

    @SerializedName("savedBefore")
    @Expose
    public Boolean savedBefore;
}
