package com.learning.ashal.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.learning.ashal.R;
import com.learning.ashal.databinding.RowMathBinding;
import com.learning.ashal.databinding.RowMathListBinding;
import com.learning.ashal.model.LastCourseModel;

import java.util.ArrayList;
import java.util.List;

public class MathListAdapter extends RecyclerView.Adapter<MathListAdapter.MyViewHolder> implements Filterable {

    private OnItemClickListener onItemClickListener;
    private List<LastCourseModel> lastCourseModelList;
    private List<LastCourseModel> mOriginalList;
    private Context context;

    public MathListAdapter(Context context, OnItemClickListener onItemClickListener){
        this.context = context;
        this.onItemClickListener = onItemClickListener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowMathListBinding binding = DataBindingUtil.inflate( LayoutInflater.from(parent.getContext()), R.layout.row_math_list, parent, false);
        return new MyViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        LastCourseModel lastCourseModel = lastCourseModelList.get(position);
        holder.binding.row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onItemClickListener.onClick(lastCourseModel);
            }
        });

        holder.binding.btBrowseCourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClickListener.onClick(lastCourseModel);
            }
        });

        if(lastCourseModel.isPurchasedBefore){
            holder.binding.btAddToCart.setBackgroundColor(context.getResources().getColor(R.color.colorGrey));
            holder.binding.btAddToCart.setEnabled(false);
        }else{
            holder.binding.btAddToCart.setBackgroundColor(context.getResources().getColor(R.color.colorYellow));
            holder.binding.btAddToCart.setEnabled(true);
        }

        holder.binding.btAddToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onItemClickListener.addToCart(lastCourseModel);
            }
        });

        if(lastCourseModel.image != null)
            Glide.with(context).load(lastCourseModel.image).into(holder.binding.imgCourse);
        else
            Glide.with(context).load(R.drawable.placeholder).into(holder.binding.imgCourse);

        holder.binding.txtDesc.setText(lastCourseModel.description);
        holder.binding.txtTeacherName.setText(lastCourseModel.firstName);
        holder.binding.rb.setRating(Float.parseFloat(lastCourseModel.rating));
        holder.binding.title.setText(lastCourseModel.title);

    }

    public void setData(List<LastCourseModel> list){
        this.lastCourseModelList = list;
        mOriginalList = list;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if(lastCourseModelList != null )
            return lastCourseModelList.size();
        return 0;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private RowMathListBinding binding;
        public MyViewHolder(RowMathListBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public interface OnItemClickListener{
        void onClick(LastCourseModel lastCourseModel);
        void addToCart(LastCourseModel lastCourseModel);
    }

    protected List<LastCourseModel> getFilteredResults(String constraint) {
        List<LastCourseModel> results = new ArrayList<>();

        for (LastCourseModel item : lastCourseModelList) {
            if (item.firstName.toLowerCase().contains(constraint) ||
                    item.lastName.toLowerCase().contains(constraint) ||
                    item.description.toLowerCase().contains(constraint)) {
                results.add(item);
            }
        }
        return results;
    }

    @Override
    public Filter getFilter() {

        return new Filter() {

            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                List<LastCourseModel> filteredResults = null;
                if (constraint.length() == 0) {
                    filteredResults = mOriginalList;
                } else {
                    filteredResults = getFilteredResults(constraint.toString().toLowerCase());
                }

                FilterResults results = new FilterResults();
                results.values = filteredResults;

                return results;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults results) {
                lastCourseModelList = (ArrayList<LastCourseModel>) results.values;
                notifyDataSetChanged();
            }
        };
    }
}
