package com.learning.ashal.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class RegionModel {
    @SerializedName("id")
    @Expose
    public String id;

    @SerializedName("arabicName")
    @Expose
    public String arabicName;

    @SerializedName("englishName")
    @Expose
    public String englishName;

    @SerializedName("status")
    @Expose
    public String status;

    @SerializedName("created_at")
    @Expose
    public String created_at;

    @SerializedName("updated_at")
    @Expose
    public String updated_at;

    @SerializedName("states")
    @Expose
    public List<StateModel> states;

}
