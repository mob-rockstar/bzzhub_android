package com.learning.ashal.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.learning.ashal.R;
import com.learning.ashal.databinding.RowMathBinding;
import com.learning.ashal.model.DownloadedVideoModel;
import com.learning.ashal.model.LessonModel;
import com.learning.ashal.model.UserModel;
import com.learning.ashal.utilities.SavePref;
import com.learning.ashal.utilities.TempStore;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import io.realm.Realm;

public class MathAdapter extends RecyclerView.Adapter<MathAdapter.MyViewHolder> implements Filterable {

    private OnItemClickListener onItemClickListener;
    private List<LessonModel> lessonModelList;
    private List<LessonModel> mOriginalList;
    private Context context;
    private boolean isCoursePurchased;
    private SimpleDateFormat dateParser = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH);

    public MathAdapter(Context context, boolean isCoursePurchased, OnItemClickListener onItemClickListener){
        this.context = context;
        this.onItemClickListener = onItemClickListener;
        this.isCoursePurchased = isCoursePurchased;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowMathBinding binding = DataBindingUtil.inflate( LayoutInflater.from(parent.getContext()), R.layout.row_math, parent, false);
        return new MyViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        LessonModel lessonModel = lessonModelList.get(position);


        holder.binding.row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onItemClickListener.onClick(lessonModel);
            }
        });

        if(lessonModel.cover == null){
            Glide.with(context).load(R.drawable.rect_lesson_play).into(holder.binding.imgCover);
        }else{
            Glide.with(context).load(lessonModel.cover).into(holder.binding.imgCover);
        }

        holder.binding.txtTitle.setText(lessonModel.title);

        try {
            Date date = dateParser.parse(lessonModel.created_at);
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
            holder.binding.txtDate.setText(sdf.format(date));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        if(lessonModel.paid.equals("0")){
            holder.binding.imgFree.setVisibility(View.VISIBLE);
            holder.binding.imgCrown.setVisibility(View.GONE);
        }else{
            holder.binding.imgFree.setVisibility(View.GONE);
            holder.binding.imgCrown.setVisibility(View.VISIBLE);
        }

        if(lessonModel.paid.equals("1")) {
            if (isCoursePurchased) {
                holder.binding.llDownload.setVisibility(View.VISIBLE);
            } else {
                holder.binding.llDownload.setVisibility(View.INVISIBLE);
            }
        }else{
            holder.binding.llDownload.setVisibility(View.VISIBLE);
        }

        if(!lessonModel.alreadyDownloaded){
            Glide.with(context).load(R.drawable.download_active).into(holder.binding.imgDownload);
            holder.binding.txtDownload.setText(context.getString(R.string.download));
            holder.binding.txtDownload.setTextColor(context.getResources().getColor(R.color.colorDownloadText));
        }else{
            Glide.with(context).load(R.drawable.download).into(holder.binding.imgDownload);
            holder.binding.txtDownload.setText(context.getString(R.string.downloaded));
            holder.binding.txtDownload.setTextColor(context.getResources().getColor(R.color.colorDownloadGreyText));
        }

        holder.binding.llDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!lessonModel.alreadyDownloaded){
                    onItemClickListener.onDownload(lessonModel);
                }
            }
        });
    }

    public void setCourseFlag(boolean isCoursePurchased){
        this.isCoursePurchased = isCoursePurchased;
        notifyDataSetChanged();
    }
    public void setData(List<LessonModel> list){
        this.lessonModelList = list;
        mOriginalList = list;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if(lessonModelList != null )
            return lessonModelList.size();
        return 0;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private RowMathBinding binding;
        public MyViewHolder(RowMathBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public interface OnItemClickListener{
        void onClick(LessonModel lessonModel);
        void onDownload(LessonModel lessonModel);
    }

    protected List<LessonModel> getFilteredResults(String constraint) {
        List<LessonModel> results = new ArrayList<>();

        for (LessonModel item : lessonModelList) {
            if (item.description.toLowerCase().contains(constraint) || item.title.toLowerCase().contains(constraint)) {
                results.add(item);
            }
        }
        return results;
    }

    @Override
    public Filter getFilter() {

        return new Filter() {

            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                List<LessonModel> filteredResults = null;
                if (constraint.length() == 0) {
                    filteredResults = mOriginalList;
                } else {
                    filteredResults = getFilteredResults(constraint.toString().toLowerCase());
                }

                FilterResults results = new FilterResults();
                results.values = filteredResults;

                return results;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults results) {
                lessonModelList = (ArrayList<LessonModel>) results.values;
                notifyDataSetChanged();
            }
        };
    }
}
