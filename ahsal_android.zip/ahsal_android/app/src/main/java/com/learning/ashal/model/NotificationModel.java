package com.learning.ashal.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class NotificationModel {
    @SerializedName("id")
    @Expose
    public String id;

    @SerializedName("type")
    @Expose
    public String type;

    @SerializedName("notifiable_type")
    @Expose
    public String notifiable_type;

    @SerializedName("notifiable_id")
    @Expose
    public String notifiable_id;

    @SerializedName("data")
    @Expose
    public String data;

    @SerializedName("read_at")
    @Expose
    public String read_at;

    @SerializedName("created_at")
    @Expose
    public String created_at;

    @SerializedName("updated_at")
    @Expose
    public String updated_at;

    @SerializedName("agoArabic")
    @Expose
    public String agoArabic;

    @SerializedName("arabicTitle")
    @Expose
    public String arabicTitle;
    @SerializedName("title")
    @Expose
    public String title;

    @SerializedName("arabicDescription")
    @Expose
    public String arabicDescription;

    @SerializedName("description")
    @Expose
    public String description;

    @SerializedName("ago")
    @Expose
    public String ago;

}
