package com.learning.ashal.adapter;

import android.app.Activity;
import android.content.Context;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.learning.ashal.R;
import com.learning.ashal.databinding.RowGradeBinding;
import com.learning.ashal.databinding.RowProfileBinding;
import com.learning.ashal.model.GradeModel;
import com.learning.ashal.utilities.LocaleHelper;

import java.util.List;

public class GradeAdapter extends RecyclerView.Adapter<GradeAdapter.MyViewHolder> {

    private OnItemClickListener onItemClickListener;
    private List<GradeModel> gradeModelList;
    private Context context;
    private int deviceWidth;
    private int previousSelected = -1;

    public GradeAdapter(Context context, OnItemClickListener onItemClickListener){
        this.onItemClickListener = onItemClickListener;
        this.context = context;
        DisplayMetrics displaymetrics = new DisplayMetrics();
        ((Activity) context).getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
        deviceWidth = (displaymetrics.widthPixels ) / 5;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowGradeBinding binding = DataBindingUtil.inflate( LayoutInflater.from(parent.getContext()), R.layout.row_grade, parent, false);
        return new MyViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        holder.binding.row.getLayoutParams().width = deviceWidth;
        final GradeModel gradeModel = gradeModelList.get(position);
        if(gradeModel.image == null){
            Glide.with(context).load(R.drawable.placeholder).into(holder.binding.imgGrade);
        }else{
            Glide.with(context).load(gradeModel.image).into(holder.binding.imgGrade);
        }

        if(gradeModel.isSelected){
            holder.binding.imgGrade.setBorderWidth(10);
        }else{
            holder.binding.imgGrade.setBorderWidth(0);
        }

        holder.binding.row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(previousSelected != -1){
                    gradeModelList.get(previousSelected).isSelected = false;
                }
                gradeModel.isSelected = true;
                previousSelected = position;
                onItemClickListener.onClick(gradeModel);
                notifyDataSetChanged();
            }
        });
    }

    public void setData(List<GradeModel> list){
        this.gradeModelList = list;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if(gradeModelList != null )
            return gradeModelList.size();
        return 0;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private RowGradeBinding binding;
        public MyViewHolder(RowGradeBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public interface OnItemClickListener{
        void onClick(GradeModel gradeModel);
    }
}
