package com.learning.ashal.adapter;

import android.app.Activity;
import android.content.Context;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.learning.ashal.R;
import com.learning.ashal.databinding.RowSubjectBinding;
import com.learning.ashal.model.SubjectModel;
import com.learning.ashal.utilities.LocaleHelper;
import com.learning.ashal.utilities.TempStore;

import java.util.List;

public class SubjectAdapter extends RecyclerView.Adapter<SubjectAdapter.MyViewHolder> {

    private OnItemClickListener onItemClickListener;
    private List<SubjectModel> subjectModelList;
    private Context context;
    private String lang;
    private int deviceWidth;

    public SubjectAdapter(){

    }

    public SubjectAdapter(Context context, OnItemClickListener onItemClickListener){
        this.onItemClickListener = onItemClickListener;
        this.context = context;
        lang =LocaleHelper.getLanguage(context);
        DisplayMetrics displaymetrics = new DisplayMetrics();
        ((Activity) context).getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
        deviceWidth = (displaymetrics.widthPixels - 150) / 3;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowSubjectBinding binding = DataBindingUtil.inflate( LayoutInflater.from(parent.getContext()), R.layout.row_subject, parent, false);
        return new MyViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {

        holder.binding.row.getLayoutParams().width = deviceWidth;

        final SubjectModel subjectModel = subjectModelList.get(position);
        if(subjectModel.courseImage == null){
            Glide.with(context).load(R.drawable.placeholder).into(holder.binding.imgCourse);
        }else{
            Glide.with(context).load(subjectModel.courseImage).into(holder.binding.imgCourse);
        }

        if(lang.equals("en")){
            holder.binding.txtCourse.setText(subjectModel.englishName);
        }else{
            holder.binding.txtCourse.setText(subjectModel.arabicName);
        }

        holder.binding.row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onItemClickListener.onClick(subjectModel);
            }
        });
    }

    public void setData(List<SubjectModel> list){
        this.subjectModelList = list;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if(subjectModelList != null )
            return subjectModelList.size();
        return 0;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private RowSubjectBinding binding;
        public MyViewHolder(RowSubjectBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public interface OnItemClickListener{
        void onClick(SubjectModel subjectModel);
    }
}
