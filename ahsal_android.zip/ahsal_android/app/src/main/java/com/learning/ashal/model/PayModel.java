package com.learning.ashal.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PayModel {
    @SerializedName("description")
    @Expose
    public String description;

    @SerializedName("code")
    @Expose
    public String code;

    @SerializedName("returnurl")
    @Expose
    public String returnurl;

    @SerializedName("payment_id")
    @Expose
    public String payment_id;
}
