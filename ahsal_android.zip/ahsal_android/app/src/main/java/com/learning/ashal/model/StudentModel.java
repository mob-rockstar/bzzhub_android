package com.learning.ashal.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class StudentModel implements Serializable {
    @SerializedName("id")
    @Expose
    public String id;

    @SerializedName("parentId")
    @Expose
    public String parentId;

    @SerializedName("gradeId")
    @Expose
    public String gradeId;

    @SerializedName("lastName")
    @Expose
    public String lastName;

    @SerializedName("firstName")
    @Expose
    public String firstName;

    @SerializedName("mobile")
    @Expose
    public String mobile;

    @SerializedName("email")
    @Expose
    public String email;

    @SerializedName("image")
    @Expose
    public String image;

    @SerializedName("state")
    @Expose
    public String state;

    @SerializedName("school")
    @Expose
    public String school;

    @SerializedName("status")
    @Expose
    public String status;

    @SerializedName("created_at")
    @Expose
    public String created_at;

    @SerializedName("updated_at")
    @Expose
    public String updated_at;

    @SerializedName("default")
    @Expose
    public String defaults;

    @SerializedName("gradeArabicName")
    @Expose
    public String gradeArabicName;

    @SerializedName("gradeEnglishName")
    @Expose
    public String gradeEnglishName;

    @SerializedName("regionId")
    @Expose
    public String regionId;

    @SerializedName("courses_count")
    @Expose
    public String courses_count;

    @SerializedName("exams_count")
    @Expose
    public String exams_count;

    @SerializedName("files_count")
    @Expose
    public String files_count;

    public boolean isSelected;
}
