package com.learning.ashal.fragments;

import android.app.Activity;
import android.content.Context;
import android.graphics.Typeface;
import android.os.Build;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.google.android.material.snackbar.Snackbar;
import com.learning.ashal.R;
import com.learning.ashal.activities.BaseActivity;
import com.learning.ashal.custom.CustomQuestionInfoDlg;
import com.learning.ashal.custom.CustomTextView;
import com.learning.ashal.custom.QuestionPopupWindow;
import com.learning.ashal.interfaces.QuestionCallbackListener;
import com.learning.ashal.model.LastCourseModel;
import com.learning.ashal.model.LocalDBCartModel;
import com.learning.ashal.model.MessageEvent;
import com.learning.ashal.model.StudentModel;
import com.learning.ashal.model.UserModel;
import com.learning.ashal.utilities.SavePref;
import com.learning.ashal.utilities.TempStore;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.Objects;

import io.realm.Realm;
import io.realm.RealmResults;

public class BaseFragment extends Fragment {

    protected BaseActivity mActivity;

    public BaseFragment(){

    }

    public void updateUI() {

    }

    public void saveCartToLocalDB(LastCourseModel lastCourseModel){
        Realm realm = Realm.getDefaultInstance();
        realm.beginTransaction();
        LocalDBCartModel localDBCartModel = realm.createObject(LocalDBCartModel.class);
        localDBCartModel.id = lastCourseModel.id;
        localDBCartModel.teacherId = lastCourseModel.teacherId;
        localDBCartModel.firstName = lastCourseModel.firstName;
        localDBCartModel.lastName = lastCourseModel.lastName;
        localDBCartModel.title = lastCourseModel.title;
        localDBCartModel.description = lastCourseModel.description;
        localDBCartModel.image = lastCourseModel.image;
        localDBCartModel.rating = lastCourseModel.rating;
        localDBCartModel.price = lastCourseModel.price;
        localDBCartModel.validity_date = lastCourseModel.validity_date;
        localDBCartModel.isPurchasedBefore = lastCourseModel.isPurchasedBefore;
        realm.commitTransaction();
    }

    public void removeCartItemFromLocalDB(String id){
        Realm realm = Realm.getDefaultInstance();
        RealmResults<LocalDBCartModel> results = realm.where(LocalDBCartModel.class).equalTo("id", id).findAll();
        realm.beginTransaction();
        results.deleteAllFromRealm();
        realm.commitTransaction();
    }

    public void clearCartFromLocalDB(){
        Realm realm = Realm.getDefaultInstance();
        RealmResults<LocalDBCartModel> results = realm.where(LocalDBCartModel.class).findAll();
        realm.beginTransaction();
        results.deleteAllFromRealm();
        realm.commitTransaction();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        if (context instanceof BaseActivity) {
            mActivity = (BaseActivity) context;
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventFragment(MessageEvent messageEvent) {

    }

    public void restart(){
        Objects.requireNonNull(mActivity).finish();
        startActivity(mActivity.getIntent());
    }

    public String getStudentId(){
        UserModel userModel = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel : SavePref.getInstance(mActivity).getUserModel();
        if(userModel == null)
            return null;
        for (StudentModel studentModel: userModel.profiles) {
            if(studentModel.defaults.equals("1")){
                return studentModel.id;
            }
        }
        return null;
    }

    public boolean hasProfile(){
        UserModel userModel = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel : SavePref.getInstance(mActivity).getUserModel();
        if(userModel == null)
            return false;
        if(userModel.profiles.size() > 0){
            return true;
        }
       return false;
    }

    public StudentModel getStudent(){
        UserModel userModel = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel : SavePref.getInstance(mActivity).getUserModel();
        if(userModel == null)
            return null;
        for(StudentModel studentModel: userModel.profiles) {
            if(studentModel.defaults.equals("1")){
                return studentModel;
            }
        }
        return null;
    }

    public void setupUI(View view) {
        // Set up touch listener for non-text box views to hide keyboard.
//        if (!(view instanceof EditText)) {
//            view.setOnTouchListener(new View.OnTouchListener() {
//                public boolean onTouch(View v, MotionEvent event) {
//                    hideSoftKeyboard();
//                    return false;
//                }
//            });
//        }
//
//        //If a layout container, iterate over children and seed recursion.
//        if (view instanceof ViewGroup) {
//            for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
//                View innerView = ((ViewGroup) view).getChildAt(i);
//                setupUI(innerView);
//            }
//        }
    }

    public void hideSoftKeyboard() {
        InputMethodManager inputMethodManager = (InputMethodManager) mActivity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        if(inputMethodManager != null && mActivity.getCurrentFocus() != null)
            inputMethodManager.hideSoftInputFromWindow(mActivity.getCurrentFocus().getWindowToken(), 0);
    }

    public Fragment getCurrentFragment() {
        try {
            int index = this.getFragmentManager().getBackStackEntryCount() - 1;
            FragmentManager.BackStackEntry backEntry = getFragmentManager().getBackStackEntryAt(index);
            String tag = backEntry.getName();
            Fragment fragment = getFragmentManager().findFragmentByTag(tag);
            return fragment;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public void back(){
        hideSoftKeyboard();
        mActivity.back();
    }

    public void showErrorMessage(View view, String msg){
        Snackbar snackbar = Snackbar.make(view, msg, Snackbar.LENGTH_SHORT);
        View sbView = snackbar.getView();
        sbView.setBackgroundColor(ContextCompat.getColor(mActivity, R.color.colorRed));
        TextView tv = sbView.findViewById(R.id.snackbar_text);
        Typeface font = Typeface.createFromAsset(getContext().getAssets(), getString(R.string.SFProDisplay_Regular));
        tv.setTypeface(font);
        tv.setTextColor(getResources().getColor(R.color.colorWhite));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        } else {
            tv.setGravity(Gravity.CENTER_HORIZONTAL);
        }
        snackbar.show();
    }

    public void showSuccessMessage(View view, String msg){
        Snackbar snackbar = Snackbar
                .make(view, msg, Snackbar.LENGTH_SHORT);
        View sbView = snackbar.getView();
        sbView.setBackgroundColor(ContextCompat.getColor(mActivity, R.color.colorTransparent));
        TextView tv = sbView.findViewById(R.id.snackbar_text);
        Typeface font = Typeface.createFromAsset(getContext().getAssets(), getString(R.string.SFProDisplay_Regular));
        tv.setTypeface(font);
        tv.setTextColor(getResources().getColor(R.color.colorSuccess));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        } else {
            tv.setGravity(Gravity.CENTER_HORIZONTAL);
        }
        snackbar.show();
    }

    private QuestionPopupWindow popupWindow;
    public void openQuestionDlg(String question, View parent, QuestionCallbackListener questionCallbackListener){
        View view = ((LayoutInflater)mActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.dialog_layout_question, null);
        CustomTextView txtQuestion = view.findViewById(R.id.txtQuestion);
        txtQuestion.setText(question);
        popupWindow = new QuestionPopupWindow(view, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.btYes:
                        questionCallbackListener.onYes();
                        break;
                    case R.id.btNo:
                        questionCallbackListener.onNo();
                        break;
                }
                popupWindow.dismiss();
            }
        });
        popupWindow.showAtLocation(parent, Gravity.CENTER, 0, 0);
    }

    public void openQuestionDlg(String question, QuestionCallbackListener questionCallbackListener){
        CustomQuestionInfoDlg dlg = new CustomQuestionInfoDlg(mActivity, question, new CustomQuestionInfoDlg.ItemClickInterface() {
            @Override
            public void onOK() {
                questionCallbackListener.onYes();
            }
        });
        dlg.showDialog();
    }

    public void openQuestionDlg(String question, String yes, String no, QuestionCallbackListener questionCallbackListener){
        CustomQuestionInfoDlg dlg = new CustomQuestionInfoDlg(mActivity, question, yes, no, new CustomQuestionInfoDlg.ItemClickInterface() {
            @Override
            public void onOK() {
                questionCallbackListener.onYes();
            }
        });
        dlg.showDialog();
    }

    public void remvoeSticky(){
        MessageEvent stickyEvent = EventBus.getDefault().getStickyEvent(MessageEvent.class);
        if(stickyEvent != null) {
            EventBus.getDefault().removeStickyEvent(stickyEvent);
        }
    }
}
