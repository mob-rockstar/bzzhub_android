package com.learning.ashal.fragments;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;

import com.google.android.material.button.MaterialButton;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.learning.ashal.R;
import com.learning.ashal.adapter.TeacherQuestionAdapter;
import com.learning.ashal.adapter.TeacherUploadFileAdapter;
import com.learning.ashal.custom.CustomTextView;
import com.learning.ashal.custom.FilePopupWindow;
import com.learning.ashal.databinding.FragmentTeacherAddCourseExamBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.interfaces.QuestionCallbackListener;
import com.learning.ashal.model.FileModel;
import com.learning.ashal.model.MessageEvent;
import com.learning.ashal.model.QuestionModel;
import com.learning.ashal.services.MediaDownloadService;
import com.learning.ashal.utilities.FileOpen;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.app.Activity.RESULT_OK;
import static com.learning.ashal.utilities.Constants.BASE_URL;

public class TeacherAddTestCourseExamFragment extends BaseFragment {

    private String TAG = TeacherAddTestCourseExamFragment.class.getSimpleName();
    private FragmentTeacherAddCourseExamBinding mBinding;
    private TeacherUploadFileAdapter teacherUploadFileAdapter;
    private TeacherQuestionAdapter teacherQuestionAdapter;
    private List<QuestionModel> questionModelList;
    private String lessonId;
    private CustomTextView txtTitle;
    private boolean isFileTab;
    private FileModel fileModel;
    private boolean isNotification;
    private List<FileModel> fileModelList;

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventFragment(MessageEvent messageEvent) {
        if(messageEvent.messageType.equals(MessageEvent.MessageType.QUESTION_REFRESH)
        ||  messageEvent.messageType.equals(MessageEvent.MessageType.ANSWER_REFRESH)){
            isNotification = true;
            callGetQuestionList();
        }
    }

    public TeacherAddTestCourseExamFragment(){

    }

    public TeacherAddTestCourseExamFragment(String lessonId){
        this.lessonId = lessonId;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_teacher_add_course_exam, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    private void initView() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorWhite));

        mBinding.txtTopTitle.setText(getString(R.string.add_test_yourself));
        mBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.back();
            }
        });

        txtTitle = mBinding.getRoot().findViewById(R.id.txtTitle);
        MaterialButton btNext = mBinding.getRoot().findViewById(R.id.btNext);
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isFileTab){
                    openFileDlg();
                }else{
                    FragmentProcess.addFragment(mActivity.getSupportFragmentManager(), new TeacherTestNewQuestionFragment(lessonId), R.id.frameLayout);
                }
            }
        });
        btNext.setBackgroundColor(getResources().getColor(R.color.colorQuestionBk));

        teacherUploadFileAdapter = new TeacherUploadFileAdapter(mActivity, new TeacherUploadFileAdapter.OnItemClickListener() {
            @Override
            public void onDelete(FileModel fileModel) {
                openQuestionDlg(getString(R.string.sure_delete_file), new QuestionCallbackListener() {
                    @Override
                    public void onYes() {
                        callDeleteFile(fileModel);
                    }

                    @Override
                    public void onNo() {

                    }
                });
            }

            @Override
            public void onDownload(FileModel file) {
                fileModel = file;

                String path = Environment.getExternalStorageDirectory() + "/ashal/"+ fileModel.title+"."+fileModel.extension;
                File f = new File(path);
                if(f.exists()){
                    Toast.makeText(mActivity, getResources().getString(R.string.already_downloaded), Toast.LENGTH_SHORT).show();
                    return;
                }
                if(checkAndRequestPermissions()){
                    Toast.makeText(mActivity, getResources().getString(R.string.downloading), Toast.LENGTH_SHORT).show();
                    downloadFile();
                }
            }

            @Override
            public void onClick(FileModel fileModel) {
                try{
                    String path = Environment.getExternalStorageDirectory() + "/ashal/"+ fileModel.title+"."+fileModel.extension;
                    File file = new File(path);
                    if(file.exists()){
                        FileOpen.openFileFromLocal(mActivity, fileModel.file, file);
                    }else{
                        FileOpen.openFile(mActivity, fileModel.file);
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });

        teacherQuestionAdapter = new TeacherQuestionAdapter(mActivity, new TeacherQuestionAdapter.OnItemClickListener() {
            @Override
            public void onClick(QuestionModel questionModel) {
                FragmentProcess.addFragment(mActivity.getSupportFragmentManager(), new TeacherTestNewQuestionFragment(lessonId, questionModel), R.id.frameLayout);
            }

            @Override
            public void onDelete(QuestionModel questionModel) {
                openQuestionDlg(getString(R.string.sure_delete_question),  new QuestionCallbackListener() {
                    @Override
                    public void onYes() {
                        callRemoveQuestion(questionModel);
                    }

                    @Override
                    public void onNo() {

                    }
                });
            }
        });

        mBinding.txtTabUploadExamFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectTabUploadExamFile();
            }
        });

        mBinding.txtTabWriteExam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectTabWriteExam();
            }
        });

        selectTabUploadExamFile();
    }

    private FilePopupWindow popupWindow;
    public void openFileDlg(){
        View view = ((LayoutInflater)mActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.dialog_layout_file_upload, null);
        popupWindow = new FilePopupWindow(view, new FilePopupWindow.OnClickListener() {
            @Override
            public void onUpload(String fileTitle) {
                if(fileTitle.isEmpty()){
                    showErrorMessage(mBinding.getRoot(), getString(R.string.enter_file_title));
                }else if(path == null){
                    showErrorMessage(mBinding.getRoot(), getString(R.string.select_file));
                }else{
                    callCreateFile(fileTitle);
                    popupWindow.dismiss();
                }
            }

            @Override
            public void onSelectFile() {
//                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/pdf");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {"application/pdf", "application/vnd.ms-powerpoint", "application/msword"});

                startActivityForResult(Intent.createChooser(intent, "Select a file"), 123);
            }
        });
        popupWindow.showAtLocation(mBinding.getRoot(), Gravity.CENTER, 0, 0);
    }

    private void downloadFile(){
        MediaDownloadService downloadService = new MediaDownloadService(fileModel.file, fileModel.title+"."+fileModel.extension,
                mActivity);
        downloadService.execute();
    }

    private  boolean checkAndRequestPermissions() {
        int permissionReadStorage = ContextCompat.checkSelfPermission(mActivity, Manifest.permission.READ_EXTERNAL_STORAGE);
        int permissionWriteStorage = ContextCompat.checkSelfPermission(mActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        List<String> listPermissionsNeeded = new ArrayList<>();
        if (permissionWriteStorage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }

        if (permissionReadStorage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }

        if (!listPermissionsNeeded.isEmpty()) {
            this.requestPermissions(listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), 1);
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            Map<String, Integer> perms = new HashMap<>();
            perms.put(Manifest.permission.WRITE_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
            perms.put(Manifest.permission.READ_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
            if (grantResults.length > 0) {
                for (int i = 0; i < permissions.length; i++)
                    perms.put(permissions[i], grantResults[i]);
                if (perms.get(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                        && perms.get(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                    downloadFile();
                }
            }
        }
    }

    private void selectTabUploadExamFile(){
        isFileTab = true;
        mBinding.txtTabUploadExamFile.setBackgroundColor(getResources().getColor(R.color.colorTab));
        mBinding.txtTabWriteExam.setBackgroundColor(getResources().getColor(R.color.colorWhite));
        mBinding.rvTeacherMath.setAdapter(teacherUploadFileAdapter);
        txtTitle.setText(getResources().getString(R.string.create));
        callGetFileList();
    }

    private void selectTabWriteExam(){
        isFileTab = false;
        mBinding.txtTabUploadExamFile.setBackgroundColor(getResources().getColor(R.color.colorWhite));
        mBinding.txtTabWriteExam.setBackgroundColor(getResources().getColor(R.color.colorTab));
        mBinding.rvTeacherMath.setAdapter(teacherQuestionAdapter);
        txtTitle.setText(getResources().getString(R.string.new_question));
        callGetQuestionList();
    }

    private String path;
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 123 && resultCode == RESULT_OK) {
            Uri selectedfile = data.getData(); //The uri with the location of the file

            String fileName = getFileName( selectedfile);
            if(fileName != null){
                try {
                    ParcelFileDescriptor mInputPFD = mActivity.getContentResolver().openFileDescriptor(selectedfile, "r");
                    FileDescriptor fd = mInputPFD.getFileDescriptor();

                    File file = new File(mActivity.getCacheDir(), fileName);
                    path = file.getAbsolutePath();

                    FileInputStream input;
                    FileOutputStream output;
                    input = new FileInputStream(fd);
                    output = new FileOutputStream(path);
                    int read;
                    byte[] bytes = new byte[4096];
                    while ((read = input.read(bytes)) != -1) {
                        output.write(bytes, 0, read);
                    }
                    input.close();
                    output.close();

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public String getFileName(Uri uri) {
        String result = null;
        if (uri.getScheme().equals("content")) {
            Cursor cursor = mActivity.getContentResolver().query(uri, null, null, null, null);
            try {
                if (cursor != null && cursor.moveToFirst()) {
                    result = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                }
            } finally {
                cursor.close();
            }
        }
        if (result == null) {
            result = uri.getPath();
            int cut = result.lastIndexOf('/');
            if (cut != -1) {
                result = result.substring(cut + 1);
            }
        }
        return result;
    }

    private void callGetFileList(){
        if(!isNotification)
            ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.fileList(lessonId);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if(!isNotification)
                    ProgressDialog.hideprogressbar();
                isNotification = false;
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<List<FileModel>>() {}.getType();
                            try{
                                fileModelList = gson.fromJson(jsonObject.get("data").getAsJsonArray(), type);
                                if(fileModelList != null && fileModelList.size() > 0){
                                    teacherUploadFileAdapter.setData(fileModelList);
                                    mBinding.txtNoData.setVisibility(View.GONE);
                                }else{
                                    teacherUploadFileAdapter.setData(null);
                                    mBinding.txtNoData.setVisibility(View.VISIBLE);
                                }
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                if(!isNotification)
                    ProgressDialog.hideprogressbar();
                isNotification = false;
            }
        });
    }

    private void callGetQuestionList(){
        if(!isNotification)
            ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.questionTestList(lessonId);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if(!isNotification)
                    ProgressDialog.hideprogressbar();
                isNotification = false;
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<List<QuestionModel>>() {}.getType();
                            try{
                                questionModelList = gson.fromJson(jsonObject.get("data").getAsJsonArray(), type);
                                if(questionModelList != null && questionModelList.size() > 0){
                                   teacherQuestionAdapter.setData(questionModelList);
                                   mBinding.txtNoData.setVisibility(View.GONE);
                                }else{
                                    teacherQuestionAdapter.setData(null);
                                    mBinding.txtNoData.setVisibility(View.VISIBLE);
                                }
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                if(!isNotification)
                    ProgressDialog.hideprogressbar();
                isNotification = false;
            }
        });
    }

    private void callCreateFile(String title) {
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        RequestBody titleReq = RequestBody.create(MediaType.parse("text/plain"), title);
        RequestBody lessonIdReq = RequestBody.create(MediaType.parse("text/plain"), lessonId);

        MultipartBody.Part file = null;
        if (path != null && new File(path).exists()) {
            File f = new File(path);
            RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), f);
            file = MultipartBody.Part.createFormData("file", f.getName(), requestFile);
        }

        Call<JsonObject> call = apiInterface.createFile(titleReq, lessonIdReq, file);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                path = null;
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if(jsonObject.get("status").getAsBoolean()) {
                            isNotification = true;
                            callGetFileList();
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                } else {
                    Log.e(TAG, "response error: " + response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                path = null;
                ProgressDialog.hideprogressbar();
                Log.e(TAG, "response fail error: " + t.getMessage());
            }
        });
    }

    private void callDeleteFile(FileModel fileModel){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.deleteFile(fileModel.id);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            fileModelList.remove(fileModel);
                            teacherUploadFileAdapter.notifyDataSetChanged();
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private void callRemoveQuestion(QuestionModel questionModel){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.removeTestQuestion(questionModel.id);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            questionModelList.remove(questionModel);
                            teacherQuestionAdapter.notifyDataSetChanged();
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }
}
