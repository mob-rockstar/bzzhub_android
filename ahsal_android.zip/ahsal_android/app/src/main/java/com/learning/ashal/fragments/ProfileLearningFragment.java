package com.learning.ashal.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.databinding.DataBindingUtil;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.learning.ashal.R;
import com.learning.ashal.adapter.ProfileLearningAdapter;
import com.learning.ashal.databinding.FragmentLearningProfileBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.model.AchievementModel;
import com.learning.ashal.model.CourseModel;
import com.learning.ashal.model.ExamResultModel;
import com.learning.ashal.model.StudentModel;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import com.learning.ashal.utilities.SavePref;
import com.learning.ashal.utilities.TempStore;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.learning.ashal.utilities.Constants.BASE_URL;

public class ProfileLearningFragment extends BaseFragment {

    private String TAG = ProfileLearningFragment.class.getSimpleName();
    private FragmentLearningProfileBinding mBinding;
    private ProfileLearningAdapter profileLearningAdapter;
    private StudentModel studentModel;

    public ProfileLearningFragment(){

    }

    public ProfileLearningFragment(StudentModel studentModel){
        this.studentModel = studentModel;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_learning_profile, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    private void initView() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorPrimary));

        profileLearningAdapter = new ProfileLearningAdapter(mActivity);
        mBinding.rvProfile.setAdapter(profileLearningAdapter);


        mBinding.txtProfileInActive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.clearBackStack();
                FragmentProcess.replaceFragment(mActivity.getSupportFragmentManager(), new ProfileNewFragment(studentModel), R.id.frameLayout);
            }
        });

        mBinding.txtCoursesInActive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.clearBackStack();
                FragmentProcess.replaceFragment(mActivity.getSupportFragmentManager(), new ProfileCourseFragment(studentModel), R.id.frameLayout);
            }
        });

        callGetMyCourses();
        callGetExamResults();
    }

    private void callGetExamResults(){
        if(getStudentId() == null){
            Toast.makeText(mActivity, getString(R.string.select_default_student), Toast.LENGTH_SHORT).show();
            return;
        }
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.examResults(getStudentId());
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<List<ExamResultModel>>() {}.getType();
                            try{
                                List<ExamResultModel> examResultModelList = gson.fromJson(jsonObject.get("data").getAsJsonArray(), type);
                                if (examResultModelList != null && examResultModelList.size() > 0) {
                                    mBinding.txtNoData.setVisibility(View.GONE);
                                    profileLearningAdapter.setData(examResultModelList);
                                }else{
                                    profileLearningAdapter.setData(null);
                                    mBinding.txtNoData.setVisibility(View.VISIBLE);
                                }
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                } else {
                    Log.e(TAG, "response error: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
                Log.e(TAG, "response fail error: "+ t.getMessage());
            }
        });
    }

    private void callGetMyCourses(){
        if(getStudentId() == null){
            Toast.makeText(mActivity, getString(R.string.select_default_student), Toast.LENGTH_SHORT).show();
            return;
        }
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.achievement(getStudentId());
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<AchievementModel>() {}.getType();
                            try{
                                AchievementModel achievementModel = gson.fromJson(jsonObject.get("data").getAsJsonObject(), type);
                                mBinding.txtCompletedCourse.setText(achievementModel.completed);
                                mBinding.txtCourses.setText(achievementModel.total);
                                mBinding.txtExamQuestions.setText(achievementModel.totalQuestion);
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                } else {
                    Log.e(TAG, "response error: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Log.e(TAG, "response fail error: "+ t.getMessage());
            }
        });
    }
}
