package com.learning.ashal.custom;

import android.os.SystemClock;
import android.view.View;

public abstract class SingleClickListener implements View.OnClickListener {
    private long lastClickTime = 0;
    @Override
    public void onClick(View v) {
        // preventing double, using threshold of 1000 ms
        if (SystemClock.elapsedRealtime() - lastClickTime < 1000){
            return;
        }

        lastClickTime = SystemClock.elapsedRealtime();
        performClick(v);
    }

    public abstract void performClick(View v);
}
