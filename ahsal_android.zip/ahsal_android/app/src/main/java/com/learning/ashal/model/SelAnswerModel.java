package com.learning.ashal.model;

public class SelAnswerModel {
    public boolean isDrag;
    public AnswerModel answerModel;
    public String dragAnswer;
    public boolean isCorrect;
}
