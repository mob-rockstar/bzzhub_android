package com.learning.ashal.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;

import com.google.android.material.button.MaterialButton;
import com.learning.ashal.R;
import com.learning.ashal.custom.CustomTextView;
import com.learning.ashal.databinding.FragmentShareBinding;
import com.learning.ashal.utilities.FragmentProcess;

public class ShareFragment extends BaseFragment {

    private String TAG = ShareFragment.class.getSimpleName();
    private FragmentShareBinding mBinding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_share, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    private void initView() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorPrimary));
        CustomTextView label = mBinding.getRoot().findViewById(R.id.label);
        label.setText(getString(R.string.share));
        MaterialButton btNext = mBinding.getRoot().findViewById(R.id.btNext);
        btNext.setBackgroundColor(getResources().getColor(R.color.colorRed));
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentProcess.replaceFragment(mActivity.getSupportFragmentManager(), new LoginFragment(), R.id.frameLayout);
            }
        });
    }
}
