package com.learning.ashal.utilities;

public class Constants {
//    public static String BASE_URL = "http://128.199.82.108/api/"; //test ip
    public static String BASE_URL = "http://admincp.ashal.om/api/";
    public static String SEPERATOR = "@#!";
}
