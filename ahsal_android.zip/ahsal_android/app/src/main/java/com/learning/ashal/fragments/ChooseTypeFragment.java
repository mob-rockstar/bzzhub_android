package com.learning.ashal.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.databinding.DataBindingUtil;

import com.google.android.material.button.MaterialButton;
import com.learning.ashal.R;
import com.learning.ashal.activities.MainActivity;
import com.learning.ashal.activities.SplashActivity;
import com.learning.ashal.databinding.FragmentChooseTypeBinding;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.LocaleHelper;
import com.learning.ashal.utilities.SavePref;

public class ChooseTypeFragment extends BaseFragment {

    private String TAG = ChooseTypeFragment.class.getSimpleName();
    private FragmentChooseTypeBinding mBinding;
    private boolean isTeacherSelected;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_choose_type, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    @Override
    public void updateUI() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorPrimary));
    }

    private void initView() {
        updateUI();
        MaterialButton btNext = mBinding.getRoot().findViewById(R.id.btNext);
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isTeacherSelected){
//                    SavePref.getInstance(mActivity).setLoginTypeTeacher(true);
                }else{
                    SavePref.getInstance(mActivity).setLoginTypeTeacher(false);
                }
                FragmentProcess.replaceFragment(mActivity.getSupportFragmentManager(), new LoginFragment(), R.id.frameLayout);
            }
        });

        mBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mActivity, MainActivity.class);
                startActivity(intent);
                mActivity.finish();
            }
        });

        mBinding.imgStudentUnCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectStudent();
            }
        });


        mBinding.imgTeacherUnCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectTeacher();
            }
        });

        selectStudent();
    }

    private void selectTeacher(){
        Toast.makeText(mActivity, getString(R.string.not_login_as_teacher), Toast.LENGTH_SHORT).show();
        return;
//        isTeacherSelected = true;
//        mBinding.imgStudentUnCheck.setVisibility(View.VISIBLE);
//        mBinding.imgStudentCheck.setVisibility(View.GONE);
//        mBinding.imgTeacherUnCheck.setVisibility(View.GONE);
//        mBinding.imgTeacherCheck.setVisibility(View.VISIBLE);
    }

    private void selectStudent(){
        isTeacherSelected = false;
        mBinding.imgStudentUnCheck.setVisibility(View.GONE);
        mBinding.imgStudentCheck.setVisibility(View.VISIBLE);
        mBinding.imgTeacherUnCheck.setVisibility(View.VISIBLE);
        mBinding.imgTeacherCheck.setVisibility(View.GONE);
    }
}
