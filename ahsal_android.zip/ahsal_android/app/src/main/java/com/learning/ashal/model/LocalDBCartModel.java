package com.learning.ashal.model;

import io.realm.RealmObject;
import io.realm.annotations.Required;

public class LocalDBCartModel extends RealmObject {

    @Required
    public String id;

    public String teacherId;

    public String firstName;

    public String lastName;

    public String title;

    public String description;

    public String image;

    public String rating;

    public String price;

    public String validity_date;

    public Boolean isPurchasedBefore;
}