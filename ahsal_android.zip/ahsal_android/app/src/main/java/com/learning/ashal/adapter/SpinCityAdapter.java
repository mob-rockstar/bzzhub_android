package com.learning.ashal.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.learning.ashal.model.StateModel;
import com.learning.ashal.utilities.LocaleHelper;

import java.util.List;

public class SpinCityAdapter extends ArrayAdapter<StateModel> {

    private Context context;
    private List<StateModel> values;
    private String lang;

    public SpinCityAdapter(Context context, int textViewResourceId,
                           List<StateModel>  values) {
        super(context, textViewResourceId, values);
        this.context = context;
        this.values = values;
        lang = LocaleHelper.getLanguage(context);
    }

    @Override
    public int getCount(){
        return values.size();
    }

    @Override
    public StateModel getItem(int position){
        return values.get(position);
    }

    @Override
    public long getItemId(int position){
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        TextView label = (TextView) super.getView(position, convertView, parent);
        if(lang.equals("en")){
            label.setText(values.get(position).englishName);
        }else{
            label.setText(values.get(position).arabicName);
        }
        return label;
    }

   /* @Override
    public boolean isEnabled(int position) {
        if (position == 0) {
            // Disable the first item from Spinner
            // First item will be use for hint
            return false;
        } else {
            return true;
        }
    }*/

    @Override
    public View getDropDownView(int position, View convertView,
                                ViewGroup parent) {
        TextView label = (TextView) super.getDropDownView(position, convertView, parent);
        if(lang.equals("en")){
            label.setText(values.get(position).englishName);
        }else{
            label.setText(values.get(position).arabicName);
        }

//        if (position == 0) {
//            // Set the hint text color gray
//            label.setTextColor(Color.GRAY);
//        } else {
//            label.setTextColor(Color.WHITE);
//        }

        return label;
    }
}
