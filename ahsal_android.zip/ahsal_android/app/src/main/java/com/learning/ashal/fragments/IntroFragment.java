package com.learning.ashal.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.databinding.DataBindingUtil;
import com.google.android.material.button.MaterialButton;
import com.learning.ashal.R;
import com.learning.ashal.activities.LoginActivity;
import com.learning.ashal.activities.MainActivity;
import com.learning.ashal.databinding.FragmentIntroBinding;
import com.learning.ashal.model.IntroModel;

public class IntroFragment extends BaseFragment {

    private IntroModel mIntroModel;
    private FragmentIntroBinding mbinding;
    private static OnNextClickListener onNextClickListener;

    public interface OnNextClickListener{
        void onClick();
    }

    public IntroFragment() {
        // Required empty public constructor
    }

    public static IntroFragment newInstance(IntroModel introModel, OnNextClickListener listener) {
        onNextClickListener = listener;
        IntroFragment fragment = new IntroFragment();
        Bundle args = new Bundle();
        args.putSerializable("introData", introModel);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mIntroModel = (IntroModel) getArguments().getSerializable("introData");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mbinding = DataBindingUtil.inflate(inflater, R.layout.fragment_intro, container, false);
        View view = mbinding.getRoot();
        initView();
        return view;
    }

    private void initView() {
        mbinding.txtLabel.setText(mIntroModel.strTitle);
        mbinding.txtDesc.setText(mIntroModel.strDesc);
        mbinding.imgBgGif.setImageResource(mIntroModel.imgResourceId);

        MaterialButton btNext = mbinding.getRoot().findViewById(R.id.btNext);
        btNext.setBackgroundColor(getResources().getColor(R.color.colorRed));
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onNextClickListener.onClick();
            }
        });

        mbinding.txtAction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mActivity, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        });
    }
}