package com.learning.ashal.interfaces;

public interface QuestionCallbackListener {
    void onYes();
    void onNo();
}
