package com.learning.ashal.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.databinding.DataBindingUtil;
import com.google.android.material.button.MaterialButton;
import com.google.gson.JsonObject;
import com.learning.ashal.R;
import com.learning.ashal.custom.CustomTextView;
import com.learning.ashal.databinding.FragmentChangePwdBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.LocaleHelper;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import com.learning.ashal.utilities.SavePref;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.learning.ashal.utilities.Constants.BASE_URL;

public class ChangePwdFragment extends BaseFragment {

    private String TAG = ChangePwdFragment.class.getSimpleName();
    private FragmentChangePwdBinding mBinding;
    private String id;

    public ChangePwdFragment(){

    }

    public ChangePwdFragment(String id){
        this.id = id;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_change_pwd, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    @Override
    public void updateUI() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorPrimary));
    }

    private void initView() {
        updateUI();
        MaterialButton btNext = mBinding.getRoot().findViewById(R.id.btNext);
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkValidForm()){
                    if(SavePref.getInstance(mActivity).isLoginTypeTeacher()){
                        callTeacherResetPwd();
                    }else{
                        callResetPwd();
                    }
                }
            }
        });

        mBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.back();
            }
        });

        CustomTextView txtTitle = mBinding.getRoot().findViewById(R.id.txtTitle);
        txtTitle.setText(getResources().getString(R.string.login_again));

    }

    private boolean checkValidForm(){
        if(mBinding.etPwd.getText().toString().isEmpty()){
            showErrorMessage(mBinding.parent, getString(R.string.pwd_required));
            return false;
        }

        if(mBinding.etConfirmPwd.getText().toString().isEmpty()){
            showErrorMessage(mBinding.parent, getString(R.string.confirm_pwd_required));
            return false;
        }

        if(!mBinding.etPwd.getText().toString().equals(mBinding.etConfirmPwd.getText().toString())){
            showErrorMessage(mBinding.parent, getString(R.string.pwd_not_matched));
            return false;
        }

        return true;
    }

    private void callResetPwd(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.resetPassword(id, mBinding.etPwd.getText().toString());
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            mActivity.clearBackStack();
                            FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new LoginFragment(), R.id.frameLayout);
                        }else{
                            showErrorMessage(mBinding.getRoot(),  jsonObject.get("message").getAsString());
                        }
                    }
                } else {
                    Log.e(TAG, "response error: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
                Log.e(TAG, "response fail error: "+ t.getMessage());
            }
        });
    }

    private void callTeacherResetPwd(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.resetTeacherPassword(id, mBinding.etPwd.getText().toString());
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            mActivity.clearBackStack();
                            FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new LoginFragment(), R.id.frameLayout);
                        }else{
                            showErrorMessage(mBinding.getRoot(),  jsonObject.get("message").getAsString());
                        }
                    }
                } else {
                    Log.e(TAG, "response error: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
                Log.e(TAG, "response fail error: "+ t.getMessage());
            }
        });
    }
}
