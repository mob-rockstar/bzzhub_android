package com.learning.ashal.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;
import com.learning.ashal.R;
import com.learning.ashal.databinding.RowTeacherGradeBinding;
import com.learning.ashal.model.GradeModel;
import com.learning.ashal.utilities.LocaleHelper;
import java.util.List;

public class TeacherGradeAdapter extends RecyclerView.Adapter<TeacherGradeAdapter.MyViewHolder> {

    private OnItemClickListener onItemClickListener;
    private List<GradeModel> gradeModelList;
    private Context context;
    private boolean mBIsEnglish;

    public TeacherGradeAdapter(Context context, OnItemClickListener onItemClickListener){
        this.onItemClickListener = onItemClickListener;
        this.context = context;
        String lang = LocaleHelper.getLanguage(context);
        if(lang.equals("en")){
            mBIsEnglish = true;
        }else{
            mBIsEnglish = false;
        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowTeacherGradeBinding binding = DataBindingUtil.inflate( LayoutInflater.from(parent.getContext()), R.layout.row_teacher_grade, parent, false);
        return new MyViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        final GradeModel gradeModel = gradeModelList.get(position);

        if(gradeModel.isSelected){
            holder.binding.txtGrade.setTextColor(Color.WHITE);
            holder.binding.txtGrade.setBackground(context.getDrawable(R.drawable.rounded_dark_yellow_bg));
        }else{
            holder.binding.txtGrade.setTextColor(context.getResources().getColor(R.color.colorGrade));
            holder.binding.txtGrade.setBackground(null);
        }

        if(mBIsEnglish){
            holder.binding.txtGrade.setText(gradeModel.englishName);
        }else{
            holder.binding.txtGrade.setText(gradeModel.arabicName);
        }

        holder.binding.txtGrade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                for(GradeModel gradeModel1 : gradeModelList){
                    gradeModel1.isSelected = false;
                }
                gradeModel.isSelected = true;
                notifyDataSetChanged();
                onItemClickListener.onClick(gradeModel);
            }
        });
    }

    public void setData(List<GradeModel> list){
        this.gradeModelList = list;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if(gradeModelList != null )
            return gradeModelList.size();
        return 0;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private RowTeacherGradeBinding binding;
        public MyViewHolder(RowTeacherGradeBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public interface OnItemClickListener{
        void onClick(GradeModel gradeModel);
    }
}
