package com.learning.ashal.fragments;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.DragEvent;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.databinding.DataBindingUtil;

import com.bumptech.glide.Glide;
import com.google.android.material.button.MaterialButton;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.learning.ashal.R;
import com.learning.ashal.activities.VimeoPlayActivity;
import com.learning.ashal.adapter.AnswerAdapter;
import com.learning.ashal.adapter.AnswerTestAdapter;
import com.learning.ashal.adapter.QuestionAdapter;
import com.learning.ashal.custom.CustomTextView;
import com.learning.ashal.databinding.FragmentQuestionBankBinding;
import com.learning.ashal.databinding.FragmentTestBankBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.model.AnswerModel;
import com.learning.ashal.model.QuestionModel;
import com.learning.ashal.model.SelAnswerModel;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.learning.ashal.utilities.Constants.BASE_URL;
import static com.learning.ashal.utilities.Constants.SEPERATOR;

public class TestUnderstandingFragment extends BaseFragment {

    private String TAG = TestUnderstandingFragment.class.getSimpleName();
    private FragmentTestBankBinding mBinding;
    private QuestionAdapter questionAdapter;
    private String lessonId;
    private String title;
    private  List<QuestionModel> questionModelList;
    private int questionNo = 0;
    private int deviceWidth;
    private List<CustomTextView> spaceTextViewList = new ArrayList<>();
    private List<AnswerModel> correctAnswerList = new ArrayList<>();

    public TestUnderstandingFragment(){

    }

    public TestUnderstandingFragment(String title, String id){
        lessonId = id;
        this.title = title;
    }

    @Override
    public void updateUI() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorWhite));
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_test_bank, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    private void initView() {
        DisplayMetrics displaymetrics = new DisplayMetrics();
        mActivity.getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
        deviceWidth = (displaymetrics.widthPixels - 250) / 3;

        updateUI();
        CustomTextView txtTitle = mBinding.getRoot().findViewById(R.id.txtTitle);
        MaterialButton btNext = mBinding.getRoot().findViewById(R.id.btNext);
        btNext.setBackgroundColor(getResources().getColor(R.color.colorQuestionBk));
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean isValid = false;
                if(questionModelList == null)
                    return;
                if(questionNo >= questionModelList.size())
                    return;
                for(AnswerModel answerModel : questionModelList.get(questionNo).answerModelList){
                    if(questionModelList.get(questionNo).type.equals("drag")){
                        for(int i = 0; i < spaceTextViewList.size(); i++){
                            if(!spaceTextViewList.get(i).getText().toString().isEmpty()){
                                selectedAnswer[questionNo].isDrag = true;
                                if(spaceTextViewList.get(i).getText().toString().equals(correctAnswerList.get(i).answer)){
                                    selectedAnswer[questionNo].isCorrect = true;
                                }else{
                                    selectedAnswer[questionNo].isCorrect = false;
                                }
                                isValid = true;
                            }else{
                                isValid = false;
                                break;
                            }
                        }
                    }else{
                        if(answerModel.isSelected){
                            selectedAnswer[questionNo].isDrag = false;
                            selectedAnswer[questionNo].answerModel = answerModel;
                            isValid = true;
                            break;
                        }
                    }
                }


                if(isValid){
                    if(selectedAnswer[questionNo].isDrag){
                        String str = "";
                        for(int i = 0; i < mBinding.dragQuestion.getChildCount(); i++){
                            str += ((TextView)mBinding.dragQuestion.getChildAt(i)).getText().toString();
                        }
                        selectedAnswer[questionNo].dragAnswer = str;
                    }

                    questionNo = questionNo + 1;
                    if(questionModelList != null && questionNo == questionModelList.size() - 1){
                        txtTitle.setText(getString(R.string.submit));
                    }else if(questionModelList != null && questionNo >= questionModelList.size()){
                        callSubmit();
                    }else{
                        txtTitle.setText(getString(R.string.next));
                    }
                    if( questionNo >= questionModelList.size())
                        return;
                    initFromApi();
                }else{
                    Toast.makeText(mActivity, getString(R.string.select_answer), Toast.LENGTH_SHORT).show();
                }
            }
        });

        mBinding.txtSubject.setText(title);
        mBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.back();
            }
        });

        callGetQuestionList();
    }

    private final class ChoiceTouchListener implements View.OnTouchListener {
        @SuppressLint("NewApi")
        public boolean onTouch(View view, MotionEvent motionEvent) {
            if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {

                ClipData data = ClipData.newPlainText("", "");
                View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(view);
                //start dragging the item touched
                view.startDrag(data, shadowBuilder, view, 0);
                return true;
            } else {
                return false;
            }
        }
    }

    @SuppressLint("NewApi")
    private class ChoiceDragListener implements View.OnDragListener {

        @Override
        public boolean onDrag(View viewSpace, DragEvent event) {
            switch (event.getAction()) {
//                case DragEvent.ACTION_DRAG_ENTERED:
//
//                    break;
                case DragEvent.ACTION_DROP:
                    View moveView = (View) event.getLocalState();
                    TextView spaceText = (TextView) viewSpace;
                   if(spaceText.getCurrentTextColor() == getResources().getColor(R.color.colorDragWhite)){
                       return true;
                   }

                    TextView moveText = (TextView) moveView;
                    moveView.setVisibility(View.INVISIBLE);
                    spaceText.setText(moveText.getText().toString());
                    Object tag = spaceText.getTag();
                    if(tag!=null)
                    {
                        int existingID = (Integer)tag;
                        mBinding.getRoot().findViewById(existingID).setVisibility(View.VISIBLE);
                    }
                    spaceText.setTag(moveText.getId());

//                    for(int i=0; i<spaceTextViewList.size(); i++){
//                        if(spaceTextViewList.get(i).getId() == spaceText.getId()){
//                            if(spaceTextViewList.get(i).getText().toString().equals(correctAnswerList.get(i).answer)){
//                                Toast.makeText(mActivity, getString(R.string.correct_answer_msg), Toast.LENGTH_SHORT).show();
//                            }else{
//                                Toast.makeText(mActivity, getString(R.string.wrong_answer_msg), Toast.LENGTH_SHORT).show();
//                            }
//                            break;
//                        }
//                    }
                    break;
                default:
                    break;
            }
            return true;
        }
    }

    private void generateDragTextView(QuestionModel questionModel){

        List<AnswerModel> answerModelList = questionModel.answerModelList;
        mBinding.gridAnswer.removeAllViews();
        mBinding.dragQuestion.removeAllViews();
        spaceTextViewList.clear();
        correctAnswerList.clear();

        //generate answer grid layout
        for(int i = 0 ; i< answerModelList.size(); i++){
            if(answerModelList.get(i).type.equals("text")){
                CustomTextView tv = new CustomTextView(mActivity);
                tv.setId(i);
                LinearLayout.LayoutParams param = new LinearLayout.LayoutParams(
                        deviceWidth,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );
                param.setMargins(5, 20, 5, 20);
                tv.setLayoutParams(param);
                tv.setGravity(Gravity.CENTER);
                tv.setTextSize(14);
                tv.setTextColor(getResources().getColor(R.color.colorDragWhite));
                String asset = getResources().getString(R.string.SFProDisplay_Regular);
                Typeface font = Typeface.createFromAsset(getContext().getAssets(), asset);
                tv.setTypeface(font);
                tv.setMinWidth(200);
                tv.setMinHeight(90);
                tv.setPadding(20, 10, 20, 10);
                tv.setBackground(getResources().getDrawable(R.drawable.rounded_primary_bg_20));
                tv.setOnDragListener(new ChoiceDragListener());
                tv.setText(answerModelList.get(i).answer);
                tv.setOnTouchListener(new ChoiceTouchListener());
                mBinding.gridAnswer.addView(tv);
            }
        }

        for(AnswerModel answerModel : answerModelList){
            if(answerModel.isCorrect.equals("1")){
                correctAnswerList.add(answerModel);
            }
        }
        if(correctAnswerList.size() == 0){
            return;
        }

        String str = questionModel.question;
        for(AnswerModel answerModel: correctAnswerList){
            str = str.replace(answerModel.answer, SEPERATOR);
        }
        //generate question layout
        ArrayList<String> data = new ArrayList<>();

        if(! str.isEmpty()){
            int n;
            while ((n =str.indexOf(SEPERATOR)) != -1){
                if (n != 0) {
                    String cutStr = str.substring(0, n);
                    data.add(cutStr);
                }
                data.add(SEPERATOR);
                str = str.substring(n + SEPERATOR.length());
            }
            if(!str.isEmpty())
                data.add(str);
        }

        int questionId = answerModelList.size() + 1;
        for(String strData: data){
            LinearLayout.LayoutParams lamas = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
//            lamas.bottomMargin = 50;
            CustomTextView tv = new CustomTextView(mActivity);
            tv.setLayoutParams(lamas);
            tv.setTextSize(14);
            String asset = getResources().getString(R.string.SFProDisplay_Regular);
            Typeface font = Typeface.createFromAsset(getContext().getAssets(), asset);
            tv.setTypeface(font);

            if(strData.equals(SEPERATOR)){
                tv.setTextColor(Color.WHITE);
                tv.setGravity(Gravity.CENTER);
                tv.setId(questionId);
                tv.setMinWidth(150);
                tv.setMinHeight(90);
                tv.setPadding(20, 10, 20, 10);
                tv.setBackground(getResources().getDrawable(R.drawable.drag_space_bg));
                tv.setOnDragListener(new ChoiceDragListener());
                spaceTextViewList.add(tv);
            }else{
                tv.setText(strData);
            }
            mBinding.dragQuestion.addView(tv);
            questionId++;
        }
    }

    private void callGetQuestionList(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.questionTestList(lessonId);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<List<QuestionModel>>() {}.getType();
                            try{
                               questionModelList = gson.fromJson(jsonObject.get("data").getAsJsonArray(), type);
                               if(questionModelList != null && questionModelList.size() > 0){
                                   selectedAnswer = new SelAnswerModel[questionModelList.size()];
                                   for(int i = 0 ;i < questionModelList.size(); i++){
                                       selectedAnswer[i] = new SelAnswerModel();
                                   }
                                   answerAdapter = new AnswerTestAdapter(mActivity, new AnswerTestAdapter.OnItemClickListener() {
                                       @Override
                                       public void onClick(AnswerModel answerModel) {
                                           if(answerModel.isCorrect.equals("1")){
//                                               Toast.makeText(mActivity, getString(R.string.correct_answer_msg), Toast.LENGTH_SHORT).show();
                                               if(questionNo >= selectedAnswer.length)
                                                   return;
                                               selectedAnswer[questionNo].isCorrect = true;
                                           }else{
//                                               Toast.makeText(mActivity, getString(R.string.wrong_answer_msg), Toast.LENGTH_SHORT).show();
                                               if(questionNo >= selectedAnswer.length)
                                                   return;
                                               selectedAnswer[questionNo].isCorrect = false;
                                           }
                                       }
                                   });
                                   mBinding.rvAnswer.setAdapter(answerAdapter);
                                   mBinding.scrollView.setVisibility(View.VISIBLE);
                                   mBinding.txtNoData.setVisibility(View.GONE);
                                   initFromApi();
                                   startTimer();
                               }else{
                                   mBinding.scrollView.setVisibility(View.GONE);
                                   mBinding.txtNoData.setVisibility(View.VISIBLE);
                               }

                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    long statTime;
    private SelAnswerModel[] selectedAnswer;
    private AnswerTestAdapter answerAdapter;

    private void startTimer(){
        statTime = System.currentTimeMillis();
    }
    
    private void initFromApi(){
        if(questionNo >= questionModelList.size())
            return;
        QuestionModel questionModel = questionModelList.get(questionNo);
        mBinding.rvAnswer.setVisibility(View.VISIBLE);
        mBinding.gridAnswer.setVisibility(View.GONE);
        if(questionModel.type.equals("text")){
            mBinding.imgQuestion.setVisibility(View.GONE);
            mBinding.dragQuestion.setVisibility(View.GONE);
            mBinding.txtQuestion.setVisibility(View.VISIBLE);
            mBinding.txtQuestion.setText(questionModel.question);
            answerAdapter.setData(questionModel.answerModelList);
        }else if(questionModel.type.equals("image")){
            mBinding.imgQuestion.setVisibility(View.VISIBLE);
            mBinding.txtQuestion.setVisibility(View.GONE);
            mBinding.dragQuestion.setVisibility(View.GONE);
            if(questionModel.file != null)
                Glide.with(mActivity).load(questionModel.file).into(mBinding.imgQuestion);
            answerAdapter.setData(questionModel.answerModelList);
        }else if(questionModel.type.equals("video")){
            mBinding.imgQuestion.setVisibility(View.VISIBLE);
            mBinding.txtQuestion.setVisibility(View.GONE);
            mBinding.dragQuestion.setVisibility(View.GONE);
            if(questionModel.file != null)
                Glide.with(mActivity).load(questionModel.file).into(mBinding.imgQuestion);
            answerAdapter.setData(questionModel.answerModelList);
        }else if(questionModel.type.equals("drag")){
            mBinding.imgQuestion.setVisibility(View.GONE);
            mBinding.txtQuestion.setVisibility(View.GONE);
            mBinding.dragQuestion.setVisibility(View.VISIBLE);
            mBinding.rvAnswer.setVisibility(View.GONE);
            mBinding.gridAnswer.setVisibility(View.VISIBLE);
            generateDragTextView(questionModel);
        }

        mBinding.imgQuestion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(questionModel.type.equals("video")){
                    Intent intent = new Intent(mActivity, VimeoPlayActivity.class);
                    intent.putExtra("uri", questionModel.file);
                    startActivity(intent);
                }
            }
        });
        mBinding.txtQuestionNo.setText(getResources().getString(R.string.question, String.valueOf(questionNo + 1)));
    }

    private  int answerCount = 0;;
    private void callSubmit(){
        if(getStudentId() == null){
            Toast.makeText(mActivity, getString(R.string.select_default_student), Toast.LENGTH_SHORT).show();
            return;
        }
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Map params = new HashMap();
        params.put("lessonId", lessonId);
        params.put("totalQuestions", questionModelList.size());

        answerCount = 0;
        for(int i = 0; i < selectedAnswer.length; i++){
            if(selectedAnswer[i].isCorrect){
                answerCount++;
            }
        }
        params.put("correctAnswers", String.valueOf(answerCount) );

        long diff = System.currentTimeMillis() - statTime;

        int difMiliSec = (int) (diff % 1000);
        int difSeconds = (int) (diff / 1000);
        int difMin = 0;
        int difHour = 0;
        if(difSeconds > 60){
            int temp = difSeconds;
            difSeconds = temp % 60;
            difMin = temp / 60;
        }
        if(difMin > 60){
            int temp = difMin;
            difMin = temp % 60;
            difHour = temp / 60;
        }
        String time = difHour > 0 ? difHour + "hour " + difMin + "min " + difSeconds + " sec" :
                difMin > 0 ? difMin + "min " + difSeconds + " sec" : difMiliSec > 0 ? difSeconds + " sec " + difMiliSec:
                        difMiliSec + "msec";

        params.put("examTime", time);
        params.put("studentId", getStudentId());

        Call<JsonObject> call = apiInterface.submitExamResult(params);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
//                            CustomAlertDlg dlg = new CustomAlertDlg(mActivity, String.valueOf(questionModelList.size()), String.valueOf(answerCount),
//                                    new CustomAlertDlg.ItemClickInterface() {
//                                        @Override
//                                        public void onClick() {
//                                            mActivity.back();
//                                        }
//                                    });
//                            dlg.setCanceledOnTouchOutside(false);
//                            dlg.showDialog();
//
                            FragmentProcess.replaceFragment(mActivity.getSupportFragmentManager(),
                                    new MathTestResultFragment(title, questionModelList, selectedAnswer), R.id.frameLayout);

                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                } else {
                    Log.e(TAG, "response error: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
                Log.e(TAG, "response fail error: "+ t.getMessage());
            }
        });
    }
}
