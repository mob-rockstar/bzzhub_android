package com.learning.ashal.activities;

import android.os.Bundle;
import androidx.databinding.DataBindingUtil;

import com.bumptech.glide.Glide;
import com.learning.ashal.R;
import com.learning.ashal.databinding.ActivityImageViewerBinding;


public class ImageViewerActivity extends BaseActivity {

    private ActivityImageViewerBinding mbinding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mbinding = DataBindingUtil.setContentView(this, R.layout.activity_image_viewer);

        if(getIntent() != null){
            Glide.with(this).load(getIntent().getStringExtra("url")).into(mbinding.image);
        }
    }
}
