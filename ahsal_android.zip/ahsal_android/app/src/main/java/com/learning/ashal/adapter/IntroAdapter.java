package com.learning.ashal.adapter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import com.learning.ashal.fragments.IntroFragment;
import com.learning.ashal.model.IntroModel;
import java.util.ArrayList;

public class IntroAdapter  extends FragmentStatePagerAdapter {

    private ArrayList<IntroModel> introModels;
    private IntroFragment.OnNextClickListener onNextClickListener;

    public IntroAdapter(@NonNull FragmentManager fm, ArrayList<IntroModel> introModels, IntroFragment.OnNextClickListener listener) {
        super(fm, FragmentStatePagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        this.introModels = introModels;
        onNextClickListener = listener;
    }

    @Override
    public Fragment getItem(int position) {
        return IntroFragment.newInstance(introModels.get(position), onNextClickListener);
    }

    @Override
    public int getCount() {
        return introModels.size();
    }

}