package com.learning.ashal.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AchievementModel {
    @SerializedName("completed")
    @Expose
    public String completed;

    @SerializedName("nonCompleted")
    @Expose
    public String nonCompleted;

    @SerializedName("total")
    @Expose
    public String total;

    @SerializedName("totalQuestion")
    @Expose
    public String totalQuestion;
}
