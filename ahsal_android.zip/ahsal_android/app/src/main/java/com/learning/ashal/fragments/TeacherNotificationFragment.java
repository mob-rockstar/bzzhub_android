package com.learning.ashal.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.learning.ashal.R;
import com.learning.ashal.activities.MainActivity;
import com.learning.ashal.activities.TeacherMainActivity;
import com.learning.ashal.adapter.NotificationsAdapter;
import com.learning.ashal.databinding.FragmentNotificationBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.model.NotificationModel;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import com.learning.ashal.utilities.SavePref;
import com.learning.ashal.utilities.TempStore;

import java.lang.reflect.Type;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.learning.ashal.utilities.Constants.BASE_URL;

public class TeacherNotificationFragment extends BaseFragment {

    private String TAG = TeacherNotificationFragment.class.getSimpleName();
    private FragmentNotificationBinding mBinding;
    private NotificationsAdapter notificationsAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_notification, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    private void initView() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorPrimary));
        ((TeacherMainActivity)mActivity).reset();
        notificationsAdapter = new NotificationsAdapter(mActivity);
        mBinding.rvNotification.setAdapter(notificationsAdapter);
        callGetNotifications();
    }

    private void callGetNotifications(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        String id = SavePref.getInstance(mActivity).getTeacherModel() == null ? TempStore.teacherModel.id : SavePref.getInstance(mActivity).getTeacherModel().id;
        Call<JsonObject> call = apiInterface.getTeacherNotifications(id);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<List<NotificationModel>>() {}.getType();
                            try{
                                List<NotificationModel> notificationModelList = gson.fromJson(jsonObject.get("data").getAsJsonArray(), type);
                                if (notificationModelList != null && notificationModelList.size() > 0) {
                                    mBinding.llNoData.setVisibility(View.GONE);
                                    notificationsAdapter.setData(notificationModelList);
                                }else{
                                    notificationsAdapter.setData(null);
                                    mBinding.llNoData.setVisibility(View.VISIBLE);
                                }
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                } else {
                    Log.e(TAG, "response error: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
                Log.e(TAG, "response fail error: "+ t.getMessage());
            }
        });
    }
}
