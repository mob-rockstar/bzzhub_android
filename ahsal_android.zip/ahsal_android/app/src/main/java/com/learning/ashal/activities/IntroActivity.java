package com.learning.ashal.activities;

import android.content.Intent;
import android.os.Bundle;

import androidx.databinding.DataBindingUtil;

import com.learning.ashal.R;
import com.learning.ashal.adapter.IntroAdapter;
import com.learning.ashal.databinding.ActivityIntroBinding;
import com.learning.ashal.fragments.IntroFragment;
import com.learning.ashal.model.IntroModel;
import com.learning.ashal.utilities.SavePref;

import java.util.ArrayList;

public class IntroActivity extends BaseActivity {

    private ActivityIntroBinding mbinding;
    private IntroAdapter mIntroAdapter;
    private ArrayList<IntroModel> introModels = new ArrayList<IntroModel>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mbinding = DataBindingUtil.setContentView(this, R.layout.activity_intro);

        SavePref.getInstance(IntroActivity.this).setFirstRunning(false);

//        setStatusBarColor(getResources().getColor(R.color.colorPrimary));

        IntroModel introModel1 = new IntroModel(R.drawable.intro1, getString(R.string.join_us), getString(R.string.enter_information));
        IntroModel introModel2 = new IntroModel(R.drawable.intro2, getString(R.string.discover), getString(R.string.search_teacher));
        IntroModel introModel3 = new IntroModel(R.drawable.intro3, getString(R.string.share), getString(R.string.know_more_about));
        introModels.add(introModel1);
        introModels.add(introModel2);
        introModels.add(introModel3);

        mIntroAdapter = new IntroAdapter(getSupportFragmentManager(), introModels, new IntroFragment.OnNextClickListener() {
            @Override
            public void onClick() {
                int position = mbinding.vpIntro.getCurrentItem();
                if(position == introModels.size() - 1){
                    Intent intent = new Intent(IntroActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                }else{
                    mbinding.vpIntro.setCurrentItem(position + 1);
                }
            }
        });
        mbinding.vpIntro.setAdapter(mIntroAdapter);

        mIntroAdapter.notifyDataSetChanged();
        mbinding.indicator.setViewPager(mbinding.vpIntro);
    }

}
