package com.learning.ashal.adapter;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;
import com.learning.ashal.R;
import com.learning.ashal.databinding.RowAnswerTestDragBinding;
import com.learning.ashal.model.AnswerModel;

import java.util.List;

public class AnswerTestDragAdapter extends RecyclerView.Adapter<AnswerTestDragAdapter.MyViewHolder>{

    private OnItemClickListener onItemClickListener;
    private List<AnswerModel> answerModelList;
    private Context context;


    public AnswerTestDragAdapter(){

    }

    public AnswerTestDragAdapter(Context context, OnItemClickListener onItemClickListener){
        this.context = context;
        this.onItemClickListener = onItemClickListener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowAnswerTestDragBinding binding = DataBindingUtil.inflate( LayoutInflater.from(parent.getContext()), R.layout.row_answer_test_drag, parent, false);
        return new MyViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        holder.binding.txtAnswer.setText(position + "");
        holder.binding.txtAnswer.setOnTouchListener(new ChoiceTouchListener());
    }

    public void setData(List<AnswerModel> list){
        this.answerModelList = list;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if(answerModelList != null )
            return answerModelList.size();
        return 9;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private RowAnswerTestDragBinding binding;
        public MyViewHolder(RowAnswerTestDragBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public interface OnItemClickListener{
        void onClick(AnswerModel answerModel);
    }

    private final class ChoiceTouchListener implements View.OnTouchListener {
        @SuppressLint("NewApi")
        public boolean onTouch(View view, MotionEvent motionEvent) {
            if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {

                ClipData data = ClipData.newPlainText("", "");
                View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(view);
                //start dragging the item touched
                view.startDrag(data, shadowBuilder, view, 0);
                return true;
            } else {
                return false;
            }
        }
    }
}
