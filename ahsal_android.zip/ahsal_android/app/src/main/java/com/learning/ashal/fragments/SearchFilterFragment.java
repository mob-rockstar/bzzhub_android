package com.learning.ashal.fragments;

import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.RadioGroup;
import androidx.databinding.DataBindingUtil;
import com.google.android.material.button.MaterialButton;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.learning.ashal.R;
import com.learning.ashal.activities.MainActivity;
import com.learning.ashal.adapter.CourseNameAdapter;
import com.learning.ashal.custom.CustomTextView;
import com.learning.ashal.databinding.FragmentSearchFilterBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.model.LastCourseModel;
import com.learning.ashal.model.SubjectModel;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import com.learning.ashal.utilities.SavePref;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.learning.ashal.utilities.Constants.BASE_URL;

public class SearchFilterFragment extends BaseFragment {

    private String TAG = SearchFilterFragment.class.getSimpleName();
    private FragmentSearchFilterBinding mBinding;
    private CourseNameAdapter courseNameAdapter;
    private List<SubjectModel> subjectModelList;
    private SubjectModel subjectModel;
    private String sort = "price", rating = "5";

    public SearchFilterFragment(){

    }

    public SearchFilterFragment(List<SubjectModel> subjectModelList){
        this.subjectModelList = subjectModelList;
        subjectModel = subjectModelList.get(0);
        subjectModelList.get(0).isSelected = true;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_search_filter, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    @Override
    public void updateUI() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorWhite));
    }

    private void initView() {
        updateUI();
        MaterialButton btNext = mBinding.getRoot().findViewById(R.id.btNext);
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                callGetCourseList();
            }
        });
        CustomTextView txtTitle = mBinding.getRoot().findViewById(R.id.txtTitle);
        txtTitle.setText(getResources().getString(R.string.apply));

        mBinding.txtCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.back();
            }
        });

        courseNameAdapter = new CourseNameAdapter(mActivity, new CourseNameAdapter.OnItemClickListener() {
            @Override
            public void onClick(SubjectModel param) {
                subjectModel = param;
            }
        });
        mBinding.rvCourseName.setAdapter(courseNameAdapter);
        courseNameAdapter.setData(subjectModelList);

        mBinding.rgSort.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch(checkedId){
                    case R.id.radioLowToHigh:
                        sort = "price";
                            break;
                    case R.id.radioHighToLow:
                        sort = "priceLow";
                        break;
                    case R.id.radioDate:
                        sort = "created_at";
                        break;
                    case R.id.radioAZ:
                        sort = "title";
                        break;
                }
            }
        });
        initRadioReview();
        setFont();
    }

    private void initRadioReview(){
        mBinding.radio5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
               if(b){
                   rating = "5";
                   mBinding.radio4.setChecked(false);
                   mBinding.radio3.setChecked(false);
               }
            }
        });

        mBinding.radio4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    rating = "4";
                    mBinding.radio5.setChecked(false);
                    mBinding.radio3.setChecked(false);
                }
            }
        });

        mBinding.radio3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
              if(b){
                  rating = "3";
                  mBinding.radio5.setChecked(false);
                  mBinding.radio4.setChecked(false);
              }
            }
        });
    }

    private void setFont(){
        String asset = getResources().getString(R.string.SFProDisplay_Regular);
        Typeface font = Typeface.createFromAsset(getContext().getAssets(), asset);
        mBinding.radioFeaturedTitle.setTypeface(font);
        mBinding.radioHighToLow.setTypeface(font);
        mBinding.radioLowToHigh.setTypeface(font);
        mBinding.radioDate.setTypeface(font);
        mBinding.radioAZ.setTypeface(font);
    }

    private void callGetCourseList(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Map params = new HashMap();
        params.put("id", subjectModel.id);
        params.put("sort", sort);
        params.put("rating", rating);
        Call<JsonObject> call = apiInterface.searchCourse(params);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<List<LastCourseModel>>() {}.getType();
                            try{
                                List<LastCourseModel> lastCourseModels = gson.fromJson(jsonObject.get("data").getAsJsonArray(), type);
                                FragmentProcess.addFragment(mActivity.getSupportFragmentManager(), new CourseListFragment(subjectModel, subjectModelList, lastCourseModels), R.id.frameLayout);
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

}
