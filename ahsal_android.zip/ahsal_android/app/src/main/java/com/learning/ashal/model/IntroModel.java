package com.learning.ashal.model;

import java.io.Serializable;

public class IntroModel implements Serializable {
    public int imgResourceId;
    public String strTitle;
    public String strDesc;

    public IntroModel(int imgResourceId, String strTitle, String strDesc){
        this.imgResourceId = imgResourceId;
        this.strTitle = strTitle;
        this.strDesc = strDesc;
    }
}
