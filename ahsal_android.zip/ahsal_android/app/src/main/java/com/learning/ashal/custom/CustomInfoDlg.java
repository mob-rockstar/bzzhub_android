package com.learning.ashal.custom;

import android.app.Dialog;
import android.content.Context;
import android.view.View;

import com.learning.ashal.R;

public class CustomInfoDlg extends Dialog {

    private ItemClickInterface mItemClickInterface;
    private Context mContext;

    public CustomInfoDlg(Context paramContext, String info) {
        super(paramContext, R.style.dialog);

        setContentView(R.layout.dialog_info);
        mContext = paramContext;

        init(info);
    }

    public CustomInfoDlg(Context paramContext, String info, ItemClickInterface itemClickInterface) {
        super(paramContext, R.style.dialog);

        setContentView(R.layout.dialog_info);
        mContext = paramContext;
        this.mItemClickInterface = itemClickInterface;
        init(info);
    }

    private void init(String info){
        CustomButton btOK = findViewById(R.id.btOK);
        CustomTextView txtDlgQuestion = findViewById(R.id.txtDlgQuestion);
        txtDlgQuestion.setText(info);
        btOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mItemClickInterface != null){
                    mItemClickInterface.onClick();
                }
                disMissDialog();
            }
        });
    }

    public void disMissDialog() {
        if (isShowing()) {
            dismiss();
        }
    }

    public void showDialog() {
        if (isShowing())
            dismiss();
        this.show();
    }

    public interface ItemClickInterface{
        void onClick();
    }

}
