package com.learning.ashal.utilities;

import com.learning.ashal.model.LastCourseModel;
import com.learning.ashal.model.TeacherModel;
import com.learning.ashal.model.UserModel;

import java.util.ArrayList;
import java.util.List;

public class TempStore {
    public static UserModel userModel;
    public static TeacherModel teacherModel;
    public static List<LastCourseModel> cartList = new ArrayList<>();
    public static boolean isFromAppLink;
    public static String lessonId;
    public static String cartTotalPrice;
    public static String paymentId;
    public static boolean isLoggedIn;
    public static String gradeId;
}
