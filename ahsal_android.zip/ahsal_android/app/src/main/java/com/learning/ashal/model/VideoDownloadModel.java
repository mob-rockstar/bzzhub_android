package com.learning.ashal.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class VideoDownloadModel {
    @SerializedName("quality")
    @Expose
    public String quality;

    @SerializedName("type")
    @Expose
    public String type;

    @SerializedName("width")
    @Expose
    public String width;

    @SerializedName("height")
    @Expose
    public String height;

    @SerializedName("expires")
    @Expose
    public String expires;

    @SerializedName("link")
    @Expose
    public String link;

    @SerializedName("created_time")
    @Expose
    public String created_time;

    @SerializedName("fps")
    @Expose
    public String fps;

    @SerializedName("size")
    @Expose
    public String size;

    @SerializedName("md5")
    @Expose
    public String md5;

    @SerializedName("public_name")
    @Expose
    public String public_name;

    @SerializedName("size_short")
    @Expose
    public String size_short;

    @SerializedName("grade")
    @Expose
    public GradeModel gradeModel;
}
