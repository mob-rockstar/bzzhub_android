package com.learning.ashal.activities;

import android.os.Bundle;
import android.view.View;

import androidx.databinding.DataBindingUtil;

import com.learning.ashal.R;
import com.learning.ashal.databinding.ActivityTeacherMainBinding;
import com.learning.ashal.fragments.TeacherHomeFragment;
import com.learning.ashal.fragments.TeacherProfileFragment;
import com.learning.ashal.fragments.TeacherSettingFragment;
import com.learning.ashal.utilities.FragmentProcess;

public class TeacherMainActivity extends BaseActivity {

    private ActivityTeacherMainBinding mainBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mainBinding = DataBindingUtil.setContentView(this, R.layout.activity_teacher_main);

        mainBinding.llTabHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectHome();
            }
        });

        mainBinding.llTabChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectChat();
            }
        });

        mainBinding.llTabProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectProfile();
            }
        });

        mainBinding.llTabSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectSetting();
            }
        });

        selectHome();
    }

    public void reset(){
        mainBinding.imgHome.setVisibility(View.VISIBLE);
        mainBinding.llActiveHome.setVisibility(View.GONE);
        mainBinding.imgChat.setVisibility(View.VISIBLE);
        mainBinding.llActiveChat.setVisibility(View.GONE);
        mainBinding.imgProfile.setVisibility(View.VISIBLE);
        mainBinding.llActiveProfile.setVisibility(View.GONE);
        mainBinding.imgSetting.setVisibility(View.VISIBLE);
        mainBinding.llActiveSetting.setVisibility(View.GONE);
    }

    private void selectHome(){
        clearBackStack();
        reset();
        mainBinding.imgHome.setVisibility(View.GONE);
        mainBinding.llActiveHome.setVisibility(View.VISIBLE);
        FragmentProcess.replaceFragment(getSupportFragmentManager(), new TeacherHomeFragment(),  R.id.frameLayout);
    }

    public void selectHomeTabMark(){
        mainBinding.imgHome.setVisibility(View.GONE);
        mainBinding.llActiveHome.setVisibility(View.VISIBLE);
    }

    private void selectChat(){
        clearBackStack();
        reset();
        mainBinding.imgChat.setVisibility(View.GONE);
        mainBinding.llActiveChat.setVisibility(View.VISIBLE);
//        FragmentProcess.replaceFragment(getSupportFragmentManager(), new TeacherMathFragment(),  R.id.frameLayout);
    }

    public void selectChatTabMark(){
        mainBinding.imgChat.setVisibility(View.GONE);
        mainBinding.llActiveChat.setVisibility(View.VISIBLE);
    }

    public void selectProfile(){
        clearBackStack();
        reset();
        mainBinding.imgProfile.setVisibility(View.GONE);
        mainBinding.llActiveProfile.setVisibility(View.VISIBLE);
        FragmentProcess.replaceFragment(getSupportFragmentManager(), new TeacherProfileFragment(),  R.id.frameLayout);
    }

    public void selectProfileTabMark(){
        mainBinding.imgProfile.setVisibility(View.GONE);
        mainBinding.llActiveProfile.setVisibility(View.VISIBLE);
    }

    private void selectSetting(){
        clearBackStack();
        reset();
        mainBinding.imgSetting.setVisibility(View.GONE);
        mainBinding.llActiveSetting.setVisibility(View.VISIBLE);
        FragmentProcess.replaceFragment(getSupportFragmentManager(), new TeacherSettingFragment(),  R.id.frameLayout);
    }

    public void selectSettingTabMark(){
        mainBinding.imgSetting.setVisibility(View.GONE);
        mainBinding.llActiveSetting.setVisibility(View.VISIBLE);
    }
}
