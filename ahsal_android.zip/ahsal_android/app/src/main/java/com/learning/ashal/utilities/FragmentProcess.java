package com.learning.ashal.utilities;

import android.app.Activity;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.learning.ashal.R;

public class FragmentProcess {

    public static void addFragment(FragmentManager supportFragment, Fragment mFragment, int container) {
        FragmentTransaction transaction = supportFragment.beginTransaction();
        transaction.add(container, mFragment, mFragment.getClass().getSimpleName());
        transaction.addToBackStack(mFragment.getClass().getSimpleName());
        transaction.commitAllowingStateLoss();
    }

    public static void addFragmentWithAnimation(FragmentManager supportFragment, Fragment mFragment, int container) {
        FragmentTransaction transaction = supportFragment.beginTransaction();
        transaction.setCustomAnimations(R.anim.slide_in_left, R.anim.slide_out_left, R.anim.slide_out_right, R.anim.slide_in_right);
        transaction.add(container, mFragment, mFragment.getClass().getSimpleName());
        transaction.addToBackStack(mFragment.getClass().getSimpleName());
        transaction.commitAllowingStateLoss();
    }

    public static void addFragmentWithBottomToTopAnimation(FragmentManager supportFragment, Fragment mFragment, int container) {
        FragmentTransaction transaction = supportFragment.beginTransaction();
        transaction.setCustomAnimations(R.anim.slide_in_down, R.anim.slide_out_down, R.anim.slide_out_top, R.anim.slide_in_top);
        transaction.add(container, mFragment, mFragment.getClass().getSimpleName());
        transaction.addToBackStack(mFragment.getClass().getSimpleName());
        transaction.commitAllowingStateLoss();
    }

    public static void addFragment(FragmentManager supportFragment, Fragment mFragment, Bundle bundle, int container) {
        if (bundle != null) {
            mFragment.setArguments(bundle);
        }
        FragmentTransaction transaction = supportFragment.beginTransaction();
        transaction.add(container, mFragment, mFragment.getClass().getSimpleName());
        transaction.addToBackStack(mFragment.getClass().getSimpleName());
        transaction.commitAllowingStateLoss();
    }

    public static void replaceFragment(FragmentManager supportFragment, Fragment fragment, Bundle bundle, int layout) {
        if (bundle != null) {
            fragment.setArguments(bundle);
        }
        FragmentTransaction transaction =supportFragment.beginTransaction();
        transaction.replace(layout, fragment, fragment.getClass().getSimpleName());
        transaction.addToBackStack(fragment.getClass().getSimpleName());
        transaction.commitAllowingStateLoss();
    }

    public static void replaceFragment(FragmentManager supportFragment, Fragment fragment, int layout) {
        FragmentTransaction transaction =supportFragment.beginTransaction();
        transaction.replace(layout, fragment, fragment.getClass().getSimpleName());
        transaction.addToBackStack(fragment.getClass().getSimpleName());
        transaction.commitAllowingStateLoss();
    }

    public static void removeFragment(FragmentManager supportFragment, String tag, Activity mActivity, int container) {
        supportFragment.popBackStack(tag,0);
        //trans.commitAllowingStateLoss();
    }

    public static void clearBackStack(FragmentManager supportFragment){
        supportFragment.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
    }
}
