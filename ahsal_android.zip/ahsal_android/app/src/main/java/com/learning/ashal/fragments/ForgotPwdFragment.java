package com.learning.ashal.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;

import com.google.android.material.button.MaterialButton;
import com.google.gson.JsonObject;
import com.learning.ashal.R;
import com.learning.ashal.custom.CustomTextView;
import com.learning.ashal.databinding.FragmentForgetPwdBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.LocaleHelper;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import com.learning.ashal.utilities.SavePref;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.learning.ashal.utilities.Constants.BASE_URL;

public class ForgotPwdFragment extends BaseFragment {

    private String TAG = ForgotPwdFragment.class.getSimpleName();
    private FragmentForgetPwdBinding mBinding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_forget_pwd, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }



    @Override
    public void updateUI() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorPrimary));
    }

    private void initView() {
        updateUI();
        MaterialButton btNext = mBinding.getRoot().findViewById(R.id.btNext);
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkValidForm()){
                    callCheckMobile();
                }
            }
        });

        mBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.back();
            }
        });

        CustomTextView txtTitle = mBinding.getRoot().findViewById(R.id.txtTitle);
        txtTitle.setText(getResources().getString(R.string.send));

    }

    private boolean checkValidForm(){
        if(mBinding.etPhoneNumber.getText().toString().isEmpty()){
            showErrorMessage(mBinding.parent, getString(R.string.phone_number_required));
            return false;
        }

//        if(!Validation.isValidEmail(mBinding.etEmail.getText().toString())){
//            showErrorMessage(mBinding.parent, getString(R.string.invalid_email));
//            return false;
//        }

        return true;
    }

    private void callCheckMobile(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call;
        if(SavePref.getInstance(mActivity).isLoginTypeTeacher()){
            call = apiInterface.checkTeacherMobile(mBinding.etPhoneNumber.getText().toString().trim());
        }else{
            call = apiInterface.checkMobile(mBinding.etPhoneNumber.getText().toString().trim());
        }
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new OTPFragment(
                                    jsonObject.get("data").getAsString()
                            ), R.id.frameLayout);
                        }else{
                            if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                } else {
                    Log.e(TAG, "response error: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
                Log.e(TAG, "response fail error: "+ t.getMessage());
            }
        });
    }

}
