package com.learning.ashal.custom;

import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;

import androidx.recyclerview.widget.RecyclerView;

import com.learning.ashal.R;
import com.learning.ashal.adapter.StudentListAdapter;
import com.learning.ashal.model.StudentModel;
import com.learning.ashal.model.UserModel;
import com.learning.ashal.utilities.SavePref;
import com.learning.ashal.utilities.TempStore;

public class SelectStudentPopupWindow extends PopupWindow
{
    private CustomTextView btCancel;
    private CustomTextView btApply;
    private RecyclerView rvStudents;
    private OnClickListener onClickListener;
    private StudentModel selectedStudentModel;

    public SelectStudentPopupWindow(final View mMenuView, Context context, OnClickListener paramOnClickListener)
    {
        super(mMenuView , RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT,true);

        this.onClickListener = paramOnClickListener;

        btCancel = mMenuView.findViewById(R.id.btCancel);
        btApply = mMenuView.findViewById(R.id.btApply);
        rvStudents = mMenuView.findViewById(R.id.rvStudents);
        btCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
            }
        });

        btApply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(selectedStudentModel != null){
                    onClickListener.onSelect(selectedStudentModel);
                    dismiss();
                }
            }
        });

        StudentListAdapter studentListAdapter = new StudentListAdapter(context, new StudentListAdapter.OnItemClickListener() {
            @Override
            public void onClick(StudentModel studentModel) {
                selectedStudentModel = studentModel;
            }
        });
        rvStudents.setAdapter(studentListAdapter);

        UserModel userModel = SavePref.getInstance(context).getUserModel() == null ? TempStore.userModel : SavePref.getInstance(context).getUserModel();
        studentListAdapter.setData(userModel.profiles);

        setContentView(mMenuView);
        setFocusable(true);
        setAnimationStyle(R.style.PopupAnimation);
        mMenuView.setOnTouchListener(new View.OnTouchListener()
        {
            public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
            {
                int i = mMenuView.findViewById(R.id.pop_layout).getTop();
                int j = (int)paramMotionEvent.getY();
                if ((paramMotionEvent.getAction() == 1) && (j < i))
                    dismiss();
                return true;
            }
        });
    }

    public interface OnClickListener{
        void onSelect(StudentModel studentModel);
    }
}

