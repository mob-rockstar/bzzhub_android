package com.learning.ashal.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.os.UserManager;
import android.text.InputType;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.learning.ashal.R;
import com.learning.ashal.activities.MainActivity;
import com.learning.ashal.activities.SplashActivity;
import com.learning.ashal.activities.TeacherMainActivity;
import com.learning.ashal.custom.CustomTextView;
import com.learning.ashal.databinding.FragmentLoginBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.model.TeacherModel;
import com.learning.ashal.model.UserModel;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.LocaleHelper;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import com.learning.ashal.utilities.SavePref;
import com.learning.ashal.utilities.TempStore;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.learning.ashal.utilities.Constants.BASE_URL;

public class LoginFragment extends BaseFragment {

    private String TAG = LoginFragment.class.getSimpleName();
    private FragmentLoginBinding mBinding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_login, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    private void initView() {
        if(SavePref.getInstance(mActivity).getFirebaseKey().isEmpty()){
            FirebaseInstanceId.getInstance().getInstanceId()
                    .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                        @Override
                        public void onComplete(@NonNull Task<InstanceIdResult> task) {
                            if (!task.isSuccessful()) {
                                Log.w("SplashActivity", "getInstanceId failed", task.getException());
                                return;
                            }

                            // Get new Instance ID token
                            String token = task.getResult().getToken();
                            SavePref.getInstance(mActivity).setFirebaseKey(token);
                        }
                    });
        }

        MaterialButton btNext = mBinding.getRoot().findViewById(R.id.btNext);
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkValidForm()){
                    if(SavePref.getInstance(mActivity).isLoginTypeTeacher()){
                        callTeacherLogin();
                    }else{
                        try{
                            callLogin();
                        }catch (Exception ex){
                            ex.printStackTrace();
                        }
                    }
                }
            }
        });
        CustomTextView txtTitle = mBinding.getRoot().findViewById(R.id.txtTitle);
        txtTitle.setText(getResources().getString(R.string.sign_in));

        mBinding.txtSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new SignupFragment(), R.id.frameLayout);
            }
        });

        mBinding.txtForgotPwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new ForgotPwdFragment(), R.id.frameLayout);
            }
        });

        mBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentProcess.replaceFragment(mActivity.getSupportFragmentManager(), new ChooseTypeFragment(), R.id.frameLayout);
            }
        });

        mBinding.imgHideEye.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mBinding.imgHideEye.setVisibility(View.GONE);
                mBinding.imgShowEye.setVisibility(View.VISIBLE);
                mBinding.etPwd.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            }
        });

        mBinding.imgShowEye.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mBinding.imgHideEye.setVisibility(View.VISIBLE);
                mBinding.imgShowEye.setVisibility(View.GONE);
                mBinding.etPwd.setTransformationMethod(PasswordTransformationMethod.getInstance());
            }
        });
    }

    private boolean checkValidForm(){
        if(mBinding.etPhoneNumber.getText().toString().isEmpty()){
            showErrorMessage(mBinding.parent, getString(R.string.phone_number_required));
            return false;
        }

        if(mBinding.etPwd.getText().toString().isEmpty()){
            showErrorMessage(mBinding.parent, getString(R.string.pwd_required));
            return false;
        }

        return true;
    }

    private void callLogin(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Map params = new HashMap();
        params.put("mobile", mBinding.etPhoneNumber.getText().toString().trim());
        params.put("password", mBinding.etPwd.getText().toString().trim());
        String lang = LocaleHelper.getPersistedData(mActivity, "ar");
        params.put("language", lang);
        params.put("fcmToken", SavePref.getInstance(mActivity).getFirebaseKey());

        Call<JsonObject> call = apiInterface.login(params);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<UserModel>() {}.getType();
                            try{
                                UserModel userModel = gson.fromJson(jsonObject.get("data").getAsJsonObject(), type);
                                TempStore.isLoggedIn = true;
                                if(mBinding.cbRemember.isChecked()){
                                    SavePref.getInstance(mActivity).saveUserModel(userModel);
                                }else{
                                    TempStore.userModel = userModel;
                                    SavePref.getInstance(mActivity).clearPref();
                                }

                                Intent intent = new Intent(mActivity, MainActivity.class);
//                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(intent);
                                mActivity.finish();
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                } else {
                    Log.e(TAG, "response error: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
                Log.e(TAG, "response fail error: "+ t.getMessage());
            }
        });
    }

    private void callTeacherLogin(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Map params = new HashMap();
        params.put("mobile", mBinding.etPhoneNumber.getText().toString().trim());
        params.put("password", mBinding.etPwd.getText().toString().trim());
        String lang = LocaleHelper.getPersistedData(mActivity, "ar");
        params.put("language", lang);
        params.put("fcmToken", SavePref.getInstance(mActivity).getFirebaseKey());

        Call<JsonObject> call = apiInterface.loginTeacher(params);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<TeacherModel>() {}.getType();
                            try{
                                TeacherModel teacherModel = gson.fromJson(jsonObject.get("data").getAsJsonObject(), type);
                                if(mBinding.cbRemember.isChecked()){
                                    SavePref.getInstance(mActivity).saveTeacherModel(teacherModel);
                                }
                                else{
                                    TempStore.teacherModel = teacherModel;
                                    SavePref.getInstance(mActivity).clearPref();
                                }

                                Intent intent = new Intent(mActivity, TeacherMainActivity.class);
                                startActivity(intent);
                                mActivity.finish();
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }
                    }
                } else {
                    Log.e(TAG, "response error: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
                Log.e(TAG, "response fail error: "+ t.getMessage());
            }
        });
    }
}
