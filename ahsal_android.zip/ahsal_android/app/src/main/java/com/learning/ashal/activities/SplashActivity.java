package com.learning.ashal.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.learning.ashal.R;
import com.learning.ashal.databinding.ActivityLandingBinding;
import com.learning.ashal.utilities.LocaleHelper;
import com.learning.ashal.utilities.SavePref;
import com.learning.ashal.utilities.TempStore;

public class SplashActivity extends BaseActivity {

    private ActivityLandingBinding mBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = DataBindingUtil.setContentView(this, R.layout.activity_landing);
        initView();
    }

    private void initView() {
        new WebView(this).destroy();

        LocaleHelper.onAttach(this);

//        setStatusBarColor(getResources().getColor(R.color.colorWhite));

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if(SavePref.getInstance(SplashActivity.this).isLoginTypeTeacher()){
                    if(SavePref.getInstance(SplashActivity.this).getTeacherModel() == null){
                        Intent intent = new Intent(SplashActivity.this, IntroActivity.class);
                        startActivity(intent);
                    }else{
                        Intent intent = new Intent(SplashActivity.this, TeacherMainActivity.class);
                        startActivity(intent);
                    }
                }else{
                    if(SavePref.getInstance(SplashActivity.this).getUserModel() == null){
                        TempStore.isLoggedIn = false;

                        if(SavePref.getInstance(SplashActivity.this).isFirstRunning()){
                            Intent intent = new Intent(SplashActivity.this, IntroActivity.class);
                            startActivity(intent);
                        }else{
                            Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                            startActivity(intent);
                        }

                    }else{
                        TempStore.isLoggedIn = true;
                        Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                        startActivity(intent);
                    }
                }
                finish();
            }
        }, 3000);


        if(SavePref.getInstance(this).getFirebaseKey().isEmpty()){
            FirebaseInstanceId.getInstance().getInstanceId()
                    .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                        @Override
                        public void onComplete(@NonNull Task<InstanceIdResult> task) {
                            if (!task.isSuccessful()) {
                                Log.w("SplashActivity", "getInstanceId failed", task.getException());
                                return;
                            }

                            // Get new Instance ID token
                            String token = task.getResult().getToken();
                            SavePref.getInstance(SplashActivity.this).setFirebaseKey(token);
                        }
                    });
        }

    }
}
