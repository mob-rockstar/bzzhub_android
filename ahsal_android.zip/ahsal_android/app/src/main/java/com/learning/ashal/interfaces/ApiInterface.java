package com.learning.ashal.interfaces;

import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.Map;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.PartMap;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiInterface {

    @POST("parent/login")
    @FormUrlEncoded
    Call<JsonObject> login(@FieldMap Map<String, String> parmas);

    @POST("teacher/login")
    @FormUrlEncoded
    Call<JsonObject> loginTeacher(@FieldMap Map<String, String> parmas);

    @POST("parent/otp")
    @FormUrlEncoded
    Call<JsonObject> verifyOtp(@FieldMap Map<String, String> parmas);

    @POST("teacher/otp")
    @FormUrlEncoded
    Call<JsonObject> verifyTeacherOtp(@FieldMap Map<String, String> parmas);

    @POST("parent/otp/resend")
    @FormUrlEncoded
    Call<JsonObject> resendOtp(@Field("id") String id);

    @POST("teacher/otp/resend")
    @FormUrlEncoded
    Call<JsonObject> resendTeacherOtp(@Field("id") String id);

    @POST("parent/language")
    @FormUrlEncoded
    Call<JsonObject> updateLanguage(@Field("id") String id, @Field("language") String language);

    @POST("parent/notification")
    @FormUrlEncoded
    Call<JsonObject> updateNotificationStatus(@Field("id") String id, @Field("notificationStatus") String notificationStatus);

    @POST("parent/settings")
    @FormUrlEncoded
    Call<JsonObject> getParentSettings(@Field("id") String id);

    @POST("profile/delete")
    @FormUrlEncoded
    Call<JsonObject> deleteProfile(@Field("id") String id, @Field("parentId") String parentId);

    @POST("profile/default")
    @FormUrlEncoded
    Call<JsonObject> defaultProfile(@Field("id") String id, @Field("parentId") String parentId);

    @POST("parent/profile")
    @FormUrlEncoded
    Call<JsonObject> getProfile(@Field("id") String id);

    @POST("teacher/profile")
    @FormUrlEncoded
    Call<JsonObject> getTeacherProfile(@Field("id") String id);

    @POST("teacher/grade/courses")
    @FormUrlEncoded
    Call<JsonObject> getCourses(@Field("gradeId") String gradeId, @Field("teacherId") String teacherId);

    @POST("parent/logout")
    @FormUrlEncoded
    Call<JsonObject> logout(@Field("id") String id);

    @POST("profile/update")
    @Multipart
    Call<JsonObject> updateStudent(
            @Part("id") RequestBody id,
            @Part("firstName") RequestBody firstName,
            @Part("mobile") RequestBody mobile,
            @Part("email") RequestBody email,
            @Part("state") RequestBody state,
            @Part("school") RequestBody school,
            @Part("gradeId") RequestBody gradeId,
            @Part MultipartBody.Part image);

    @POST("profile/create")
    @Multipart
    Call<JsonObject> createStudent(
            @Part("parentId") RequestBody parentId,
            @Part("firstName") RequestBody firstName,
            @Part("mobile") RequestBody mobile,
            @Part("email") RequestBody email,
            @Part("state") RequestBody state,
            @Part("school") RequestBody school,
            @Part("gradeId") RequestBody gradeId,
            @Part MultipartBody.Part image);


    @POST("parent/create")
    @FormUrlEncoded
    Call<JsonObject> createParent(@FieldMap Map<String, String> parmas);

    @POST("teacher/create")
    @FormUrlEncoded
    Call<JsonObject> createTeacher(@FieldMap Map<String, String> parmas);

    @POST("parent/mobile")
    @FormUrlEncoded
    Call<JsonObject> checkMobile(@Field("mobile") String mobile);

    @POST("teacher/mobile")
    @FormUrlEncoded
    Call<JsonObject> checkTeacherMobile(@Field("mobile") String mobile);

    @POST("parent/password")
    @FormUrlEncoded
    Call<JsonObject> resetPassword(@Field("id") String id, @Field("password") String password);

    @POST("teacher/password")
    @FormUrlEncoded
    Call<JsonObject> resetTeacherPassword(@Field("id") String id, @Field("password") String password);

    @Headers({
            "Accept: application/json",
            "Content-Type: application/json"
    })
    @POST("parent/status")
    Call<JsonObject> deleteAccount(@Body JsonObject jsonObject);

    @POST("parent/notification/get")
    @FormUrlEncoded
    Call<JsonObject> getNotificationStatus(@Field("id") String id);

    @GET("region/list")
    Call<JsonObject> getLocationList();

    @GET("school/list")
    Call<JsonObject> getSchoolList();

    @GET("grade/app/list")
    Call<JsonObject> getGradeList();

    @GET("course/app/list")
    Call<JsonObject> getSubjectList();

    @GET("course/grade/list")
    Call<JsonObject> getStudentSubjectList();

    @POST("courses/myCourses")
    @FormUrlEncoded
    Call<JsonObject> myCourses(@FieldMap Map<String, String> parmas);

    @POST("exam/student/result")
    @FormUrlEncoded
    Call<JsonObject> examResults(@Field("studentId") String studentId);

    @POST("student/achievement")
    @FormUrlEncoded
    Call<JsonObject> achievement(@Field("studentId") String studentId);

    @POST("courses/last")
    Call<JsonObject> lastCourse();

    @POST("home/statistics")
    Call<JsonObject> statistics();

    @POST("course/student")
    @FormUrlEncoded
    Call<JsonObject> checkCourse(@Field("studentId") String studentId, @Field("courseId") String courseId);

    @POST("courses/list")
    @FormUrlEncoded
    Call<JsonObject> courseList(@Field("id") String id, @Field("studentId") String studentId);

    @POST("lesson/list")
    @FormUrlEncoded
    Call<JsonObject> lessonList(@Field("courseId") String courseId);

    @POST("lesson/file/list")
    @FormUrlEncoded
    Call<JsonObject> fileList(@Field("lessonId") String lessonId, @Field("studentId") String studentId);

    @POST("savedfile/add")
    @FormUrlEncoded
    Call<JsonObject> saveFile(@Field("fileId") String fileId, @Field("studentId") String studentId);

    @POST("savedfile/lesson/list")
    @FormUrlEncoded
    Call<JsonObject> getSavedFiles(@Field("lessonId") String lessonId, @Field("studentId") String studentId);

    @POST("bank/question/list")
    @FormUrlEncoded
    Call<JsonObject> questionList(@Field("lessonId") String lessonId, @Field("keyword") String keyword);

    @POST("bank/question/list")
    @FormUrlEncoded
    Call<JsonObject> questionList(@Field("lessonId") String lessonId);

    @POST("test/question/list")
    @FormUrlEncoded
    Call<JsonObject> questionTestList(@Field("lessonId") String lessonId);

    @Headers({
            "Accept: application/json",
            "Content-Type: application/json"
    })
    @POST("coupon/check")
    Call<JsonObject> checkCoupon(@Body JsonObject jsonObject);

    @POST("exam/result")
    @FormUrlEncoded
    Call<JsonObject> submitExamResult(@FieldMap Map<String, String> parmas);

    @POST("savedfile/delete/{fileId}")
    Call<JsonObject> unSaveFile(@Path("fileId") String fileId);

    @POST("savedfile/remove")
    @FormUrlEncoded
    Call<JsonObject> unSaveFileByFileId(@Field("studentId") String studentId, @Field("fileId") String fileId);

    @POST("courses/search")
    @FormUrlEncoded
    Call<JsonObject> searchCourse(@FieldMap Map<String, String> parmas);

    @Headers({
            "Accept: application/json",
            "Content-Type: application/json"
    })
    @POST("pay")
    Call<JsonObject> pay(@Header("Authorization") String auth, @Body JsonObject jsonObject);

    @POST("lesson/check")
    @FormUrlEncoded
    Call<JsonObject> lessonDetail(@Field("lessonId") String lessonId, @Field("studentId") String studentId);

    @POST("lesson/search")
    @FormUrlEncoded
    Call<JsonObject> relativeLesson(@Field("title") String title, @Field("studentId") String studentId);

    @POST("pay/status")
    @FormUrlEncoded
    Call<JsonObject> paymentStatus(@Field("payment_id") String payment_id);

    @Headers({
            "Accept: application/json",
            "Content-Type: application/json"
    })
    @POST("courses/purchase")
    Call<JsonObject> purchaseCourse(@Body JsonObject jsonObject);

    @POST("parent/notifications")
    @FormUrlEncoded
    Call<JsonObject> getNotifications(@Field("parentId") String parentId);

    @POST("lesson/course")
    @FormUrlEncoded
    Call<JsonObject> callGetCoursePerLesson(@Field("lessonId") String lessonId, @Field("studentId") String studentId);

    @POST("teacher/course/create")
    @Multipart
    Call<JsonObject> createCourse(
            @Part("teacherId") RequestBody teacherId,
            @Part("gradeId") RequestBody gradeId,
            @Part("title") RequestBody title,
            @Part("description") RequestBody description,
            @Part MultipartBody.Part image);

    @POST("teacher/course/edit")
    @Multipart
    Call<JsonObject> editCourse(
            @Part("id") RequestBody id,
            @Part("title") RequestBody title,
            @Part("description") RequestBody description,
            @Part MultipartBody.Part image);

    @POST("teacher/language")
    @FormUrlEncoded
    Call<JsonObject> updateTeacherLanguage(@Field("id") String id, @Field("language") String language);

    @POST("teacher/notification")
    @FormUrlEncoded
    Call<JsonObject> updateTeacherNotificationStatus(@Field("id") String id, @Field("notificationStatus") String notificationStatus);

    @POST("teacher/logout")
    @FormUrlEncoded
    Call<JsonObject> logoutTeacher(@Field("id") String id);

    @Headers({
            "Accept: application/json",
            "Content-Type: application/json"
    })
    @POST("teacher/status")
    Call<JsonObject> deleteTeacherAccount(@Body JsonObject jsonObject);

    @POST("teacher/notification/get")
    @FormUrlEncoded
    Call<JsonObject> getTeacherNotificationStatus(@Field("id") String id);

    @POST("teacher/notifications")
    @FormUrlEncoded
    Call<JsonObject> getTeacherNotifications(@Field("teacherId") String parentId);

    @POST("lesson/create")
    @Multipart
    Call<JsonObject> createLesson(
            @Part("courseId") RequestBody courseId,
            @Part("title") RequestBody title,
            @Part("description") RequestBody description,
            @Part("semester") RequestBody semester,
            @Part("file") RequestBody file,
            @Part MultipartBody.Part image);

    @POST("lesson/edit")
    @Multipart
    Call<JsonObject> editLesson(
            @Part("id") RequestBody id,
            @Part("title") RequestBody title,
            @Part("description") RequestBody description,
            @Part("semester") RequestBody semester,
            @Part("file") RequestBody file,
            @Part MultipartBody.Part image);

    @POST("lesson/delete")
    @FormUrlEncoded
    Call<JsonObject> deleteLesson(@Field("id") String lessonId);

    @Headers({
            "Accept: application/json",
            "Content-Type: application/json"
    })
    @POST("teacher/profile/update")
    Call<JsonObject> updateTeacherProfile(@Body JsonObject jsonObject);

    @POST("teacher/profile/image")
    @Multipart
    Call<JsonObject> uploadTeacherImage(
            @Part("id") RequestBody id,
            @Part MultipartBody.Part image);

    @POST("lesson/downloadLink")
    @FormUrlEncoded
    Call<JsonObject> downloadLink(@Field("videoId") String videoId, @Field("courseId") String courseId);

    @POST("lesson/teacher/file/list")
    @FormUrlEncoded
    Call<JsonObject> fileList(@Field("lessonId") String lessonId);

    @POST("lesson/file/create")
    @Multipart
    Call<JsonObject> createFile(
            @Part("title") RequestBody title,
            @Part("lessonId") RequestBody lessonId,
            @Part MultipartBody.Part file);

    @POST("lesson/file/remove")
    @FormUrlEncoded
    Call<JsonObject> deleteFile(@Field("id") String fileId);

    @POST("bank/question/answer/create")
    @Multipart
    Call<JsonObject> createAnswer(
            @PartMap() Map<String, RequestBody> partMap,
            @Part MultipartBody.Part file);

    @POST("test/question/answer/create")
    @Multipart
    Call<JsonObject> createTestAnswer(
            @PartMap() Map<String, RequestBody> partMap,
            @Part MultipartBody.Part file);

    @POST("bank/question/update")
    @Multipart
    Call<JsonObject> updateQuestion(
            @PartMap() Map<String, RequestBody> partMap,
            @Part MultipartBody.Part file);

    @POST("test/question/update")
    @Multipart
    Call<JsonObject> updateTestQuestion(
            @PartMap() Map<String, RequestBody> partMap,
            @Part MultipartBody.Part file);

    @POST("bank/question/create")
    @Multipart
    Call<JsonObject> createQuestion(
            @PartMap() Map<String, RequestBody> partMap,
            @Part MultipartBody.Part file);

    @POST("test/question/create")
    @Multipart
    Call<JsonObject> createTestQuestion(
            @PartMap() Map<String, RequestBody> partMap,
            @Part MultipartBody.Part file);

    @POST("bank/question/answer/list")
    @FormUrlEncoded
    Call<JsonObject> answerList(@Field("questionId") String questionId);

    @POST("test/question/answer/list")
    @FormUrlEncoded
    Call<JsonObject> answerTestList(@Field("questionId") String questionId);

    @POST("bank/question/answer/update")
    @Multipart
    Call<JsonObject> updateAnswer(
            @PartMap() Map<String, RequestBody> partMap,
            @Part MultipartBody.Part file);

    @POST("test/question/answer/update")
    @Multipart
    Call<JsonObject> updateTestAnswer(
            @PartMap() Map<String, RequestBody> partMap,
            @Part MultipartBody.Part file);

    @POST("bank/question/answer/remove")
    @FormUrlEncoded
    Call<JsonObject> removeAnswer(@Field("id") String id);

    @POST("test/question/answer/remove")
    @FormUrlEncoded
    Call<JsonObject> removeTestAnswer(@Field("id") String id);

    @POST("bank/question/remove")
    @FormUrlEncoded
    Call<JsonObject> removeQuestion(@Field("id") String id);

    @POST("test/question/remove")
    @FormUrlEncoded
    Call<JsonObject> removeTestQuestion(@Field("id") String id);


    @POST("parent/profile/update")
    @Multipart
    Call<JsonObject> updateParentProfile(
            @Part("id") RequestBody id,
            @Part("firstName") RequestBody firstName,
            @Part("mobile") RequestBody mobile,
            @Part MultipartBody.Part image);

}
