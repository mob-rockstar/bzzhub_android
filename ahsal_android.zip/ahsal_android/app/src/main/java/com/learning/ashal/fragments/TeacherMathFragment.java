package com.learning.ashal.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;

import com.google.android.material.button.MaterialButton;
import com.learning.ashal.R;
import com.learning.ashal.adapter.MathFileAdapter;
import com.learning.ashal.adapter.TeacherMathAdapter;
import com.learning.ashal.custom.CustomTextView;
import com.learning.ashal.databinding.FragmentTeacherMathBinding;
import com.learning.ashal.databinding.FragmentTermsBinding;

public class TeacherMathFragment extends BaseFragment {

    private String TAG = TeacherMathFragment.class.getSimpleName();
    private FragmentTeacherMathBinding mBinding;
    private TeacherMathAdapter teacherMathAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_teacher_math, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    private void initView() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorWhite));

        teacherMathAdapter = new TeacherMathAdapter();
        mBinding.rvTeacherMath.setAdapter(teacherMathAdapter);

        mBinding.txtTabLesson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectTabLesson();
            }
        });

        mBinding.txtTabFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectTabFile();
            }
        });

        selectTabLesson();
    }

    private void selectTabLesson(){
        mBinding.txtTabLesson.setBackgroundColor(getResources().getColor(R.color.colorTab));
        mBinding.txtTabFile.setBackgroundColor(getResources().getColor(R.color.colorWhite));
    }

    private void selectTabFile(){
        mBinding.txtTabLesson.setBackgroundColor(getResources().getColor(R.color.colorWhite));
        mBinding.txtTabFile.setBackgroundColor(getResources().getColor(R.color.colorTab));
    }
}
