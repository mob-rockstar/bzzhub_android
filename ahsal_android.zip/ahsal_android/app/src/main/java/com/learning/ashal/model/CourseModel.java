package com.learning.ashal.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CourseModel {
    @SerializedName("id")
    @Expose
    public String id;

    @SerializedName("title")
    @Expose
    public String title;

    @SerializedName("arabicName")
    @Expose
    public String arabicName;

    @SerializedName("englishName")
    @Expose
    public String englishName;

    @SerializedName("image")
    @Expose
    public String image;

    @SerializedName("isCompleted")
    @Expose
    public String isCompleted;
}
