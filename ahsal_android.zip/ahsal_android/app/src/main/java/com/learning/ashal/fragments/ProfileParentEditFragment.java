package com.learning.ashal.fragments;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;

import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;

import com.bumptech.glide.Glide;
import com.google.android.material.button.MaterialButton;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.learning.ashal.R;
import com.learning.ashal.activities.MainActivity;
import com.learning.ashal.adapter.SpinCityAdapter;
import com.learning.ashal.adapter.SpinGradeAdapter;
import com.learning.ashal.adapter.SpinRegionAdapter;
import com.learning.ashal.adapter.SpinSchoolAdapter;
import com.learning.ashal.custom.CustomTextView;
import com.learning.ashal.custom.SelectPicPopupWindow;
import com.learning.ashal.databinding.FragmentEditParentProfileBinding;
import com.learning.ashal.databinding.FragmentNewProfileBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.model.GradeModel;
import com.learning.ashal.model.MessageEvent;
import com.learning.ashal.model.RegionModel;
import com.learning.ashal.model.SchoolModel;
import com.learning.ashal.model.StateModel;
import com.learning.ashal.model.StudentModel;
import com.learning.ashal.model.UserModel;
import com.learning.ashal.utilities.AnimationUtils;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.LocaleHelper;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import com.learning.ashal.utilities.SavePref;
import com.learning.ashal.utilities.TempStore;
import com.learning.ashal.utilities.Validation;

import org.greenrobot.eventbus.EventBus;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.app.Activity.RESULT_OK;
import static com.learning.ashal.utilities.Constants.BASE_URL;

public class ProfileParentEditFragment extends BaseFragment {

    private String TAG = ProfileParentEditFragment.class.getSimpleName();
    private FragmentEditParentProfileBinding mBinding;
    UserModel userModel = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel : SavePref.getInstance(mActivity).getUserModel();

    private SelectPicPopupWindow selectPicPopupWindow;
    private String path;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_edit_parent_profile, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    private void initView() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorPrimary));

        mBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.back();
            }
        });

        MaterialButton btNext = mBinding.getRoot().findViewById(R.id.btNext);
        btNext.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkValidation()){
                    callUpdateParentProfile();
                }
            }
        });

        CustomTextView txtTitle = mBinding.getRoot().findViewById(R.id.txtTitle);
        txtTitle.setText(getString(R.string.save));

        mBinding.txtEditPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSelectDlg();
            }
        });

        mBinding.etFirstName.setText(userModel.firstName);
        mBinding.etPhoneNumber.setText(userModel.mobile);
        if(userModel.image != null){
            Glide
                    .with(mActivity)
                    .load(userModel.image)
                    .into(mBinding.imgPhoto);
        }

        AnimationUtils.animateSlideTopFromDown(mActivity, mBinding.scrollview);
    }

    private boolean checkValidation(){

        if(mBinding.etFirstName.getText().toString().isEmpty()){
            showErrorMessage(mBinding.getRoot(), getString(R.string.first_name_required));
            return false;
        }

        if(mBinding.etPhoneNumber.getText().toString().isEmpty()){
            showErrorMessage(mBinding.getRoot(), getString(R.string.phone_number_required));
            return false;
        }

        return true;
    }

    private void openSelectDlg(){
        View view = ((LayoutInflater)mActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.dialog_layout_camera, null);
        selectPicPopupWindow = new SelectPicPopupWindow(view, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.btCancel:
                        selectPicPopupWindow.dismiss();
                        break;
                    case R.id.btCamera:
                        selectPicPopupWindow.dismiss();
                        if (checkAndRequestPermissions()) {
                            openCamera();
                        }
                        break;
                    case R.id.btGallery:
                        selectPicPopupWindow.dismiss();
                        openGallery();
                        break;
                }
            }
        });
        selectPicPopupWindow.showAtLocation(mBinding.getRoot(), Gravity.CENTER, 0, 0);
    }

    private Uri imageUri;
    public void openCamera(){
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "New Picture");
        imageUri = mActivity.getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        startActivityForResult(intent, 1);
    }

    public void openGallery() {
        Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(i, 2);
    }

    public String getRealPathFromURI(Uri contentUri) {
        Cursor cursor = mActivity.getContentResolver().query(contentUri, null, null, null, null);
        if (cursor == null) {
            return contentUri.getPath();
        } else {
            cursor.moveToFirst();
            int index = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            return cursor.getString(index);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if(requestCode == 1){
                try {
//                    path = getRealPathFromURI(imageUri);
                    path = selectImageFromCameraResult(imageUri);
                    Glide
                            .with(mActivity)
                            .load(path)
                            .into(mBinding.imgPhoto);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }else if (requestCode == 2 && data != null) {
                try {
                    selectImageFromGalleryResult(data);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }
    }

    private void selectImageFromGalleryResult(Intent data) {
        Uri uri_data = data.getData();
        try {
            Bitmap originalBitmap = MediaStore.Images.Media.getBitmap(mActivity.getContentResolver(), uri_data);
            int nh = (int) (originalBitmap.getHeight() * (512.0 / originalBitmap.getWidth()));
            Bitmap compressedBitmap = Bitmap.createScaledBitmap(originalBitmap, 512, nh, true);
            File compressedFile = createFileFromBitmap(compressedBitmap, mActivity);
            path = compressedFile.getPath();
            Glide
                    .with(mActivity)
                    .load(path)
                    .into(mBinding.imgPhoto);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String selectImageFromCameraResult(Uri uri) {
        try {
            Bitmap originalBitmap = MediaStore.Images.Media.getBitmap(mActivity.getContentResolver(), uri);
            int nh = (int) (originalBitmap.getHeight() * (512.0 / originalBitmap.getWidth()));
            Bitmap compressedBitmap = Bitmap.createScaledBitmap(originalBitmap, 512, nh, true);
            File compressedFile = createFileFromBitmap(compressedBitmap, mActivity);
            path = compressedFile.getPath();
            return path;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }

    public File createFileFromBitmap(Bitmap bitmap, Context context) {

        Long tsLong = System.currentTimeMillis() / 1000;
        String name = tsLong.toString();

        File filesDir = context.getFilesDir();
        File imageFile = new File(filesDir, name + ".jpg");

        OutputStream os;
        try {
            os = new FileOutputStream(imageFile);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, os);
            os.flush();
            os.close();
        } catch (Exception e) {
            Log.e("NewProductFragment", "Error writing bitmap", e);
        }

        return imageFile;
    }

    private  boolean checkAndRequestPermissions() {
        int permissionCamera = ContextCompat.checkSelfPermission(mActivity, Manifest.permission.CAMERA);
        int permissionReadStorage = ContextCompat.checkSelfPermission(mActivity, Manifest.permission.READ_EXTERNAL_STORAGE);
        int permissionWriteStorage = ContextCompat.checkSelfPermission(mActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        List<String> listPermissionsNeeded = new ArrayList<>();
        if (permissionWriteStorage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (permissionCamera != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.CAMERA);
        }

        if (permissionReadStorage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }

        if (!listPermissionsNeeded.isEmpty()) {
            this.requestPermissions(listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), 1);
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            Map<String, Integer> perms = new HashMap<>();
            perms.put(Manifest.permission.CAMERA, PackageManager.PERMISSION_GRANTED);
            perms.put(Manifest.permission.WRITE_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
            perms.put(Manifest.permission.READ_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
            if (grantResults.length > 0) {
                for (int i = 0; i < permissions.length; i++)
                    perms.put(permissions[i], grantResults[i]);
                if (perms.get(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                        && perms.get(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                        && perms.get(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                    openCamera();
                }
            }
        }
    }

    private void callUpdateParentProfile(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);

        RequestBody id = RequestBody.create(MediaType.parse("text/plain"), userModel.id);
        RequestBody firstName = RequestBody.create(MediaType.parse("text/plain"), mBinding.etFirstName.getText().toString());
        RequestBody mobile = RequestBody.create(MediaType.parse("text/plain"), mBinding.etPhoneNumber.getText().toString());
        MultipartBody.Part image = null;
        if(path!=null && new File(path).exists())
        {
            File file = new File(path);
            RequestBody requestFile =RequestBody.create(MediaType.parse("multipart/form-data"), file);
            image = MultipartBody.Part.createFormData("image", file.getName(), requestFile);
        }

        Call<JsonObject> call = apiInterface.updateParentProfile(id, firstName, mobile, image);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            MessageEvent messageEvent = new MessageEvent();
                            messageEvent.messageType = MessageEvent.MessageType.PROFILE_REFRESH;
                            EventBus.getDefault().post(messageEvent);
                            mActivity.back();
                        }else{
                            if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                } else {
                    Log.e(TAG, "response error: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
                Log.e(TAG, "response fail error: "+ t.getMessage());
            }
        });
    }
}
