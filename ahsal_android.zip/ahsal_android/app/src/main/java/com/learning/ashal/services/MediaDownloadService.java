package com.learning.ashal.services;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import com.learning.ashal.R;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;

public class MediaDownloadService extends AsyncTask<String, String, String> {

    private String mediaUrl, fileName;
    private Context mContext;
    private OnListener onListener;

    public MediaDownloadService(String mediaUrl, String fileName, Context context) {
        mContext = context;
        this.mediaUrl = mediaUrl;
        this.fileName = fileName;
    }

    public MediaDownloadService(String mediaUrl, String fileName, Context context, OnListener onListener) {
        mContext = context;
        this.mediaUrl = mediaUrl;
        this.fileName = fileName;
        this.onListener = onListener;
    }

    @Override
    protected String doInBackground(String... f_url) {
        int count;
        try {
            URL url = new URL(this.mediaUrl);
            URLConnection connection = url.openConnection();
            connection.connect();
            int lefOfFile = connection.getContentLength();
            InputStream input = new BufferedInputStream(url.openStream());
            File storageDir = new File(Environment
                    .getExternalStorageDirectory() + "/ashal/");
            if (!storageDir.exists())
                storageDir.mkdirs();


            OutputStream output = new FileOutputStream(Environment
                    .getExternalStorageDirectory() + "/ashal/"+ fileName);

            byte data[] = new byte[1024];
            long total = 0;
            while ((count = input.read(data)) != -1) {
                total += count;
                publishProgress("" + (int) ((total * 100) / lefOfFile));
                output.write(data, 0, count);
            }
            output.flush();
            output.close();
            input.close();

        } catch (Exception e) {
            Log.e("Error: ", e.getMessage());
            Handler handler = new Handler(Looper.getMainLooper());
            handler.post(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(mContext, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }

        return null;
    }

    protected void onProgressUpdate(String... progress) {
        Log.e("MediaDownProgress", progress[0]);
    }

    @Override
    protected void onPostExecute(String file_url) {
        Log.e("MediaDownloadService", "done");
        if(onListener != null){
            onListener.onFinish();
        }
        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(mContext, mContext.getString(R.string.download_success), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public interface OnListener{
        void onFinish();
    }
}
