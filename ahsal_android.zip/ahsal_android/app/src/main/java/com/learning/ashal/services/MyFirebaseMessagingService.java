package com.learning.ashal.services;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.media.AudioAttributes;
import android.os.Build;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.learning.ashal.R;
import com.learning.ashal.activities.MainActivity;
import com.learning.ashal.utilities.LocaleHelper;
import com.learning.ashal.utilities.SavePref;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import org.json.JSONException;
import org.json.JSONObject;


import com.applozic.mobicomkit.Applozic;
import com.applozic.mobicomkit.api.account.register.RegisterUserClientService;
import com.applozic.mobicomkit.api.account.register.RegistrationResponse;
import com.applozic.mobicomkit.api.account.user.MobiComUserPreference;
import com.applozic.mobicomkit.api.notification.MobiComPushReceiver;

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    private static final String TAG = "FCM Service";
    private static final String CHANNEL_NAME = "Ashal Notification Channel";
    private static final String CHANNEL_DESCRIPTION = "";

    @Override
    public void onNewToken(String token) {
        Log.d(TAG, "Refreshed token: " + token);
        SavePref.getInstance(this).setFirebaseKey(token);

        Applozic.getInstance(this).setDeviceRegistrationId(token);
        if (MobiComUserPreference.getInstance(this).isRegistered()) {
            try {
                RegistrationResponse registrationResponse = new RegisterUserClientService(this).updatePushNotificationId(token);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        Log.d(TAG, "From: " + remoteMessage.getFrom());

        // Check if message contains a data payload.
        if (remoteMessage.getData().size() > 0) {
            Log.d(TAG, "Push Message data payload: " + remoteMessage.getData());

            if (MobiComPushReceiver.isMobiComPushNotification(remoteMessage.getData())) {
                Log.i(TAG, "Applozic notification processing...");
                MobiComPushReceiver.processMessageAsync(this, remoteMessage.getData());
                return;
            }

            String title = "";
            String bodyMessage = "";
            String arabicTitle = "";
            String arabicMessage = "";
            String type = "";
            String engMessage = "";
            String entTitle = "";

            JSONObject notificationJson = null;
            try {
                notificationJson = new JSONObject(remoteMessage.getData());
                entTitle = notificationJson.getString("title");
                engMessage = notificationJson.getString("message");
                arabicTitle = notificationJson.getString("arabicTitle");
                arabicMessage = notificationJson.getString("arabicMessage");

                type = notificationJson.getString("type");
            } catch (JSONException e) {
                e.printStackTrace();
            }

            if(LocaleHelper.getLanguage(this).equals("en")){
                title = entTitle;
                bodyMessage = engMessage;
            }else{
                title = arabicTitle;
                bodyMessage = arabicMessage;
            }

            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);


            int uniqueInt = (int) (System.currentTimeMillis() & 0xfffffff);
            PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

//            final Uri NOTIFICATION_SOUND_URI = Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://" + BuildConfig.APPLICATION_ID + "/" + R.raw.sound_notification);
            String chanelId = "learningID";

//            int badgeCount = SavePref.getInstance(getApplicationContext()).getNotificationCount();
//            badgeCount ++;
//            SavePref.getInstance(getApplicationContext()).setNotificationCount(badgeCount);
//
            NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE );

            // show the notification
            NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this, chanelId)
                    .setContentTitle(title)
                    .setContentText(bodyMessage)
//                    .setSound(NOTIFICATION_SOUND_URI)
//                    .setContentIntent(pendingIntent)
                    .setAutoCancel(true)
//                    .setNumber(badgeCount)
                    .setColor(getResources().getColor(R.color.colorPrimary))
                    .setPriority(NotificationCompat.PRIORITY_HIGH);

            mBuilder.setSmallIcon(R.drawable.notification);

            // Create the NotificationChannel, but only on API 26+ because
            // the NotificationChannel class is new and not in the support library
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                mBuilder.setChannelId( chanelId ) ;
                CharSequence name = CHANNEL_NAME;
                int importance = NotificationManager.IMPORTANCE_DEFAULT;
                NotificationChannel channel = new NotificationChannel(chanelId, name, importance);
                channel.setDescription(CHANNEL_DESCRIPTION);
                channel.setShowBadge(true);
                AudioAttributes attributes = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .build();

//                channel.setSound(NOTIFICATION_SOUND_URI, attributes);
                assert notificationManager != null;
                notificationManager.createNotificationChannel(channel);
            }
            assert notificationManager != null;
            notificationManager.notify(( int ) System. currentTimeMillis () , mBuilder.build()) ;
        }

        // Check if message contains a notification payload.
        if (remoteMessage.getNotification() != null) {
            Log.d(TAG, "Message Notification Body: " + remoteMessage.getNotification().getBody());
        }

    }

}