package com.learning.ashal.custom;

import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;

import androidx.recyclerview.widget.RecyclerView;

import com.learning.ashal.R;
import com.learning.ashal.adapter.StudentListAdapter;
import com.learning.ashal.adapter.VideoDownloadGradeAdapter;
import com.learning.ashal.model.GradeModel;
import com.learning.ashal.model.StudentModel;
import com.learning.ashal.model.UserModel;
import com.learning.ashal.utilities.AnimationUtils;
import com.learning.ashal.utilities.SavePref;
import com.learning.ashal.utilities.TempStore;

import java.util.List;

public class SelectGradePopupWindow extends PopupWindow
{
    private CustomTextView btCancel;
    private CustomTextView btApply;
    private RecyclerView rvGrades;
    private OnClickListener onClickListener;
    private GradeModel gradeModel;

    public SelectGradePopupWindow(final View mMenuView, Context context, List<GradeModel> gradeList, OnClickListener paramOnClickListener)
    {
        super(mMenuView , RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT,true);

        this.onClickListener = paramOnClickListener;
        btCancel = mMenuView.findViewById(R.id.btCancel);
        btApply = mMenuView.findViewById(R.id.btApply);
        rvGrades = mMenuView.findViewById(R.id.rvGrades);
        btCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClickListener.onCancel();
                dismiss();
            }
        });
        btApply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(gradeModel != null){
                    onClickListener.onSelect(gradeModel);
                    dismiss();
                }
            }
        });
        VideoDownloadGradeAdapter videoDownloadGradeAdapter = new VideoDownloadGradeAdapter(context, new VideoDownloadGradeAdapter.OnItemClickListener() {
            @Override
            public void onClick(GradeModel param) {
                gradeModel = param;
            }
        });
        rvGrades.setAdapter(videoDownloadGradeAdapter);

        if(gradeList.size() > 0){
            if(gradeList.size() == 1){
                gradeModel = gradeList.get(0);
                gradeList.get(0).isSelected = true;
            }
            videoDownloadGradeAdapter.setData(gradeList);
        }else{
            videoDownloadGradeAdapter.setData(null);
        }


        setContentView(mMenuView);
        setFocusable(true);
        setAnimationStyle(R.style.PopupAnimation);
        mMenuView.setOnTouchListener(new View.OnTouchListener()
        {
            public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
            {
                int i = mMenuView.findViewById(R.id.pop_layout).getTop();
                int j = (int)paramMotionEvent.getY();
                if ((paramMotionEvent.getAction() == 1) && (j < i))
                    dismiss();
                return true;
            }
        });
    }

    public interface OnClickListener{
        void onSelect(GradeModel grade);
        void onCancel();
    }
}

