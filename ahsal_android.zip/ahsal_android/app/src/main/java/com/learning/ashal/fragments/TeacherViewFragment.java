package com.learning.ashal.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;

import com.google.android.material.button.MaterialButton;
import com.learning.ashal.R;
import com.learning.ashal.adapter.TeacherUploadFileAdapter;
import com.learning.ashal.adapter.TeacherViewLessonAdapter;
import com.learning.ashal.custom.CustomTextView;
import com.learning.ashal.databinding.FragmentTeacherViewBinding;

public class TeacherViewFragment extends BaseFragment {

    private String TAG = TeacherViewFragment.class.getSimpleName();
    private FragmentTeacherViewBinding mBinding;
    private TeacherUploadFileAdapter teacherAddCourseAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_teacher_view, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    private void initView() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorWhite));

        CustomTextView txtTitle = mBinding.getRoot().findViewById(R.id.txtTitle);
        txtTitle.setText(getResources().getString(R.string.chat));
        MaterialButton btNext = mBinding.getRoot().findViewById(R.id.btNext);
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        btNext.setBackgroundColor(getResources().getColor(R.color.colorQuestionBk));

        TeacherViewLessonAdapter teacherViewLessonAdapter = new TeacherViewLessonAdapter();
        mBinding.rvLessons.setAdapter(teacherViewLessonAdapter);
        selectTabLessons();

    }

    private void selectTabLessons(){
        mBinding.txtTabLessons.setBackgroundColor(getResources().getColor(R.color.colorTab));
        mBinding.txtTabFileExam.setBackgroundColor(getResources().getColor(R.color.colorWhite));
    }

    private void selectTabFiles(){
        mBinding.txtTabLessons.setBackgroundColor(getResources().getColor(R.color.colorWhite));
        mBinding.txtTabFileExam.setBackgroundColor(getResources().getColor(R.color.colorTab));
    }
}
