package com.learning.ashal.fragments;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;

import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import com.bumptech.glide.Glide;
import com.google.android.material.button.MaterialButton;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.learning.ashal.R;
import com.learning.ashal.activities.MainActivity;
import com.learning.ashal.adapter.SpinCityAdapter;
import com.learning.ashal.adapter.SpinGradeAdapter;
import com.learning.ashal.adapter.SpinRegionAdapter;
import com.learning.ashal.adapter.SpinSchoolAdapter;
import com.learning.ashal.custom.CustomTextView;
import com.learning.ashal.custom.SelectPicPopupWindow;
import com.learning.ashal.databinding.FragmentNewProfileBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.model.GradeModel;
import com.learning.ashal.model.MessageEvent;
import com.learning.ashal.model.RegionModel;
import com.learning.ashal.model.SchoolModel;
import com.learning.ashal.model.StateModel;
import com.learning.ashal.model.StudentModel;
import com.learning.ashal.utilities.AnimationUtils;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import com.learning.ashal.utilities.SavePref;
import com.learning.ashal.utilities.TempStore;
import com.learning.ashal.utilities.Validation;

import org.greenrobot.eventbus.EventBus;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import static android.app.Activity.RESULT_OK;
import static com.learning.ashal.utilities.Constants.BASE_URL;

public class ProfileNewFragment extends BaseFragment {

    private String TAG = ProfileNewFragment.class.getSimpleName();
    private FragmentNewProfileBinding mBinding;
    private SelectPicPopupWindow selectPicPopupWindow;
    private String path;
    private List<RegionModel> regionModelList;
    private List<StateModel> cityModelList;
    private List<SchoolModel> schoolModelList;
    private List<SchoolModel> selectedSchoolModelList = new ArrayList<>();
    private List<GradeModel> gradeModelList;
    private RegionModel selRegion;
    private StateModel selState;
    private SchoolModel selSchool;
    private GradeModel selGrade;
    private StudentModel studentModel;

    public ProfileNewFragment(){

    }

    public ProfileNewFragment(StudentModel studentModel){
        this.studentModel = studentModel;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_new_profile, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    private void initView() {

        mBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.back();
            }
        });

        MaterialButton btNext = mBinding.getRoot().findViewById(R.id.btNext);
        btNext.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkValidation()){
                    if(studentModel == null){
                        callCreateStudent();
                    }else{
                        callUpdateStudent();
                    }
                }
            }
        });

        CustomTextView txtTitle = mBinding.getRoot().findViewById(R.id.txtTitle);
        txtTitle.setText(getString(R.string.save));

        mBinding.txtEditPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSelectDlg();
            }
        });

        if(studentModel == null){
            mBinding.txtHeaderTitle.setText(getString(R.string.profile));
            mBinding.llTab.setVisibility(View.GONE);
        }else{
            mBinding.txtHeaderTitle.setText(getString(R.string.edit_profile));
            mBinding.llTab.setVisibility(View.VISIBLE);
        }

        mBinding.txtCoursesInActive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.clearBackStack();
                FragmentProcess.replaceFragment(mActivity.getSupportFragmentManager(), new ProfileCourseFragment(studentModel), R.id.frameLayout);
            }
        });

        mBinding.txtLearningInActive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.clearBackStack();
                FragmentProcess.replaceFragment(mActivity.getSupportFragmentManager(), new ProfileLearningFragment(studentModel), R.id.frameLayout);
            }
        });

        mBinding.spnRegion.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            int check = 0;
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                int position = parent.getSelectedItemPosition();
                if(regionModelList != null){
                    selRegion = regionModelList.get(position);
                    cityModelList = selRegion.states;
                    SpinCityAdapter adapter = new SpinCityAdapter(mActivity, R.layout.item_spinner_count, selRegion.states);
                    mBinding.spnCity.setAdapter(adapter);

                    check++;

                    if(studentModel != null && check < 2){
                        for(int i=0; i<cityModelList.size();i++){
                            if(studentModel.state.equals(cityModelList.get(i).id)){
                                mBinding.spnCity.setSelection(i);
                                break;
                            }
                        }
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });

        mBinding.spnCity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            int check = 0;
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                int position = parent.getSelectedItemPosition();
                if(cityModelList != null){
                    selState = cityModelList.get(position);
                    check++;
                    selectedSchoolModelList.clear();
                    if(schoolModelList != null){
                        for(SchoolModel schoolModel : schoolModelList){
                            if(schoolModel.state.equals(selState.id)){
                                selectedSchoolModelList.add(schoolModel);
                            }
                        }
                        SpinSchoolAdapter adapter = new SpinSchoolAdapter(mActivity, R.layout.item_spinner_count, selectedSchoolModelList);
                        mBinding.spnSchool.setAdapter(adapter);
                        if(selectedSchoolModelList.size() > 0){
                            mBinding.txtNoSchool.setVisibility(View.GONE);
                        }else{
                            mBinding.txtNoSchool.setVisibility(View.VISIBLE);
                        }
                        if(studentModel != null && check < 2){
                            for(int i=0; i<selectedSchoolModelList.size();i++){
                                if(studentModel.school.equals(selectedSchoolModelList.get(i).id)){
                                    mBinding.spnSchool.setSelection(i);
                                    break;
                                }
                            }
                        }
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });

        mBinding.spnSchool.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                int position = parent.getSelectedItemPosition();
                if(selectedSchoolModelList != null){
                    selSchool = selectedSchoolModelList.get(position);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });

        mBinding.spnGrade.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                int position = parent.getSelectedItemPosition();
                if(gradeModelList != null){
                    selGrade = gradeModelList.get(position);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });

        callGetSchools();
        callGetGradeList();

        if(studentModel != null){
            setData();
        }else{
            mBinding.txtEditPhoto.setText(getString(R.string.add_photo));
        }

        AnimationUtils.animateSlideTopFromDown(mActivity, mBinding.scrollview);
    }

    private void setData(){
        mBinding.etFirstName.setText(studentModel.firstName);
//        mBinding.etLastName.setText(studentModel.lastName);
        mBinding.txtEditPhoto.setText(getString(R.string.edit_photo));
        mBinding.etPhoneNumber.setText(studentModel.mobile);
        mBinding.etEmail.setText(studentModel.email);
        if(studentModel.image != null){
            Glide
                    .with(mActivity)
                    .load(studentModel.image)
                    .into(mBinding.imgPhoto);
        }
    }

    private boolean checkValidation(){
//        if(path == null && studentModel == null){
//            showErrorMessage(mBinding.getRoot(), getString(R.string.image_required));
//            return false;
//        }

        if(mBinding.etFirstName.getText().toString().isEmpty()){
            showErrorMessage(mBinding.getRoot(), getString(R.string.first_name_required));
            return false;
        }

        if(!mBinding.etEmail.getText().toString().isEmpty()){
            if(!Validation.isValidEmail(mBinding.etEmail.getText().toString().trim())){
                showErrorMessage(mBinding.parent, getString(R.string.invalid_email));
                return false;
            }
        }

        if(mBinding.etPhoneNumber.getText().toString().isEmpty()){
            showErrorMessage(mBinding.getRoot(), getString(R.string.phone_number_required));
            return false;
        }

        if(selGrade == null || selRegion == null || selSchool == null || selState == null){
            return false;
        }

        return true;
    }

    private void openSelectDlg(){
        View view = ((LayoutInflater)mActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.dialog_layout_camera, null);
        selectPicPopupWindow = new SelectPicPopupWindow(view, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.btCancel:
                        selectPicPopupWindow.dismiss();
                        break;
                    case R.id.btCamera:
                        selectPicPopupWindow.dismiss();
                        if (checkAndRequestPermissions()) {
                            openCamera();
                        }
                        break;
                    case R.id.btGallery:
                        selectPicPopupWindow.dismiss();
                        openGallery();
                        break;
                }
            }
        });
        selectPicPopupWindow.showAtLocation(mBinding.getRoot(), Gravity.CENTER, 0, 0);
    }

    private Uri imageUri;
    public void openCamera(){
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "New Picture");
        imageUri = mActivity.getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        startActivityForResult(intent, 1);
    }

    public void openGallery() {
        Intent i = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(i, 2);
    }

    public String getRealPathFromURI(Uri contentUri) {
        Cursor cursor = mActivity.getContentResolver().query(contentUri, null, null, null, null);
        if (cursor == null) {
            return contentUri.getPath();
        } else {
            cursor.moveToFirst();
            int index = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            return cursor.getString(index);
        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if(requestCode == 1){
                try {
                    path = getRealPathFromURI(imageUri);
                    Glide
                            .with(mActivity)
                            .load(path)
                            .into(mBinding.imgPhoto);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }else if (requestCode == 2 && data != null) {
                try {
                    selectImageFromGalleryResult(data);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }
    }

    private void selectImageFromGalleryResult(Intent data) {
        Uri uri_data = data.getData();
        try {
            Bitmap originalBitmap = MediaStore.Images.Media.getBitmap(mActivity.getContentResolver(), uri_data);
            int nh = (int) (originalBitmap.getHeight() * (512.0 / originalBitmap.getWidth()));
            Bitmap compressedBitmap = Bitmap.createScaledBitmap(originalBitmap, 512, nh, true);
            File compressedFile = createFileFromBitmap(compressedBitmap, mActivity);
            path = compressedFile.getPath();
            Glide
                    .with(mActivity)
                    .load(path)
                    .into(mBinding.imgPhoto);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public File createFileFromBitmap(Bitmap bitmap, Context context) {

        Long tsLong = System.currentTimeMillis() / 1000;
        String name = tsLong.toString();

        File filesDir = context.getFilesDir();
        File imageFile = new File(filesDir, name + ".jpg");

        OutputStream os;
        try {
            os = new FileOutputStream(imageFile);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, os);
            os.flush();
            os.close();
        } catch (Exception e) {
            Log.e("NewProductFragment", "Error writing bitmap", e);
        }

        return imageFile;
    }

    private  boolean checkAndRequestPermissions() {
        int permissionCamera = ContextCompat.checkSelfPermission(mActivity, android.Manifest.permission.CAMERA);
        int permissionReadStorage = ContextCompat.checkSelfPermission(mActivity, Manifest.permission.READ_EXTERNAL_STORAGE);
        int permissionWriteStorage = ContextCompat.checkSelfPermission(mActivity, android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
        List<String> listPermissionsNeeded = new ArrayList<>();
        if (permissionWriteStorage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (permissionCamera != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.CAMERA);
        }

        if (permissionReadStorage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }

        if (!listPermissionsNeeded.isEmpty()) {
            this.requestPermissions(listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), 1);
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            Map<String, Integer> perms = new HashMap<>();
            perms.put(Manifest.permission.CAMERA, PackageManager.PERMISSION_GRANTED);
            perms.put(Manifest.permission.WRITE_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
            perms.put(Manifest.permission.READ_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
            if (grantResults.length > 0) {
                for (int i = 0; i < permissions.length; i++)
                    perms.put(permissions[i], grantResults[i]);
                if (perms.get(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                        && perms.get(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                        && perms.get(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                    openCamera();
                }
            }
        }
    }

    private void callGetLocation(){
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.getLocationList();
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<List<RegionModel>>() {}.getType();
                            try{
                                regionModelList = gson.fromJson(jsonObject.get("data").getAsJsonArray(), type);
                                SpinRegionAdapter adapter = new SpinRegionAdapter(mActivity, R.layout.item_spinner_count, regionModelList);
                                mBinding.spnRegion.setAdapter(adapter);

                                if(studentModel != null){
                                    for(int i=0; i<regionModelList.size();i++){
                                        if(studentModel.regionId != null)
                                            if(studentModel.regionId.equals(regionModelList.get(i).id)){
                                                mBinding.spnRegion.setSelection(i);
                                                break;
                                            }
                                    }
                                }

                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private void callGetSchools(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.getSchoolList();
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<List<SchoolModel>>() {}.getType();
                            try{
                                schoolModelList = gson.fromJson(jsonObject.get("data").getAsJsonArray(), type);
                                callGetLocation();
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                            ProgressDialog.hideprogressbar();
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }else{
                    ProgressDialog.hideprogressbar();
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private void callGetGradeList(){
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.getGradeList();
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<List<GradeModel>>() {}.getType();
                            try{
                                gradeModelList = gson.fromJson(jsonObject.get("data").getAsJsonArray(), type);
                                SpinGradeAdapter adapter = new SpinGradeAdapter(mActivity, R.layout.item_spinner_count, gradeModelList);
                                mBinding.spnGrade.setAdapter(adapter);

                                if(studentModel != null){
                                    for(int i=0; i<gradeModelList.size();i++){
                                        if(studentModel.gradeId.equals(gradeModelList.get(i).id)){
                                            mBinding.spnGrade.setSelection(i);
                                            break;
                                        }
                                    }
                                }
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
            }
        });
    }

    private void callCreateStudent(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        String id = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel.id : SavePref.getInstance(mActivity).getUserModel().id;
        RequestBody parentId = RequestBody.create(MediaType.parse("text/plain"), id);
        RequestBody firstName = RequestBody.create(MediaType.parse("text/plain"), mBinding.etFirstName.getText().toString());
        RequestBody lastName = RequestBody.create(MediaType.parse("text/plain"), mBinding.etLastName.getText().toString());
        RequestBody mobile = RequestBody.create(MediaType.parse("text/plain"), mBinding.etPhoneNumber.getText().toString());
        RequestBody email = RequestBody.create(MediaType.parse("text/plain"), mBinding.etEmail.getText().toString().trim());
        RequestBody state = RequestBody.create(MediaType.parse("text/plain"), selState.id);
        RequestBody school = RequestBody.create(MediaType.parse("text/plain"), selSchool.id);
        RequestBody gradeId = RequestBody.create(MediaType.parse("text/plain"), selGrade.id);
        MultipartBody.Part image = null;
        if(path!=null && new File(path).exists())
        {
            File file = new File(path);
            RequestBody requestFile =RequestBody.create(MediaType.parse("multipart/form-data"), file);
            image = MultipartBody.Part.createFormData("image", file.getName(), requestFile);
        }

        Call<JsonObject> call = apiInterface.createStudent(parentId, firstName, mobile, email, state, school, gradeId, image);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            MessageEvent messageEvent = new MessageEvent();
                            messageEvent.messageType = MessageEvent.MessageType.PROFILE_REFRESH;
                            EventBus.getDefault().post(messageEvent);
                            mActivity.back();
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                } else {
                    Log.e(TAG, "response error: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
                Log.e(TAG, "response fail error: "+ t.getMessage());
            }
        });
    }

    private void callUpdateStudent(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        RequestBody id = RequestBody.create(MediaType.parse("text/plain"), studentModel.id);
        RequestBody firstName = RequestBody.create(MediaType.parse("text/plain"), mBinding.etFirstName.getText().toString());
//        RequestBody lastName = RequestBody.create(MediaType.parse("text/plain"), mBinding.etLastName.getText().toString());
        RequestBody mobile = RequestBody.create(MediaType.parse("text/plain"), mBinding.etPhoneNumber.getText().toString());
        RequestBody email = RequestBody.create(MediaType.parse("text/plain"), mBinding.etEmail.getText().toString().trim());
        RequestBody state = RequestBody.create(MediaType.parse("text/plain"), selState.id);
        RequestBody school = RequestBody.create(MediaType.parse("text/plain"), selSchool.id);
        RequestBody gradeId = RequestBody.create(MediaType.parse("text/plain"), selGrade.id);
        MultipartBody.Part image = null;
        if(path!=null && new File(path).exists())
        {
            File file = new File(path);
            RequestBody requestFile =RequestBody.create(MediaType.parse("multipart/form-data"), file);
            image = MultipartBody.Part.createFormData("image", file.getName(), requestFile);
        }

        Call<JsonObject> call = apiInterface.updateStudent(id, firstName, mobile, email, state, school, gradeId, image);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            MessageEvent messageEvent = new MessageEvent();
                            messageEvent.messageType = MessageEvent.MessageType.PROFILE_REFRESH;
                            EventBus.getDefault().post(messageEvent);
                            mActivity.back();
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                } else {
                    Log.e(TAG, "response error: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
                Log.e(TAG, "response fail error: "+ t.getMessage());
            }
        });
    }
}
