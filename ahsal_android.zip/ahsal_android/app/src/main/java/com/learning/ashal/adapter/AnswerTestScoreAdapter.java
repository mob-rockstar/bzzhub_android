package com.learning.ashal.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.learning.ashal.R;
import com.learning.ashal.activities.ImageViewerActivity;
import com.learning.ashal.activities.SplashActivity;
import com.learning.ashal.activities.TeacherMainActivity;
import com.learning.ashal.databinding.RowAnswerTestScoreBinding;
import com.learning.ashal.model.AnswerModel;
import com.learning.ashal.model.QuestionModel;
import com.learning.ashal.model.SelAnswerModel;

import java.util.List;

public class AnswerTestScoreAdapter extends RecyclerView.Adapter<AnswerTestScoreAdapter.MyViewHolder>{

    private List<QuestionModel> questionModelList;
    private SelAnswerModel[] selectedAnswerList;
    private AnswerModel[] correctAnswerList;
    private Context context;

    public AnswerTestScoreAdapter(Context context){
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowAnswerTestScoreBinding binding = DataBindingUtil.inflate( LayoutInflater.from(parent.getContext()), R.layout.row_answer_test_score, parent, false);
        return new MyViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {

        QuestionModel questionModel = questionModelList.get(position);
        SelAnswerModel selectedAnswerModel = selectedAnswerList[position];
        AnswerModel correctAnswerModel = correctAnswerList[position];

        //question
        if(questionModel.type.equals("text")){
            holder.binding.imgQuestion.setVisibility(View.GONE);
            holder.binding.txtQuestion.setVisibility(View.VISIBLE);
            holder.binding.txtQuestion.setText(questionModel.question);
        }else if(questionModel.type.equals("image")){
            holder.binding.imgQuestion.setVisibility(View.VISIBLE);
            holder.binding.txtQuestion.setVisibility(View.GONE);
            if(questionModel.file != null)
                Glide.with(context).load(questionModel.file).into(holder.binding.imgQuestion);
        }else{
            holder.binding.imgQuestion.setVisibility(View.VISIBLE);
            holder.binding.txtQuestion.setVisibility(View.GONE);
            if(questionModel.file != null)
                Glide.with(context).load(questionModel.file).into(holder.binding.imgQuestion);
        }

        holder.binding.txtNo.setText(String.valueOf(position + 1));

        holder.binding.imgFeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ImageViewerActivity.class);
                intent.putExtra("url", questionModel.feedbackImage);
                context.startActivity(intent);
            }
        });

        if(questionModel.feedbackType != null)
            if(questionModel.feedbackType.equals("image")){
                holder.binding.imgFeedback.setVisibility(View.VISIBLE);
                holder.binding.txtFeedback.setVisibility(View.GONE);
                if(questionModel.feedbackImage != null)
                    Glide.with(context).load(questionModel.feedbackImage).into(holder.binding.imgFeedback);
            }else{
                holder.binding.imgFeedback.setVisibility(View.GONE);
                holder.binding.txtFeedback.setVisibility(View.VISIBLE);
                holder.binding.txtFeedback.setText(questionModel.feedback);
            }

        if(selectedAnswerModel.isDrag){
            holder.binding.txtYourAnswer.setVisibility(View.VISIBLE);
            holder.binding.imgYourAnswer.setVisibility(View.GONE);
            holder.binding.txtYourAnswer.setText(selectedAnswerModel.dragAnswer);
            //correct answer
            if(selectedAnswerModel.isCorrect){
                holder.binding.imgNoBk.setImageResource(R.color.colorTypeBk);
                holder.binding.llCorrectAnswer.setVisibility(View.GONE);
                holder.binding.txtCorrect.setVisibility(View.VISIBLE);
                holder.binding.txtInCorrect.setVisibility(View.GONE);
            }else{
                holder.binding.imgNoBk.setImageResource(R.color.colorRed);
                holder.binding.llCorrectAnswer.setVisibility(View.VISIBLE);
                holder.binding.txtCorrect.setVisibility(View.GONE);
                holder.binding.txtInCorrect.setVisibility(View.VISIBLE);

                holder.binding.txtYourAnswer.setVisibility(View.VISIBLE);
                holder.binding.imgCorrectAnswer.setVisibility(View.GONE);
                holder.binding.txtCorrectAnswer.setText(questionModel.question);
            }
        }else{
            //your answer
            if(selectedAnswerModel.answerModel.type.equals("text")){
                holder.binding.txtYourAnswer.setVisibility(View.VISIBLE);
                holder.binding.imgYourAnswer.setVisibility(View.GONE);
                holder.binding.txtYourAnswer.setText(selectedAnswerModel.answerModel.answer);
            }else{
                holder.binding.txtYourAnswer.setVisibility(View.GONE);
                holder.binding.imgYourAnswer.setVisibility(View.VISIBLE);
                if(selectedAnswerModel.answerModel.file != null)
                    Glide.with(context).load(selectedAnswerModel.answerModel.file).into(holder.binding.imgYourAnswer);
            }

            //correct answer
            if(selectedAnswerModel.isCorrect){
                holder.binding.imgNoBk.setImageResource(R.color.colorTypeBk);
                holder.binding.llCorrectAnswer.setVisibility(View.GONE);
                holder.binding.txtCorrect.setVisibility(View.VISIBLE);
                holder.binding.txtInCorrect.setVisibility(View.GONE);
            }else{
                holder.binding.imgNoBk.setImageResource(R.color.colorRed);
                holder.binding.llCorrectAnswer.setVisibility(View.VISIBLE);
                holder.binding.txtCorrect.setVisibility(View.GONE);
                holder.binding.txtInCorrect.setVisibility(View.VISIBLE);
                if(correctAnswerModel != null && correctAnswerModel.type != null)
                    if(correctAnswerModel.type.equals("text")){
                        holder.binding.txtYourAnswer.setVisibility(View.VISIBLE);
                        holder.binding.imgCorrectAnswer.setVisibility(View.GONE);
                        holder.binding.txtCorrectAnswer.setText(correctAnswerModel.answer);
                    }else{
                        holder.binding.txtCorrectAnswer.setVisibility(View.GONE);
                        holder.binding.imgCorrectAnswer.setVisibility(View.VISIBLE);
                        if(correctAnswerModel.file != null)
                            Glide.with(context).load(correctAnswerModel.file).into(holder.binding.imgYourAnswer);
                    }
            }
        }
    }

    public void setData(List<QuestionModel> list, SelAnswerModel[] selectedAnswerList, AnswerModel[] correctAnswerList){
        this.questionModelList = list;
        this.selectedAnswerList = selectedAnswerList;
        this.correctAnswerList = correctAnswerList;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if(questionModelList != null )
            return questionModelList.size();
        return 0;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private RowAnswerTestScoreBinding binding;
        public MyViewHolder(RowAnswerTestScoreBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
