package com.learning.ashal.fragments;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Toast;

import androidx.databinding.DataBindingUtil;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.learning.ashal.R;
import com.learning.ashal.activities.AboutUsActivity;
import com.learning.ashal.activities.ContactUsActivity;
import com.learning.ashal.activities.LoginActivity;
import com.learning.ashal.activities.MainActivity;
import com.learning.ashal.activities.PolicyActivity;
import com.learning.ashal.activities.TermsActivity;
import com.learning.ashal.custom.SingleClickListener;
import com.learning.ashal.databinding.FragmentSettingBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.interfaces.QuestionCallbackListener;
import com.learning.ashal.model.MessageEvent;
import com.learning.ashal.model.SettingModel;
import com.learning.ashal.model.StudentModel;
import com.learning.ashal.model.UserModel;
import com.learning.ashal.utilities.AnimationUtils;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.LocaleHelper;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import com.learning.ashal.utilities.SavePref;
import com.learning.ashal.utilities.TempStore;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.lang.reflect.Type;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.learning.ashal.utilities.Constants.BASE_URL;

public class SettingFragment extends BaseFragment {

    private String TAG = SettingFragment.class.getSimpleName();
    private FragmentSettingBinding mBinding;
    private SettingModel settingModel;

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventFragment(MessageEvent messageEvent) {
        if(messageEvent.messageType.equals(MessageEvent.MessageType.PROFILE_REFRESH)){
            if(TempStore.isLoggedIn)
                callGetProfile();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_setting, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    private void initFromApi(){

        if(settingModel.enableNotification.equals("1")){
            mBinding.swNotification.setChecked(true);
        }else{
            mBinding.swNotification.setChecked(false);
        }

        mBinding.swNotification.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                String value = b ? "1" : "2";
                callUpdateNotificationStatus(value);
            }
        });

//        mBinding.llWhatsApp.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                boolean installed = appInstalledOrNot("com.whatsapp");
//                if (installed){
//                    Intent intent = new Intent(Intent.ACTION_VIEW);
//                    intent.setData(Uri.parse("http://api.whatsapp.com/send?phone="+ settingModel.whatsapp));
//                    startActivity(intent);
//                }else {
//                    Toast.makeText(mActivity, getString(R.string.whatsapp_not_installed), Toast.LENGTH_SHORT).show();
//                }
//            }
//        });
    }

    private void initView() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorPrimary));

        ((MainActivity)mActivity).selectSettingTabMark();

        UserModel userModel = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel : SavePref.getInstance(mActivity).getUserModel();
        if(TempStore.isLoggedIn){
            if(userModel != null){
                mBinding.txtName.setText(userModel.firstName);
                if(userModel.image == null){
                    Glide.with(mActivity).load(R.drawable.placeholder).into(mBinding.imgPhoto);
                }else{
                    Glide.with(mActivity).load(userModel.image).into(mBinding.imgPhoto);
                }
            }else{
                Glide.with(mActivity).load(R.drawable.placeholder).into(mBinding.imgPhoto);
            }
        }else{
            mBinding.txtName.setText(getString(R.string.guest));
            Glide.with(mActivity).load(R.drawable.man).into(mBinding.imgPhoto);
        }

        if(LocaleHelper.getLanguage(mActivity).equals("en")){
            mBinding.swLang.setChecked(true);
        }else{
            mBinding.swLang.setChecked(false);
        }

        mBinding.swLang.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    changeLanguage("en");
                }else {
                    changeLanguage("ar");
                }
            }
        });

        mBinding.llLogout.setOnClickListener(new SingleClickListener() {
            @Override
            public void performClick(View view) {
                openQuestionDlg(getString(R.string.sure_logout), new QuestionCallbackListener() {
                    @Override
                    public void onYes() {
                        callLogout();
                    }

                    @Override
                    public void onNo() {

                    }
                });
            }
        });

        mBinding.llDeleteAccount.setOnClickListener(new SingleClickListener() {
            @Override
            public void performClick(View view) {
                openQuestionDlg(getString(R.string.sure_delete_account), new QuestionCallbackListener() {
                    @Override
                    public void onYes() {
                        callDeleteAccount();
                    }

                    @Override
                    public void onNo() {

                    }
                });
            }
        });

        mBinding.txtEditAccount.setOnClickListener(new SingleClickListener() {
            @Override
            public void performClick(View v) {
                FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new ProfileParentEditFragment(),  R.id.frameLayout);
            }
        });

        mBinding.llTerms.setOnClickListener(new SingleClickListener() {
            @Override
            public void performClick(View view) {
                startActivity(new Intent(mActivity, TermsActivity.class));
            }
        });

        mBinding.llPolicy.setOnClickListener(new SingleClickListener() {
            @Override
            public void performClick(View view) {
                startActivity(new Intent(mActivity, PolicyActivity.class));
            }
        });

        mBinding.llAbout.setOnClickListener(new SingleClickListener() {
            @Override
            public void performClick(View view) {
                startActivity(new Intent(mActivity, AboutUsActivity.class));
            }
        });

        mBinding.llContactus.setOnClickListener(new SingleClickListener() {
            @Override
            public void performClick(View v) {
                Intent intent = new Intent(mActivity, ContactUsActivity.class);
                if(settingModel != null)
                    intent.putExtra("whatsapp", settingModel.whatsapp);
                startActivity(intent);
            }
        });

        if(TempStore.isLoggedIn){
            mBinding.txtEditAccount.setVisibility(View.VISIBLE);
            mBinding.llNotification.setVisibility(View.VISIBLE);
            mBinding.llLogout.setVisibility(View.VISIBLE);
//            mBinding.llDeleteAccount.setVisibility(View.VISIBLE);
//            mBinding.llWhatsApp.setVisibility(View.VISIBLE);
            callGetParentSettings();
        }else{
            mBinding.txtEditAccount.setVisibility(View.GONE);
            mBinding.llNotification.setVisibility(View.GONE);
            mBinding.llLogout.setVisibility(View.GONE);
//            mBinding.llDeleteAccount.setVisibility(View.GONE);
//            mBinding.llWhatsApp.setVisibility(View.GONE);
        }
    }


    private void changeLanguage(final String lang){

        if(lang.equals("en")){
            LocaleHelper.changeLocale(mActivity, "en", "US");
        }else{
            LocaleHelper.changeLocale(mActivity, "ar", "SA");
        }
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                restart();
            }
        }, 200);

        if(!TempStore.isLoggedIn){
            return;
        }

        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        String id = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel.id : SavePref.getInstance(mActivity).getUserModel().id;
        Call<JsonObject> call = apiInterface.updateLanguage(id, lang);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {}
                    }
                }
            }
            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
            }
        });
    }

    private void callUpdateNotificationStatus(String value){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        String id = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel.id : SavePref.getInstance(mActivity).getUserModel().id;
        Call<JsonObject> call = apiInterface.updateNotificationStatus(id, value);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {

                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private void callGetParentSettings(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        String id = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel.id : SavePref.getInstance(mActivity).getUserModel().id;
        Call<JsonObject> call = apiInterface.getParentSettings(id);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<SettingModel>() {}.getType();
                            try{
                                settingModel = gson.fromJson(jsonObject.get("data").getAsJsonObject(), type);
                                initFromApi();
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }

                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private void callLogout(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        String id = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel.id : SavePref.getInstance(mActivity).getUserModel().id;
        Call<JsonObject> call = apiInterface.logout(id);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            SavePref.getInstance(mActivity).clearPref();
                            TempStore.isLoggedIn = false;
                            TempStore.userModel = null;
                            TempStore.cartList.clear();
                            MessageEvent messageEvent = new MessageEvent();
                            messageEvent.messageType = MessageEvent.MessageType.CART_BADGE_SHOW;
                            EventBus.getDefault().post(messageEvent);
                            TempStore.isFromAppLink = false;
                            Intent intent = new Intent(mActivity, LoginActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    public void callDeleteAccount(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        JsonObject requestParam = new JsonObject();
        JsonArray idArray = new JsonArray();
        String id = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel.id : SavePref.getInstance(mActivity).getUserModel().id;
        idArray.add(id);
        requestParam.add("ids", idArray);
        requestParam.addProperty("status", 3);

        Call<JsonObject> call = apiInterface.deleteAccount(requestParam);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            SavePref.getInstance(mActivity).clearPref();
                            TempStore.userModel = null;
                            Intent intent = new Intent(mActivity, LoginActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }
            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private void callGetNotificationStatus(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        String id = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel.id : SavePref.getInstance(mActivity).getUserModel().id;
        Call<JsonObject> call = apiInterface.getNotificationStatus(id);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            if(jsonObject.get("data").getAsString().equals("1")){
                                mBinding.swNotification.setChecked(true);
                            }else{
                                mBinding.swNotification.setChecked(false);
                            }

                            mBinding.swNotification.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                @Override
                                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                    String value = b ? "1" : "2";
                                    callUpdateNotificationStatus(value);
                                }
                            });
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private boolean appInstalledOrNot(String url){
        PackageManager packageManager = mActivity.getPackageManager();
        boolean app_installed;
        try {
            packageManager.getPackageInfo(url,PackageManager.GET_ACTIVITIES);
            app_installed = true;
        }catch (PackageManager.NameNotFoundException e){
            app_installed = false;
        }
        return app_installed;
    }


    private void callGetProfile(){
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        String id = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel.id : SavePref.getInstance(mActivity).getUserModel().id;
        Call<JsonObject> call = apiInterface.getProfile(id);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<UserModel>() {}.getType();
                            try{
                                UserModel userModel = gson.fromJson(jsonObject.get("data").getAsJsonObject(), type);
                                if(TempStore.userModel == null){
                                    SavePref.getInstance(mActivity).saveUserModel(userModel);
                                }else{
                                    TempStore.userModel = userModel;
                                }


                                if(userModel != null){
                                    if(userModel.image == null){
                                        Glide.with(mActivity).load(R.drawable.placeholder).into(mBinding.imgPhoto);
                                    }else{
                                        Glide.with(mActivity).load(userModel.image).into(mBinding.imgPhoto);
                                    }
                                }else{
                                    Glide.with(mActivity).load(R.drawable.placeholder).into(mBinding.imgPhoto);
                                }

                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

            }
        });
    }
}
