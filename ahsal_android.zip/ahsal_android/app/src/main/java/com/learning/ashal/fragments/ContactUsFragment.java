package com.learning.ashal.fragments;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.learning.ashal.R;
import com.learning.ashal.custom.SingleClickListener;
import com.learning.ashal.databinding.FragmentAboutUsBinding;
import com.learning.ashal.databinding.FragmentContactUsBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.model.SettingModel;
import com.learning.ashal.utilities.LocaleHelper;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.learning.ashal.utilities.Constants.BASE_URL;

public class ContactUsFragment extends BaseFragment {

    private String TAG = ContactUsFragment.class.getSimpleName();
    private FragmentContactUsBinding mBinding;
    private String whatsapp;

    public ContactUsFragment(){

    }

    public ContactUsFragment(String whatsapp){
        this.whatsapp = whatsapp;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_contact_us, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    private void initView() {
        mBinding.imgBack.setOnClickListener(new SingleClickListener() {
            @Override
            public void performClick(View view) {
                mActivity.back();
            }
        });

        mBinding.imgFacebook.setOnClickListener(new SingleClickListener() {
            @Override
            public void performClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://twitter.com/ashaledu"));
                startActivity(intent);
            }
        });

        mBinding.imgInstagram.setOnClickListener(new SingleClickListener() {
            @Override
            public void performClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://www.instagram.com/ashaledu"));
                startActivity(intent);
            }
        });

        mBinding.llContact.setOnClickListener(new SingleClickListener() {
            @Override
            public void performClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://ashal.om"));
                startActivity(intent);
            }
        });

        mBinding.llContactAshalStudio.setOnClickListener(new SingleClickListener() {
            @Override
            public void performClick(View v) {
                if(checkAndRequestCallPermission()){
                    call();
                }
            }
        });

        mBinding.llSupportTeam.setOnClickListener(new SingleClickListener() {
            @Override
            public void performClick(View v) {
                if(whatsapp != null){
                    boolean installed = appInstalledOrNot("com.whatsapp");
                    if (installed){
                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.setData(Uri.parse("http://api.whatsapp.com/send?phone="+ whatsapp));
                        startActivity(intent);
                    }else {
                        Toast.makeText(mActivity, getString(R.string.whatsapp_not_installed), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        mBinding.llInfo.setOnClickListener(new SingleClickListener() {
            @Override
            public void performClick(View v) {
                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_APP_EMAIL);
                startActivity(intent);
            }
        });
    }

    private void call(){
        Intent intent = new Intent(Intent.ACTION_CALL);
        intent.setData(Uri.parse("tel:" + "24155300"));
        startActivity(intent);
    }

    private boolean appInstalledOrNot(String url){
        PackageManager packageManager = mActivity.getPackageManager();
        boolean app_installed;
        try {
            packageManager.getPackageInfo(url,PackageManager.GET_ACTIVITIES);
            app_installed = true;
        }catch (PackageManager.NameNotFoundException e){
            app_installed = false;
        }
        return app_installed;
    }

    private boolean checkAndRequestCallPermission(){
        int checkPermission = ContextCompat.checkSelfPermission(mActivity, Manifest.permission.CALL_PHONE);
        if (checkPermission != PackageManager.PERMISSION_GRANTED) {
            this.requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, 5);
            return false;
        } else {
            return true;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 5) {
            if (grantResults.length > 0) {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    call();
                }
            }
        }
    }
}
