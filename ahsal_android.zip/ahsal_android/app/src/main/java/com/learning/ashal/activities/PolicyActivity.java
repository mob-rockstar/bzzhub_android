package com.learning.ashal.activities;

import android.os.Bundle;

import com.learning.ashal.R;
import com.learning.ashal.fragments.PolicyFragment;
import com.learning.ashal.fragments.TermsFragment;
import com.learning.ashal.utilities.FragmentProcess;

public class PolicyActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        FragmentProcess.replaceFragment(getSupportFragmentManager(), new PolicyFragment(),  R.id.frameLayout);
    }
}
