package com.learning.ashal.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.learning.ashal.R;
import com.learning.ashal.databinding.RowCourseProfileBinding;
import com.learning.ashal.databinding.RowLearningProfileBinding;
import com.learning.ashal.model.ExamResultModel;

import java.util.List;

public class ProfileLearningAdapter extends RecyclerView.Adapter<ProfileLearningAdapter.MyViewHolder> {

    private OnItemClickListener onItemClickListener;
    private List<ExamResultModel> examResultModelList;
    private Context context;

    public ProfileLearningAdapter(Context context){
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowLearningProfileBinding binding = DataBindingUtil.inflate( LayoutInflater.from(parent.getContext()), R.layout.row_learning_profile, parent, false);
        return new MyViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        ExamResultModel examResultModel = examResultModelList.get(position);
        holder.binding.txtTitle.setText(examResultModel.title);

        if(examResultModel.cover == null){
            Glide.with(context).load(R.drawable.placeholder).into(holder.binding.imgCover);
        }else{
            Glide.with(context).load(examResultModel.cover).into(holder.binding.imgCover);
        }

        holder.binding.txtTime.setText(examResultModel.examTime);

    }

    public void setData(List<ExamResultModel> list){
        this.examResultModelList = list;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if(examResultModelList != null )
            return examResultModelList.size();
        return 0;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private RowLearningProfileBinding binding;
        public MyViewHolder(RowLearningProfileBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public interface OnItemClickListener{
        void onClick(ExamResultModel examResultModel);
    }
}
