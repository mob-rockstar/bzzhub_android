package com.learning.ashal.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GradeModel {
    @SerializedName("id")
    @Expose
    public String id;

    @SerializedName("arabicName")
    @Expose
    public String arabicName;

    @SerializedName("englishName")
    @Expose
    public String englishName;

    @SerializedName("image")
    @Expose
    public String image;

    @SerializedName("status")
    @Expose
    public String status;

    @SerializedName("created_at")
    @Expose
    public String created_at;

    @SerializedName("updated_at")
    @Expose
    public String updated_at;

    public boolean isSelected;
}
