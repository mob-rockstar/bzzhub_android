package com.learning.ashal.model;

public class MessageEvent {
    public MessageType messageType;
    public boolean isSuccess;
    public String sms;

    public enum MessageType {
        PROFILE_REFRESH,
        COURSE_REFRESH,
        LESSON_REFRESH,
        QUESTION_REFRESH,
        ANSWER_REFRESH,
        SHOW_DIALOG,
        READ_SMS,
        CART_BADGE_SHOW,
    }
}