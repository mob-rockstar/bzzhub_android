package com.learning.ashal.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;

import androidx.databinding.DataBindingUtil;

import com.bumptech.glide.Glide;
import com.google.gson.JsonObject;
import com.learning.ashal.R;
import com.learning.ashal.databinding.DialogLayoutAddAnswerBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.model.AnswerModel;
import com.learning.ashal.model.MessageEvent;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;

import org.greenrobot.eventbus.EventBus;

import java.io.File;
import java.util.HashMap;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.learning.ashal.utilities.Constants.BASE_URL;

public class AddTestAnswerPopupFragment extends BaseCameraFragment
{
    private boolean isYes;
    private boolean isText;
    private DialogLayoutAddAnswerBinding mBinding;
    private String questionId;
    private AnswerModel answerModel;
    private boolean isChoice;


    public AddTestAnswerPopupFragment(){

    }

    public AddTestAnswerPopupFragment(String questionId, boolean isChoice){
        this.questionId = questionId;
        this.isChoice = isChoice;
    }

    public AddTestAnswerPopupFragment(String questionId, AnswerModel answerModel, boolean isChoice){
        this.questionId = questionId;
        this.answerModel = answerModel;
        this.isChoice = isChoice;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.dialog_layout_add_answer, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }
    
    private void initView(){
        mBinding.radioYes.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b)
                    setRadioYes();
            }
        });

        mBinding.radioNo.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b)
                    setRadioNo();
            }
        });

        mBinding.btCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.back();
            }
        });

        mBinding.txtAddText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectAddText();
            }
        });

        mBinding.txtUploadFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectUploadFile();
            }
        });

        mBinding.btUploadQuestion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSelectDlg(mBinding.getRoot(), mBinding.imgQuestion);
            }
        });

        mBinding.btSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isText){
                    if(mBinding.etAnswer.getText().toString().isEmpty()){
                        showErrorMessage(mBinding.getRoot(), getString(R.string.enter_answer));
                        return;
                    }
                }else{
                    if(path == null && answerModel == null){
                        showErrorMessage(mBinding.getRoot(), getString(R.string.upload_file));
                        return;
                    }
                }
                if(answerModel == null){
                    callCreateAnswer();
                }else{
                    callUpdateAnswer();
                }
            }
        });

        if(answerModel == null){
            mBinding.txtTopTitle.setText(getResources().getString(R.string.add_answer));
            mBinding.tab.setVisibility(View.VISIBLE);
            selectAddText();
            setRadioNo();
        }else {
            //edit
            mBinding.txtTopTitle.setText(getResources().getString(R.string.edit_answer));
            if (answerModel.isCorrect.equals("1")) {
                setRadioYes();
            }else{
                setRadioNo();
            }

            if(answerModel.type.equals("text")){
                selectAddText();
                mBinding.etAnswer.setText(answerModel.answer);
            }else{
                selectUploadFile();
                Glide.with(mActivity).load(answerModel.file).into(mBinding.imgQuestion);
            }
        }
    }
    
    private void selectAddText(){
        isText = true;
        hideSoftKeyboard();
        mBinding.txtAddText.setBackgroundColor(mActivity.getResources().getColor(R.color.colorPrimary));
        mBinding.txtAddText.setTextColor(mActivity.getResources().getColor(R.color.colorWhite));
        mBinding.txtUploadFile.setBackgroundColor(mActivity.getResources().getColor(R.color.colorWhite));
        mBinding.txtUploadFile.setTextColor(mActivity.getResources().getColor(R.color.colorBlack));
        mBinding.llQuestionImage.setVisibility(View.GONE);
        mBinding.llQuestionText.setVisibility(View.VISIBLE);
    }

    private void selectUploadFile(){
        isText = false;
        hideSoftKeyboard();
        mBinding.txtUploadFile.setBackgroundColor(mActivity.getResources().getColor(R.color.colorPrimary));
        mBinding.txtUploadFile.setTextColor(mActivity.getResources().getColor(R.color.colorWhite));
        mBinding.txtAddText.setBackgroundColor(mActivity.getResources().getColor(R.color.colorWhite));
        mBinding.txtAddText.setTextColor(mActivity.getResources().getColor(R.color.colorBlack));
        mBinding.llQuestionImage.setVisibility(View.VISIBLE);
        mBinding.llQuestionText.setVisibility(View.GONE);
    }

    private void setRadioYes(){
        isYes = true;
        mBinding.radioYes.setChecked(true);
        mBinding.radioNo.setChecked(false);
    }

    private void setRadioNo() {
        isYes = false;
        mBinding.radioYes.setChecked(false);
        mBinding.radioNo.setChecked(true);
    }

    private void callCreateAnswer(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        MultipartBody.Part file = null;
        RequestBody answerBody = null;
        RequestBody questionIdBody = RequestBody.create(MediaType.parse("text/plain"), questionId);
        RequestBody isCorrectBody = RequestBody.create(MediaType.parse("text/plain"), isYes ? "1" : "0");
        RequestBody typeBody = RequestBody.create(MediaType.parse("text/plain"), isText ? "text" : "image");
        if(isText){
            answerBody = RequestBody.create(MediaType.parse("text/plain"), mBinding.etAnswer.getText().toString().trim());
        }else{
            if (path != null && new File(path).exists()) {
                File f = new File(path);
                RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), f);
                file = MultipartBody.Part.createFormData("file", f.getName(), requestFile);
            }
        }
        HashMap<String, RequestBody> map = new HashMap<>();
        map.put("questionId", questionIdBody);
        if(answerBody != null)
            map.put("answer", answerBody);
        map.put("isCorrect", isCorrectBody);
        map.put("type", typeBody);

        Call<JsonObject> call = apiInterface.createTestAnswer(map, file);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            MessageEvent messageEvent = new MessageEvent();
                            messageEvent.messageType = MessageEvent.MessageType.ANSWER_REFRESH;
                            EventBus.getDefault().post(messageEvent);
                            mActivity.back();
                        }else{
                            showErrorMessage(mBinding.getRoot(),  jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private void callUpdateAnswer(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        MultipartBody.Part file = null;
        RequestBody answerBody = null;
        RequestBody answerIdBody = RequestBody.create(MediaType.parse("text/plain"), answerModel.id);
        RequestBody isCorrectBody = RequestBody.create(MediaType.parse("text/plain"), isYes ? "1" : "0");
        RequestBody typeBody = RequestBody.create(MediaType.parse("text/plain"), isText ? "text" : "image");
        if(isText){
            answerBody = RequestBody.create(MediaType.parse("text/plain"), mBinding.etAnswer.getText().toString().trim());
        }else{
            if (path != null && new File(path).exists()) {
                File f = new File(path);
                RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), f);
                file = MultipartBody.Part.createFormData("file", f.getName(), requestFile);
            }
        }
        HashMap<String, RequestBody> map = new HashMap<>();
        map.put("id", answerIdBody);
        if(answerBody != null)
            map.put("answer", answerBody);
        map.put("isCorrect", isCorrectBody);
        map.put("type", typeBody);

        Call<JsonObject> call = apiInterface.updateTestAnswer(map, file);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            MessageEvent messageEvent = new MessageEvent();
                            messageEvent.messageType = MessageEvent.MessageType.ANSWER_REFRESH;
                            EventBus.getDefault().post(messageEvent);
                            mActivity.back();
                        }else{
                            showErrorMessage(mBinding.getRoot(),  jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }
}

