package com.learning.ashal.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.learning.ashal.R;
import com.learning.ashal.activities.MainActivity;
import com.learning.ashal.activities.TeacherMainActivity;
import com.learning.ashal.adapter.ClassAdapter;
import com.learning.ashal.adapter.LessonAdapter;
import com.learning.ashal.adapter.TeacherCourseAdapter;
import com.learning.ashal.adapter.TeacherGradeAdapter;
import com.learning.ashal.custom.CustomQuestionDlg;
import com.learning.ashal.databinding.FragmentTeacherHomeBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.model.GradeModel;
import com.learning.ashal.model.GroupModel;
import com.learning.ashal.model.LastCourseModel;
import com.learning.ashal.model.LessonModel;
import com.learning.ashal.model.MessageEvent;
import com.learning.ashal.model.TeacherModel;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import com.learning.ashal.utilities.SavePref;
import com.learning.ashal.utilities.TempStore;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.lang.reflect.Type;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.learning.ashal.utilities.Constants.BASE_URL;

public class TeacherHomeFragment extends BaseFragment {

    private String TAG = TeacherHomeFragment.class.getSimpleName();
    private FragmentTeacherHomeBinding mBinding;
    private LessonAdapter lessonAdapter;
    private TeacherCourseAdapter teacherCourseAdapter;
    private ClassAdapter classAdapter;
    private TeacherGradeAdapter teacherGradeAdapter;
    private boolean isNotification;
    private String selectedGradeId;

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventFragment(MessageEvent messageEvent) {
        if(messageEvent.messageType.equals(MessageEvent.MessageType.COURSE_REFRESH)
        || messageEvent.messageType.equals(MessageEvent.MessageType.LESSON_REFRESH)){
            isNotification = true;
            if(selectedGradeId != null)
                callGetCourses(selectedGradeId);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_teacher_home, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    @Override
    public void updateUI() {
        ((TeacherMainActivity)mActivity).selectHomeTabMark();
    }

    private void initView() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorWhite));

        TeacherModel teacherModel = SavePref.getInstance(mActivity).getTeacherModel() == null ? TempStore.teacherModel : SavePref.getInstance(mActivity).getTeacherModel();
        mBinding.txtHi.setText(getString(R.string.hi, teacherModel.firstName));

        LinearLayoutManager layoutManager = new LinearLayoutManager(mActivity,LinearLayoutManager.HORIZONTAL,false);
        mBinding.rvGrades.setLayoutManager(layoutManager);
        teacherGradeAdapter = new TeacherGradeAdapter(mActivity, new TeacherGradeAdapter.OnItemClickListener() {
            @Override
            public void onClick(GradeModel gradeModel) {
                selectedGradeId = gradeModel.id;
                callGetCourses(gradeModel.id);
            }
        });
        mBinding.rvGrades.setAdapter(teacherGradeAdapter);

        LinearLayoutManager layoutManagerLesson = new LinearLayoutManager(mActivity,LinearLayoutManager.HORIZONTAL,false);
        mBinding.rvLessons.setLayoutManager(layoutManagerLesson);
        lessonAdapter = new LessonAdapter(mActivity, new LessonAdapter.OnItemClickListener() {
            @Override
            public void onClick(LessonModel lessonModel) {
                FragmentProcess.addFragment(mActivity.getSupportFragmentManager(), new TeacherAddLessonFragment(lessonModel), R.id.frameLayout);
            }
        });
        mBinding.rvLessons.setAdapter(lessonAdapter);


        LinearLayoutManager layoutManagerCourse = new LinearLayoutManager(mActivity,LinearLayoutManager.HORIZONTAL,false);
        mBinding.rvCourses.setLayoutManager(layoutManagerCourse);
        teacherCourseAdapter = new TeacherCourseAdapter(mActivity, new TeacherCourseAdapter.OnItemClickListener() {
            @Override
            public void onClick(LastCourseModel courseModel) {
                FragmentProcess.addFragment(mActivity.getSupportFragmentManager(), new TeacherAddCourseFragment(selectedGradeId, courseModel), R.id.frameLayout);
            }
        });
        mBinding.rvCourses.setAdapter(teacherCourseAdapter);

        LinearLayoutManager layoutManagerGroup = new LinearLayoutManager(mActivity,LinearLayoutManager.HORIZONTAL,false);
        mBinding.rvGroups.setLayoutManager(layoutManagerGroup);
        classAdapter = new ClassAdapter(mActivity, new ClassAdapter.OnItemClickListener() {
            @Override
            public void onClick(GroupModel groupModel) {

            }
        });
        mBinding.rvGroups.setAdapter(classAdapter);

        mBinding.imgCourseAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentProcess.addFragment(mActivity.getSupportFragmentManager(), new TeacherAddCourseFragment(), R.id.frameLayout);
            }
        });
        callGetTeacherProfile();
    }

    private void callGetTeacherProfile(){
        if(!isNotification)
            ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        String id = SavePref.getInstance(mActivity).getTeacherModel() == null ? TempStore.teacherModel.id : SavePref.getInstance(mActivity).getTeacherModel().id;
        Call<JsonObject> call = apiInterface.getTeacherProfile(id);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if(!isNotification)
                    ProgressDialog.hideprogressbar();
                isNotification = false;
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<TeacherModel>() {}.getType();
                            try{
                                TeacherModel teacherModel = gson.fromJson(jsonObject.get("data").getAsJsonObject(), type);
                                if(TempStore.teacherModel == null){
                                    SavePref.getInstance(mActivity).saveTeacherModel(teacherModel);
                                }else{
                                    TempStore.teacherModel = teacherModel;
                                }
                                if(teacherModel.grades != null && teacherModel.grades.size() > 0){
                                    teacherModel.grades.get(0).isSelected = true;
                                    selectedGradeId = teacherModel.grades.get(0).id;
                                    callGetCourses(teacherModel.grades.get(0).id);
                                    teacherGradeAdapter.setData(teacherModel.grades);
                                    mBinding.txtGradesNoData.setVisibility(View.GONE);
                                }else{
                                    CustomQuestionDlg dlg = new CustomQuestionDlg(mActivity, getString(R.string.complete), new CustomQuestionDlg.ItemClickInterface() {
                                        @Override
                                        public void onOK() {
                                            ((TeacherMainActivity)mActivity).selectProfile();
                                        }
                                    });
                                    dlg.showDialog();
                                    dlg.setCanceledOnTouchOutside(false);

                                    teacherGradeAdapter.setData(null);
                                    mBinding.txtGradesNoData.setVisibility(View.VISIBLE);
                                    lessonAdapter.setData(null);
                                    mBinding.txtLessonsNoData.setVisibility(View.VISIBLE);
                                    teacherCourseAdapter.setData(null);
                                    mBinding.txtCoursesNoData.setVisibility(View.VISIBLE);
                                }
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                if(!isNotification)
                    ProgressDialog.hideprogressbar();
                isNotification = false;
            }
        });
    }


    private void callGetCourses(String gradeId ){
        if(!isNotification)
            ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        String id = SavePref.getInstance(mActivity).getTeacherModel() == null ? TempStore.teacherModel.id : SavePref.getInstance(mActivity).getTeacherModel().id;
        Call<JsonObject> call = apiInterface.getCourses(gradeId, id);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if(!isNotification)
                    ProgressDialog.hideprogressbar();
                isNotification = false;
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<List<LessonModel>>() {}.getType();
                            Type type1 = new TypeToken<List<LastCourseModel>>() {}.getType();
                            try{
                                List<LessonModel> lessonModelList = gson.fromJson(jsonObject.get("data").getAsJsonObject().getAsJsonArray("lessons"), type);
                                List<LastCourseModel> lastCourseModelList = gson.fromJson(jsonObject.get("data").getAsJsonObject().getAsJsonArray("courses"), type1);

                                if(lessonModelList != null && lessonModelList.size() > 0){
                                    lessonAdapter.setData(lessonModelList);
                                    mBinding.txtLessonsNoData.setVisibility(View.GONE);
                                }else{
                                    lessonAdapter.setData(null);
                                    mBinding.txtLessonsNoData.setVisibility(View.VISIBLE);
                                }

                                if(lastCourseModelList != null && lastCourseModelList.size() > 0){
                                    teacherCourseAdapter.setData(lastCourseModelList);
                                    mBinding.txtCoursesNoData.setVisibility(View.GONE);
                                }else{
                                    teacherCourseAdapter.setData(null);
                                    mBinding.txtCoursesNoData.setVisibility(View.VISIBLE);
                                }
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                if(!isNotification)
                    ProgressDialog.hideprogressbar();
                isNotification = false;
            }
        });
    }
}
