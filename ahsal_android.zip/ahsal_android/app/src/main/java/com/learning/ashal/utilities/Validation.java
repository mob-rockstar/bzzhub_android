package com.learning.ashal.utilities;

import android.util.Patterns;

import java.util.regex.Pattern;

public class Validation {
    public final static boolean isValidEmail(CharSequence target) {
        if (target == null) {
            return false;
        } else {
            return Patterns.EMAIL_ADDRESS.matcher(target).matches();
        }
    }

    public final static boolean isValidPhone(CharSequence target) {
        if (target == null) {
            return false;
        } else {
            return Patterns.PHONE.matcher(target).matches();
        }
    }


    public final static boolean isValidUsername(String str) {
        try {
            Pattern pattern = Pattern.compile("^[A-Za-z0-9_.ء-ي]+$");
            return pattern.matcher(str).matches();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
