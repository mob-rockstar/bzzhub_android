package com.learning.ashal.activities;

import android.Manifest;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.PersistableBundle;
import android.os.ResultReceiver;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;

import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.learning.ashal.R;
import com.learning.ashal.custom.CustomInfoDlg;
import com.learning.ashal.custom.CustomQuestionDlg;
import com.learning.ashal.custom.CustomVideoDownloadDlg;
import com.learning.ashal.databinding.ActivityVimeoPlayBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.model.DownloadedVideoModel;
import com.learning.ashal.model.MessageEvent;
import com.learning.ashal.model.UserModel;
import com.learning.ashal.model.VideoDownloadModel;
import com.learning.ashal.utilities.LocaleHelper;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import com.learning.ashal.utilities.SavePref;
import com.learning.ashal.utilities.TempStore;

import org.greenrobot.eventbus.EventBus;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Type;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import io.realm.Realm;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.learning.ashal.utilities.Constants.BASE_URL;

public class VimeoPlayActivity extends BaseActivity {

    private ActivityVimeoPlayBinding binding;
    private String courseTitle;
    private String lessonName;
    private String vimeoId;
    private Realm realm;
    private String lessonImage, courseId, courseImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

//        setStatusBarColor(getResources().getColor(R.color.colorBlack));
//        requestWindowFeature(Window.FEATURE_NO_TITLE);
//        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        binding = DataBindingUtil.setContentView(this, R.layout.activity_vimeo_play);

        binding.imgClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        binding.imgDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(TempStore.isLoggedIn){
                    if(checkAndRequestPermissions()){
                        callGetDownload();
                    }
                }else{
                    CustomQuestionDlg dlg = new CustomQuestionDlg(VimeoPlayActivity.this, getString(R.string.need_to_register),
                            getString(R.string.new_register), getString(R.string.cancel), new CustomQuestionDlg.ItemClickInterface() {
                        @Override
                        public void onOK() {
                            Intent intent = new Intent(VimeoPlayActivity.this, LoginActivity.class);
                            startActivity(intent);
                        }
                    });
                    dlg.showDialog();
                    dlg.setCanceledOnTouchOutside(false);
                }
            }
        });

        if(getIntent() != null){
            courseTitle = getIntent().getStringExtra("courseTitle");
            lessonName = getIntent().getStringExtra("lessonName");
            vimeoId = getIntent().getStringExtra("vimeoId");
            webviewPlay(getIntent().getStringExtra("uri"));
            courseId = getIntent().getStringExtra("courseId");
            courseImage = getIntent().getStringExtra("courseImage");
            lessonImage = getIntent().getStringExtra("lessonImage");
        }
    }

    private void webviewPlay(String html){
        binding.webView.setBackgroundColor(Color.BLACK);
//        binding.webView.setWebViewClient(new WebViewClient() {
//            @Override
//            public boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest request) {
//                webView.loadUrl(request.getUrl().toString());
//                return true;
//            }
//        });g
        binding.webView.setWebViewClient(new WebViewClient());
        binding.webView.setWebChromeClient(new MyChrome());
        WebSettings webSettings = binding.webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setAppCacheEnabled(true);
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
        binding.webView.loadData(html, "text/html", "utf-8");
    }

    private boolean checkAndRequestPermissions() {
        int permissionReadStorage = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);
        int permissionWriteStorage = ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
        List<String> listPermissionsNeeded = new ArrayList<>();
        if (permissionWriteStorage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }

        if (permissionReadStorage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }

        if (!listPermissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this, listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), 1);
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            Map<String, Integer> perms = new HashMap<>();
            perms.put(Manifest.permission.WRITE_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
            perms.put(Manifest.permission.READ_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
            if (grantResults.length > 0) {
                for (int i = 0; i < permissions.length; i++)
                    perms.put(permissions[i], grantResults[i]);
                if (perms.get(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                        && perms.get(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                    callGetDownload();
                }
            }
        }
    }

    private void downloadVideo(VideoDownloadModel videoDownloadModel){
        realm = Realm.getDefaultInstance();
        String id;
        UserModel userModel = SavePref.getInstance(VimeoPlayActivity.this).getUserModel() == null ? TempStore.userModel :
                SavePref.getInstance(VimeoPlayActivity.this).getUserModel();
        id = lessonName + userModel.id + videoDownloadModel.gradeModel.id;

        DownloadedVideoModel result = realm.where(DownloadedVideoModel.class).equalTo("id", id).findFirst();

        if(result == null){
//                MediaDownloadService downloadService = new MediaDownloadService(downloadLink, lessonName,
//                        this, new MediaDownloadService.OnListener() {
//                    @Override
//                    public void onFinish() {
//                        createMetaFile();
//                    }
//                });
//                downloadService.execute();

//                Intent intent = new Intent(this, MediaDownloadIntentService.class);
//                intent.setAction(DOWNLOAD_ACTION);
//                intent.putExtra("receiver", new MyResultReceiver(new Handler()));
//                intent.putExtra("mediaUrl", downloadLink);
//                intent.putExtra("fileName", lessonName);
//                startService(intent);


//                ComponentName serviceComponent = new ComponentName(this, VideoDownloadService.class);
//                JobInfo.Builder builder = new JobInfo.Builder(0, serviceComponent);
//                builder.setMinimumLatency(1 * 1000); // wait at least
//                builder.setOverrideDeadline(3 * 1000); // maximum delay
//                PersistableBundle pb = new PersistableBundle();
//                pb.putString("mediaUrl", downloadLink);
//                pb.putString("fileName", lessonName);
//                builder.setExtras(pb);
//                builder.setRequiredNetworkType(JobInfo.NETWORK_TYPE_UNMETERED); // require unmetered network
//                builder.setRequiresDeviceIdle(true); // device should be idle
//                builder.setRequiresCharging(false); // we don't care if the device is charging or not
//                JobScheduler jobScheduler = getSystemService(JobScheduler.class);
//                jobScheduler.schedule(builder.build());

            new Thread(new Runnable() {
                public void run() {
                    runDownloadImageThread(lessonImage, lessonName);
                }
            }).start();

            new Thread(new Runnable() {
                public void run() {
                    runDownloadImageThread(courseImage, courseTitle);
                }
            }).start();

            new Thread(new Runnable() {
                public void run() {
                    runDownloadVideoThread(videoDownloadModel, id);
                }
            }).start();

            Toast.makeText(this, getString(R.string.downloading), Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this, getString(R.string.already_downloaded), Toast.LENGTH_SHORT).show();
        }
    }

    private void createMetaFile(VideoDownloadModel videoDownloadModel, String id){

        Date date = Calendar.getInstance().getTime();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);

        Realm realm = Realm.getDefaultInstance();

        realm.beginTransaction();
        DownloadedVideoModel result = realm.where(DownloadedVideoModel.class).equalTo("id", id).findFirst();
        if (result == null) {
            // Exists
            DownloadedVideoModel downloadedVideoModel = realm.createObject(DownloadedVideoModel.class);
            downloadedVideoModel.courseTitle = courseTitle;
            downloadedVideoModel.lessonName = lessonName;
            downloadedVideoModel.date = sdf.format(date);
            UserModel userModel = SavePref.getInstance(VimeoPlayActivity.this).getUserModel() == null ? TempStore.userModel : SavePref.getInstance(VimeoPlayActivity.this).getUserModel();
            downloadedVideoModel.userId = userModel.id;
            downloadedVideoModel.id = id;
            downloadedVideoModel.gradeId = videoDownloadModel.gradeModel.id;
            downloadedVideoModel.gradeArabicName = videoDownloadModel.gradeModel.arabicName;
            downloadedVideoModel.gradeEnglishName = videoDownloadModel.gradeModel.englishName;
        }
        realm.commitTransaction();

        Log.e("MediaDownloadService", "create meta file: "+ id);
    }

    private void callGetDownload(){
        ProgressDialog.showProgress(this);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.downloadLink(vimeoId, courseId);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            if(!jsonObject.get("data").isJsonNull()){
                                Gson gson = new Gson();
                                Type type = new TypeToken<List<VideoDownloadModel>>() {}.getType();
                                try{
                                    List<VideoDownloadModel> videoDownloadModelList = gson.fromJson(jsonObject.get("data").getAsJsonArray(), type);
                                    CustomVideoDownloadDlg customVideoDownloadDlg = new CustomVideoDownloadDlg(VimeoPlayActivity.this,
                                            new CustomVideoDownloadDlg.ItemClickInterface() {
                                                @Override
                                                public void onSelect(VideoDownloadModel videoDownloadModel) {
                                                    downloadVideo(videoDownloadModel);
                                                }
                                            }, videoDownloadModelList);
                                    customVideoDownloadDlg.showDialog();
                                }catch (JsonSyntaxException ex){
                                    ex.printStackTrace();
                                }
                            }
                        }else{
                            showErrorMessage(binding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    public void showErrorMessage(View view, String msg){
        Snackbar snackbar = Snackbar
                .make(view, msg, Snackbar.LENGTH_SHORT);
        View sbView = snackbar.getView();
        sbView.setBackgroundColor(ContextCompat.getColor(this, R.color.colorRed));
        TextView tv = sbView.findViewById(R.id.snackbar_text);
        Typeface font = Typeface.createFromAsset(getAssets(), getString(R.string.SFProDisplay_Regular));
        tv.setTypeface(font);
        tv.setTextColor(getResources().getColor(R.color.colorWhite));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        } else {
            tv.setGravity(Gravity.CENTER_HORIZONTAL);
        }
        snackbar.show();
    }

    private void runDownloadVideoThread(VideoDownloadModel videoDownloadModel, String id){
        int count;

        try {
            URL url = new URL(videoDownloadModel.link);
            URLConnection connection = url.openConnection();
            connection.connect();
            int lefOfFile = connection.getContentLength();
            InputStream input = new BufferedInputStream(url.openStream());
            File storageDir = new File(Environment
                    .getExternalStorageDirectory() + "/ashal/");
            if (!storageDir.exists())
                storageDir.mkdirs();


            OutputStream output = new FileOutputStream(Environment
                    .getExternalStorageDirectory() + "/ashal/"+ id);

            byte data[] = new byte[1024];
            long total = 0;
            while ((count = input.read(data)) != -1) {
                total += count;
                Log.e("MediaDownProgress", "" + (int) ((total * 100) / lefOfFile));
                output.write(data, 0, count);
            }
            output.flush();
            output.close();
            input.close();

            MessageEvent messageEvent = new MessageEvent();
            messageEvent.messageType = MessageEvent.MessageType.SHOW_DIALOG;
            messageEvent.isSuccess = true;
            EventBus.getDefault().post(messageEvent);

            createMetaFile(videoDownloadModel, id);

        } catch (Exception e) {
            MessageEvent messageEvent = new MessageEvent();
            messageEvent.messageType = MessageEvent.MessageType.SHOW_DIALOG;
            EventBus.getDefault().post(messageEvent);
        }
    }

    private void runDownloadImageThread(String mediaUrl, String filename){
        int count;

        try {
            URL url = new URL(mediaUrl);
            URLConnection connection = url.openConnection();
            connection.connect();
            int lefOfFile = connection.getContentLength();
            InputStream input = new BufferedInputStream(url.openStream());
            File storageDir = new File(Environment
                    .getExternalStorageDirectory() + "/ashal/");
            if (!storageDir.exists())
                storageDir.mkdirs();


            OutputStream output = new FileOutputStream(Environment
                    .getExternalStorageDirectory() + "/ashal/"+ filename);

            byte data[] = new byte[1024];
            long total = 0;
            while ((count = input.read(data)) != -1) {
                total += count;
                Log.e("IamgeDownProgress", "" + (int) ((total * 100) / lefOfFile));
                output.write(data, 0, count);
            }
            output.flush();
            output.close();
            input.close();
        } catch (Exception e) {

        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        LocaleHelper.onAttach(this);
    }



    private class MyChrome extends WebChromeClient {

        private View mCustomView;
        private WebChromeClient.CustomViewCallback mCustomViewCallback;
        protected FrameLayout mFullscreenContainer;
        private int mOriginalOrientation;
        private int mOriginalSystemUiVisibility;

        MyChrome() {}

        public Bitmap getDefaultVideoPoster()
        {
            if (mCustomView == null) {
                return null;
            }
            return BitmapFactory.decodeResource(getApplicationContext().getResources(), 2130837573);
        }

        public void onHideCustomView()
        {
            ((FrameLayout)getWindow().getDecorView()).removeView(this.mCustomView);
            this.mCustomView = null;
            getWindow().getDecorView().setSystemUiVisibility(this.mOriginalSystemUiVisibility);
            setRequestedOrientation(this.mOriginalOrientation);
            this.mCustomViewCallback.onCustomViewHidden();
            this.mCustomViewCallback = null;
        }

        public void onShowCustomView(View paramView, WebChromeClient.CustomViewCallback paramCustomViewCallback)
        {
            if (this.mCustomView != null)
            {
                onHideCustomView();
                return;
            }
            this.mCustomView = paramView;
            this.mOriginalSystemUiVisibility = getWindow().getDecorView().getSystemUiVisibility();
            this.mOriginalOrientation = getRequestedOrientation();
            this.mCustomViewCallback = paramCustomViewCallback;
            ((FrameLayout)getWindow().getDecorView()).addView(this.mCustomView, new FrameLayout.LayoutParams(-1, -1));
            getWindow().getDecorView().setSystemUiVisibility(3846 | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

}
