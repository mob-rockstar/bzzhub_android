package com.learning.ashal.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.learning.ashal.R;
import com.learning.ashal.custom.CustomTextView;
import com.learning.ashal.model.NotificationModel;
import com.learning.ashal.utilities.LocaleHelper;
import java.util.List;

public class NotificationsAdapter extends RecyclerView.Adapter<NotificationsAdapter.MyViewHolder> {

    private Context mContext;
    private List<NotificationModel> mNotificationList;
    private boolean mBIsEnglish;

    public NotificationsAdapter(Context context) {
        this.mContext = context;
        String lang = LocaleHelper.getLanguage(context);
        if(lang.equals("en")){
            mBIsEnglish = true;
        }else{
            mBIsEnglish = false;
        }
    }

    @NonNull
    @Override
    public NotificationsAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_notifications, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull NotificationsAdapter.MyViewHolder holder, final int position) {
        if(mBIsEnglish){
            holder.txtDate.setText(mNotificationList.get(position).ago);
            holder.txtNotificationType.setText(mNotificationList.get(position).title);
            holder.txtNotificationMsg.setText(mNotificationList.get(position).description);
        }
        else{
            holder.txtDate.setText(mNotificationList.get(position).agoArabic);
            holder.txtNotificationType.setText(mNotificationList.get(position).arabicTitle);
            holder.txtNotificationMsg.setText(mNotificationList.get(position).arabicDescription);
        }
    }

    @Override
    public int getItemCount() {
        if(mNotificationList == null)
            return 0;
        return mNotificationList.size();
    }

    public void setData(List<NotificationModel> notificationList){
        mNotificationList = notificationList;
        notifyDataSetChanged();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        private CustomTextView txtDate;
        private CustomTextView txtNotificationType;
        private CustomTextView txtNotificationMsg;

        public MyViewHolder(View view) {
            super(view);
            txtDate = view.findViewById(R.id.txtDate);
            txtNotificationType = view.findViewById(R.id.txtNotificationType);
            txtNotificationMsg = view.findViewById(R.id.txtNotificationMsg);
        }
    }
}

