package com.learning.ashal.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.learning.ashal.R;
import com.learning.ashal.activities.MainActivity;
import com.learning.ashal.adapter.ProfileAdapter;
import com.learning.ashal.databinding.FragmentProfileBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.interfaces.QuestionCallbackListener;
import com.learning.ashal.model.MessageEvent;
import com.learning.ashal.model.StudentModel;
import com.learning.ashal.model.UserModel;
import com.learning.ashal.utilities.AnimationUtils;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import com.learning.ashal.utilities.SavePref;
import com.learning.ashal.utilities.TempStore;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import java.lang.reflect.Type;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.learning.ashal.utilities.Constants.BASE_URL;

public class ProfileFragment extends BaseFragment {

    private String TAG = ProfileFragment.class.getSimpleName();
    private FragmentProfileBinding mBinding;
    private ProfileAdapter profileAdapter;
    private boolean isNotification;

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventFragment(MessageEvent messageEvent) {
        if(messageEvent.messageType.equals(MessageEvent.MessageType.PROFILE_REFRESH)){
            isNotification = true;
            callGetProfile();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_profile, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    @Override
    public void updateUI() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorPrimary));
        ((MainActivity)mActivity).selectProfileTabMark();
    }

    private void initView() {
        updateUI();

        profileAdapter = new ProfileAdapter(mActivity, new ProfileAdapter.OnItemClickListener() {
            @Override
            public void onClick(StudentModel studentModel) {
                FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new ProfileNewFragment(studentModel),  R.id.frameLayout);
            }

            @Override
            public void onDefault(StudentModel studentModel) {
                callSetDefaultProfile(studentModel);
            }

            @Override
            public void onDelete(StudentModel studentModel) {
                openQuestionDlg(getString(R.string.sure_delete_profile, studentModel.firstName), new QuestionCallbackListener() {
                    @Override
                    public void onYes() {
                        callDeleteProfile(studentModel);
                    }

                    @Override
                    public void onNo() {

                    }
                });
            }
        });

        mBinding.rvProfile.setAdapter(profileAdapter);

        mBinding.txtAddStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new ProfileNewFragment(),  R.id.frameLayout);
            }
        });

        mBinding.txtEditAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new ProfileParentEditFragment(),  R.id.frameLayout);
            }
        });

        callGetProfile();
    }

    private void setData(){
        UserModel userModel = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel : SavePref.getInstance(mActivity).getUserModel();
        if(TempStore.isLoggedIn){
            if(userModel != null){
                mBinding.txtName.setText(userModel.firstName);
                if(userModel.image == null){
                    Glide.with(mActivity).load(R.drawable.placeholder).into(mBinding.imgPhoto);
                }else{
                    Glide.with(mActivity).load(userModel.image).into(mBinding.imgPhoto);
                }
            }else{
                Glide.with(mActivity).load(R.drawable.placeholder).into(mBinding.imgPhoto);
            }
        }else{
            mBinding.txtName.setText(getString(R.string.guest));
            Glide.with(mActivity).load(R.drawable.man).into(mBinding.imgPhoto);
        }
    }

    private void callDeleteProfile(final StudentModel studentModel){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        String id = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel.id : SavePref.getInstance(mActivity).getUserModel().id;
        Call<JsonObject> call = apiInterface.deleteProfile(studentModel.id, id);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            isNotification = true;
                            callGetProfile();
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private void callSetDefaultProfile(final StudentModel studentModel){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        String id = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel.id : SavePref.getInstance(mActivity).getUserModel().id;
        Call<JsonObject> call = apiInterface.defaultProfile(studentModel.id, id);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            isNotification = true;
                            callGetProfile();
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private void callGetProfile(){
        if(!isNotification)
            ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        String id = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel.id : SavePref.getInstance(mActivity).getUserModel().id;
        Call<JsonObject> call = apiInterface.getProfile(id);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if(!isNotification)
                    ProgressDialog.hideprogressbar();
                isNotification = false;
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<UserModel>() {}.getType();
                            try{
                                UserModel userModel = gson.fromJson(jsonObject.get("data").getAsJsonObject(), type);
                                if(TempStore.userModel == null){
                                    SavePref.getInstance(mActivity).saveUserModel(userModel);
                                }else{
                                    TempStore.userModel = userModel;
                                }
                                if(userModel.profiles != null && userModel.profiles.size()>0){
                                    profileAdapter.setData(userModel.profiles);
                                    mBinding.txtNoData.setVisibility(View.GONE);
                                    AnimationUtils.animateSlideTopFromDown(mActivity, mBinding.rvProfile);
                                }else{
                                    profileAdapter.setData(null);
                                    mBinding.txtNoData.setVisibility(View.VISIBLE);
                                }
                                setData();
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                if(!isNotification)
                    ProgressDialog.hideprogressbar();
                isNotification = false;
            }
        });
    }
}
