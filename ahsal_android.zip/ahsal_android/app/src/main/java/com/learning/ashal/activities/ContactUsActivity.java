package com.learning.ashal.activities;

import android.os.Bundle;

import com.learning.ashal.R;
import com.learning.ashal.fragments.AboutUsFragment;
import com.learning.ashal.fragments.ContactUsFragment;
import com.learning.ashal.utilities.FragmentProcess;

public class ContactUsActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        FragmentProcess.replaceFragment(getSupportFragmentManager(), new ContactUsFragment(getIntent().getStringExtra("whatsapp")),  R.id.frameLayout);
    }
}
