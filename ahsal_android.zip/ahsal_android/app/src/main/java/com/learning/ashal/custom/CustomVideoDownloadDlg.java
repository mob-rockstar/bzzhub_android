package com.learning.ashal.custom;

import android.app.Dialog;
import android.content.Context;
import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

import com.learning.ashal.R;
import com.learning.ashal.adapter.VideoLinkAdapter;
import com.learning.ashal.model.VideoDownloadModel;

import java.util.List;

public class CustomVideoDownloadDlg extends Dialog {

    private ItemClickInterface mItemClickInterface;
    private Context mContext;
    private List<VideoDownloadModel> videoDownloadModelList;

    public CustomVideoDownloadDlg(Context paramContext, ItemClickInterface itemClickInterface, List<VideoDownloadModel> videoDownloadModels) {
        super(paramContext, R.style.dialog);

        setContentView(R.layout.dialog_video_download);

        mContext = paramContext;
        mItemClickInterface = itemClickInterface;

        videoDownloadModelList = videoDownloadModels;

        VideoLinkAdapter videoLinkAdapter = new VideoLinkAdapter(mContext, new VideoLinkAdapter.OnItemClickListener() {
            @Override
            public void onClick(VideoDownloadModel videoDownloadModel) {
                mItemClickInterface.onSelect(videoDownloadModel);
                disMissDialog();
            }
        });
        RecyclerView rvVideo = findViewById(R.id.rvVideoDownload);
        rvVideo.setAdapter(videoLinkAdapter);
        videoLinkAdapter.setData(videoDownloadModelList);
    }

    public void disMissDialog() {
        if (isShowing()) {
            dismiss();
        }
    }

    public void showDialog() {
        if (isShowing())
            dismiss();
        this.show();
    }

    public interface ItemClickInterface{
        void onSelect(VideoDownloadModel videoDownloadModel);
    }
}
