package com.learning.ashal.adapter;

import android.content.Context;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.learning.ashal.R;
import com.learning.ashal.databinding.RowVideoCourseDownloadBinding;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class VideoDownloadCourseAdapter extends RecyclerView.Adapter<VideoDownloadCourseAdapter.MyViewHolder> implements Filterable {

    private OnItemClickListener onItemClickListener;
    private List<String> courseNameList, mOriginalList;
    private Context context;
    private String baseDir = Environment.getExternalStorageDirectory() + "/ashal/";

    public VideoDownloadCourseAdapter(Context context, OnItemClickListener onItemClickListener){
        this.context = context;
        this.onItemClickListener = onItemClickListener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowVideoCourseDownloadBinding binding = DataBindingUtil.inflate( LayoutInflater.from(parent.getContext()), R.layout.row_video_course_download, parent, false);
        return new MyViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        String courseName = courseNameList.get(position);

        holder.binding.txtTitle.setText(courseName);
        File file = new File( baseDir + courseName);
        if(file.exists())
            Glide.with(context).load(file).into(holder.binding.imgCourse);

        holder.binding.row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onItemClickListener.onClick(courseName);
            }
        });

        holder.binding.imgDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClickListener.onDelete(courseName);
            }
        });
    }

    public void setData(List<String> list){
        this.courseNameList = list;
        mOriginalList = list;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if(courseNameList != null )
            return courseNameList.size();
        return 0;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private RowVideoCourseDownloadBinding binding;
        public MyViewHolder(RowVideoCourseDownloadBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public interface OnItemClickListener{
        void onClick(String courseName);
        void onDelete(String courseName);
    }

    protected List<String> getFilteredResults(String constraint) {
        List<String> results = new ArrayList<>();

        for (String item : courseNameList) {
            if (item.toLowerCase().contains(constraint)) {
                results.add(item);
            }
        }
        return results;
    }

    @Override
    public Filter getFilter() {

        return new Filter() {

            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                List<String> filteredResults = null;
                if (constraint.length() == 0) {
                    filteredResults = mOriginalList;
                } else {
                    filteredResults = getFilteredResults(constraint.toString().toLowerCase());
                }

                FilterResults results = new FilterResults();
                results.values = filteredResults;

                return results;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults results) {
                courseNameList = (ArrayList<String>) results.values;
                notifyDataSetChanged();
            }
        };
    }
}
