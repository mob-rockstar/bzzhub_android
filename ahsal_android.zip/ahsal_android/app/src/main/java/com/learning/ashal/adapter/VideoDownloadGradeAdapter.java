package com.learning.ashal.adapter;

import android.content.Context;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.learning.ashal.R;
import com.learning.ashal.databinding.RowVideoCourseDownloadBinding;
import com.learning.ashal.databinding.RowVideoGradeDownloadBinding;
import com.learning.ashal.model.GradeModel;
import com.learning.ashal.model.StudentModel;
import com.learning.ashal.utilities.LocaleHelper;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class VideoDownloadGradeAdapter extends RecyclerView.Adapter<VideoDownloadGradeAdapter.MyViewHolder>{

    private OnItemClickListener onItemClickListener;
    private List<GradeModel> gradeList;
    private Context context;
    private String lang;

    public VideoDownloadGradeAdapter(Context context, OnItemClickListener onItemClickListener){
        this.context = context;
        this.onItemClickListener = onItemClickListener;
        lang = LocaleHelper.getLanguage(context);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowVideoGradeDownloadBinding binding = DataBindingUtil.inflate( LayoutInflater.from(parent.getContext()), R.layout.row_video_grade_download, parent, false);
        return new MyViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        GradeModel grade = gradeList.get(position);

        if(lang.equals("en")){
            holder.binding.txtGrade.setText(grade.englishName);
        }else{
            holder.binding.txtGrade.setText(grade.arabicName);
        }

        if(grade.isSelected){
            holder.binding.txtGrade.setBackgroundColor(context.getResources().getColor(R.color.colorSelected));
        }else{
            holder.binding.txtGrade.setBackgroundColor(context.getResources().getColor(R.color.colorWhite));
        }

        holder.binding.txtGrade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for(GradeModel model: gradeList){
                    model.isSelected = false;
                }
                grade.isSelected = true;
                onItemClickListener.onClick(grade);
                notifyDataSetChanged();
            }
        });
    }

    public void setData(List<GradeModel> list){
        this.gradeList = list;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if(gradeList != null )
            return gradeList.size();
        return 0;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private RowVideoGradeDownloadBinding binding;
        public MyViewHolder(RowVideoGradeDownloadBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public interface OnItemClickListener{
        void onClick(GradeModel grade);
    }
}
