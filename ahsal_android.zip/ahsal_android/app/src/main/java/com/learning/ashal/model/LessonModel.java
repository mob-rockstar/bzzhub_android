package com.learning.ashal.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class LessonModel {
    @SerializedName("id")
    @Expose
    public String id;

    @SerializedName("courseId")
    @Expose
    public String courseId;

    @SerializedName("title")
    @Expose
    public String title;

    @SerializedName("file")
    @Expose
    public String file;

    @SerializedName("cover")
    @Expose
    public String cover;

    @SerializedName("description")
    @Expose
    public String description;

    @SerializedName("paid")
    @Expose
    public String paid;

    @SerializedName("status")
    @Expose
    public String status;

    @SerializedName("created_at")
    @Expose
    public String created_at;

    @SerializedName("updated_at")
    @Expose
    public String updated_at;

    @SerializedName("semester")
    @Expose
    public String semester;

    @SerializedName("isPurchased")
    @Expose
    public Boolean isPurchased;

    @SerializedName("downloadLink")
    @Expose
    public String downloadLink;

    @SerializedName("vimeoId")
    @Expose
    public String vimeoId;

    public boolean alreadyDownloaded;
}
