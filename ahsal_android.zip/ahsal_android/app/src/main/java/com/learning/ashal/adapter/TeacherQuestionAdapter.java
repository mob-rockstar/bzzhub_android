package com.learning.ashal.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.learning.ashal.R;
import com.learning.ashal.databinding.RowQuestionBinding;
import com.learning.ashal.databinding.RowTeacherQuestionBinding;
import com.learning.ashal.model.AnswerModel;
import com.learning.ashal.model.QuestionModel;

import java.util.ArrayList;
import java.util.List;

public class TeacherQuestionAdapter extends RecyclerView.Adapter<TeacherQuestionAdapter.MyViewHolder> implements Filterable {

    private OnItemClickListener onItemClickListener;
    private List<QuestionModel> questionModelList, mOriginalList;
    private Context context;

    public TeacherQuestionAdapter(Context context, OnItemClickListener onItemClickListener){
        this.context = context;
        this.onItemClickListener = onItemClickListener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowTeacherQuestionBinding binding = DataBindingUtil.inflate( LayoutInflater.from(parent.getContext()), R.layout.row_teacher_question, parent, false);
        return new MyViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        QuestionModel questionModel = questionModelList.get(position);
        if(questionModel.type.equals("text")){
            holder.binding.imgQuestion.setVisibility(View.GONE);
            holder.binding.txtQuestion.setVisibility(View.VISIBLE);
            holder.binding.txtQuestion.setText(questionModel.question);
        }else if(questionModel.type.equals("image")){
            holder.binding.imgQuestion.setVisibility(View.VISIBLE);
            holder.binding.txtQuestion.setVisibility(View.GONE);
            if(questionModel.file != null)
                Glide.with(context).load(questionModel.file).into(holder.binding.imgQuestion);
        }else if(questionModel.type.equals("video")){
            holder.binding.imgQuestion.setVisibility(View.VISIBLE);
            holder.binding.txtQuestion.setVisibility(View.GONE);
            if(questionModel.file != null)
                Glide.with(context).load(questionModel.file).into(holder.binding.imgQuestion);
        }else if(questionModel.type.equals("drag")){
            holder.binding.imgQuestion.setVisibility(View.GONE);
            holder.binding.txtQuestion.setVisibility(View.VISIBLE);
            holder.binding.txtQuestion.setText(questionModel.question);
            holder.binding.txtQuestion.setText(questionModel.question);
        }

        holder.binding.row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onItemClickListener.onClick(questionModel);
            }
        });
        holder.binding.imgDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onItemClickListener.onDelete(questionModel);
            }
        });

        holder.binding.txtQuestionNo.setText(context.getString(R.string.question, String.valueOf(position + 1)));
    }

    public void setData(List<QuestionModel> list){
        this.questionModelList = list;
        mOriginalList = list;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if(questionModelList != null )
            return questionModelList.size();
        return 0;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private RowTeacherQuestionBinding binding;
        public MyViewHolder(RowTeacherQuestionBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public interface OnItemClickListener{
        void onClick(QuestionModel questionModel);
        void onDelete(QuestionModel questionModel);
    }

    protected List<QuestionModel> getFilteredResults(String constraint) {
        List<QuestionModel> results = new ArrayList<>();

        for (QuestionModel item : questionModelList) {
            if(item.question != null)
                if (item.question.toLowerCase().contains(constraint)) {
                    results.add(item);
                }
        }
        return results;
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                List<QuestionModel> filteredResults = null;
                if (constraint.length() == 0) {
                    filteredResults = mOriginalList;
                } else {
                    filteredResults = getFilteredResults(constraint.toString().toLowerCase());
                }

                FilterResults results = new FilterResults();
                results.values = filteredResults;

                return results;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults results) {
                questionModelList = (ArrayList<QuestionModel>) results.values;
                notifyDataSetChanged();
            }
        };
    }
}
