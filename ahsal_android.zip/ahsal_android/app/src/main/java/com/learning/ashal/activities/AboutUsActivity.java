package com.learning.ashal.activities;

import android.os.Bundle;
import android.view.WindowManager;

import com.learning.ashal.R;
import com.learning.ashal.fragments.AboutUsFragment;
import com.learning.ashal.fragments.ProfileNewFragment;
import com.learning.ashal.utilities.FragmentProcess;

public class AboutUsActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        FragmentProcess.replaceFragment(getSupportFragmentManager(), new AboutUsFragment(),  R.id.frameLayout);
    }
}
