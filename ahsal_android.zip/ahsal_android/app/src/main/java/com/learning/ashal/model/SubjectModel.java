package com.learning.ashal.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SubjectModel {
    @SerializedName("id")
    @Expose
    public String id;

    @SerializedName("arabicName")
    @Expose
    public String arabicName;

    @SerializedName("courseImage")
    @Expose
    public String courseImage;

    @SerializedName("englishName")
    @Expose
    public String englishName;

    @SerializedName("gradeId")
    @Expose
    public String gradeId;

    @SerializedName("gradeImage")
    @Expose
    public String gradeImage;

    public boolean isSelected;
}
