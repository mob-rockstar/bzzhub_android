package com.learning.ashal.custom;


import android.view.MotionEvent;
import android.view.View;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;

import com.learning.ashal.R;


public class SelectPicPopupWindow extends PopupWindow
{
    private CustomButton cancelBtn;
    private CustomButton btGallery;
    private CustomButton btCamera;

    public SelectPicPopupWindow(final View mMenuView, View.OnClickListener paramOnClickListener)
    {
        super(mMenuView , RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT,true);


        btGallery = mMenuView.findViewById(R.id.btGallery);
        btCamera = mMenuView.findViewById(R.id.btCamera);
        cancelBtn = mMenuView.findViewById(R.id.btCancel);
        cancelBtn.setOnClickListener(paramOnClickListener);
        btGallery.setOnClickListener(paramOnClickListener);
        btCamera.setOnClickListener(paramOnClickListener);

        setContentView(mMenuView);
        setFocusable(true);
        setAnimationStyle(R.style.PopupAnimation);
        mMenuView.setOnTouchListener(new View.OnTouchListener()
        {
            public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
            {
                int i = mMenuView.findViewById(R.id.pop_layout).getTop();
                int j = (int)paramMotionEvent.getY();
                if ((paramMotionEvent.getAction() == 1) && (j < i))
                    dismiss();
                return true;
            }
        });
    }
}

