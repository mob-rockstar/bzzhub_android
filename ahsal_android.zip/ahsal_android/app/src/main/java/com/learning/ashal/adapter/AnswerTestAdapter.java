package com.learning.ashal.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.learning.ashal.R;
import com.learning.ashal.databinding.RowAnswerBinding;
import com.learning.ashal.databinding.RowAnswerTestBinding;
import com.learning.ashal.model.AnswerModel;
import com.learning.ashal.utilities.LocaleHelper;

import java.util.List;

public class AnswerTestAdapter extends RecyclerView.Adapter<AnswerTestAdapter.MyViewHolder>{

    private OnItemClickListener onItemClickListener;
    private List<AnswerModel> answerModelList;
    private Context context;
    private int selectedNo = -1;
    private boolean isArabic;

    public AnswerTestAdapter(Context context, OnItemClickListener onItemClickListener){
        this.context = context;
        this.onItemClickListener = onItemClickListener;
        if(LocaleHelper.getLanguage(context).equals("ar")){
            isArabic = true;
        }else{
            isArabic = false;
        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowAnswerTestBinding binding = DataBindingUtil.inflate( LayoutInflater.from(parent.getContext()), R.layout.row_answer_test, parent, false);
        return new MyViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        AnswerModel answerModel = answerModelList.get(position);

        if(answerModel.isSelected){
            setActive(answerModel, holder);
        }else{
            setRefresh(holder);
        }

        if(answerModel.type.equals("text")){
            holder.binding.txtAnswer.setVisibility(View.VISIBLE);
            holder.binding.imgAnswer.setVisibility(View.GONE);
            holder.binding.txtAnswer.setText(answerModel.answer);
        }else{
            holder.binding.txtAnswer.setVisibility(View.GONE);
            holder.binding.imgAnswer.setVisibility(View.VISIBLE);
            if(answerModel.file != null)
                Glide.with(context).load(answerModel.file).into(holder.binding.imgAnswer);
        }

        if(isArabic)
            holder.binding.txtNo.setText(answerModel.arabicLetter);
        else
            holder.binding.txtNo.setText(answerModel.letter);

        holder.binding.llRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setSelectedFlag(position);
                selectedNo = position;
                onItemClickListener.onClick(answerModel);
            }
        });
    }

    private void setSelectedFlag(int pos){
        if(selectedNo > -1 && selectedNo < answerModelList.size()){
            answerModelList.get(selectedNo).isSelected = false;
        }
        if(pos < answerModelList.size())
            answerModelList.get(pos).isSelected = true;
        notifyDataSetChanged();
    }

    private void setRefresh(MyViewHolder holder){
        holder.binding.txtAnswer.setTextColor(context.getResources().getColor(R.color.colorTypeBk));
        holder.binding.llRow.setBackgroundColor(context.getResources().getColor(R.color.colorWhite));
        holder.binding.imgNoBk.setImageResource(R.color.colorTypeBk);
    }

    private void setActive(AnswerModel answerModel, MyViewHolder holder){
        holder.binding.txtAnswer.setTextColor(context.getResources().getColor(R.color.colorWhite));
//        if(answerModel.isCorrect.equals("1")){
            holder.binding.llRow.setBackgroundColor(context.getResources().getColor(R.color.colorYellow));
//        }else{
//            holder.binding.llRow.setBackgroundColor(context.getResources().getColor(R.color.colorRed));
//        }

        holder.binding.imgNoBk.setImageResource(R.color.colorYellow);
    }

    public void setData(List<AnswerModel> list){
        this.answerModelList = list;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if(answerModelList != null )
            return answerModelList.size();
        return 0;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private RowAnswerTestBinding binding;
        public MyViewHolder(RowAnswerTestBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public interface OnItemClickListener{
        void onClick(AnswerModel answerModel);
    }
}
