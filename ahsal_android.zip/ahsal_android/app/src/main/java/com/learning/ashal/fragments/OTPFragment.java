package com.learning.ashal.fragments;

import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import com.google.android.gms.auth.api.phone.SmsRetriever;
import com.google.android.gms.auth.api.phone.SmsRetrieverClient;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.gson.JsonObject;
import com.learning.ashal.R;
import com.learning.ashal.activities.MainActivity;
import com.learning.ashal.activities.TeacherMainActivity;
import com.learning.ashal.databinding.FragmentOtpBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.model.MessageEvent;
import com.learning.ashal.model.TeacherModel;
import com.learning.ashal.model.UserModel;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.LocaleHelper;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import com.learning.ashal.utilities.SavePref;
import com.learning.ashal.utilities.TempStore;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.app.Activity.RESULT_OK;
import static com.learning.ashal.utilities.Constants.BASE_URL;

public class OTPFragment extends BaseFragment {

    private String TAG = OTPFragment.class.getSimpleName();
    private FragmentOtpBinding mBinding;
    private String id;
    private UserModel userModel;
    private TeacherModel teacherModel;


    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventFragment(MessageEvent messageEvent) {
        if(messageEvent.messageType.equals(MessageEvent.MessageType.READ_SMS)){
            String code = parseCode(messageEvent.sms);
            if(!code.isEmpty())
                mBinding.etOtp.setText(code);
        }
    }

    public String parseCode(String message) {
        Pattern p = Pattern.compile("\\b\\d{4}\\b");
        Matcher m = p.matcher(message);
        String code = "";
        while (m.find()) {
            code = m.group(0);
        }
        return code;
    }

    public OTPFragment(){

    }

    public OTPFragment(String id){
        this.id = id;
    }

    public OTPFragment(UserModel userModel){
        this.userModel = userModel;
    }

    public OTPFragment(TeacherModel teacherModel){
        this.teacherModel = teacherModel;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_otp, container, false);
        View view = mBinding.getRoot();
        initView();
        initSMS();
        return view;
    }

    @Override
    public void onStop() {
        super.onStop();
        mActivity.unregisterReceiver(smsVerificationReceiver);
        if(countDownTimer != null)
            countDownTimer.cancel();
    }

    private static final int SMS_CONSENT_REQUEST = 2;  // Set to an unused request code
    private final BroadcastReceiver smsVerificationReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (SmsRetriever.SMS_RETRIEVED_ACTION.equals(intent.getAction())) {
                Bundle extras = intent.getExtras();
                Status smsRetrieverStatus = (Status) extras.get(SmsRetriever.EXTRA_STATUS);

                switch (smsRetrieverStatus.getStatusCode()) {
                    case CommonStatusCodes.SUCCESS:

                        Intent consentIntent = extras.getParcelable(SmsRetriever.EXTRA_CONSENT_INTENT);
                        try {
                            // Start activity to show consent dialog to user, activity must be started in
                            // 5 minutes, otherwise you'll receive another TIMEOUT intent
                            startActivityForResult(consentIntent, SMS_CONSENT_REQUEST);
                        } catch (ActivityNotFoundException e) {
                            // Handle the exception ...
                        }

//                        String message = (String) extras.get(SmsRetriever.EXTRA_SMS_MESSAGE);
//                        String oneTimeCode = parseCode(message); // define this function
//                        if(!oneTimeCode.isEmpty())
//                            mBinding.etOtp.setText(oneTimeCode);
                        break;
                    case CommonStatusCodes.TIMEOUT:
                        // Time out occurred, handle the error.
                        break;
                }

                Task<Void> task = SmsRetriever.getClient(mActivity).startSmsUserConsent(null);//one time
            }
        }
    };

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case SMS_CONSENT_REQUEST:
                if (resultCode == RESULT_OK) {
                    // Get SMS message content
                    String message = data.getStringExtra(SmsRetriever.EXTRA_SMS_MESSAGE);
                    String oneTimeCode = parseCode(message); // define this function
                    if(!oneTimeCode.isEmpty())
                        mBinding.etOtp.setText(oneTimeCode);
                }
                break;
        }
    }


    private void initSMS(){
        IntentFilter intentFilter = new IntentFilter(SmsRetriever.SMS_RETRIEVED_ACTION);
        mActivity.registerReceiver(smsVerificationReceiver, intentFilter, SmsRetriever.SEND_PERMISSION, null);
        Task<Void> task = SmsRetriever.getClient(mActivity).startSmsUserConsent(null);//one time
//        SmsRetrieverClient client = SmsRetriever.getClient(mActivity);
//        Task<Void> task = client.startSmsRetriever();
//        task.addOnSuccessListener(new OnSuccessListener<Void>() {
//            @Override
//            public void onSuccess(Void aVoid) {
//                Toast.makeText(mActivity, "success", Toast.LENGTH_SHORT).show();
//            }
//        });
//
//        task.addOnFailureListener(new OnFailureListener() {
//            @Override
//            public void onFailure(@NonNull Exception e) {
//                Toast.makeText(mActivity, "fail", Toast.LENGTH_SHORT).show();
//            }
//        });
    }


    private void initView() {
        updateUI();
        mBinding.btConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkValidForm()){
                    if(SavePref.getInstance(mActivity).isLoginTypeTeacher()){
                        callTeacherVerifyOTP();
                    }else{
                        callVerifyOTP();
                    }
                }
            }
        });

        mBinding.btCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.back();
            }
        });

        mBinding.txtResend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mBinding.txtSec.setVisibility(View.VISIBLE);
                mBinding.llResend.setVisibility(View.GONE);
                if(SavePref.getInstance(mActivity).isLoginTypeTeacher()){
                    callTeacherResendOTP();
                }else{
                    callResendOTP();
                }
                mBinding.txtSec.setText(getString(R.string.secondes, "60"));
                playCountDownTimer();
            }
        });

//        checkAndRequestPermissions();

    }

//    public boolean checkAndRequestPermissions() {
//        int permissionReceiveSMS = ContextCompat.checkSelfPermission(mActivity, Manifest.permission.RECEIVE_SMS);
//        int permissionReadSMS = ContextCompat.checkSelfPermission(mActivity, Manifest.permission.READ_SMS);
//
//        List<String> listPermissionsNeeded = new ArrayList<>();
//        if (permissionReceiveSMS != PackageManager.PERMISSION_GRANTED) {
//            listPermissionsNeeded.add(Manifest.permission.RECEIVE_SMS);
//        }
//        if (permissionReadSMS != PackageManager.PERMISSION_GRANTED) {
//            listPermissionsNeeded.add(Manifest.permission.READ_SMS);
//        }
//
//
//        if (!listPermissionsNeeded.isEmpty()) {
//            this.requestPermissions(listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), 1);
//            return false;
//        }
//        return true;
//    }

//    @Override
//    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//        if (requestCode == 1) {
//            Map<String, Integer> perms = new HashMap<>();
//            perms.put(Manifest.permission.RECEIVE_SMS, PackageManager.PERMISSION_GRANTED);
//            perms.put(Manifest.permission.READ_SMS, PackageManager.PERMISSION_GRANTED);
//
//            if (grantResults.length > 0) {
//                for (int i = 0; i < permissions.length; i++)
//                    perms.put(permissions[i], grantResults[i]);
//                if (perms.get(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED
//                        && perms.get(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) {
//
//                }
//            }
//        }
//    }

    private CountDownTimer countDownTimer;
    private void playCountDownTimer(){
        if(countDownTimer != null)
            countDownTimer.cancel();
        countDownTimer = new CountDownTimer(60000, 1000) {
            public void onTick(long millisUntilFinished) {
                if(isAdded() && mBinding.txtSec != null)
                    mBinding.txtSec.setText(getString(R.string.secondes, String.valueOf(millisUntilFinished / 1000)));
            }
            public void onFinish() {
                if(isAdded()){
                    mBinding.txtSec.setVisibility(View.GONE);
                    mBinding.llResend.setVisibility(View.VISIBLE);
                }
            }

        };
        countDownTimer.start();
    }

    private boolean checkValidForm(){
        if(mBinding.etOtp.getText().toString().isEmpty()){
            showErrorMessage(mBinding.parent, getString(R.string.enter_otp));
            return false;
        }
        return true;
    }

    private void callVerifyOTP(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Map params = new HashMap();
        if(id != null){
            params.put("id", id);
        }else{
            params.put("id", userModel.id);
        }

        params.put("otp", mBinding.etOtp.getText().toString().trim());
        String lang = LocaleHelper.getPersistedData(mActivity, "ar");
        params.put("language", lang);
        params.put("fcmToken", SavePref.getInstance(mActivity).getFirebaseKey());

        Call<JsonObject> call = apiInterface.verifyOtp(params);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            if(countDownTimer != null)
                                countDownTimer.cancel();
                            if(id == null){
                                TempStore.isLoggedIn = true;
                                SavePref.getInstance(mActivity).saveUserModel(userModel);
                                SavePref.getInstance(mActivity).saveTeacherModel(teacherModel);
                                Intent intent = new Intent(mActivity, MainActivity.class);
                                startActivity(intent);
                                mActivity.finish();
                            }else{
                                FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new ChangePwdFragment(id), R.id.frameLayout);
                            }
                        }else{
                            if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                } else {
                    Log.e(TAG, "response error: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
                Log.e(TAG, "response fail error: "+ t.getMessage());
            }
        });
    }

    private void callResendOTP(){
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.resendOtp(id != null? id : userModel.id);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {

                        }
                    }
                } else {
                    Log.e(TAG, "response error: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Log.e(TAG, "response fail error: "+ t.getMessage());
            }
        });
    }

    private void callTeacherVerifyOTP(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Map params = new HashMap();
        if(id != null){
            params.put("id", id);
        }else{
            params.put("id", teacherModel.id);
        }

        params.put("otp", mBinding.etOtp.getText().toString().trim());
        String lang = LocaleHelper.getPersistedData(mActivity, "ar");
        params.put("language", lang);
        params.put("fcmToken", SavePref.getInstance(mActivity).getFirebaseKey());

        Call<JsonObject> call = apiInterface.verifyTeacherOtp(params);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            if(countDownTimer != null)
                                countDownTimer.cancel();
                            if(id == null){
                                SavePref.getInstance(mActivity).saveTeacherModel(teacherModel);
                                Intent intent = new Intent(mActivity, TeacherMainActivity.class);
                                startActivity(intent);
                                mActivity.finish();
                            }else{
                                FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new ChangePwdFragment(id), R.id.frameLayout);
                            }
                        }else{
                            if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                } else {
                    Log.e(TAG, "response error: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
                Log.e(TAG, "response fail error: "+ t.getMessage());
            }
        });
    }

    private void callTeacherResendOTP(){
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.resendTeacherOtp(id != null? id : teacherModel.id);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {

                        }
                    }
                } else {
                    Log.e(TAG, "response error: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Log.e(TAG, "response fail error: "+ t.getMessage());
            }
        });
    }
}
