package com.learning.ashal.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class SettingModel {
    @SerializedName("enableNotification")
    @Expose
    public String enableNotification;

    @SerializedName("whatsapp")
    @Expose
    public String whatsapp;

    @SerializedName("terms_ar")
    @Expose
    public String terms_ar;

    @SerializedName("terms_en")
    @Expose
    public String terms_en;

    @SerializedName("about_ar")
    @Expose
    public String about_ar;

    @SerializedName("about_en")
    @Expose
    public String about_en;

    @SerializedName("policy_ar")
    @Expose
    public String polcy_ar;

    @SerializedName("policy_en")
    @Expose
    public String polcy_en;
}
