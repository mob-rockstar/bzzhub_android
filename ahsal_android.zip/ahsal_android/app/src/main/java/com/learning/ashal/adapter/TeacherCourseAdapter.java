package com.learning.ashal.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.learning.ashal.R;
import com.learning.ashal.databinding.RowLessonBinding;
import com.learning.ashal.model.LastCourseModel;
import com.learning.ashal.utilities.LocaleHelper;

import java.util.List;

public class TeacherCourseAdapter extends RecyclerView.Adapter<TeacherCourseAdapter.MyViewHolder> {

    private OnItemClickListener onItemClickListener;
    private List<LastCourseModel> courseModelList;
    private boolean mBIsEnglish;
    private Context context;

    public TeacherCourseAdapter(Context context, TeacherCourseAdapter.OnItemClickListener onItemClickListener){
        this.onItemClickListener = onItemClickListener;
        this.context = context;
        String lang = LocaleHelper.getLanguage(context);
        if(lang.equals("en")){
            mBIsEnglish = true;
        }else{
            mBIsEnglish = false;
        }
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowLessonBinding binding = DataBindingUtil.inflate( LayoutInflater.from(parent.getContext()), R.layout.row_lesson, parent, false);
        return new MyViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {

        final LastCourseModel courseModel = courseModelList.get(position);
        holder.binding.txtName.setText(courseModel.title);

        if(courseModel.image== null){
            Glide.with(context).load(R.drawable.rect_lesson_play).into(holder.binding.imgCourse);
        }else{
            Glide.with(context).load(courseModel.image).into(holder.binding.imgCourse);
        }

        holder.binding.row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onItemClickListener.onClick(courseModel);
            }
        });
    }

    public void setData(List<LastCourseModel> list){
        this.courseModelList = list;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if(courseModelList != null )
            return courseModelList.size();
        return 0;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private RowLessonBinding binding;
        public MyViewHolder(RowLessonBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public interface OnItemClickListener{
        void onClick(LastCourseModel courseModel);
    }
}
