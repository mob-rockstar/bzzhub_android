package com.learning.ashal.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;

import com.google.android.material.button.MaterialButton;
import com.learning.ashal.R;
import com.learning.ashal.custom.CustomTextView;
import com.learning.ashal.databinding.FragmentTeacherAddCourseExamDetailBinding;

public class TeacherAddCourseExamDetailFragment extends BaseFragment {

    private String TAG = TeacherAddCourseExamDetailFragment.class.getSimpleName();
    private FragmentTeacherAddCourseExamDetailBinding mBinding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_teacher_add_course_exam_detail, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    private void initView() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorWhite));

        CustomTextView txtTitle = mBinding.getRoot().findViewById(R.id.txtTitle);
        txtTitle.setText(getResources().getString(R.string.create));
        MaterialButton btNext = mBinding.getRoot().findViewById(R.id.btNext);
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        btNext.setBackgroundColor(getResources().getColor(R.color.colorQuestionBk));

        mBinding.txtTabUploadExamFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectTabUploadExamFile();
            }
        });

        mBinding.txtTabWriteExam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectTabWriteExam();
            }
        });

        selectTabUploadExamFile();
    }

    private void selectTabUploadExamFile(){
        mBinding.txtTabUploadExamFile.setBackgroundColor(getResources().getColor(R.color.colorTab));
        mBinding.txtTabWriteExam.setBackgroundColor(getResources().getColor(R.color.colorWhite));
    }

    private void selectTabWriteExam(){
        mBinding.txtTabUploadExamFile.setBackgroundColor(getResources().getColor(R.color.colorWhite));
        mBinding.txtTabWriteExam.setBackgroundColor(getResources().getColor(R.color.colorTab));
    }
}
