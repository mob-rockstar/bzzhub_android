package com.learning.ashal.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class LastCourseModel {
    @SerializedName("id")
    @Expose
    public String id;

    @SerializedName("teacherId")
    @Expose
    public String teacherId;

    @SerializedName("firstName")
    @Expose
    public String firstName;

    @SerializedName("lastName")
    @Expose
    public String lastName;

    @SerializedName("title")
    @Expose
    public String title;

    @SerializedName("description")
    @Expose
    public String description;

    @SerializedName("image")
    @Expose
    public String image;

    @SerializedName("rating")
    @Expose
    public String rating;

    @SerializedName("price")
    @Expose
    public String price;

    @SerializedName("validity_date")
    @Expose
    public String validity_date;

    @SerializedName("isPurchasedBefore")
    @Expose
    public Boolean isPurchasedBefore;
}
