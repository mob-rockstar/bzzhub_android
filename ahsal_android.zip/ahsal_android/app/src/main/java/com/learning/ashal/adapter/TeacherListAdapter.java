package com.learning.ashal.adapter;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.learning.ashal.R;
import com.learning.ashal.databinding.RowLessonBinding;
import com.learning.ashal.databinding.RowTeacherListBinding;

import java.util.List;

public class TeacherListAdapter extends RecyclerView.Adapter<TeacherListAdapter.MyViewHolder> implements Filterable {

//    private OnItemClickListener onItemClickListener;
    private List<String> pumpModelList;


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowTeacherListBinding binding = DataBindingUtil.inflate( LayoutInflater.from(parent.getContext()), R.layout.row_teacher_list, parent, false);
        return new MyViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {


    }

//    public void setData(List<PumpModel> list){
//        this.pumpModelList = list;
//        notifyDataSetChanged();
//    }

    @Override
    public int getItemCount() {
        if(pumpModelList != null )
            return pumpModelList.size();
        return 10;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private RowTeacherListBinding binding;
        public MyViewHolder(RowTeacherListBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

//    public interface OnItemClickListener{
//        void onClick(PumpModel pumpModel);
//    }

//    protected List<ContactUserModel> getFilteredResults(String constraint) {
//        List<ContactUserModel> results = new ArrayList<>();
//
//        for (ContactUserModel item : mList) {
//            if (item.full_name.toLowerCase().contains(constraint)) {
//                results.add(item);
//            }
//        }
//        return results;
//    }

    @Override
    public Filter getFilter() {

        return new Filter() {

            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
//                List<ContactUserModel> filteredResults = null;
//                if (constraint.length() == 0) {
//                    filteredResults = mOriginalList;
//                } else {
//                    filteredResults = getFilteredResults(constraint.toString().toLowerCase());
//                }

                FilterResults results = new FilterResults();
//                results.values = filteredResults;

                return results;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults results) {
//                mList = (ArrayList<ContactUserModel>) results.values;
                notifyDataSetChanged();
            }
        };
    }
}
