package com.learning.ashal.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AnswerModel {
    @SerializedName("id")
    @Expose
    public String id;

    @SerializedName("questionId")
    @Expose
    public String questionId;

    @SerializedName("answer")
    @Expose
    public String answer;

    @SerializedName("status")
    @Expose
    public String status;

    @SerializedName("created_at")
    @Expose
    public String created_at;

    @SerializedName("updated_at")
    @Expose
    public String updated_at;

    @SerializedName("isCorrect")
    @Expose
    public String isCorrect;

    @SerializedName("type")
    @Expose
    public String type;

    @SerializedName("file")
    @Expose
    public String file;

    @SerializedName("letter")
    @Expose
    public String letter;

    @SerializedName("arabicLetter")
    @Expose
    public String arabicLetter;

    public boolean isSelected;
}
