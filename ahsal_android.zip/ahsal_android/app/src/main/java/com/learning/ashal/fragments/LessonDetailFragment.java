package com.learning.ashal.fragments;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.google.android.material.button.MaterialButton;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.learning.ashal.R;
import com.learning.ashal.activities.LoginActivity;
import com.learning.ashal.activities.MainActivity;
import com.learning.ashal.activities.VimeoPlayActivity;
import com.learning.ashal.adapter.RelativeLessonAdapter;
import com.learning.ashal.custom.CustomTextView;
import com.learning.ashal.custom.LinkCopyPopupWindow;
import com.learning.ashal.databinding.FragmentMathDetailBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.interfaces.QuestionCallbackListener;
import com.learning.ashal.model.LastCourseModel;
import com.learning.ashal.model.LessonModel;
import com.learning.ashal.model.MessageEvent;
import com.learning.ashal.utilities.AnimationUtils;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import com.learning.ashal.utilities.TempStore;

import org.greenrobot.eventbus.EventBus;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import static com.learning.ashal.utilities.Constants.BASE_URL;

public class LessonDetailFragment extends BaseFragment {

    private String TAG = LessonDetailFragment.class.getSimpleName();
    private FragmentMathDetailBinding mBinding;
    private RelativeLessonAdapter relativeLessonAdapter;
    private LessonModel lessonModel;
    private String subjectName;
    private String lessonId;
    private boolean isFromProfile;
    private CustomTextView txtTitle;
    private MaterialButton btNext;
    private String courseId;
    private String courseImage;

    public LessonDetailFragment(){

    }

    public LessonDetailFragment(String subjectName, LessonModel lessonModel, boolean isFromProfile, String courseId, String courseImage){
        this.lessonModel = lessonModel;
        this.subjectName = subjectName;
        this.isFromProfile = isFromProfile;
        this.courseId = courseId;
        this.courseImage = courseImage;
    }

    @Override
    public void updateUI() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorPrimary));
        if (!isFromProfile) {
            ((MainActivity)mActivity).setWhiteBk();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_math_detail, container, false);
        View view = mBinding.getRoot();
        updateUI();
        if(TempStore.lessonId != null){
            callGetLessonDetail(TempStore.lessonId);
        }else{
            initView();
        }
        return view;
    }

    private void initView() {
        if(!isFromProfile)
            ((MainActivity)mActivity).unsetTab();
        if(lessonModel == null)
            return;
        mBinding.txtSubject.setText(lessonModel.title);

        SimpleDateFormat dateParser = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH);
        try {
            Date date = dateParser.parse(lessonModel.created_at);
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
            mBinding.txtDate.setText(sdf.format(date));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        mBinding.txtLessonTitle.setText(lessonModel.title);
        mBinding.txtDesc.setText(lessonModel.description);

        mBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.back();
            }
        });

        txtTitle = mBinding.getRoot().findViewById(R.id.txtTitle);
        txtTitle.setText(getString(R.string.question_bank));
        btNext = mBinding.getRoot().findViewById(R.id.btNext);
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(TempStore.isLoggedIn){
                    FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new QuestionBankFragment(lessonModel.title, lessonModel.id), R.id.frameLayout);
                }else{
                    gotoLogin();
                }
            }
        });
        txtTitle.setVisibility(View.INVISIBLE);
        btNext.setVisibility(View.INVISIBLE);

        LinearLayoutManager layoutManager = new LinearLayoutManager(mActivity,LinearLayoutManager.HORIZONTAL,false);
        mBinding.rvRelatedLesson.setLayoutManager(layoutManager);
        relativeLessonAdapter = new RelativeLessonAdapter(new RelativeLessonAdapter.OnItemClickListener() {
            @Override
            public void onClick(LessonModel lessonModel) {
                if (TempStore.isLoggedIn){
                    if(lessonModel.isPurchased){
                        FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new LessonDetailFragment(subjectName, lessonModel, isFromProfile, courseId, courseImage), R.id.frameLayout);
                    }else{
                        openQuestionDlg(getResources().getString(R.string.msg_purchase_course),
                                getString(R.string.buy_course), getString(R.string.cancel), new QuestionCallbackListener() {
                            @Override
                            public void onYes() {
                                callGetCoursePerLesson(lessonModel);
                            }

                            @Override
                            public void onNo() {

                            }
                        });
                    }
                }else {
                    gotoLogin();
                }
            }
        }, mActivity);
        mBinding.rvRelatedLesson.setAdapter(relativeLessonAdapter);

        mBinding.imgPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mActivity, VimeoPlayActivity.class);
                intent.putExtra("uri", lessonModel.file);
                intent.putExtra("courseTitle", subjectName);
                intent.putExtra("lessonName", lessonModel.title);
                intent.putExtra("vimeoId", lessonModel.vimeoId);
                intent.putExtra("lessonImage", lessonModel.cover);
                intent.putExtra("courseImage", courseImage);
                intent.putExtra("courseId", courseId);
                startActivity(intent);
            }
        });

        mBinding.llFileExam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TempStore.isLoggedIn){
                    if(!hasProfile()){
                        openQuestionDlg(getString(R.string.add_student_profile), getString(R.string.add), getString(R.string.cancel),new QuestionCallbackListener() {
                            @Override
                            public void onYes() {
                                ((MainActivity)mActivity).selectNewProfile();
                            }
                            @Override
                            public void onNo() {

                            }
                        });
                        return;
                    }
                    FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new MathFileFragment(lessonModel.title, lessonModel.id), R.id.frameLayout);
                }else{
                    gotoLogin();
                }
            }
        });

        mBinding.llTest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TempStore.isLoggedIn){
                    FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new TestUnderstandingFragment(lessonModel.title, lessonModel.id), R.id.frameLayout);
                }else {
                    gotoLogin();
                }
            }
        });
        
        mBinding.llShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TempStore.isLoggedIn){
                    openSelectDlg();
                }else {
                    gotoLogin();
                }
            }
        });

        mBinding.llSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TempStore.isLoggedIn){
                    if(!hasProfile()){
                        openQuestionDlg(getString(R.string.add_student_profile), getString(R.string.add), getString(R.string.cancel),new QuestionCallbackListener() {
                            @Override
                            public void onYes() {
                                ((MainActivity)mActivity).selectNewProfile();
                            }
                            @Override
                            public void onNo() {

                            }
                        });
                        return;
                    }
                    FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new MathFileFragment(lessonModel.title, lessonModel.id, true), R.id.frameLayout);
                }else {
                    gotoLogin();
                }
            }
        });

        AnimationUtils.animateSlideTopFromDown(mActivity, mBinding.llSelect);
        AnimationUtils.animateSlideTopFromDown(mActivity, mBinding.txtDesc);
        callGetRelativeLesson();
    }

    private LinkCopyPopupWindow linkCopyPopupWindow;
    private void openSelectDlg(){
//        View view = ((LayoutInflater)mActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.dialog_layout_share_session, null);
//        linkCopyPopupWindow = new LinkCopyPopupWindow(view, new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                switch (v.getId()) {
//                    case R.id.btCancel:
//                        linkCopyPopupWindow.dismiss();
//                        break;
//                    case R.id.txtCopySessionLink:
//                        String link = generateLessonLink();
//                        if (link != null){
//                            Intent share = new Intent(android.content.Intent.ACTION_SEND);
//                            share.setType("text/plain");
//                            share.putExtra(Intent.EXTRA_TEXT, link);
//                            startActivity(Intent.createChooser(share, getResources().getString(R.string.share)));
//                        }
////                        linkCopyPopupWindow.dismiss();
//                        break;
//                }
//            }
//        });
//        linkCopyPopupWindow.showAtLocation(mBinding.getRoot(), Gravity.CENTER, 0, 0);

        String link = generateLessonLink();
        if (link != null){
            Intent share = new Intent(android.content.Intent.ACTION_SEND);
            share.setType("text/plain");
            share.putExtra(Intent.EXTRA_TEXT, link);
            startActivity(Intent.createChooser(share, getResources().getString(R.string.share)));
        }
    }

    private void gotoLogin(){
        Intent intent = new Intent(mActivity, LoginActivity.class);
        intent.putExtra("fromGuest", true);
        startActivity(intent);
    }

    private String generateLessonLink() {
        Uri.Builder builder = new Uri.Builder()
                .scheme("https")
                .authority("ashal.om")
                .path("/lesson/"+ lessonModel.id);

        final Uri appLink = builder.build();

        try{
            URL dynamicLinkUrl = new URL(URLDecoder.decode(appLink.toString(), "UTF-8"));
            return dynamicLinkUrl.toString();
//            ClipboardManager clipboard = (ClipboardManager) mActivity.getSystemService(CLIPBOARD_SERVICE);
//            ClipData clip = ClipData.newPlainText("label",  dynamicLinkUrl.toString());
//            clipboard.setPrimaryClip(clip);
//            linkCopyPopupWindow.showSuccess();
        }catch (UnsupportedEncodingException | MalformedURLException ex){
            ex.printStackTrace();
        }
        return null;
    }

    private void callGetLessonDetail(String lessonId){
        if(getStudentId() == null){
            Toast.makeText(mActivity, getString(R.string.select_default_student), Toast.LENGTH_SHORT).show();
            return;
        }
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.lessonDetail(lessonId, getStudentId());
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                TempStore.lessonId = null;
                TempStore.isFromAppLink = false;
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<LessonModel>() {}.getType();
                            try{
                                JsonObject data = jsonObject.get("data").getAsJsonObject();
                                if(data.get("isPurchased").getAsBoolean()){
                                    lessonModel = gson.fromJson(data.get("lesson").getAsJsonObject(), type);
                                    initView();
                                }else{
                                    androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(mActivity);
                                    builder.setTitle(getResources().getString(R.string.app_name));
                                    builder.setMessage(getResources().getString(R.string.msg_purchase_course));
                                    builder.setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                        }
                                    });
                                    builder.show();
                                    mActivity.back();
                                }

                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                TempStore.lessonId = null;
                TempStore.isFromAppLink = false;
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private void callGetRelativeLesson(){
        String id = getStudentId();
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.relativeLesson(lessonModel.title, id == null ? "" : id);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                TempStore.lessonId = null;
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<List<LessonModel>>() {}.getType();
                            try{
                               List<LessonModel> lessonModelList = gson.fromJson(jsonObject.get("data").getAsJsonArray(), type);
                               if(lessonModelList != null && lessonModelList.size() > 0){
                                   mBinding.txtNoData.setVisibility(View.GONE);
                                   relativeLessonAdapter.setData(lessonModelList);
                               }else{
                                   mBinding.txtNoData.setVisibility(View.VISIBLE);
                                   relativeLessonAdapter.setData(null);
                               }
                                txtTitle.setVisibility(View.VISIBLE);
                                btNext.setVisibility(View.VISIBLE);
                                AnimationUtils.animateSlideTopFromDown(mActivity, mBinding.txtRvTitle);
                                AnimationUtils.animateSlideTopFromDown(mActivity, mBinding.rvRelatedLesson);

                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private void callGetCoursePerLesson(LessonModel lessonModel){
        if(getStudentId() == null){
            Toast.makeText(mActivity, getString(R.string.select_default_student), Toast.LENGTH_SHORT).show();
            return;
        }
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.callGetCoursePerLesson(lessonModel.id, getStudentId());
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<LastCourseModel>() {}.getType();
                            try{
                                LastCourseModel lastCourseModel = gson.fromJson(jsonObject.get("data").getAsJsonObject(), type);
                                if(!TempStore.isLoggedIn){
                                    Toast.makeText(mActivity, getString(R.string.register_ashal), Toast.LENGTH_SHORT).show();
                                    return;
                                }
                                if(getStudentId() == null){
                                    Toast.makeText(mActivity, getString(R.string.select_default_student), Toast.LENGTH_SHORT).show();
                                    return;
                                }
                                //already exists in cart
                                for(LastCourseModel lastCourseModel1: TempStore.cartList){
                                    if(lastCourseModel.id.equals(lastCourseModel1.id)){
                                        FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new CheckoutFragment(lastCourseModel, isFromProfile), R.id.frameLayout);
                                        return;
                                    }
                                }
                                //newly
                                TempStore.cartList.add(lastCourseModel);
                                saveCartToLocalDB(lastCourseModel);
                                MessageEvent messageEvent = new MessageEvent();
                                messageEvent.messageType = MessageEvent.MessageType.CART_BADGE_SHOW;
                                EventBus.getDefault().post(messageEvent);
                                FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new CheckoutFragment(lastCourseModel, isFromProfile), R.id.frameLayout);
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }
}
