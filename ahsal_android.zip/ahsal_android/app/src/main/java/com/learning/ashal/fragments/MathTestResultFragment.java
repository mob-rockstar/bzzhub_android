package com.learning.ashal.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.databinding.DataBindingUtil;

import com.bumptech.glide.Glide;
import com.google.android.material.button.MaterialButton;
import com.learning.ashal.R;
import com.learning.ashal.adapter.AnswerTestScoreAdapter;
import com.learning.ashal.custom.CustomTextView;
import com.learning.ashal.databinding.FragmentMathTestResultBinding;
import com.learning.ashal.model.AnswerModel;
import com.learning.ashal.model.QuestionModel;
import com.learning.ashal.model.SelAnswerModel;

import java.util.List;

public class MathTestResultFragment extends BaseFragment {

    private String TAG = MathTestResultFragment.class.getSimpleName();
    private FragmentMathTestResultBinding mBinding;
    private List<QuestionModel> questionModelList;
    private SelAnswerModel[] selectedAnswerList;
    private boolean[] selectedQuestionBankAnswerList;
    private AnswerModel[] correctAnswerList;
    private String title;

    public MathTestResultFragment(){

    }

    public MathTestResultFragment(String title, List<QuestionModel> questionModelList, SelAnswerModel[] selectedAnswerList){
        this.questionModelList = questionModelList;
        this.selectedAnswerList = selectedAnswerList;
        this.title = title;
    }

//    public MathTestResultFragment(String title, List<QuestionModel> questionModelList, boolean[] selectedAnswerList){
//        this.questionModelList = questionModelList;
//        this.selectedQuestionBankAnswerList = selectedAnswerList;
//        this.title = title;
//    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_math_test_result, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    private void initView() {
        mBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.back();
                mActivity.back();
            }
        });
        mBinding.txtSubject.setText(title);

        CustomTextView txtTitle = mBinding.getRoot().findViewById(R.id.txtTitle);
        txtTitle.setText(getString(R.string.finish));

        MaterialButton btNext = mBinding.getRoot().findViewById(R.id.btNext);
        btNext.setBackgroundColor(getResources().getColor(R.color.colorTypeBk));
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mActivity.back();
                mActivity.back();
            }
        });

        mBinding.txtTryAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               mActivity.back();
            }
        });

        int answerCount = 0;
        if(selectedAnswerList != null){
            for(int i = 0; i < selectedAnswerList.length; i++){
                if(selectedAnswerList[i].isCorrect){
                    answerCount++;
                }
            }
        }else{
            for(int i = 0; i < selectedQuestionBankAnswerList.length; i++){
                if(selectedQuestionBankAnswerList[i]){
                    answerCount++;
                }
            }
        }

        if(answerCount * 100/questionModelList.size() >= 70){
            mBinding.txtTip.setText(getString(R.string.excellent));
            Glide.with(mActivity).load(R.drawable.score_star3).into(mBinding.imgStar);
        }else if(answerCount * 100/questionModelList.size() >= 40){
            mBinding.txtTip.setText(getString(R.string.good_can_do_more));
            Glide.with(mActivity).load(R.drawable.score_star2).into(mBinding.imgStar);
        }else if(answerCount * 100/questionModelList.size()  == 0){
            mBinding.txtTip.setText(getString(R.string.try_best_next));
            Glide.with(mActivity).load(R.drawable.score_star).into(mBinding.imgStar);
        }else{
            mBinding.txtTip.setText(getString(R.string.try_best_next));
            Glide.with(mActivity).load(R.drawable.score_star1).into(mBinding.imgStar);
        }

        if(answerCount * 100/questionModelList.size() >= 60){
            mBinding.txtTryAgain.setVisibility(View.GONE);
        }else{
            mBinding.txtTryAgain.setVisibility(View.VISIBLE);
        }

        if(answerCount * 100/questionModelList.size() >= 90){
            mBinding.imgCong.setVisibility(View.VISIBLE);
        }else{
            mBinding.imgCong.setVisibility(View.GONE);
        }

        mBinding.txtScore.setText(getString(R.string.score_pro, answerCount+"", questionModelList.size()+"" ));

        correctAnswerList = new AnswerModel[questionModelList.size()];
        for(int i = 0; i < questionModelList.size(); i++){
            for(AnswerModel answerModel : questionModelList.get(i).answerModelList){
                if(answerModel.isCorrect.equals("1")){
                    correctAnswerList[i] = answerModel;
                    break;
                }
            }
        }

        AnswerTestScoreAdapter answerTestScoreAdapter = new AnswerTestScoreAdapter(mActivity);
        mBinding.rvTestResultAnswer.setAdapter(answerTestScoreAdapter);
        answerTestScoreAdapter.setData(questionModelList, selectedAnswerList, correctAnswerList);
    }
}
