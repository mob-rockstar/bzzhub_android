package com.learning.ashal.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.Toast;

import androidx.databinding.DataBindingUtil;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.learning.ashal.R;
import com.learning.ashal.adapter.TeacherAnswerAdapter;
import com.learning.ashal.databinding.FragmentTeacherNewQuestionBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.interfaces.QuestionCallbackListener;
import com.learning.ashal.model.AnswerModel;
import com.learning.ashal.model.FileModel;
import com.learning.ashal.model.MessageEvent;
import com.learning.ashal.model.QuestionModel;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.File;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import static com.learning.ashal.utilities.Constants.BASE_URL;

public class TeacherNewQuestionFragment extends BaseCameraFragment {

    private String TAG = TeacherNewQuestionFragment.class.getSimpleName();
    private FragmentTeacherNewQuestionBinding mBinding;
    private TeacherAnswerAdapter teacherAnswerAdapter;
    private boolean isText;
    private boolean isChoice;
    private String lessonId;
    private List<String> correctAnswerCountList = new ArrayList<String>();
    private String numberOfCorrectAnswers;
    private String questionId;
    private boolean isNotification;
    private List<AnswerModel> answerModelList;
    private QuestionModel questionModel;

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventFragment(MessageEvent messageEvent) {
        if(messageEvent.messageType.equals(MessageEvent.MessageType.ANSWER_REFRESH)){
            isNotification = true;
            callGetAnswerList();
        }
    }

    public TeacherNewQuestionFragment(){

    }

    public TeacherNewQuestionFragment(String lessonId){
        this.lessonId = lessonId;
    }

    public TeacherNewQuestionFragment(String lessonId, QuestionModel questionModel){
        this.lessonId = lessonId;
        this.questionModel = questionModel;
        this.questionId = questionModel.id;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_teacher_new_question, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    private void initView() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorWhite));

        mBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.back();
            }
        });

        mBinding.radioText.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b)
                    setRadioText();
            }
        });

        mBinding.radioImage.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b)
                    setRadioImage();
            }
        });

        mBinding.radioChoice.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b)
                    setRadioChoice();
            }
        });

        mBinding.radioDrag.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b)
                    setRadioDrag();
            }
        });

        mBinding.btUploadQuestion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSelectDlg(mBinding.getRoot(), mBinding.imgQuestion);
            }
        });

        mBinding.btNewAnswer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(questionId == null){
                    showErrorMessage(mBinding.getRoot(), getString(R.string.create_question_required));
                }else{
                    FragmentProcess.addFragment(mActivity.getSupportFragmentManager(), new AddAnswerPopupFragment(questionId, isChoice), R.id.frameLayout);
                }
            }
        });

        mBinding.btSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkValidation()){
                    if(questionModel == null){
                        callCreateQuestion();
                    }else {
                        callUpdateQuestion(questionModel.id);
                    }
                }
            }
        });

        mBinding.spnCorrectAnswers.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                int position = parent.getSelectedItemPosition();
                numberOfCorrectAnswers = correctAnswerCountList.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });

        for(int i = 1; i< 11; i++){
            correctAnswerCountList.add(""+ i);
        }

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(mActivity, android.R.layout.simple_spinner_item, correctAnswerCountList);
//        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mBinding.spnCorrectAnswers.setAdapter(dataAdapter);

        teacherAnswerAdapter = new TeacherAnswerAdapter(mActivity, new TeacherAnswerAdapter.OnItemClickListener() {
            @Override
            public void onClick(AnswerModel answerModel) {
                FragmentProcess.addFragment(mActivity.getSupportFragmentManager(), new AddAnswerPopupFragment(questionId, answerModel, isChoice), R.id.frameLayout);
            }

            @Override
            public void onDelete(AnswerModel answerModel) {
                openQuestionDlg(getString(R.string.sure_delete_answer), new QuestionCallbackListener() {
                    @Override
                    public void onYes() {
                        callRemoveAnswer(answerModel);
                    }

                    @Override
                    public void onNo() {

                    }
                });
            }
        });
        mBinding.rvAnswer.setAdapter(teacherAnswerAdapter);

        if(questionModel == null){
            mBinding.radioDrag.setEnabled(true);
            mBinding.radioChoice.setEnabled(true);
            setRadioText();
            setRadioChoice();
            mBinding.txtTopTitle.setText(getResources().getString(R.string.new_question));
        }else{
            //edit
            mBinding.txtTopTitle.setText(getResources().getString(R.string.eidt_question));
            if(questionModel.type.equals("drag")){
                setRadioDrag();
                mBinding.etDragQuestion.setText(questionModel.question);
                mBinding.spnCorrectAnswers.setSelection(Integer.parseInt(questionModel.numberOfCorrectAnswers) - 1);
            }else{
                setRadioChoice();
                if(questionModel.type.equals("text")){
                    setRadioText();
                    mBinding.etQuestion.setText(questionModel.question);
                }else if(questionModel.type.equals("image")){
                    setRadioImage();
                    if(questionModel.file != null)
                        Glide.with(mActivity).load(questionModel.file).into(mBinding.imgQuestion);
                }
            }
            mBinding.radioDrag.setEnabled(false);
            mBinding.radioChoice.setEnabled(false);
            answerModelList = questionModel.answerModelList;
            teacherAnswerAdapter.setData(questionModel.answerModelList);
        }
    }

    private void setRadioText(){
        isText = true;
        mBinding.radioText.setChecked(true);
        mBinding.radioImage.setChecked(false);
        mBinding.llQuestionText.setVisibility(View.VISIBLE);
        mBinding.llQuestionImage.setVisibility(View.GONE);
    }

    private void setRadioImage(){
        isText = false;
        mBinding.llQuestionText.setVisibility(View.GONE);
        mBinding.llQuestionImage.setVisibility(View.VISIBLE);
        mBinding.radioImage.setChecked(true);
        mBinding.radioText.setChecked(false);
    }

    private void setRadioDrag(){
        isChoice = false;
        mBinding.radioDrag.setChecked(true);
        mBinding.radioChoice.setChecked(false);
        mBinding.llChoice.setVisibility(View.GONE);
        mBinding.llDrag.setVisibility(View.VISIBLE);
    }

    private void setRadioChoice(){
        isChoice = true;
        mBinding.radioDrag.setChecked(false);
        mBinding.radioChoice.setChecked(true);
        mBinding.llChoice.setVisibility(View.VISIBLE);
        mBinding.llDrag.setVisibility(View.GONE);
    }

    private boolean checkValidation(){
        if(isChoice){
            if(isText){
                if(mBinding.etQuestion.getText().toString().isEmpty()){
                    showErrorMessage(mBinding.parent, getString(R.string.enter_question));
                    return false;
                }
            }else{
                if(path == null && questionModel == null){
                    showErrorMessage(mBinding.parent, getString(R.string.upload_file));
                    return false;
                }
            }
        }else{
            if(mBinding.etDragQuestion.getText().toString().isEmpty()){
                showErrorMessage(mBinding.parent, getString(R.string.enter_question));
                return false;
            }
        }
        return true;
    }

    private void callCreateQuestion(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        MultipartBody.Part file = null;
        RequestBody questionBody = null;
        RequestBody numberOfCorrectAnswersBody = null;
        RequestBody lessonIdBody = RequestBody.create(MediaType.parse("text/plain"), lessonId);
        RequestBody typeBody;

        if(isChoice){
            if(isText){
                questionBody = RequestBody.create(MediaType.parse("text/plain"), mBinding.etQuestion.getText().toString());
            }else{
                if (path != null && new File(path).exists()) {
                    File f = new File(path);
                    RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), f);
                    file = MultipartBody.Part.createFormData("file", f.getName(), requestFile);
                }
            }
            typeBody = RequestBody.create(MediaType.parse("text/plain"), isText ? "text" : "image");
        }else{
            typeBody = RequestBody.create(MediaType.parse("text/plain"), "drag");
            questionBody = RequestBody.create(MediaType.parse("text/plain"), mBinding.etDragQuestion.getText().toString());
            numberOfCorrectAnswersBody = RequestBody.create(MediaType.parse("text/plain"), numberOfCorrectAnswers);
        }

        HashMap<String, RequestBody> map = new HashMap<>();
        map.put("lessonId", lessonIdBody);
        map.put("type", typeBody);
        if(questionBody != null)
            map.put("question", questionBody);
        if(numberOfCorrectAnswersBody != null)
            map.put("numberOfCorrectAnswers", numberOfCorrectAnswersBody);

        Call<JsonObject> call = apiInterface.createQuestion(map, file);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            questionId = jsonObject.get("data").getAsJsonObject().get("id").getAsString();
                            MessageEvent messageEvent = new MessageEvent();
                            messageEvent.messageType = MessageEvent.MessageType.QUESTION_REFRESH;
                            EventBus.getDefault().post(messageEvent);
                            showSuccessMessage(mBinding.getRoot(),  jsonObject.get("message").getAsString());
                        }else{
                            showErrorMessage(mBinding.getRoot(),  jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private void callUpdateQuestion(String questionId){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        MultipartBody.Part file = null;
        RequestBody questionBody = null;
        RequestBody numberOfCorrectAnswersBody = null;
        RequestBody questionIdBody = RequestBody.create(MediaType.parse("text/plain"), questionId);
        RequestBody typeBody;

        if(isChoice){
            if(isText){
                questionBody = RequestBody.create(MediaType.parse("text/plain"), mBinding.etQuestion.getText().toString());
            }else{
                if (path != null && new File(path).exists()) {
                    File f = new File(path);
                    RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), f);
                    file = MultipartBody.Part.createFormData("file", f.getName(), requestFile);
                }
            }
            typeBody = RequestBody.create(MediaType.parse("text/plain"), isText ? "text" : "image");
        }else{
            typeBody = RequestBody.create(MediaType.parse("text/plain"), "drag");
            questionBody = RequestBody.create(MediaType.parse("text/plain"), mBinding.etDragQuestion.getText().toString());
            numberOfCorrectAnswersBody = RequestBody.create(MediaType.parse("text/plain"), numberOfCorrectAnswers);
        }

        HashMap<String, RequestBody> map = new HashMap<>();
        map.put("id", questionIdBody);
        map.put("type", typeBody);
        if(questionBody != null)
            map.put("question", questionBody);
        if(numberOfCorrectAnswersBody != null)
            map.put("numberOfCorrectAnswers", numberOfCorrectAnswersBody);

        Call<JsonObject> call = apiInterface.updateQuestion(map, file);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            MessageEvent messageEvent = new MessageEvent();
                            messageEvent.messageType = MessageEvent.MessageType.QUESTION_REFRESH;
                            EventBus.getDefault().post(messageEvent);
                            mActivity.back();
                        }else{
                            showErrorMessage(mBinding.getRoot(),  jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private void callGetAnswerList(){
        if(!isNotification)
            ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.answerList(questionId);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if(!isNotification)
                    ProgressDialog.hideprogressbar();
                isNotification = false;
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<List<AnswerModel>>() {}.getType();
                            try{
                                answerModelList = gson.fromJson(jsonObject.get("data").getAsJsonArray(), type);
                                if(answerModelList != null && answerModelList.size() > 0){
                                    teacherAnswerAdapter.setData(answerModelList);
                                    mBinding.txtNoData.setVisibility(View.GONE);
                                }else{
                                    teacherAnswerAdapter.setData(null);
                                    mBinding.txtNoData.setVisibility(View.VISIBLE);
                                }
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                if(!isNotification)
                    ProgressDialog.hideprogressbar();
                isNotification = false;
            }
        });
    }

    private void callRemoveAnswer(AnswerModel answerModel){
        if(!isNotification)
            ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.removeAnswer(answerModel.id);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if(!isNotification)
                    ProgressDialog.hideprogressbar();
                isNotification = false;
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                           answerModelList.remove(answerModel);
                           teacherAnswerAdapter.notifyDataSetChanged();
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                if(!isNotification)
                    ProgressDialog.hideprogressbar();
                isNotification = false;
            }
        });
    }
}
