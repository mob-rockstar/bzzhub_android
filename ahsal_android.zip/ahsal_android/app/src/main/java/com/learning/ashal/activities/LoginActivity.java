package com.learning.ashal.activities;

import android.os.Bundle;

import com.learning.ashal.R;
import com.learning.ashal.fragments.ChooseTypeFragment;
import com.learning.ashal.fragments.LoginFragment;
import com.learning.ashal.utilities.FragmentProcess;

public class LoginActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        FragmentProcess.replaceFragment(getSupportFragmentManager(), new ChooseTypeFragment(),  R.id.frameLayout);
    }
}
