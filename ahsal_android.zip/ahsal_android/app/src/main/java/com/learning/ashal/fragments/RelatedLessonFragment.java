package com.learning.ashal.fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.android.material.button.MaterialButton;
import com.learning.ashal.R;
import com.learning.ashal.activities.VideoPlayActivity;
import com.learning.ashal.adapter.RelativeLessonAdapter;
import com.learning.ashal.custom.CustomTextView;
import com.learning.ashal.custom.LinkCopyPopupWindow;
import com.learning.ashal.databinding.FragmentRelatedLessonlBinding;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.LocaleHelper;

public class RelatedLessonFragment extends BaseFragment {

    private String TAG = RelatedLessonFragment.class.getSimpleName();
    private FragmentRelatedLessonlBinding mBinding;
    private RelativeLessonAdapter relativeLessonAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_related_lessonl, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }



    private void initView() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorPrimary));

        mBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.back();
            }
        });

        CustomTextView txtTitle = mBinding.getRoot().findViewById(R.id.txtTitle);
        txtTitle.setText(getString(R.string.question_bank));
        MaterialButton btNext = mBinding.getRoot().findViewById(R.id.btNext);
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentProcess.replaceFragment(mActivity.getSupportFragmentManager(), new QuestionBankFragment(), R.id.frameLayout);
            }
        });

        LinearLayoutManager layoutManager = new LinearLayoutManager(mActivity,LinearLayoutManager.HORIZONTAL,false);
        mBinding.rvRelatedLesson.setLayoutManager(layoutManager);
//        relativeLessonAdapter = new RelativeLessonAdapter(new RelativeLessonAdapter.OnItemClickListener() {
//            @Override
//            public void onClick() {
////                FragmentProcess.replaceFragment(mActivity.getSupportFragmentManager(), new RelatedLessonFragment(), R.id.frameLayout);
//            }
//        });
        mBinding.rvRelatedLesson.setAdapter(relativeLessonAdapter);


        mBinding.imgPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mActivity, VideoPlayActivity.class));
            }
        });

        mBinding.llFileExam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentProcess.replaceFragment(mActivity.getSupportFragmentManager(), new MathFileFragment(), R.id.frameLayout);
            }
        });

        mBinding.llTest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentProcess.replaceFragment(mActivity.getSupportFragmentManager(), new MathTestFragment(), R.id.frameLayout);
            }
        });
        mBinding.llShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSelectDlg();
            }
        });
    }

    private LinkCopyPopupWindow linkCopyPopupWindow;
    private void openSelectDlg(){
        View view = ((LayoutInflater)mActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.dialog_layout_share_session, null);
        linkCopyPopupWindow = new LinkCopyPopupWindow(view, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.btCancel:
                        linkCopyPopupWindow.dismiss();
                        break;
                }
            }
        });
        linkCopyPopupWindow.showAtLocation(mBinding.getRoot(), Gravity.CENTER, 0, 0);
    }
}
