package com.learning.ashal.adapter;

import android.content.Context;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.learning.ashal.R;
import com.learning.ashal.custom.SingleClickListener;
import com.learning.ashal.databinding.RowMathFileBinding;
import com.learning.ashal.databinding.RowVideoDownloadBinding;
import com.learning.ashal.model.DownloadedVideoModel;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class VideoDownloadAdapter extends RecyclerView.Adapter<VideoDownloadAdapter.MyViewHolder> implements Filterable {

    private OnItemClickListener onItemClickListener;
    private List<DownloadedVideoModel> downloadedVideoModelList, mOriginalList;
    private Context context;
    private String baseDir = Environment.getExternalStorageDirectory() + "/ashal/";

    public VideoDownloadAdapter(Context context, OnItemClickListener onItemClickListener){
        this.context = context;
        this.onItemClickListener = onItemClickListener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowVideoDownloadBinding binding = DataBindingUtil.inflate( LayoutInflater.from(parent.getContext()), R.layout.row_video_download, parent, false);
        return new MyViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        DownloadedVideoModel downloadedVideoModel = downloadedVideoModelList.get(position);

        holder.binding.txtTitle.setText(downloadedVideoModel.courseTitle);
        holder.binding.txtLessonName.setText(downloadedVideoModel.lessonName);
        holder.binding.txtDate.setText(downloadedVideoModel.date);

        holder.binding.row.setOnClickListener(new SingleClickListener() {
            @Override
            public void performClick(View view) {
                onItemClickListener.onClick(downloadedVideoModel);
            }
        });

        holder.binding.imgDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onItemClickListener.onDelete(downloadedVideoModel);
            }
        });

        File file = new File( baseDir + downloadedVideoModel.lessonName);
        if(file.exists())
            Glide.with(context).load(file).into(holder.binding.imgLesson);

    }

    public void setData(List<DownloadedVideoModel> list){
        this.downloadedVideoModelList = list;

        mOriginalList = list;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if(downloadedVideoModelList != null )
            return downloadedVideoModelList.size();
        return 0;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private RowVideoDownloadBinding binding;
        public MyViewHolder(RowVideoDownloadBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public interface OnItemClickListener{
        void onClick(DownloadedVideoModel downloadedVideoModel);
        void onDelete(DownloadedVideoModel downloadedVideoModel);
    }

    protected List<DownloadedVideoModel> getFilteredResults(String constraint) {
        List<DownloadedVideoModel> results = new ArrayList<>();

        for (DownloadedVideoModel item : downloadedVideoModelList) {
            if (item.lessonName.toLowerCase().contains(constraint)) {
                results.add(item);
            }
        }
        return results;
    }

    @Override
    public Filter getFilter() {

        return new Filter() {

            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                List<DownloadedVideoModel> filteredResults = null;
                if (constraint.length() == 0) {
                    filteredResults = mOriginalList;
                } else {
                    filteredResults = getFilteredResults(constraint.toString().toLowerCase());
                }

                FilterResults results = new FilterResults();
                results.values = filteredResults;

                return results;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults results) {
                downloadedVideoModelList = (ArrayList<DownloadedVideoModel>) results.values;
                notifyDataSetChanged();
            }
        };
    }
}
