package com.learning.ashal.activities;

import android.os.Bundle;

import androidx.databinding.DataBindingUtil;

import com.learning.ashal.R;
import com.learning.ashal.databinding.ActivityPdfViewerBinding;
import com.learning.ashal.fragments.AboutUsFragment;
import com.learning.ashal.utilities.FragmentProcess;

import java.io.File;

public class PDFViewerActivity extends BaseActivity {
    private ActivityPdfViewerBinding mbinding;
    private String file;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mbinding = DataBindingUtil.setContentView(this, R.layout.activity_pdf_viewer);

        if(getIntent() != null){
            file = getIntent().getStringExtra("file");
            mbinding.pdfView.fromFile(new File(file)).load();
        }
    }
}
