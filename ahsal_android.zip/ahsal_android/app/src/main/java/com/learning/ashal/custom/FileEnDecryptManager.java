package com.learning.ashal.custom;

import android.util.Log;

import java.io.File;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;


public class FileEnDecryptManager {

    private String key = "abcdefg";

    private FileEnDecryptManager() {
    }

    private static FileEnDecryptManager instance = null;

    public static FileEnDecryptManager getInstance() {
        synchronized (FileEnDecryptManager.class) {
            if (instance == null) {
                instance = new FileEnDecryptManager();
            }
        }
        return instance;
    }


    public boolean doEncrypt(String fileUrl) {
//        try {
//            if (isDecrypted(fileUrl)) {
                if (encrypt(fileUrl)) {
                    // 可在此处保存加密状态到数据库或文件(you can save state into db or file)
                    Log.d("FileEnDecryptManager","encrypt succeed");
                    return true;
                } else {
                    Log.d("FileEnDecryptManager","encrypt failed");
                    return false;
                }
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        return false;
    }

    private final int REVERSE_LENGTH = 28; // 加解密长度(Encryption length)

    private boolean encrypt(String strFile) {
        int len = REVERSE_LENGTH;
        try {
            File f = new File(strFile);
            if (f.exists()) {
                RandomAccessFile raf = new RandomAccessFile(f, "rw");
                long totalLen = raf.length();

                if (totalLen < REVERSE_LENGTH)
                    len = (int) totalLen;

                FileChannel channel = raf.getChannel();
                MappedByteBuffer buffer = channel.map(
                        FileChannel.MapMode.READ_WRITE, 0, REVERSE_LENGTH);
                byte tmp;
                for (int i = 0; i < len; ++i) {
                    byte rawByte = buffer.get(i);
                    if (i <= key.length() - 1) {
                        tmp = (byte) (rawByte ^ key.charAt(i)); // (XOR operation)
                    } else {
                        tmp = (byte) (rawByte ^ i);
                    }
                    buffer.put(i, tmp);
                }
                buffer.force();
                buffer.clear();
                channel.close();
                raf.close();
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public void doDecrypt(String fileUrl) {
        try {
//            if (!isDecrypted(fileUrl)) {
                decrypt(fileUrl);
//            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void decrypt(String fileUrl) {
        if (encrypt(fileUrl)) {
            // 可在此处保存解密状态到数据库或文件(you can save state into db or file)
            Log.d("FileEnDecryptManager","decrypt succeed");
        }
    }

//    private boolean isDecrypted(String filePath) throws IOException {
//        // 从数据库或者文件中取出此路径对应的状态(get state out from db or file)
//    }
}