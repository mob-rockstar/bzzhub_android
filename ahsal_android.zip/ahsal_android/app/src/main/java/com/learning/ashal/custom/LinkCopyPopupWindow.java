package com.learning.ashal.custom;


import android.content.ClipData;
import android.content.ClipboardManager;
import android.view.MotionEvent;
import android.view.View;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;

import com.learning.ashal.R;

import static android.content.Context.CLIPBOARD_SERVICE;

public class LinkCopyPopupWindow extends PopupWindow
{
    private CustomButton cancelBtn;
    private CustomTextView txtCopy;
    private CustomTextView txtSuccess;

    public LinkCopyPopupWindow(final View mMenuView, View.OnClickListener paramOnClickListener)
    {
        super(mMenuView , RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT,true);

        cancelBtn = mMenuView.findViewById(R.id.btCancel);
        txtCopy = mMenuView.findViewById(R.id.txtCopySessionLink);
        txtSuccess = mMenuView.findViewById(R.id.txtCopySuccess);
        cancelBtn.setOnClickListener(paramOnClickListener);
        txtCopy.setOnClickListener(paramOnClickListener);

        setContentView(mMenuView);
        setFocusable(true);
        setAnimationStyle(R.style.PopupAnimation);
        mMenuView.setOnTouchListener(new View.OnTouchListener()
        {
            public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
            {
                int i = mMenuView.findViewById(R.id.pop_layout).getTop();
                int j = (int)paramMotionEvent.getY();
                if ((paramMotionEvent.getAction() == 1) && (j < i))
                    dismiss();
                return true;
            }
        });
    }

    public void showSuccess(){
        txtSuccess.setVisibility(View.VISIBLE);
    }
}

