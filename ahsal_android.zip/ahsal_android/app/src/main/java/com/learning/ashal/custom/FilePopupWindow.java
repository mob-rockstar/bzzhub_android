package com.learning.ashal.custom;

import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;

import com.learning.ashal.R;

public class FilePopupWindow extends PopupWindow
{
    private CustomButton btUploadFile;
    private CustomButton btSelectFile;
    private CustomEditText etTitle;
    private CustomTextView txtError;

    public FilePopupWindow(final View mMenuView, OnClickListener paramOnClickListener)
    {
        super(mMenuView , RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT,true);


        btUploadFile = mMenuView.findViewById(R.id.btUploadFile);
        btSelectFile = mMenuView.findViewById(R.id.btSelectFile);
        etTitle = mMenuView.findViewById(R.id.etTitle);
        txtError = mMenuView.findViewById(R.id.txtError);

        ImageView imgClose = mMenuView.findViewById(R.id.imgClose);
        imgClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
            }
        });

        btUploadFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                paramOnClickListener.onUpload(etTitle.getText().toString());
            }
        });

        btSelectFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                paramOnClickListener.onSelectFile();
            }
        });

        setContentView(mMenuView);
        setFocusable(true);
        setAnimationStyle(R.style.PopupAnimation);
        mMenuView.setOnTouchListener(new View.OnTouchListener()
        {
            public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
            {
                int i = mMenuView.findViewById(R.id.pop_layout).getTop();
                int j = (int)paramMotionEvent.getY();
                if ((paramMotionEvent.getAction() == 1) && (j < i))
                    dismiss();
                return true;
            }
        });
    }

    public interface OnClickListener{
        void onUpload(String title);
        void onSelectFile();
    }
}

