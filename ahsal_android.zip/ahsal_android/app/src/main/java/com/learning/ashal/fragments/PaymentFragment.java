package com.learning.ashal.fragments;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.databinding.DataBindingUtil;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.learning.ashal.R;
import com.learning.ashal.databinding.FragmentOtpBinding;
import com.learning.ashal.databinding.FragmentPaymentBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.model.LastCourseModel;
import com.learning.ashal.model.LessonModel;
import com.learning.ashal.model.PayModel;
import com.learning.ashal.model.UserModel;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.LocaleHelper;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import com.learning.ashal.utilities.SavePref;
import com.learning.ashal.utilities.TempStore;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.learning.ashal.utilities.Constants.BASE_URL;

public class PaymentFragment extends BaseFragment {

    private String TAG = PaymentFragment.class.getSimpleName();
    private FragmentPaymentBinding mBinding;
    private float totalPrice;
    private String studentId;

    public PaymentFragment(){

    }

    public PaymentFragment(float totalPrice, String studentId){
        this.totalPrice = totalPrice;
        this.studentId = studentId;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_payment, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    private void initView() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorPrimary));

        mBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.back();
            }
        });

        mBinding.txtTotal.setText(String.valueOf(totalPrice).replaceAll("\\.?0*$", "")+ " R.O");

        mBinding.llPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                callPay();
            }
        });
    }

    private void callPay(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        UserModel userModel = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel : SavePref.getInstance(mActivity).getUserModel();
        JsonObject requestParam = new JsonObject();
        requestParam.addProperty("parentId", userModel.id);
        requestParam.addProperty("studentId", studentId);
        requestParam.addProperty("amount",  String.format("%.3f", totalPrice));
        JsonArray jsonArray = new JsonArray();
        for(LastCourseModel lastCourseModel: TempStore.cartList){
            JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("courseId", lastCourseModel.id);
            jsonObject.addProperty("teacherId", lastCourseModel.teacherId);
            jsonObject.addProperty("cost", lastCourseModel.price);
            jsonArray.add(jsonObject);
        }
        requestParam.add("courses", jsonArray);

        Call<JsonObject> call = apiInterface.pay("Bearer "+ userModel.api_token, requestParam);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<PayModel>() {}.getType();
                            try{
                                PayModel payModel  = gson.fromJson(jsonObject.get("data").getAsJsonObject(), type);
                                TempStore.cartTotalPrice = totalPrice + "";
                                TempStore.paymentId = payModel.payment_id;
                                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(payModel.returnurl));
                                startActivity(browserIntent);
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                } else {
                    Log.e(TAG, "response error: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
                Log.e(TAG, "response fail error: "+ t.getMessage());
            }
        });
    }
}
