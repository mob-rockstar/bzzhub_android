package com.learning.ashal.fragments;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.databinding.DataBindingUtil;

import com.google.android.material.button.MaterialButton;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.learning.ashal.R;
import com.learning.ashal.activities.LoginActivity;
import com.learning.ashal.activities.MainActivity;
import com.learning.ashal.adapter.CartAdapter;
import com.learning.ashal.custom.CustomInfoDlg;
import com.learning.ashal.custom.CustomQuestionInfoDlg;
import com.learning.ashal.custom.CustomTextView;
import com.learning.ashal.custom.SelectStudentPopupWindow;
import com.learning.ashal.databinding.FragmentCheckoutBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.model.LastCourseModel;
import com.learning.ashal.model.MessageEvent;
import com.learning.ashal.model.StudentModel;
import com.learning.ashal.utilities.AnimationUtils;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.LocaleHelper;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import com.learning.ashal.utilities.SavePref;
import com.learning.ashal.utilities.TempStore;

import org.greenrobot.eventbus.EventBus;

import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.learning.ashal.utilities.Constants.BASE_URL;

public class CheckoutFragment extends BaseFragment {

    private String TAG = CheckoutFragment.class.getSimpleName();
    private FragmentCheckoutBinding mBinding;
    private LastCourseModel lastCourseModel;
    private CartAdapter cartAdapter;
    private float totalPrice = 0.0f;
    private float totalPriceBefore;
    private float discount;
    private boolean isFromProfile;
    private String couponCode;

    public CheckoutFragment(){

    }

    public CheckoutFragment(LastCourseModel lastCourseModel){
        this.lastCourseModel = lastCourseModel;
    }

    public CheckoutFragment(LastCourseModel lastCourseModel, boolean isFromProfile){
        this.lastCourseModel = lastCourseModel;
        this.isFromProfile = isFromProfile;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_checkout, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    @Override
    public void updateUI() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorWhite));
        if(!isFromProfile){
            ((MainActivity)mActivity).setWhiteBk();
        }
    }

    private void initView() {
        updateUI();
        MaterialButton btNext = mBinding.getRoot().findViewById(R.id.btNext);
        CustomTextView txtTitle = mBinding.getRoot().findViewById(R.id.txtTitle);
        txtTitle.setText(getResources().getString(R.string.buy));
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                View dlgView = ((LayoutInflater) mActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.dialog_select_student, null);
                SelectStudentPopupWindow selectStudentPopupWindow = new SelectStudentPopupWindow(dlgView, mActivity, new SelectStudentPopupWindow.OnClickListener() {
                    @Override
                    public void onSelect(StudentModel studentModel) {
                        if(totalPrice > 0) {
                            FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new PaymentFragment(totalPrice, studentModel.id), R.id.frameLayout);
                        }else{
                            callPurchaseCourse(studentModel.id);
                        }
                    }
                });
                selectStudentPopupWindow.showAtLocation(mBinding.getRoot(), Gravity.CENTER, 0, 0);
            }
        });

        mBinding.btBackCourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mActivity.back();
            }
        });

        mBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.back();
            }
        });

        cartAdapter = new CartAdapter(mActivity, new CartAdapter.OnItemClickListener() {
            @Override
            public void onClick(LastCourseModel lastCourseModel) {

            }

            @Override
            public void onDelete(LastCourseModel lastCourseModel) {
                if(TempStore.cartList.size() > 0){
                    TempStore.cartList.remove(lastCourseModel);
                    removeCartItemFromLocalDB(lastCourseModel.id);
                    cartAdapter.notifyDataSetChanged();
                    if(TempStore.cartList.size() == 0){
                        mBinding.parent.setVisibility(View.GONE);
                        mBinding.txtNoData.setVisibility(View.VISIBLE);
                    }else{
                        calTotal();
                        mBinding.llCoupon.setVisibility(View.GONE);
                    }
                    MessageEvent messageEvent = new MessageEvent();
                    messageEvent.messageType = MessageEvent.MessageType.CART_BADGE_SHOW;
                    EventBus.getDefault().post(messageEvent);
                }
            }
        });
        mBinding.rvCart.setAdapter(cartAdapter);
        cartAdapter.setData(TempStore.cartList);
        AnimationUtils.animateSlideTopFromDown(mActivity, mBinding.rvCart);

        mBinding.txtApply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!mBinding.etCoupon.getText().toString().isEmpty()){
                    callCheckCoupon();
                }
            }
        });

        mBinding.imgClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mBinding.etCoupon.setText("");
                mBinding.txtApply.setVisibility(View.VISIBLE);
                mBinding.imgClose.setVisibility(View.GONE);
                mBinding.llCoupon.setVisibility(View.GONE);
            }
        });

        if(TempStore.cartList.size() == 0){
            mBinding.parent.setVisibility(View.GONE);
            mBinding.txtNoData.setVisibility(View.VISIBLE);
        }else{
            mBinding.parent.setVisibility(View.VISIBLE);
            mBinding.txtNoData.setVisibility(View.GONE);
            calTotal();
        }
    }

    private void calTotal(){
        totalPrice = 0;
        mBinding.txtTotalItems.setText(String.valueOf(TempStore.cartList.size()));
        for(LastCourseModel lastCourseModel: TempStore.cartList){
            totalPrice += Float.parseFloat(lastCourseModel.price);
        }
        totalPriceBefore = totalPrice;
        mBinding.txtTotal.setText("R.O."+String.valueOf(totalPrice).replaceAll("\\.?0*$", ""));
    }

    private void callCheckCoupon(){
        if(getStudentId() == null){
            Toast.makeText(mActivity, getString(R.string.select_default_student), Toast.LENGTH_SHORT).show();
            return;
        }
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        JsonObject requestParam = new JsonObject();
        requestParam.addProperty("code",  mBinding.etCoupon.getText().toString().trim());
        requestParam.addProperty("studentId", getStudentId());
        requestParam.addProperty("amount",  String.valueOf(totalPrice).replaceAll("\\.?0*$", ""));
        requestParam.addProperty("itemsCount",  TempStore.cartList.size()+"");
        JsonArray jsonArray = new JsonArray();
        for(LastCourseModel lastCourseModel: TempStore.cartList){
            JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("id", lastCourseModel.id);
            jsonObject.addProperty("amount", lastCourseModel.price);
            jsonArray.add(jsonObject);
        }
        requestParam.add("itemsList", jsonArray);

        Call<JsonObject> call = apiInterface.checkCoupon(requestParam);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            couponCode = mBinding.etCoupon.getText().toString().trim();
                            mBinding.llCoupon.setVisibility(View.VISIBLE);
                            mBinding.txtNoCorrectCoupon.setVisibility(View.GONE);
                            mBinding.txtApply.setVisibility(View.GONE);
                            mBinding.imgClose.setVisibility(View.VISIBLE);
                            mBinding.txtDiscount.setText("R.O."+jsonObject.get("data").getAsString());
                            totalPrice = totalPriceBefore -  jsonObject.get("data").getAsFloat();
                            discount =  jsonObject.get("data").getAsFloat();
                            mBinding.txtTotal.setText("R.O."+String.valueOf(totalPrice).replaceAll("\\.?0*$", ""));
                        } else {
                            mBinding.llCoupon.setVisibility(View.GONE);
                            mBinding.txtNoCorrectCoupon.setVisibility(View.VISIBLE);
                            mBinding.txtNoCorrectCoupon.setText(jsonObject.get("message").getAsString());
                        }
                    }
                } else {
                    Log.e(TAG, "response error: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
                Log.e(TAG, "response fail error: "+ t.getMessage());
            }
        });
    }

    public void callPurchaseCourse(String studentId){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        JsonObject requestParam = new JsonObject();

        String id = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel.id : SavePref.getInstance(mActivity).getUserModel().id;
        requestParam.addProperty("parentId", id);
        requestParam.addProperty("studentId", studentId);
        requestParam.addProperty("cost", totalPrice);
        requestParam.addProperty("discount", discount);
        requestParam.addProperty("coupon", couponCode);
        JsonArray courseArray = new JsonArray();
        for(LastCourseModel lastCourseModel :TempStore.cartList){
            JsonObject courseObject = new JsonObject();
            courseObject.addProperty("courseId", lastCourseModel.id);
            courseObject.addProperty("teacherId", lastCourseModel.teacherId);
            courseObject.addProperty("cost", lastCourseModel.price);
            courseArray.add(courseObject);
        }
        requestParam.add("courses", courseArray);

        Call<JsonObject> call = apiInterface.purchaseCourse(requestParam);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            TempStore.cartList.clear();
                            clearCartFromLocalDB();
                            MessageEvent messageEvent = new MessageEvent();
                            messageEvent.messageType = MessageEvent.MessageType.CART_BADGE_SHOW;
                            EventBus.getDefault().post(messageEvent);
                            CustomInfoDlg dlg = new CustomInfoDlg(mActivity, getString(R.string.payment_success), new CustomInfoDlg.ItemClickInterface() {
                                @Override
                                public void onClick() {
                                    ((MainActivity)mActivity).selectHome();
                                }
                            });
                            dlg.showDialog();
                        }else{
                            CustomInfoDlg dlg = new CustomInfoDlg(mActivity, getString(R.string.payment_fail), new CustomInfoDlg.ItemClickInterface() {
                                @Override
                                public void onClick() {

                                }
                            });
                            dlg.showDialog();
                        }
                    }
                }
            }
            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }
}
