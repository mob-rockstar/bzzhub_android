package com.learning.ashal.fragments;

import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;

import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import com.bumptech.glide.Glide;
import com.google.gson.JsonObject;
import com.learning.ashal.R;
import com.learning.ashal.activities.TeacherMainActivity;
import com.learning.ashal.custom.SelectPicPopupWindow;
import com.learning.ashal.databinding.FragmentTeacherAddLessonBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.model.LessonModel;
import com.learning.ashal.model.MessageEvent;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import com.learning.ashal.utilities.SavePref;
import com.learning.ashal.utilities.TempStore;

import org.greenrobot.eventbus.EventBus;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.app.Activity.RESULT_OK;
import static android.content.Context.CLIPBOARD_SERVICE;
import static com.learning.ashal.utilities.Constants.BASE_URL;

public class TeacherAddLessonFragment extends BaseFragment {

    private String TAG = TeacherAddLessonFragment.class.getSimpleName();
    private FragmentTeacherAddLessonBinding mBinding;
    private boolean isNotification;
    private String path;
    private SelectPicPopupWindow selectPicPopupWindow;
    private LessonModel lessonModel;
    private String semester = "1";
    private String courseId;

    public TeacherAddLessonFragment(){

    }

    public TeacherAddLessonFragment(String courseId){
        this.courseId = courseId;
    }

    public TeacherAddLessonFragment(LessonModel lessonModel){
        this.lessonModel = lessonModel;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_teacher_add_lesson, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    private void initView() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorWhite));
        ((TeacherMainActivity)mActivity).reset();
        mBinding.btAddPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSelectDlg();
            }
        });

        mBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.back();
            }
        });

        mBinding.btCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkValidation()){
                    if(lessonModel != null){
                        callEditLesson();
                    }else{
                        callCreateLesson();
                    }
                }
            }
        });

        mBinding.rgSemester.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch(checkedId){
                    case R.id.radioFirst:
                        semester = "1";
                        break;
                    case R.id.radioSecond:
                        semester = "2";
                        break;
                }
            }
        });

        String asset = getResources().getString(R.string.SFProDisplay_Regular);
        Typeface font = Typeface.createFromAsset(getContext().getAssets(), asset);
        mBinding.radioFirst.setTypeface(font);
        mBinding.radioSecond.setTypeface(font);


        if(lessonModel != null){
            mBinding.llOptions.setVisibility(View.VISIBLE);
            mBinding.txtTitle.setText(getString(R.string.edit));
            mBinding.txtAddPhoto.setText(getString(R.string.edit_photo));
            mBinding.txtCreate.setText(getString(R.string.save));
            mBinding.etLessonName.setText(lessonModel.title);
            mBinding.etDescription.setText(lessonModel.description);
            mBinding.etVideoUrl.setText(lessonModel.file);
            if(lessonModel.semester.equals("1")){
                mBinding.radioFirst.setChecked(true);
            }else{
                mBinding.radioSecond.setChecked(true);
            }
            Glide
                    .with(mActivity)
                    .load(lessonModel.cover)
                    .into(mBinding.imgCover);
        }else{
            mBinding.llOptions.setVisibility(View.GONE);
            mBinding.txtTitle.setText(getString(R.string.add));
            mBinding.txtAddPhoto.setText(getString(R.string.add_photo));
            mBinding.txtCreate.setText(getString(R.string.create));
        }

        mBinding.llShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String link = generateLessonLink();
                if (link != null){
                    Intent share = new Intent(android.content.Intent.ACTION_SEND);
                    share.setType("text/plain");
                    share.putExtra(Intent.EXTRA_TEXT, link);
                    startActivity(Intent.createChooser(share, getResources().getString(R.string.share)));
                }
            }
        });

        mBinding.llTest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentProcess.addFragment(mActivity.getSupportFragmentManager(), new TeacherAddTestCourseExamFragment(lessonModel.id), R.id.frameLayout);
            }
        });
        mBinding.llFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentProcess.addFragment(mActivity.getSupportFragmentManager(), new TeacherAddCourseExamFragment(lessonModel.id), R.id.frameLayout);
            }
        });

    }

    private String generateLessonLink() {
        Uri.Builder builder = new Uri.Builder()
                .scheme("https")
                .authority("ashal.om")
                .path("/lesson/"+ lessonModel.id);

        final Uri appLink = builder.build();

        try{
            URL dynamicLinkUrl = new URL(URLDecoder.decode(appLink.toString(), "UTF-8"));
            return dynamicLinkUrl.toString();
        }catch (UnsupportedEncodingException | MalformedURLException ex){
            ex.printStackTrace();
        }
        return null;
    }

    private boolean checkValidation(){
        if(mBinding.etLessonName.getText().toString().isEmpty()){
            showErrorMessage(mBinding.getRoot(), getString(R.string.lesson_name_required));
            return false;
        }

        if(mBinding.etDescription.getText().toString().isEmpty()){
            showErrorMessage(mBinding.getRoot(), getString(R.string.desc_required));
            return false;
        }

        if(mBinding.etVideoUrl.getText().toString().isEmpty()){
            showErrorMessage(mBinding.getRoot(), getString(R.string.video_url_required));
            return false;
        }

        if(path == null && lessonModel == null){
            showErrorMessage(mBinding.getRoot(), getString(R.string.add_photo));
            return false;
        }
        
        return true;
    }

    private void openSelectDlg(){
        View view = ((LayoutInflater)mActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.dialog_layout_camera, null);
        selectPicPopupWindow = new SelectPicPopupWindow(view, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.btCancel:
                        selectPicPopupWindow.dismiss();
                        break;
                    case R.id.btCamera:
                        selectPicPopupWindow.dismiss();
                        if (checkAndRequestPermissions()) {
                            openCamera();
                        }
                        break;
                    case R.id.btGallery:
                        selectPicPopupWindow.dismiss();
                        openGallery();
                        break;
                }
            }
        });
        selectPicPopupWindow.showAtLocation(mBinding.getRoot(), Gravity.CENTER, 0, 0);
    }

    private Uri imageUri;
    public void openCamera(){
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "New Picture");
        imageUri = mActivity.getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        startActivityForResult(intent, 1);
    }

    public void openGallery() {
        Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(i, 2);
    }

    public String getRealPathFromURI(Uri contentUri) {
        Cursor cursor = mActivity.getContentResolver().query(contentUri, null, null, null, null);
        if (cursor == null) {
            return contentUri.getPath();
        } else {
            cursor.moveToFirst();
            int index = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            return cursor.getString(index);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if(requestCode == 1){
                try {
                    path = getRealPathFromURI(imageUri);
                    Glide
                            .with(mActivity)
                            .load(path)
                            .into(mBinding.imgCover);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }else if (requestCode == 2 && data != null) {
                try {
                    selectImageFromGalleryResult(data);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }
    }

    private void selectImageFromGalleryResult(Intent data) {
        Uri uri_data = data.getData();
        try {
            Bitmap originalBitmap = MediaStore.Images.Media.getBitmap(mActivity.getContentResolver(), uri_data);
            int nh = (int) (originalBitmap.getHeight() * (512.0 / originalBitmap.getWidth()));
            Bitmap compressedBitmap = Bitmap.createScaledBitmap(originalBitmap, 512, nh, true);
            File compressedFile = createFileFromBitmap(compressedBitmap, mActivity);
            path = compressedFile.getPath();
            Glide
                    .with(mActivity)
                    .load(path)
                    .into(mBinding.imgCover);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public File createFileFromBitmap(Bitmap bitmap, Context context) {

        Long tsLong = System.currentTimeMillis() / 1000;
        String name = tsLong.toString();

        File filesDir = context.getFilesDir();
        File imageFile = new File(filesDir, name + ".jpg");

        OutputStream os;
        try {
            os = new FileOutputStream(imageFile);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, os);
            os.flush();
            os.close();
        } catch (Exception e) {
            Log.e("NewProductFragment", "Error writing bitmap", e);
        }

        return imageFile;
    }

    private  boolean checkAndRequestPermissions() {
        int permissionCamera = ContextCompat.checkSelfPermission(mActivity, Manifest.permission.CAMERA);
        int permissionReadStorage = ContextCompat.checkSelfPermission(mActivity, Manifest.permission.READ_EXTERNAL_STORAGE);
        int permissionWriteStorage = ContextCompat.checkSelfPermission(mActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        List<String> listPermissionsNeeded = new ArrayList<>();
        if (permissionWriteStorage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (permissionCamera != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.CAMERA);
        }

        if (permissionReadStorage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }

        if (!listPermissionsNeeded.isEmpty()) {
            this.requestPermissions(listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), 1);
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            Map<String, Integer> perms = new HashMap<>();
            perms.put(Manifest.permission.CAMERA, PackageManager.PERMISSION_GRANTED);
            perms.put(Manifest.permission.WRITE_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
            perms.put(Manifest.permission.READ_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
            if (grantResults.length > 0) {
                for (int i = 0; i < permissions.length; i++)
                    perms.put(permissions[i], grantResults[i]);
                if (perms.get(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                        && perms.get(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                        && perms.get(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                    openCamera();
                }
            }
        }
    }

    private void callCreateLesson(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        RequestBody course = RequestBody.create(MediaType.parse("text/plain"), courseId);
        RequestBody title = RequestBody.create(MediaType.parse("text/plain"), mBinding.etLessonName.getText().toString());
        RequestBody description = RequestBody.create(MediaType.parse("text/plain"), mBinding.etDescription.getText().toString());
        RequestBody sem = RequestBody.create(MediaType.parse("text/plain"), semester);
        RequestBody file = RequestBody.create(MediaType.parse("text/plain"), mBinding.etVideoUrl.getText().toString());
        MultipartBody.Part image = null;
        if(path!=null && new File(path).exists())
        {
            File cover = new File(path);
            RequestBody requestFile =RequestBody.create(MediaType.parse("multipart/form-data"), cover);
            image = MultipartBody.Part.createFormData("cover", cover.getName(), requestFile);
        }

        Call<JsonObject> call = apiInterface.createLesson(course, title, description, sem, file, image);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            MessageEvent messageEvent = new MessageEvent();
                            messageEvent.messageType = MessageEvent.MessageType.LESSON_REFRESH;
                            EventBus.getDefault().post(messageEvent);
                            mActivity.back();
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                } else {
                    Log.e(TAG, "response error: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
                Log.e(TAG, "response fail error: "+ t.getMessage());
            }
        });
    }

    private void callEditLesson(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        RequestBody lessonId = RequestBody.create(MediaType.parse("text/plain"), lessonModel.id);
        RequestBody title = RequestBody.create(MediaType.parse("text/plain"), mBinding.etLessonName.getText().toString());
        RequestBody description = RequestBody.create(MediaType.parse("text/plain"), mBinding.etDescription.getText().toString());
        RequestBody sem = RequestBody.create(MediaType.parse("text/plain"), semester);
        RequestBody file = RequestBody.create(MediaType.parse("text/plain"), mBinding.etVideoUrl.getText().toString());
        MultipartBody.Part image = null;
        if(path!=null && new File(path).exists())
        {
            File cover = new File(path);
            RequestBody requestFile =RequestBody.create(MediaType.parse("multipart/form-data"), cover);
            image = MultipartBody.Part.createFormData("cover", cover.getName(), requestFile);
        }

        Call<JsonObject> call = apiInterface.editLesson(lessonId, title, description, sem, file, image);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            MessageEvent messageEvent = new MessageEvent();
                            messageEvent.messageType = MessageEvent.MessageType.LESSON_REFRESH;
                            EventBus.getDefault().post(messageEvent);
                            mActivity.back();
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                } else {
                    Log.e(TAG, "response error: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
                Log.e(TAG, "response fail error: "+ t.getMessage());
            }
        });
    }

}
