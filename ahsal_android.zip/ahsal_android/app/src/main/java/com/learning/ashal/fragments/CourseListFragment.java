package com.learning.ashal.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.databinding.DataBindingUtil;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.learning.ashal.R;
import com.learning.ashal.activities.LoginActivity;
import com.learning.ashal.activities.MainActivity;
import com.learning.ashal.adapter.MathListAdapter;
import com.learning.ashal.databinding.FragmentMathListBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.interfaces.QuestionCallbackListener;
import com.learning.ashal.model.LastCourseModel;
import com.learning.ashal.model.MessageEvent;
import com.learning.ashal.model.SubjectModel;
import com.learning.ashal.utilities.AnimationUtils;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.LocaleHelper;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import com.learning.ashal.utilities.TempStore;

import org.greenrobot.eventbus.EventBus;

import java.io.File;
import java.lang.reflect.Type;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.learning.ashal.utilities.Constants.BASE_URL;

public class CourseListFragment extends BaseFragment {

    private String TAG = CourseListFragment.class.getSimpleName();
    private FragmentMathListBinding mBinding;
    private MathListAdapter mathAdapter;
    private SubjectModel subjectModel;
    private String subjectName;
    private List<SubjectModel> subjectModelList;
    private List<LastCourseModel> lastCourseModels;

    public CourseListFragment(){

    }

    public CourseListFragment(SubjectModel subjectModel, List<SubjectModel> subjectModelList){
        this.subjectModel = subjectModel;
        this.subjectModelList = subjectModelList;
    }

    public CourseListFragment(SubjectModel subjectModel, List<SubjectModel> subjectModelList, List<LastCourseModel> lastCourseModels){
        this.subjectModel = subjectModel;
        this.subjectModelList = subjectModelList;
        this.lastCourseModels = lastCourseModels;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_math_list, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    @Override
    public void updateUI() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorWhite));
        ((MainActivity)mActivity).setWhiteBk();
    }

    private void initView() {

        if(subjectModel == null)
            return;
        String lang = LocaleHelper.getPersistedData(mActivity, "ar");
        if(lang.equals("en")){
            subjectName = subjectModel.englishName;
        }else{
            subjectName = subjectModel.arabicName;
        }
        mBinding.txtSubject.setText(subjectName);


        mBinding.txtCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.back();
                mActivity.back();
            }
        });

        mBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.back();
            }
        });

        mBinding.imgFilter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentProcess.addFragmentWithBottomToTopAnimation(mActivity.getSupportFragmentManager(), new SearchFilterFragment(subjectModelList), R.id.frameLayout);
            }
        });

        mathAdapter = new MathListAdapter(mActivity, new MathListAdapter.OnItemClickListener() {
            @Override
            public void onClick(LastCourseModel lastCourseModel) {
                FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new LessonListFragment(lastCourseModel.title, lastCourseModel.id, lastCourseModel.image), R.id.frameLayout);
            }

            @Override
            public void addToCart(LastCourseModel lastCourseModel) {
                if(!TempStore.isLoggedIn){
                    Intent intent = new Intent(mActivity, LoginActivity.class);
                    startActivity(intent);
//                    Toast.makeText(mActivity, getString(R.string.register_ashal), Toast.LENGTH_SHORT).show();
                    return;
                }
                if(!hasProfile()){
//                    Toast.makeText(mActivity, getString(R.string.select_default_student), Toast.LENGTH_SHORT).show();
                    openQuestionDlg(getString(R.string.add_student_profile), getString(R.string.add), getString(R.string.cancel),new QuestionCallbackListener() {
                        @Override
                        public void onYes() {
                            ((MainActivity)mActivity).selectNewProfile();
                        }
                        @Override
                        public void onNo() {

                        }
                    });

                    return;
                }
                //already exists in cart
                for(LastCourseModel lastCourseModel1: TempStore.cartList){
                    if(lastCourseModel.id.equals(lastCourseModel1.id)){
                        showErrorMessage(mBinding.getRoot(), getString(R.string.already_exists_cart));
//                        FragmentProcess.addFragment(mActivity.getSupportFragmentManager(), new CheckoutFragment(lastCourseModel), R.id.frameLayout);
                        return;
                    }
                }
                //newly
                TempStore.cartList.add(lastCourseModel);
                saveCartToLocalDB(lastCourseModel);
                MessageEvent messageEvent = new MessageEvent();
                messageEvent.messageType = MessageEvent.MessageType.CART_BADGE_SHOW;
                EventBus.getDefault().post(messageEvent);
                FragmentProcess.addFragment(mActivity.getSupportFragmentManager(), new CheckoutFragment(lastCourseModel), R.id.frameLayout);
            }
        });
        mBinding.rvMath.setAdapter(mathAdapter);

        mBinding.etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(mathAdapter!=null) {
                    mathAdapter.getFilter().filter(charSequence);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        if(lastCourseModels == null){
            mBinding.txtCancel.setVisibility(View.GONE);
            callGetCourseList();
        }else{
            mBinding.txtCancel.setVisibility(View.VISIBLE);
            mathAdapter.setData(lastCourseModels);
            AnimationUtils.animateSlideTopFromDown(mActivity, mBinding.rvMath);
        }

        updateUI();
    }

    private void callGetCourseList(){
        String id = getStudentId();
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.courseList(subjectModel.id, id == null ? "": id);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<List<LastCourseModel>>() {}.getType();
                            try{
                                lastCourseModels = gson.fromJson(jsonObject.get("data").getAsJsonArray(), type);
                                if(lastCourseModels != null && lastCourseModels.size() > 0){
                                    mBinding.llNoData.setVisibility(View.GONE);
                                }else{
                                    mBinding.llNoData.setVisibility(View.VISIBLE);
                                }
                                mathAdapter.setData(lastCourseModels);
                                AnimationUtils.animateSlideTopFromDown(mActivity, mBinding.rvMath);
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }
}
