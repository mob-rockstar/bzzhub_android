package com.learning.ashal.fragments;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.GridLayoutManager;

import com.bumptech.glide.Glide;
import com.google.android.material.button.MaterialButton;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.learning.ashal.R;
import com.learning.ashal.activities.TeacherMainActivity;
import com.learning.ashal.adapter.SpinCityAdapter;
import com.learning.ashal.adapter.SpinRegionAdapter;
import com.learning.ashal.adapter.SpinSchoolAdapter;
import com.learning.ashal.adapter.TeacherProfileGradeAdapter;
import com.learning.ashal.adapter.TeacherSubjectAdapter;
import com.learning.ashal.custom.CustomQuestionDlg;
import com.learning.ashal.custom.CustomTextView;
import com.learning.ashal.custom.SelectPicPopupWindow;
import com.learning.ashal.databinding.FragmentTeacherProfileBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.model.GradeModel;
import com.learning.ashal.model.LastCourseModel;
import com.learning.ashal.model.MessageEvent;
import com.learning.ashal.model.PayModel;
import com.learning.ashal.model.RegionModel;
import com.learning.ashal.model.SchoolModel;
import com.learning.ashal.model.StateModel;
import com.learning.ashal.model.SubjectModel;
import com.learning.ashal.model.TeacherModel;
import com.learning.ashal.model.UserModel;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import com.learning.ashal.utilities.SavePref;
import com.learning.ashal.utilities.TempStore;

import org.greenrobot.eventbus.EventBus;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.app.Activity.RESULT_OK;
import static com.learning.ashal.utilities.Constants.BASE_URL;

public class TeacherProfileFragment extends BaseFragment {

    private String TAG = TeacherProfileFragment.class.getSimpleName();
    private FragmentTeacherProfileBinding mBinding;
    private SelectPicPopupWindow selectPicPopupWindow;
    private String path;
    private TeacherSubjectAdapter teacherSubjectAdapter;
    private TeacherProfileGradeAdapter teacherProfileGradeAdapter;
    private SchoolModel selSchool;
    private StateModel selCity;
    private String selTeacherType;
    private SubjectModel selSubjectModel;
    private ArrayList<String> selGradeModelList = new ArrayList<>();
    private List<RegionModel> regionModelList;
    private TeacherModel teacherModel;
    private List<StateModel> cityModelList;
    private RegionModel selRegion;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_teacher_profile, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    @Override
    public void updateUI() {
        ((TeacherMainActivity)mActivity).selectProfileTabMark();
    }

    private void initView() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorWhite));

        MaterialButton btNext = mBinding.getRoot().findViewById(R.id.btNext);
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkValidation()){
                    if(path!=null && new File(path).exists()){
                        callUploadTeacherImage();
                    }
                    callUpdateProfile();
                }
            }
        });

        CustomTextView txtTitle = mBinding.getRoot().findViewById(R.id.txtTitle);
        txtTitle.setText(getString(R.string.save));

        mBinding.txtEditPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSelectDlg();
            }
        });

        teacherSubjectAdapter = new TeacherSubjectAdapter(mActivity, new TeacherSubjectAdapter.OnItemClickListener() {
            @Override
            public void onClick(SubjectModel subjectModel) {
                selSubjectModel = subjectModel;
            }
        });
        GridLayoutManager gridLayoutManager = new GridLayoutManager(mActivity, 3);
        mBinding.rvSubject.setLayoutManager(gridLayoutManager);
        mBinding.rvSubject.setAdapter(teacherSubjectAdapter);

        teacherProfileGradeAdapter = new TeacherProfileGradeAdapter(mActivity, new TeacherProfileGradeAdapter.OnItemClickListener() {
            @Override
            public void onClick(GradeModel gradeModel) {
                if(gradeModel.isSelected){
                    selGradeModelList.add(gradeModel.id);
                }else{
                    selGradeModelList.remove(gradeModel.id);
                }
            }
        });
        GridLayoutManager gridLayoutManager1 = new GridLayoutManager(mActivity, 3);
        mBinding.rvGrade.setLayoutManager(gridLayoutManager1);
        mBinding.rvGrade.setAdapter(teacherProfileGradeAdapter);
        callGetTeacherProfile();
    }

    private void initFromApi(){
        teacherModel = TempStore.teacherModel == null ? SavePref.getInstance(mActivity).getTeacherModel() : TempStore.teacherModel;

        mBinding.etFirstName.setText(teacherModel.firstName);
        mBinding.etLastName.setText(teacherModel.lastName);
        mBinding.etEmail.setText(teacherModel.email);
        mBinding.etPhoneNumber.setText(teacherModel.mobile);
        if(teacherModel.image != null){
            Glide
                    .with(mActivity)
                    .load(teacherModel.image)
                    .placeholder(R.drawable.placeholder)
                    .error(R.drawable.placeholder)
                    .into(mBinding.imgPhoto);
        }

        mBinding.spnSchoolName.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                int position = parent.getSelectedItemPosition();
                if(teacherModel.schools != null){
                    selSchool = teacherModel.schools.get(position);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });

        mBinding.spnSchoolCity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                int position = parent.getSelectedItemPosition();
                if(cityModelList != null){
                    selCity = cityModelList.get(position);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });

        mBinding.spnTeacherType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                int position = parent.getSelectedItemPosition();
                if(teacherModel.teacherTypes != null){
                    selTeacherType = teacherModel.teacherTypes.get(position);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });

        mBinding.spnRegion.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            int check = 0;
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                int position = parent.getSelectedItemPosition();
                if(regionModelList != null){

                    selRegion = regionModelList.get(position);
                    cityModelList = selRegion.states;
                    SpinCityAdapter adapter = new SpinCityAdapter(mActivity, R.layout.item_spinner_count, selRegion.states);
                    mBinding.spnSchoolCity.setAdapter(adapter);

                    check++;

                    if(teacherModel != null && check < 2){

                        if(teacherModel.cities != null){
                            for(int i=0; i<teacherModel.cities.size();i++){
                                if(teacherModel.state.equals(teacherModel.cities.get(i).id)){
                                    mBinding.spnSchoolCity.setSelection(i);
                                    break;
                                }
                            }
                        }
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(mActivity, android.R.layout.simple_spinner_item, teacherModel.teacherTypes);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mBinding.spnTeacherType.setAdapter(dataAdapter);
        if(teacherModel.teacherTypes != null){
            for(int i=0; i<teacherModel.teacherTypes.size();i++){
                if(teacherModel.teacherType.equals(teacherModel.teacherTypes.get(i))){
                    mBinding.spnTeacherType.setSelection(i);
                    break;
                }
            }
        }

        SpinSchoolAdapter adapterSchool = new SpinSchoolAdapter(mActivity, R.layout.item_spinner_count, teacherModel.schools);
        mBinding.spnSchoolName.setAdapter(adapterSchool);
        if(teacherModel.schools != null){
            for(int i=0; i<teacherModel.schools.size();i++){
                if(teacherModel.school.equals(teacherModel.schools.get(i).id)){
                    mBinding.spnSchoolName.setSelection(i);
                    break;
                }
            }
        }

        if(teacherModel.askTeacherService == 1){
            mBinding.cbJoinAsk.setChecked(true);
        }else{
            mBinding.cbJoinAsk.setChecked(false);
        }

        callGetLocation();
    }

    private boolean checkValidation(){
        if(mBinding.etFirstName.getText().toString().isEmpty()){
            showErrorMessage(mBinding.getRoot(), getString(R.string.first_name_required));
            return false;
        }

        if(mBinding.etLastName.getText().toString().isEmpty()){
            showErrorMessage(mBinding.getRoot(), getString(R.string.last_name_required));
            return false;
        }

        if(mBinding.etEmail.getText().toString().isEmpty()){
            showErrorMessage(mBinding.getRoot(), getString(R.string.email_required));
            return false;
        }

        if(mBinding.etPhoneNumber.getText().toString().isEmpty()){
            showErrorMessage(mBinding.getRoot(), getString(R.string.phone_number_required));
            return false;
        }

        if(selSchool == null || selTeacherType == null || selCity == null || selSubjectModel == null ||
            selGradeModelList.size() == 0){
            return false;
        }

        return true;
    }

    private void openSelectDlg(){
        View view = ((LayoutInflater)mActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.dialog_layout_camera, null);
        selectPicPopupWindow = new SelectPicPopupWindow(view, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.btCancel:
                        selectPicPopupWindow.dismiss();
                        break;
                    case R.id.btCamera:
                        selectPicPopupWindow.dismiss();
                        if (checkAndRequestPermissions()) {
                            openCamera();
                        }
                        break;
                    case R.id.btGallery:
                        selectPicPopupWindow.dismiss();
                        openGallery();
                        break;
                }
            }
        });
        selectPicPopupWindow.showAtLocation(mBinding.getRoot(), Gravity.CENTER, 0, 0);
    }

    private Uri imageUri;
    public void openCamera(){
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "New Picture");
        imageUri = mActivity.getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        startActivityForResult(intent, 1);
    }

    public void openGallery() {
        Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(i, 2);
    }

    public String getRealPathFromURI(Uri contentUri) {
        Cursor cursor = mActivity.getContentResolver().query(contentUri, null, null, null, null);
        if (cursor == null) {
            return contentUri.getPath();
        } else {
            cursor.moveToFirst();
            int index = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            return cursor.getString(index);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if(requestCode == 1 && data != null ){
                try {
                    path = getRealPathFromURI(imageUri);
                    Glide
                            .with(mActivity)
                            .load(path)
                            .into(mBinding.imgPhoto);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (requestCode == 2 && data != null) {
                try {
                    selectImageFromGalleryResult(data);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }
    }

    private void selectImageFromGalleryResult(Intent data) {
        Uri uri_data = data.getData();
        try {
            Bitmap originalBitmap = MediaStore.Images.Media.getBitmap(mActivity.getContentResolver(), uri_data);
            int nh = (int) (originalBitmap.getHeight() * (512.0 / originalBitmap.getWidth()));
            Bitmap compressedBitmap = Bitmap.createScaledBitmap(originalBitmap, 512, nh, true);
            File compressedFile = createFileFromBitmap(compressedBitmap, mActivity);
            path = compressedFile.getPath();
            Glide
                    .with(mActivity)
                    .load(path)
                    .into(mBinding.imgPhoto);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public File createFileFromBitmap(Bitmap bitmap, Context context) {

        Long tsLong = System.currentTimeMillis() / 1000;
        String name = tsLong.toString();

        File filesDir = context.getFilesDir();
        File imageFile = new File(filesDir, name + ".jpg");

        OutputStream os;
        try {
            os = new FileOutputStream(imageFile);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, os);
            os.flush();
            os.close();
        } catch (Exception e) {
            Log.e("NewProductFragment", "Error writing bitmap", e);
        }

        return imageFile;
    }

    private  boolean checkAndRequestPermissions() {
        int permissionCamera = ContextCompat.checkSelfPermission(mActivity, Manifest.permission.CAMERA);
        int permissionReadStorage = ContextCompat.checkSelfPermission(mActivity, Manifest.permission.READ_EXTERNAL_STORAGE);
        int permissionWriteStorage = ContextCompat.checkSelfPermission(mActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        List<String> listPermissionsNeeded = new ArrayList<>();
        if (permissionWriteStorage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (permissionCamera != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.CAMERA);
        }

        if (permissionReadStorage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }

        if (!listPermissionsNeeded.isEmpty()) {
            this.requestPermissions(listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), 1);
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            Map<String, Integer> perms = new HashMap<>();
            perms.put(Manifest.permission.CAMERA, PackageManager.PERMISSION_GRANTED);
            perms.put(Manifest.permission.WRITE_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
            perms.put(Manifest.permission.READ_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
            if (grantResults.length > 0) {
                for (int i = 0; i < permissions.length; i++)
                    perms.put(permissions[i], grantResults[i]);
                if (perms.get(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                        && perms.get(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                        && perms.get(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                    openCamera();
                }
            }
        }
    }

    private void callGetSubjectList(){
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.getSubjectList();
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<List<SubjectModel>>() {}.getType();
                            try{
                                List<SubjectModel> subjectModelList = gson.fromJson(jsonObject.get("data").getAsJsonArray(), type);
                                TeacherModel teacherModel = TempStore.teacherModel == null ? SavePref.getInstance(mActivity).getTeacherModel() : TempStore.teacherModel;
                                for(SubjectModel subjectModel : subjectModelList){
                                    if(teacherModel.course.id.equals(subjectModel.id)){
                                        subjectModel.isSelected = true;
                                        selSubjectModel = subjectModel;
                                        break;
                                    }
                                }
                                teacherSubjectAdapter.setData(subjectModelList);
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private void callGetGradeList(){
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.getGradeList();
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<List<GradeModel>>() {}.getType();
                            try{
                                List<GradeModel> gradeModelList = gson.fromJson(jsonObject.get("data").getAsJsonArray(), type);
                                TeacherModel teacherModel = TempStore.teacherModel == null ? SavePref.getInstance(mActivity).getTeacherModel() : TempStore.teacherModel;
                                if(teacherModel.grades != null){
                                    selGradeModelList.clear();
                                    for(GradeModel gradeModel : teacherModel.grades){
                                        for(GradeModel all : gradeModelList){
                                            if(gradeModel.id.equals(all.id)){
                                                all.isSelected = true;
                                                selGradeModelList.add(gradeModel.id);
                                                break;
                                            }
                                        }
                                    }
                                }

                                teacherProfileGradeAdapter.setData(gradeModelList);

                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

            }
        });
    }

    private void callUpdateProfile(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        TeacherModel teacherModel = TempStore.teacherModel == null ? SavePref.getInstance(mActivity).getTeacherModel() : TempStore.teacherModel;
        JsonObject requestParam = new JsonObject();
        requestParam.addProperty("id", teacherModel.id);
        requestParam.addProperty("mobile", mBinding.etPhoneNumber.getText().toString());
        requestParam.addProperty("firstName", mBinding.etFirstName.getText().toString());
        requestParam.addProperty("lastName", mBinding.etLastName.getText().toString());
        requestParam.addProperty("email", mBinding.etEmail.getText().toString());
        requestParam.addProperty("state", selCity.id);
        requestParam.addProperty("school", selSchool.id);
        requestParam.addProperty("teacherType", selTeacherType);
        requestParam.addProperty("askTeacherService", mBinding.cbJoinAsk.isChecked()?"1":"0");
        requestParam.addProperty("courseId", selSubjectModel.id);

        JsonArray jsonArray = new JsonArray();
        for(String gradeId: selGradeModelList){
            jsonArray.add(gradeId);
        }
        requestParam.add("grades", jsonArray);

        Call<JsonObject> call = apiInterface.updateTeacherProfile(requestParam);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Toast.makeText(mActivity, jsonObject.get("message").getAsString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    Log.e(TAG, "response error: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
                Log.e(TAG, "response fail error: "+ t.getMessage());
            }
        });
}

    private void callUploadTeacherImage(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        TeacherModel teacherModel = TempStore.teacherModel == null ? SavePref.getInstance(mActivity).getTeacherModel() : TempStore.teacherModel;
        RequestBody id = RequestBody.create(MediaType.parse("text/plain"), teacherModel.id);
        MultipartBody.Part image;
        File file = new File(path);
        RequestBody requestFile =RequestBody.create(MediaType.parse("multipart/form-data"), file);
        image = MultipartBody.Part.createFormData("image", file.getName(), requestFile);
        Call<JsonObject> call = apiInterface.uploadTeacherImage(id,  image);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {

                        }
                    }
                } else {
                    Log.e(TAG, "response error: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
                Log.e(TAG, "response fail error: "+ t.getMessage());
            }
        });
    }

    private void callGetTeacherProfile() {
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        String id = SavePref.getInstance(mActivity).getTeacherModel() == null ? TempStore.teacherModel.id : SavePref.getInstance(mActivity).getTeacherModel().id;
        Call<JsonObject> call = apiInterface.getTeacherProfile(id);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<TeacherModel>() {
                            }.getType();
                            try {
                                TeacherModel teacherModel = gson.fromJson(jsonObject.get("data").getAsJsonObject(), type);
                                if (TempStore.teacherModel == null) {
                                    SavePref.getInstance(mActivity).saveTeacherModel(teacherModel);
                                } else {
                                    TempStore.teacherModel = teacherModel;
                                }
                                initFromApi();
                                callGetGradeList();
                                callGetSubjectList();
                            } catch (JsonSyntaxException ex) {
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private void callGetLocation(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.getLocationList();
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<List<RegionModel>>() {}.getType();
                            try{
                                regionModelList = gson.fromJson(jsonObject.get("data").getAsJsonArray(), type);
                                SpinRegionAdapter adapter = new SpinRegionAdapter(mActivity, R.layout.item_spinner_count, regionModelList);
                                mBinding.spnRegion.setAdapter(adapter);

                                if(teacherModel != null){
                                    for(int i=0; i<regionModelList.size();i++){
                                        if(teacherModel.regionId.equals(regionModelList.get(i).id)){
                                            mBinding.spnRegion.setSelection(i);
                                            break;
                                        }
                                    }
                                }

                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }
}
