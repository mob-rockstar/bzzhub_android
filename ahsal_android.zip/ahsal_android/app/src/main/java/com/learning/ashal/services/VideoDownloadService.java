package com.learning.ashal.services;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.DialogInterface;
import android.os.Environment;
import android.os.PersistableBundle;
import android.util.Log;

import androidx.appcompat.app.AlertDialog;

import com.learning.ashal.R;
import com.learning.ashal.model.DownloadedVideoModel;
import com.learning.ashal.model.MessageEvent;

import org.greenrobot.eventbus.EventBus;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import io.realm.Realm;

public class VideoDownloadService extends JobService {

    private JobParameters params;
    private String mediaUrl;
    private String fileName;
    private Realm realm;

    @Override
    public boolean onStartJob(JobParameters jobParameters) {
        this.params = jobParameters;
        PersistableBundle bundle = params.getExtras();
        mediaUrl = bundle.getString("mediaUrl");
        fileName = bundle.getString("fileName");

        new Thread(new Runnable() {
            public void run() {
                downloadVideo();
            }
        }).start();

        return false;
    }

    @Override
    public boolean onStopJob(JobParameters jobParameters) {
        return false;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.e("VideoDownloadService", "VideoDownloadService created");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e("VideoDownloadService", "VideoDownloadService destroyed");
    }

    public void stopJobNow() {
        jobFinished(params, false);
    }

    private void downloadVideo(){
        int count;

        try {
            URL url = new URL(this.mediaUrl);
            URLConnection connection = url.openConnection();
            connection.connect();
            int lefOfFile = connection.getContentLength();
            InputStream input = new BufferedInputStream(url.openStream());
            File storageDir = new File(Environment
                    .getExternalStorageDirectory() + "/ashal/");
            if (!storageDir.exists())
                storageDir.mkdirs();


            OutputStream output = new FileOutputStream(Environment
                    .getExternalStorageDirectory() + "/ashal/"+ fileName);

            byte data[] = new byte[1024];
            long total = 0;
            while ((count = input.read(data)) != -1) {
                total += count;
                Log.e("MediaDownProgress", "" + (int) ((total * 100) / lefOfFile));
                output.write(data, 0, count);
            }
            output.flush();
            output.close();
            input.close();

            MessageEvent messageEvent = new MessageEvent();
            messageEvent.messageType = MessageEvent.MessageType.SHOW_DIALOG;
            messageEvent.isSuccess = true;
            EventBus.getDefault().post(messageEvent);

            stopJobNow();

        } catch (Exception e) {
            MessageEvent messageEvent = new MessageEvent();
            messageEvent.messageType = MessageEvent.MessageType.SHOW_DIALOG;
            EventBus.getDefault().post(messageEvent);
            stopJobNow();
        }
    }

}
