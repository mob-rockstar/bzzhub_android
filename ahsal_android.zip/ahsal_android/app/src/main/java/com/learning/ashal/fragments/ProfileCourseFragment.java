package com.learning.ashal.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.databinding.DataBindingUtil;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.learning.ashal.R;
import com.learning.ashal.adapter.ProfileCourseAdapter;
import com.learning.ashal.databinding.FragmentCourseProfileBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.model.CourseModel;
import com.learning.ashal.model.StudentModel;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import com.learning.ashal.utilities.SavePref;
import com.learning.ashal.utilities.TempStore;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.learning.ashal.utilities.Constants.BASE_URL;

public class ProfileCourseFragment extends BaseFragment {

    private String TAG = ProfileCourseFragment.class.getSimpleName();
    private FragmentCourseProfileBinding mBinding;
    private ProfileCourseAdapter profileCourseAdapter;
    private StudentModel studentModel;

    public ProfileCourseFragment(){

    }

    public ProfileCourseFragment(StudentModel studentModel){
        this.studentModel = studentModel;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_course_profile, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    private void initView() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorPrimary));

        profileCourseAdapter = new ProfileCourseAdapter(mActivity, new ProfileCourseAdapter.OnItemClickListener() {
            @Override
            public void onClick(CourseModel courseModel) {
                FragmentProcess.addFragment(mActivity.getSupportFragmentManager(), new LessonListFragment(
                        courseModel.title, courseModel.id, true, courseModel.image), R.id.frameLayout);
            }
        });
        mBinding.rvProfile.setAdapter(profileCourseAdapter);

        mBinding.txtProfileInActive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.clearBackStack();
                FragmentProcess.replaceFragment(mActivity.getSupportFragmentManager(), new ProfileNewFragment(studentModel), R.id.frameLayout);
            }
        });

        mBinding.txtLearningInActive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.clearBackStack();
                FragmentProcess.replaceFragment(mActivity.getSupportFragmentManager(), new ProfileLearningFragment(studentModel), R.id.frameLayout);
            }
        });

        callGetMyCourses();
    }

    private void callGetMyCourses(){
        if(getStudentId() == null){
            Toast.makeText(mActivity, getString(R.string.select_default_student), Toast.LENGTH_SHORT).show();
            return;
        }
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Map params = new HashMap();
        String id = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel.id : SavePref.getInstance(mActivity).getUserModel().id;
        params.put("parentId", id);
        params.put("studentId", getStudentId());

        Call<JsonObject> call = apiInterface.myCourses(params);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<List<CourseModel>>() {}.getType();
                            try{
                                List<CourseModel> courseModelList = gson.fromJson(jsonObject.get("data").getAsJsonArray(), type);
                                if (courseModelList != null && courseModelList.size() > 0) {
                                    mBinding.txtNoData.setVisibility(View.GONE);
                                    profileCourseAdapter.setData(courseModelList);
                                }else{
                                    profileCourseAdapter.setData(null);
                                    mBinding.txtNoData.setVisibility(View.VISIBLE);
                                }
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                } else {
                    Log.e(TAG, "response error: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
                Log.e(TAG, "response fail error: "+ t.getMessage());
            }
        });
    }
}
