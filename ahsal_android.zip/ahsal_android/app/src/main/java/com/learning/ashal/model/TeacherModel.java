package com.learning.ashal.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class TeacherModel {
    @SerializedName("id")
    @Expose
    public String id;

    @SerializedName("mobile")
    @Expose
    public String mobile;

    @SerializedName("firstName")
    @Expose
    public String firstName;

    @SerializedName("lastName")
    @Expose
    public String lastName;

    @SerializedName("email")
    @Expose
    public String email;

    @SerializedName("teacherType")
    @Expose
    public String teacherType;

    @SerializedName("askTeacherService")
    @Expose
    public Integer askTeacherService;

    @SerializedName("image")
    @Expose
    public String image;

    @SerializedName("language")
    @Expose
    public String language;

    @SerializedName("status")
    @Expose
    public Integer status;

    @SerializedName("created_at")
    @Expose
    public String created_at;

    @SerializedName("updated_at")
    @Expose
    public String updated_at;

    @SerializedName("numberOfGroups")
    @Expose
    public Integer numberOfGroups;

    @SerializedName("numberOfStudentPerGroup")
    @Expose
    public Integer numberOfStudentPerGroup;

    @SerializedName("school")
    @Expose
    public String school;

    @SerializedName("state")
    @Expose
    public String state;

    @SerializedName("courseId")
    @Expose
    public Integer courseId;

    @SerializedName("enableNotification")
    @Expose
    public Integer enableNotification;

    @SerializedName("api_token")
    @Expose
    public String api_token;

    @SerializedName("grades")
    @Expose
    public List<GradeModel> grades;

    @SerializedName("regionId")
    @Expose
    public String regionId;

    @SerializedName("regions")
    @Expose
    public List<RegionModel> regionModelList;

    @SerializedName("groups")
    @Expose
    public List<GroupModel> groups;

    @SerializedName("course")
    @Expose
    public GradeModel course;

    @SerializedName("cities")
    @Expose
    public List<StateModel> cities;

    @SerializedName("schools")
    @Expose
    public List<SchoolModel> schools;

    @SerializedName("teacherTypes")
    @Expose
    public List<String> teacherTypes;
}
