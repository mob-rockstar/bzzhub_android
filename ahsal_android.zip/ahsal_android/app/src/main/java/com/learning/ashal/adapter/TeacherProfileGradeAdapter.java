package com.learning.ashal.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.learning.ashal.R;
import com.learning.ashal.databinding.RowTeacherGradeBinding;
import com.learning.ashal.databinding.RowTeacherProfileGradeBinding;
import com.learning.ashal.databinding.RowTeacherSubjectBinding;
import com.learning.ashal.model.GradeModel;
import com.learning.ashal.model.SubjectModel;
import com.learning.ashal.utilities.LocaleHelper;

import java.util.List;

public class TeacherProfileGradeAdapter extends RecyclerView.Adapter<TeacherProfileGradeAdapter.MyViewHolder> {

    private TeacherProfileGradeAdapter.OnItemClickListener onItemClickListener;
    private List<GradeModel> gradeModelList;
    private Context context;
    private boolean mBIsEnglish;

    public TeacherProfileGradeAdapter(Context context, TeacherProfileGradeAdapter.OnItemClickListener onItemClickListener){
        this.onItemClickListener = onItemClickListener;
        this.context = context;
        String lang = LocaleHelper.getLanguage(context);
        if(lang.equals("en")){
            mBIsEnglish = true;
        }else{
            mBIsEnglish = false;
        }
    }

    @NonNull
    @Override
    public TeacherProfileGradeAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowTeacherProfileGradeBinding binding = DataBindingUtil.inflate( LayoutInflater.from(parent.getContext()), R.layout.row_teacher_profile_grade, parent, false);
        return new MyViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull TeacherProfileGradeAdapter.MyViewHolder holder, final int position) {
        final GradeModel gradeModel = gradeModelList.get(position);

        holder.binding.checkbox.setChecked(gradeModel.isSelected);

        if(mBIsEnglish){
            holder.binding.txtGrade.setText(gradeModel.englishName);
        }else{
            holder.binding.txtGrade.setText(gradeModel.arabicName);
        }

        holder.binding.checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                gradeModel.isSelected = b;
                notifyDataSetChanged();
                onItemClickListener.onClick(gradeModel);
            }
        });
    }

    public void setData(List<GradeModel> list){
        this.gradeModelList = list;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if(gradeModelList != null )
            return gradeModelList.size();
        return 0;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private RowTeacherProfileGradeBinding binding;
        public MyViewHolder(RowTeacherProfileGradeBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public interface OnItemClickListener{
        void onClick(GradeModel gradeModel);
    }
}
