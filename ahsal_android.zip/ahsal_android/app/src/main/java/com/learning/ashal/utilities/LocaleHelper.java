package com.learning.ashal.utilities;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;

import java.util.Locale;

public class LocaleHelper {

    private static final String SELECTED_LANGUAGE = "Locale.Helper.Selected.Language";

    public static void onAttach(Context context) {
        String lang = getPersistedData(context, "ar");
        if(lang.equals("en")){
            changeLocale(context, lang, "US");
        }else{
            changeLocale(context, lang, "SA");
        }
    }

    public static void onAttach(Context context, String defaultLanguage, String country) {
        String lang = getPersistedData(context, defaultLanguage);
        changeLocale(context, lang, country);
    }

    public static String getLanguage(Context context) {
        return getPersistedData(context, "ar");
    }

//    public static Context setLocale(Context context, String language, String country) {
//        persist(context, language);
//
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
//            return updateResources(context, language);
//        }
//
//        return updateResourcesLegacy(context, language);
//    }

    public static String getPersistedData(Context context, String defaultLanguage) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        return preferences.getString(SELECTED_LANGUAGE, defaultLanguage);
    }

    private static void persist(Context context, String language) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = preferences.edit();

        editor.putString(SELECTED_LANGUAGE, language);
        editor.apply();
    }

//    @TargetApi(Build.VERSION_CODES.N)
//    private static Context updateResources(Context context, String language) {
//        Locale locale = new Locale(language);
//        Locale.setDefault(locale);
//
//        Configuration configuration = context.getResources().getConfiguration();
//        configuration.setLocale(locale);
//
//        return context.createConfigurationContext(configuration);
//    }
//
//    @SuppressWarnings("deprecation")
//    private static Context updateResourcesLegacy(Context context, String language) {
//        Locale locale = new Locale(language);
//        Locale.setDefault(locale);
//
//        Resources resources = context.getResources();
//
//        Configuration configuration = resources.getConfiguration();
//        configuration.locale = locale;
//
//        resources.updateConfiguration(configuration, resources.getDisplayMetrics());
//
//        return context;
//    }

    // Change locale
    public static void changeLocale(Context context, String localeCode, String countryCode){

        persist(context, localeCode);

        Locale locale = new Locale(localeCode, countryCode);

//        Locale.setDefault(locale);
//        Configuration config = new Configuration();
//        config.locale = locale;
//        getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());

        Resources res = context.getResources();

        // Change locale settings in the app.
        DisplayMetrics dm = res.getDisplayMetrics();
        android.content.res.Configuration conf = res.getConfiguration();
        conf.setLocale(locale); // API 17+ only.

        res.updateConfiguration(conf, dm);
    }

}
