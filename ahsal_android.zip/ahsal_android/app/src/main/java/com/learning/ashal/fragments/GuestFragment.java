package com.learning.ashal.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.databinding.DataBindingUtil;
import com.bumptech.glide.Glide;
import com.google.android.flexbox.FlexDirection;
import com.google.android.flexbox.FlexboxLayoutManager;
import com.google.android.flexbox.JustifyContent;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.learning.ashal.R;
import com.learning.ashal.activities.LoginActivity;
import com.learning.ashal.activities.MainActivity;
import com.learning.ashal.adapter.GradeAdapter;
import com.learning.ashal.adapter.SubjectAdapter;
import com.learning.ashal.custom.CustomInfoDlg;
import com.learning.ashal.custom.SingleClickListener;
import com.learning.ashal.databinding.FragmentGuestBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.interfaces.QuestionCallbackListener;
import com.learning.ashal.model.GradeModel;
import com.learning.ashal.model.LastCourseModel;
import com.learning.ashal.model.LocalDBCartModel;
import com.learning.ashal.model.MessageEvent;
import com.learning.ashal.model.StudentModel;
import com.learning.ashal.model.SubjectModel;
import com.learning.ashal.model.UserModel;
import com.learning.ashal.utilities.AnimationUtils;
import com.learning.ashal.utilities.CheckConnection;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import com.learning.ashal.utilities.SavePref;
import com.learning.ashal.utilities.TempStore;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import io.realm.Realm;
import io.realm.RealmResults;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.learning.ashal.utilities.Constants.BASE_URL;

public class GuestFragment extends BaseFragment {

    private String TAG = GuestFragment.class.getSimpleName();
    private FragmentGuestBinding mBinding;
    private List<GradeModel> gradeModelList;
    private List<SubjectModel> subjectModelList;
    private List<SubjectModel> selectedSubjectModelList = new ArrayList<>();
    private LastCourseModel lastCourseModel;
    private GradeAdapter gradeAdapter;
    private SubjectAdapter subjectAdapter;


    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventFragment(MessageEvent messageEvent) {
        if(messageEvent.messageType.equals(MessageEvent.MessageType.PROFILE_REFRESH)){
            if(TempStore.isLoggedIn)
                callGetProfile();
        }else if(messageEvent.messageType.equals(MessageEvent.MessageType.CART_BADGE_SHOW)){
            if( TempStore.cartList.size() == 0){
                mBinding.txtCartCount.setVisibility(View.GONE);
            }else{
                mBinding.txtCartCount.setVisibility(View.VISIBLE);
                mBinding.txtCartCount.setText(String.valueOf(TempStore.cartList.size()));
            }
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_guest, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    @Override
    public void updateUI() {
        ((MainActivity)mActivity).setPrimaryBk();
        ((MainActivity)mActivity).selectHomeTabMark();
    }

    private void initView() {
        updateUI();

        UserModel userModel = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel : SavePref.getInstance(mActivity).getUserModel();
        mBinding.txtStudentName.setText("");
        if(TempStore.isLoggedIn){
            //read cart from local db
//            Realm realm = Realm.getDefaultInstance();
//            RealmResults<LocalDBCartModel> results = realm.where(LocalDBCartModel.class).findAll();
//            if(results.size() > 0){
//                for (LocalDBCartModel localDBCartModel:results) {
//                    LastCourseModel lastCourseModel = new LastCourseModel();
//                    lastCourseModel.id = localDBCartModel.id;
//                    lastCourseModel.teacherId = localDBCartModel.teacherId;
//                    lastCourseModel.firstName = localDBCartModel.firstName;
//                    lastCourseModel.lastName = localDBCartModel.lastName;
//                    lastCourseModel.title = localDBCartModel.title;
//                    lastCourseModel.description = localDBCartModel.description;
//                    lastCourseModel.image = localDBCartModel.image;
//                    lastCourseModel.rating = localDBCartModel.rating;
//                    lastCourseModel.price = localDBCartModel.price;
//                    lastCourseModel.validity_date = localDBCartModel.validity_date;
//                    lastCourseModel.isPurchasedBefore = localDBCartModel.isPurchasedBefore;
//                    TempStore.cartList.add(lastCourseModel);
//                }
//
//            }
//
//            if( TempStore.cartList.size() == 0){
//                mBinding.txtCartCount.setVisibility(View.GONE);
//            }else{
//                mBinding.txtCartCount.setVisibility(View.VISIBLE);
//                mBinding.txtCartCount.setText(String.valueOf(TempStore.cartList.size()));
//            }

            mBinding.imgProfile.setOnClickListener(new SingleClickListener() {
                @Override
                public void performClick(View v) {
                    FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new ProfileParentEditFragment(),  R.id.frameLayout);
                }
            });

            if(userModel != null){
                for (StudentModel studentModel: userModel.profiles) {
                    if(studentModel.defaults.equals("1")){
                        mBinding.txtStudentName.setText(studentModel.firstName);
                        break;
                    }
                }

                mBinding.txtName.setText(userModel.firstName);
                if(userModel.image == null){
                    Glide.with(mActivity).load(R.drawable.placeholder).into(mBinding.imgProfile);
                }else{
                    Glide.with(mActivity).load(userModel.image).into(mBinding.imgProfile);
                }
            }else{
                Glide.with(mActivity).load(R.drawable.placeholder).into(mBinding.imgProfile);
                if(CheckConnection.isNetworkAvailable(mActivity)){
                    if(!hasProfile())
                        openQuestionDlg(getString(R.string.add_student_profile), getString(R.string.add), getString(R.string.cancel),new QuestionCallbackListener() {
                            @Override
                            public void onYes() {
                                ((MainActivity)mActivity).selectNewProfile();
                            }
                            @Override
                            public void onNo() {

                            }
                        });
                }
            }

        }else{
            mBinding.txtName.setText(getString(R.string.guest));
            Glide.with(mActivity).load(R.drawable.man).into(mBinding.imgProfile);
        }

        mBinding.rlNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(TempStore.isLoggedIn){
                    ((MainActivity)mActivity).unsetTab();
                    FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new NotificationFragment(), R.id.frameLayout);
                }else{
                    Intent intent = new Intent(mActivity, LoginActivity.class);
                    intent.putExtra("fromGuest", true);
                    startActivity(intent);
                }
            }
        });

        gradeAdapter = new GradeAdapter(mActivity, new GradeAdapter.OnItemClickListener() {
            @Override
            public void onClick(GradeModel gradeModel) {
                setSubject(gradeModel);
            }
        });

        FlexboxLayoutManager managerGrade = new FlexboxLayoutManager(mActivity, FlexDirection.ROW);
        managerGrade.setJustifyContent(JustifyContent.CENTER);
        mBinding.rvGrade.setLayoutManager(managerGrade);
        mBinding.rvGrade.setAdapter(gradeAdapter);

        subjectAdapter = new SubjectAdapter(mActivity, new SubjectAdapter.OnItemClickListener() {
            @Override
            public void onClick(SubjectModel subjectModel) {
                ((MainActivity)mActivity).unsetTab();
                FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new CourseListFragment(subjectModel, selectedSubjectModelList), R.id.frameLayout);
            }
        });

        FlexboxLayoutManager manager = new FlexboxLayoutManager(mActivity, FlexDirection.ROW);
        manager.setJustifyContent(JustifyContent.CENTER);
        mBinding.rvCourse.setLayoutManager(manager);

        mBinding.rvCourse.setAdapter(subjectAdapter);

        mBinding.imgCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(TempStore.isLoggedIn){
                    ((MainActivity)mActivity).unsetTab();
                    FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new CheckoutFragment(), R.id.frameLayout);
                }else{
                    Intent intent = new Intent(mActivity, LoginActivity.class);
                    intent.putExtra("fromGuest", true);
                    startActivity(intent);
                }
            }
        });

        mBinding.llOverview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((MainActivity)mActivity).unsetTab();
                FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new LessonListFragment(lastCourseModel.title, lastCourseModel.id, lastCourseModel.image), R.id.frameLayout);
            }
        });

        if(CheckConnection.isNetworkAvailable(mActivity)){
            callGetSubjectList();
//            callLastCourse();
            callStatistics();
        }else{
            CustomInfoDlg dlg = new CustomInfoDlg(mActivity, getString(R.string.network_down), new CustomInfoDlg.ItemClickInterface() {
                @Override
                public void onClick() {
                    ((MainActivity)mActivity).selectDownload();
                }
            });
            dlg.showDialog();
        }
    }

    private void setSubject(GradeModel gradeModel){
        TempStore.gradeId = gradeModel.id;
        if(subjectModelList != null){
            selectedSubjectModelList.clear();
            for (SubjectModel subjectModel:subjectModelList) {
                if(gradeModel.id.equals(subjectModel.gradeId)){
                    selectedSubjectModelList.add(subjectModel);
                }
            }

            if(selectedSubjectModelList.size() > 0){
                mBinding.txtCourseList.setVisibility(View.VISIBLE);
                mBinding.txtNoCourseData.setVisibility(View.GONE);
                subjectAdapter.setData(selectedSubjectModelList);
                AnimationUtils.animateSlideFromRight(mActivity, mBinding.rvCourse);
            }else{
                mBinding.txtCourseList.setVisibility(View.GONE);
                mBinding.txtNoCourseData.setVisibility(View.VISIBLE);
                subjectAdapter.setData(null);
            }
        }else{
            mBinding.txtCourseList.setVisibility(View.GONE);
        }
    }

    private void callGetSubjectList(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.getStudentSubjectList();
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<List<SubjectModel>>() {}.getType();
                            try{
                                subjectModelList = gson.fromJson(jsonObject.get("data").getAsJsonArray(), type);
                                callGetGradeList();
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private void callGetGradeList(){
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.getGradeList();
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<List<GradeModel>>() {}.getType();
                            try{
                                gradeModelList = gson.fromJson(jsonObject.get("data").getAsJsonArray(), type);
                                if(gradeModelList != null && gradeModelList.size() > 0){
                                    mBinding.txtNoGradeData.setVisibility(View.GONE);
                                    gradeAdapter.setData(gradeModelList);
                                    AnimationUtils.animateSlideFromRight(mActivity, mBinding.rvGrade);
                                }else{
                                    mBinding.txtNoGradeData.setVisibility(View.VISIBLE);
                                    gradeAdapter.setData(null);
                                }

//                                new Handler().postDelayed(new Runnable() {
//                                    @Override
//                                    public void run() {
//                                        if(subjectModelList != null && gradeModelList != null && gradeModelList.size() > 0){
//                                            setSubject(gradeModelList.get(0));
//                                        }
//                                    }
//                                }, 200);

                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private void callLastCourse(){
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.lastCourse();
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<LastCourseModel>() {}.getType();
                            try{
                                lastCourseModel = gson.fromJson(jsonObject.get("data").getAsJsonObject(), type);
                                if(lastCourseModel != null){
                                    mBinding.txtCourseTitle.setText(lastCourseModel.title);
                                    if(lastCourseModel.image != null)
                                        Glide.with(mActivity).load(lastCourseModel.image).centerCrop().into(mBinding.imgOverview);
                                }
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
            }
        });
    }

    private void callStatistics(){
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.statistics();
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            JsonObject jsonObject1 = jsonObject.get("data").getAsJsonObject();
                            String courses = jsonObject1.get("courses").getAsString();
                            String subscriptions = jsonObject1.get("subscriptions").getAsString();
                            String teachers = jsonObject1.get("teachers").getAsString();

                            mBinding.txtCourses.setText(courses);
                            mBinding.txtSubscriptions.setText(subscriptions);
                            mBinding.txtTeachers.setText(teachers);
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
            }
        });
    }

    private void callGetProfile(){
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        String id = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel.id : SavePref.getInstance(mActivity).getUserModel().id;
        Call<JsonObject> call = apiInterface.getProfile(id);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<UserModel>() {}.getType();
                            try{
                                UserModel userModel = gson.fromJson(jsonObject.get("data").getAsJsonObject(), type);
                                if(TempStore.userModel == null){
                                    SavePref.getInstance(mActivity).saveUserModel(userModel);
                                }else{
                                    TempStore.userModel = userModel;
                                }

                                if(userModel != null){
                                    if(userModel.image == null){
                                        Glide.with(mActivity).load(R.drawable.placeholder).into(mBinding.imgProfile);
                                    }else{
                                        Glide.with(mActivity).load(userModel.image).into(mBinding.imgProfile);
                                    }
                                }else{
                                    Glide.with(mActivity).load(R.drawable.placeholder).into(mBinding.imgProfile);
                                }

                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

            }
        });
    }
}
