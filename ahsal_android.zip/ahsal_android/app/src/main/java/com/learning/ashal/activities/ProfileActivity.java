package com.learning.ashal.activities;

import android.os.Bundle;

import com.learning.ashal.R;
import com.learning.ashal.fragments.ChooseTypeFragment;
import com.learning.ashal.fragments.ProfileNewFragment;
import com.learning.ashal.model.StudentModel;
import com.learning.ashal.utilities.FragmentProcess;

public class ProfileActivity extends BaseActivity {

    private StudentModel studentModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        if(getIntent() != null){
            studentModel = (StudentModel) getIntent().getSerializableExtra("model");
            FragmentProcess.replaceFragment(getSupportFragmentManager(), new ProfileNewFragment(studentModel),  R.id.frameLayout);
        }else{
            FragmentProcess.replaceFragment(getSupportFragmentManager(), new ProfileNewFragment(),  R.id.frameLayout);
        }
    }
}
