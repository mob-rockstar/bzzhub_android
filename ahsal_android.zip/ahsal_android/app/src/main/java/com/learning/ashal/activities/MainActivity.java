package com.learning.ashal.activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;

import androidx.databinding.DataBindingUtil;
import com.google.gson.JsonObject;
import com.jaeger.library.StatusBarUtil;
import com.learning.ashal.R;
import com.learning.ashal.custom.CustomInfoDlg;
import com.learning.ashal.custom.CustomQuestionInfoDlg;
import com.learning.ashal.databinding.ActivityMainBinding;
import com.learning.ashal.fragments.GuestFragment;
import com.learning.ashal.fragments.LessonDetailFragment;
import com.learning.ashal.fragments.ProfileFragment;
import com.learning.ashal.fragments.ProfileNewFragment;
import com.learning.ashal.fragments.SettingFragment;
import com.learning.ashal.fragments.DownloadedVideoFragment;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.model.LocalDBCartModel;
import com.learning.ashal.model.MessageEvent;
import com.learning.ashal.utilities.CheckConnection;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.LocaleHelper;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import com.learning.ashal.utilities.SavePref;
import com.learning.ashal.utilities.TempStore;

import org.greenrobot.eventbus.EventBus;

import java.util.List;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import io.realm.Realm;
import io.realm.RealmResults;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.learning.ashal.utilities.Constants.BASE_URL;

public class MainActivity extends BaseActivity {

    private ActivityMainBinding mainBinding;

    @Override

    protected void onResume() {
        super.onResume();
        LocaleHelper.onAttach(this);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mainBinding = DataBindingUtil.setContentView(this, R.layout.activity_main);

        mainBinding.llTabHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectHome();
            }
        });

        mainBinding.llTabChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(TempStore.isLoggedIn){
                    selectChat();
                }else{
                    Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                    intent.putExtra("fromGuest", true);
                    startActivity(intent);
                }

            }
        });

        mainBinding.llTabProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(TempStore.isLoggedIn){
                    selectProfile();
                }else{
                    Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                    intent.putExtra("fromGuest", true);
                    startActivity(intent);
                }
            }
        });

        mainBinding.llTabSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectSetting();
            }
        });

        mainBinding.llTabDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectDownload();
            }
        });

        selectHome();

        Log.e("main", "is from app link: " +TempStore.isFromAppLink);
        if(TempStore.isFromAppLink){
            FragmentProcess.replaceFragment(getSupportFragmentManager(), new LessonDetailFragment(), R.id.frameLayout);
        }else{
            handleIntent(getIntent());
        }
    }

    public void setWhiteBk(){
        mainBinding.tabBackground.setBackgroundColor(getResources().getColor(R.color.colorWhite));
    }

    public void setPrimaryBk(){
        mainBinding.tabBackground.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
    }

    private void reset(){
        mainBinding.llHome.setVisibility(View.VISIBLE);
        mainBinding.llActiveHome.setVisibility(View.GONE);
        mainBinding.llChat.setVisibility(View.VISIBLE);
        mainBinding.llActiveChat.setVisibility(View.GONE);
        mainBinding.llProfile.setVisibility(View.VISIBLE);
        mainBinding.llActiveProfile.setVisibility(View.GONE);
        mainBinding.llSetting.setVisibility(View.VISIBLE);
        mainBinding.llActiveSetting.setVisibility(View.GONE);
        mainBinding.llDownload.setVisibility(View.VISIBLE);
        mainBinding.llActiveDownload.setVisibility(View.GONE);
    }

    public void selectHome(){
        if(CheckConnection.isNetworkAvailable(this)){
            mainBinding.tabBackground.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
            clearBackStack();
            reset();
            mainBinding.llHome.setVisibility(View.GONE);
            mainBinding.llActiveHome.setVisibility(View.VISIBLE);
            FragmentProcess.replaceFragment(getSupportFragmentManager(), new GuestFragment(),  R.id.frameLayout);
        }else{
            CustomInfoDlg dlg = new CustomInfoDlg(this, getString(R.string.network_down), new CustomInfoDlg.ItemClickInterface() {
                @Override
                public void onClick() {
                    selectDownload();
                }
            });
            dlg.showDialog();
        }
    }

    public void selectHomeTabMark(){
        mainBinding.llHome.setVisibility(View.GONE);
        mainBinding.llActiveHome.setVisibility(View.VISIBLE);
    }

    private void selectChat(){
        reset();
        mainBinding.llChat.setVisibility(View.GONE);
        mainBinding.llActiveChat.setVisibility(View.VISIBLE);
//        FragmentProcess.replaceFragment(getSupportFragmentManager(), new ChooseTypeFragment(),  R.id.frameLayout);
    }

    public void selectChatTabMark(){
        mainBinding.llChat.setVisibility(View.GONE);
        mainBinding.llActiveChat.setVisibility(View.VISIBLE);
    }

    public void selectDownload(){
        mainBinding.tabBackground.setBackgroundColor(getResources().getColor(R.color.colorWhite));
        clearBackStack();
        reset();
        mainBinding.llDownload.setVisibility(View.GONE);
        mainBinding.llActiveDownload.setVisibility(View.VISIBLE);
        FragmentProcess.replaceFragment(getSupportFragmentManager(), new DownloadedVideoFragment(),  R.id.frameLayout);
    }

    public void selectDownloadTabMark(){
        mainBinding.llDownload.setVisibility(View.GONE);
        mainBinding.llActiveDownload.setVisibility(View.VISIBLE);
    }

    public void selectNewProfile(){
        if(CheckConnection.isNetworkAvailable(this)){
            mainBinding.tabBackground.setBackgroundColor(getResources().getColor(R.color.colorWhite));
            clearBackStack();
            reset();
            mainBinding.llProfile.setVisibility(View.GONE);
            mainBinding.llActiveProfile.setVisibility(View.VISIBLE);
            FragmentProcess.replaceFragment(getSupportFragmentManager(), new ProfileFragment(),  R.id.frameLayout);
            FragmentProcess.addFragment(getSupportFragmentManager(), new ProfileNewFragment(),  R.id.frameLayout);
        }else{
            CustomInfoDlg dlg = new CustomInfoDlg(this, getString(R.string.network_down), new CustomInfoDlg.ItemClickInterface() {
                @Override
                public void onClick() {
                    selectDownload();
                }
            });
            dlg.showDialog();
        }
    }

    public void selectProfile(){
        mainBinding.tabBackground.setBackgroundColor(getResources().getColor(R.color.colorWhite));
        clearBackStack();
        reset();
        mainBinding.llProfile.setVisibility(View.GONE);
        mainBinding.llActiveProfile.setVisibility(View.VISIBLE);
        FragmentProcess.replaceFragment(getSupportFragmentManager(), new ProfileFragment(),  R.id.frameLayout);
    }

    public void selectProfileTabMark(){
        mainBinding.llProfile.setVisibility(View.GONE);
        mainBinding.llActiveProfile.setVisibility(View.VISIBLE);
    }


    private void selectSetting(){
        if(CheckConnection.isNetworkAvailable(this)){
            mainBinding.tabBackground.setBackgroundColor(getResources().getColor(R.color.colorWhite));
            clearBackStack();
            reset();
            mainBinding.llSetting.setVisibility(View.GONE);
            mainBinding.llActiveSetting.setVisibility(View.VISIBLE);
            FragmentProcess.replaceFragment(getSupportFragmentManager(), new SettingFragment(),  R.id.frameLayout);
        }else{
            CustomInfoDlg dlg = new CustomInfoDlg(this, getString(R.string.network_down), new CustomInfoDlg.ItemClickInterface() {
                @Override
                public void onClick() {
                    selectDownload();
                }
            });
            dlg.showDialog();
        }
    }

    public void selectSettingTabMark(){
        mainBinding.llSetting.setVisibility(View.GONE);
        mainBinding.llActiveSetting.setVisibility(View.VISIBLE);
    }

    public void unsetTab(){
        mainBinding.llActiveSetting.setVisibility(View.GONE);
        mainBinding.llSetting.setVisibility(View.VISIBLE);
        mainBinding.llActiveProfile.setVisibility(View.GONE);
        mainBinding.llProfile.setVisibility(View.VISIBLE);
        mainBinding.llActiveChat.setVisibility(View.GONE);
        mainBinding.llChat.setVisibility(View.VISIBLE);
        mainBinding.llActiveHome.setVisibility(View.GONE);
        mainBinding.llHome.setVisibility(View.VISIBLE);
        mainBinding.llActiveDownload.setVisibility(View.GONE);
        mainBinding.llDownload.setVisibility(View.VISIBLE);
    }

    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        String appLinkAction = intent.getAction();
        Uri appLinkData = intent.getData();
        if (Intent.ACTION_VIEW.equals(appLinkAction) && appLinkData != null){
            List<String> pathList = appLinkData.getPathSegments();
            if(pathList != null && pathList.size() == 2){
                TempStore.isFromAppLink = true;
                if(pathList.get(0).contains("lesson")){
                    TempStore.lessonId = pathList.get(1);
                    //is logged in
                    if(SavePref.getInstance(MainActivity.this).getUserModel() == null && TempStore.userModel == null){
                        Intent intent1 = new Intent(MainActivity.this, LoginActivity.class);
                        startActivity(intent1);
                        finish();
                        return;
                    }
                    FragmentProcess.replaceFragment(getSupportFragmentManager(), new LessonDetailFragment(), R.id.frameLayout);
                }else if(pathList.get(0).contains("payment") && pathList.get(1).contains("success")){
                    TempStore.isFromAppLink = false;
                    callGetPaymentStatus();
                }
            }
        }
    }

    private void callGetPaymentStatus(){
        ProgressDialog.showProgress(this);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.paymentStatus(TempStore.paymentId);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null ) {
                        CustomInfoDlg dlg;
                        if(!jsonObject.get("data").getAsString().equals("failed")){
                            TempStore.cartList.clear();

                            Realm realm = Realm.getDefaultInstance();
                            RealmResults<LocalDBCartModel> results = realm.where(LocalDBCartModel.class).findAll();
                            realm.beginTransaction();
                            results.deleteAllFromRealm();
                            realm.commitTransaction();

                            MessageEvent messageEvent = new MessageEvent();
                            messageEvent.messageType = MessageEvent.MessageType.CART_BADGE_SHOW;
                            EventBus.getDefault().post(messageEvent);
                            dlg = new CustomInfoDlg(MainActivity.this, getString(R.string.payment_success), new CustomInfoDlg.ItemClickInterface() {
                                @Override
                                public void onClick() {

                                }
                            });
                        }else{
                            dlg = new CustomInfoDlg(MainActivity.this, getString(R.string.payment_fail), new CustomInfoDlg.ItemClickInterface() {
                                @Override
                                public void onClick() {

                                }
                            });
                        }
                        dlg.showDialog();
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }
}
