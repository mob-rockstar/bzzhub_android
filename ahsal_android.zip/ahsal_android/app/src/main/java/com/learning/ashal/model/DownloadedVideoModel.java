package com.learning.ashal.model;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;
import io.realm.annotations.Required;

public class DownloadedVideoModel extends RealmObject {
    @Required
    public String id;
    @Required
    public String courseTitle;
    @Required
    public String lessonName;
    @Required
    public String date;
    @Required
    public String userId;
    @Required
    public String gradeEnglishName;
    @Required
    public String gradeArabicName;
    @Required
    public String gradeId;
}