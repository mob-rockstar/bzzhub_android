package com.learning.ashal.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class QuestionModel {
    @SerializedName("id")
    @Expose
    public String id;

    @SerializedName("lessonId")
    @Expose
    public String lessonId;

    @SerializedName("question")
    @Expose
    public String question;

    @SerializedName("status")
    @Expose
    public String status;

    @SerializedName("created_at")
    @Expose
    public String created_at;

    @SerializedName("updated_at")
    @Expose
    public String updated_at;

    @SerializedName("file")
    @Expose
    public String file;

    @SerializedName("type")
    @Expose
    public String type;

    @SerializedName("feedback")
    @Expose
    public String feedback;

    @SerializedName("feedbackType")
    @Expose
    public String feedbackType;

    @SerializedName("feedbackImage")
    @Expose
    public String feedbackImage;

    @SerializedName("numberOfCorrectAnswers")
    @Expose
    public String numberOfCorrectAnswers;

    @SerializedName("answers")
    @Expose
    public List<AnswerModel> answerModelList;
}
