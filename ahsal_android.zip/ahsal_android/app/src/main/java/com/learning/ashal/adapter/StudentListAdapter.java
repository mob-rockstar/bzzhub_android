package com.learning.ashal.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;
import com.learning.ashal.R;
import com.learning.ashal.databinding.RowStudentBinding;
import com.learning.ashal.model.StudentModel;
import com.learning.ashal.utilities.LocaleHelper;

import java.util.List;

public class StudentListAdapter extends RecyclerView.Adapter<StudentListAdapter.MyViewHolder> {

    private OnItemClickListener onItemClickListener;
    private List<StudentModel> studentModelList;
    private Context context;

    public StudentListAdapter(){

    }

    public StudentListAdapter(Context context, OnItemClickListener onItemClickListener){
        this.onItemClickListener = onItemClickListener;
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowStudentBinding binding = DataBindingUtil.inflate( LayoutInflater.from(parent.getContext()), R.layout.row_student, parent, false);
        return new MyViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        final StudentModel studentModel = studentModelList.get(position);
        holder.binding.txtName.setText(studentModel.firstName);
        if(LocaleHelper.getLanguage(context).equals("en")){
            holder.binding.txtGrade.setText(studentModel.gradeEnglishName);
        }else{
            holder.binding.txtGrade.setText(studentModel.gradeArabicName);
        }
        if(studentModel.isSelected){
            holder.binding.row.setBackgroundColor(context.getResources().getColor(R.color.colorSelected));
        }else{
            holder.binding.row.setBackgroundColor(context.getResources().getColor(R.color.colorWhite));
        }

        holder.binding.row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for(StudentModel model: studentModelList){
                    model.isSelected = false;
                }
                studentModel.isSelected = true;

                onItemClickListener.onClick(studentModel);
                notifyDataSetChanged();
            }
        });
    }

    public void setData(List<StudentModel> list){
        this.studentModelList = list;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if(studentModelList != null )
            return studentModelList.size();
        return 0;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private RowStudentBinding binding;
        public MyViewHolder(RowStudentBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public interface OnItemClickListener{
        void onClick(StudentModel studentModel);
    }
}
