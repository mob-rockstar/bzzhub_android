package com.learning.ashal.fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.databinding.DataBindingUtil;
import com.learning.ashal.R;
import com.learning.ashal.activities.MainActivity;
import com.learning.ashal.activities.VideoPlayActivity;
import com.learning.ashal.adapter.VideoDownloadAdapter;
import com.learning.ashal.adapter.VideoDownloadCourseAdapter;
import com.learning.ashal.adapter.VideoDownloadGradeAdapter;
import com.learning.ashal.custom.SelectGradePopupWindow;
import com.learning.ashal.custom.SelectStudentPopupWindow;
import com.learning.ashal.databinding.FragmentVideoDownloadBinding;
import com.learning.ashal.interfaces.QuestionCallbackListener;
import com.learning.ashal.model.DownloadedVideoModel;
import com.learning.ashal.model.GradeModel;
import com.learning.ashal.model.MessageEvent;
import com.learning.ashal.model.StudentModel;
import com.learning.ashal.model.UserModel;
import com.learning.ashal.utilities.AnimationUtils;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.LocaleHelper;
import com.learning.ashal.utilities.SavePref;
import com.learning.ashal.utilities.TempStore;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import io.realm.Realm;
import io.realm.RealmResults;

public class DownloadedVideoFragment extends BaseFragment {

    private String TAG = DownloadedVideoFragment.class.getSimpleName();
    private FragmentVideoDownloadBinding mBinding;
    private VideoDownloadCourseAdapter videoDownloadCourseAdapter;
    private Realm realm;
    private String baseDir = Environment.getExternalStorageDirectory() + "/ashal/";
    private RealmResults<DownloadedVideoModel> results;
    private GradeModel selectedGrade;
    private List<String> courseNames = new ArrayList<>();
    private UserModel userModel;

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventFragment(MessageEvent messageEvent) {
        if(messageEvent.messageType.equals(MessageEvent.MessageType.SHOW_DIALOG)){
            if(messageEvent.isSuccess){
                if(selectedGrade != null)
                    loadCourse(selectedGrade);
            }
        }
    }

    @Override
    public void updateUI() {
        ((MainActivity)mActivity).selectDownloadTabMark();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_video_download, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    private void initView() {
        userModel = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel : SavePref.getInstance(mActivity).getUserModel();
        videoDownloadCourseAdapter = new VideoDownloadCourseAdapter(mActivity, new VideoDownloadCourseAdapter.OnItemClickListener() {
            @Override
            public void onClick(String courseName) {
                FragmentProcess.addFragment(mActivity.getSupportFragmentManager(), new DownloadedVideoLessonFragment(courseName, selectedGrade), R.id.frameLayout);
            }

            @Override
            public void onDelete(String courseName) {
                openQuestionDlg(getString(R.string.sure_delete_course), new QuestionCallbackListener() {
                    @Override
                    public void onYes() {
                        deleteCourse(courseName);
                        courseNames.remove(courseName);
                        videoDownloadCourseAdapter.notifyDataSetChanged();
                        if(courseNames.size() > 0){
                            mBinding.txtNoData.setVisibility(View.GONE);
                        }else{
                            mBinding.txtNoData.setVisibility(View.VISIBLE);
                        }
                    }

                    @Override
                    public void onNo() {

                    }
                });

            }
        });
        mBinding.rvVideo.setAdapter(videoDownloadCourseAdapter);

        File storageDir = new File(baseDir);
        if (!storageDir.exists())
            storageDir.mkdirs();

        realm = Realm.getDefaultInstance();
        if(!TempStore.isLoggedIn || realm.where(DownloadedVideoModel.class).findAll().size() == 0){
            mBinding.txtNoData.setVisibility(View.VISIBLE);
        }else{
            loadGrade();
            mBinding.txtNoData.setVisibility(View.GONE);
        }
    }

    private void loadCourse(GradeModel gradeModel){
        mBinding.imgBack.setVisibility(View.GONE);
        results = realm.where(DownloadedVideoModel.class)
                .equalTo("userId", userModel.id)
                .equalTo("gradeId", gradeModel.id)
                .findAll();


        List<DownloadedVideoModel> downloadedVideoModels = results;
        for(DownloadedVideoModel downloadedVideoModel : downloadedVideoModels){
            if(!courseNames.contains(downloadedVideoModel.courseTitle))
                courseNames.add(downloadedVideoModel.courseTitle);
        }

        if(results.size() > 0){
            videoDownloadCourseAdapter.setData(courseNames);
            mBinding.txtNoData.setVisibility(View.GONE);
            AnimationUtils.animateSlideTopFromDown(mActivity, mBinding.rvVideo);
        }else{
            videoDownloadCourseAdapter.setData(null);
            mBinding.txtNoData.setVisibility(View.VISIBLE);
        }
    }

    private void loadGrade(){
        mBinding.imgBack.setVisibility(View.GONE);
        results = realm.where(DownloadedVideoModel.class)
                .equalTo("userId", userModel.id)
                .findAll();

        for(int i = 0; i < results.size(); i++){
            File file = new File(baseDir + results.get(i).id);
            if(!file.exists()){
                deleteRecord(results.get(i));
            }
        }

        List<DownloadedVideoModel> downloadedVideoModels = results;
        List<GradeModel> gradeList = new ArrayList<>();
        List<String> gradeIdList = new ArrayList<>();
        for(DownloadedVideoModel downloadedVideoModel : downloadedVideoModels){
            GradeModel gradeModel = new GradeModel();
            gradeModel.id = downloadedVideoModel.gradeId;
            gradeModel.arabicName = downloadedVideoModel.gradeArabicName;
            gradeModel.englishName = downloadedVideoModel.gradeEnglishName;
            if(!gradeIdList.contains(gradeModel.id)){
                gradeList.add(gradeModel);
                gradeIdList.add(gradeModel.id);
            }
        }

        View dlgView = ((LayoutInflater) mActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.dialog_select_grade, null);
        SelectGradePopupWindow selectGradePopupWindow = new SelectGradePopupWindow(dlgView, mActivity, gradeList, new SelectGradePopupWindow.OnClickListener() {
            @Override
            public void onSelect(GradeModel gradeModel) {
                selectedGrade = gradeModel;
                loadCourse(gradeModel);
            }

            @Override
            public void onCancel() {
                ((MainActivity)mActivity).selectHome();
            }
        });
        selectGradePopupWindow.showAtLocation(mBinding.getRoot(), Gravity.CENTER, 0, 0);
    }

    public void deleteRecord(DownloadedVideoModel downloadedVideoModel){
        RealmResults<DownloadedVideoModel> results = realm.where(DownloadedVideoModel.class).equalTo("lessonName", downloadedVideoModel.lessonName).findAll();

        realm.beginTransaction();

        results.deleteAllFromRealm();

        realm.commitTransaction();
    }

    public void deleteCourse(String courseName){
        RealmResults<DownloadedVideoModel> results = realm.where(DownloadedVideoModel.class).equalTo("courseTitle", courseName).findAll();

        List<DownloadedVideoModel> downloadedVideoModels = results;
        for(DownloadedVideoModel downloadedVideoModel: downloadedVideoModels){
            File file = new File(baseDir + downloadedVideoModel.id);
            if(file.exists()){
                file.delete();
            }
        }

        realm.beginTransaction();

        results.deleteAllFromRealm();

        realm.commitTransaction();
    }
}
