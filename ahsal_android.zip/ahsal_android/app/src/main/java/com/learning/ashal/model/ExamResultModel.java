package com.learning.ashal.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ExamResultModel {
    @SerializedName("id")
    @Expose
    public String id;

    @SerializedName("title")
    @Expose
    public String title;

    @SerializedName("lessonId")
    @Expose
    public String lessonId;

    @SerializedName("totalQuestions")
    @Expose
    public String totalQuestions;

    @SerializedName("correctAnswers")
    @Expose
    public String correctAnswers;

    @SerializedName("examTime")
    @Expose
    public String examTime;

    @SerializedName("created_at")
    @Expose
    public String created_at;

    @SerializedName("updated_at")
    @Expose
    public String updated_at;

    @SerializedName("studentId")
    @Expose
    public String studentId;

    @SerializedName("cover")
    @Expose
    public String cover;
}
