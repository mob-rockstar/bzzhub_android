package com.learning.ashal.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;

import androidx.databinding.DataBindingUtil;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.learning.ashal.R;
import com.learning.ashal.activities.AboutUsActivity;
import com.learning.ashal.activities.LoginActivity;
import com.learning.ashal.activities.TeacherMainActivity;
import com.learning.ashal.activities.TermsActivity;
import com.learning.ashal.databinding.FragmentSettingBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.interfaces.QuestionCallbackListener;
import com.learning.ashal.model.TeacherModel;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.LocaleHelper;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import com.learning.ashal.utilities.SavePref;
import com.learning.ashal.utilities.TempStore;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.learning.ashal.utilities.Constants.BASE_URL;

public class TeacherSettingFragment extends BaseFragment {

    private String TAG = TeacherSettingFragment.class.getSimpleName();
    private FragmentSettingBinding mBinding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_setting, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    @Override
    public void updateUI() {
       ((TeacherMainActivity)mActivity).selectSettingTabMark();
    }

    private void initView() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorPrimary));

        TeacherModel teacherModel = SavePref.getInstance(mActivity).getTeacherModel() == null ? TempStore.teacherModel : SavePref.getInstance(mActivity).getTeacherModel();
        mBinding.txtName.setText(teacherModel.firstName);

        mBinding.llNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentProcess.addFragment(mActivity.getSupportFragmentManager(), new TeacherNotificationFragment(), R.id.frameLayout);
            }
        });

        if(LocaleHelper.getLanguage(mActivity).equals("en")){
            mBinding.swLang.setChecked(true);
        }else{
            mBinding.swLang.setChecked(false);
        }

        mBinding.swLang.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    changeLanguage("en");
                }else {
                    changeLanguage("ar");
                }
            }
        });

        mBinding.llTerms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mActivity, TermsActivity.class));
            }
        });

        mBinding.llAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mActivity, AboutUsActivity.class));
            }
        });

        mBinding.llLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openQuestionDlg(getString(R.string.sure_logout), mBinding.getRoot(), new QuestionCallbackListener() {
                    @Override
                    public void onYes() {
                        callLogout();
                    }

                    @Override
                    public void onNo() {

                    }
                });
            }
        });

        mBinding.llDeleteAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openQuestionDlg(getString(R.string.sure_delete_account), mBinding.getRoot(), new QuestionCallbackListener() {
                    @Override
                    public void onYes() {
                        callDeleteAccount();
                    }

                    @Override
                    public void onNo() {

                    }
                });
            }
        });

        callGetNotificationStatus();
    }


    private void changeLanguage(final String lang){
        if(lang.equals("en")){
            LocaleHelper.changeLocale(mActivity, "en", "US");
        }else{
            LocaleHelper.changeLocale(mActivity, "ar", "SA");
        }
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                restart();
            }
        }, 200);

        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        String id = SavePref.getInstance(mActivity).getTeacherModel() == null ? TempStore.teacherModel.id : SavePref.getInstance(mActivity).getTeacherModel().id;
        Call<JsonObject> call = apiInterface.updateTeacherLanguage(id, lang);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {

                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

            }
        });
    }

    private void callUpdateNotificationStatus(String value){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        String id = SavePref.getInstance(mActivity).getTeacherModel() == null ? TempStore.teacherModel.id : SavePref.getInstance(mActivity).getTeacherModel().id;
        Call<JsonObject> call = apiInterface.updateTeacherNotificationStatus(id, value);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {

                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private void callLogout(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        String id = SavePref.getInstance(mActivity).getTeacherModel() == null ? TempStore.teacherModel.id : SavePref.getInstance(mActivity).getTeacherModel().id;
        Call<JsonObject> call = apiInterface.logoutTeacher(id);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            SavePref.getInstance(mActivity).clearPref();
                            TempStore.teacherModel = null;
                            Intent intent = new Intent(mActivity, LoginActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    public void callDeleteAccount(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        JsonObject requestParam = new JsonObject();
        JsonArray idArray = new JsonArray();
        String id = SavePref.getInstance(mActivity).getTeacherModel() == null ? TempStore.teacherModel.id : SavePref.getInstance(mActivity).getTeacherModel().id;
        idArray.add(id);
        requestParam.add("ids", idArray);
        requestParam.addProperty("status", 3);

        Call<JsonObject> call = apiInterface.deleteTeacherAccount(requestParam);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            SavePref.getInstance(mActivity).clearPref();
                            TempStore.teacherModel = null;
                            Intent intent = new Intent(mActivity, LoginActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }
            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private void callGetNotificationStatus(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        String id = SavePref.getInstance(mActivity).getTeacherModel() == null ? TempStore.teacherModel.id : SavePref.getInstance(mActivity).getTeacherModel().id;
        Call<JsonObject> call = apiInterface.getTeacherNotificationStatus(id);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            if(jsonObject.get("data").getAsString().equals("1")){
                                mBinding.swNotification.setChecked(true);
                            }else{
                                mBinding.swNotification.setChecked(false);
                            }

                            mBinding.swNotification.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                @Override
                                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                    String value = b ? "1" : "2";
                                    callUpdateNotificationStatus(value);
                                }
                            });
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }
}
