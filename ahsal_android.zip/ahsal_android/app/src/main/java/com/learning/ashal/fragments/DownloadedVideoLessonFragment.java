package com.learning.ashal.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;

import com.learning.ashal.R;
import com.learning.ashal.activities.MainActivity;
import com.learning.ashal.activities.VideoPlayActivity;
import com.learning.ashal.adapter.VideoDownloadAdapter;
import com.learning.ashal.databinding.FragmentVideoDownloadBinding;
import com.learning.ashal.interfaces.QuestionCallbackListener;
import com.learning.ashal.model.DownloadedVideoModel;
import com.learning.ashal.model.GradeModel;
import com.learning.ashal.model.MessageEvent;
import com.learning.ashal.model.UserModel;
import com.learning.ashal.utilities.AnimationUtils;
import com.learning.ashal.utilities.SavePref;
import com.learning.ashal.utilities.TempStore;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.File;
import io.realm.Realm;
import io.realm.RealmResults;

public class DownloadedVideoLessonFragment extends BaseFragment {

    private String TAG = DownloadedVideoLessonFragment.class.getSimpleName();
    private FragmentVideoDownloadBinding mBinding;
    private VideoDownloadAdapter videoDownloadAdapter;
    private Realm realm;
    private String baseDir = Environment.getExternalStorageDirectory() + "/ashal/";
    private RealmResults<DownloadedVideoModel> results;
    private GradeModel selectedGrade;
    private String courseName;
    private UserModel userModel;

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventFragment(MessageEvent messageEvent) {
        if(messageEvent.messageType.equals(MessageEvent.MessageType.SHOW_DIALOG)){
            if(messageEvent.isSuccess){
                loadLesson();
            }
        }
    }

    public DownloadedVideoLessonFragment(){

    }

    public DownloadedVideoLessonFragment(String courseName, GradeModel gradeModel){
        this.courseName = courseName;
        this.selectedGrade = gradeModel;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_video_download, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    private void initView() {
        userModel = SavePref.getInstance(mActivity).getUserModel() == null ? TempStore.userModel : SavePref.getInstance(mActivity).getUserModel();
        videoDownloadAdapter = new VideoDownloadAdapter(mActivity, new VideoDownloadAdapter.OnItemClickListener() {
            @Override
            public void onClick(DownloadedVideoModel downloadedVideoModel) {
                Intent intent = new Intent(mActivity, VideoPlayActivity.class);
                intent.putExtra("uri", baseDir + downloadedVideoModel.id);
                startActivity(intent);
            }

            @Override
            public void onDelete(DownloadedVideoModel downloadedVideoModel) {
                openQuestionDlg(getString(R.string.sure_delete_video), new QuestionCallbackListener() {
                    @Override
                    public void onYes() {
                        File file = new File(baseDir + downloadedVideoModel.id);
                        if(file.exists()){
                            file.delete();
                        }
                        File fileLesson = new File(baseDir + downloadedVideoModel.lessonName);
                        if(fileLesson.exists()){
                            fileLesson.delete();
                        }

                        File fileCourse = new File(baseDir + downloadedVideoModel.courseTitle);
                        if(fileCourse.exists()){
                            fileCourse.delete();
                        }

                        deleteRecord(downloadedVideoModel);
                        videoDownloadAdapter.notifyDataSetChanged();
                        if(results.size() > 0){
                            mBinding.txtNoData.setVisibility(View.GONE);
                        }else{
                            mBinding.txtNoData.setVisibility(View.VISIBLE);
                        }
                    }

                    @Override
                    public void onNo() {

                    }
                });

            }
        });

        mBinding.rvVideo.setAdapter(videoDownloadAdapter);

        realm = Realm.getDefaultInstance();

        mBinding.imgBack.setVisibility(View.VISIBLE);

        mBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity)mActivity).selectDownloadTabMark();
                mActivity.back();
            }
        });

        ((MainActivity)mActivity).unsetTab();

        loadLesson();
    }
    
    private void loadLesson(){
        results = realm.where(DownloadedVideoModel.class)
                .equalTo("userId", userModel.id)
                .equalTo("gradeId", selectedGrade.id)
                .equalTo("courseTitle", courseName)
                .findAll();

        if(results.size() > 0){
            videoDownloadAdapter.setData(results);
            AnimationUtils.animateSlideTopFromDown(mActivity, mBinding.rvVideo);
        }else{
            videoDownloadAdapter.setData(null);
        }
    }


    public void deleteRecord(DownloadedVideoModel downloadedVideoModel){
        RealmResults<DownloadedVideoModel> results = realm.where(DownloadedVideoModel.class).equalTo("lessonName", downloadedVideoModel.lessonName).findAll();

        realm.beginTransaction();

        results.deleteAllFromRealm();

        realm.commitTransaction();
    }

}
