package com.learning.ashal.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.databinding.DataBindingUtil;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.learning.ashal.R;
import com.learning.ashal.adapter.QuestionAdapter;
import com.learning.ashal.adapter.TeacherLessonsAdapter;
import com.learning.ashal.databinding.FragmentTeacherLessonsBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.interfaces.QuestionCallbackListener;
import com.learning.ashal.model.AnswerModel;
import com.learning.ashal.model.LessonModel;
import com.learning.ashal.model.MessageEvent;
import com.learning.ashal.model.QuestionModel;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.lang.reflect.Type;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.learning.ashal.utilities.Constants.BASE_URL;

public class TeacherLessonsFragment extends BaseFragment {

    private String TAG = TeacherLessonsFragment.class.getSimpleName();
    private FragmentTeacherLessonsBinding mBinding;
    private TeacherLessonsAdapter teacherLessonsAdapter;
    private String courseId;
    private List<LessonModel> lessonModelList;
    private boolean isNotification;

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventFragment(MessageEvent messageEvent) {
        if(messageEvent.messageType.equals(MessageEvent.MessageType.LESSON_REFRESH)){
            isNotification = true;
            callGetLessonList();
        }
    }

    public TeacherLessonsFragment(){

    }

    public TeacherLessonsFragment(String courseId){
        this.courseId = courseId;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_teacher_lessons, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    private void initView() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorWhite));

        mBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.back();
            }
        });

        teacherLessonsAdapter = new TeacherLessonsAdapter(mActivity, new TeacherLessonsAdapter.OnItemClickListener() {
            @Override
            public void onDelete(LessonModel lessonModel) {
                openQuestionDlg(getString(R.string.sure_delete_lesson), new QuestionCallbackListener() {
                    @Override
                    public void onYes() {
                        callDelLessonList(lessonModel);
                    }

                    @Override
                    public void onNo() {

                    }
                });
            }

            @Override
            public void onEdit(LessonModel lessonModel) {
                FragmentProcess.addFragment(mActivity.getSupportFragmentManager(), new TeacherAddLessonFragment(lessonModel), R.id.frameLayout);
            }
        });

        mBinding.rvLessons.setAdapter(teacherLessonsAdapter);

        mBinding.imgAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentProcess.addFragment(mActivity.getSupportFragmentManager(), new TeacherAddLessonFragment(courseId), R.id.frameLayout);
            }
        });

        callGetLessonList();
    }

    private void callGetLessonList(){
        if(!isNotification)
            ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.lessonList(this.courseId);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if(!isNotification)
                    ProgressDialog.hideprogressbar();
                isNotification = false;
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<List<LessonModel>>() {}.getType();
                            try{
                                lessonModelList = gson.fromJson(jsonObject.get("data").getAsJsonArray(), type);
                                if(lessonModelList != null && lessonModelList.size() > 0){
                                    mBinding.txtNoData.setVisibility(View.GONE);
                                    teacherLessonsAdapter.setData(lessonModelList);
                                }else{
                                    mBinding.txtNoData.setVisibility(View.VISIBLE);
                                    teacherLessonsAdapter.setData(null);
                                }
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                if(!isNotification)
                    ProgressDialog.hideprogressbar();
                isNotification = false;
            }
        });
    }

    private void callDelLessonList(LessonModel lessonModel){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.deleteLesson(lessonModel.id);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            lessonModelList.remove(lessonModel);
                            teacherLessonsAdapter.notifyDataSetChanged();

                            MessageEvent messageEvent = new MessageEvent();
                            messageEvent.messageType = MessageEvent.MessageType.LESSON_REFRESH;
                            EventBus.getDefault().post(messageEvent);
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }
}
