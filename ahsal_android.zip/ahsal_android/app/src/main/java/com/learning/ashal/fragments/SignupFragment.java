package com.learning.ashal.fragments;

import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.databinding.DataBindingUtil;
import com.google.android.material.button.MaterialButton;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.learning.ashal.R;
import com.learning.ashal.custom.CustomTextView;
import com.learning.ashal.databinding.FragmentSignUpBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.model.TeacherModel;
import com.learning.ashal.model.UserModel;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.LocaleHelper;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import com.learning.ashal.utilities.SavePref;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import static com.learning.ashal.utilities.Constants.BASE_URL;

public class SignupFragment extends BaseFragment {

    private String TAG = SignupFragment.class.getSimpleName();
    private FragmentSignUpBinding mBinding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_sign_up, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    private void initView() {
        MaterialButton btNext = mBinding.getRoot().findViewById(R.id.btNext);
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkValidForm()){
                    if(SavePref.getInstance(mActivity).isLoginTypeTeacher()){
                        callTeacherRegister();
                    }else{
                        callRegister();
                    }
                }
            }
        });
        CustomTextView txtTitle = mBinding.getRoot().findViewById(R.id.txtTitle);
        txtTitle.setText(getResources().getString(R.string.register));

        mBinding.txtTerms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new TermsFragment(), R.id.frameLayout);
            }
        });

        mBinding.txtPolicies.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new AboutUsFragment(), R.id.frameLayout);
            }
        });

        mBinding.txtSingIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.back();
            }
        });

        mBinding.imgHideEye.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mBinding.imgHideEye.setVisibility(View.GONE);
                mBinding.imgShowEye.setVisibility(View.VISIBLE);
                mBinding.etPwd.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            }
        });

        mBinding.imgShowEye.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mBinding.imgHideEye.setVisibility(View.VISIBLE);
                mBinding.imgShowEye.setVisibility(View.GONE);
                mBinding.etPwd.setTransformationMethod(PasswordTransformationMethod.getInstance());
            }
        });
    }

    private boolean checkValidForm(){
        if(mBinding.etFirstName.getText().toString().isEmpty()){
            showErrorMessage(mBinding.parent, getString(R.string.first_name_required));
            return false;
        }
//        if(mBinding.etLastName.getText().toString().isEmpty()){
//            showErrorMessage(mBinding.parent, getString(R.string.last_name_required));
//            return false;
//        }

        if(mBinding.etPhoneNumber.getText().toString().isEmpty()){
            showErrorMessage(mBinding.parent, getString(R.string.phone_number_required));
            return false;
        }

        if(mBinding.etPwd.getText().toString().isEmpty()){
            showErrorMessage(mBinding.parent, getString(R.string.pwd_required));
            return false;
        }

        if(mBinding.etConfirmPwd.getText().toString().isEmpty()){
            showErrorMessage(mBinding.parent, getString(R.string.confirm_pwd_required));
            return false;
        }

        if(!mBinding.etPwd.getText().toString().equals(mBinding.etConfirmPwd.getText().toString())){
            showErrorMessage(mBinding.parent, getString(R.string.pwd_not_matched));
            return false;
        }

        if(!mBinding.cbTerms.isChecked()){
            showErrorMessage(mBinding.parent, getString(R.string.must_agree_terms));
            return false;
        }

        return true;
    }

    private void callRegister(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Map params = new HashMap();
        params.put("mobile", mBinding.etPhoneNumber.getText().toString().trim());
        params.put("password", mBinding.etPwd.getText().toString().trim());
        params.put("firstName", mBinding.etFirstName.getText().toString().trim());
//        params.put("lastName", mBinding.etLastName.getText().toString().trim());
        String lang = LocaleHelper.getPersistedData(mActivity, "ar");
        params.put("language", lang);
        params.put("fcmToken", SavePref.getInstance(mActivity).getFirebaseKey());

        Call<JsonObject> call = apiInterface.createParent(params);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if(jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<UserModel>() {}.getType();
                            try{
                                UserModel userModel = gson.fromJson(jsonObject.get("data").getAsJsonObject(), type);
                                FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new OTPFragment(userModel), R.id.frameLayout);
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                } else {
                    Log.e(TAG, "response error: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
                Log.e(TAG, "response fail error: "+ t.getMessage());
            }
        });
    }

    private void callTeacherRegister(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Map params = new HashMap();
        params.put("mobile", mBinding.etPhoneNumber.getText().toString().trim());
        params.put("password", mBinding.etPwd.getText().toString().trim());
        params.put("firstName", mBinding.etFirstName.getText().toString().trim());
//        params.put("lastName", mBinding.etLastName.getText().toString().trim());
        String lang = LocaleHelper.getPersistedData(mActivity, "ar");
        params.put("language", lang);
        params.put("fcmToken", SavePref.getInstance(mActivity).getFirebaseKey());

        Call<JsonObject> call = apiInterface.createTeacher(params);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<TeacherModel>() {}.getType();
                            try{
                                TeacherModel teacherModel = gson.fromJson(jsonObject.get("data").getAsJsonObject(), type);
                                FragmentProcess.addFragmentWithAnimation(mActivity.getSupportFragmentManager(), new OTPFragment(teacherModel), R.id.frameLayout);
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }
                    }
                } else {
                    Log.e(TAG, "response error: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
                Log.e(TAG, "response fail error: "+ t.getMessage());
            }
        });
    }
}
