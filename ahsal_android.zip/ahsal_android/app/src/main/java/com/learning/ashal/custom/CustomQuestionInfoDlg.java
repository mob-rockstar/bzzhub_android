package com.learning.ashal.custom;

import android.app.Dialog;
import android.content.Context;
import android.view.View;

import com.learning.ashal.R;

public class CustomQuestionInfoDlg extends Dialog {

    private ItemClickInterface mItemClickInterface;
    private Context mContext;

    public CustomQuestionInfoDlg(Context paramContext, String question, ItemClickInterface itemClickInterface) {
        super(paramContext, R.style.dialog);

        setContentView(R.layout.dialog_question_info);
        mContext = paramContext;
        mItemClickInterface = itemClickInterface;

        CustomButton btNo = findViewById(R.id.btNo);
        CustomButton btYes = findViewById(R.id.btYes);
        CustomTextView txtDlgQuestion = findViewById(R.id.txtDlgQuestion);
        txtDlgQuestion.setText(question);
        btYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mItemClickInterface.onOK();
                disMissDialog();
            }
        });

        btNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                disMissDialog();
            }
        });

    }

    public CustomQuestionInfoDlg(Context paramContext, String question, String yesTitle, String noTitle, ItemClickInterface itemClickInterface) {
        super(paramContext, R.style.dialog);

        setContentView(R.layout.dialog_question_info);
        mContext = paramContext;
        mItemClickInterface = itemClickInterface;

        CustomButton btNo = findViewById(R.id.btNo);
        CustomButton btYes = findViewById(R.id.btYes);
        btYes.setText(yesTitle);
        btNo.setText(noTitle);
        CustomTextView txtDlgQuestion = findViewById(R.id.txtDlgQuestion);
        txtDlgQuestion.setText(question);
        btYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mItemClickInterface.onOK();
                disMissDialog();
            }
        });

        btNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                disMissDialog();
            }
        });

    }

    public void disMissDialog() {
        if (isShowing()) {
            dismiss();
        }
    }

    public void showDialog() {
        if (isShowing())
            dismiss();
        this.show();
    }

    public interface ItemClickInterface{
        void onOK();
    }
}
