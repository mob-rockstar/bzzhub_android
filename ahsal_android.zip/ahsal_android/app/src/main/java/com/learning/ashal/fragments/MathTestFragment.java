package com.learning.ashal.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.bumptech.glide.Glide;
import com.google.android.material.button.MaterialButton;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.learning.ashal.R;
import com.learning.ashal.activities.VimeoPlayActivity;
import com.learning.ashal.adapter.AnswerTestAdapter;
import com.learning.ashal.adapter.QuestionNoAdapter;
import com.learning.ashal.custom.CustomAlertDlg;
import com.learning.ashal.custom.CustomTextView;
import com.learning.ashal.databinding.FragmentMathTestBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.model.AnswerModel;
import com.learning.ashal.model.QuestionModel;
import com.learning.ashal.model.SelAnswerModel;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import static com.learning.ashal.utilities.Constants.BASE_URL;

public class MathTestFragment extends BaseFragment {

    private String TAG = MathTestFragment.class.getSimpleName();
    private FragmentMathTestBinding mBinding;
    private AnswerTestAdapter answerTestAdapter;
    private QuestionNoAdapter questionNoAdapter;
    private String lessonId;
    private List<QuestionModel> questionModelList;
    private String title;
    private SelAnswerModel[] selectedAnswer;

    public MathTestFragment(){

    }

    public MathTestFragment(String title, String id){
        lessonId = id;
        this.title = title;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_math_test, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }


    private void initView() {

        mBinding.txtSubject.setText(title);
        mBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.back();
            }
        });

        CustomTextView txtTitle = mBinding.getRoot().findViewById(R.id.txtTitle);
        txtTitle.setText(getString(R.string.next));

        MaterialButton btNext = mBinding.getRoot().findViewById(R.id.btNext);
        btNext.setBackgroundColor(getResources().getColor(R.color.colorQuestionBk));
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean isValid = false;
                if(pageNo >= questionModelList.size())
                    return;
                for(AnswerModel answerModel : questionModelList.get(pageNo).answerModelList){
                    if(answerModel.isSelected){
                        isValid = true;
                        break;
                    }
                }
                if(isValid){
                    pageNo = pageNo + 1;
                    setQuestion(pageNo);
                    if(questionModelList != null && pageNo == questionModelList.size() - 1){
                        txtTitle.setText(getString(R.string.submit));
                    }else if(questionModelList != null && pageNo >= questionModelList.size()){
//                        callSubmit();
                        FragmentProcess.replaceFragment(mActivity.getSupportFragmentManager(),
                                new MathTestResultFragment(title, questionModelList, selectedAnswer), R.id.frameLayout);

                    }else{
                        txtTitle.setText(getString(R.string.next));
                    }
                }else{
                    Toast.makeText(mActivity, getString(R.string.select_answer), Toast.LENGTH_SHORT).show();
                }
            }
        });

        answerTestAdapter = new AnswerTestAdapter(mActivity, new AnswerTestAdapter.OnItemClickListener() {
            @Override
            public void onClick(AnswerModel answerModel) {
//                if(answerModel.isCorrect.equals("1")){
//                    Toast.makeText(mActivity, getString(R.string.correct_answer_msg), Toast.LENGTH_SHORT).show();
//                }else{
//                    Toast.makeText(mActivity, getString(R.string.wrong_answer_msg), Toast.LENGTH_SHORT).show();
//                }
                selectedAnswer[pageNo].isCorrect = answerModel.isCorrect.equals("1");
                selectedAnswer[pageNo].isDrag = false;
                selectedAnswer[pageNo].answerModel = answerModel;
            }
        });

        questionNoAdapter = new QuestionNoAdapter(mActivity, new QuestionNoAdapter.OnItemClickListener() {
            @Override
            public void onClick(int no) {
                setQuestion(no);
            }
        });
        mBinding.rvQuestionNo.setLayoutManager(new LinearLayoutManager(mActivity, LinearLayoutManager.HORIZONTAL,false));
        mBinding.rvQuestionNo.setAdapter(questionNoAdapter);
        mBinding.rvTestAnswer.setAdapter(answerTestAdapter);

        callGetQuestionTestList();
    }

    private int pageNo;
    private void setQuestion(int no){
        if( no >= questionModelList.size())
            return;
        pageNo = no;
        QuestionModel questionModel = questionModelList.get(no);
        if(questionModel.type.equals("text")){
            mBinding.imgQuestion.setVisibility(View.GONE);
            mBinding.txtQuestion.setVisibility(View.VISIBLE);
            mBinding.txtQuestion.setText(questionModel.question);
        }else if(questionModel.type.equals("image")){
            mBinding.imgQuestion.setVisibility(View.VISIBLE);
            mBinding.txtQuestion.setVisibility(View.GONE);
            if(questionModel.file != null)
                Glide.with(mActivity).load(questionModel.file).into(mBinding.imgQuestion);
        }else if(questionModel.type.equals("video")){
            mBinding.imgQuestion.setVisibility(View.VISIBLE);
            mBinding.txtQuestion.setVisibility(View.GONE);
            if(questionModel.file != null)
                Glide.with(mActivity).load(questionModel.file).into(mBinding.imgQuestion);
        }

        mBinding.imgQuestion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(questionModel.type.equals("video")){
                    Intent intent = new Intent(mActivity, VimeoPlayActivity.class);
                    intent.putExtra("uri", questionModel.file);
                    startActivity(intent);
                }
            }
        });

        questionNoAdapter.setSelectedFlag(pageNo);
        answerTestAdapter.setData(questionModelList.get(no).answerModelList);
    }

    private void callGetQuestionTestList(){
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.questionTestList(lessonId);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<List<QuestionModel>>() {}.getType();
                            try{

                               questionModelList = gson.fromJson(jsonObject.get("data").getAsJsonArray(), type);
                                if(questionModelList != null && questionModelList.size() > 0){
                                    questionNoAdapter.setData(questionModelList.size());
                                    setQuestion(0);
                                    selectedAnswer = new SelAnswerModel[questionModelList.size()];
                                    for(int i = 0 ;i < questionModelList.size(); i++){
                                        selectedAnswer[i] = new SelAnswerModel();
                                    }
                                    mBinding.txtNoData.setVisibility(View.GONE);
                                    mBinding.scrollView.setVisibility(View.VISIBLE);
//                                    startTimer();
                                }else{
                                    questionNoAdapter.setData(0);
                                    mBinding.txtNoData.setVisibility(View.VISIBLE);
                                    mBinding.scrollView.setVisibility(View.GONE);
                                }
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }
            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    long statTime;
    private void startTimer(){
        statTime = System.currentTimeMillis();
    }

    private void callSubmit(){
        if(getStudentId() == null){
            Toast.makeText(mActivity, getString(R.string.select_default_student), Toast.LENGTH_SHORT).show();
            return;
        }
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Map params = new HashMap();
        params.put("lessonId", lessonId);
        params.put("totalQuestions", questionModelList.size());

        int answerCount = 0;
        for(int i = 0; i < selectedAnswer.length; i++){
            if(selectedAnswer[i].isCorrect){
                answerCount++;
            }
        }
        params.put("correctAnswers", String.valueOf(answerCount) );

        long diff = System.currentTimeMillis() - statTime;

        int difMiliSec = (int) (diff % 1000);
        int difSeconds = (int) (diff / 1000);
        int difMin = 0;
        int difHour = 0;
        if(difSeconds > 60){
            int temp = difSeconds;
            difSeconds = temp % 60;
            difMin = temp / 60;
        }
        if(difMin > 60){
            int temp = difMin;
            difMin = temp % 60;
            difHour = temp / 60;
        }
        String time = difHour > 0 ? difHour + "hour " + difMin + "min " + difSeconds + " sec" :
                difMin > 0 ? difMin + "min " + difSeconds + " sec" : difMiliSec > 0 ? difSeconds + " sec " + difMiliSec:
                        difMiliSec + "msec";

        params.put("examTime", time);
        params.put("studentId", getStudentId());

        Call<JsonObject> call = apiInterface.submitExamResult(params);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            mActivity.back();
                        }
                    }
                } else {
                    Log.e(TAG, "response error: "+ response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
                Log.e(TAG, "response fail error: "+ t.getMessage());
            }
        });
    }
}
