package com.learning.ashal.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.learning.ashal.R;
import com.learning.ashal.databinding.RowClassroomBinding;
import com.learning.ashal.databinding.RowFileBinding;
import com.learning.ashal.model.GroupModel;

import java.util.List;

public class ClassAdapter extends RecyclerView.Adapter<ClassAdapter.MyViewHolder> {

    private OnItemClickListener onItemClickListener;
    private List<GroupModel> groupModelList;
    private Context context;

    public ClassAdapter(Context context, OnItemClickListener onItemClickListener){
        this.context = context;
        this.onItemClickListener = onItemClickListener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowClassroomBinding binding = DataBindingUtil.inflate( LayoutInflater.from(parent.getContext()), R.layout.row_classroom, parent, false);
        return new MyViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {


    }

    public void setData(List<GroupModel> list){
        this.groupModelList = list;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if(groupModelList != null )
            return groupModelList.size();
        return 1;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private RowClassroomBinding binding;
        public MyViewHolder(RowClassroomBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public interface OnItemClickListener{
        void onClick(GroupModel groupModel);
    }
}
