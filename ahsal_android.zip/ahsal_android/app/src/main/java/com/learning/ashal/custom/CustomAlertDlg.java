package com.learning.ashal.custom;

import android.app.Dialog;
import android.content.Context;
import android.view.View;

import com.learning.ashal.R;

public class CustomAlertDlg extends Dialog {

    private ItemClickInterface mItemClickInterface;
    private Context mContext;

    public CustomAlertDlg(Context paramContext, String total, String correct, ItemClickInterface itemClickInterface) {
        super(paramContext, R.style.dialog);

        setContentView(R.layout.dialog_alert);
        mContext = paramContext;
        mItemClickInterface = itemClickInterface;

        CustomButton btOK = findViewById(R.id.btOK);
        CustomTextView txtCorrectAnswer = findViewById(R.id.txtCorrectAnswer);
        txtCorrectAnswer.setText(paramContext.getString(R.string.correct_answer, correct, total));
        btOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mItemClickInterface.onClick();
                disMissDialog();
            }
        });

    }

    public void disMissDialog() {
        if (isShowing()) {
            dismiss();
        }
    }

    public void showDialog() {
        if (isShowing())
            dismiss();
        this.show();
    }

    public interface ItemClickInterface{
        void onClick();
    }

}
