package com.learning.ashal.services;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.widget.Toast;

import com.google.android.gms.auth.api.phone.SmsRetriever;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.api.Status;
import com.learning.ashal.model.MessageEvent;

import org.greenrobot.eventbus.EventBus;

public class SmsBroadcastReceiver extends BroadcastReceiver {
//    public static final String SMS_BUNDLE = "pdus";
//
//    public void onReceive(Context context, Intent intent) {
//        Bundle intentExtras = intent.getExtras();
//        if (intentExtras != null) {
//            Object[] sms = (Object[]) intentExtras.get(SMS_BUNDLE);
////            String smsMessageStr = "";
////            for (int i = 0; i < sms.length; ++i) {
//                SmsMessage smsMessage = SmsMessage.createFromPdu((byte[]) sms[0]);
//
//                String smsBody = smsMessage.getMessageBody().toString();
//                String address = smsMessage.getOriginatingAddress();
//
////                smsMessageStr += "SMS From: " + address + "\n";
////                smsMessageStr += smsBody + "\n";
////            }
//
//            MessageEvent messageEvent = new MessageEvent();
//            messageEvent.messageType = MessageEvent.MessageType.READ_SMS;
//            messageEvent.sms = smsBody;
//            EventBus.getDefault().post(messageEvent);
//        }
//    }

    @Override
    public void onReceive(Context context, Intent intent) {

        if (SmsRetriever.SMS_RETRIEVED_ACTION.equals(intent.getAction())) {
            Bundle extras = intent.getExtras();
            Status status = (Status) extras.get(SmsRetriever.EXTRA_STATUS);

            switch(status.getStatusCode()) {
                case CommonStatusCodes.SUCCESS:
                    // Get SMS message contents
                    String message = (String) extras.get(SmsRetriever.EXTRA_SMS_MESSAGE);

                    MessageEvent messageEvent = new MessageEvent();
                    messageEvent.messageType = MessageEvent.MessageType.READ_SMS;
                    messageEvent.sms = message;
                    EventBus.getDefault().post(messageEvent);
                    // Extract one-time code from the message and complete verification
                    // by sending the code back to your server.
                    break;
                case CommonStatusCodes.TIMEOUT:
                    // Waiting for SMS timed out (5 minutes)
                    // Handle the error ...
                    break;
            }
        }
    }
}
