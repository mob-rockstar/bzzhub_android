package com.learning.ashal.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.learning.ashal.R;
import com.learning.ashal.databinding.RowFileBinding;
import com.learning.ashal.databinding.RowRelativeLessonBinding;
import com.learning.ashal.model.LessonModel;

import java.util.List;

public class RelativeLessonAdapter extends RecyclerView.Adapter<RelativeLessonAdapter.MyViewHolder> {

    private OnItemClickListener onItemClickListener;
    private List<LessonModel> lessonModelList;
    private Context context;

    public RelativeLessonAdapter(OnItemClickListener onItemClickListener, Context context){
        this.onItemClickListener = onItemClickListener;
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowRelativeLessonBinding binding = DataBindingUtil.inflate( LayoutInflater.from(parent.getContext()), R.layout.row_relative_lesson, parent, false);
        return new MyViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        LessonModel lessonModel = lessonModelList.get(position);
        holder.binding.row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onItemClickListener.onClick(lessonModel);
            }
        });

        Glide.with(context).load(lessonModel.cover).into(holder.binding.imgCover);
    }

    public void setData(List<LessonModel> list){
        this.lessonModelList = list;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if(lessonModelList != null )
            return lessonModelList.size();
        return 0;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private RowRelativeLessonBinding binding;
        public MyViewHolder(RowRelativeLessonBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public interface OnItemClickListener{
        void onClick(LessonModel lessonModel);
    }
}
