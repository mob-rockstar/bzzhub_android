package com.learning.ashal.fragments;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;

import com.google.android.material.button.MaterialButton;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.learning.ashal.R;
import com.learning.ashal.activities.MainActivity;
import com.learning.ashal.activities.PDFViewerActivity;
import com.learning.ashal.adapter.MathAdapter;
import com.learning.ashal.adapter.MathFileAdapter;
import com.learning.ashal.custom.CustomTextView;
import com.learning.ashal.custom.FileDescPopupWindow;
import com.learning.ashal.custom.QuestionPopupWindow;
import com.learning.ashal.databinding.FragmentMathBinding;
import com.learning.ashal.databinding.FragmentMathFileBinding;
import com.learning.ashal.interfaces.ApiInterface;
import com.learning.ashal.interfaces.QuestionCallbackListener;
import com.learning.ashal.model.FileModel;
import com.learning.ashal.model.LessonModel;
import com.learning.ashal.services.MediaDownloadService;
import com.learning.ashal.utilities.AnimationUtils;
import com.learning.ashal.utilities.FileOpen;
import com.learning.ashal.utilities.FragmentProcess;
import com.learning.ashal.utilities.LocaleHelper;
import com.learning.ashal.utilities.ProgressDialog;
import com.learning.ashal.utilities.RequestClient;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.learning.ashal.utilities.Constants.BASE_URL;

public class MathFileFragment extends BaseFragment {

    private String TAG = MathFileFragment.class.getSimpleName();
    private FragmentMathFileBinding mBinding;
    private MathFileAdapter mathFileAdapter;
    private String lessonId;
    private FileModel fileModel;
    private boolean viewSaved;
    private String title;
    private List<FileModel> fileModelList;

    public MathFileFragment(){

    }

    public MathFileFragment(String title, String id){
        this.title = title;
        lessonId = id;
    }

    public MathFileFragment(String title, String id, boolean viewSaved){
        lessonId = id;
        this.title = title;
        this.viewSaved =viewSaved;
    }


    @Override
    public void updateUI() {
//        mActivity.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
//        mActivity.setStatusBarColor(getResources().getColor(R.color.colorPrimary));
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_math_file, container, false);
        View view = mBinding.getRoot();
        initView();
        return view;
    }

    private void initView() {
        updateUI();
        mBinding.txtSubject.setText(title);
        mBinding.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mActivity.back();
            }
        });
        CustomTextView txtTitle = mBinding.getRoot().findViewById(R.id.txtTitle);
        txtTitle.setText(getString(R.string.course_chat));
        MaterialButton btNext = mBinding.getRoot().findViewById(R.id.btNext);
        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentProcess.addFragment(mActivity.getSupportFragmentManager(), new QuestionBankFragment(), R.id.frameLayout);
            }
        });

        mathFileAdapter = new MathFileAdapter(mActivity, viewSaved, new MathFileAdapter.OnItemClickListener() {
            @Override
            public void onClick(FileModel fileModel) {
                try{
                    String path = Environment.getExternalStorageDirectory() + "/ashal/"+ fileModel.title+"."+fileModel.extension;
                    File file = new File(path);
                    if(file.exists()){
                        Intent pdfIntent = new Intent(mActivity, PDFViewerActivity.class);
                        pdfIntent.putExtra("file", path);
                        mActivity.startActivity(pdfIntent);
//                        FileOpen.openFileFromLocal(mActivity, fileModel.file, file);
                    }else{
                        FileOpen.openFile(mActivity, fileModel.file);
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }

            @Override
            public void onDownload(FileModel file) {
                fileModel = file;

                String path = Environment.getExternalStorageDirectory() + "/ashal/"+ fileModel.title+"."+fileModel.extension;
                File f = new File(path);
                if(f.exists()){
                    Toast.makeText(mActivity, getResources().getString(R.string.already_downloaded), Toast.LENGTH_SHORT).show();
                    return;
                }
                if(checkAndRequestPermissions()){
                    Toast.makeText(mActivity, getResources().getString(R.string.downloading), Toast.LENGTH_SHORT).show();
                    downloadFile();
                }
            }

            @Override
            public void onSave(FileModel fileModel) {
                saveFile(fileModel);
            }

            @Override
            public void onUnSave(FileModel fileModel) {
                unSaveFile(fileModel);
            }
        });
        mBinding.rvMathFile.setAdapter(mathFileAdapter);

        mBinding.etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(mathFileAdapter!=null) {
                    mathFileAdapter.getFilter().filter(charSequence);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        if(viewSaved){
            callGetSavedFileList();
        }else{
            callGetFileList();
        }
    }

    private void downloadFile(){
        MediaDownloadService downloadService = new MediaDownloadService(fileModel.file, fileModel.title+"."+fileModel.extension,
                mActivity);
        downloadService.execute();
    }

    private FileDescPopupWindow popupWindow;
    private void openFileDetail(){
        View view = ((LayoutInflater)mActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.dialog_layout_file_desc, null);
        popupWindow = new FileDescPopupWindow(view, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.btCancel:
                        popupWindow.dismiss();
                        break;
                }
                popupWindow.dismiss();
            }
        }, mActivity);
        popupWindow.showAtLocation(mBinding.getRoot(), Gravity.CENTER, 0, 0);
    }

    private  boolean checkAndRequestPermissions() {
        int permissionReadStorage = ContextCompat.checkSelfPermission(mActivity, Manifest.permission.READ_EXTERNAL_STORAGE);
        int permissionWriteStorage = ContextCompat.checkSelfPermission(mActivity, android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
        List<String> listPermissionsNeeded = new ArrayList<>();
        if (permissionWriteStorage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }

        if (permissionReadStorage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }

        if (!listPermissionsNeeded.isEmpty()) {
            this.requestPermissions(listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), 1);
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            Map<String, Integer> perms = new HashMap<>();
            perms.put(Manifest.permission.WRITE_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
            perms.put(Manifest.permission.READ_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
            if (grantResults.length > 0) {
                for (int i = 0; i < permissions.length; i++)
                    perms.put(permissions[i], grantResults[i]);
                if (perms.get(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                        && perms.get(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                    downloadFile();
                }
            }
        }
    }

    private void callGetFileList(){
        if(getStudentId() == null){
            Toast.makeText(mActivity, getString(R.string.select_default_student), Toast.LENGTH_SHORT).show();
            return;
        }
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.fileList(lessonId, getStudentId());
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<List<FileModel>>() {}.getType();
                            try{
                                List<FileModel> fileModelList = gson.fromJson(jsonObject.get("data").getAsJsonArray(), type);
                                if(fileModelList != null && fileModelList.size() > 0){
                                    mathFileAdapter.setData(fileModelList);
                                    mBinding.llNoData.setVisibility(View.GONE);
                                    AnimationUtils.animateSlideTopFromDown(mActivity, mBinding.rvMathFile);
                                }else{
                                    mathFileAdapter.setData(null);
                                    mBinding.llNoData.setVisibility(View.VISIBLE);
                                }

                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private void callGetSavedFileList(){
        if(getStudentId() == null){
            Toast.makeText(mActivity, getString(R.string.select_default_student), Toast.LENGTH_SHORT).show();
            return;
        }
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.getSavedFiles(lessonId, getStudentId());
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            Gson gson = new Gson();
                            Type type = new TypeToken<List<FileModel>>() {}.getType();
                            try{
                                fileModelList = gson.fromJson(jsonObject.get("data").getAsJsonArray(), type);
                                if(fileModelList != null && fileModelList.size() > 0){
                                    mathFileAdapter.setData(fileModelList);
                                    mBinding.llNoData.setVisibility(View.GONE);
                                    AnimationUtils.animateSlideTopFromDown(mActivity, mBinding.rvMathFile);
                                }else{
                                    mathFileAdapter.setData(null);
                                    mBinding.llNoData.setVisibility(View.VISIBLE);
                                }
                            }catch (JsonSyntaxException ex){
                                ex.printStackTrace();
                            }
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private void saveFile(FileModel fileModel){
        if(getStudentId() == null){
            Toast.makeText(mActivity, getString(R.string.select_default_student), Toast.LENGTH_SHORT).show();
            return;
        }
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call = apiInterface.saveFile(fileModel.id, getStudentId());
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            fileModel.savedBefore = true;
                            mathFileAdapter.notifyDataSetChanged();
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }

    private void unSaveFile(FileModel fileModel){
        if(!viewSaved)
            if(getStudentId() == null){
                Toast.makeText(mActivity, getString(R.string.select_default_student), Toast.LENGTH_SHORT).show();
                return;
            }
        ProgressDialog.showProgress(mActivity);
        ApiInterface apiInterface = RequestClient.getClient(BASE_URL).create(ApiInterface.class);
        Call<JsonObject> call;
        if(viewSaved){
            call = apiInterface.unSaveFile(fileModel.savedFileId);
        }else{
            call = apiInterface.unSaveFileByFileId(getStudentId(), fileModel.id);
        }

        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                ProgressDialog.hideprogressbar();
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    JsonObject jsonObject = response.body().getAsJsonObject();
                    if (jsonObject != null && isAdded()) {
                        if (jsonObject.get("status").getAsBoolean()) {
                            if(viewSaved){
                                fileModelList.remove(fileModel);
                            }else{
                                fileModel.savedBefore = false;
                            }
                            mathFileAdapter.notifyDataSetChanged();
                        }else{
                             if(!jsonObject.get("message").isJsonNull())
                                showErrorMessage(mBinding.parent, jsonObject.get("message").getAsString());
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                ProgressDialog.hideprogressbar();
            }
        });
    }
}
