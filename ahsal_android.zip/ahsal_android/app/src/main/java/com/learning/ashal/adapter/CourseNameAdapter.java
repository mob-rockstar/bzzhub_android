package com.learning.ashal.adapter;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.CompoundButton;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;
import com.learning.ashal.R;
import com.learning.ashal.databinding.RowCourseNameListBinding;
import com.learning.ashal.model.SubjectModel;
import com.learning.ashal.utilities.LocaleHelper;
import java.util.List;

public class CourseNameAdapter extends RecyclerView.Adapter<CourseNameAdapter.MyViewHolder> {

    private OnItemClickListener onItemClickListener;
    private List<SubjectModel> subjectModelList;
    private Context context;
    private String lang;
    private Typeface font;

    public CourseNameAdapter(Context context, OnItemClickListener onItemClickListener){
        this.context = context;
        this.onItemClickListener = onItemClickListener;
        lang = LocaleHelper.getLanguage(context);
        String asset = context.getResources().getString(R.string.SFProDisplay_Regular);
        font = Typeface.createFromAsset(context.getAssets(), asset);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RowCourseNameListBinding binding = DataBindingUtil.inflate( LayoutInflater.from(parent.getContext()), R.layout.row_course_name_list, parent, false);
        return new MyViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        SubjectModel subjectModel = subjectModelList.get(position);

        holder.binding.radio.setOnCheckedChangeListener(null);
        if(subjectModel.isSelected){
            holder.binding.radio.setChecked(true);
        }else{
            holder.binding.radio.setChecked(false);
        }
       
        if(lang.equals("en")){
            holder.binding.radio.setText(subjectModel.englishName);
        }else{
            holder.binding.radio.setText(subjectModel.arabicName);
        }
        holder.binding.radio.setTypeface(font);

        holder.binding.radio.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                for(SubjectModel subjectModel1 : subjectModelList){
                    subjectModel1.isSelected = false;
                }
                subjectModel.isSelected = true;
                onItemClickListener.onClick(subjectModel);
                notifyDataSetChanged();
            }
        });

    }

    public void setData(List<SubjectModel> list){
        this.subjectModelList = list;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if(subjectModelList != null )
            return subjectModelList.size();
        return 0;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private RowCourseNameListBinding binding;
        public MyViewHolder(RowCourseNameListBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public interface OnItemClickListener{
        void onClick(SubjectModel subjectModel);
    }

}
