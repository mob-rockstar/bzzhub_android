package com.learning.ashal.utilities;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.learning.ashal.model.TeacherModel;
import com.learning.ashal.model.UserModel;


public class SavePref {
    public static final String Key_userdetail="usermodel";
    public static final String pref_name="learning";

    public static  SavePref mSavePref;
    private Context context;
    public SavePref(Context context){
        this.context = context;
    }

    public static SavePref getInstance(Context mcontext) {
        if(mSavePref==null){
            mSavePref=new SavePref(mcontext);
        }
        return mSavePref;
    }

    public void saveUserModel(UserModel userModel) {
        SharedPreferences sharedPref = context.getSharedPreferences(pref_name,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        Gson gson = new Gson();
        String userjson = gson.toJson(userModel);
        editor.putString(Key_userdetail, userjson);
        editor.apply();
    }

    public UserModel getUserModel() {
        SharedPreferences sharedPref = context.getSharedPreferences(pref_name,Context.MODE_PRIVATE);
        Gson gson = new Gson();
        UserModel userModel = gson.fromJson(sharedPref.getString(Key_userdetail,null), UserModel.class);
        return  userModel;
    }

    public void saveTeacherModel(TeacherModel teacherModel) {
        SharedPreferences sharedPref = context.getSharedPreferences(pref_name,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        Gson gson = new Gson();
        String userjson = gson.toJson(teacherModel);
        editor.putString("teachermodel", userjson);
        editor.apply();
    }

    public TeacherModel getTeacherModel() {
        SharedPreferences sharedPref = context.getSharedPreferences(pref_name,Context.MODE_PRIVATE);
        Gson gson = new Gson();
        TeacherModel teacherModel = gson.fromJson(sharedPref.getString("teachermodel",null), TeacherModel.class);
        return teacherModel;
    }

    public boolean isLoginTypeTeacher() {
        SharedPreferences sharedPref = context.getSharedPreferences(pref_name,Context.MODE_PRIVATE);
        return sharedPref.getBoolean("logintype",false);
    }

    public void setLoginTypeTeacher(boolean isTeacher) {
        SharedPreferences sharedPref = context.getSharedPreferences(pref_name,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putBoolean("logintype", isTeacher).apply();
    }

    public boolean isFirstRunning() {
        SharedPreferences sharedPref = context.getSharedPreferences(pref_name,Context.MODE_PRIVATE);
        return sharedPref.getBoolean("isFirst",true);
    }

    public void setFirstRunning(boolean isFirst) {
        SharedPreferences sharedPref = context.getSharedPreferences(pref_name,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putBoolean("isFirst", isFirst).apply();
    }

    public void setFirebaseKey(String key) {
        SharedPreferences sharedPref = context.getSharedPreferences(pref_name,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("firebaseKey", key).apply();
    }

    public String getFirebaseKey(){
        SharedPreferences sharedPref = context.getSharedPreferences(pref_name,Context.MODE_PRIVATE);
        return sharedPref.getString("firebaseKey","");
    }

    public void clearPref() {
        SharedPreferences sharedPref = context.getSharedPreferences(pref_name,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.clear();
        editor.apply();
    }

}
