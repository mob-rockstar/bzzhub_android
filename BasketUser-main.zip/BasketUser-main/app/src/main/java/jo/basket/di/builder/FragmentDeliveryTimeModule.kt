package jo.basket.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector
import jo.basket.ui.deliverypricing.alldelivery.AllDeliveryFragment
import jo.basket.ui.deliverypricing.storedelivery.StoreDeliveryFragment

@Module
abstract class FragmentDeliveryTimeModule {
    @ContributesAndroidInjector
    abstract fun contributeDeliveryInfoFragment(): StoreDeliveryFragment

    @ContributesAndroidInjector
    abstract fun contributeAllDeliveryFragment(): AllDeliveryFragment

}