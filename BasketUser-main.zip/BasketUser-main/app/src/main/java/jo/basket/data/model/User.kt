package jo.basket.data.model

import com.google.gson.annotations.SerializedName
import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import java.io.Serializable


open class User : RealmObject(), Serializable {
    @PrimaryKey
    @SerializedName("customer_id")
    var userId: Long = 0

    @SerializedName("token")
    var token: String? = null

    @SerializedName("email")
    var email: String? = null

    @SerializedName("first_name")
    var firstName: String? = null

    @SerializedName("last_name")
    var lastName: String? = null

    @SerializedName("facebook_id")
    var facebookId: String? = null

    @SerializedName("google_id")
    var googleId: String? = null

    @SerializedName("country_code")
    var countryCode: String? = null

    @SerializedName("mobile")
    var mobile: String? = null

    @SerializedName("country_id")
    var countryId: Int = 0

    @SerializedName("city_id")
    var cityId: Int = 0

    @SerializedName("location_id")
    var areaId: Int = 0

    @SerializedName("outlet_id")
    var storeId: Int = 0

    @SerializedName("code")
    var code: Int = 0

    @SerializedName("image")
    var imageUrl: String? = null

    @SerializedName("gender")
    var gender: String? = null

    @SerializedName("date_of_birth")
    var dateOfBirth: String? = null

    @SerializedName("is_mobile_verified")
    var mobileVerified: Int = 0

    @SerializedName("is_account_found")
    var accountFound: Int = 0

    @SerializedName("express_user_end_date")
    var expressUserEndDate: String? = null

    @SerializedName("profile_setup_step")
    var profileSetupStep: Int = 0
    var vendorId: Int? = null
    var latestOrderId: Int? = null
 //   var nextDeliveryTime: String? = null

    @SerializedName("language_id")
    var languageID: Int = 1

    @SerializedName("country_flag_url")
    var countryFlag: String = ""

    @SerializedName("currency_symbol")
    var currency: String = "JD"

    @SerializedName("country_name")
    var countryName: String = "Jordan"

    var socialType: Int = 0 // if 0 : Mobile, 1: google 2: facebook
    var userSelectedLatitude: Double = 0.0
    var userSelectedLongitude : Double = 0.0
}