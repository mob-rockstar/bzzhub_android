package jo.basket.ui.checkout.detail.address

import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import jo.basket.R
import jo.basket.data.model.Address
import jo.basket.databinding.RecyclerItemCheckoutAddressBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter

class CheckoutAddressAdapter :
    BaseRecyclerViewAdapter<Address, RecyclerItemCheckoutAddressBinding>() {

    var addressSelectedListener: OnAddressSelectedListener? = null
    var instruction: String = ""

    override val layoutId: Int
        get() = R.layout.recycler_item_checkout_address

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = createBindedView(viewGroup)
        return AddressViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as AddressViewHolder
        val context = holder.binding.root.context
        val item = items[position]

        with(holder) {
            // If selected, set Tint color green
            if (item.isSelected == 1) {
                if (item.available == 1) {
                    binding.ivAddressType.setImageDrawable(ContextCompat.getDrawable(context,
                        R.drawable.ic_radio_checked))
                    binding.layoutAdditionalOption.visibility = VISIBLE
                } else {
                    binding.ivAddressType.setImageDrawable(ContextCompat.getDrawable(context,
                        R.drawable.ic_radio))
                    binding.layoutAdditionalOption.visibility = GONE
                }
            } else {
                binding.ivAddressType.setImageDrawable(ContextCompat.getDrawable(context,
                    R.drawable.ic_radio))
                binding.layoutBackground.setBackgroundColor(ContextCompat.getColor(context,
                    R.color.md_white_1000))
                binding.layoutAdditionalOption.visibility = GONE
            }

            itemView.setOnClickListener {
                addressSelectedListener?.onAddressSelected(item, instruction)
            }

            binding.ivEdit.setOnClickListener {
                addressSelectedListener?.onEditAddress(item)
            }

            var alpha = 1.0f
            if (item.available != 1) {
                alpha = 0.27f
                binding.tvOutsideDeliveryAddress.visibility = VISIBLE
                itemView.isClickable = false
                itemView.isFocusable = false
                binding.layoutAdditionalOption.visibility = GONE
            } else {
                alpha = 1.0f
                binding.tvOutsideDeliveryAddress.visibility = GONE
                if (item.isSelected != 1) {
                    binding.layoutBackground.setBackgroundColor(ContextCompat.getColor(context,
                        R.color.md_white_1000))
                }
            }

            itemView.alpha = alpha
            binding.tvAddress.text = item.address
            binding.tvAddressType.text = item.addressType
        }
    }

    interface OnAddressSelectedListener {
        fun onAddressSelected(address: Address, instruction: String)
        fun onEditAddress(address: Address)
    }

    inner class AddressViewHolder(val binding: RecyclerItemCheckoutAddressBinding) :
        RecyclerView.ViewHolder(binding.root)
}