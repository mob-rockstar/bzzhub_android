package jo.basket.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector
import jo.basket.ui.language.ads.UserADSFragment

@Module
abstract class FragmentLanguageModule {
    @ContributesAndroidInjector
    abstract fun contributeUserADSFragment(): UserADSFragment
}