package jo.basket.data.model.currency


import com.google.gson.annotations.SerializedName

data class CurrencyData(
    @SerializedName("country_flag_url")
    var countryFlagUrl: String,
    @SerializedName("currency_symbol")
    var currencySymbol: String,
    var id: Int
)