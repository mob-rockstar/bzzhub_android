package jo.basket.ui.component.imagesnack

import android.content.Context
import android.util.AttributeSet
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import com.google.android.material.snackbar.ContentViewCallback
import jo.basket.R

class ImageSnackbarView (
    context: Context,
    attrs: AttributeSet? = null
) : ConstraintLayout(context, attrs), ContentViewCallback {

    lateinit var tvMsg: TextView
  //  lateinit var tvAction: TextView
    lateinit var layRoot: ConstraintLayout

    init {
        clipToPadding = false
    }

    override fun onFinishInflate() {
        super.onFinishInflate()
        this.tvMsg = findViewById(R.id.tv_message)
  //      this.tvAction = findViewById(R.id.tv_action)
        this.layRoot = findViewById(R.id.snack_constraint)
    }

    override fun animateContentIn(delay: Int, duration: Int) {
    }

    override fun animateContentOut(delay: Int, duration: Int) {
    }
}