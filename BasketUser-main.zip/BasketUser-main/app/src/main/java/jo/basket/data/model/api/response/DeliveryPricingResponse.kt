package jo.basket.data.model.api.response

import jo.basket.data.model.pricingmodel.PricingData

data class DeliveryPricingResponse(
    var `data`: List<PricingData>,
    var message: String,
    var status: Int
)