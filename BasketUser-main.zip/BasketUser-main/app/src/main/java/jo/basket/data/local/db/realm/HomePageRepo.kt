package jo.basket.data.local.db.realm

import jo.basket.data.model.NewHomePageData


class HomePageRepo : BaseRepo() {

    fun findAll(detached: Boolean = true): List<NewHomePageData> {
        val realmResults = realm.where(NewHomePageData::class.java).findAll()

        return if (detached) {
            realm.copyFromRealm(realmResults)
        } else {
            realmResults
        }
    }

    fun findInStore(storeId: Int, detached: Boolean = true): List<NewHomePageData> {
        val realmResults =
            realm.where(NewHomePageData::class.java).equalTo("store.id", storeId).findAll()

        return if (detached) {
            realm.copyFromRealm(realmResults)
        } else {
            realmResults
        }
    }

    fun getById(id: Int, detached: Boolean = true): NewHomePageData? {
        var realmHomePage: NewHomePageData? =
            realm.where(NewHomePageData::class.java).equalTo("id", id).findFirst()
        if (detached && realmHomePage != null) {
            realmHomePage = realm.copyFromRealm<NewHomePageData>(realmHomePage)
        }
        return realmHomePage
    }

    fun getByField(field: String?, value: String?, detached: Boolean = true): NewHomePageData? {
        var realmHomePage: NewHomePageData? =
            realm.where(NewHomePageData::class.java).equalTo(field, value).findFirst()
        if (detached && realmHomePage != null) {
            realmHomePage = realm.copyFromRealm<NewHomePageData>(realmHomePage)
        }
        return realmHomePage
    }

    fun save(homePage: NewHomePageData) {
        realm.executeTransaction { r -> r.copyToRealmOrUpdate(homePage) }
    }

    fun load(): NewHomePageData? {
        var realmHomePage: NewHomePageData? = realm.where(NewHomePageData::class.java).findFirst()
        if (realmHomePage != null) {
            realmHomePage = realm.copyFromRealm<NewHomePageData>(realmHomePage)
        }
        return realmHomePage
    }

    fun delete(realmHomePage: NewHomePageData) {
        if (realmHomePage.isValid) {
            realm.executeTransaction { realmHomePage.deleteFromRealm() }
        }
    }

    fun detach(homePage: NewHomePageData): NewHomePageData {
        return if (homePage.isManaged) {
            realm.copyFromRealm(homePage)
        } else {
            homePage
        }
    }
}