package jo.basket.ui.checkout.detail.placingorder

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import jo.basket.R
import jo.basket.data.model.Product
import jo.basket.databinding.RecyclerItemProductPlacingOrderBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter

// Adapter to handle Product List while placing an order
// Just need 5 product to be shown in Horizontal View
class PlacingOrderProductAdapter :
    BaseRecyclerViewAdapter<Product, RecyclerItemProductPlacingOrderBinding>() {

    override val layoutId: Int
        get() = R.layout.recycler_item_product_placing_order

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return PlacingOrderProductViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as PlacingOrderProductViewHolder
        if (items[position].productImage != null && items[position].productImage!!.isNotEmpty()) {
            Glide.with(holder.itemView.context).asBitmap().load(items[position].productImage).apply(
                RequestOptions().fitCenter().placeholder(R.drawable.placeholder300x300)
                    .error(R.drawable.placeholder300x300)
            ).into(holder.binding.iProduct)
        }
    }

    override fun getItemCount(): Int {
        return if (items.size > 5) 5 else items.size
    }

    inner class PlacingOrderProductViewHolder(val binding: RecyclerItemProductPlacingOrderBinding) :
        RecyclerView.ViewHolder(binding.root)
}