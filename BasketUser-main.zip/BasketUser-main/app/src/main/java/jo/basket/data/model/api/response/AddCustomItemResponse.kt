package jo.basket.data.model.api.response

import jo.basket.data.model.CustomItemIDData


data class AddCustomItemResponse(
    var customItemIDData: CustomItemIDData,
    var message: String,
    var status: Int
)