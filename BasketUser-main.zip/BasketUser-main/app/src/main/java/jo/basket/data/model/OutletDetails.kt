package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.realm.RealmObject
import io.realm.annotations.PrimaryKey


open class OutletDetails : RealmObject() {
    @PrimaryKey
    @SerializedName("outlet_id")
    @Expose
    var id: Int = 0

    @SerializedName("vendor_id")
    @Expose
    var vendorId: Int? = null

    @SerializedName("outlet_name")
    @Expose
    var outletName: String? = null

    @SerializedName("contact_phone")
    @Expose
    var contactPhone: String? = null

    @SerializedName("contact_email")
    @Expose
    var contactEmail: String? = null

    @SerializedName("contact_address")
    @Expose
    var contactAddress: String? = null

    @SerializedName("logo_image")
    @Expose
    var logoImage: String? = null

    @SerializedName("store_banner")
    @Expose
    var storeBanner: String? = null

    @SerializedName("item_price")
    @Expose
    var itemPrice: Int = 0

    @SerializedName("item_price_label")
    @Expose
    var itemPriceLabel: String? = null

    @SerializedName("created_date")
    @Expose
    var createdDate: String? = null

    @SerializedName("updated_date")
    @Expose
    var updatedDate: String? = null
}