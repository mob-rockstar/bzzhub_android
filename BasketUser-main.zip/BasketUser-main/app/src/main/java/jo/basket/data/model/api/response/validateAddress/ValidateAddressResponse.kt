package jo.basket.data.model.api.response.validateAddress

import com.google.gson.JsonElement
import com.google.gson.JsonNull
import com.google.gson.annotations.SerializedName

data class ValidateAddressResponse(
    @field:SerializedName("data")
    var data: JsonElement? = JsonNull(),
    var message: String,
    var status: Int
)



