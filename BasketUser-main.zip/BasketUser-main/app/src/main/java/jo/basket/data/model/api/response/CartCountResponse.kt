package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.Banner


class CartCountResponse {

    @field:SerializedName("httpCode")
    val code: Int = 0

    @field:SerializedName("Message")
    val message: String? = null

    @field:SerializedName("cart_count")
    var cartCount: Int = 0

    @field:SerializedName("scrolling_duration_seconds")
    var scrollingDuration: Int = 0

    @field:SerializedName("incentivizing_discount_basket_size")
    var incentiveDiscountSize: Double = 0.0

    @field:SerializedName("basket_amount")
    var basketAmount: Double = 0.0

    @field:SerializedName("banner_list")
    var bannerList: ArrayList<Banner> = ArrayList()
}