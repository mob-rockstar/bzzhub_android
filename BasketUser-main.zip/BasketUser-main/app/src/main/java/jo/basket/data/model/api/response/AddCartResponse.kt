package jo.basket.data.model.api.response


import com.google.gson.annotations.SerializedName
import jo.basket.data.model.LowInStockSuggestedItem

data class AddCartResponse(
    @SerializedName("cart_count")
    var cartCount: Int,
    @SerializedName("httpCode")
    var code: Int,
    @SerializedName("item_running_low")
    var itemRunningLow: Int?,
    @SerializedName("Message")
    var message: String,
    @SerializedName("suggested_item")
    var lowInStockSuggestedItem: List<LowInStockSuggestedItem>?,
    var type: Int,
    @SerializedName("unlock_free_delivery")
    var unlockFreeDelivery: String,
    @SerializedName("cart_outlets_id")
    var cartOutletId: Int = 0,
    @SerializedName("cart_outlets_item_id")
    var cartOutletItemId: Int = 0
)