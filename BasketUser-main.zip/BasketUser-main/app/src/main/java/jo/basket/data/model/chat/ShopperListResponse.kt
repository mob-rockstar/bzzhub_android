package jo.basket.data.model.chat


data class ShopperListResponse(
    var users: List<Shopper>
)