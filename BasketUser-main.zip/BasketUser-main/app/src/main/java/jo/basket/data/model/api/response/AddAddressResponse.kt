package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName


class AddAddressResponse {

    @field:SerializedName("httpCode")
    val code: Int = 0

    @field:SerializedName("Message")
    val message: String? = null

    @SerializedName("address_id")
    var addressId: Int? = null

    @SerializedName("city_id")
    var cityId: Int? = null

    @SerializedName("location_id")
    var locationId: Int? = null

    @SerializedName("location_name")
    var locationName: String? = null

    @SerializedName("city_name")
    var cityName: String? = null

    @SerializedName("country_name")
    var countryName: String? = null
}