package jo.basket.data.model

import com.google.gson.annotations.SerializedName


class UserSelectedPaymentMethod {

    @field:SerializedName("type")
    val type: Int = -1

    @field:SerializedName("name")
    val name: String? = null

    @field:SerializedName("payment_mode")
    val paymentMode: Int? = null

    @field:SerializedName("available")
    val available: Int? = null

    @field:SerializedName("payment_id")
    val paymentId: Int? = null

    @field:SerializedName("card_id")
    val cardId: Int? = null

    @field:SerializedName("card_number")
    val cardNumber: String? = null

    @field:SerializedName("payment_option")
    val paymentOption: String? = null

    @field:SerializedName("card_holder_name")
    val cardHolderName: String? = null

    @field:SerializedName("card_label")
    val cardLabel: String? = null

    @field:SerializedName("token_name")
    val tokenName: String? = null

    @field:SerializedName("default_status")
    val defaultStatus: Int? = null

    @field:SerializedName("created_date")
    val createdDate: String? = null

}