package jo.basket.data.model.orderreceipt


import com.google.gson.annotations.SerializedName

open class ReceiptProduct {

    @SerializedName("item_type")
    var itemType: Int? = null

    @SerializedName("department_name")
    var departmentName: String? = null

    @SerializedName("outlet_item_id")
    var outletItemId: Int? = null

    @SerializedName("product_name")
    var productName: String? = null

    @SerializedName("product_image")
    var productImage: String? = null

    @SerializedName("product_info_image")
    var productInfoImage: String? = null

    @SerializedName("sold_per")
    var soldPer: Int? = null

    @SerializedName("sold_per_label")
    var soldPerLabel: String? = null

    @SerializedName("label_value")
    var labelValue: String? = null

    @SerializedName("size_label")
    var sizeLabel: Int? = null

    @SerializedName("each_suffix")
    var eachSuffix: Int? = null

    @SerializedName("actual_approx_weight")
    var actualApproxWeight: Double? = null

    @SerializedName("actual_selling_price")
    var actualSellingPrice: Double? = null

    @SerializedName("actual_item_unit_price")
    var actualItemUnitPrice: Double? = null

    @SerializedName("item_unit_price_org")
    var itemUnitPriceOrg: Double? = null

    @SerializedName("unit")
    var unit: String? = null

    @SerializedName("actual_qty")
    var actualQty: Double? = null

    @SerializedName("actual_item_total")
    var actualItemTotal: Float? = null

    @SerializedName("customer_item_notes")
    var customerItemNotes: String? = null

    @SerializedName("promo_item")
    var promoItem: Int? = null

    @SerializedName("items")
    var items: List<ReceiptItem>? = null

    @SerializedName("old_outlet_item_id")
    var oldOutletItemId: Int? = null

    @SerializedName("old_product_name")
    var oldProductName: String? = null

    @SerializedName("old_product_image")
    var oldProductImage: String? = null

    @SerializedName("old_product_info_image")
    var oldProductInfoImage: String? = null

    @SerializedName("old_sold_per")
    var oldSoldPer: Int? = null

    @SerializedName("old_sold_per_label")
    var oldSoldPerLabel: String? = null

    @SerializedName("old_label_value")
    var oldLabelValue: String? = null

    @SerializedName("old_size_label")
    var oldSizeLabel: Int? = null

    @SerializedName("old_each_suffix")
    var oldEachSuffix: Int? = null

    @SerializedName("old_actual_approx_weight")
    var oldActualApproxWeight: Double? = null

    @SerializedName("old_actual_selling_price")
    var oldActualSellingPrice: Double? = null

    @SerializedName("old_actual_item_unit_price")
    var oldActualItemUnitPrice: Double? = null

    @SerializedName("old_item_unit_price_org")
    var oldItemUnitPriceOrg: Double? = null

    @SerializedName("old_unit")
    var oldUnit: String? = null

    @SerializedName("old_actual_qty")
    var oldActualQty: Double? = null

    @SerializedName("old_actual_item_total")
    var oldActualItemTotal: Double? = null

    @SerializedName("old_customer_item_notes")
    var oldCustomerItemNotes: String? = null

}