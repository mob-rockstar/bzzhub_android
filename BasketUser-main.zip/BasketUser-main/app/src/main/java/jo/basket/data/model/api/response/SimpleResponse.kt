package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName

open class SimpleResponse {

    @field:SerializedName("httpCode")
    val code: Int = 0

    @field:SerializedName("Message")
    val message: String? = null

    @field:SerializedName("message")
    val message2: String? = null

    @field:SerializedName("Error")
    val error: String? = null

    @field:SerializedName("status")
    val status: Int = 0

    @SerializedName("country_flag_url")
    var countryFlag: String = ""

    @SerializedName("currency_symbol")
    var currency: String = "JD"

    @SerializedName("order_id")
    var orderId: Int? = 0

    @SerializedName("order_outlet_id")
    var orderOutletId: Int? = 0

}