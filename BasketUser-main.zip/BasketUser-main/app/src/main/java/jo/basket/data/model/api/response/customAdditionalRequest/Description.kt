package jo.basket.data.model.api.response.customAdditionalRequest

data class Description(
    val lang: String,
    val text: String
)