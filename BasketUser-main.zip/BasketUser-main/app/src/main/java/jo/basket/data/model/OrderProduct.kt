package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


open class OrderProduct {

    @SerializedName("item_type")
    @Expose
    var itemType: Int? = null

    @SerializedName("orders_outlets_items_id")
    @Expose
    var ordersOutletsItemsId: Int? = null

    @SerializedName("outlet_item_id")
    @Expose
    var outletItemId: Int? = null

    @SerializedName("product_name")
    @Expose
    var productName: String? = null

    @SerializedName("department_id")
    @Expose
    var departmentId: Int? = null

    @SerializedName("department_url")
    @Expose
    var departmentUrl: String? = null

    @SerializedName("department_name")
    @Expose
    var departmentName: String? = null

    @SerializedName("aisle_id")
    @Expose
    var aisleId: Int? = null

    @SerializedName("aisle_name")
    @Expose
    var aisleName: String? = null

    @SerializedName("aisle_url_key")
    @Expose
    var aisleUrlKey: String? = null

    @SerializedName("original_price")
    @Expose
    var originalPrice: Double? = null

    @SerializedName("tax_included")
    @Expose
    var taxIncluded: Int? = null

    @SerializedName("product_image")
    @Expose
    var productImage: String? = null

    @SerializedName("product_info_image")
    @Expose
    var productInfoImage: String? = null

    @SerializedName("item_status")
    @Expose
    var itemStatus: String? = null

    @SerializedName("sold_per")
    @Expose
    var soldPer: Int? = null

    @SerializedName("sold_per_label")
    @Expose
    var soldPerLabel: String? = null

    @SerializedName("label_value")
    @Expose
    var labelValue: String? = null

    @SerializedName("size_label")
    @Expose
    var sizeLabel: Int? = null

    @SerializedName("approx_weight")
    @Expose
    var approxWeight: Double? = null

    @SerializedName("each_suffix")
    @Expose
    var eachSuffix: Int? = null

    @SerializedName("our_selling_price")
    @Expose
    var ourSellingPrice: Double? = null

    @SerializedName("unit")
    @Expose
    var unit: String? = null

    @SerializedName("cart_qty")
    @Expose
    var cartQty: Double? = null

    @SerializedName("cart_notes")
    @Expose
    var cartNotes: String? = null

    @SerializedName("item_unit_price_org")
    @Expose
    var itemUnitPriceOrg: Double? = null

    @SerializedName("old_outlet_item_id")
    @Expose
    var oldOutletItemId: Int? = null

    @SerializedName("old_product_name")
    @Expose
    var oldProductName: String? = null

    @SerializedName("old_our_selling_price")
    @Expose
    var oldOurSellingPrice: Double? = null

    @SerializedName("old_product_image")
    @Expose
    var oldProductImage: String? = null

    @SerializedName("old_product_info_image")
    @Expose
    var oldProductInfoImage: String? = null

    @SerializedName("old_bar_code")
    @Expose
    var oldBarCode: String? = null

    @SerializedName("old_sold_per")
    @Expose
    var oldSoldPer: Int? = null

    @SerializedName("old_sold_per_label")
    @Expose
    var oldSoldPerLabel: String? = null

    @SerializedName("old_size_label")
    @Expose
    var oldSizeLabel: Int? = null

    @SerializedName("old_unit")
    @Expose
    var oldUnit: String? = null

    @SerializedName("old_label_value")
    @Expose
    var oldLabelValue: String? = null

    @SerializedName("old_each_suffix")
    @Expose
    var oldEachSuffix: Int? = null

    @SerializedName("old_approx_weight")
    @Expose
    var oldApproxWeight: Double? = null

    @SerializedName("old_cart_qty")
    @Expose
    var oldCartQty: Double? = null

    @SerializedName("customer_suggestion_type")
    @Expose
    var customerSuggestionType: Int? = null

    @SerializedName("customer_suggestion_id")
    @Expose
    var customerSuggestionId: Int? = null

    @SerializedName("customer_suggestion_product_name")
    @Expose
    var customerSuggestionProductName: String? = null

    @SerializedName("additional_questions_answers")
    @Expose
    var additionalQuestionAnswers: String? = null

    var addComplainComment: String? = null

}