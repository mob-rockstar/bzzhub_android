package jo.basket.data.model

import com.google.gson.annotations.SerializedName

class PopupDetails {

    @field:SerializedName("id")
    var id: Int? = 0

    @field:SerializedName("title_label")
    var title: String? = ""

    @field:SerializedName("description_label")
    var description: String? = ""

    @field:SerializedName("button_label")
    var buttonLabel: String? = ""

    @field:SerializedName("image")
    var image: String? = ""

    @field:SerializedName("updated_date")
    var updatedDate: String? = ""

}