package jo.basket.data.model.api.response


import jo.basket.data.model.SplashADSData

data class SplashADSResponse(
    var `data`: List<SplashADSData>,
    var message: String
)