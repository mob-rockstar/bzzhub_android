package jo.basket.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector
import jo.basket.ui.checkout.CheckoutMapFragment
import jo.basket.ui.checkout.deliverytime.DeliverySlotFragment
import jo.basket.ui.checkout.detail.CheckoutDetailFragment
import jo.basket.ui.checkout.detail.WaitFoodOrderFragment
import jo.basket.ui.checkout.promocode.PromoCodeFragment



@Module
abstract class FragmentCheckoutModule {

    @ContributesAndroidInjector
    abstract fun contributeCheckoutDetailNewFragment(): CheckoutDetailFragment

    @ContributesAndroidInjector
    abstract fun contributeDeliverySlotFragment(): DeliverySlotFragment

    @ContributesAndroidInjector
    abstract fun contributePromoCodeFragment(): PromoCodeFragment

    @ContributesAndroidInjector
    abstract fun contributeCheckoutMapFragment(): CheckoutMapFragment

    @ContributesAndroidInjector
    abstract fun contributeWaitFoodOrderFragment(): WaitFoodOrderFragment
}