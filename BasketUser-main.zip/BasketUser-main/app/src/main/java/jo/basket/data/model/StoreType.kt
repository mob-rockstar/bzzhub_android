package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.realm.RealmObject
import io.realm.RealmResults
import io.realm.annotations.LinkingObjects
import io.realm.annotations.PrimaryKey

open class StoreType : RealmObject() {
    @LinkingObjects("types")
    val stores: RealmResults<Store>? = null

    @PrimaryKey
    @SerializedName("id")
    @Expose
    var id: Int = 0

    @SerializedName("name")
    @Expose
    var name: String? = null

    @SerializedName("banner_image")
    @Expose
    var bannerImage: String? = null

    @SerializedName("sort_order")
    @Expose
    var sortOrder: Int = 0
}