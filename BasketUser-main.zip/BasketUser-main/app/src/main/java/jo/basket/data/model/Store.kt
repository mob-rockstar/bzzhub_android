package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.realm.RealmList
import io.realm.RealmObject
import io.realm.RealmResults
import io.realm.annotations.LinkingObjects
import io.realm.annotations.PrimaryKey


open class Store : RealmObject() {
    @LinkingObjects("stores")
    val area: RealmResults<Area>? = null

    var departments: RealmList<Department> = RealmList<Department>()

    var homePages: RealmList<NewHomePageData> = RealmList<NewHomePageData>()

    var promotions: RealmList<PromotionData> = RealmList<PromotionData>()

    @PrimaryKey
    @SerializedName("outlet_id")
    @Expose
    var id: Int = 0

    @SerializedName("store_type")
    @Expose
    var types: RealmList<StoreType>? = null

    @SerializedName("logo_image")
    @Expose
    var logoImage: String? = null

    @SerializedName("store_banner")
    @Expose
    var storeBanner: String? = null

    @SerializedName("created_date")
    @Expose
    var createdDate: String? = null

    @SerializedName("updated_date")
    @Expose
    var updatedDate: String? = null

    @SerializedName("outlet_name")
    @Expose
    var outletName: String? = null

    @SerializedName("display_name")
    @Expose
    var displayName: String? = null

    @SerializedName("vendor_name")
    @Expose
    var vendorName: String? = null

    @SerializedName("vendor_id")
    @Expose
    var vendorId: Int = 0

    @SerializedName("is_grid_view")
    @Expose
    var isGridView: Int = 0


    @SerializedName("item_price")
    @Expose
    var itemPrice = 0

    @SerializedName("online_payment")
    @Expose
    var onlinePayment = 0

    @SerializedName("item_price_label")
    @Expose
    var itemPriceLabel: String? = null

    @SerializedName("is_new")
    @Expose
    var isNew: Int = 0

    @SerializedName("is_featured")
    @Expose
    var isFeatured: Int = 0

    @SerializedName("fee_per_additional_km")
    @Expose
    var feePerAdditionalKm: Double? = null

    @SerializedName("delivery_fee")
    @Expose
    var deliveryFee: Double = 0.0

    @SerializedName("include_km")
    @Expose
    var includeKm: String? = ""

    @SerializedName("shopping_fee")
    @Expose
    var shoppingFee: Double? = null

    @SerializedName("now_delivery_slot")
    @Expose
    var deliverySlot: String? = null

    @SerializedName("store_disabled")
    @Expose
    var storeDisabled: Int? = 0

    @SerializedName("disabled_message")
    @Expose
    var disabledMessage: String = ""

    @SerializedName("service_fee")
    @Expose
    var serviceFee: Double = 0.0

    @SerializedName("service_type_id")
    @Expose
    var serviceTypeId: Int? = 0

    @SerializedName("store_to_customer_distance")
    @Expose
    var storeToCustomerDistance: String = ""

    @SerializedName("estimated_order_time")
    @Expose
    var estimatedOrderTime: String = ""

    @SerializedName("store_opening_status")
    @Expose
    var storeOpeningStatus: String = ""

    @SerializedName("is_incentivizing_users")
    @Expose
    var isIncentivizingUsers: Int? = 0

    @SerializedName("store_closing_time")
    @Expose
    var storeClosingTime: String = ""

    @SerializedName("outlet_design_view")
    @Expose
    var outletDesignView:  Int? = 0


    @SerializedName("store_opening_time")
    @Expose
    var storeOpeningTime: String = ""

    var express = if (serviceTypeId == 1) 1 else 0

}
