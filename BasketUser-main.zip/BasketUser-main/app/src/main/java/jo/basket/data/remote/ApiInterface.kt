package jo.basket.data.remote

import com.google.gson.JsonObject
import io.reactivex.Single
import jo.basket.BuildConfig
import jo.basket.data.model.CreditCardResponse
import jo.basket.data.model.WalletHistoryResponse
import jo.basket.data.model.api.ServerResponse
import jo.basket.data.model.api.response.*
import jo.basket.data.model.api.response.base.BaseResponse
import jo.basket.data.model.api.response.NormalSignUpResponse
import jo.basket.data.model.api.response.newstoreaislelist.NewStoreAisleListResponse
import jo.basket.data.model.api.response.service.ServiceListResponse
import jo.basket.data.model.api.response.validateAddress.ValidateAddressResponse
import jo.basket.data.model.currency.CurrencyResponse
import jo.basket.data.model.payfort.PayRequestBody
import jo.basket.data.model.payfort.PayResponseBody
import jo.basket.data.model.payfort.TokenRequestBody
import jo.basket.data.model.payfort.TokenResponse
import jo.basket.data.model.payment.PaymentListResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.http.*


interface ApiInterface {


    @POST("maintenance-details")
    fun maintenanceDetails(): Single<ServerResponse<MaintenanceResponse>>

    @FormUrlEncoded
    @POST("check-app-version")
    fun checkVersion(
        @Field("device") device: String?,
        @Field("version_number") versionNumber: String?,
        @Field("build_number") buildNumber: Int?,
        @Field("app_id") appId: String?
    ): Single<ServerResponse<AppVersionResponse>>

    @FormUrlEncoded
    @POST("cms-details")
    fun getCmsDetail(
        @Field("language") langCode: Int?,
        @Field("cms_url") cmsUrl: String
    ): Single<ServerResponse<CmsResponse>>

    @FormUrlEncoded
    @POST("check-user-free-delivery")
    fun checkFreeDelivery(
        @Field("language") langCode: Int?,
        @Field("token") token: String,
        @Field("user_id") customerId: Long
    ): Single<ServerResponse<FreeDeliveryResponse>>

    @FormUrlEncoded
    @POST("unlike-user-free-delivery-settings")
    fun disableFreeDeliveryPopup(
        @Field("language") langCode: Int?,
        @Field("token") token: String,
        @Field("user_id") customerId: Long
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("customer/verify_mobile")
    fun verifyMobile(
        @Field("language") langCode: Int?,
        @Field("platform") platform: String?,
        @Field("country_code") countryCode: String?,
        @Field("mobile") mobile: String?,
        @Field("device_id") deviceId: String?,
        @Field("device_token") deviceToken: String?,
        @Field("save_token") save_token: Int?,
        ): Single<VerifyMobileResponse>

    @FormUrlEncoded
    @POST("customer/verify_otp")
    fun verifyOtp(
        @Field("language") langCode: Int?,
        @Field("customer_id") customerId: Long,
        @Field("otp") otp: String?,
        @Field("device_id") deviceId: String?,
        @Field("device_token") deviceToken: String?
    ): Single<LoginResponse>

    @FormUrlEncoded
    @POST("customer/social-login-with-otp")
    fun getSocialOTP(
        @Field("language") langCode: Int?,
        @Field("customer_id") customerId: Long,
    ): Single<VerifyMobileResponse>

    @FormUrlEncoded
    @POST("customer/login_with_password")
    fun loginWithPassword(
        @Field("language") langCode: Int?,
        @Field("customer_id") customerId: Long,
        @Field("password") password: String
    ): Single<LoginResponse>

    @FormUrlEncoded
    @POST("customer/update_name")
    fun updateCustomerName(
        @Field("language") langCode: Int?,
        @Field("customer_id") customerId: Long,
        @Field("first_name") firstName: String,
        @Field("last_name") lastName: String
    ): Single<LoginResponse>

    @FormUrlEncoded
    @POST("customer/update_email")
    fun updateCustomerEmailAndPassword(
        @Field("language") langCode: Int?,
        @Field("customer_id") customerId: Long,
        @Field("email") email: String,
        @Field("password") password: String
    ): Single<LoginResponse>

    @FormUrlEncoded
    @POST("customer/update_gender")
    fun updateCustomerGender(
        @Field("language") langCode: Int?,
        @Field("customer_id") customerId: Long,
        @Field("gender") gender: String
    ): Single<LoginResponse>

    @FormUrlEncoded
    @POST("customer/update_dob")
    fun updateCustomerBirthday(
        @Field("language") langCode: Int?,
        @Field("customer_id") customerId: Long,
        @Field("date_of_month") dateOfBirth: String
    ): Single<LoginResponse>

    @FormUrlEncoded
    @POST("customer/normal-signup")
    fun customerRegularSignUp(
        @Field("language") langCode: Int?,
        @Field("customer_id") customerId: Long,
        @Field("first_name") firstName: String,
        @Field("last_name") lastName: String,
        @Field("email") email: String,
        @Field("password") password: String
    ): Single<NormalSignUpResponse>

    @FormUrlEncoded
    @POST("customer/change_forgot_password")
    fun changePassword(
        @Field("language") langCode: Int?,
        @Field("customer_id") customerId: Long,
        @Field("password") password: String
    ): Single<LoginResponse>

    @FormUrlEncoded
    @POST("customer/social_login")
    fun loginWithSocial(
        @Field("language") langCode: Int?,
        @Field("social_type") socialType: String,
        @Field("social_id") socialId: String?,
        @Field("platform") platform: String?,
        @Field("device_id") deviceId: String?,
        @Field("device_token") deviceToken: String?
    ): Single<LoginResponse>

    @FormUrlEncoded
    @POST("customer/social_signup")
    fun signupWithSocial(
        @Field("language") langCode: Int?,
        @Field("social_signup_type") socialType: String,
        @Field("social_id") socialId: String?,
        @Field("first_name") firstName: String,
        @Field("last_name") lastName: String,
        @Field("country_code") countryCode: String,
        @Field("mobile") mobile: String,
        @Field("email") email: String,
        @Field("date_of_birth") birthday: String,
        @Field("gender") gender: String,
        @Field("platform") platform: String?,
        @Field("device_id") deviceId: String,
        @Field("device_token") deviceToken: String?
    ): Single<LoginResponse>

    @FormUrlEncoded
    @POST("customer/app-news")
    fun getAppNews(
        @Field("language_id") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String
    ): Single<AppNewsResponse>

    @FormUrlEncoded
    @POST("update_device_information")
    fun updateFcmToken(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("device_token") deviceToken: String
    ): Single<LoginResponse>

    @FormUrlEncoded
    @POST("update-user-location")
    fun updateUserLocation(
        @Field("language") langCode: Int?,
        @Field("token") token: String,
        @Field("user_id") customerId: Long,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int,
        @Field("location_id") areaId: Int
    ): Single<ServerResponse<BaseResponse>>

    @FormUrlEncoded
    @POST("get-currency-details")
    fun getCurrencyCode(
        @Field("language") langCode: Int?,
        @Field("country_id") countryId: Int
    ): Single<CurrencyResponse>

    @GET
    fun callGoogleAPI(@Url url: String): Single<JsonObject>

    @FormUrlEncoded
    @POST("user-logout")
    fun logout(
        @Field("language") langCode: Int?,
        @Field("token") token: String,
        @Field("user_id") customerId: Long,
        @Field("device_token") fcmToken: String
    ): Single<ServerResponse<BaseResponse>>

    @FormUrlEncoded
    @POST("customer/country-city-list")
    fun getCountryCityList(
        @Field("customer_id") customerId: Long,
        @Field("language") langCode: Int?,
        @Field("token") token: String
    ): Single<CountryCityResponse>

    @FormUrlEncoded
    @POST("city-list")
    fun getCities(
        @Field("language") langCode: Int?,
        @Field("token") token: String
    ): Single<ServerResponse<CityResponse>>

    @FormUrlEncoded
    @POST("customer/city-areas-list")
    fun getCityAreaList(
        @Field("customer_id") customerId: Long,
        @Field("language") langCode: Int?,
        @Field("token") token: String,
        @Field("country_id") countryId: Int
    ): Single<CityAreaListResponse>

    @FormUrlEncoded
    @POST("location-list")
    fun getAreas(
        @Field("language") langCode: Int?,
        @Field("token") token: String,
        @Field("city_id") cityId: Int
    ): Single<ServerResponse<AreaResponse>>

    @FormUrlEncoded
    @POST("updated-store-list")
    fun getStores(
        @Field("language") langCode: Int?,
        @Field("user_id") customerId: Long,
        @Field("token") token: String,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int,
        @Field("location_id") areaId: Int,
        @Field("store_type_ids") storeType: Int,
        @Field("latitude") latitude: String,
        @Field("longitude") longitude: String,
        @Field("service_type_id") serviceTypeId: Int,
    ):Single<ServerResponse<StoreResponse>>

    @FormUrlEncoded
    @POST("store-list")
    fun getOldStores(
        @Field("language") langCode: Int?,
        @Field("user_id") customerId: Long,
        @Field("token") token: String,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int,
        @Field("location_id") areaId: Int,
        @Field("store_type_ids") storeType: Int,
        @Field("latitude") latitude: String,
        @Field("longitude") longitude: String,
    ):Single<ServerResponse<StoreResponse>>

    @FormUrlEncoded
    @POST("get-services")
    fun getServiceList(
        @Field("language") langCode: Int?,
        @Field("user_id") customerId: Long,
        @Field("token") token: String,
        @Field("latitude") latitude: String,
        @Field("longitude") longitude: String,
        @Field("platform") platform: String
    ):Single<ServiceListResponse>
    @FormUrlEncoded
    @POST("search-product-event-click")
    fun searchProductEventClick(
        @Field("language") langCode: Int?,
        @Field("token") token: String,
        @Field("user_id") userId: Long,
        @Field("query_id") queryId: String,
        @Field("object_ids[]") objectIds: ArrayList<String>,
        @Field("positions[]") positions: ArrayList<Int>
    ): Single<SimpleResponse>

    @FormUrlEncoded
    @POST("search-product-event-conversion")
    fun searchProductEventConversion(
        @Field("language") langCode: Int?,
        @Field("token") token: String,
        @Field("user_id") userId: Long,
        @Field("event_name") eventName: String,
        @Field("object_ids[]") objectIds: ArrayList<String>,
        @Field("query_id") queryId: String
    ): Single<SimpleResponse>

    @FormUrlEncoded
    @POST("pickup-unavailable")
    fun getPickUpServiceAvailability(
        @Field("language") langCode: Int?,
        @Field("customer_id") userId: Long,
        @Field("token") token: String
    ): Single<PickupServiceAvailabilityResponse>

    @FormUrlEncoded
    @POST("update-demand-on-pickup-location")
    fun updatePickUpServiceDemand(
        @Field("language") langCode: Int?,
        @Field("customer_id") userId: Long,
        @Field("token") token: String,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int,
        @Field("location_id") areaId: Int,
        @Field("latitude") latitude: Double,
        @Field("longitude") longitude: Double
    ): Single<PickupServiceAvailabilityResponse>

    @FormUrlEncoded
    @POST("customer/update_last_active_store")
    fun updateUserSelectedStore(
        @Field("language") langCode: Int?,
        @Field("customer_id") userId: Long,
        @Field("token") token: String,
        @Field("store_id") storeId: Int
    ): Single<SimpleResponse>

    @FormUrlEncoded
    @POST("store-department-list")
    fun getStoreDepartments(
        @Field("language") langCode: Int?,
        @Field("customer_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_id") storeId: Int
    ): Single<ServerResponse<StoreDepartmentResponse>>

    @FormUrlEncoded
    @POST("store-home-page-list")
    fun getStoreHomePages(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_id") storeId: Int,
        @Field("is_department_needed") requireDepartment: Int
    ): Single<ServerResponse<StoreHomePageResponse>>

    @FormUrlEncoded
    @POST("new-store-home-page-list")
    fun getNewStoreHomePages(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_id") storeId: Int,
        @Field("is_department_needed") requireDepartment: Int,
        @Field("vendor_id") vendorId: Int,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int,
    ): Single<NewStoreHomePageResponse>

    @FormUrlEncoded
    @POST("customer/outlet_pricing_and_delivery_info")
    fun getOutletPricingDeliveryInfo(
        @Field("language") languageId: Int?,
        @Field("customer_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_id") storeId: Int,
        @Field("city_id") cityId: Int,
        @Field("country_id") countryId: Int
    ): Single<DeliveryPricingResponse>

    @FormUrlEncoded
    @POST("user-my-items")
    fun getOrderedProducts(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_id") storeId: Int,
        @Field("search") search: String,
    ): Single<ServerResponse<OrderedProductsResponse>>

    @FormUrlEncoded
    @POST("store-aisle-list")
    fun getDepartmentCategories(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_id") storeId: Int,
        @Field("department_id") departmentId: Int,
        @Field("vendor_id") vendorId: Int,
        @Field("section_type_id") sectionTypeId: Int
    ): Single<ServerResponse<StoreCategoryResponse>>

    @FormUrlEncoded
    @POST("new-store-aisle-list")
    fun getNewDepartmentCategories(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_id") storeId: Int,
        @Field("department_id") departmentId: Int,
        @Field("department_type") departmentType: String,
        @Field("aisle_id") aisleId: Int,
        @Field("offset") offset: Int,
        @Field("count") count: Int
    ): Single<NewStoreAisleListResponse>

    @FormUrlEncoded
    @POST("store-product-list")
    fun getCategoryProducts(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_id") storeId: Int,
        @Field("department_id") departmentId: Int,
        @Field("aisle_id") categoryId: Int,
        @Field("section_type_id") sectionTypeId: Int
    ): Single<ServerResponse<StoreProductsResponse>>

    @FormUrlEncoded
    @POST("favorite-items-list")
    fun getFavoriteProducts(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_id") storeId: Int
    ): Single<ServerResponse<StoreProductsResponse>>

    @FormUrlEncoded
    @POST("store-free-delivery-promotion-items")
    fun getPromotionProducts(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_id") storeId: Int,
        @Field("promotion_id") promotionId: Int
    ): Single<ServerResponse<PromotionProductsResponse>>

    @FormUrlEncoded
    @POST("featured-items-list")
    fun getFeaturedProducts(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_id") storeId: Int
    ): Single<ServerResponse<StoreProductsResponse>>

    @FormUrlEncoded
    @POST("ramadan-items-list")
    fun getRamadanProducts(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_id") storeId: Int
    ): Single<ServerResponse<StoreProductsResponse>>

    @FormUrlEncoded
    @POST("add-cart")
    fun addToCart(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_id") storeId: Int,
        @Field("outlet_item_id") productId: Int,
        @Field("notes") note: String?,
        @Field("quantity") amount: Double,
        @Field("vendor_id") vendorId: Int,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int,
        @Field("cart_detail_id") cartDetailId: Int,
        @Field("custom_additional_questions") customItemString: String,
        @Field("show_product_detail") showProductDetail: Int
    ): Single<ServerResponse<AddCartResponse>>

    @FormUrlEncoded
    @POST("customer/replace-item-cart")
    fun replaceLowInStockItem(
        @Field("language") langCode: Int?,
        @Field("customer_id") userId: Long,
        @Field("token") token: String,
        @Field("cart_outlets_id") cartsOutletsId: Int,
        @Field("cart_outlet_item_id") cartsOutletItemId: Int,
        @Field("customer_suggestion_type") customerSuggestionType: Int,
        @Field("customer_suggestion_item_id") customerSuggestionTypeId: Int,
        @Field("shopper_instruction_note") note: String
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("customer/cart_replacement_suggestion")
    fun getLowRunningSuggestionList(
        @Field("language") languageId: Int?,
        @Field("customer_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_id") outletId: Int,  // Here outlet_id is OrderOutletID, need to be changed after discuss
        @Field("product_search") productSearch: String,
        @Field("outlet_item_id") outletItemId: Int,
        @Field("offset") offset: Int,
        @Field("count") count: Int,
        @Field("is_from_search") isFromSearch: Int
    ): Single<LowInStockSuggestionListResponse>

    @FormUrlEncoded
    @POST("add-custom-item-to-cart")
    fun addCustomItemToCart(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_id") storeId: Int,
        @Field("cart_detail_id") cartDetailId: Int,
        @Field("notes") note: String?,
        @Field("quantity") amount: Double,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("add-to-favorite")
    fun addToFavorite(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_item_id") productId: Int
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("delete-from-favorite")
    fun removeFromFavorite(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_item_id") productId: Int
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("add-note")
    fun addNote(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("cart_outlets_items_id") outletItemId: Int,
        @Field("note") note: String
    ): Single<ServerResponse<SimpleResponse>>

    @Multipart
    @POST("add-custom-item-to-cart")
    fun addCustomItemToCart(
        @Part("language") langCode: RequestBody?,
        @Part("user_id") userId: RequestBody?,
        @Part("token") token: RequestBody?,
        @Part("outlet_id") outletId: RequestBody?,
        @Part("product_name") productName: RequestBody?,
        @Part("product_sold_type") productUnit: RequestBody?,
        @Part("quantity") qty: RequestBody?,
        @Part("product_price") price: RequestBody?,
        @Part("notes") instruction: RequestBody?,
        @Part("department_id") departmentId: RequestBody?,
        @Part product_image: MultipartBody.Part?
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("store-products")
    fun getProductHints(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_id") storeId: Int,
        @Field("product_search") search: String
    ): Single<ServerResponse<ProductHintsResponse>>

    @FormUrlEncoded
    @POST("search-product-suggestions")
    fun getProductSuggestionHintList(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("query") search: String,
        @Field("outlet_id") storeId: Int
    ): Single<ServerResponse<HintSuggestionResponse>>

    @FormUrlEncoded
    @POST("clear-user-search")
    fun clearSearchHistory(
        @Field("language") langCode: Int?,
        @Field("customer_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_id") storeId: Int
    ): Single<SimpleResponse>

    @FormUrlEncoded
    @POST("search-product-other-outlet")
    fun searchStores(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("city_id") cityId: Int,
        @Field("location_id") locationId: Int,
        @Field("outlet_id") storeId: Int,
        @Field("product_search") search: String
    ): Single<ServerResponse<StoreResponse>>

    @FormUrlEncoded
    @POST("search-product-new")
    fun searchProducts(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_id") storeId: Int,
        @Field("product_search") search: String,
        @Field("offset") offset: Int,
        @Field("count") count: Int,
        @Field("service_id") service_id: Int,
        @Field("order_by") order_by: Int

    ): Single<ServerResponse<SearchProductsResponse>>

    @FormUrlEncoded
    @POST("user-cart-list")
    fun getMyCart(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int,
        @Field("location_id") locationId: Int,
        @Field("outlet_id") storeId: Int
    ): Single<ServerResponse<MyCartResponse>>

    @FormUrlEncoded
    @POST("user-cart-store-details")
    fun getStoreAllMyCart(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int,
        @Field("location_id") locationId: Int,
        @Field("service_type_id") serviceId: String
    ): Single<StoreMyCartResponse>

    @FormUrlEncoded
    @POST("user-cart-count")
    fun getCartCount(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int,
        @Field("outlet_id") storeId: Int
    ): Single<ServerResponse<CartCountResponse>>

    @FormUrlEncoded
    @POST("delete-all-user-cart")
    fun removeCart(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_id") storeId: Int
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("delete-user-cart")
    fun removeProductFromCart(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("cart_detail_id") cartDetailID: Int
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("add-multiple-item-to-order")
    fun addCartItemsToOrder(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_id") storeId: Int,
        @Field("orders_outlets_id") orderStoreId: Int
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("checkout-details")
    fun getCheckoutDetail(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int,
        @Field("location_id") locationId: Int,
        @Field("outlet_id") storeId: Int,
        @Field("is_from") isFrom: String,
//        @Field("cart_id") cartId: String,
    ): Single<ServerResponse<CheckoutResponse>>

    @FormUrlEncoded
    @POST("cart-outlet-delivery-slot")
    fun getDeliverySlots(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int,
        @Field("outlet_id") outletID: Int
    ): Single<ServerResponse<DeliverySlotsResponse>>

    @FormUrlEncoded
    @POST("update-delivery-instruction")
    fun updateDeliveryInstruction(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("delivery_instructions") instruction: String
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("customer/online-order")
    fun payToOrder(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int,
        @Field("payment_gateway_id") paymentId: Int,
        @Field("card_id") cardId: Int,
        @Field("delivery_instructions") instruction: String,
        @Field("security_code") cvv: String,
        @Field("currency_code") currencyCode: String,
        @Field("order_type") orderType: Int,
        @Field("user_type") userType: Int,
        @Field("outlet_id") outletID: Int,
        @Field("adjust_identifier_type") adjustIDType: String,
        @Field("adjust_identifier_value") adjustIDValue: String,
        @Field("adjust_adid") adjustADID : String,
        @Field("shopper_tip_amount") shopperTipAmount: Float
    //    @Field("is_latest_app") isLatestApp: Int
    ): Single<ServerResponse<OnlinePaymentResponse>>

    @FormUrlEncoded
    @POST("customer/capture-online-order-payment")
    fun captureOnlinePayment(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("currency_code") currencyCode: String,
        @Field("card_id") cardId: Int,
        @Field("order_id") orderId: Int,
        @Field("order_outlet_id") orderStoreId: Int,

    ): Single<PayByCardResponse>

    @FormUrlEncoded
    @POST("order/forexpress/capacity")
    fun expressCapacity(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_id") outletID: Int
    ): Single<SimpleResponse>

    @FormUrlEncoded
    @POST("update-payment-method-for-order")
    fun updatePaymentMethodForOrder(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("card_id") cardId: Int,
        @Field("order_id") orderId: Int,
        @Field("order_outlet_id") orderOutletId: Int,
        @Field("payment_gateway_id") paymentGatewayId: Int
    ): Single<PayByCardResponse>

    @FormUrlEncoded
    @POST("offline-payment")
    fun offlinePayment(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int,
        @Field("payment_gateway_id") paymentId: Int,
        @Field("delivery_instructions") instruction: String,
        @Field("currency_code") currencyCode: String,
        @Field("order_type") orderType: Int,
        @Field("user_type") userType: Int,
        @Field("device_token") fcmToken: String,
        @Field("device_id") deviceId: String,
        @Field("platform") platform: String,
        @Field("outlet_id") outletID: Int,
        @Field("adjust_identifier_type") adjustIDType: String,
        @Field("adjust_identifier_value") adjustIDValue: String,
        @Field("adjust_adid") adjustADID : String
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("update-delivery-address")
    fun updateDeliveryAddress(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("address_id") addressId: Int
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("update-delivery-slot")
    fun updateDeliverySlot(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int,
        @Field("outlet_id") storeId: Int,
        @Field("delivery_date") deliveryDay: String,
        @Field("delivery_slot_time_id") deliverySlotTimeId: Int,
        @Field("delivery_time") deliveryTime: String
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("add-promo-code-from-cart")
    fun addPromoCodeToCart(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("city_id") cityId: Int,
        @Field("promo_code") promoCode: String,
        @Field("outlet_id") storeId: Int
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("remove-promo-code-from-cart")
    fun removePromoFromCart(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("payment-method-list")
    fun getPaymentMethods(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("page_id") pageId: Int
    ): Single<ServerResponse<PaymentMethodsResponse>>

    @FormUrlEncoded
    @POST("new-payment-method-list")
    fun getPaymentListNew(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int,
        @Field("page_id") pageId: Int
    ): Single<PaymentListResponse>

    @FormUrlEncoded
    @POST("update-user-selected-method")
    fun updatePaymentMethod(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("payment_id") paymentId: Int,
        @Field("card_id") cardId: Int?,
        @Field("outlet_id") outletId: Int
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("store-user-card")
    fun addUserCard(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("card_number") cardNumber: String,
        @Field("merchant_reference") merchantReference: String,
        @Field("token_name") tokenName: String,
        @Field("card_holder_name") cardHolderName: String,
        @Field("payment_option") paymentOption: String,
        @Field("response_code") responseCode: String,
        @Field("response_message") responseMessage: String,
        @Field("expiry_date") expiryDate: String,
        @Field("service_command") serviceCommand: String,
        @Field("fort_id") fortId: String,
        @Field("sdk_token") sdkToken: String,
        @Field("platform") userType: Int,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int,
        @Field("page_id") pageId: Int,
        @Field("outlet_id") storeId: Int ?= null,
        @Field("selected_payment_method_id") selectedPaymentMethodId: Int ?= null
    ): Single<ServerResponse<CreditCardResponse>>

    @FormUrlEncoded
    @POST("delete-card")
    fun deleteCreditCard(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("card_id") cardID: Int
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("new-my-order")
    fun getOrderHistory(
        @Field("language") langCode: Int?,
        @Field("customer_id") userId: Long,
        @Field("token") token: String,
        @Field("offset") offset: Int,
        @Field("count") count: Int,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int,
        @Field("filter_type") filterType: Int
    ): Single<OrderResponseNew>

    @FormUrlEncoded
    @POST("customer/add_all_items_to_cart")
    fun addAllOrderItemsToCart(
        @Field("language") langCode: Int?,
        @Field("customer_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_id") storeId: Int,
        @Field("order_outlet_id") orderStoreId: Int
    ): Single<SimpleStatusResponse>

    @FormUrlEncoded
    @POST("order-detail")
    fun getOrderDetail(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("order_id") orderId: Int,
        @Field("order_outlet_id") orderStoreId: Int
    ): Single<ServerResponse<OrderDetailResponse>>

    @FormUrlEncoded
    @POST("cart-outlet-delivery-slot-order")
    fun getOrderDeliverySlots(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int,
        @Field("outlet_id") storeId: Int,
        @Field("orders_outlets_id") orderStoreId: Int
    ): Single<ServerResponse<DeliverySlotsResponse>>

    @FormUrlEncoded
    @POST("update-delivery-slot-order")
    fun updateOrderDeliverySlot(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int,
        @Field("outlet_id") storeId: Int,
        @Field("orders_outlets_id") orderStoreId: Int,
        @Field("delivery_date") deliveryDay: String,
        @Field("delivery_slot_time_id") deliverySlotTimeId: Int,
        @Field("delivery_time") deliveryTime: String
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("add-item-to-order")
    fun addToOrder(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("notes") note: String,
        @Field("outlet_id") storeId: Int,
        @Field("orders_outlets_id") orderStoreId: Int,
        @Field("outlet_item_id") productId: Int,
        @Field("quantity") amount: Double
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("order-history-info")
    fun getCompleteOrderDetail(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("orders_outlets_id") orderStoreId: Int
    ): Single<ServerResponse<CompleteOrderDetailResponse>>

    @FormUrlEncoded
    @POST("outlet-ordered-detail")
    fun getStoreOrderDetail(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("orders_outlets_id") orderStoreId: Int
    ): Single<ServerResponse<StoreOrderDetailResponse>>

    @FormUrlEncoded
    @POST("product-detail")
    fun getProductDetail(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_id") storeId: Int,
        @Field("outlet_item_id") productId: Int,
        @Field("cart_outlet_item_id") cartDetailId   : Int,
        @Field("show_product_detail") showProductDetail: Int,
    ): Single<ServerResponse<ProductResponse>>

    @FormUrlEncoded
    @POST("customer/get_order_real_shopping_items_list")
    fun getShoppingItems(
        @Field("language") langCode: Int?,
        @Field("customer_id") userId: Long,
        @Field("token") token: String,
        @Field("orders_outlet_id") orderStoreId: Int
    ): Single<ShoppingItemsResponse>

    @FormUrlEncoded
    @POST("customer/update_customer_suggestion_to_item")
    fun replaceItemWithCustomerSuggestionDetail(
        @Field("language") langCode: Int?,
        @Field("customer_id") userId: Long,
        @Field("token") token: String,
        @Field("order_outlet_id") orderStoreId: Int,
        @Field("order_item_id") productId: Int,
        @Field("suggestion_type") suggestionType: Int,
        @Field("suggestion_item_id") suggestionProductId: Int,
        @Field("item_qty") amount: Double?,
        @Field("suggestion_from") suggestionFrom: Int?,
        @Field("note") note: String
    ): Single<SimpleUpdateResponse>

    @FormUrlEncoded
    @POST("customer/new_approve_review_order_item")
    fun approveReplaceOrderItem(
        @Field("language") langCode: Int?,
        @Field("customer_id") userId: Long,
        @Field("token") token: String,
        @Field("order_outlet_id") orderStoreId: Int,
        @Field("order_item_id") productId: Int,
        @Field("approve_type") approveType: Int,
        @Field("reqeust_from") requestFrom : Int,
        @Field("replace_item_id") replaceItemId : Int,
    ): Single<SimpleStatusResponse>


    @FormUrlEncoded
    @POST("customer/add-secondary-mobile")
    fun addSecondaryMobile(
        @Field("customer_id") userId: Long,
        @Field("token") token: String,
        @Field("mobile_number") mobileNumber: String,
    ): Single<AddSecondaryMobile>


    @FormUrlEncoded
    @POST("customer/verify-secondary-mobile")
    fun verifySecondaryMobile(
        @Field("customer_id") userId: Long,
        @Field("token") token: String,
        @Field("otp") otp: String,
        @Field("mobile_number") mobileNumber: String,
    ): Single<VerifyMobileResponse>

    @FormUrlEncoded
    @POST("rating-details")
    fun getLastOrderRatings(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("orders_outlets_id") orderStoreId: Int
    ): Single<ServerResponse<OrderRatingsResponse>>

    @FormUrlEncoded
    @POST("view-rating")
    fun getOrderRatings(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("orders_outlets_id") orderStoreId: Int
    ): Single<ServerResponse<OrderRatingsResponse>>

    @FormUrlEncoded
    @POST("rate-order")
    fun rateOrder(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("orders_outlets_id") orderStoreId: Int,
        @Field("shopping_rating") shopperRating: Float,
        @Field("delivery_rating") driverRating: Float,
        @Field("rating_comments") comments: String,
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("skip-order-rating")
    fun skipOrderRating(
        @Field("language") langCode: Int?,
        @Field("customer_id") userId: Long,
        @Field("token") token: String,
        @Field("order_outlet_id") orderStoreId: Int
    ): Single<SimpleResponse>

    @FormUrlEncoded
    @POST("get-cancel-reasons")
    fun getCancelOrderReasonList(
        @Field("language") languageId: Int?,
        @Field("customer_id") userId: Long,
        @Field("token") token: String,
        @Field("page_type") pageType: Int
    ): Single<CancelReasonListResponse>

    @FormUrlEncoded
    @POST("customer-cancel-order-outlet")
    fun cancelOrder(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("orders_outlets_id") orderStoreId: Int,
        @Field("cancel_reason_id") cancelReasonId: Int,
        @Field("order_cancel_reason_comment") cancelReasonComment: String
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("notification-list")
    fun getNotificationList(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String
    ): Single<ServerResponse<NotificationResponse>>

    @FormUrlEncoded
    @POST("update-all-read-notification")
    fun readAllNotifications(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("delete-all-notification")
    fun removeAllNotifications(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("update-read-notification")
    fun readNotification(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("notification_id") notificationID: Int?
    ): Single<ServerResponse<SimpleResponse>>

    @GET("contact-settings")
    fun getSupportInformation(): Single<ServerResponse<ContactInfoResponse>>

    @FormUrlEncoded
    @POST("update-profile")
    fun updateProfile(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("first_name") firstNam: String,
        @Field("last_name") lastName: String,
        @Field("email") email: String,
        @Field("mobile") mobile: String,
        @Field("gender") gender: String
    ): Single<ServerResponse<ProfileResponse>>

    @FormUrlEncoded
    @POST("remove-profile-image")
    fun removeProfileImage(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
    ): Single<SimpleResponse>

    @Multipart
    @POST("update-profile-image")
    fun updateProfileImage(
        @Part("language") langCode: RequestBody?,
        @Part("user_id") userId: RequestBody?,
        @Part("token") token: RequestBody?,
        @Part profile_image: MultipartBody.Part?
    ): Single<ProfileImageResponse>

    @FormUrlEncoded
    @POST("change-pwd-forgot")
    fun changePassword(
        @Field("language") langCode: Int?,
        @Field("mobile") mobile: String,
        @Field("token") token: String,
        @Field("password") password: String,
        @Field("password_confirmation") confirmPassword: String
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("cms-list")
    fun getAppInfo(@Field("language") langCode: Int?): Single<ServerResponse<AboutAppResponse>>

    @FormUrlEncoded
    @POST("address-type-list")
    fun getAddressTypes(@Field("language") langCode: Int?): Single<ServerResponse<AddressTypeResponse>>

    @FormUrlEncoded
    @POST("add-address")
    fun addAddress(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int?,
        @Field("location_id") locationId: Int?,
        @Field("latitude") lat: Double,
        @Field("longtitude") lng: Double,
        @Field("address_type") addressType: Int,
        @Field("address") address: String?,
        @Field("department_building") departmentBuilding: String?,
        @Field("additional_info") additionalInfo: String?,
        @Field("is_latest_app") isLatestApp: Int,
    ): Single<ServerResponse<AddAddressResponse>>

    @FormUrlEncoded
    @POST("validate-address")
    fun validateAddress(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("latitude") lat: Double,
        @Field("longitude") lng: Double,
    ): Single<ValidateAddressResponse>

    @FormUrlEncoded
    @POST("update-address")
    fun updateAddress(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("address_id") addressId: Int,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int,
        @Field("location_id") locationId: Int,
        @Field("latitude") lat: Double,
        @Field("longtitude") lng: Double,
        @Field("address_type") addressType: Int,
        @Field("address") address: String?,
        @Field("department_building") departmentBuilding: String?,
        @Field("near_landmark") nearLandmark: String?,
        @Field("additional_info") additionalInfo: String?,
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("delete-address")
    fun deleteAddress(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("address_id") addressId: Int
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("user-notification-settings-details")
    fun getNotificationSettings(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String
    ): Single<ServerResponse<NotificationSettingResponse>>

    @FormUrlEncoded
    @POST("update-user-notification-settings")
    fun updateNotificationSettings(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("order_update_push_notification") enablePush: Int,
        @Field("order_update_sms") updateSMS: Int,
        @Field("order_update_call_before_checkout") enableCall: Int,
        @Field("promo_marketing_email") promoEmail: Int,
        @Field("promo_marketing_push_notification") promoNotification: Int,
        @Field("promo_marketing_sms") promoSMS: Int
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("country-list")
    fun getCountryList(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String
    ): Single<ServerResponse<CountrySettingResponse>>

    @FormUrlEncoded
    @POST("customer/update_customer_country")
    fun updateCountrySetting(
        @Field("language") langCode: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("country_id") countryId: Int
    ): Single<SimpleUpdateResponse>


    @GET("language-list")
    fun getLanguageList(): Single<ServerResponse<LanguageListResponse>>

    @FormUrlEncoded
    @POST("customer/update_customer_language")
    fun updateLanguageSetting(
        @Field("language_id") languageId: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String
    ): Single<SimpleUpdateResponse>

    @FormUrlEncoded
    @POST("user-vendor-loyalty-card-list")
    fun getLoyaltyCardList(
        @Field("language_id") languageId: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("country_id") countryID: Int?,
        @Field("city_id") cityID: Int?
    ): Single<ServerResponse<LoyaltyCardListResponse>>

    @FormUrlEncoded
    @POST("add-user-loyalty-card")
    fun addLoyaltyCard(
        @Field("language_id") languageId: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("country_id") countryID: Int?,
        @Field("city_id") cityID: Int?,
        @Field("vendor_id") vendorId: Int?,
        @Field("loyalty_card_number") cardNumber: String
    ): Single<SimpleUpdateResponse>

    @FormUrlEncoded
    @POST("update-user-loyalty-card")
    fun updateLoyaltyCard(
        @Field("language_id") languageId: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("country_id") countryID: Int?,
        @Field("city_id") cityID: Int?,
        @Field("vendor_id") vendorId: Int?,
        @Field("loyalty_card_number") cardNumber: String,
        @Field("user_loyalty_card_id") loyaltyCardID: Int?
    ): Single<SimpleUpdateResponse>

    @FormUrlEncoded
    @POST("delete-user-loyalty-card")
    fun removeLoyaltyCard(
        @Field("language_id") languageId: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("user_loyalty_card_id") loyaltyCardID: Int?
    ): Single<SimpleUpdateResponse>

    @FormUrlEncoded
    @POST("list-promo-code-account")
    fun getPromoCodes(
        @Field("language_id") languageId: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String
    ): Single<ServerResponse<PromoCodeResponse>>

    @FormUrlEncoded
    @POST("add-promo-code-account")
    fun addPromoCodeToAccount(
        @Field("language_id") languageId: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("promo_code") promoCode: String
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("remove-promo-code-account")
    fun removePromoCodeFromAccount(
        @Field("language_id") languageId: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("promo_id") promoId: Int
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("user_orders_count")
    fun getOpenedOrderCount(
        @Field("language_id") languageId: Int?,
        @Field("customer_id") userId: Long,
        @Field("token") token: String
    ): Single<OpenedOrderCountResponse>

    @FormUrlEncoded
    @POST("customer/order_receipt")
    fun getOrderReceipt(
        @Field("language") languageId: Int?,
        @Field("customer_id") userId: Long,
        @Field("token") token: String,
        @Field("order_id") orderId: Int
    ): Single<ReceiptResponse>

    @FormUrlEncoded
    @POST("customer/order/store-receipt")
    fun getStoreReceipt(
        @Field("language") languageId: Int?,
        @Field("customer_id") userId: Long,
        @Field("token") token: String,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int,
        @Field("order_outlet_id") orderStoreId: Int
    ): Single<StoreReceiptResponse>

    @FormUrlEncoded
    @POST("customer/replacement_suggestion")
    fun getReplacementSuggestionList(
        @Field("language") languageId: Int?,
        @Field("customer_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_id") orderStoreId: Int,  // Here outlet_id is OrderOutletID, need to be changed after discuss
        @Field("product_search") productSearch: String,
        @Field("order_item_id") orderItemId: Int,
        @Field("offset") offset: Int,
        @Field("count") count: Int,
        @Field("is_from_search") isFromSearch: Int
    ): Single<ReplacementSuggestionResponse>

    @FormUrlEncoded
    @POST("customer/get-service-app-token")
    fun getSocketToken(
        @Field("language") languageId: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String
    ): Single<SocketTokenResponse>

    @FormUrlEncoded
    @POST("customer/membership-details")
    fun getUserMembershipDetail(
        @Field("language") languageId: Int?,
        @Field("customer_id") userId: Long,
        @Field("token") token: String,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int
    ): Single<UserMembershipDetailResponse>

    @FormUrlEncoded
    @POST("membership-list")
    fun getMembershipList(
        @Field("language") languageId: Int?,
        @Field("country_id") countryId: Int,
        @Field("token") token: String,
        @Field("city_id") cityId: Int
    ): Single<ServerResponse<MembershipListResponse>>

    @FormUrlEncoded
    @POST("mobile-express-checkout")
    fun checkoutExpress(
        @Field("language") languageId: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("card_id") cardId: Int,
        @Field("membership_id") membershipId: Int,
        @Field("payment_gateway_id") paymentGatewayId: Int
    ): Single<ServerResponse<ExpressCheckoutResponse>>

    @FormUrlEncoded
    @POST("membership-update-card")
    fun updateMembershipPayment(
        @Field("language") languageId: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("card_id") cardId: Int
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("customer/membership-history")
    fun getMembershipPaymentHistory(
        @Field("language") languageId: Int?,
        @Field("customer_id") userId: Long,
        @Field("token") token: String,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int
    ): Single<MembershipPaymentHistoryResponse>

    @FormUrlEncoded
    @POST("membership-update-plan")
    fun updateMembershipPlan(
        @Field("language") languageId: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("plan_id") planId: Int
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("user-cancel-membership")
    fun cancelMembership(
        @Field("language") languageId: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("cancel_user_reason_id") cancelReasonId: Int,
        @Field("cancel_user_reason") cancelReasonTitle: String,
        @Field("cancel_reason_comment") cancelReasonComment: String
    ): Single<ServerResponse<SimpleResponse>>

    @FormUrlEncoded
    @POST("get-address")
    fun getAddressList(
        @Field("language") languageId: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int
    ): Single<ServerResponse<AddressListResponse>>

    @POST("${BuildConfig.CHAT_SERVICE_URL}/v1.0/upload")
    @Multipart
    fun uploadChatAttachment(
        @Header("Authorization") token: String,
        @Part attachment: MultipartBody.Part?,
        @Part("file_type") messageType: RequestBody?,
        @Part("order_id") orderId: RequestBody?,
        @Part("user_type") userType: RequestBody?,
        @Part("user_id") userId: RequestBody?
    ): Single<jo.basket.data.model.chat.BaseResponse>

    @FormUrlEncoded
    @POST("get-user-device-information")
    fun getDeviceTokenList(
        @Field("language") languageId: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("user_type") userType: String
    ): Single<ActiveDeviceTokenResponse>

    @FormUrlEncoded
    @POST("customer/get-wallet-transactions")
    fun getWalletTransactions(
        @Field("language") languageId: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String
    ): Single<WalletHistoryResponse>

    @FormUrlEncoded
    @POST("manage-shopping-custom-item-to-cart")
    fun manageShoppingItems(
        @Field("language") languageId: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int,
        @Field("cart_item_id") cartItemId: Int,
        @Field("outlet_id") storeId: Int,
        @Field("quantity") amount: Double,
        @Field("notes") notes: String,
        @Field("product_name") productName: String
    ): Single<AddCustomItemResponse>

    @FormUrlEncoded
    @POST("get-shopping-custom-items-list")
    fun getCustomShoppingItemsList(
        @Field("language") languageId: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int,
        @Field("outlet_id") storeId: Int
    ): Single<CustomItemListResponse>

    @FormUrlEncoded
    @POST("get-splash-advertisements")
    fun getSplashADS(
        @Field("language") languageId: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int,
    ): Single<SplashADSResponse>

    @FormUrlEncoded
    @POST("payfort-sdk-tokenization")
    fun getLocalPayfortToken(
        @Field("language") languageId: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int,
        @Field("device_id") deviceId: String
    ) : Single<PayfortTokenResponse>

    @FormUrlEncoded
    @POST("customer/setting-membership-renewal-reminder")
    fun updateMembershipRenewalSetting(
        @Field("language") languageId: Int?,
        @Field("customer_id") userId: Long,
        @Field("token") token: String,
        @Field("reminder") reminder: Int,
    ): Single<SimpleResponse>

    @FormUrlEncoded
    @POST("unread-notification-count")
    fun getUnreadBadgeCount(
        @Field("customer_id") userId: Long,
        @Field("token") token: String
    ): Single<UnreadNotificationResponse>

    @FormUrlEncoded
    @POST("store-customer-suggestion")
    fun addCustomProductToExpress(
        @Field("customer_id") userId: Long,
        @Field("token") token: String,
        @Field("outlet_id") storeId: Int,
        @Field("suggestion_product_name") productName: String
    ): Single<SimpleResponse>

    @FormUrlEncoded
    @POST("notify/forexpress/user")
    fun notifyForExpress(
        @Field("language") languageId: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
    ): Single<SimpleResponse>

    @FormUrlEncoded
    @POST("deactivate-user")
    fun deactivateAccount(
        @Field("language") languageId: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
    ): Single<SimpleResponse>

    @FormUrlEncoded
    @POST("update-cart-qty")
    fun updateCartQty(
        @Field("language") languageId: Int?,
        @Field("user_id") userId: Long,
        @Field("cart_detail_id") cartDetailId: Int,
        @Field("country_id") countryId: Int,
        @Field("city_id") cityId: Int,
        @Field("token") token: String,
        @Field("notes") note: String?,
        @Field("outlet_id") storeId: Int,
        @Field("outlet_item_id") productId: Int,
        @Field("quantity") amount: Double,
        @Field("custom_additional_questions") customItemString: String,
        @Field("vendor_id") vendorId: Int
    ): Single<ServerResponse<AddCartResponse>>

    @FormUrlEncoded
    @POST("shopper/tip-amount")
    fun payTipForShopper(
        @Field("language") languageId: Int?,
        @Field("user_id") userId: Long,
        @Field("token") token: String,
        @Field("order_id") orderId: Int,
        @Field("order_outlet_id") orderStoreId: Int,
        @Field("card_id") cardId: Int,
        @Field("payment_gateway_id") paymentGatewayId: Int,
        @Field("shopper_tip_amount") shopperTipAmount: Float,
    ): Single<SimpleResponse>
}