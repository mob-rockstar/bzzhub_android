package jo.basket.ui.accountsetting.languagesetting

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import jo.basket.R
import jo.basket.data.local.db.RealmManager
import jo.basket.data.local.prefs.PreferenceManager
import jo.basket.data.model.City
import jo.basket.data.model.api.response.*
import jo.basket.data.model.api.response.base.ErrorResponse
import jo.basket.databinding.DialogLanguageSettingsBinding
import jo.basket.di.Injectable
import jo.basket.ui.accountsetting.AccountSettingViewModel
import jo.basket.ui.base.BaseInputDialogFragment
import jo.basket.ui.base.HandleResponse
import jo.basket.ui.location.citynew.CityNewAdapter
import jo.basket.ui.splash.SplashActivity
import jo.basket.utils.*
import jo.basket.utils.analytics.BasketAnalyticsManager
import org.greenrobot.eventbus.EventBus
import timber.log.Timber

// Screen to show List of Languages and User's Language Setting
class LanguageSettingsFragment :
    BaseInputDialogFragment<DialogLanguageSettingsBinding?, AccountSettingViewModel>(),
    Injectable, LanguageSettingsAdapter.OnLanguageSelectedListener {

    var languageSettingsAdapter: LanguageSettingsAdapter = LanguageSettingsAdapter()

    override val layoutId: Int
        get() = R.layout.dialog_language_settings

    override val viewModel: AccountSettingViewModel
        get() {
            return getViewModel(baseActivity, AccountSettingViewModel::class.java)
        }

    // Set Full Screen
    override fun getTheme(): Int {
        return R.style.FullScreenDialogFragmentTheme
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        progressView = viewDataBinding?.progressBar

        initToolbar()
        initRecyclerView()
        getLanguageSettings()
    }

    // Init Toolbar details
    fun initToolbar() {
        viewDataBinding!!.toolbar.collapsingToolbar.title =
            baseActivity.resources.getString(R.string.str_language_settings)

        viewDataBinding?.toolbar?.collapsingToolbar?.setExpandedTitleTypeface(
            ResUtils.getTypeFaceWithPath(ResUtils.getExpandedTitleFont())
        )

        viewDataBinding?.toolbar?.collapsingToolbar?.setCollapsedTitleTypeface(
            ResUtils.getTypeFaceWithPath(ResUtils.getCollapsedTitleFont())
        )

        viewDataBinding!!.toolbar.ivBack.setOnClickListener { dismiss() }
    }

    // Init Recyclerview details
    private fun initRecyclerView() {
        languageSettingsAdapter.selectedListener = this
        languageSettingsAdapter.currentUserLanguageID = PreferenceManager.currentUserLanguage

        viewDataBinding!!.recyclerView.layoutManager = LinearLayoutManager(baseActivity)
        viewDataBinding!!.recyclerView.adapter = languageSettingsAdapter
    }

    override fun onSelect(languageID: Int, languageName: String) {
        // Show confirm dialog for change language
        openConfirmDialog(languageID, languageName)
    }


    private fun openConfirmDialog(languageID: Int, languageName: String) {
        PopupUtils.showConfirmDialog(
            baseActivity,
            getString(R.string.str_title_confirm_language_change),
            getString(R.string.str_content_language_change)
        ) {
       //     BrazeEventTracker.trackLanguageSelection(languageName)
            updateLanguageSettings(languageID)

        }
    }

    // Restart Application
    fun restartApp() {
        try {
            val homeIntent = Intent(baseActivity.applicationContext, SplashActivity::class.java)
            homeIntent.addCategory(Intent.CATEGORY_HOME)
            homeIntent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(homeIntent)
            EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_RESTART))
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }

    // Get User's Language settings
    fun getLanguageSettings() {
        viewModel.getLanguageList(object : HandleResponse<LanguageListResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                 if (NetworkUtils.isNetworkConnected(baseActivity) &&!(error?.message ?:"").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)) {
                    this@LanguageSettingsFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    NetworkUtils.showNoInternetDialog(
                        baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    getLanguageSettings()
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(successResponse: LanguageListResponse) {
                if (successResponse.code == 200) {
                    languageSettingsAdapter.setItems(successResponse.languageList)
                } else {
                    this@LanguageSettingsFragment.onError(
                        successResponse.message
                    )
                }
            }
        })
    }

    //Update user's Language settings
    private fun updateLanguageSettings(languageID: Int) {
        viewModel.updateLanguageSettings(languageID, object : HandleResponse<SimpleUpdateResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                 if (NetworkUtils.isNetworkConnected(baseActivity) &&!(error?.message ?:"").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)) {
                    this@LanguageSettingsFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    NetworkUtils.showNoInternetDialog(
                        baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    updateLanguageSettings(languageID)
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(successResponse: SimpleUpdateResponse) {
                if (successResponse.status == 200) {
                    updateLanguageUI(languageID)
                    getCountryNCityList()
                }
            }
        })
    }

    private fun updateLanguageUI(languageID : Int){
        //Update user's Local Language setting
        PreferenceManager.currentUserLanguage = languageID

        BasketAnalyticsManager.changeLanguageNew(if (languageID == 2) "English" else "Arabic",
            if (languageID == 1) "English" else "Arabic")

        BasketAnalyticsManager.setLanguageAttribute(PreferenceManager.currentUserId, if (languageID == 1)
            "English" else "Arabic")

        languageSettingsAdapter.setCurrentLanguage(languageID)
    }

    // Get city List
    fun getCountryNCityList(){
        viewModel.getCountryNCities(object : HandleResponse<CountryCityResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                 if (NetworkUtils.isNetworkConnected(baseActivity) &&!(error?.message ?:"").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)) {
                    this@LanguageSettingsFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    NetworkUtils.showNoInternetDialog(
                        baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    getCountryNCityList()
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(successResponse: CountryCityResponse) {
                if (successResponse.status == 200) {
                    if (successResponse.data != null && successResponse.data.isNotEmpty()){
                        val countryList = successResponse.data
                        val cityList = ArrayList<City>()
                        for (country in countryList){
                            if (country.id == PreferenceManager.currentUserCountryId){
                                cityList.addAll(country.cityList)
                            }
                        }
                        RealmManager.setLocalCityData(cityList)
                    }
                    getAreaList()
                } else {
                    this@LanguageSettingsFragment.onError(
                        successResponse.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                }
            }
        })
    }

    fun getAreaList(){
        viewModel.getAreas(PreferenceManager.currentUserCityId, object : HandleResponse<AreaResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                 if (NetworkUtils.isNetworkConnected(baseActivity) &&!(error?.message ?:"").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)) {
                    this@LanguageSettingsFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    NetworkUtils.showNoInternetDialog(
                        baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    getAreaList()
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(response: AreaResponse) {
                if (response.code == 200) {
                    getAddressList()
                } else {
                    this@LanguageSettingsFragment.onError(
                        response.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                }
            }
        })
    }

    fun getAddressList() {
        viewModel.getAddressList(object : HandleResponse<AddressListResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                 if (NetworkUtils.isNetworkConnected(baseActivity) &&!(error?.message ?:"").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)) {
                    this@LanguageSettingsFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    NetworkUtils.showNoInternetDialog(
                        baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    getAddressList()
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(successResponse: AddressListResponse) {
                if (successResponse.code == 200) {
                    restartApp()
                } else {
                    this@LanguageSettingsFragment.onError(
                        successResponse.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                }
            }
        })
    }
}
