package jo.basket.data.model.pricingmodel

import com.google.gson.annotations.SerializedName

data class Slot(
    var available: Int,
    var day: Int,
    @SerializedName("delivery_charge")
    var deliveryCharge: Double,
    @SerializedName("delivery_date")
    var deliveryDate: String,
    @SerializedName("delivery_time")
    var deliveryTime: String,
    @SerializedName("delivery_time_interval_id")
    var deliveryTimeIntervalId: Int,
    @SerializedName("end_time")
    var endTime: String,
    var id: Int,
    var label: String,
    @SerializedName("start_time")
    var startTime: String
)