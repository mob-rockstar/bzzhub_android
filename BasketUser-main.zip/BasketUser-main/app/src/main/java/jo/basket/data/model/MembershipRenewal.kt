package jo.basket.data.model

import com.google.gson.annotations.SerializedName

class MembershipRenewal {
    @field:SerializedName("renewal_date")
    var renewalDate: String? = null

    @field:SerializedName("renewal_membership_id")
    var renewalMembershipId: Int? = null

    @field:SerializedName("image")
    var image: String? = null

    @field:SerializedName("renewal_membership_name")
    var renewalMembershipName: String? = null

    @field:SerializedName("is_cancel")
    var isCancel: Int? = null
}