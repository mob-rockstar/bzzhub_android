package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.realm.RealmList
import io.realm.RealmObject
import io.realm.annotations.PrimaryKey

open class Category : RealmObject(), Cloneable {
    var departmentId: Int = 0

    @PrimaryKey
    @SerializedName("aisle_id")
    @Expose
    var id: Int = 0

    @SerializedName("aisle_name")
    @Expose
    var name: String? = null

    @SerializedName("product_list")
    @Expose
    var products = RealmList<Product>()
    var fullProducts = RealmList<Product>()

    var productsViewMore = RealmList<ProductViewMore>()
    var productPromotion = RealmList<ProductPromotion>()

    @SerializedName("created_date")
    @Expose
    var createdDate: String? = null

    @SerializedName("updated_date")
    @Expose
    var updatedDate: String? = null

    @SerializedName("product_count")
    @Expose
    var productCount: Int = 0

    @SerializedName("sort_order")
    @Expose
    var sortOrder: Int = 0

    @SerializedName("banner")
    @Expose
    var banner: String? = null

    public override fun clone(): Category {
        return super.clone() as Category
    }
}