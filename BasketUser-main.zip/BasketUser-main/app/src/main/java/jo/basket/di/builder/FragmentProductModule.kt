package jo.basket.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector
import jo.basket.ui.product.AddNoteFragment
import jo.basket.ui.product.FullImageFragment
import jo.basket.ui.product.ProductMainFragment


@Module
abstract class FragmentProductModule {

    @ContributesAndroidInjector
    abstract fun contributeProductMainFragment(): ProductMainFragment

    @ContributesAndroidInjector
    abstract fun contributeFullImageFragment(): FullImageFragment

    @ContributesAndroidInjector
    abstract fun contributeAddNoteFragment(): AddNoteFragment
}
