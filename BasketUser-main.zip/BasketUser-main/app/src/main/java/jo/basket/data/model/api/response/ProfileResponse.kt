package jo.basket.data.model.api.response


import com.google.gson.annotations.SerializedName
import jo.basket.data.model.Profile

data class ProfileResponse(
    var data: Profile,
    var httpCode: Int = 0,
    @SerializedName("Message")
    var message: String
)