package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.Address

class AddressListResponse {
    @field:SerializedName("httpCode")
    var code: Int = 0

    @field:SerializedName("Message")
    var message: String? = null

    @field:SerializedName("address_list")
    var addressList: List<Address>? = null
}