package jo.basket.ui.component.imagesnack

import android.app.Activity
import android.content.res.ColorStateList
import android.text.TextUtils
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.annotation.ColorInt
import androidx.annotation.StringRes
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.content.ContextCompat
import com.google.android.material.snackbar.BaseTransientBottomBar
import jo.basket.R
import timber.log.Timber
import android.util.DisplayMetrics




class ImageSnackbar(
    parent: ViewGroup,
    content: ImageSnackbarView
) : BaseTransientBottomBar<ImageSnackbar>(parent, content, content) {

    private var hasAction = false

    init {
        getView().setBackgroundColor(
            ContextCompat.getColor(
                view.context,
                android.R.color.transparent
            )
        )
        getView().setPadding(0, 0, 0, 0)
    }

    fun setText(message: CharSequence): ImageSnackbar {
        val contentLayout = view.getChildAt(0) as ImageSnackbarView

        contentLayout.tvMsg.text = message
        //Adjust text size base on text length
        if (message.toString().trim().length > 20) {
            contentLayout.tvMsg.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 13.3f)
        } else {
            contentLayout.tvMsg.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15.3f)
        }
        return this
    }

    fun setText(@StringRes resId: Int): ImageSnackbar {
        return this.setText(context.getText(resId))
    }

    fun setAction(@StringRes resId: Int, listener: ((View) -> Unit)?): ImageSnackbar {
        return this.setAction(context.getText(resId), listener)
    }

    // Set action text
    fun setAction(
        text: CharSequence?,
        listener: ((View) -> Unit)?
    ): ImageSnackbar {
        this.hasAction = !TextUtils.isEmpty(text) && listener != null
        return this
    }

    fun setActionTextColor(colors: ColorStateList?): ImageSnackbar {
        return this
    }

    fun setActionTextColor(@ColorInt color: Int): ImageSnackbar {
        return this
    }

    companion object {
        const val LENGTH_INDEFINITE = -2
        const val LENGTH_SHORT = -1
        const val LENGTH_LONG = 0

        fun make(
            view: View,
            message: String,
            duretion: Int,
            action_lable: String? = null
        ): ImageSnackbar {

            // First we find a suitable parent for our custom view
            val parent = findSuitableParent(view) ?: throw IllegalArgumentException(
                "No suitable parent found from the given view. Please provide a valid view."
            )

            // We inflate our custom view
            try {
                val mView = LayoutInflater.from(view.context).inflate(
                    R.layout.layout_image_snackbar,
                    parent,
                    false
                )
                val displayMetrics = DisplayMetrics()
                (view.context as Activity).windowManager.defaultDisplay.getMetrics(displayMetrics)

                val snackView = mView.findViewById<ImageSnackbarView>(R.id.snack_constraint)
                snackView.layoutParams = ViewGroup.LayoutParams(displayMetrics.widthPixels, displayMetrics.heightPixels)
                // We create and return our Snackbar
                snackView.tvMsg.text = message
            /*    action_lable?.let {
                    snackView.tvAction.text = action_lable
                }*/

                return ImageSnackbar(parent, snackView).setDuration(duretion)
            } catch (e: Exception) {
                Timber.v(e)
                throw java.lang.IllegalArgumentException("No suitable parent found from the given view. Please provide a valid view.")
            }

        }

        private fun findSuitableParent(startView: View): ViewGroup? {
            var view: View? = startView
            var fallback: ViewGroup? = null
            do {
                if (view is CoordinatorLayout) {
                    return view
                }
                if (view is FrameLayout) {
                    if (view.getId() == android.R.id.content) {
                        return view
                    }
                    fallback = view
                }
                if (view != null) {
                    val parent = view.parent
                    view = if (parent is View) parent else null
                }
            } while (view != null)
            return fallback
        }

    }

}