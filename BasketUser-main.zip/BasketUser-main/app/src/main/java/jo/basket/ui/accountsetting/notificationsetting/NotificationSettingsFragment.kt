package jo.basket.ui.accountsetting.notificationsetting

import android.content.DialogInterface
import android.os.Bundle
import android.view.View
import jo.basket.R
import jo.basket.data.model.NotificationSettingsDetails
import jo.basket.data.model.api.response.NotificationSettingResponse
import jo.basket.data.model.api.response.base.ErrorResponse
import jo.basket.databinding.DialogNotificationSettingsBinding
import jo.basket.di.Injectable
import jo.basket.ui.accountsetting.AccountSettingViewModel
import jo.basket.ui.base.BaseInputDialogFragment
import jo.basket.ui.base.HandleResponse
import jo.basket.utils.AppConstants
import jo.basket.utils.NetworkUtils
import jo.basket.utils.ResUtils

// Screen To Display User Notification Setting Information
class NotificationSettingsFragment :
    BaseInputDialogFragment<DialogNotificationSettingsBinding?, AccountSettingViewModel>(),
    Injectable {

    override val layoutId: Int
        get() = R.layout.dialog_notification_settings

    override val viewModel: AccountSettingViewModel
        get() {
            return getViewModel(baseActivity, AccountSettingViewModel::class.java)
        }

    // Set fragment Full screen
    override fun getTheme(): Int {
        return R.style.FullScreenDialogFragmentTheme
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        progressView = viewDataBinding?.progressBar
        initToolBar()
        getNotificationSettings()
    }

    private fun initToolBar() {
        viewDataBinding!!.toolbar.collapsingToolbar?.title =
            baseActivity.resources.getString(R.string.notification)

        viewDataBinding?.toolbar?.collapsingToolbar?.setExpandedTitleTypeface(
            ResUtils.getTypeFaceWithPath(ResUtils.getExpandedTitleFont())
        )

        viewDataBinding?.toolbar?.collapsingToolbar?.setCollapsedTitleTypeface(
            ResUtils.getTypeFaceWithPath(ResUtils.getCollapsedTitleFont())
        )

        viewDataBinding!!.toolbar.ivBack.setOnClickListener { dismiss() }
    }

    // Get user's notification settings
    private fun getNotificationSettings() {
        viewModel.getNotificationSettings(object : HandleResponse<NotificationSettingResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                 if (NetworkUtils.isNetworkConnected(baseActivity) &&!(error?.message ?:"").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)) {
                    this@NotificationSettingsFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    NetworkUtils.showNoInternetDialog(
                        baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    getNotificationSettings()
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(successResponse: NotificationSettingResponse) {
                if (successResponse.code == 200 && successResponse.notificationSettingsDetails != null) {
                    initUI(successResponse.notificationSettingsDetails)
                } else {
                    this@NotificationSettingsFragment.onError(
                        successResponse.message
                    )
                }
            }
        })
    }

    // Init UI base on User Notification Settings
    fun initUI(settings: NotificationSettingsDetails) {
        settings.run {
            viewDataBinding!!.swSendPush.isChecked = orderUpdatePushNotification != null && orderUpdatePushNotification == 1
            viewDataBinding!!.swSendSMS.isChecked = orderUpdateSms != null && orderUpdateSms == 1
            viewDataBinding!!.swCallBeforeCheckout.isChecked =
                orderUpdateCallBeforeCheckout != null && orderUpdateCallBeforeCheckout == 1
            viewDataBinding!!.swMarkEmails.isChecked = promoMarketingEmail != null && promoMarketingEmail == 1
            viewDataBinding!!.swMarkPush.isChecked = promoMarketingPushNotification != null && promoMarketingPushNotification == 1
        }
    }

    // Save notification settings when user is closing Notification Setting screen
    override fun onDismiss(dialog: DialogInterface) {
  /*      BrazeEventTracker.setPushNEmailSubscription(
            viewDataBinding!!.swSendPush.isChecked,viewDataBinding!!.swMarkEmails.isChecked
        )*/
        viewModel.updateNotificationSettings(
            if (viewDataBinding!!.swSendPush.isChecked) 1 else 0,
            if (viewDataBinding!!.swSendSMS.isChecked) 1 else 0,
            if (viewDataBinding!!.swCallBeforeCheckout.isChecked) 1 else 0,
            if (viewDataBinding!!.swMarkEmails.isChecked) 1 else 0,
            if (viewDataBinding!!.swMarkPush.isChecked) 1 else 0,
            0
        )
        super.onDismiss(dialog)
    }
}