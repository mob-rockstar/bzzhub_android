package jo.basket.di.factory.module

import android.content.Context
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import dagger.Module
import dagger.Provides
import io.github.inflationx.calligraphy3.CalligraphyConfig
import io.reactivex.disposables.CompositeDisposable
import jo.basket.BasketApp
import jo.basket.R
import jo.basket.data.remote.SocketManager
import jo.basket.ui.base.navigator.ActivityNavigator
import jo.basket.ui.base.navigator.ChildFragmentNavigator
import jo.basket.ui.base.navigator.FragmentNavigator
import jo.basket.ui.base.navigator.Navigator
import jo.basket.utils.rx.AppSchedulerProvider
import jo.basket.utils.rx.SchedulerProvider
import javax.inject.Singleton


@Module
class AppModule {


    @Provides
    @Singleton
    fun provideCalligraphyDefaultConfig(): CalligraphyConfig {
        return CalligraphyConfig.Builder()
//            .setDefaultFontPath("fonts/OpenSans-Regular.ttf")
            .setFontAttrId(R.attr.fontPath)
            .build()
    }

    @Provides
    @Singleton
    fun provideContext(application: BasketApp): Context {
        return application
    }


    @Provides
    @Singleton
    fun provideSocketManager(): SocketManager {
        return SocketManager()
    }


    @Provides
    @Singleton
    fun provideCompositeDisposable(): CompositeDisposable {
        return CompositeDisposable()
    }


    @Provides
    @Singleton
    fun provideGson(): Gson? {
        return GsonBuilder().excludeFieldsWithoutExposeAnnotation().create()
    }

    @Provides
    fun provideSchedulerProvider(): SchedulerProvider {
        return AppSchedulerProvider()
    }

    @Provides
    @Singleton
    fun provideNavigator(activityNavigator: ActivityNavigator): Navigator {
        return activityNavigator
    }

    @Provides
    @Singleton
    fun provideFragmentNavigator(childFragmentNavigator: ChildFragmentNavigator): FragmentNavigator {
        return childFragmentNavigator
    }
}