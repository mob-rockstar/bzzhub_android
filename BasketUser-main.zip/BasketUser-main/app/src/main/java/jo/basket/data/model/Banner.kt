package jo.basket.data.model


import com.google.gson.annotations.SerializedName
import java.io.Serializable

open class Banner : Serializable {
    @SerializedName("aisle_id")
    var aisleId: Int? = null
    @SerializedName("department_id")
    var departmentId: Int? = null
    var description: String? = null
    @SerializedName("external_url")
    var externalUrl: String? = null
    var id: Int? = null
    var image: String? = null

    @SerializedName("logo_image")
    var logoImage: String? = null

    @SerializedName("outlet_id")
    var outletId: Int? = null

    @SerializedName("outlet_item_id")
    var outletItemId: Int? = null

    @SerializedName("redirect_action")
    var redirectAction: Int? = null

    @SerializedName("section_type_id")
    var sectionTypeId: Int? = null

    @SerializedName("vendor_id")
    var vendorId: Int? = null

    var title: String? = null

    @SerializedName("department_name")
    var departmentName: String? = null

    @SerializedName("aisle_name")
    var aisleName: String? = null

    @SerializedName("outlets_list")
    var outletList: List<Outlet> = ArrayList()

    @SerializedName("second_outlet_list")
    var secondOutletList: List<Outlet> = ArrayList()

    @SerializedName("free_delivery_promotion_id")
    var freeDeliveryPromotionId: Int? = null

    @SerializedName("service_id")
    var serviceId: Int? = null

    open class Outlet: Serializable {
        @SerializedName("outlet_id")
        val outletId: Int = 0
        @SerializedName("outlet_name")
        val outletName: String= ""
    }


}
