package jo.basket.data.model.currency


data class CurrencyResponse(
    var `data`: CurrencyData,
    var message: String,
    var status: Int
)