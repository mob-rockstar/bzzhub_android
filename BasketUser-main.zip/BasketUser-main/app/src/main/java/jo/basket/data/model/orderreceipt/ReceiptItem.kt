package jo.basket.data.model.orderreceipt


import com.google.gson.annotations.SerializedName

open class ReceiptItem {

    @SerializedName("item_type")
    var itemType: Int? = null

    @SerializedName("outlet_item_id")
    var outletItemId: Int? = null

    @SerializedName("product_name")
    var productName: String? = null

    @SerializedName("product_image")
    var productImage: String? = null

    @SerializedName("product_info_image")
    var productInfoImage: String? = null

    @SerializedName("sold_per")
    var soldPer: Int? = null

    @SerializedName("sold_per_label")
    var soldPerLabel: String? = null

    @SerializedName("label_value")
    var labelValue: String? = null

    @SerializedName("size_label")
    var sizeLabel: Int? = null

    @SerializedName("each_suffix")
    var eachSuffix: Double? = null

    @SerializedName("actual_approx_weight")
    var actualApproxWeight: Double? = null

    @SerializedName("actual_selling_price")
    var actualSellingPrice: Double? = null

    @SerializedName("item_unit_price_actual")
    var itemUnitPriceActual: Double? = null

    @SerializedName("unit")
    var unit: String? = null

    @SerializedName("actual_qty")
    var actualQty: Double? = null

    @SerializedName("actual_item_total")
    var actualItemTotal: Double? = null

    @SerializedName("customer_item_notes")
    var customerItemNotes: String? = null

    @SerializedName("item_unit_price_org")
    var itemUnitPriceOrg: Double? = null

    @SerializedName("promo_item")
    var promoItem: Int? = null

}