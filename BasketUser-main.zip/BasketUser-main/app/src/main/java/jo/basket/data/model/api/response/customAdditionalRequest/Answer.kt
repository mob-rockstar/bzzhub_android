package jo.basket.data.model.api.response.customAdditionalRequest

data class Answer(
    var active: Boolean,
    val description: MutableList<Description>,
    val id: Int,
    val price: Double,
    val rank: Int,
    var selected: Boolean,
    val title: List<Title>,
    var answer_count: Int = 0,
)