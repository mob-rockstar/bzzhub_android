package jo.basket.data.model.orderreceipt


data class OrderItems(
    var `data`: List<ReceiptSection>,
    var section: String
)