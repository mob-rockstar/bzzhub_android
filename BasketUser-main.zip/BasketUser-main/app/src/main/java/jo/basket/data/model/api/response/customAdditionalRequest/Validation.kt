package jo.basket.data.model.api.response.customAdditionalRequest

data class Validation(
    val max: Int,
    val min: Int,
    val repeat: Int,
    val required: Boolean
)