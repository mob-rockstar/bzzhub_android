package jo.basket.data.model.chat

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

open class ChatMessage {

    @SerializedName("message_id")
    @Expose
    var id: String = ""

    @SerializedName("message_type")
    @Expose
    var type: String = "text"

    @SerializedName("message_content")
    @Expose
    var content: String? = null

    @SerializedName("by")
    @Expose
    var by: User? = null

    @SerializedName("is_send")
    @Expose
    var isSend: Boolean = false

    @SerializedName("is_received")
    @Expose
    var isReceived: Boolean = false

    @SerializedName("is_read")
    @Expose
    var isRead: Boolean = false

    @SerializedName("send_at")
    @Expose
    var send_at: String? = null

    @SerializedName("received_at")
    @Expose
    var received_at: String? = null

    @SerializedName("read_at")
    @Expose
    var read_at: String? = null

    @SerializedName("order_id")
    @Expose
    val orderId: String? = ""

    companion object {

        fun fromHistoryMessage(message: FetchHistoryResponse.Message): ChatMessage {
            val chatMessage = ChatMessage()
            chatMessage.id = message.id
            chatMessage.type = message.type
            chatMessage.content = message.content
            val user = User()
            user.id = message.by?.id ?: ""
            user.type = message.by?.role
            chatMessage.by = user
            chatMessage.isSend = message.isSend
            chatMessage.isReceived = message.isReceived
            chatMessage.isRead = message.isRead
            chatMessage.send_at = message.send_at
            chatMessage.received_at = message.received_at
            chatMessage.read_at = message.read_at
            return chatMessage
        }

    }

}