package jo.basket.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector
import jo.basket.ui.promocodes.AddPromoCodeFragment
import jo.basket.ui.promocodes.PromoCodesMainFragment

@Module
abstract class FragmentPromoCodesModule {

    @ContributesAndroidInjector
    abstract fun contributePromoCodesMainFragment(): PromoCodesMainFragment

    @ContributesAndroidInjector
    abstract fun contributeAddPromoCodeFragment(): AddPromoCodeFragment

}