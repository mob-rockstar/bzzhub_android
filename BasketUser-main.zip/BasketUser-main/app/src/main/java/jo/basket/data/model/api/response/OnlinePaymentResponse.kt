package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName


class OnlinePaymentResponse {

    @field:SerializedName("httpCode")
    val code: Int = 0

    @field:SerializedName("Message")
    val message: String? = null

    @field:SerializedName("ds_url")
    val dsUrl: String? = null

    @SerializedName("order_id")
    var orderId: Int? = 0

    @SerializedName("order_outlet_id")
    var orderOutletId: Int? = 0

}