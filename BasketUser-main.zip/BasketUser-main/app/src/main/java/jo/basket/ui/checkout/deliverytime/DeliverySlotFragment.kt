package jo.basket.ui.checkout.deliverytime

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.View.GONE
import android.widget.TextView
import jo.basket.R
import jo.basket.data.model.Cart
import jo.basket.data.model.DeliveryDay
import jo.basket.data.model.DeliveryTime
import jo.basket.data.model.StoreDeliverySlot
import jo.basket.data.model.api.response.DeliverySlotsResponse
import jo.basket.data.model.api.response.base.ErrorResponse
import jo.basket.databinding.FragmentCheckoutDeliverySlotBinding
import jo.basket.di.Injectable
import jo.basket.ui.base.BaseDialogFragment
import jo.basket.ui.base.HandleResponse
import jo.basket.ui.checkout.CheckoutViewModel
import jo.basket.ui.component.timepicker.DaysAdapter
import jo.basket.utils.AppConstants
import jo.basket.utils.NetworkUtils
import timber.log.Timber
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

// Delivery Slot List Screen
class DeliverySlotFragment(
    private val cart: Cart,
    private val pickTimeListener: OnPickTimeListener
) : BaseDialogFragment<FragmentCheckoutDeliverySlotBinding?, CheckoutViewModel>(),
    Injectable, DaysAdapter.OnDeliveryTimeSelectListener {

    private lateinit var adapter: DaysAdapter

    private var deliverySlot: StoreDeliverySlot? = null
    private var selectedTime: DeliveryTime? = null

    private var oldDayIndex = -1


    override val layoutId: Int
        get() = R.layout.fragment_checkout_delivery_slot

    override val viewModel: CheckoutViewModel
        get() {
            return getViewModel(baseActivity, CheckoutViewModel::class.java)
        }

    // Set Full Screen
    override fun getTheme(): Int {
        return R.style.FullScreenDialogFragmentTheme
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        progressView = viewDataBinding?.progressBar

        initToolbar()

        // Init ViewPager Tabs (Each Tabs would contain weekday)
        initDeliveryDayTabs()

        viewDataBinding?.btSave?.setOnClickListener {
            if (selectedTime != null) pickTimeListener.onTimePicked(selectedTime!!)
            dismiss()
        }

        val deliverySlots = viewModel.deliverySlots
        if (deliverySlots != null) {
            initSlots(deliverySlots)
        } else {
            viewModel.setIsLoading(true)
            getDeliverySlots()
        }
    }

    fun initToolbar() {
        viewDataBinding?.toolbar?.tvTitle?.setText(R.string.select_delivery_title)
        viewDataBinding?.toolbar?.ivBack?.setOnClickListener { dismiss() }
      //  viewDataBinding?.tabbar?.setupWithViewPager(viewDataBinding?.vpDeliverySlots)
        viewDataBinding?.toolbar?.ivSearch?.visibility = GONE
        viewDataBinding?.toolbar?.cart?.visibility = GONE
    }

    fun initDeliveryDayTabs(){
        adapter = DaysAdapter(baseActivity, this, cart.deliveryDate, cart.deliveryTime)
        viewDataBinding?.vpDeliverySlots?.adapter = adapter
    }

    override fun onSelect(time: DeliveryTime) {
        selectedTime = time
        viewDataBinding?.btSave?.isEnabled = time.available == 1
    }


    private fun initSlots(deliverySlots: List<StoreDeliverySlot>) {
        for (slot in deliverySlots) {
            if (slot.storeId == cart.storeId) {
                deliverySlot = slot
                break
            }
        }

        if (deliverySlot == null) {
            popBackStack()
        }

        val deliveryDays = ArrayList<DeliveryDay>(deliverySlot!!.deliveryDays ?: emptyList())
        // check if first day is available
        if (deliveryDays.isNotEmpty()) {
            val times = deliveryDays.first().times
            var isAvailableDay = false
            if (times != null) {
                for (time in times) {
                    if (time.available == 1) {
                        isAvailableDay = true
                        break
                    }
                }
            }
            // Remove Empty Day
            if (!isAvailableDay) {
                deliveryDays.removeAt(0)
            }
        }

        adapter.setData(deliveryDays)
        viewDataBinding?.vpDeliverySlots?.currentItem = 0
        try {
            createTabs(deliveryDays)
        } catch (e: java.lang.Exception) {
            Timber.d(e.message)
        }

        oldDayIndex = -1
        for ((tabIndex, day) in deliveryDays.withIndex()) {
            if (day.weekDate == cart.deliveryDate) {
                oldDayIndex = tabIndex
                break
            }
        }
        if (oldDayIndex > -1) {
            viewDataBinding?.vpDeliverySlots?.currentItem = oldDayIndex
        }
    }

    // Create Tabs Base on DeliverySlot Response
    private fun createTabs(deliveryDays: List<DeliveryDay>) {
        val parser = SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH)
        val formatter = SimpleDateFormat("dd MMM", Locale.ENGLISH)
        val inflater = LayoutInflater.from(context)

        for ((tabIndex, day) in deliveryDays.withIndex()) {
            val tab: View = inflater.inflate(R.layout.tabbar_item_delivery_day, null, false)

            val tvDayOfWeek = tab.findViewById<TextView>(R.id.tv_day_of_week)
            tvDayOfWeek.text = day.day?.substring(0, 3)
            val tvDate = tab.findViewById<TextView>(R.id.tv_date)
            tvDate.text = formatter.format(parser.parse(day.weekDate!!)!!)

       //     viewDataBinding?.tabbar?.getTabAt(tabIndex)?.customView = tab
        }
    }

    // Get Delivery slot list
    private fun getDeliverySlots() {
        viewModel.getDeliverySlots(cart.storeId,object : HandleResponse<DeliverySlotsResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                 if (NetworkUtils.isNetworkConnected(baseActivity) &&!(error?.message ?:"").lowercase().contains(
                         AppConstants.UNABLE_TO_RESOLVE_NETWORK)) {
                    popBackStack()
                } else {
                    NetworkUtils.showNoInternetDialog(
                        baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    getDeliverySlots()
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(response: DeliverySlotsResponse) {
                if (response.code == 200 && response.storeDeliverySlots != null) {
                    initSlots((response.storeDeliverySlots!!))
                } else {
                    popBackStack()
                }
            }
        })
    }


    interface OnPickTimeListener {
        fun onTimePicked(time: DeliveryTime)
    }

}