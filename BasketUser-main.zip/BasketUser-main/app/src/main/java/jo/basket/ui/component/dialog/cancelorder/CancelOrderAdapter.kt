package jo.basket.ui.component.dialog.cancelorder

import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import jo.basket.R
import jo.basket.data.model.CancelReason
import jo.basket.databinding.RecyclerItemOrderCancelReasonBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter

class CancelOrderAdapter (private val onItemSelected: (cancelReason: CancelReason) -> Unit) :
    BaseRecyclerViewAdapter<CancelReason, RecyclerItemOrderCancelReasonBinding>() {

    override val layoutId: Int
        get() = R.layout.recycler_item_order_cancel_reason


    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return CancelMembershipViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as CancelMembershipViewHolder
        val item = items[position]
        val context = holder.binding.root.context
        holder.binding.tvReason.text = item.name

        if (selected == position){
            holder.binding.ivSelect.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_radio_checked))
        }else{
            holder.binding.ivSelect.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_radio))
        }

        holder.itemView.setOnClickListener {
            setSelection(position)
            onItemSelected(item)
        }
    }

    class CancelMembershipViewHolder(val binding: RecyclerItemOrderCancelReasonBinding) :
        RecyclerView.ViewHolder(binding.root)

}