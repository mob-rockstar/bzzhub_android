package jo.basket.data.model


import com.google.gson.annotations.SerializedName
import jo.basket.data.model.api.response.WalletTransactionsHistory

data class WalletData(
    @SerializedName("transactions_history")
    var walletTransactionsHistory: List<WalletTransactionsHistory>,
    @SerializedName("wallet_balance")
    var walletBalance: String
)