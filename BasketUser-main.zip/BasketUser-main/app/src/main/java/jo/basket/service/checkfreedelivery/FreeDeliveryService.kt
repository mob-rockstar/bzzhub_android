package jo.basket.service.checkfreedelivery

import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import jo.basket.data.local.prefs.PreferenceManager
import jo.basket.ui.freedelivery.FreeDeliveryActivity
import jo.basket.ui.login.LoginActivity
import jo.basket.utils.AppConstants
import jo.basket.utils.AppConstants.NEXT_FREE_DELIVERY_POPUP_INTERVAL
import jo.basket.utils.MessageEvent
import org.greenrobot.eventbus.EventBus
import java.util.*

// Service to check Free Delivery Option
class FreeDeliveryService : Service() {

    private var timer: Timer? = null

    // Time interval 30 seconds
    private val defaultInterval: Long = 30 * 1000

    override fun onBind(intent: Intent?): IBinder? {
        return FreeDeliveryBinder()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Check Free Delivery
        checkFreeDelivery()
        return super.onStartCommand(intent, flags, startId)
    }

    private fun checkFreeDelivery() {
        timer = Timer()
        val timerTask = CheckFreeDeliveryTask(timer!!, this)
        timer!!.scheduleAtFixedRate(timerTask, defaultInterval, defaultInterval)
    }

    // Open Free Delivery Activity
    fun showFreeDeliveryPopup(secondTime: Long): Boolean {
        // If User is logged out or Dialog is already showing, then do not show popup
        if (FreeDeliveryActivity.IS_FREE_DELIVERY_SHOWING
            || PreferenceManager.currentUserLoggedInMode == PreferenceManager.LoggedInMode.LOGGED_IN_MODE_LOGGED_OUT
        ) return false
        val intent = Intent(applicationContext, FreeDeliveryActivity::class.java)
        intent.putExtra(NEXT_FREE_DELIVERY_POPUP_INTERVAL, secondTime)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        return true
    }

    fun logoutUser(){
        // need to force logout even get error from API
        PreferenceManager.currentUserLoggedInMode =
            PreferenceManager.LoggedInMode.LOGGED_IN_MODE_LOGGED_OUT
        gotoLoginActivity()
        //Send Event broadcast to finish existing activities
        EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_RESTART))
    }

    // Open Login Activity
    fun gotoLoginActivity() {
        val intent = Intent(applicationContext, LoginActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        startActivity(intent)
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    fun checkNextFreeDelivery(seconds: Long) {
        val timer = Timer()
        timer.schedule(CheckFreeDeliveryTask(timer, this), (if (seconds < 15) 30 else seconds) * 1000)
    }

    inner class FreeDeliveryBinder : Binder() {
        fun getService(): FreeDeliveryService {
            return this@FreeDeliveryService
        }
    }
}