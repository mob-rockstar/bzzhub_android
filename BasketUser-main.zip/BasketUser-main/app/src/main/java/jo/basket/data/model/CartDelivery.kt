package jo.basket.data.model

open class CartDelivery(val storeName: String, val timeList: List<DeliveryTime>)