package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


open class CheckoutPermissionDetails {

    @SerializedName("checkout_permission")
    @Expose
    var checkoutPermission: Int? = null

    @SerializedName("delivery_permission")
    @Expose
    var deliveryPermission: Int? = null

    @SerializedName("min_order_permission")
    @Expose
    var minOrderPermission: Int? = null

    @SerializedName("cart_user_message")
    @Expose
    var cartUserMessage: String? = null

    @SerializedName("popup_details")
    @Expose
    var popupDetails: CheckoutPopupDetails? = null

}