package jo.basket.ui.checkout

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.payfort.fortpaymentsdk.FortSdk
import com.payfort.fortpaymentsdk.callbacks.FortCallBackManager
import com.payfort.fortpaymentsdk.callbacks.FortInterfaces
import com.payfort.fortpaymentsdk.domain.model.FortRequest
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import jo.basket.R
import jo.basket.data.model.api.response.CountrySettingResponse
import jo.basket.data.model.api.response.base.ErrorResponse
import jo.basket.databinding.ActivityCheckoutBinding
import jo.basket.ui.base.BaseActivity
import jo.basket.ui.base.HandleResponse
import jo.basket.ui.checkout.detail.CheckoutDetailFragment
import jo.basket.utils.AppConstants
import jo.basket.utils.MessageEvent
import org.greenrobot.eventbus.EventBus
import javax.inject.Inject

// Activity For Checkout Flow
class CheckoutActivity : BaseActivity<ActivityCheckoutBinding?, CheckoutViewModel>(),
    HasAndroidInjector {

    override val layoutId: Int
        get() = R.layout.activity_checkout

    override val viewModel: CheckoutViewModel
        get() {
            return getViewModel(CheckoutViewModel::class.java)
        }
    private var fortCallback: FortCallBackManager? = null
    var isPaymentScreenOpened = false

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewModel.getCountryList(
            object : HandleResponse<CountrySettingResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {

                }

                override fun handleSuccessRespons(successResponse: CountrySettingResponse) {

                }
            }
        )

        fortCallback = FortCallBackManager.Factory.create()

        Handler(Looper.getMainLooper()).postDelayed({
            replaceFragmentDirectly(R.id.checkout_fragment, CheckoutDetailFragment())
        }, 250)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        fortCallback!!.onActivityResult(requestCode, resultCode, data)
    }

    fun addCreditCardRequest(requestMap: Map<String, Any>, payfortEnvironmentMode: String){

        val fortRequest = FortRequest()
        fortRequest.requestMap = requestMap

        FortSdk.getInstance().registerCallback(this@CheckoutActivity,
            fortRequest,
            payfortEnvironmentMode,
            AppConstants.FORT_REQUEST_CODE,
            fortCallback,
            true,
            object : FortInterfaces.OnTnxProcessed {

                override fun onCancel(
                    map: MutableMap<String, Any>, map1: MutableMap<String, Any>
                ) {
                    isPaymentScreenOpened = false
          //          this@CheckoutActivity.onError(AppConstants.DEFAULT_ERROR_MESSAGE)
                }

                override fun onSuccess(
                    map: MutableMap<String, Any>, fortData: MutableMap<String, Any>
                ) {// Add Credit Card to server
                    isPaymentScreenOpened = false
                    (supportFragmentManager.findFragmentById(R.id.checkout_fragment)
                            as CheckoutDetailFragment).addCreditCard(fortData)
                }

                override fun onFailure(
                    map: MutableMap<String, Any>,
                    fortResponse: MutableMap<String, Any>
                ) {
                    isPaymentScreenOpened = false
                    if (fortResponse != null && fortResponse["response_message"] != null) {
                        this@CheckoutActivity.onError(
                            fortResponse["response_message"].toString()
                        )
                    }else{
                        this@CheckoutActivity.onError(
                            "Something went wrong"
                        )
                    }
                }
            })
    }

    fun addMapFragment(onPlaceOrder: () -> Unit, onChangeAddress :() -> Unit){
        addFragment(R.id.checkout_fragment, CheckoutMapFragment({onPlaceOrder()}, {onChangeAddress()}))
    }

    override fun onBackPressed() {
        if (!viewModel.isFoodRunning){
            EventBus.getDefault()
                .post(MessageEvent(AppConstants.MESSAGE_RELOAD_CART))
            super.onBackPressed()
        }
    }
}