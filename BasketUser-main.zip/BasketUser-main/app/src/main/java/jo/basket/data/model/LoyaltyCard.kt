package jo.basket.data.model


import com.google.gson.annotations.SerializedName

data class LoyaltyCard(
    var id: Int,
    @SerializedName("logo_image")
    var logoImage: String = "",
    @SerializedName("loyalty_card_name")
    var loyaltyCardName: String = "",
    @SerializedName("loyalty_card_number")
    var loyaltyCardNumber: String,
    @SerializedName("user_loyalty_card_id")
    var userLoyaltyCardId: Int,
    @SerializedName("vendor_name")
    var vendorName: String = ""
)