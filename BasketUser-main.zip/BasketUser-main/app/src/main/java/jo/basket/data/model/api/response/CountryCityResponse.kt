package jo.basket.data.model.api.response

import jo.basket.data.model.CountryNew


data class CountryCityResponse(
    var `data`: List<CountryNew>,
    var message: String,
    var status: Int
)