package jo.basket.ui.component.dialog.payment

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import jo.basket.R
import jo.basket.data.model.PaymentMethod
import jo.basket.databinding.RecyclerItemMembershipPaymentBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter

class MembershipPaymentAdapter (private val onItemSelected: (paymentMethod: PaymentMethod) -> Unit) :
    BaseRecyclerViewAdapter<PaymentMethod, RecyclerItemMembershipPaymentBinding>() {

    override val layoutId: Int
        get() = R.layout.recycler_item_membership_payment

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return MembershipPaymentViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as MembershipPaymentViewHolder
        val item = items[position]
        val context = holder.binding.root.context

        holder.binding.tvPaymentMethod.text = item.cardNumber
        holder.itemView.setOnClickListener { onItemSelected(item) }
    }

    class MembershipPaymentViewHolder(val binding: RecyclerItemMembershipPaymentBinding) :
        RecyclerView.ViewHolder(binding.root)
}