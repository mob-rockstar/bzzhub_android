package jo.basket.ui.cart.main

import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import androidx.recyclerview.widget.LinearLayoutManager
import jo.basket.R
import jo.basket.data.local.prefs.PreferenceManager
import jo.basket.data.model.api.response.*
import jo.basket.data.model.api.response.base.ErrorResponse
import jo.basket.databinding.FragmentCartAllBinding
import jo.basket.di.Injectable
import jo.basket.ui.base.BaseInputDialogFragment
import jo.basket.ui.base.HandleResponse
import jo.basket.ui.cart.CartActivity
import jo.basket.ui.cart.CartViewModel
import jo.basket.utils.*
import org.greenrobot.eventbus.EventBus


class CartAllFragment : BaseInputDialogFragment<FragmentCartAllBinding?, CartViewModel>(),
    Injectable {
    override val layoutId: Int
        get() = R.layout.fragment_cart_all
    private var cartViewAllAdapter: CartViewAllAdapter = CartViewAllAdapter()
    override val viewModel: CartViewModel
        get() {
            return getViewModel(baseActivity, CartViewModel::class.java)
        }

    private val allCarts: ArrayList<Outlet> = ArrayList()
    var layoutManager: LinearLayoutManager? = null
    // prevent double tapping variables
    private var lastClickTime: Long = 0

    override fun getTheme(): Int {
        return R.style.FullScreenDialogFragmentTheme
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        getStoreAllMyCart(AppConstants.selectedService!!.id.toString(), true)
        initListeners()
    }

    fun initListeners() {

        // Listener for Cart Adapter
        cartViewAllAdapter.setOnCartActionListener(object :
            CartViewAllAdapter.OnCartActionListener {
            override fun onItemClickList(outletId: Int?) {
                Log.d("TAG", "outletId===>: "+outletId.toString())
                PreferenceManager.currentUserStoreId = outletId!!.toInt()
                EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_SWITCH_CART,outletId))
                EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_DATA_CART_UPDATE,outletId))
                dismiss()
            }

        })

        viewDataBinding?.ivBack?.setOnClickListener {
            dismiss()
        }

    }

    private fun getStoreAllMyCart(serviceId: String, isLoading: Boolean? = false) {

        viewModel.getStoreAllMyCart(serviceId, isLoading ?: false, object : HandleResponse<StoreMyCartResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                viewDataBinding?.rvCartStores?.visibility = GONE
                (activity as CartActivity).viewDataBinding?.toolbar?.toolbar?.visibility = VISIBLE

                if (NetworkUtils.isNetworkConnected(baseActivity) && !(error?.message ?: "").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)) {
                    this@CartAllFragment.onError(error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE)
                } else {
                    NetworkUtils.showNoInternetDialog(
                        baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    getStoreAllMyCart(serviceId)
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(response: StoreMyCartResponse) {
                //    viewDataBinding?.progressBar?.visibility = GONE
                if (response.status == 200) {

                    allCarts.apply {
                        clear()
                        addAll(response.data)
                    }
                    if (allCarts.isNotEmpty()) {
                        viewDataBinding?.rvCartStores?.layoutManager = LinearLayoutManager(requireContext())
                        cartViewAllAdapter.setItems(allCarts)
                        viewDataBinding?.rvCartStores?.adapter = cartViewAllAdapter
                    } else {

                    }
                } else {
                    this@CartAllFragment.onError(
                        response.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                }

            }
        })
    }

}
