package jo.basket.data.model.payfort

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import jo.basket.utils.AppConstants
import jo.basket.utils.AppConstants.PAYFORT_CURRENCY
import jo.basket.utils.AppConstants.PAYFORT_ESCI
import jo.basket.utils.AppConstants.PAYFORT_SDK_TOKEN
import jo.basket.utils.StringUtils

class PayRequestBody(private val paymentMode : Int)  {
    @SerializedName("command")
    @Expose
    var command: String = PAYFORT_SDK_TOKEN

    @SerializedName("access_code")
    @Expose
    var accessCode: String =
        if (paymentMode == AppConstants.PAYFORT_MODE_SANDBOX) AppConstants.PAYFORT_ACCESS_CODE_SANDBOX
    else AppConstants.PAYFORT_ACCESS_CODE_PRODUCTION

    @SerializedName("merchant_identifier")
    @Expose
    var merchantIdentifier: String =
        if (paymentMode == AppConstants.PAYFORT_MODE_SANDBOX) AppConstants.PAYFORT_MERCHANT_ID_SANDBOX
    else AppConstants.PAYFORT_MERCHANT_ID_PRODUCTION

    @SerializedName("merchant_reference")
    @Expose
    var merchantReference: String? = null

    @SerializedName("amount")
    @Expose
    var amount = 0

    @SerializedName("currency")
    @Expose
    var currency: String = StringUtils.getCurrencyForPayment()

    @SerializedName("language")
    @Expose
    var language: String = AppConstants.PAYFORT_LANGUAGE

    @SerializedName("customer_email")
    @Expose
    var customerEmail: String? = null

    @SerializedName("eci")
    @Expose
    var eci: String = PAYFORT_ESCI

    @SerializedName("token_name")
    @Expose
    var tokenName: String? = null

    @SerializedName("signature")
    @Expose
    var signature: String? = null
}