package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.realm.annotations.PrimaryKey


open class ProductHint {

    @PrimaryKey
    @SerializedName("product_id")
    @Expose
    var id: Int = 0

    @SerializedName("product_name")
    @Expose
    var name: String? = null

    @SerializedName("aisle_id")
    @Expose
    var categoryId: Int = 0

    @SerializedName("brand_id")
    @Expose
    var brandId: Int = 0

    @SerializedName("featured_item")
    @Expose
    var featuredItem: Int = 0

    @SerializedName("suggestion_type")
    @Expose
    var suggestionType: String? = null

}