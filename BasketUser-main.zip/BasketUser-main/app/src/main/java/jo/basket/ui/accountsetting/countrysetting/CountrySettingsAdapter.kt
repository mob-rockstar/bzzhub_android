package jo.basket.ui.accountsetting.countrysetting

import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import jo.basket.R
import jo.basket.data.local.prefs.PreferenceManager
import jo.basket.data.model.Country
import jo.basket.databinding.RecyclerItemCountrySettingBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter

class CountrySettingsAdapter :
    BaseRecyclerViewAdapter<Country, RecyclerItemCountrySettingBinding>() {

    override val layoutId: Int
        get() = R.layout.recycler_item_country_setting

    var currentCountryId: Int = PreferenceManager.currentUserCountryId
    var selectedListener: OnCountrySelectListener? = null

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return CountrySettingViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as CountrySettingViewHolder

        // Set Country Name
        holder.binding.tvCountryName.text = items[position].countryName

        if (currentCountryId == items[position].id)
            holder.binding.ivCheck.visibility = VISIBLE
        else
            holder.binding.ivCheck.visibility = GONE

        holder.itemView.setOnClickListener {
            selectedListener!!.onSelect(items[position].id)
        }
    }

    fun setCountryID(mCountryId: Int) {
        this.currentCountryId = mCountryId
        notifyDataSetChanged()
    }

    inner class CountrySettingViewHolder(val binding: RecyclerItemCountrySettingBinding) :
        RecyclerView.ViewHolder(binding.root)

    interface OnCountrySelectListener {
        fun onSelect(countryID: Int)
    }
}