package jo.basket.ui.component

import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import jo.basket.R
import jo.basket.data.model.Service
import jo.basket.databinding.RecyclerItemBottomServiceLeafBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter

class BottomLeafAdapter(private val onBottomTabSelected: () -> Unit):   BaseRecyclerViewAdapter<Service, RecyclerItemBottomServiceLeafBinding>() {
    override val layoutId: Int
        get() = R.layout.recycler_item_bottom_service_leaf

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = createBindedView(viewGroup)
        return StoreServiceViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as StoreServiceViewHolder
        val context =  holder.binding.root.context

        if (selected == position) {
            holder.binding.ivTab.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_bottom_tab_express_active))
        }else{
            holder.binding.ivTab.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_bottom_tab_express_inactive))
        }

        holder.binding.ivTab.setOnClickListener {
            onBottomTabSelected()
        }
    }

    inner class StoreServiceViewHolder(val binding: RecyclerItemBottomServiceLeafBinding) :
        RecyclerView.ViewHolder(binding.root)
}