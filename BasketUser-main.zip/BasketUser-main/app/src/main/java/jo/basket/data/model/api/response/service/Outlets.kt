package jo.basket.data.model.api.response.service

data class Outlets(
    val outlet_id: Int,
    val outlet_name: String
)