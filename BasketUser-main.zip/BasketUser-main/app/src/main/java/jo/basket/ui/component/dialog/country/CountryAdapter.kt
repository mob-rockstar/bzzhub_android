package jo.basket.ui.component.dialog.country

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import jo.basket.R
import jo.basket.data.model.Country
import jo.basket.databinding.RecyclerItemCountryNewBinding
import jo.basket.ui.accountsetting.countrysetting.CountrySettingsAdapter
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter

class CountryAdapter (private val onItemSelected: (country: Country) -> Unit) :
    BaseRecyclerViewAdapter<Country, RecyclerItemCountryNewBinding>() {

    override val layoutId: Int
        get() = R.layout.recycler_item_country_new

    var selectedListener: CountrySettingsAdapter.OnCountrySelectListener? = null


    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return CountryViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as CountryViewHolder

        // Set Country Name
        holder.binding.tvCountry.text = items[position].countryName
        holder.itemView.setOnClickListener {
            onItemSelected(items[position])
        }
    }

    inner class CountryViewHolder(val binding: RecyclerItemCountryNewBinding) :
        RecyclerView.ViewHolder(binding.root)

}