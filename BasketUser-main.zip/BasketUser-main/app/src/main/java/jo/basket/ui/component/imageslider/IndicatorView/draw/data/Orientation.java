package jo.basket.ui.component.imageslider.IndicatorView.draw.data;

public enum Orientation {HORIZONTAL, VERTICAL}
