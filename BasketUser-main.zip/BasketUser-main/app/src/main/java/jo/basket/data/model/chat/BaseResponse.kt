package jo.basket.data.model.chat

import com.google.gson.JsonElement
import com.google.gson.JsonNull
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

open class BaseResponse {

    @SerializedName("error")
    @Expose
    var error: Boolean = false

    @SerializedName("message")
    @Expose
    var message: String? = null

    @SerializedName("payload")
    @Expose
    var payload: JsonElement = JsonNull()

}