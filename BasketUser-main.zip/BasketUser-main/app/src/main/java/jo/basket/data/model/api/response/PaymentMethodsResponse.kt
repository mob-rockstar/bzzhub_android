package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.AvailablePaymentMethod
import jo.basket.data.model.PaymentMethod


class PaymentMethodsResponse {

    @field:SerializedName("httpCode")
    val code: Int = 0

    @field:SerializedName("Message")
    val message: String? = null

    @field:SerializedName("available_payment_methods")
    var availablePaymentMethods: List<AvailablePaymentMethod>? = null

    @field:SerializedName("payment_method_list")
    var paymentMethods: List<PaymentMethod>? = null

}