package jo.basket.data.model

import com.google.gson.annotations.SerializedName

class PickupServiceAvailability {

    @field:SerializedName("is_pickup_service_enable")
    var isPickupServiceEnable: Int? = 0

    @field:SerializedName("demand_on_pickup_service_text")
    var demandOnPickupServiceText: String? = ""

    @field:SerializedName("pickup_service_text_subtitle")
    var subTitle: String? = ""

}