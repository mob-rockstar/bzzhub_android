package jo.basket.data.model.pricingmodel


import com.google.gson.annotations.SerializedName

data class OutletOpeningHours(
    @SerializedName("outlet_margin_info")
    var outletMarginInfo: String,
    @SerializedName("store_hours")
    var storeHours: List<StoreHour>
)