package jo.basket.ui.cart

import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import jo.basket.data.local.db.RealmManager
import jo.basket.data.local.prefs.PreferenceManager
import jo.basket.data.model.Cart
import jo.basket.data.model.CartDelivery
import jo.basket.data.model.Product
import jo.basket.data.model.Store
import jo.basket.data.model.api.response.*
import jo.basket.data.remote.APIManager
import jo.basket.ui.base.BaseViewModel
import jo.basket.ui.base.HandleResponse
import jo.basket.utils.AppConstants
import jo.basket.utils.ConverterUtils
import jo.basket.utils.MessageEvent
import jo.basket.utils.analytics.BasketAnalyticsManager
import org.greenrobot.eventbus.EventBus
import timber.log.Timber


class CartViewModel : BaseViewModel() {

    var cartDeliveries: List<CartDelivery>? = null
    var isFoodRunning = false

    // Get product counts from cart
    fun getCartCount() {
        compositeDisposable.add(APIManager.getCartCount()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        PreferenceManager.userCartCount = result.cartCount
                    }
                }, { x ->
                    Timber.tag("getCartCount").d(x)
                }
            )
        )
    }

    // Get information of personal cart
    fun getMyCart(storeId: Int , isLoading: Boolean, handleResponse: HandleResponse<MyCartResponse>) {
        setIsLoading(isLoading)
        compositeDisposable.add(APIManager.getMyCart(storeId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }
    fun getStoreAllMyCart(serviceId: String , isLoading: Boolean, handleResponse: HandleResponse<StoreMyCartResponse>) {
        setIsLoading(isLoading)
        compositeDisposable.add(APIManager.getStoreAllMyCart(serviceId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    //Remove cart item (by store Unit)
    fun removeCart(cart: Cart, handleResponse: HandleResponse<SimpleResponse>) {
        setIsLoading(true)
        compositeDisposable.add(APIManager.removeCart(cart.storeId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                        getCartCount()
                        if (!cart.products.isNullOrEmpty())
                            for (product in cart.products!!) {
                                product.cartQty = 0.0
                                updateLocalProduct(product)
                            }
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    // Add product to cart
    fun addToCart(
        product: Product,
        amount: Double,
        handleResponse: HandleResponse<AddCartResponse>
    ) {
        if (amount == 0.0){
            BasketAnalyticsManager.removeItemFromCartNew(
                RealmManager.getLocalStore(product.outletId ?: 0)?.outletName ?: "",
                product.name ?: "", 0
            )
        }else{
            BasketAnalyticsManager.addToCartNew(product, amount, "Cart",
                if (product.display_saving_per_unit != null && product.display_saving_per_unit!!.isNotEmpty()) 1 else 0)
        }
        compositeDisposable.add(APIManager.addToCart(
            product.outletId!!,
            product.outletItemId!!,
            product.cartNotes,
            amount,
            product.vendorId!!,
            product.cartDetailId ?: 0,
            product.customAdditionalQuestion ?: ""
        )
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                        getCartCount()
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    // Add product to cart
    fun updateToCart(
        product: Product,
        amount: Double, vendorId: Int,
        handleResponse: HandleResponse<AddCartResponse>
    ) {
        if (amount == 0.0){
            BasketAnalyticsManager.removeItemFromCartNew(
                RealmManager.getLocalStore(product.outletId ?: 0)?.outletName ?: "",
                product.name ?: "", 0
            )
        }else{
            BasketAnalyticsManager.addToCartNew(product, amount, "Cart",
                if (product.display_saving_per_unit != null && product.display_saving_per_unit!!.isNotEmpty()) 1 else 0)
        }
        compositeDisposable.add(APIManager.updateCartQty(
            product.outletId!!,
            product.outletItemId!!,
            product.cartNotes,
            amount, product.cartDetailId ?: 0,
            product.customAdditionalQuestion ?: "", vendorId
        )
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                        getCartCount()
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    // Remove item from cart (By product unit)
    fun removeProductFromCart(product: Product , handleResponse: HandleResponse<SimpleResponse>) {
        setIsLoading(true)
        compositeDisposable.add(APIManager.removeProductFromCart(product.cartDetailId!!)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        handleResponse.handleSuccessRespons(result)
                        product.cartQty = 0.0
                        updateLocalProduct(product)
                        getCartCount()
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

/*
    // Get delivery slots
    fun getDeliverySlots(handleResponse: HandleResponse<DeliverySlotsResponse>) {
        setIsLoading(true)
        compositeDisposable.add(APIManager.getDeliverySlots()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        cartDeliveries = ConverterUtils.getTodayDeliverySlot(result)
                        //         deliverySlots = result.storeDeliverySlots
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }
*/

    // Update product information from Local DB
    fun updateLocalProduct(product: Product) {
        if (product.cartQty == 0.0) product.cartNotes = ""
        RealmManager.setLocalProduct(product)
        EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_PRODUCT_CHANGED, product))
    }

    //Add items from cart (For particular store) to Order
    fun addCartItemsToOrder(
        storeId: Int,
        orderStoreId: Int,
        handleResponse: HandleResponse<SimpleResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.add(APIManager.addCartItemsToOrder(storeId, orderStoreId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    // Get Membership Details
    fun getMembershipDetails(handleResponse: HandleResponse<UserMembershipDetailResponse>) {
        setIsLoading(true)
        compositeDisposable.add(APIManager.getUserMembershipDetails()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            )
        )
    }

    fun getLocalStore(storeId: Int): Store? {
        val store = RealmManager.getLocalStore(storeId)
        if (store == null) setIsLoading(true)

        return store
    }

    // Get Order Detail
    fun getOrderDetail(
        orderId: Int,
        orderStoreId: Int,
        handleResponse: HandleResponse<OrderDetailResponse>
    ) {

        //  setIsLoading(true)
        compositeDisposable.add(APIManager.getOrderDetail(orderId, orderStoreId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        //      setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        //       setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

}