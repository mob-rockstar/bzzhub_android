package jo.basket.data.model.api.response.service

data class ServiceListResponse(
    val data: ServiceListData,
    val message: String,
    val status: Int
)