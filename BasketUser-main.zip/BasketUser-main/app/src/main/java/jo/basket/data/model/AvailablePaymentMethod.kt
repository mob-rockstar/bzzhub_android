package jo.basket.data.model

import com.google.gson.annotations.SerializedName


class AvailablePaymentMethod {

    @field:SerializedName("type")
    var type: Int? = null

    @field:SerializedName("payment_mode")
    var paymentMode: Int? = null

}