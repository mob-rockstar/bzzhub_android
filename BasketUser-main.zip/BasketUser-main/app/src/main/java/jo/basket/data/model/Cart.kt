package jo.basket.data.model

import com.google.gson.GsonBuilder
import com.google.gson.JsonElement
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


open class Cart {

    @SerializedName("top_selling_items")
    @Expose
    var topSellingItems: List<Product>? = null

    @SerializedName("outlet_id")
    @Expose
    var storeId: Int = 0

    @SerializedName("vendor_id")
    @Expose
    var vendorId: Int? = null

    @SerializedName("delivery_date")
    @Expose
    var deliveryDate: String? = null

    @SerializedName("delivery_time")
    @Expose
    var deliveryTime: String? = null

    @SerializedName("delivery_label")
    @Expose
    var deliveryLabel: String? = null

    @SerializedName("delivery_slot_time_id")
    @Expose
    var deliverySlotTimeId: Int? = null

    @SerializedName("product_lsit")
    @Expose
    var products: List<Product>? = null

    @SerializedName("orders_outlets_id")
    @Expose
    var ordersOutletsId: Int? = null

    @SerializedName("outlet_name")
    @Expose
    var outletName: String? = null

    @SerializedName("display_name")
    @Expose
    var displayName: String? = null

    @SerializedName("is_grid_view")
    @Expose
    var isGridView: Int?= null

    @SerializedName("updated_date")
    @Expose
    var updatedDate: String? = null

    @SerializedName("logo_image")
    @Expose
    var logoImage: String? = null

    @SerializedName("outlet_delivery_settings")
    @Expose
    var outletDeliverySettings: OutletDeliverySettings? = null

    @SerializedName("next_delivery_time_slot")
    @Expose
    var nextDeliveryTimeSlot: JsonElement? = null

    @SerializedName("incentivizing_discount_basket_size")
    @Expose
    var incentivizingDiscountBasketSize: String? = null

    @SerializedName("incentivizing_discount")
    @Expose
    var incentivizing_discount: Double? = null

    @SerializedName("order_id")
    @Expose
    var orderId: Int? = null


    @SerializedName("outlet_subtotal")
    @Expose
    var outletSubtotal: Double? = null

    @SerializedName("outlet_promo_code_amount")
    @Expose
    var outletPromoCodeAmount: Double? = null

    @SerializedName("outlet_total_delivery_fee")
    @Expose
    var outletTotalDeliveryFee: Double? = null

    @SerializedName("outlet_basic_plus_under_threshold")
    @Expose
    var outletBasicPlusUnderThreshold: Double? = null

    @SerializedName("outlet_one_hour_delivery_fee")
    @Expose
    var outletOneHourDeliveryFee: String? = null

    @SerializedName("outlet_under_threshold_fee")
    @Expose
    var outletUnderThresholdFee: Double? = null

    @SerializedName("outlet_basic_delivery_fee")
    @Expose
    var outletBasicDeliveryFee: Double? = null

    @SerializedName("outlet_included_tax_amount")
    @Expose
    var outletIncludedTaxAmount: Double? = null

    @SerializedName("outlet_free_delivery_discount")
    @Expose
    var outletFreeDeliveryDiscount: Double? = null

    @SerializedName("outlet_service_tax")
    @Expose
    var outletServiceTax: Double? = null

    @SerializedName("outlet_total")
    @Expose
    var outletTotal: Double? = null

    @SerializedName("checkout_permission_details")
    @Expose
    var checkoutPermissionDetails: CheckoutPermissionDetails? = null

    @SerializedName("store_status")
    @Expose
    var storeStatus: String? = null

    @SerializedName("store_disabled")
    @Expose
    var storeDisabled: Int? = 0
    fun getNextDeliveryTime() : NextDeliveryTimeSlot?{
        if (nextDeliveryTimeSlot != null && nextDeliveryTimeSlot!!.isJsonObject) {
            return GsonBuilder().create()
                .fromJson(nextDeliveryTimeSlot, NextDeliveryTimeSlot::class.java)
        }

        return null
    }
}