package jo.basket.data.model

import com.google.gson.annotations.SerializedName

class PromotionDetails {

    @field:SerializedName("id")
    var id: String? = null

    @field:SerializedName("title")
    var title: String? = null

    @field:SerializedName("detail")
    var detail: String? = null

    @field:SerializedName("banner")
    var banner: String? = null

    @field:SerializedName("minimum_amount")
    var minimumAmount: Int? = null

    @field:SerializedName("threshold_amount")
    var thresholdAmount: Int? = null

    @field:SerializedName("threshold_detail")
    var thresholdDetail: String? = null

    @field:SerializedName("cart_price")
    var cartPrice: Double? = null

    @field:SerializedName("price_needed")
    var priceNeeded: Double? = null

    @field:SerializedName("per_done")
    var perDone: Double? = null

}