package jo.basket.ui.component.dialog.customersuggestion

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.Window
import androidx.databinding.DataBindingUtil
import jo.basket.R
import jo.basket.data.model.OrderProduct
import jo.basket.databinding.DialogCustomerSuggestionOrderBinding
import jo.basket.utils.AppConstants.CUSTOMER_SUGGESTION_TYPE_BEST_MATCH
import jo.basket.utils.AppConstants.CUSTOMER_SUGGESTION_TYPE_NOT_REPLACE
import jo.basket.utils.AppConstants.CUSTOMER_SUGGESTION_TYPE_PICK_REPLACEMENT
import jo.basket.utils.PopupUtils

//Dialog to give suggestion options to customer(Product Replacement Options)
class OrderSuggestion {

    fun openDialog(
        context: Context,
        product: OrderProduct,
        position: Int,
        listener: OnApplySuggestionListener?
    ) {
        val dialog = Dialog(context)
        val binding: DialogCustomerSuggestionOrderBinding = DataBindingUtil.inflate(
            LayoutInflater.from(context),
            R.layout.dialog_customer_suggestion_order,
            null,
            false
        )

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(binding.root)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        //To select option 'Best Match' option which Basket platform is suggesting
        binding.tvFindBestMatch.setOnClickListener {
            listener?.onReplaceItem(CUSTOMER_SUGGESTION_TYPE_BEST_MATCH, position, product)
            dialog.dismiss()
        }

        binding.ivClose.setOnClickListener { dialog.dismiss() }

        //Customer doesn't want replacement but only the original product
        binding.tvNotReplace.setOnClickListener {
            listener?.onReplaceItem(CUSTOMER_SUGGESTION_TYPE_NOT_REPLACE, position, product)
            dialog.dismiss()
        }

        //Customer want pick replacement option her/himself
        binding.tvSpecificReplacement.setOnClickListener {

            listener?.onReplaceItem(CUSTOMER_SUGGESTION_TYPE_PICK_REPLACEMENT, position, product)
            dialog.dismiss()
        }

        PopupUtils.setDefaultDialogProperty(dialog)
        dialog.show()
    }

    companion object {
        private var instance: OrderSuggestion? = null
        private val Instance: OrderSuggestion
            get() {
                if (instance == null) {
                    instance = OrderSuggestion()
                }
                return instance!!
            }

        fun openDialog(
            context: Context,
            product: OrderProduct,
            position: Int,
            listener: OnApplySuggestionListener
        ) {
            Instance.openDialog(context, product, position, listener)
        }
    }

    interface OnApplySuggestionListener {
        fun onReplaceItem(suggestionType: Int, position: Int, product: OrderProduct)
    }
}