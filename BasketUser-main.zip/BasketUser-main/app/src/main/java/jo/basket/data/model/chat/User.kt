package jo.basket.data.model.chat

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

open class User {

    @SerializedName("user_id")
    @Expose
    var id: String = ""

    @SerializedName("user_type")
    @Expose
    var type: String? = null

    @SerializedName("user_name")
    @Expose
    var userName: String? = null

    @SerializedName("user_photo")
    @Expose
    var image: String? = null

    companion object {
        const val TYPE_SYSTEM = "system"
        const val TYPE_SHOPPER = "shopper"
        const val TYPE_CUSTOMER = "customer"
    }

}