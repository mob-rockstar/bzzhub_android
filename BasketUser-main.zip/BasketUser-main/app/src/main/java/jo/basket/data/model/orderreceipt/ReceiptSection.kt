package jo.basket.data.model.orderreceipt


import com.google.gson.annotations.SerializedName

open class ReceiptSection {

    @SerializedName("type_name")
    var typeName: String? = null

    @SerializedName("type_label")
    var typeLabel: String? = null

    @SerializedName("type_id")
    var typeId: Int? = null

    @SerializedName("product_list")
    var productList: List<ReceiptProduct>? = null

}