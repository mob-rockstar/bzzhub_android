package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.realm.RealmList
import io.realm.RealmObject
import io.realm.annotations.PrimaryKey

open class City : RealmObject() {
    var areas: RealmList<Area> = RealmList<Area>()

    @PrimaryKey
    @SerializedName("city_id")
    @Expose
    var id: Int = 0

    @SerializedName("country_id")
    @Expose
    var countryId: Int? = null

    @SerializedName("city_name")
    @Expose
    var cityName: String? = null

    @SerializedName("country_name")
    @Expose
    var countryName: String? = null

    @SerializedName("created_date")
    @Expose
    var createdDate: String? = null

    @SerializedName("updated_date")
    @Expose
    var updatedDate: String? = null
}