package jo.basket.ui.base

import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.databinding.ViewDataBinding
import jo.basket.utils.KeyboardUtils


abstract class BaseInputFragment<T : ViewDataBinding?, V : BaseViewModel?> : BaseFragment<T, V>() {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupKeyboardHidingListener(view)
    }

    open fun setupKeyboardHidingListener(view: View) {
        // Set up touch listener for non-text box views to hide keyboard.
        if (view !is EditText) {
            view.setOnTouchListener { _, _ ->
                KeyboardUtils.hideKeyboard(baseActivity)
                false
            }
        }

        //If a layout container, iterate over children and seed recursion.
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                val innerView = view.getChildAt(i)
                setupKeyboardHidingListener(innerView)
            }
        }
    }
    
}