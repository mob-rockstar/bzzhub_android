package jo.basket.ui.checkout

import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import jo.basket.data.local.db.RealmManager
import jo.basket.data.local.prefs.PreferenceManager
import jo.basket.data.model.*
import jo.basket.data.model.api.response.*
import jo.basket.data.model.payfort.TokenResponse
import jo.basket.data.model.payment.PaymentListResponse
import jo.basket.data.remote.APIManager
import jo.basket.ui.base.BaseViewModel
import jo.basket.ui.base.HandleResponse
import jo.basket.utils.AppConstants
import jo.basket.utils.AppConstants.PAYMENT_PAGE_ID_CHECKOUT
import jo.basket.utils.MessageEvent
import jo.basket.utils.analytics.BasketAnalyticsManager
import org.greenrobot.eventbus.EventBus
import timber.log.Timber


class CheckoutViewModel : BaseViewModel() {

    var deliverySlots: List<StoreDeliverySlot>? = null
    var storeId = PreferenceManager.currentUserStoreId
    var countryList: List<Country> = ArrayList()
    var checkoutDetail: CheckoutResponse?= null
    var isFoodRunning = false

    fun getCountryWithId(countryId: Int) : Country?{
        var mCountry : Country? = null
        for (country in countryList){
            if (country.id == countryId){
                mCountry = country
                break
            }
        }
        return  mCountry
    }

    // Get checkout detail data
    fun getCheckoutDetail(isFromCart: Boolean,cartId:String, handleResponse: HandleResponse<CheckoutResponse>) {
        setIsLoading(true)
        compositeDisposable.add(APIManager.getCheckoutDetail(isFromCart, storeId, cartId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    // Get delivery slot
    fun getDeliverySlots(outletID: Int , handleResponse: HandleResponse<DeliverySlotsResponse>) {
        setIsLoading(true)
        compositeDisposable.add(APIManager.getDeliverySlots(outletID)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        deliverySlots = result.storeDeliverySlots
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    // Update delivery instruction
    fun updateDeliveryInstruction(instruction: String) {
        setIsLoading(true)
        compositeDisposable.add(APIManager.updateDeliveryInstruction(instruction)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { },
                { x ->
                    Timber.tag("deliveryInstruction").d(x)
                }
            ))
    }

    // Pay to order with credit card
    fun queryOnlinePayment(
        countryId: Int, cityId: Int, paymentId: Int, cardId: Int, instruction: String, cvv: String,
        adjustIdType: String,
        adjustIDValue: String,
        adjustADID: String,
        shopperTipAmount: Float,
        handleResponse: HandleResponse<OnlinePaymentResponse>
    ) {
        compositeDisposable.add(APIManager.queryOnlinePayment(
            countryId,
            cityId,
            paymentId,
            cardId,
            instruction,
            cvv,
            adjustIdType,
            adjustIDValue,
            adjustADID,
            shopperTipAmount
        )
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    // Place order with 'Cash On Delivery' option
    fun offlinePayment(
        countryId: Int,
        cityId: Int,
        paymentId: Int,
        instruction: String,
        adjustIdType: String,
        adjustIdValue: String,
        adjustADID: String,
        handleResponse: HandleResponse<SimpleResponse>
    ) {

        compositeDisposable.add(APIManager.offlinePayment(countryId, cityId, paymentId, instruction,
            adjustIdType,
            adjustIdValue,
            adjustADID,
        )
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {

                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            )
        )
    }

    fun expressCapacity(
        outletID: Int,
        handleResponse: HandleResponse<SimpleResponse>){
        compositeDisposable.add(APIManager.expressCapacity(outletID)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {

                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            )
        )
    }

    //Update delivery address
    fun updateDeliveryAddress(addressId: Int, handleResponse: HandleResponse<SimpleResponse>) {
        setIsLoading(true)
        compositeDisposable.add(APIManager.updateDeliveryAddress(addressId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    // Update delivery slot
    fun updateDeliverySlot(
        storeId: Int,
        deliveryDay: String,
        deliverySlotTimeId: Int,
        deliveryTime: String,
        handleResponse: HandleResponse<SimpleResponse>
    ) {
        setIsLoading(true)

        compositeDisposable.add(APIManager.updateDeliverySlot(
            storeId,
            deliveryDay,
            deliverySlotTimeId,
            deliveryTime
        )
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    // Add promo code to cart
    fun addPromoCodeToCart(promoCode: String, handleResponse: HandleResponse<SimpleResponse>) {
        setIsLoading(true)
        compositeDisposable.add(APIManager.addPromoCodeToCart(promoCode)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    // Remove promo code from cart
    fun removePromoFromCart(handleResponse: HandleResponse<SimpleResponse>) {
        setIsLoading(true)
        compositeDisposable.add(APIManager.removePromoFromCart()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    // Get Payment Method List
    fun getPaymentMethods(pageId: Int, handleResponse: HandleResponse<PaymentMethodsResponse>) {
        setIsLoading(true)
        compositeDisposable.add(APIManager.getPaymentMethods(pageId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    // Update Payment Method
    fun updatePaymentMethod(
        paymentId: Int,
        cardId: Int?,
        handleResponse: HandleResponse<SimpleResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.add(APIManager.updatePaymentMethod(paymentId, cardId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }


    // Add Credit Card
    fun addCreditCard(
        fortData: Map<String, Any>,
        storeId: Int,
        paymentId: Int,
        handleResponse: HandleResponse<CreditCardResponse>
    ) {
        val cardNumber = fortData["card_number"] as String?
        val merchantReference = fortData["merchant_reference"] as String?
        val tokenName = fortData["token_name"] as String?
        var cardHolderName: String? = null
        cardHolderName =
            if (fortData.containsKey("card_holder_name")) fortData["card_holder_name"] as String?
            else ""
        val paymentOption = fortData["payment_option"] as String?
        val responseCode = fortData["response_code"] as String?
        val responseMessage = fortData["response_message"] as String?
        val expiryDate = fortData["expiry_date"] as String?
        val serviceCommand = fortData["command"] as String?
        val sdkToken = fortData["sdk_token"] as String?

        val fortId = fortData["fort_id"] as String?

        setIsLoading(true)
        compositeDisposable.add(APIManager.addCreditCard(
            cardNumber!!,
            merchantReference!!,
            tokenName!!,
            cardHolderName!!,
            paymentOption!!,
            responseCode!!,
            responseMessage!!,
            expiryDate!!,
            serviceCommand!!,
            fortId!!,
            sdkToken!!,
            PAYMENT_PAGE_ID_CHECKOUT,
            storeId,
            paymentId
        )
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }


    // Add product to cart
    fun addToCart(
        product: Product,
        amount: Double,
        handleResponse: HandleResponse<AddCartResponse>
    ) {
        if (amount == 0.0){
            BasketAnalyticsManager.removeItemFromCartNew(
                RealmManager.getLocalStore(product.outletId ?: 0)?.outletName ?: "",
                product.name ?: "", 0
            )
        }else{
            BasketAnalyticsManager.addToCartNew(product, amount, "Cart",
                if (product.display_saving_per_unit != null && product.display_saving_per_unit!!.isNotEmpty()) 1 else 0)
        }
        compositeDisposable.add(APIManager.addToCart(
            product.outletId!!,
            product.outletItemId!!,
            product.cartNotes,
            amount,
            product.vendorId!!,
            product.cartDetailId ?: 0,
            product.customAdditionalQuestion ?: ""
        )
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                        getCartCount()
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }


    // Remove item from cart (By product unit)
    fun removeProductFromCart(product: Product, handleResponse: HandleResponse<SimpleResponse>) {
        compositeDisposable.add(APIManager.removeProductFromCart(product.cartDetailId!!)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        product.cartQty = 0.0
                        updateLocalProduct(product)
                        EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_PRODUCT_CHANGED))
                        handleResponse.handleSuccessRespons(result)
                        getCartCount()
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    // Get Payment Method List
    fun getPaymentMethodNew(pageId: Int, handleResponse: HandleResponse<PaymentListResponse>) {
        setIsLoading(true)
        compositeDisposable.add(APIManager.getNewPaymentMethods(PreferenceManager.currentUserCountryId, pageId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    // Get product counts from cart
    fun getCartCount() {
        compositeDisposable.add(APIManager.getCartCount()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        PreferenceManager.userCartCount = result.cartCount
                    }
                }, { x ->
                    Timber.tag("getCartCount").d(x)
                }
            )
        )
    }

    // Update product information from Local DB
    fun updateLocalProduct(product: Product, toUpdateProductList: Boolean = true) {
        if (product.cartQty == 0.0) product.cartNotes = ""
        RealmManager.setLocalProduct(product)
        EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_PRODUCT_CHANGED, product))
    }

    
    fun getLocalPayfortToken(deviceID: String, handleResponse: HandleResponse<PayfortTokenResponse>){
        compositeDisposable.addAll(APIManager.getLocalPayfortToken(deviceID)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            )
        )
    }

    // Get country List of users
    fun getCountryList(handleResponse: HandleResponse<CountrySettingResponse>) {
        setIsLoading(true)
        compositeDisposable.add(APIManager.getCountryList()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        countryList = result.countryList ?: ArrayList()
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    // Add product to cart
    fun updateToCart(
        product: Product,
        amount: Double,
        vendorId: Int,
        handleResponse: HandleResponse<AddCartResponse>
    ) {
        if (amount == 0.0){
            BasketAnalyticsManager.removeItemFromCartNew(
                RealmManager.getLocalStore(product.outletId ?: 0)?.outletName ?: "",
                product.name ?: "", 0
            )
        }else{
            BasketAnalyticsManager.addToCartNew(product, amount, "Cart",
                if (product.display_saving_per_unit != null && product.display_saving_per_unit!!.isNotEmpty()) 1 else 0)
        }
        compositeDisposable.add(APIManager.updateCartQty(
            product.outletId!!,
            product.outletItemId!!,
            product.cartNotes,
            amount, product.cartDetailId ?: 0,
            product.customAdditionalQuestion?: "", vendorId,
        )
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                        getCartCount()
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    fun getOrderDetail(
        orderId: Int,
        orderStoreId: Int,
        handleResponse: HandleResponse<OrderDetailResponse>
    ) {

        //  setIsLoading(true)
        compositeDisposable.add(APIManager.getOrderDetail(orderId, orderStoreId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        //      setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        //       setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    fun addSecondaryMobile(
        mobileNumber: String,
        handleResponse: HandleResponse<AddSecondaryMobile>,
    ) {
        compositeDisposable.add(APIManager.addSecondaryMobile(
            mobileNumber,
        )
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    fun verifySecondaryMobile(
        mobileNumber: String,
        otp: String,
        handleResponse: HandleResponse<VerifyMobileResponse>,
    ) {
        compositeDisposable.add(APIManager.verifySecondaryMobile(
            mobileNumber,
            otp,
        )
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }
}