package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.PopupDetails
import jo.basket.data.model.api.response.base.BaseResponse


class MaintenanceResponse : BaseResponse() {

    @field:SerializedName("under_construction")
    val underConstruction: Int? = 0

    @field:SerializedName("refresh_delay")
    val refreshDelay: Int? = 0

    @field:SerializedName("popup_details")
    val popupDetails: PopupDetails? = null

}