package jo.basket.ui.component.dialog.sortNfilter

import android.util.SparseBooleanArray
import android.view.ViewGroup
import androidx.core.util.set
import androidx.recyclerview.widget.RecyclerView
import jo.basket.R
import jo.basket.data.model.Brand
import jo.basket.databinding.RecyclerItemProductFilterBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter

class BrandFilterAdapter : BaseRecyclerViewAdapter<Brand, RecyclerItemProductFilterBinding>() {

    private val brands: ArrayList<Brand> = ArrayList()
    private val selectedStates = SparseBooleanArray()

    private var onChangeFilterListener: OnChangeFilterListener? = null

    val selectedBrands: ArrayList<Brand>
        get() {
            val array = ArrayList<Brand>()
            for (i in brands.indices) {
                if (selectedStates[i]) {
                    array.add(brands[i])
                }
            }

            return array
        }

    fun setSelectedBrands(selectedBrands: ArrayList<Brand>){
        selectedStates.clear()
        for (i in selectedBrands.indices){
            selectedStates[brands.indexOf(selectedBrands[i])] = true
        }
        notifyDataSetChanged()
    }

    private var isExpanded: Boolean = false

    override val layoutId: Int
        get() = R.layout.recycler_item_product_filter

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return BrandFilterViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as BrandFilterViewHolder
        val brand = items[position]

        // Brand Name
        holder.binding.tvBrand.text = brand.title?.trim()
        holder.binding.ivCheckbox.setImageResource(if (selectedStates[position]) R.drawable.ic_checkbox_checked else R.drawable.ic_checkbox)

        holder.binding.layoutFilter.setOnClickListener {
            if (selectedStates[position]) {
                selectedStates[position] = false
                holder.binding.ivCheckbox.setImageResource(R.drawable.ic_checkbox)
            } else {
                selectedStates[position] = true
                holder.binding.ivCheckbox.setImageResource(R.drawable.ic_checkbox_checked)
            }
            onChangeFilterListener?.onChange(position)
        }
    }

    fun setBrands(brandList: List<Brand>) {
        brands.clear()
        items.clear()
        selectedStates.clear()
        brands.addAll(brandList)
    }

    fun setOnChangeFilterListener(listener: OnChangeFilterListener) {
        onChangeFilterListener = listener
    }

    //init brand filter list, if expanded, no limit for count, if collapsed, count limit should be 3
    fun init() {
        items.clear()
        isExpanded = if (brands.size > 3) {
            items.addAll(brands.subList(0, 3))
            false
        } else {
            items.addAll(brands)
            true
        }
        notifyDataSetChanged()
    }

    //Expand brand list
    fun expand() {
        if (!isExpanded) {
            isExpanded = true
            items.clear()
            items.addAll(brands)
            notifyDataSetChanged()
        }
    }

    fun collapse() {
        if (isExpanded && brands.size > 3) {
            isExpanded = false
            items.clear()
            items.addAll(brands.subList(0, 3))
            notifyDataSetChanged()
        }
    }

    fun resetFilters() {
        selectedStates.clear()
        notifyDataSetChanged()
    }

    inner class BrandFilterViewHolder(val binding: RecyclerItemProductFilterBinding) :
        RecyclerView.ViewHolder(binding.root)


    interface OnChangeFilterListener {
        fun onChange(position: Int)
    }
}