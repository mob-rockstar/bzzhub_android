package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.HintSuggestion
import jo.basket.data.model.RecentSearch

data class HintSuggestionResponse(
    @field:SerializedName("data") var data : ArrayList<HintSuggestion>,
    @field:SerializedName("user_search") var userSearch: ArrayList<RecentSearch>)