package jo.basket.ui.cart.main

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.Window
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import de.hdodenhof.circleimageview.CircleImageView
import jo.basket.R
import jo.basket.data.local.db.RealmManager
import jo.basket.data.local.prefs.PreferenceManager
import jo.basket.data.model.Cart
import jo.basket.data.model.CheckoutPermissionDetails
import jo.basket.data.model.Product
import jo.basket.data.model.Store
import jo.basket.data.model.api.response.*
import jo.basket.data.model.api.response.base.ErrorResponse
import jo.basket.databinding.FragmentCartMainBinding
import jo.basket.di.Injectable
import jo.basket.ui.base.BaseFragment
import jo.basket.ui.base.HandleResponse
import jo.basket.ui.cart.CartActivity
import jo.basket.ui.cart.CartViewModel
import jo.basket.ui.checkout.CheckoutActivity
import jo.basket.ui.deliverypricing.DeliveryTimeActivity
import jo.basket.ui.membership.MembershipActivity
import jo.basket.ui.order.shopping.ShoppingFragment
import jo.basket.ui.product.ProductActivity
import jo.basket.utils.*
import jo.basket.utils.analytics.BasketAnalyticsManager
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.text.DecimalFormat


// Main Fragment of Cart Module
class CartMainFragment(

) : BaseFragment<FragmentCartMainBinding?, CartViewModel>(),
    Injectable {

    private var isValid: Boolean = false
    private var isEmpty: Boolean = false

    private val adapter: CartStoresAdapter = CartStoresAdapter()
    private val carts: ArrayList<Cart> = ArrayList()
    private val allCarts: ArrayList<Outlet> = ArrayList()
    var outlet:Outlet = Outlet()
    private var existingStoreId = 0
    private var existingOrderStoreId = 0
    private var response: MyCartResponse? = null

    override val layoutId: Int
        get() = R.layout.fragment_cart_main

    override val viewModel: CartViewModel
        get() {
            return getViewModel(baseActivity, CartViewModel::class.java)
        }

    // prevent double tapping variables
    private var lastClickTime: Long = 0

    private var isFirstOpen = true
    private var isMembershipAPICalled = false
    private var productName = ""
    private var store: Store? = null


    private val POPUP_DELAY_TIME: Long = 600
    private val handler = Handler(Looper.getMainLooper())
    private var mRunnable = Runnable { getMyCart(PreferenceManager.currentUserStoreId) }

    private var TO_FINISH_CART = false
    private var minOrderAmount = 0.0
    var isSecondImage = false


    private var yourStringData: String?= null
 private var cartImage1: CircleImageView?= null
 private var cartImage2: CircleImageView?= null
 private var view1: View?= null
 private var view2: View?= null
 private var secondItem: LinearLayout?= null
 private var textAllCart: TextView?= null
 private var allCartLayout: LinearLayout?= null
 private var tvTitle: TextView?= null
 private var cartImageLayout: LinearLayout?= null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        store = viewModel.getLocalStore(PreferenceManager.currentUserStoreId)

        if (yourStringData.equals("1")){
            cartImage1!!.visibility = VISIBLE
            view2!!.visibility = GONE
            view1!!.visibility = GONE
            cartImage2!!.visibility = GONE
            allCartLayout!!.visibility = GONE
        }else{

        }

        Log.d("TAG", "onViewCreated: "+AppConstants.selectedService!!.id + " "+PreferenceManager.currentUserStoreId)

        if (AppConstants.selectedService!!.id ==3 || AppConstants.selectedService!!.id ==2 || AppConstants.selectedService!!.id ==6 )
        {
            if (PreferenceManager.currentUserStoreId == 499){
                cartImageLayout!!.visibility = GONE
                tvTitle!!.visibility = VISIBLE
                tvTitle!!.setTextColor(resources.getColor(R.color.md_white_1000))
            }else{
                cartImageLayout!!.visibility = VISIBLE
                tvTitle!!.visibility = GONE
                tvTitle!!.setTextColor(resources.getColor(R.color.md_white_1000))
            }

        }
        getStoreAllMyCart(AppConstants.selectedService!!.id.toString(),PreferenceManager.currentUserStoreId, true)

        initRecyclerView()
        initListeners()

        getMembershipDetails()


//        val layoutParams = cartImage1.layoutParams as LinearLayout.LayoutParams
//
//        val leftMarginInPixels = 10
//
//        layoutParams.setMargins(
//            leftMarginInPixels,
//            layoutParams.topMargin,
//            layoutParams.rightMargin,
//            layoutParams.bottomMargin
//        )

//        cartImage1.layoutParams = layoutParams





        cartImage1!!.setOnClickListener {

            isSecondImage = false
            viewDataBinding?.progressBar?.visibility = VISIBLE

            getMyCart(PreferenceManager.currentUserStoreId, true)
            EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_DATA_CART_UPDATE,PreferenceManager.currentUserStoreId))
            if (yourStringData.equals("1")){
                view1!!.visibility = GONE
            }else{
                view1!!.visibility = GONE
                view2!!.visibility = GONE
            }

        }

        cartImage2!!.setOnClickListener {
         //   isSecondImage = true
//            PreferenceManager.currentUserStoreId = allCarts[1].outletId!!
         //   viewDataBinding?.progressBar?.visibility = VISIBLE
            getMyCart(allCarts[1].outletId!!, true)
        //    EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_DATA_CART_UPDATE,allCarts[1].outletId!!))
            view1!!.visibility = GONE
            view2!!.visibility = GONE
        }

        allCartLayout!!.setOnClickListener {
           // showDialogFragment(CartAllFragment())
        }
    }


    private fun getStoreAllMyCart(serviceId: String, storeID: Int, isLoading: Boolean? = false) {
        viewModel.getStoreAllMyCart(serviceId, isLoading ?: false, object : HandleResponse<StoreMyCartResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                viewDataBinding?.progressBar?.visibility = GONE
                viewDataBinding?.rvCartStores?.visibility = GONE
                (activity as CartActivity).viewDataBinding?.toolbar?.toolbar?.visibility = VISIBLE

                if (NetworkUtils.isNetworkConnected(baseActivity) && !(error?.message ?: "").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)) {
                    this@CartMainFragment.onError(error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE)
                } else {
                    NetworkUtils.showNoInternetDialog(
                        baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    getStoreAllMyCart(serviceId,storeID)
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(response: StoreMyCartResponse) {
                //    viewDataBinding?.progressBar?.visibility = GONE
                if (response.status == 200) {
                    Log.d("TAG", "getMyCart: 1")
                    if (response.status ==200 && response.data.isEmpty() && AppConstants.selectedService!!.id.toString() == "5"){
                        getMyCart(PreferenceManager.currentUserStoreId, false)
                    }else{
                        allCarts.apply {
                            clear()
                            addAll(response.data)
                        }
                        textAllCart!!.text = "All ${allCarts.size.toString()} cart"
                        if (allCarts.isNotEmpty()) {

                            dismissCartProgress()
                            if(allCarts.size >1){
                                for(i in 0 until  allCarts.size){
                                    Log.d("TAG", "handleSuccessRespons: "+allCarts[i].logoImage)
                                    Log.d("TAG", "handleSuccessRespons: "+allCarts[i].vendorId)
                                    Log.d("TAG", "handleSuccessRespons: "+allCarts[i].outletId)

                                    if(allCarts[i].outletId == storeID){

                                        Glide.with(requireActivity()).load(allCarts[i].logoImage).into(cartImage1!!)
                                        var first = allCarts[0]
                                        if(i != 0){
                                            allCarts.add(0,allCarts[i])
                                            allCarts.removeAt(i)
                                        }
                                        if(allCarts.size >2){
                                            //     allCartLayout.visibility = VISIBLE
                                        }
                                        if(yourStringData.equals("1")){
                                            //    allCartLayout.visibility = GONE
                                        }
                                        if(allCarts.size >=2){
                                            secondItem!!.visibility = VISIBLE
                                            if (i == 1){
                                                allCarts.removeAt(i)
                                                allCarts.add(i,first)

                                                //  Glide.with(requireActivity()).load(first.logoImage).into(cartImage2)
                                            }else{

                                                //  Glide.with(requireActivity()).load(allCarts[1].logoImage).into(cartImage2)
                                            }
                                        }else{
//                                        secondItem.visibility = GONE
//                                        cartImage2.visibility = GONE
                                        }
                                    }
                                }
                            }

                            else{
                                cartImageLayout!!.visibility = GONE
                                tvTitle!!.visibility = VISIBLE
                                tvTitle!!.setTextColor(resources.getColor(R.color.md_white_1000))
                            }

                        } else {
                            dismissCartProgress()
                            initEmptyCartUI()
                        }
                    }


                } else {
                    this@CartMainFragment.onError(
                        response.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                }

            }
        })
    }
    // Init Recyclerview details
    fun initRecyclerView() {

        viewDataBinding?.rvCartStores?.apply {
            setHasFixedSize(true)
            isNestedScrollingEnabled = false
            layoutManager = LinearLayoutManager(baseActivity)
            adapter = this@CartMainFragment.adapter
        }
    }

    fun initListeners() {

        // Listener for Cart Adapter
        adapter.setOnCartActionListener(object : CartStoresAdapter.OnCartActionListener {
            // Remove Cart Clicked (For each Store Cart)
            override fun onRemoveCart(cart: Cart) {
                if (SystemClock.elapsedRealtime() - lastClickTime > 1000) {
                    lastClickTime = SystemClock.elapsedRealtime()
                    removeCart(cart)
                }
            }

            // User Selected any product
            override fun onSelectProduct(product: Product) {
                if (SystemClock.elapsedRealtime() - lastClickTime > 1000) {
                    lastClickTime = SystemClock.elapsedRealtime()
                    //   if (store?.isGridView != 1) {
                    val intent = ProductActivity.newIntent(context, product)
                    startActivity(intent)
                    //    }
                }
            }

            // User tapped 'Instruction' for Product
            override fun onSelectProductInstruction(product: Product) {
                if (SystemClock.elapsedRealtime() - lastClickTime > 1000) {
                    lastClickTime = SystemClock.elapsedRealtime()
                    val intent = ProductActivity.newIntent(context, product, 0, true)
                    startActivity(intent)
                }
            }

            // User tapped 'Amount' view
            override fun onProductAmountChange(product: Product, amount: Double) {
                if (store?.isGridView == 1) {
                    updateCart(product, amount)
                } else {
                    addToCart(product, amount)
                }
            }

            // User Tapped 'Remove' view for Product
            override fun onRemoveProduct(product: Product) {
                if (SystemClock.elapsedRealtime() - lastClickTime > 1000) {
                    lastClickTime = SystemClock.elapsedRealtime()
                    removeProductFromCart(product)
                }
            }

            override fun onLogoSelected(cart: Cart) {
                if (SystemClock.elapsedRealtime() - lastClickTime > 1000) {
                    lastClickTime = SystemClock.elapsedRealtime()
                    finishActivity()
                }
            }

            // User Opened 'Next Delivery' for each Store Cart
            override fun onOpenNextDelivery(cart: Cart) {
                if (SystemClock.elapsedRealtime() - lastClickTime > 1000) {
                    lastClickTime = SystemClock.elapsedRealtime()
                    val intent = DeliveryTimeActivity.newIntent(baseActivity, cart.storeId)
                    startActivity(intent)
                }
            }
        })

        viewDataBinding?.ivClose?.setOnClickListener {
            viewDataBinding?.layoutMembership?.visibility = GONE
        }

        // User tapped 'Shop Now' button (This would be shown only if Cart is Empty)
        viewDataBinding?.btnShopNow?.setOnClickListener { finishActivity() }
        baseActivity.findViewById<ImageView>(R.id.iv_back).setOnClickListener { finishActivity() }

        // User Tapped 'Checkout' button
//        viewDataBinding?.layoutCheckout?.setOnClickListener {
//            if (SystemClock.elapsedRealtime() - lastClickTime > 1000) {
//                lastClickTime = SystemClock.elapsedRealtime()
//                checkout()
//            }
//        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        EventBus.getDefault().register(this)
    }

    override fun onDestroy() {
        if(isSecondImage){
            PreferenceManager.currentUserStoreId = allCarts[1].outletId!!
            EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_DATA_CART_UPDATE,allCarts[1].outletId!!))
        }
        EventBus.getDefault().unregister(this)
        super.onDestroy()
    }


    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        when (event.message) {
            AppConstants.MESSAGE_PRODUCT_CHANGED -> {
                //           getMyCart(PreferenceManager.currentUserStoreId)
            }

            AppConstants.MESSAGE_RESTART -> {
                finishActivity()
            }

            AppConstants.MESSAGE_FINISH_CART -> {
                TO_FINISH_CART = true
                finishActivity()
            }

            AppConstants.MESSAGE_COUNTRY_CHANGED -> {
                getMyCart(PreferenceManager.currentUserStoreId)
            }

            AppConstants.MESSAGE_RELOAD_CART -> {
                getMyCart(PreferenceManager.currentUserStoreId)
            }
            AppConstants.MESSAGE_SWITCH_CART -> {
                view1!!.visibility = GONE
                view2!!.visibility = GONE
                viewDataBinding?.progressBar?.visibility = GONE
                getStoreAllMyCart(AppConstants.selectedService!!.id.toString(),event.data as Int, true)
            }
        }
    }

    private fun onUpdateUI(cartResponse: MyCartResponse) {
        minOrderAmount = cartResponse.carts.first().outletDeliverySettings?.minOrderAmount ?: 0.0
        val isCheckoutEnabled =
            cartResponse.carts.isNotEmpty() && cartResponse.overallSubtotal!! < (cartResponse.carts.first().outletDeliverySettings?.minOrderAmount ?: 0.0)
    //    enableAmountView(isCheckoutEnabled)
        if (cartResponse.carts.isNullOrEmpty()) {
            initEmptyCartUI()


        } else {
            viewDataBinding?.layoutEmptyCart?.visibility = GONE
            viewDataBinding?.rvCartStores?.visibility = VISIBLE

            // SCROLL listener to close swipe

            isValid = true
            for (cart in cartResponse.carts) {
                val permissionDetails: CheckoutPermissionDetails? = cart.checkoutPermissionDetails
                if (permissionDetails != null && permissionDetails.checkoutPermission != 1
                ) {
                    isValid = false
                    break
                }
            }
            viewDataBinding?.tvAmount?.visibility = VISIBLE
            viewDataBinding?.tvAmount?.text = FormatterUtils.formatHTMLString(FormatterUtils.formatPrice(cartResponse.carts.first().outletSubtotal))

            val incentiveKey = (cartResponse.carts.first().incentivizingDiscountBasketSize ?: "0").toDouble()
            val cartValue = cartResponse.carts.first().outletSubtotal ?: 0.0

            val incentiveValue =
                if ((incentiveKey - cartValue) < 0.0) 0.0 else incentiveKey - cartValue

            viewDataBinding?.layoutAddMore?.visibility =
                if ((store?.isIncentivizingUsers ?: 0) != 0) {
                    viewDataBinding?.progressPromote?.progress =
                        ((cartValue / incentiveKey) * 100).toInt()
                    """${baseActivity.resources.getString(R.string.str_add)} ${
                        FormatterUtils.formatDouble(
                            incentiveValue,
                            2
                        )
                    } ${PreferenceManager.userCurrencyCode} ${
                        baseActivity.resources.getString(R.string.str_more_to_place_order)
                    }""".also { viewDataBinding?.tvAmountToAdd?.text = it }
                    VISIBLE
                } else {
                    GONE
                }
            enableAmountView(isValid)
        }
    }

    private fun enableAmountView(isCartValid: Boolean) {
        viewDataBinding?.apply {
            ivCheckout.visibility = if (isCartValid) View.VISIBLE else View.GONE

//            val buttonText = if (isEmpty) {
//
//                baseActivity.resources.getString(R.string.str_go_to_checkout)
//            } else {
//                baseActivity.resources.getString(
//                    R.string.str_not_reached_min_to_checkout,
//                    PreferenceManager.userCurrencyCode,
//                    DecimalFormat("#.##").format(minOrderAmount)
//                )
//            }
//            btCheckout.text = buttonText
            if (isEmpty) {
                baseActivity.resources.getString(R.string.str_go_to_checkout)

            } else{
                baseActivity.resources.getString(
                    R.string.str_not_reached_min_to_checkout,
                    PreferenceManager.userCurrencyCode,
                    DecimalFormat("#.##").format(minOrderAmount))
                /*   String.format(
                       Locale.US, "%.1f", minOrderAmount
                   )*/
            }
            btCheckout.text =
                if (isEmpty || isCartValid) {
                    baseActivity.resources.getString(R.string.str_go_to_checkout)

                } else{
                    baseActivity.resources.getString(
                        R.string.str_not_reached_min_to_checkout,
                        PreferenceManager.userCurrencyCode,
                        DecimalFormat("#.##").format(minOrderAmount))
                    /*   String.format(
                           Locale.US, "%.1f", minOrderAmount
                       )*/
                }
            val backgroundDrawableRes = if (isCartValid) {
                R.drawable.bg_round_green_8dp
            } else {
                R.drawable.bg_round_grey_8dp
            }

            layoutCheckout.apply {
                background = ContextCompat.getDrawable(baseActivity, backgroundDrawableRes)
                isClickable = isCartValid
                isEnabled = isCartValid
                setOnClickListener {
                    if (backgroundDrawableRes == R.drawable.bg_round_green_8dp) {
                        checkout()
                    } else {
                        // Handle click action when background is grey
                    }
                }
            }

            tvAmount.backgroundTintList = ContextCompat.getColorStateList(
                baseActivity,
                if (isCartValid) R.color.primary else R.color.grey_a44
            )
        }
    }


    // Checkout
    private fun checkout() {
        if (store?.serviceTypeId == 1 && store?.isGridView == 0) {
            for (cart in carts) {
                if (cart.ordersOutletsId != null && cart.ordersOutletsId!! > 0) {
                    existingStoreId = cart.storeId
                    existingOrderStoreId = cart.ordersOutletsId!!
                    // In-completed order from same store is existing
                    showExistingOrderDialog(cart.displayName ?: "")
                    return
                }
            }
            goToCheckout()
        } else {
            goToCheckout()
        }
    }

    // Show suggestion dialog to add all cart items to existing order
    private fun showExistingOrderDialog(storeName: String) {
        val dialog = Dialog(baseActivity)
        val view = LayoutInflater.from(baseActivity).inflate(R.layout.dialog_order_exist_new, null)

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(view)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val layoutOutside = view.findViewById<LinearLayoutCompat>(R.id.layout_outside)

        val tvContent = view.findViewById<TextView>(R.id.tv_error_message)
        tvContent.text = resources.getString(R.string.error_existing_order, storeName)

        val tvAddItem = view.findViewById<TextView>(R.id.tv_add_item)
        // Add All Items to existing order
        tvAddItem.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime > 1000) {
                lastClickTime = SystemClock.elapsedRealtime()
                productName = ""
                for (cart in carts) {
                    for (mProduct in cart.products!!) {
                        productName += mProduct.name + ", "
                    }
                }
                productName = StringUtils.removeLastCharacter(productName)
                addAllItemsToOrder()
                dialog.dismiss()
            }
        }

        // User Wants continue Checkout
        val tvContinue = view.findViewById<TextView>(R.id.tv_continue)
        tvContinue.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime > 1000) {
                lastClickTime = SystemClock.elapsedRealtime()
                goToCheckout()
                dialog.dismiss()
            }
        }

        layoutOutside.setOnClickListener { dialog.dismiss() }

        val ivClose = view.findViewById<ImageView>(R.id.iv_close)
        ivClose.setOnClickListener { dialog.dismiss() }
        PopupUtils.setDefaultDialogProperty(dialog)
        dialog.show()
    }

    // Go to checkout page
    private fun goToCheckout() {
        startActivity(CheckoutActivity::class.java)
    }

    // Get Cart information of user
    private fun getMyCart(storeId: Int, isLoading: Boolean? = false) {
        Log.d("TAG", "getMyCart: ")
        viewModel.getMyCart(storeId, isLoading ?: false, object : HandleResponse<MyCartResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                viewDataBinding?.progressBar?.visibility = GONE
                viewDataBinding?.rvCartStores?.visibility = GONE
                (activity as CartActivity).viewDataBinding?.toolbar?.toolbar?.visibility = VISIBLE

                if (NetworkUtils.isNetworkConnected(baseActivity) && !(error?.message
                        ?: "").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)
                ) {
                    this@CartMainFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    NetworkUtils.showNoInternetDialog(
                        baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    getMyCart(storeId)
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(response: MyCartResponse) {
                //    viewDataBinding?.progressBar?.visibility = GONE
                if (response.code == 200) {
                    if (!activity!!.isFinishing) {
                        carts.apply {
                            clear()
                            addAll(response.carts)
                        }

                        // Check if there's any opened Order with same store

                        this@CartMainFragment.response = response
                        if (carts.isNotEmpty()) {
                            dismissCartProgress()
                            if (response.carts[0].orderId != null && response.carts[0].orderId!! > 0 && response.carts[0].isGridView == 1 && response.carts[0].ordersOutletsId != null && response.carts[0].ordersOutletsId!! > 0) {
                                getOrderDetail(response.carts[0].orderId!!, response.carts[0].ordersOutletsId!!, response.overallSubtotal ?: 0.0)
                            } else {
                                viewDataBinding?.rvCartStores?.visibility = VISIBLE
                                if(isLoading!!){
                                    dismissCartProgress()
                                }
                                setCartList(response.overallSubtotal ?: 0.0)
                            }

                        } else {
                            dismissCartProgress()
                            initEmptyCartUI()
                        }

                        if (isFirstOpen) {
                            isFirstOpen = false
                            logViewCartEvent(response)
                        }
                    }

                } else {
                    this@CartMainFragment.onError(
                        response.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                }

            }
        })
    }

    private fun dismissCartProgress() {
        Handler(Looper.getMainLooper()).postDelayed(Runnable {
            viewDataBinding?.progressBar?.visibility = GONE
            viewDataBinding?.layoutCheckout?.visibility = VISIBLE
            (activity as CartActivity).viewDataBinding?.toolbar?.toolbar?.visibility = VISIBLE
        }, 500)
    }

    fun logViewCartEvent(response: MyCartResponse) {
        var productCount = 0
        var outletNames = ""
        var totalItemCount = 0.0
        if (carts.isNotEmpty()) {
            for (cart in response.carts) {
                productCount += cart.products?.size ?: 0
                for (product in cart.products!!) {
                    totalItemCount += product.cartQty ?: 0.0
                }
                outletNames += cart.outletName + ","
            }
        }
        BasketAnalyticsManager.viewCartNew(
            response.overallSubtotal ?: 0.0,
            productCount,
            if (outletNames.isNotEmpty()) StringUtils.removeLastCharacter(outletNames) else "",
            totalItemCount,
            if (store?.serviceTypeId == 1) 1 else 0,
            viewDataBinding?.layoutMembership?.visibility == GONE
        )

    }

    private fun getOrderDetail(orderId: Int, orderStoreId: Int, overallSubtotal: Double) {
        viewModel.getOrderDetail(
            orderId,
            orderStoreId,
            object : HandleResponse<OrderDetailResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {

                }

                override fun handleSuccessRespons(successResponse: OrderDetailResponse) {
                    Log.d("TAG", "handleSuccessRespons: 324")
                    if (successResponse.orderDetail?.storeOrders!![0].orderStatus > 1 && successResponse.orderDetail.storeOrders!![0].orderStatus != 29) {

                    } else {
                        if (successResponse.orderDetail != null && successResponse.orderDetail.storeOrders!!.isNotEmpty() && !TO_FINISH_CART) {
                            showDialogFragment(
                                WaitFoodOrderFragment(
                                    successResponse.orderDetail.storeOrders!!.first().timeLeft!!,
                                    successResponse.orderDetail.storeOrders!![0].orderId,
                                    successResponse.orderDetail.storeOrders!![0].id
                                )
                            )
                        }
                    }
                    setCartList(overallSubtotal)
                    dismissCartProgress()
                }
            })
    }

    private fun setCartList(overallSubtotal: Double) {
        adapter.apply {
            setExpress(store?.serviceTypeId == 1)
            setCartData(carts[0], overallSubtotal)
            if (carts[0].products!!.isNotEmpty()){
                setItems(carts[0].products ?: ArrayList())
                viewDataBinding!!.progressBar.visibility = GONE
            }else{
                viewDataBinding!!.progressBar.visibility = VISIBLE
            }

            setTopSellingItems(carts[0].topSellingItems ?: ArrayList())
            onUpdateUI(response!!)
        }
    }


    // Remove Store Cart
    private fun removeCart(cart: Cart) {
        var totalItemCount = 0.0
        for (product in cart.products!!) {
            totalItemCount += product.cartQty ?: 0.0
        }

        BasketAnalyticsManager.clearCart(
            cart.products?.size ?: 0,
            cart.outletName ?: "", totalItemCount
        )

        viewModel.removeCart(cart, object : HandleResponse<SimpleResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(baseActivity) && !(error?.message
                        ?: "").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)
                ) {
                    this@CartMainFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    NetworkUtils.showNoInternetDialog(
                        baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    removeCart(cart)
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(response: SimpleResponse) {
                if (response.code == 200) {
                    carts.remove(cart)
                    if (carts.isNotEmpty()) {
                        adapter.setCartData(carts.first(), carts.first().outletSubtotal ?: 0.0)
                        adapter.setItems(carts[0].products ?: ArrayList())
                        adapter.setTopSellingItems(carts[0].topSellingItems ?: ArrayList())
                    }

                    if (carts.isNullOrEmpty()) {
                        initEmptyCartUI()
                    }
                    getMyCart(PreferenceManager.currentUserStoreId)
                } else {
                    this@CartMainFragment.onError(
                        response.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                }
            }
        })
    }

    private fun initEmptyCartUI() {

        tvTitle!!.visibility = VISIBLE
        tvTitle!!.setTextColor(resources.getColor(R.color.md_white_1000))
        cartImageLayout!!.visibility = GONE
        viewDataBinding?.tvAmount?.visibility = VISIBLE
        isEmpty= true
        enableAmountView(false)
        viewDataBinding?.tvAmount?.visibility = VISIBLE
        viewDataBinding?.tvAmount?.text = FormatterUtils.formatHTMLString(FormatterUtils.formatPrice(0.0))
        viewDataBinding?.layoutCheckout?.background = ContextCompat.getDrawable(baseActivity, R.drawable.bg_round_grey_8dp)
        viewDataBinding?.rvCartStores?.visibility = GONE
        viewDataBinding?.layoutEmptyCart?.visibility = VISIBLE
        viewDataBinding?.btCheckout?.isEnabled = false
        isValid = false
        viewDataBinding?.layoutAddMore?.visibility = GONE
    }

    // Add items to cart
    private fun addToCart(product: Product, amount: Double) {
        val storeId = PreferenceManager.currentUserStoreId
        product.cartQty = amount
        adapter.notifyDataSetChanged()
        viewModel.addToCart(product, amount, object : HandleResponse<AddCartResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(baseActivity) && !(error?.message
                        ?: "").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)
                ) {
                    this@CartMainFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    NetworkUtils.showNoInternetDialog(
                        baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    addToCart(product, amount)
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(response: AddCartResponse) {
                if (response.code == 200) {
                    viewModel.updateLocalProduct(product)
                    handler.removeCallbacks(mRunnable)
                    handler.postDelayed(mRunnable, POPUP_DELAY_TIME)
                } else {
                    getMyCart(PreferenceManager.currentUserStoreId)
                    if (amount != 0.0) {
                        this@CartMainFragment.onError(
                            baseActivity.resources.getString(R.string.str_oops_i),
                            response.message
                        )
                    }

                }
            }
        })
    }

    // Add items to cart
    private fun updateCart(product: Product, amount: Double) {
        val storeId = PreferenceManager.currentUserStoreId
        product.cartQty = if (amount < 0.0) 0.0 else amount
        adapter.notifyDataSetChanged()

        viewModel.updateToCart(
            product,
            amount,
            PreferenceManager.vendorId,
            object : HandleResponse<AddCartResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (NetworkUtils.isNetworkConnected(baseActivity) && !(error?.message
                            ?: "").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)
                    ) {
                        this@CartMainFragment.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        NetworkUtils.showNoInternetDialog(
                            baseActivity,
                            object : NetworkUtils.OnConnectedListener {
                                override fun onConnected() {
                                    try {
                                        updateCart(product, amount)
                                    } catch (e1: Exception) {
                                        e1.printStackTrace()
                                    }
                                }
                            })
                    }
                }

                override fun handleSuccessRespons(response: AddCartResponse) {
                    if (response.code == 200) {
                        viewModel.updateLocalProduct(product)
                        handler.removeCallbacks(mRunnable)
                        handler.postDelayed(mRunnable, POPUP_DELAY_TIME)
                    } else {
                        getMyCart(PreferenceManager.currentUserStoreId)
                        if (amount != 0.0) {
                            this@CartMainFragment.onError(
                                baseActivity.resources.getString(R.string.str_oops_i),
                                response.message ?: ""
                            )
                        }
                    }
                }
            })
    }

    // Remove product from cart
    private fun removeProductFromCart(product: Product) {
        viewModel.removeProductFromCart(product, object : HandleResponse<SimpleResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(baseActivity) && !(error?.message
                        ?: "").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)
                ) {
                    this@CartMainFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    NetworkUtils.showNoInternetDialog(
                        baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    removeProductFromCart(product)
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(successResponse: SimpleResponse) {
                if (successResponse.code == 200) {
                    BasketAnalyticsManager.removeItemFromCartNew(
                        RealmManager.getLocalStore(product.outletId ?: 0)?.outletName ?: "",
                        product.name ?: "", 0
                    )
                    getMyCart(PreferenceManager.currentUserStoreId)
                } else {
                    this@CartMainFragment.onError(
                        successResponse.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                }
            }
        })
    }

    //Add All items from store (ordered in cart) to order
    private fun addAllItemsToOrder() {
        viewModel.addCartItemsToOrder(
            existingStoreId,
            existingOrderStoreId,
            object : HandleResponse<SimpleResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (NetworkUtils.isNetworkConnected(baseActivity) && !(error?.message
                            ?: "").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)
                    ) {
                        this@CartMainFragment.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        NetworkUtils.showNoInternetDialog(
                            baseActivity,
                            object : NetworkUtils.OnConnectedListener {
                                override fun onConnected() {
                                    try {
                                        addAllItemsToOrder()
                                    } catch (e1: Exception) {
                                        e1.printStackTrace()
                                    }
                                }
                            })
                    }
                }

                override fun handleSuccessRespons(successResponse: SimpleResponse) {
                    if (successResponse.code == 200) {
                        viewModel.getCartCount()
                        BasketAnalyticsManager.addItemsToOrder(existingOrderStoreId, productName)
                        finishActivity()
                    } else {
                        this@CartMainFragment.onError(
                            successResponse.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    }
                }
            })
    }

    override fun onResume() {
        super.onResume()
        getMyCart(PreferenceManager.currentUserStoreId)
        Log.d("TAG", "getMyCart: 2")
    }

    // Get Membership Details
    fun getMembershipDetails() {
        viewModel.getMembershipDetails(object : HandleResponse<UserMembershipDetailResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(baseActivity) && !(error?.message
                        ?: "").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)
                ) {
                    this@CartMainFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    NetworkUtils.showNoInternetDialog(
                        baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    getMembershipDetails()
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(successResponse: UserMembershipDetailResponse) {
                if (successResponse.status == 200) {
                    if (successResponse.data.userMembershipDetails != null && successResponse.data.userMembershipDetails?.isCancelled != 1) {
                        // If User has subscribed already membership
                        viewDataBinding?.layoutMembership?.visibility = GONE
                    } else {
                        // If user has not subscribed membership yet
                        if (!isMembershipAPICalled) {
                            isMembershipAPICalled = true
                            BasketAnalyticsManager.viewedAdvert("Cart")
                        }
                        if (store?.isGridView != 1) {
                            viewDataBinding?.layoutMembership?.visibility = VISIBLE
                        }
                        viewDataBinding?.layoutMembership?.setOnClickListener {
                            if (SystemClock.elapsedRealtime() - lastClickTime > 1000) {
                                lastClickTime = SystemClock.elapsedRealtime()
                                BasketAnalyticsManager.exploredPrime("Cart")
                                startActivity(MembershipActivity::class.java)
                            }
                        }
                    }
                    AppConstants.isMember = viewDataBinding?.layoutMembership?.visibility == GONE
                } else {
                    this@CartMainFragment.onError(
                        successResponse.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                }
            }
        })
    }

    companion object {


        fun newInstance(
            yourStringData:String,
            cartImage1:CircleImageView,
            cartImage2:CircleImageView,
            view1:View,
            view2:View,
            secondItem:LinearLayout,
            textAllCart:TextView,
            allCartLayout:LinearLayout,
            tvTitle:TextView,
            cartImageLayout:LinearLayout,
        ): CartMainFragment {
            val fragment = CartMainFragment()
            fragment.yourStringData = yourStringData
            fragment.cartImage1 = cartImage1
            fragment.cartImage2 = cartImage2
            fragment.view1 = view1
            fragment.view2 = view2
            fragment.secondItem = secondItem
            fragment.textAllCart = textAllCart
            fragment.allCartLayout = allCartLayout
            fragment.tvTitle = tvTitle
            fragment.cartImageLayout = cartImageLayout
            return fragment
        }

    }
}
