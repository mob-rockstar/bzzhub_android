package jo.basket.data.model.api.response

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import jo.basket.data.model.OrderProduct

class StoreOrderDetailResponse {

    @SerializedName("httpCode")
    @Expose
    var code: Int = 0

    @SerializedName("Message")
    @Expose
    var message: String? = null

    @SerializedName("order_id")
    @Expose
    var orderId: Int? = null

    @SerializedName("order_detail")
    @Expose
    var orderDetail: OrderDetail? = null

    class OrderDetail {

        @SerializedName("vendor_id")
        @Expose
        var vendorId: Int? = null

        @SerializedName("outlet_id")
        @Expose
        var outletId: Int? = null

        @SerializedName("outlet_name")
        @Expose
        var outletName: String? = null

        @SerializedName("vendor_logo")
        @Expose
        var vendorLogo: String? = null

        @SerializedName("orders_outlets_id")
        @Expose
        var ordersOutletsId: Int? = null

        @SerializedName("created_date")
        @Expose
        var createdDate: String? = null

        @SerializedName("delivery_date")
        @Expose
        var deliveryDate: String? = null

        @SerializedName("delivery_day")
        @Expose
        var deliveryDay: String? = null

        @SerializedName("delivery_slot")
        @Expose
        var deliverySlot: String? = null

        @SerializedName("order_status")
        @Expose
        var orderStatus: Int? = null

        @SerializedName("order_status_name")
        @Expose
        var orderStatusName: String? = null

        @SerializedName("user_rated")
        @Expose
        var userRated: Int? = null

        @SerializedName("cancel_order_permission")
        @Expose
        var cancelOrderPermission: Int? = null

        //        @SerializedName("shopper_detail")
//        @Expose
//        var shopperDetail: Shopper? = null
        @SerializedName("outlet_basic_delivery_fee")
        @Expose
        var outletBasicDeliveryFee: Double? = null

        @SerializedName("outlet_one_hour_delivery_fee")
        @Expose
        var outletOneHourDeliveryFee: Int? = null

        @SerializedName("outlet_included_tax_amount")
        @Expose
        var outletIncludedTaxAmount: Double? = null

        @SerializedName("outlet_service_tax")
        @Expose
        var outletServiceTax: Int? = null

        @SerializedName("outlet_under_threshold_fee")
        @Expose
        var outletUnderThresholdFee: Int? = null

        @SerializedName("outlet_free_delivery_discount")
        @Expose
        var outletFreeDeliveryDiscount: Double? = null

        @SerializedName("outlet_basic_plus_under_threshold")
        @Expose
        var outletBasicPlusUnderThreshold: Double? = null

        @SerializedName("outlet_total_delivery_fee")
        @Expose
        var outletTotalDeliveryFee: Double? = null

        @SerializedName("outlet_subtotal")
        @Expose
        var outletSubtotal: Double? = null

        @SerializedName("shopper_adjustment")
        @Expose
        var shopperAdjustment: Double? = null

        @SerializedName("outlet_total")
        @Expose
        var outletTotal: Double? = null

        @SerializedName("outlets_items_count")
        @Expose
        var outletsItemsCount: Int? = null

        @SerializedName("product_list")
        @Expose
        var products: List<OrderProduct>? = null

        @SerializedName("rating_completed")
        @Expose
        var ratingCompleted: Int? = null

    }

}