package jo.basket.data.local.db.realm

import jo.basket.data.model.Store


class StoreRepo : BaseRepo() {

    fun findAll(detached: Boolean = true): List<Store> {
        val realmResults = realm.where(Store::class.java).findAll()

        return if (detached) {
            realm.copyFromRealm(realmResults)
        } else {
            realmResults
        }
    }

    fun getById(id: Int, detached: Boolean = true): Store? {
        var realmStore: Store? = realm.where(Store::class.java).equalTo("id", id).findFirst()
        if (detached && realmStore != null) {
            realmStore = realm.copyFromRealm<Store>(realmStore)
        }
        return realmStore
    }

    fun findInArea(areaId: Int, detached: Boolean = true): List<Store> {
        val realmResults = realm.where(Store::class.java).equalTo("area.id", areaId).findAll()

        return if (detached) {
            realm.copyFromRealm(realmResults)
        } else {
            realmResults
        }
    }
    fun save(store: Store) {
        realm.executeTransaction { r -> r.copyToRealmOrUpdate(store) }
    }

    fun delete(realmStore: Store) {
        if (realmStore.isValid) {
            realm.executeTransaction { realmStore.deleteFromRealm() }
        }
    }

    fun detach(store: Store): Store {
        return if (store.isManaged) {
            realm.copyFromRealm(store)
        } else {
            store
        }
    }
}
