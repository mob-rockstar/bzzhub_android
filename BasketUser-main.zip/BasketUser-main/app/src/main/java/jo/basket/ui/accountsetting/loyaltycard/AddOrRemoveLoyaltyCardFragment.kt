package jo.basket.ui.accountsetting.loyaltycard

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import androidx.core.content.ContextCompat
import jo.basket.R
import jo.basket.data.model.LoyaltyCard
import jo.basket.data.model.api.response.SimpleUpdateResponse
import jo.basket.data.model.api.response.base.ErrorResponse
import jo.basket.databinding.DialogAddRemoveLoyaltyCardBinding
import jo.basket.di.Injectable
import jo.basket.ui.accountsetting.AccountSettingViewModel
import jo.basket.ui.base.BaseInputDialogFragment
import jo.basket.ui.base.HandleResponse
import jo.basket.utils.AppConstants
import jo.basket.utils.MessageEvent
import jo.basket.utils.NetworkUtils
import org.greenrobot.eventbus.EventBus

// Screen to Add Or Remove Loyalty Card
class AddOrRemoveLoyaltyCardFragment :
    BaseInputDialogFragment<DialogAddRemoveLoyaltyCardBinding?, AccountSettingViewModel>(),
    Injectable {

    var loyaltyCard: LoyaltyCard? = null
    var mode: Boolean = false // If true: 'Add' false: 'Edit' Mode
    var cardNumber: String = ""
    override val layoutId: Int
        get() = R.layout.dialog_add_remove_loyalty_card

    override val viewModel: AccountSettingViewModel
        get() {
            return getViewModel(baseActivity, AccountSettingViewModel::class.java)
        }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        progressView = viewDataBinding?.progressBar
        loyaltyCard = viewModel.loyaltyCard!!
        initToolbar()

        initUI()
    }

    override fun getTheme(): Int {
        return R.style.FullScreenDialogFragmentTheme
    }

    fun initToolbar() {
        viewDataBinding!!.toolbar.tvTitle.text = loyaltyCard?.loyaltyCardName
        viewDataBinding!!.toolbar.ivBack.setOnClickListener { dismiss() }
    }

    private fun initUI() {
        viewDataBinding!!.edittextCardNumber.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                cardNumber = s.toString().trim()
                enableButton(cardNumber.isNotEmpty())
                if (cardNumber.isEmpty()) {
                    viewDataBinding!!.btnAdd.setTextColor(
                        ContextCompat.getColor(
                            baseActivity,
                            R.color.md_grey_600
                        )
                    )
                    viewDataBinding!!.btnAdd.background =
                        ContextCompat.getDrawable(baseActivity, R.drawable.bg_round_grey_8dp)
                } else {
                    viewDataBinding!!.btnAdd.setTextColor(
                        ContextCompat.getColor(
                            baseActivity,
                            R.color.md_white_1000
                        )
                    )
                    viewDataBinding!!.btnAdd.background =
                        ContextCompat.getDrawable(baseActivity, R.drawable.bg_round_green_8dp)
                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }
        })

        if (!viewModel.loyaltyCard?.loyaltyCardNumber.equals("0"))
            viewDataBinding!!.edittextCardNumber.setText(loyaltyCard?.loyaltyCardNumber)
        // If LoyaltyCard is not existing, mode would be true
        mode = loyaltyCard?.userLoyaltyCardId == 0
        viewDataBinding!!.btnAdd.text = baseActivity.resources.getString(
            if (mode) R.string.str_add else R.string.update
        )

        viewDataBinding!!.tvRemove.visibility = if (!mode) VISIBLE else GONE

        viewDataBinding!!.btnAdd.setOnClickListener {
            // If LoyaltyCard is not existing,add Card
            if (mode) addCard()
            // If LoyaltyCard is existing,update Card
            else editCard()
        }
        viewDataBinding!!.tvRemove.setOnClickListener { removeCard() }
    }

    fun enableButton(enabled: Boolean) {
        viewDataBinding!!.btnAdd.isEnabled = enabled
        viewDataBinding!!.btnAdd.isClickable = enabled
    }

    //Add Loyalty Card
    private fun addCard() {
        viewModel.addCard(
            loyaltyCard!!.id,
            cardNumber,
            object : HandleResponse<SimpleUpdateResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                     if (NetworkUtils.isNetworkConnected(baseActivity) &&!(error?.message ?:"").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)) {
                        this@AddOrRemoveLoyaltyCardFragment.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        NetworkUtils.showNoInternetDialog(
                            baseActivity,
                            object : NetworkUtils.OnConnectedListener {
                                override fun onConnected() {
                                    try {
                                        addCard()
                                    } catch (e1: Exception) {
                                        e1.printStackTrace()
                                    }
                                }
                            })
                    }
                }

                override fun handleSuccessRespons(successResponse: SimpleUpdateResponse) {
                    if (successResponse.status == 200) {
                        notifyDataChanged()
                        dismiss()
                    } else {
                        viewDataBinding!!.tvInvalid.text =
                            successResponse.message
                    }
                }
            })
    }

    // Update Loyalty Card
    private fun editCard() {
        viewModel.updateCard(
            loyaltyCard!!.id,
            cardNumber,
            loyaltyCard!!.userLoyaltyCardId,
            object : HandleResponse<SimpleUpdateResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                     if (NetworkUtils.isNetworkConnected(baseActivity) &&!(error?.message ?:"").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)) {
                        this@AddOrRemoveLoyaltyCardFragment.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        NetworkUtils.showNoInternetDialog(
                            baseActivity,
                            object : NetworkUtils.OnConnectedListener {
                                override fun onConnected() {
                                    try {
                                        editCard()
                                    } catch (e1: Exception) {
                                        e1.printStackTrace()
                                    }
                                }
                            })
                    }
                }

                override fun handleSuccessRespons(successResponse: SimpleUpdateResponse) {
                    if (successResponse.status == 200) {
                        notifyDataChanged()
                        dismiss()
                    } else {
                        viewDataBinding!!.tvInvalid.visibility = VISIBLE
                        viewDataBinding!!.tvInvalid.text =
                            successResponse.message
                    }
                }
            })
    }

    // Remove Loyalty card
    private fun removeCard() {
        viewModel.removeCard(loyaltyCard!!.userLoyaltyCardId,
            object : HandleResponse<SimpleUpdateResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                     if (NetworkUtils.isNetworkConnected(baseActivity) &&!(error?.message ?:"").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)) {
                        this@AddOrRemoveLoyaltyCardFragment.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        NetworkUtils.showNoInternetDialog(
                            baseActivity,
                            object : NetworkUtils.OnConnectedListener {
                                override fun onConnected() {
                                    try {
                                        removeCard()
                                    } catch (e1: Exception) {
                                        e1.printStackTrace()
                                    }
                                }
                            })
                    }
                }

                override fun handleSuccessRespons(successResponse: SimpleUpdateResponse) {
                    if (successResponse.status == 200) {
                        notifyDataChanged()
                        dismiss()
                    } else {
                        viewDataBinding!!.tvInvalid.visibility = VISIBLE
                        viewDataBinding!!.tvInvalid.text =
                            successResponse.message
                    }
                }
            })
    }

    //If user made some changes, broadcast event to LoyaltyCardList Fragment
    fun notifyDataChanged() {
        EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_LOYALTY_CARD_CHANGED))
    }
}