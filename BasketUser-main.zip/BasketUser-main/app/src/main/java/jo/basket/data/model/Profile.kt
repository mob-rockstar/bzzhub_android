package jo.basket.data.model


import com.google.gson.annotations.SerializedName

open class Profile(
    var email: String,
    @SerializedName("first_name")
    var firstName: String,
    @SerializedName("last_name")
    var lastName: String,
    var mobile: String,
    @SerializedName("profile_image")
    var profileImage: String
)