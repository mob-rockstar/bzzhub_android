package jo.basket.ui.checkout.detail.product

import android.view.View
import android.view.View.GONE
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import jo.basket.R
import jo.basket.data.model.Cart
import jo.basket.data.model.Product
import jo.basket.databinding.RecyclerItemCheckoutCartStoreBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter

//Adapter to handle List of Store Carts
class CheckoutCartStoreAdapter : BaseRecyclerViewAdapter<Cart, RecyclerItemCheckoutCartStoreBinding>() {

    private val viewPool = RecyclerView.RecycledViewPool()

    private var listener: OnCartActionListener? = null

    override val layoutId: Int
        get() = R.layout.recycler_item_checkout_cart_store

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = createBindedView(viewGroup)
        return CheckoutCartStoreViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as CheckoutCartStoreViewHolder
        val context = holder.itemView.context

        val cart = items[position]
        // Init UI using ViewHolder
        if (items.size == 1){
            holder.binding.tvStoreName.visibility = GONE
        }else{
            holder.binding.tvStoreName.text = items[position].displayName
        }

        // Set Product List for each Store Cart
        holder.binding.rvCartProducts.setHasFixedSize(true)
        holder.binding.rvCartProducts.layoutManager = LinearLayoutManager(context)
        val adapter = CheckoutCartProductAdapter(listener)
        adapter.outletId = items[position].storeId
        adapter.setItems(items[position].products ?: emptyList())
        holder.binding.rvCartProducts.adapter = adapter
        holder.binding.rvCartProducts.setRecycledViewPool(viewPool)

    }

    fun setOnCartActionListener(listener: OnCartActionListener) {
        this.listener = listener
    }


    interface OnCartActionListener {

        fun onSelectProductInstruction(product: Product)

        fun onProductAmountChange(product: Product, amount: Double)

        fun onRemoveProduct(product: Product)

        fun onSelectProduct(product: Product)
    }

    inner class CheckoutCartStoreViewHolder(val binding: RecyclerItemCheckoutCartStoreBinding) :
        RecyclerView.ViewHolder(binding.root)

}
