package jo.basket.data.model.api.response


import com.google.gson.annotations.SerializedName

data class WalletTransactionsHistory(
    var action: String,
    var amount: String,
    @SerializedName("created_at")
    var createdAt: String,
    var description: String,
    var label: String,
    var operation: String
)