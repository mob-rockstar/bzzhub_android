package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.User


class LoginResponse {

    @field:SerializedName("data")
    var data: List<User>? = null

    @field:SerializedName("status")
    val code: Int = 0

    @field:SerializedName("message")
    val message: String? = null

}