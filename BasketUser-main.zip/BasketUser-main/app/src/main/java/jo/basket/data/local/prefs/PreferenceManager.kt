package jo.basket.data.local.prefs

import android.content.Context
import android.content.SharedPreferences
import jo.basket.data.model.AppNews
import jo.basket.data.model.CMSDetail
import jo.basket.data.model.User
import jo.basket.utils.AppConstants
import jo.basket.utils.MessageEvent
import org.greenrobot.eventbus.EventBus


object PreferenceManager {

    // Constants
    private const val PREF_KEY_ACCESS_TOKEN = "PREF_KEY_ACCESS_TOKEN"
    private const val PREF_KEY_CURRENT_USER_LANGUAGE = "PREF_KEY_USER_LANGUAGE"
    private const val PREF_KEY_CURRENT_USER_COUNTRY_CODE = "PREF_KEY_COUNTRY_CODE"
    private const val PREF_KEY_CURRENT_USER_MOBILE = "PREF_KEY_CURRENT_USER_MOBILE"
    private const val PREF_KEY_CURRENT_USER_EMAIL = "PREF_KEY_CURRENT_USER_EMAIL"
    private const val PREF_KEY_CURRENT_USER_ID = "PREF_KEY_CURRENT_USER_ID"
    private const val PREF_KEY_CURRENT_USER_FIRST_NAME = "PREF_KEY_CURRENT_USER_FIRST_NAME"
    private const val PREF_KEY_CURRENT_USER_LAST_NAME = "PREF_KEY_CURRENT_USER_LAST_NAME"
    private const val PREF_KEY_CURRENT_USER_IMAGE_URL = "PREF_KEY_CURRENT_USER_IMAGE_URL"
    private const val PREF_KEY_CURRENT_USER_SETUP_STEP = "PREF_KEY_CURRENT_USER_SETUP_STEP"
    private const val PREF_KEY_CURRENT_USER_COUNTRY_ID = "PREF_KEY_CURRENT_USER_COUNTRY_ID"
    private const val PREF_KEY_CURRENT_USER_CITY_ID = "PREF_KEY_CURRENT_USER_CITY_ID"
    private const val PREF_KEY_CURRENT_USER_AREA_ID = "PREF_KEY_CURRENT_USER_AREA_ID"
    private const val PREF_KEY_CURRENT_USER_STORE_ID = "PREF_KEY_CURRENT_USER_STORE_ID"
    private const val PREF_KEY_USER_LOGGED_IN_MODE = "PREF_KEY_USER_LOGGED_IN_MODE"
    private const val PREF_KEY_DEVICE_TOKEN = "device_token"
    private const val PREF_KEY_DEVICE_ID = "device_id"
    private const val PREF_KEY_FCM_TOKEN = "fcm_token"
    private const val PREF_KEY_SOCKET_TOKEN = "socket_token"
    private const val PREF_KEY_USER_CART_COUNT = "PREF_KEY_USER_CART_COUNT"
    private const val PREF_KEY_USER_OPENED_ORDER_COUNT = "PREF_KEY_OPENED_ORDER_COUNT"
    private const val PREF_KEY_CURRENT_USER_ADDRESS = "PREF_KEY_CURRENT_USER_ADDRESS"
    private const val PREF_KEY_USER_MISSED_NOTIFICATION = "PREF_KEY_MISSED_NOTIFICATION"
    private const val PREF_KEY_USER_CHAT_TOKEN = "PREF_KEY_CHAT_TOKEN"
    private const val PREF_KEY_USER_CURRENCY_CODE = "PREF_KEY_CURRENCY_CODE"
    private const val PREF_KEY_USER_COUNTRY_FLAG = "PREF_KEY_COUNTRY_FLAG_URL"
    private const val PREF_KEY_USER_COUNTRY_NAME = "PREF_KEY_CURRENT_USER_COUNTRY_NAME"
    private const val PREF_KEY_VENDOR_ID = "PREF_KEY_VENDOR_ID"
    private const val PREF_KEY_SERVICE_TYPE_ID = "PREF_KEY_SERVICE_TYPE_ID"
    private const val PREF_KEY_AUTHENTICATED = "PREF_KEY_AUTHENTICATED"
    private const val PREF_KEY_USER_LATITUDE = "PREF_KEY_LATITUDE"
    private const val PREF_KEY_USER_LONGITUDE = "PREF_KEY_LONGITUDE"
    private const val PREF_KEY_USER_ADDRESS_ID = "PREF_KEY_CURRENT_USER_ADDRESS_ID"
    private const val PREF_KEY_LAST_RECEIVED_STORE_PAYLOAD = "PREF_KEY_LAST_RECEIVED_STORE_PAYLOAD"
    private const val PREF_KEY_LAST_RECEIVED_IMAGE_PAYLOAD = "PREF_KEY_LAST_RECEIVED_IMAGE_PAYLOAD"
    private const val PREF_KEY_LAST_RECEIVED_POPUP_TEXT = "PREF_KEY_LAST_RECEIVED_POPUP_TEXT"
    private const val PREF_KEY_LAST_RECEIVED_TITLE = "PREF_KEY_LAST_RECEIVED_TITLE"
    private const val PREF_KEY_LAST_RECEIVED_MESSAGE = "PREF_KEY_LAST_RECEIVED_MESSAGE"
    private const val PREF_KEY_GET_PERMISSION_SUGGESTION_BEFORE =
        "PREF_KEY_GET_PERMISSION_SUGGESTION_BEFORE"
    private const val FROM_LOCAL_BANNER_TO_EXPRESS = "FROM_LOCAL_BANNER_TO_EXPRESS"
    // Variables
    var cmsDetail: CMSDetail? = null

    var news: AppNews? = null


    private lateinit var mPrefs: SharedPreferences

    fun init(context: Context) {
        mPrefs = context.getSharedPreferences(AppConstants.PREF_NAME, Context.MODE_PRIVATE)
    }

    // User Data
    private var _userData: User? = null
    var userData: User?
        get() {
            if (_userData == null) {
                if (currentUserId != null && currentUserId!! > 0) {
                    _userData = User()
                    _userData!!.userId = currentUserId!!
                    _userData!!.token =
                        accessToken
                    _userData!!.mobile =
                        currentUserMobile
                    _userData!!.countryCode =
                        currentUserCountryCode
                    _userData!!.firstName =
                        currentUserFirstName
                    _userData!!.lastName =
                        currentUserLastName
                    _userData!!.email =
                        currentUserEmail
                    _userData!!.imageUrl =
                        currentUserImageUrl
                    _userData!!.countryId =
                        currentUserCountryId
                    _userData!!.cityId =
                        currentUserCityId
                    _userData!!.areaId =
                        currentUserAreaId
                    _userData!!.storeId =
                        currentUserStoreId
                    _userData!!.profileSetupStep =
                        currentUserSetupStep
                    _userData!!.currency =
                        userCurrencyCode
                    _userData!!.countryFlag = countryFlag
                }
            }
            return _userData
        }
        set(user) {
            _userData = user

            currentUserId = user?.userId
            accessToken = user?.token
            currentUserMobile = user?.mobile
            currentUserCountryCode = user?.countryCode
            currentUserFirstName = user?.firstName
            currentUserLastName = user?.lastName
            currentUserEmail = user?.email
            currentUserImageUrl = user?.imageUrl
            currentUserCountryId = user?.countryId ?: 0
            currentUserCityId = user?.cityId ?: 0
            currentUserAreaId = user?.areaId ?: 0
            currentUserStoreId = user?.storeId ?: 0
            currentUserLanguage = user?.languageID!!
            currentUserSetupStep = user.profileSetupStep
            userCurrencyCode = user.currency
            countryFlag = user.countryFlag
        }

    // Token from Server
    var accessToken: String?
        get() = if (mPrefs.getString(
                PREF_KEY_ACCESS_TOKEN, "0"
            ) == ""
        ) "0" else mPrefs.getString(
            PREF_KEY_ACCESS_TOKEN, "0"
        )
        set(accessToken) {
            mPrefs.edit().putString(
                PREF_KEY_ACCESS_TOKEN, accessToken
            ).apply()
        }

    // User Country Code
    var currentUserCountryCode: String?
        get() = mPrefs.getString(
            PREF_KEY_CURRENT_USER_COUNTRY_CODE, "+962" // Default country Jordan
        )
        set(countryCode) {
            mPrefs.edit().putString(
                PREF_KEY_CURRENT_USER_COUNTRY_CODE, countryCode
            ).apply()
        }

    // User Mobile number
    var currentUserMobile: String?
        get() = mPrefs.getString(
            PREF_KEY_CURRENT_USER_MOBILE, null
        )
        set(mobile) {
            mPrefs.edit().putString(
                PREF_KEY_CURRENT_USER_MOBILE, mobile
            ).apply()
        }

    // User Email Address
    var currentUserEmail: String?
        get() = mPrefs.getString(
            PREF_KEY_CURRENT_USER_EMAIL, null
        )
        set(email) {
            mPrefs.edit().putString(
                PREF_KEY_CURRENT_USER_EMAIL, email
            ).apply()
        }

    // Current User Selected Language
    var currentUserLanguage: Int
        get() = mPrefs.getInt(
            PREF_KEY_CURRENT_USER_LANGUAGE, 1
        )
        set(lang) {
            mPrefs.edit().putInt(
                PREF_KEY_CURRENT_USER_LANGUAGE, lang
            ).apply()
        }

    var currentUserLanguageRaw: Int
        get() = mPrefs.getInt(
            PREF_KEY_CURRENT_USER_LANGUAGE, 0
        )
        set(lang) {
            mPrefs.edit().putInt(
                PREF_KEY_CURRENT_USER_LANGUAGE, lang
            ).apply()
        }

    // User ID
    var currentUserId: Long?
        get() {
            val userId = mPrefs.getLong(
                PREF_KEY_CURRENT_USER_ID, 0
            )
            return if (userId == 0L) 0 else userId
        }
        set(userId) {
            val id = userId ?: 0
            mPrefs.edit().putLong(
                PREF_KEY_CURRENT_USER_ID, id
            ).apply()
        }

    // Device ID
    var deviceId: String?
        get() = mPrefs.getString(
            PREF_KEY_DEVICE_ID, ""
        )!!
        set(deviceId) {
            mPrefs.edit().putString(
                PREF_KEY_DEVICE_ID, deviceId
            ).apply()
        }

    var deviceToken: String?
        get() = mPrefs.getString(
            PREF_KEY_DEVICE_TOKEN, ""
        )!!
        set(deviceToken) {
            mPrefs.edit().putString(
                PREF_KEY_DEVICE_TOKEN, deviceToken
            ).apply()
        }

    // Firebase Token
    var fcmToken: String?
        get() = mPrefs.getString(
            PREF_KEY_FCM_TOKEN, ""
        )!!
        set(deviceToken) {
            mPrefs.edit().putString(
                PREF_KEY_FCM_TOKEN, deviceToken
            ).apply()
        }

    // Token from Socket Server
    var socketToken: String?
        get() = mPrefs.getString(
            PREF_KEY_SOCKET_TOKEN, ""
        )!!
        set(socketToken) {
            mPrefs.edit().putString(
                PREF_KEY_SOCKET_TOKEN, socketToken
            ).apply()
        }

    // Current User Login Mode - Loggedin, Loggedout, Social
    var currentUserLoggedInMode: LoggedInMode
        get() = LoggedInMode.fromInt(
            mPrefs.getInt(
                PREF_KEY_USER_LOGGED_IN_MODE,
                0
            )
        )
        set(mode) {
            mPrefs.edit().putInt(
                PREF_KEY_USER_LOGGED_IN_MODE, mode.type
            ).apply()
        }

    // User First Name
    var currentUserFirstName: String?
        get() = mPrefs.getString(
            PREF_KEY_CURRENT_USER_FIRST_NAME, ""
        )
        set(firstName) {
            mPrefs.edit().putString(
                PREF_KEY_CURRENT_USER_FIRST_NAME, firstName
            ).apply()
        }

    // User Last Name
    var currentUserLastName: String?
        get() = mPrefs.getString(
            PREF_KEY_CURRENT_USER_LAST_NAME, null
        )
        set(lastName) {
            mPrefs.edit().putString(
                PREF_KEY_CURRENT_USER_LAST_NAME, lastName
            ).apply()
        }

    // User Image URL
    var currentUserImageUrl: String?
        get() = mPrefs.getString(
            PREF_KEY_CURRENT_USER_IMAGE_URL, null
        )
        set(profilePicUrl) {
            mPrefs.edit().putString(
                PREF_KEY_CURRENT_USER_IMAGE_URL, profilePicUrl
            ).apply()
        }

    // User Country ID
    var currentUserCountryId: Int
        get() = if (mPrefs.getInt(
                PREF_KEY_CURRENT_USER_COUNTRY_ID, 0
            ) == 0
        ) {
            if (mPrefs.getLong(
                    PREF_KEY_CURRENT_USER_ID, 0L
                ) == 0L
            ) 0 else 46
        } else mPrefs.getInt(
            PREF_KEY_CURRENT_USER_COUNTRY_ID, 46
        )
        set(countryId) {
            mPrefs.edit().putInt(
                PREF_KEY_CURRENT_USER_COUNTRY_ID, countryId
            ).apply()
        }

    var currentUserCountryName: String?
        get() = mPrefs.getString(PREF_KEY_USER_COUNTRY_NAME, "")
        set(countryName) {
            mPrefs.edit().putString(PREF_KEY_USER_COUNTRY_NAME, countryName)
        }

    // User City ID
    var currentUserCityId: Int
        get() = if (mPrefs.getInt(
                PREF_KEY_CURRENT_USER_CITY_ID, 0
            ) == 0
        ) if (mPrefs.getLong(
                PREF_KEY_CURRENT_USER_ID, 0L
            ) == 0L
        ) 0 else 21 else mPrefs.getInt(
            PREF_KEY_CURRENT_USER_CITY_ID, 21
        )
        set(cityId) {
            mPrefs.edit().putInt(
                PREF_KEY_CURRENT_USER_CITY_ID, cityId
            ).apply()
        }

    // User Area ID
    var currentUserAreaId: Int
        get() = mPrefs.getInt(
            PREF_KEY_CURRENT_USER_AREA_ID, 0
        )
        set(areaId) {
            mPrefs.edit().putInt(
                PREF_KEY_CURRENT_USER_AREA_ID, areaId
            ).apply()
        }

    // User Store ID
    var currentUserStoreId: Int
        get() = mPrefs.getInt(
            PREF_KEY_CURRENT_USER_STORE_ID, 0
        )
        set(storeId) {
            mPrefs.edit().putInt(
                PREF_KEY_CURRENT_USER_STORE_ID, storeId
            ).apply()
        }

    // Profile Setup Step
    var currentUserSetupStep: Int
        get() = mPrefs.getInt(
            PREF_KEY_CURRENT_USER_SETUP_STEP, 0
        )
        set(steupStep) {
            mPrefs.edit().putInt(
                PREF_KEY_CURRENT_USER_SETUP_STEP, steupStep
            ).apply()
        }

    // User Cart Count
    var userCartCount: Int
        get() = mPrefs.getInt(
            PREF_KEY_USER_CART_COUNT, 0
        )
        set(count) {
            mPrefs.edit().putInt(
                PREF_KEY_USER_CART_COUNT, count
            ).apply()
            EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_CART_CHANGED))
        }

    // Opened Order Count
    var userOpenedOrderCount: Int
        get() = mPrefs.getInt(
            PREF_KEY_USER_OPENED_ORDER_COUNT, 0
        )
        set(count) {
            mPrefs.edit().putInt(
                PREF_KEY_USER_OPENED_ORDER_COUNT, count
            ).apply()
            EventBus.getDefault()
                .post(MessageEvent(AppConstants.MESSAGE_USER_OPENED_ORDER_COUNT_CHANGED))
        }

    var currentUserAddress: String?
        get() = mPrefs.getString(
            PREF_KEY_CURRENT_USER_ADDRESS, ""
        )!!
        set(currentAddressString) {
            mPrefs.edit().putString(
                PREF_KEY_CURRENT_USER_ADDRESS, currentAddressString
            ).apply()
        }

    // Missed Notification ID
    var missedNotification: Int
        get() = mPrefs.getInt(
            PREF_KEY_USER_MISSED_NOTIFICATION, 0
        )
        set(count) {
            mPrefs.edit().putInt(
                PREF_KEY_USER_MISSED_NOTIFICATION, count
            ).apply()
        }

    // Missed Notification ID
    var authenticated: Int
        get() = mPrefs.getInt(
            PREF_KEY_AUTHENTICATED, 0
        )
        set(mAuth) {
            mPrefs.edit().putInt(
                PREF_KEY_AUTHENTICATED, mAuth
            ).apply()
        }

    var userChatToken: String?
        get() = mPrefs.getString(
            PREF_KEY_USER_CHAT_TOKEN, ""
        )!!
        set(currentUserChatToken) {
            mPrefs.edit().putString(
                PREF_KEY_USER_CHAT_TOKEN, currentUserChatToken
            ).apply()
        }

    var userCurrencyCode: String
        get() = mPrefs.getString(
            PREF_KEY_USER_CURRENCY_CODE, "JD"
        )!!
        set(currency) {
            mPrefs.edit().putString(
                PREF_KEY_USER_CURRENCY_CODE, currency
            ).apply()
            EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_COUNTRY_CHANGED))
        }

    var countryFlag: String
        get() = mPrefs.getString(
            PREF_KEY_USER_COUNTRY_FLAG, ""
        )!!
        set(flag) {
            mPrefs.edit().putString(
                PREF_KEY_USER_COUNTRY_FLAG, flag
            ).apply()
        }

    // Missed Notification ID
    var vendorId: Int
        get() = mPrefs.getInt(
            PREF_KEY_VENDOR_ID, 0
        )
        set(vendorId) {
            mPrefs.edit().putInt(
                PREF_KEY_VENDOR_ID, vendorId
            ).apply()
        }


    var serviceTypeId: Int
        get() = mPrefs.getInt(
            PREF_KEY_SERVICE_TYPE_ID, 2
        )
        set(serviceTypeId) {
            mPrefs.edit().putInt(
                PREF_KEY_SERVICE_TYPE_ID, serviceTypeId
            ).apply()
        }

    // Latitude of current Selected address
    var currentLatitude: Float
        get() = mPrefs.getFloat(
            PREF_KEY_USER_LATITUDE, 0.0f
        )
        set(latitude) {
            mPrefs.edit().putFloat(
                PREF_KEY_USER_LATITUDE, latitude
            ).apply()
        }

    // Longitude of current Selected address
    var currentLongitude: Float
        get() = mPrefs.getFloat(
            PREF_KEY_USER_LONGITUDE, 0.0f
        )
        set(longitude) {
            mPrefs.edit().putFloat(
                PREF_KEY_USER_LONGITUDE, longitude
            ).apply()
        }
    var from_local: String
        get() = mPrefs.getString(
            FROM_LOCAL_BANNER_TO_EXPRESS, ""
        )!!
        set(flag) {
            mPrefs.edit().putString(
                FROM_LOCAL_BANNER_TO_EXPRESS, flag
            ).apply()
        }

    // Current User Selected Address ID
    var currentUserAddressId: Int
        get() = mPrefs.getInt(
            PREF_KEY_USER_ADDRESS_ID, 0
        )
        set(userAddressId) {
            mPrefs.edit().putInt(
                PREF_KEY_USER_ADDRESS_ID, userAddressId
            ).apply()
        }

    var lastReceivedStorePayload: Int
        get() = mPrefs.getInt(
            PREF_KEY_LAST_RECEIVED_STORE_PAYLOAD, -1
        )
        set(mLastReceivedPayload) {
            mPrefs.edit().putInt(
                PREF_KEY_LAST_RECEIVED_STORE_PAYLOAD, mLastReceivedPayload
            ).apply()
        }

    var lastReceivedImagePayload: String
        get() = mPrefs.getString(PREF_KEY_LAST_RECEIVED_IMAGE_PAYLOAD, "") ?: ""
        set(value) {
            mPrefs.edit().putString(PREF_KEY_LAST_RECEIVED_IMAGE_PAYLOAD, value).apply()
        }

    var lastReceivedPopupText: String
        get() = mPrefs.getString(PREF_KEY_LAST_RECEIVED_POPUP_TEXT, "") ?: ""
        set(value) {
            mPrefs.edit().putString(PREF_KEY_LAST_RECEIVED_POPUP_TEXT, value).apply()
        }

    var lastReceivedMessage: String
        get() = mPrefs.getString(PREF_KEY_LAST_RECEIVED_MESSAGE, "") ?: ""
        set(value) {
            mPrefs.edit().putString(PREF_KEY_LAST_RECEIVED_MESSAGE, value).apply()
        }

    var lastReceivedTitle: String
        get() = mPrefs.getString(PREF_KEY_LAST_RECEIVED_TITLE, "") ?: ""
        set(value) {
            mPrefs.edit().putString(PREF_KEY_LAST_RECEIVED_TITLE, value).apply()
        }

    var getPermissionSuggestionBefore: Int
        get() = mPrefs.getInt(
            PREF_KEY_GET_PERMISSION_SUGGESTION_BEFORE, 0
        )
        set(mGetPermissionSuggestionBefore) {
            mPrefs.edit().putInt(
                PREF_KEY_GET_PERMISSION_SUGGESTION_BEFORE, mGetPermissionSuggestionBefore
            ).apply()
        }

    enum class LoggedInMode(val type: Int) {
        LOGGED_IN_MODE_LOGGED_OUT(0), LOGGED_IN_MODE_GOOGLE(1), LOGGED_IN_MODE_FB(2), LOGGED_IN_MODE_SERVER(
            3
        );

        companion object {
            fun fromInt(value: Int) = LoggedInMode.values().first { it.ordinal == value }
        }
    }

}