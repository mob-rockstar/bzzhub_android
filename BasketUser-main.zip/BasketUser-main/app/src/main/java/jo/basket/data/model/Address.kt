package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import java.io.Serializable


open class Address : RealmObject() , Serializable {

    @PrimaryKey
    @SerializedName("address_id")
    @Expose
    var id: Int = 0

    @SerializedName("address_type")
    @Expose
    var addressType: String? = null

    @SerializedName("address_type_id")
    @Expose
    var addressTypeId: Int? = null

    @SerializedName("address")
    @Expose
    var address: String? = null

    @SerializedName("country_id")
    @Expose
    var countryId: Int? = null

    @SerializedName("city_id")
    @Expose
    var cityId: Int? = null

    @SerializedName("location_id")
    @Expose
    var locationId: Int? = null

    @SerializedName("latitude")
    @Expose
    var latitude: Double = 0.0

    @SerializedName("longtitude")
    @Expose
    var longitude: Double = 0.0

    @SerializedName("near_landmark")
    @Expose
    var nearLandmark: String? = null

    @SerializedName("additional_info")
    @Expose
    var additionalInfo: String? = null

    @SerializedName("department_building")
    @Expose
    var departmentBuilding: String? = null

    @SerializedName("available")
    @Expose
    var available: Int? = null

    @SerializedName("is_selected")
    @Expose
    var isSelected: Int? = null

    @SerializedName("message")
    @Expose
    var message: String? = null

    @SerializedName("updated_date")
    @Expose
    var updatedDate: String? = null

    @SerializedName("location_name")
    @Expose
    var locationName: String? = null

}