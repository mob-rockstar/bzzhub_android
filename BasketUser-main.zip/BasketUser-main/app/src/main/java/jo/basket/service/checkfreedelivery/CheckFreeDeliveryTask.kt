package jo.basket.service.checkfreedelivery

import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import jo.basket.data.model.api.ServerResponse
import jo.basket.data.model.api.response.FreeDeliveryResponse
import jo.basket.data.model.api.response.base.BaseResponse
import jo.basket.data.model.api.response.base.ErrorResponse
import jo.basket.data.remote.APIManager
import jo.basket.ui.base.HandleResponse
import jo.basket.utils.NetworkUtils.getThrowableError
import java.util.*

// Timer Task to call Free Delivery API every particular times
class CheckFreeDeliveryTask(private val timer: Timer, private val service: FreeDeliveryService) :
    TimerTask() {

    // Check Free Delivery
    override fun run() {
        // Call Check Delivery API
        checkFreeDelivery(object : HandleResponse<FreeDeliveryResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                this@CheckFreeDeliveryTask.service.stopSelf()
            }

            override fun handleSuccessRespons(successResponse: FreeDeliveryResponse) {
                timer.cancel()
                if (successResponse.code == 200) {
                    if (successResponse.showPopup == 1) {
                        service.showFreeDeliveryPopup(successResponse.refreshDelay!!)
                    } else {
                        service.checkNextFreeDelivery(successResponse.refreshDelay!!)
                    }
                }else if ( successResponse.code == 201){
                    this@CheckFreeDeliveryTask.service.stopSelf()
                    logout()
                }
            }
        })
    }

    private fun logout(){
        logoutUser(object : HandleResponse <BaseResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {

            }

            override fun handleSuccessRespons(successResponse: BaseResponse) {
                service.logoutUser()
            }
        })
    }

    private fun logoutUser(handleResponse: HandleResponse<BaseResponse>){
        APIManager.logout()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            )
    }

    private fun checkFreeDelivery(handleResponse: HandleResponse<FreeDeliveryResponse>) {
        APIManager.checkFreeDelivery()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            )
    }
}