package jo.basket.data.model

data class Card(
    val card_holder_name: String,
    val card_id: Int,
    val card_label: String,
    val card_number: String,
    val created_date: String,
    val default_status: Int,
    val payment_option: String,
    val token_name: String
)