package jo.basket.data.local.db.realm

import jo.basket.data.model.Address

class AddressRepo : BaseRepo() {

    fun findAll(detached: Boolean = true): List<Address> {
        val realmResults = realm.where(Address::class.java).findAll()

        return if (detached) {
            realm.copyFromRealm(realmResults)
        } else {
            realmResults
        }
    }

    fun findInCountry(countryId: Int, detached: Boolean = true): List<Address> {
        val realmResults = realm.where(Address::class.java).equalTo("countryId", countryId).findAll()

        return if (detached) {
            realm.copyFromRealm(realmResults)
        } else {
            realmResults
        }
    }

    fun getById(id: Int, detached: Boolean = true): Address? {
        var realmAddress: Address? = realm.where(Address::class.java).equalTo("id", id).findFirst()
        if (detached && realmAddress != null) {
            realmAddress = realm.copyFromRealm<Address>(realmAddress)
        }
        return realmAddress
    }

    fun getByField(field: String?, value: String?, detached: Boolean = true): Address? {
        var realmAddress: Address? =
            realm.where(Address::class.java).equalTo(field!!, value).findFirst()
        if (detached && realmAddress != null) {
            realmAddress = realm.copyFromRealm<Address>(realmAddress)
        }
        return realmAddress
    }

    fun save(address: Address) {
        realm.executeTransaction { r -> r.copyToRealmOrUpdate(address) }
    }

    fun delete(address: Address) {
        if (address.isValid) {
            realm.executeTransaction {
                address.deleteFromRealm()
            }
        }
    }

    fun detach(address: Address): Address {
        return if (address.isManaged) {
            realm.copyFromRealm(address)
        } else {
            address
        }
    }
}