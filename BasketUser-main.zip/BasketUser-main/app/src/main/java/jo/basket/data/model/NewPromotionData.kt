package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.realm.RealmObject
import io.realm.annotations.PrimaryKey

open class NewPromotionData: RealmObject() {
    @SerializedName("created_date")
    @Expose
    var created_date: String ?= null

    @SerializedName("id")
    @Expose
    @PrimaryKey
    var id: Int ?= null

    @SerializedName("promotion_detail")
    @Expose
    var promotion_detail: String ?= null

    @SerializedName("promotion_image")
    @Expose
    var promotion_image: String ?= null

    @SerializedName("promotion_title")
    @Expose
    var promotion_title: String ?= null

    @SerializedName("updated_date")
    @Expose
    var updated_date: String ?= null
}