package jo.basket.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector
import jo.basket.ui.accountsetting.countrysetting.CountrySettingsFragment
import jo.basket.ui.accountsetting.languagesetting.LanguageSettingsFragment
import jo.basket.ui.accountsetting.loyaltycard.AddOrRemoveLoyaltyCardFragment
import jo.basket.ui.accountsetting.loyaltycard.LoyaltyCardListFragment
import jo.basket.ui.accountsetting.notificationsetting.NotificationSettingsFragment

@Module
abstract class FragmentAccountSettingModule {
    @ContributesAndroidInjector
    abstract fun contributeNotificationSettingsFragment(): NotificationSettingsFragment

    @ContributesAndroidInjector
    abstract fun contributeCountrySettingsFragment(): CountrySettingsFragment

    @ContributesAndroidInjector
    abstract fun contributeLanguageSettingsFragment(): LanguageSettingsFragment

    @ContributesAndroidInjector
    abstract fun contributeLoyaltyCardListFragment(): LoyaltyCardListFragment

    @ContributesAndroidInjector
    abstract fun contributeAddOrRemoveLoyaltyCardFragment(): AddOrRemoveLoyaltyCardFragment
}