package jo.basket.data.model

import com.google.gson.annotations.SerializedName


class CMSDetail {

    @field:SerializedName("id")
    val id: Int? = 0

    @field:SerializedName("url_index")
    val urlIndex: String? = ""

    @field:SerializedName("title")
    val title: String? = ""

    @field:SerializedName("content")
    val content: String? = ""

    @field:SerializedName("created_date")
    val createdDate: String? = ""

    @field:SerializedName("updated_date")
    val updatedDate: String? = ""

}