package jo.basket.data.model.api.response


import jo.basket.data.model.User

data class NormalSignUpResponse(
    var `data`: List<User>,
    var message: String,
    var status: Int
)