package jo.basket.data.model

data class ActivePaymentMethod(
    val cards: ArrayList<Card>,
    val id: Int,
    val name: String,
    val payment_mode: Int,
    val payment_type: Int
)