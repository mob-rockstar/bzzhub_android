package jo.basket.ui.component

import android.content.Context
import android.graphics.Paint
import android.graphics.Typeface
import android.text.TextPaint
import android.text.style.TypefaceSpan


class CustomFontSpan(
    context: Context,
    family: String?,
    private val typeFace: Typeface,
    private val size: Float
) :
    TypefaceSpan(family) {
    private val scale: Float = context.resources.displayMetrics.density

    override fun updateDrawState(ds: TextPaint) {
        ds.textSize = size * scale + 0.5f
        applyCustomTypeFace(ds, typeFace)
    }

    override fun updateMeasureState(paint: TextPaint) {
        paint.textSize = size * scale + 0.5f
        applyCustomTypeFace(paint, typeFace)
    }


    private fun applyCustomTypeFace(paint: Paint, tf: Typeface) {
        val oldStyle: Int
        val old = paint.typeface
        oldStyle = old?.style ?: 0
        val fake = oldStyle and tf.style.inv()
        if (fake and Typeface.BOLD != 0) {
            paint.isFakeBoldText = true
        }
        if (fake and Typeface.ITALIC != 0) {
            paint.textSkewX = -0.25f
        }
        paint.typeface = tf
    }

}