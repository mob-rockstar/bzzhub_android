package jo.basket.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector
import jo.basket.ui.wallet.main.WalletMainFragment

@Module
abstract class FragmentWalletModule{
    @ContributesAndroidInjector
    abstract fun contributeWalletMainFragment(): WalletMainFragment
}