package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.api.response.base.BaseResponse


class AppVersionResponse : BaseResponse() {

    @field:SerializedName("permission")
    val permission: Int? = 0

    @field:SerializedName("version_url")
    val versionUrl: String? = null

}