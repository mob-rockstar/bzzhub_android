package jo.basket.ui.component.imageslider.IndicatorView.draw.data;

public enum RtlMode {On, Off, Auto}