package jo.basket.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector
import jo.basket.ui.restaurant.allproduct.AllProductRestaurantFragment
import jo.basket.ui.restaurant.search.SearchFragment

@Module
abstract class FragmentRestaurantModule {

    @ContributesAndroidInjector
    abstract fun contributeAllProductRestaurantFragment(): AllProductRestaurantFragment

    @ContributesAndroidInjector
    abstract fun contributeSearchFragment(): SearchFragment
}