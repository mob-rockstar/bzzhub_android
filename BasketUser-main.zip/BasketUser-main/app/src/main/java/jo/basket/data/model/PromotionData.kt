package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.realm.RealmObject
import io.realm.RealmResults
import io.realm.annotations.LinkingObjects
import io.realm.annotations.PrimaryKey

open class PromotionData : RealmObject() {
    @LinkingObjects("promotions")
    val stores: RealmResults<Store>? = null

    @SerializedName("id")
    @Expose
    @PrimaryKey
    var id: Int? = null

    @SerializedName("image")
    @Expose
    var image: String? = null

    @SerializedName("created_date")
    @Expose
    var createdDate: String? = null

    @SerializedName("updated_date")
    @Expose
    var updatedDate: String? = null

    @SerializedName("title")
    @Expose
    var title: String? = null

    @SerializedName("promotion_detail")
    @Expose
    var detail: String? = null
}