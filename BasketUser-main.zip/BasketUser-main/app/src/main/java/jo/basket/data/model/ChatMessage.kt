package jo.basket.data.model

import com.google.gson.annotations.SerializedName

data class ChatMessage(
    @SerializedName("content")
    val content: String? = null,
    @SerializedName("createdat")
    val createdat: String? = null,
    @SerializedName("image")
    val image: String? = null,
    @SerializedName("message_text_type")
    val messageTextType: Int? = null,
    @SerializedName("order_outlet_id")
    val orderOutletId: Int? = null,
    @SerializedName("receiver")
    val `receiver`: Int? = null,
    @SerializedName("sender")
    val sender: Int? = null,
    @SerializedName("sender_name")
    val senderName: String? = null,
    @SerializedName("video")
    val video: String? = null,
    @SerializedName("viewed")
    val viewed: Int? = null
)