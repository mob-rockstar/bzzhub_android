package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.Category
import jo.basket.data.model.Department


class StoreCategoryResponse {

    @field:SerializedName("httpCode")
    var code: Int? = 0

    @field:SerializedName("Message")
    var message: String? = null

    @field:SerializedName("aisle_list")
    val categories: List<Category>? = null

    @field:SerializedName("department_detail")
    val department: Department? = null

    @field:SerializedName("meta")
    val meta: Meta? = null

}