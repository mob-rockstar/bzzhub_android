package jo.basket.ui.component.dialog.verifyDialog

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View.VISIBLE
import android.view.Window
import android.widget.TextView
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import jo.basket.R
import jo.basket.databinding.DialogCheckoutAddPromoBinding
import jo.basket.databinding.DialogCheckoutVerifyOtpBinding
import jo.basket.ui.component.snack.Snackbar.Companion.LENGTH_LONG
import jo.basket.utils.PopupUtils


class VerifyDialog {

    var tvErrorMessage: TextView? = null
    var dialog: Dialog? = null
    private var mContext: Context? = null

    fun openDialog(
        context: Context, verifyOtp: (otpCode: String) -> Unit
    ) {
        mContext = context
        dialog = Dialog(context)
        val binding: DialogCheckoutVerifyOtpBinding = DataBindingUtil.inflate(
            LayoutInflater.from(context),
            R.layout.dialog_checkout_verify_otp,
            null,
            false
        )

        dialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog?.setContentView(binding.root)
        dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        tvErrorMessage = binding.tvInvalid
        var otpCode = ""
        //Enable or disable 'Redeem' button base on promo code content
        binding.edittextMobileNumber.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                otpCode = binding.edittextMobileNumber.text.toString().trim()
                if (otpCode.isEmpty()) {
                    setRedeemButtonEnabled(context, binding.submit, false)
                } else {
                    setRedeemButtonEnabled(context, binding.submit, true)
                }
            }

            override fun afterTextChanged(s: Editable) {}
        })

        binding.submit.setOnClickListener {
            verifyOtp(otpCode)
        }

        PopupUtils.setDefaultDialogProperty(dialog!!)
        dialog?.show()
    }

    private fun setRedeemButtonEnabled(context: Context, btnRedeem: TextView, isEnabled: Boolean) {
        btnRedeem.isEnabled = isEnabled
        btnRedeem.isClickable = isEnabled

    }

    fun dismissDialog(){
        if (dialog != null) {
            dialog!!.dismiss()
        }
    }

    fun setErrorText(errorText: String){
        if (dialog != null && tvErrorMessage != null) {
            tvErrorMessage?.text = errorText
            tvErrorMessage?.visibility = VISIBLE
        }
    }

    companion object {
        private var instance: VerifyDialog? = null
        private val Instance: VerifyDialog
            get() {
                if (instance == null) {
                    instance = VerifyDialog()
                }
                return instance!!
            }

        fun openDialog(
            context: Context, verifyOtp: (otpCode: String) -> Unit
        ) {
            Instance.openDialog(context, verifyOtp)
        }

        fun dismissDialog(){
            Instance.dismissDialog()
        }

        fun setErrorMessage(errorText: String){
            Instance.setErrorText(errorText)
        }
    }
}