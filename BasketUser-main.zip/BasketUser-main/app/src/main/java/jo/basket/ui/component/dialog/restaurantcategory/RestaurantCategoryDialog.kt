package jo.basket.ui.component.dialog.restaurantcategory

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.Window
import android.widget.LinearLayout.VERTICAL
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import jo.basket.R
import jo.basket.data.model.Aisle
import jo.basket.databinding.DialogMenuCategoriesBinding
import jo.basket.utils.PopupUtils

class RestaurantCategoryDialog {

    private var mContext: Context ?= null
    private var dialog: Dialog ?= null
    private var categories: ArrayList<Aisle> = ArrayList()
    private var selected: Int = 0

    private var adapter: RestaurantCategoryAdapter = RestaurantCategoryAdapter(ArrayList(), 0){

    }


    fun openDialog(context: Context, onItemSelected: (position : Int) -> Unit) {
        mContext = context
        dialog = Dialog(context)
        val binding = DataBindingUtil.inflate<DialogMenuCategoriesBinding>(
            LayoutInflater.from(context),
            R.layout.dialog_menu_categories,
            null,
            false
        )

        dialog!!.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog!!.setContentView(binding.root)
        dialog!!.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        binding.recyclerView.adapter = adapter
        adapter.setOnItemSelected(onItemSelected)
        binding.recyclerView.layoutManager = LinearLayoutManager(context, RecyclerView.VERTICAL, false)

        binding.ivClose.setOnClickListener {
            dialog!!.dismiss()
        }

        PopupUtils.setDefaultDialogProperty(dialog!!)
        dialog!!.show()
    }

    fun setCategories(mCategories: ArrayList<Aisle>, selected: Int){
        this.categories = mCategories
        this.selected = selected
        adapter.setCategories(categories, selected)
    }

    fun setSelected(){

    }

    companion object {
        private var instance: RestaurantCategoryDialog? = null
        private val Instance: RestaurantCategoryDialog
            get() {
                if (instance == null) {
                    instance = RestaurantCategoryDialog()
                }
                return instance!!
            }

        fun openDialog(context: Context, onItemSelected: (position : Int) -> Unit){
            Instance.openDialog(context, onItemSelected)
        }

        fun setCategories(mCategories: ArrayList<Aisle>, selected: Int){
            Instance.setCategories(mCategories, selected)
        }
    }
}