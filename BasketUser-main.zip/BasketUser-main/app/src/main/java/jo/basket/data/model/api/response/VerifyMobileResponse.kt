package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName


class VerifyMobileResponse {

    @field:SerializedName("data")
    var data: List<Data>? = null

    @field:SerializedName("status")
    val code: Int = 0

    @field:SerializedName("message")
    val message: String? = null

    class Data {

        @field:SerializedName("social_login_type")
        var socialLoginType: String? = null

        @field:SerializedName("is_mobile_registered")
        val isMobileRegistered: Int? = 0

        @field:SerializedName("profile_setup_step")
        val profileSetupStep: Int? = 0

        @field:SerializedName("account_status")
        var accountStatus: String? = null

        @field:SerializedName("customer_id")
        val customerId: Long? = 0

        @field:SerializedName("email")
        var email: String? = null

        @field:SerializedName("first_name")
        var first_name: String? = null

        @field:SerializedName("last_name")
        var last_name: String? = null

        @field:SerializedName("mobile")
        var mobile: String? = null

        @field:SerializedName("image")
        var image: String? = null

        @field:SerializedName("currency_symbol")
        var currency: String? = "JD"

        @field:SerializedName("country_flag_url")
        var countryFlag: String? = ""
    }

}