package jo.basket.data.local.db

import jo.basket.data.local.db.realm.*
import jo.basket.data.model.*

object RealmManager {

    // Defining variables in here...
    private val storeRepo = StoreRepo()
    private val homePageRepo = HomePageRepo()
    private val categoryRepo = CategoryRepo()
    private val productRepo = ProductRepo()
    private val addressRepo = AddressRepo()
    private val addressTypeRepo = AddressTypeRepo()
    private val contactSettingsRepo = ContactSettingRepo()
    private val cityRepo = CityRepo()
    private val areaRepo = AreaRepo()
    private val cityAreaRepo =  CityAreaRepo()

    // Getter and Setters
    fun getLocalCityData(): List<City> {
        return cityRepo.findAll()
    }

    fun getLocalAreaData(cityId: Int): List<Area> {
        return areaRepo.findInCity(cityId)
    }

    fun setLocalAreaData(cityId: Int, areas: List<Area>) {
        val city = cityRepo.getById(cityId)
        if (city != null) {
            city.areas.clear()
            city.areas.addAll(areas)
            cityRepo.save(city)
        } else {
            areas.forEach { area -> areaRepo.save(area) }
        }
    }

    fun setLocalCityData(cities: List<City>) {
        cities.forEach { city -> cityRepo.save(city) }
    }

    fun setLocalCityAreaData(cities: List<CityArea>) {
        cities.forEach { city -> cityAreaRepo.save(city) }
    }
    fun getLocalAreaDetail(areaId: Int): Area?{
        return areaRepo.getById(areaId)
    }


    fun getLocalCityDetail(cityId: Int): City? {
        return cityRepo.getById(cityId)
    }

    fun getLocalStoreData(areaId: Int): List<Store> {
        return storeRepo.findInArea(areaId)
    }

    fun setLocalStoreData(areaId: Int, stores: List<Store>) {
        val area = areaRepo.getById(areaId)
        if (area != null) {
         //   area.stores.clear()
            for (store in stores){
                if (!area.stores.contains(store)){
                    area.stores.add(store)
                }
            }
            areaRepo.save(area)
        } else {
            stores.forEach { store -> storeRepo.save(store) }
        }
    }

    fun getLocalStore(storeId: Int): Store? {
        return storeRepo.getById(storeId)
    }

    fun getLocalHomePageData(storeId: Int): List<NewHomePageData> {
        return homePageRepo.findInStore(storeId)
    }

    fun setLocalHomePageData(storeId: Int, homePages: List<NewHomePageData>) {
        val store = storeRepo.getById(storeId)
        if (store != null) {
            store.homePages.clear()
            store.homePages.addAll(homePages)
            storeRepo.save(store)
        } else {
            homePages.forEach { homePage -> homePageRepo.save(homePage) }
        }
    }

    fun getLocalHomePage(homePageId: Int): NewHomePageData? {
        return homePageRepo.getById(homePageId)
    }

    fun getLocalCategoryData(departmentId: Int): List<Category> {
        return categoryRepo.findInDepartment(departmentId)
    }

    fun setLocalCategoryData(departmentId: Int, categories: List<Category>) {
        categories.forEach { category ->
            category.departmentId = departmentId
            categoryRepo.save(category, true)
        }
    }

    fun getLocalCategory(categoryId: Int): Category? {
        return categoryRepo.getById(categoryId)
    }

    fun getLocalProductData(categoryId: Int): List<Product> {
        return productRepo.findInCategory(categoryId)
    }

    fun setLocalProductData(categoryId: Int, products: List<Product>) {
        val category = categoryRepo.getById(categoryId)
        if (category != null) {
            category.fullProducts.clear()
            category.fullProducts.addAll(products)
            categoryRepo.save(category)
        } else {
            products.forEach { product -> productRepo.save(product) }
        }
    }

    fun setLocalProducts(products: List<Product>) {
        products.forEach { product -> productRepo.save(product) }
    }

    fun setLocalProduct(product: Product) {
        return productRepo.save(product)
    }

    fun getLocalProduct(productId: Int): Product? {
        return productRepo.getById(productId)
    }

    fun getLocalFavoriteProducts(storeId: Int): List<Product> {
        return productRepo.findFavoritesInStore(storeId)
    }

    fun getLocalFeaturedProducts(storeId: Int): List<Product> {
        return productRepo.findFeaturedInStore(storeId)
    }

    fun getLocalAddressData(mCountryId: Int): List<Address> {
        return if (mCountryId != 0) addressRepo.findInCountry(mCountryId)
        else addressRepo.findAll()
    }

    fun setLocalAddressData(addresses: List<Address>) {
        addresses.forEach { address -> addressRepo.save(address) }
    }

    fun getLocalAddressDetail(addressId: Int): Address? {
        return addressRepo.getById(addressId)
    }

    fun setLocalAddressDetail(address: Address) {
        addressRepo.save(address)
    }

    fun removeAddress(address: Address) {
        addressRepo.delete(address)
    }

    fun getLocalAddressTypes(): List<AddressType> {
        return addressTypeRepo.findAll()
    }

    fun setLocalAddressTypes(addressesTypes: List<AddressType>) {
        addressesTypes.forEach { addressType -> addressTypeRepo.save(addressType) }
    }

    fun getLocalContactInformation(): ContactSettings? {
        return contactSettingsRepo.load()
    }

    fun setLocalContactInformation(contactSettings: ContactSettings) {
        contactSettingsRepo.save(contactSettings)
    }

}
