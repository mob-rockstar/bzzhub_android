package jo.basket.data.model.api.response

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import jo.basket.data.model.PromoCode


class PromoCodeResponse {

    @SerializedName("httpCode")
    @Expose
    var code: Int = 0

    @SerializedName("Message")
    @Expose
    var message: String? = null

    @SerializedName("promo_list")
    @Expose
    var promoCodes: List<PromoCode>? = null

}