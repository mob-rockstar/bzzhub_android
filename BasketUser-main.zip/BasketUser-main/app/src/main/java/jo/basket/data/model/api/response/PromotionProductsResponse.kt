package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.Brand
import jo.basket.data.model.Product
import jo.basket.data.model.PromotionDetails

class PromotionProductsResponse {

    @field:SerializedName("httpCode")
    var code: Int? = 0

    @field:SerializedName("Message")
    var message: String? = null

    @field:SerializedName("product_list")
    val products: List<Product>? = null

    @field:SerializedName("promotions_detail")
    val promotionDetails: PromotionDetails? = null

    @field:SerializedName("brand_list")
    val brands: List<Brand>? = null

}