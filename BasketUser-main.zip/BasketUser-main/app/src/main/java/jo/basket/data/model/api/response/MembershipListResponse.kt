package jo.basket.data.model.api.response


import com.google.gson.annotations.SerializedName
import jo.basket.data.model.UserMembership

data class MembershipListResponse(
    var httpCode: Int,
    @SerializedName("membership_list")
    var membershipList: List<UserMembership>,
    @SerializedName("Message")
    var message: String
)