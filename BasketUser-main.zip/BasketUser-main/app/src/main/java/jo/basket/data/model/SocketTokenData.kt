package jo.basket.data.model

import com.google.gson.annotations.SerializedName

open class SocketTokenData {
    @SerializedName("service_token")
    var serviceToken: String = ""
}