package jo.basket.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector
import jo.basket.ui.invitefriend.search.InviteFriendSearchFragment
import jo.basket.ui.language.ads.UserADSFragment

@Module
abstract class FragmentInviteFriendModule {
    @ContributesAndroidInjector
    abstract fun contributeInviteFriendSearchFragment(): InviteFriendSearchFragment
}