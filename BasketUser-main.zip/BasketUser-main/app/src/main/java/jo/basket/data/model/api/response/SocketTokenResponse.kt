package jo.basket.data.model.api.response

import jo.basket.data.model.SocketTokenData

open class SocketTokenResponse(
    var `data`: SocketTokenData? = null,
    var message: String = "",
    var status: Int = 0
)