package jo.basket.ui.checkout.detail.slot

import android.content.Context
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import jo.basket.R
import jo.basket.data.model.Cart
import jo.basket.data.model.DeliveryDay
import jo.basket.data.model.DeliveryTime
import jo.basket.databinding.RecyclerItemCheckoutDeliveryTimeBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter
import jo.basket.utils.AppConstants
import jo.basket.utils.DateUtils
import jo.basket.utils.MessageEvent
import org.greenrobot.eventbus.EventBus
import timber.log.Timber
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class CheckoutDeliveryTimeAdapter : BaseRecyclerViewAdapter<Cart, RecyclerItemCheckoutDeliveryTimeBinding>(),
    CheckoutDeliveryDayAdapter.OnDaySelectedListener,
    CheckoutDeliverySlotAdapter.OnSelectTimeListener{

    override val layoutId: Int
        get() = R.layout.recycler_item_checkout_delivery_time

    var listener: OnChangeTimeSelectedListener? = null
    var deliveryDayAdapter: CheckoutDeliveryDayAdapter = CheckoutDeliveryDayAdapter()
    var cart: Cart? = null
    var rvDeliveryDay : RecyclerView? = null
    var deliverySlotAdapter : CheckoutDeliverySlotAdapter = CheckoutDeliverySlotAdapter()
    var selectedHolder : DeliveryTimeViewHolder ?= null
    var isExpress: Boolean = false
    var service_type_id: Int = 0

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = createBindedView(viewGroup)
        return DeliveryTimeViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as DeliveryTimeViewHolder
        val context = holder.itemView.context
        val cart = items[position]
        selectedHolder = holder

        holder.binding.tvDay.text = if (items.size == 1)context.resources.getString(R.string.choose_delivery_time) else context.resources.getString(R.string.str_store_delivery_time, cart.displayName)
        holder.binding.tvDeliveryTime.visibility = GONE
        holder.binding.tvDeliveryTime.text = ""
        val enabled = true
        // Check if Checkout is possible or not
        holder.itemView.setOnClickListener {
            if (enabled && selected != position && !isExpress) {
                setSelection(position)
            } else {
                setDeliveryTimeText(cart,context,holder)
                selected = -1
            }
        }

        if (selected == position){
            this.cart = cart
            holder.binding.layoutSlot.visibility = VISIBLE
            EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_CHECKOUT_DELIVERY_TIME_OPENED))
            rvDeliveryDay = holder.binding.rvDeliveryDay
            if (holder.binding.rvDeliveryDay.layoutManager == null){
                holder.binding.rvDeliveryDay.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            }
            if (holder.binding.rvDeliveryDay.adapter == null){
                holder.binding.rvDeliveryDay.adapter = deliveryDayAdapter
            }
            deliveryDayAdapter.cart = cart
            deliveryDayAdapter.setOnItemSelectListener(this)

            holder.binding.rvDeliverySlot.layoutManager = LinearLayoutManager(context)
            holder.binding.rvDeliverySlot.adapter = deliverySlotAdapter
            deliverySlotAdapter.cart = cart
            deliverySlotAdapter.listener = this

             if(service_type_id == 1 ){
                 holder.binding.layoutSlot.visibility = GONE
                 holder.binding.ivDropDownDeliveryTime.visibility = GONE
                 holder.binding.tvDay.visibility = GONE
                 holder.binding.tvDeliveryTime.visibility = GONE
                 holder.binding.tvDayExpress.visibility = VISIBLE
                 holder.binding.tvDayExpress.text = context.resources.getString(R.string.str_title_delivery_time) + " "+ context.resources.getString(R.string.str_delivery_time_exprss)
             }else{
                 holder.binding.tvDayExpress.visibility = GONE
                 if (deliverySlotAdapter.getItems() == null){
                     holder.binding.layoutEmptyDeliveryTime.visibility = VISIBLE
                     holder.binding.rvDeliverySlot.visibility = GONE
                 }else{
                     holder.binding.layoutEmptyDeliveryTime.visibility = GONE
                     holder.binding.rvDeliverySlot.visibility = VISIBLE
                 }
             }
            holder.binding.tvDay.text =
                if (items.size == 1) {
                    holder.binding.tvEdit.text = context.resources.getString(R.string.str_add)
                    context.resources.getString(R.string.choose_delivery_time)
                } else{
                    holder.binding.tvEdit.text = context.resources.getString(R.string.change)
                    context.resources.getString(R.string.str_store_delivery_time, cart.displayName)
                }
            holder.binding.tvDeliveryTime.visibility = GONE
            holder.binding.tvDeliveryTime.text = ""
            holder.binding.tvEdit.visibility = GONE
            holder.binding.ivDropDownDeliveryTime.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_close_black_24dp))
        }else{
            if (!isExpress) holder.binding.tvEdit.visibility = GONE
            holder.binding.ivDropDownDeliveryTime.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_arrow_down))
            setDeliveryTimeText(cart,context,holder)
        }
    }

    private fun setDeliveryTimeText(cart: Cart,context: Context,holder: DeliveryTimeViewHolder){
        if (!isExpress)  holder.binding.tvEdit.visibility = GONE
        holder.binding.ivDropDownDeliveryTime.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_arrow_down))
        holder.binding.layoutSlot.visibility = GONE
        // If Delivery Date and Time is Existing for Cart
        if (!cart.deliveryDate.isNullOrEmpty() && !cart.deliveryTime.isNullOrEmpty()) {
            var day = ""
            try {
                val date = SimpleDateFormat("dd-MM-yyyy", Locale.US).parse(cart.deliveryDate!!)
                day = SimpleDateFormat("EEE MMM dd, ", Locale.US).format(date!!)
            } catch (e: Exception) {
                e.stackTrace
            }
            holder.binding.tvDay.text =
                if (cart.deliveryLabel!!.contains(
                        context.resources.getString(R.string.str_now),
                        true
                    )
                ){
                    holder.binding.tvDeliveryTime.visibility = GONE
                    holder.binding.tvDeliveryTime.text = ""
                    if (cart.deliveryLabel!!.contains(context.resources.getString(R.string.today))){
                        cart.deliveryLabel
                    }else context.resources.getString(R.string.today) + " " + cart.deliveryLabel
                }
                else{
                    holder.binding.tvDeliveryTime.visibility = VISIBLE
                    holder.binding.tvDeliveryTime.text =  cart.deliveryTime
                    if(DateUtils.compareDateWithToday(cart.deliveryDate!!)) context.resources.getString(R.string.today)
                    else day
                }
            holder.binding.tvEdit.text = context.resources.getString(R.string.change)
        }else{
            if (items.size == 1){
                holder.binding.tvEdit.text = context.resources.getString(R.string.str_add)
                context.resources.getString(R.string.choose_delivery_time)
            } else {
                holder.binding.tvEdit.text = context.resources.getString(R.string.change)
                context.resources.getString(R.string.str_store_delivery_time, cart.displayName)
            }
        }
    }

    override fun onDaySelected(day: DeliveryDay) {
        deliverySlotAdapter.setItems(day.times ?: ArrayList())

        if (day.times == null){
            selectedHolder?.binding?.layoutEmptyDeliveryTime?.visibility = VISIBLE
            selectedHolder?.binding?.rvDeliverySlot?.visibility = GONE
        }else{
            selectedHolder?.binding?.layoutEmptyDeliveryTime?.visibility = GONE
            selectedHolder?.binding?.rvDeliverySlot?.visibility = VISIBLE

            if (day.weekDate!! == cart!!.deliveryDate){
                for (i in day.times!!.indices){
                    if (day.times!![i].id == cart!!.deliverySlotTimeId){
                        deliverySlotAdapter.setSelection(i)
                        return
                    }
                }
            }
        }
    }

    //Change selected item position
    override fun setSelection(position: Int) {
        if (items.isNotEmpty() && position >= 0){
            if (items[position].isGridView != 1){
                super.setSelection(position)
            }
        }

        if (position > -1 && items.isNotEmpty()){
            listener?.onChangeTimeSelected(items[position], position)
        }
    }

    fun setOnItemSelectListener(listener: OnChangeTimeSelectedListener) {
        this.listener = listener
    }

    interface OnChangeTimeSelectedListener {
        fun onChangeTimeSelected(cart: Cart,position: Int)
        fun onTimeSelected(cart: Cart, deliveryTime: DeliveryTime)
    }

    override fun onTimeSelected(cart: Cart, deliveryTime: DeliveryTime) {
        setSelection(-1)
        listener?.onTimeSelected(cart, deliveryTime)
    }

    class DeliveryTimeViewHolder(val binding: RecyclerItemCheckoutDeliveryTimeBinding) :
        RecyclerView.ViewHolder(binding.root)
}