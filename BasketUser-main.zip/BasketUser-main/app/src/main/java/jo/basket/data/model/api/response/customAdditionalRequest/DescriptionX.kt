package jo.basket.data.model.api.response.customAdditionalRequest

data class DescriptionX(
    val lang: String,
    val text: String
)