package jo.basket.data.model.api.response.customAdditionalRequest

class AdditionalRequest : ArrayList<AdditionalRequestItem>()