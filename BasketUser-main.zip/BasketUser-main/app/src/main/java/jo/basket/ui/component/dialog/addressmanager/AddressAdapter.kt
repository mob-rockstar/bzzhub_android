package jo.basket.ui.component.dialog.addressmanager

import android.content.Context
import android.graphics.PorterDuff
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import jo.basket.R
import jo.basket.data.model.Address
import jo.basket.databinding.RecyclerItemAddressGeofencingBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter
import jo.basket.utils.ImageUtils

// List Of Address
class AddressAdapter : BaseRecyclerViewAdapter<Address, RecyclerItemAddressGeofencingBinding>() {

    override val layoutId: Int
        get() = R.layout.recycler_item_address_geofencing

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return AddressViewHolder(createBindedView(viewGroup))
    }

    var mContext: Context? = null
    var mSelectedListener: SelectedListener? = null

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder: AddressViewHolder = viewHolder as AddressViewHolder

        val address = items[position]

        // Address Type Name
        holder.binding.tvAddressType.text = address.addressType
        // Address Name Text
        holder.binding.tvAddress.text = address.address

        val selected = (address.isSelected == 1)

        holder.binding.ivCheck.visibility = if (selected) View.VISIBLE else View.INVISIBLE
        val icon = ImageUtils.getBitmapFromAddressType(address.addressTypeId!!, address.isSelected ?: 0)

        holder.binding.ivLocation.setImageDrawable(ContextCompat.getDrawable(mContext!!, icon))
        if (selected) holder.binding.ivLocation.setColorFilter(
            ContextCompat.getColor(
                mContext!!,
                R.color.accent
            ), PorterDuff.Mode.SRC_IN
        )
        else holder.binding.ivLocation.setColorFilter(
            ContextCompat.getColor(
                mContext!!,
                R.color.md_grey_350
            ), PorterDuff.Mode.SRC_IN
        )

        holder.binding.layoutItem.setOnClickListener {
            mSelectedListener?.onAddressSelected(address)
        }
    }

    interface SelectedListener {
        fun onAddressSelected(address: Address)
    }

    fun setOnSelectListener(listener: SelectedListener) {
        mSelectedListener = listener
    }

    inner class AddressViewHolder(val binding: RecyclerItemAddressGeofencingBinding) :
        RecyclerView.ViewHolder(binding.root)
}