package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


open class StoreDeliverySlot {

    @SerializedName("outlet_id")
    @Expose
    var storeId: Int = 0

    @SerializedName("outlet_name")
    @Expose
    var storeName: String? = null

    @SerializedName("delivery_time_slot_settings_id")
    @Expose
    var deliveryTimeSlotSettingsId: Int? = null

    @SerializedName("delivery_slot")
    @Expose
    var deliveryDays: List<DeliveryDay>? = null

}