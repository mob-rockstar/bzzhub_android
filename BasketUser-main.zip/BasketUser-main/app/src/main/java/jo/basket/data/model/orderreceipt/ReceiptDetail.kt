package jo.basket.data.model.orderreceipt


import com.google.gson.annotations.SerializedName

open class ReceiptDetail {

    @SerializedName("order_outlet_id")
    var orderOutletId: Int? = null

    @SerializedName("outlet_id")
    var outletId: Int? = null

    @SerializedName("outlet_name")
    var outletName: String? = null

    @SerializedName("display_name")
    var displayName: String? = null

    @SerializedName("vendor_logo")
    var vendorLogo: String? = null

    @SerializedName("order_id")
    var orderId: Int? = null

    @SerializedName("delivery_date")
    var deliveryDate: String? = null

    @SerializedName("payment_type")
    var paymentType: String? = null

    @SerializedName("payment_gateway_id")
    var paymentGatewayId: Int? = null

    @SerializedName("card_label")
    var cardLabel: String? = null

    @SerializedName("order_items_list")
    var orderItemsList: List<ReceiptSection>? = null
}