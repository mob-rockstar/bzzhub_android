package jo.basket.data.model.api.response

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class Meta {
    @SerializedName("total")
    @Expose
    private val total: Int? = null

    @SerializedName("per_page")
    @Expose
    private val perPage: Int? = null

    @SerializedName("current_page")
    @Expose
    private val currentPage: Int? = null

    @SerializedName("last_page")
    @Expose
    private val lastPage: Int? = null
}