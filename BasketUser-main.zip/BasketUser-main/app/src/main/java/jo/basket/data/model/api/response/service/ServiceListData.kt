package jo.basket.data.model.api.response.service

import jo.basket.data.model.Banner
import jo.basket.data.model.Service

data class ServiceListData(
    val banners: List<Banner>,
    val express_store_id: Int,
    val last_completed_order_id: Int,
    val need_order_rating: Int,
    val scrolling_duration_seconds: Int,
    val services: List<Service>
)