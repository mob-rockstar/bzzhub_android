package jo.basket.data.model

class GoogleAddress(mAddress: String, mPlaceId: String) {
    var address = mAddress
    var placeId = mPlaceId
}