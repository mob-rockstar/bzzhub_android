package jo.basket.di.component

import dagger.BindsInstance
import dagger.Component
import dagger.android.AndroidInjectionModule
import jo.basket.BasketApp
import jo.basket.di.builder.ActivityBuilder
import jo.basket.di.factory.module.AppModule
import javax.inject.Singleton


@Singleton
@Component(modules = [AndroidInjectionModule::class, AppModule::class, ActivityBuilder::class])
interface AppComponent {

    @Component.Builder
    interface Builder {
        @BindsInstance
        fun application(application: BasketApp): Builder
        fun build(): AppComponent
    }

    fun inject(app: BasketApp)

}