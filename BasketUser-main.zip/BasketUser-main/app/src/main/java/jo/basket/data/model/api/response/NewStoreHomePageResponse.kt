package jo.basket.data.model.api.response

import com.google.gson.JsonElement
import com.google.gson.JsonNull
import com.google.gson.annotations.SerializedName
import jo.basket.data.model.NewHomePageData

data class NewStoreHomePageResponse(
    val `data`: List<NewHomePageData>,
    val message: String,
    @field:SerializedName("next_delivery_slot")
    val nextDeliverySlot: JsonElement = JsonNull(),
    val outlet_pricing_and_delivery_info: String,
    val status: Int,
    val store_disabled: Int,
    val vendor_name: String,
    val is_promotion_found : Int,
    val eta_to_customer_location: String,
    val outlet_opening_time : String,
    val outlet_closing_time: String,
    val isStoreOpen : Int,
    val out_of_operating_hours_message: String
)


data class NextDeliverySlot(
    val label: String,
    val slot: String
)

data class Aisle(
    val aisle_id: Int,
    val aisle_name: String
)
