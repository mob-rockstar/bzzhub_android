package jo.basket.ui.component.dialog.addressmanager

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.Window
import android.widget.TextView
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import jo.basket.R
import jo.basket.data.model.Address
import jo.basket.databinding.DialogManageAddressBinding
import jo.basket.utils.PopupUtils
/*

// Address Picker for GeoFencing
class AddressPicker {

    private var adapter: AddressAdapter = AddressAdapter()
    private var tvCurrentAddress: TextView? = null

    fun setAddressList(context: Context, addressList: List<Address>) {
        adapter.mContext = context
        adapter.setItems(addressList)
    }

    fun setCurrentAddress(currentAddress: String) {
        tvCurrentAddress?.text = currentAddress
    }

    fun openDialog(context: Context, listener: OnAddressPickListener?) {
        val dialog = Dialog(context)
        val binding = DataBindingUtil.inflate<DialogManageAddressBinding>(
            LayoutInflater.from(context),
            R.layout.dialog_manage_address,
            null,
            false
        )

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setContentView(binding.root)
        tvCurrentAddress = binding?.tvAddress
        initRecyclerView(context, binding?.recyclerView!!)

        adapter.setOnSelectListener(object : AddressAdapter.SelectedListener {
            override fun onAddressSelected(address: Address) {
                listener?.onPick(address)
            }
        })

        PopupUtils.setDefaultDialogProperty(dialog)
        dialog.show()
    }

    fun initRecyclerView(context: Context, recyclerView: RecyclerView) {
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = adapter
    }

    companion object {
        private var instance: AddressPicker? = null
        private val Instance: AddressPicker
            get() {
                if (instance == null) {
                    instance = AddressPicker()
                }
                return instance!!
            }

        fun setAddressList(context: Context, addresses: List<Address>) {
            Instance.setAddressList(context, addresses)
        }

        fun setCurrentAddress(currentAddress: String) {
            Instance.setCurrentAddress(currentAddress)
        }

        fun openDialog(context: Context, listener: OnAddressPickListener? = null) {
            Instance.openDialog(context, listener)
        }
    }

    interface OnAddressPickListener {
        fun onPick(address: Address)
    }
}*/
