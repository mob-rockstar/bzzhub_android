package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.realm.RealmObject
import io.realm.annotations.PrimaryKey


open class UserSelectedAddress : RealmObject() {

    @PrimaryKey
    @SerializedName("id")
    @Expose
    var id = 0

    @SerializedName("address_id")
    @Expose
    var addressId = 0

    @SerializedName("address_type")
    @Expose
    var addressType: String? = null

    @SerializedName("address")
    @Expose
    var address: String? = null

    @SerializedName("address_type_id")
    @Expose
    var addressTypeId = 0

    @SerializedName("country_id")
    @Expose
    var countryId = 0

    @SerializedName("city_id")
    @Expose
    var cityId = 0

    @SerializedName("location_id")
    @Expose
    var locationId = 0

    @SerializedName("latitude")
    @Expose
    var latitude: Double? = null

    @SerializedName("longtitude")
    @Expose
    var longtitude: Double? = null

    @SerializedName("near_landmark")
    @Expose
    var nearLandmark: String? = null

    @SerializedName("additional_info")
    @Expose
    var additionalInfo: String? = null

    @SerializedName("department_building")
    @Expose
    var departmentBuilding: String? = null

    @SerializedName("available")
    @Expose
    var available = 0

    @SerializedName("is_selected")
    @Expose
    var isSelected = 0

}