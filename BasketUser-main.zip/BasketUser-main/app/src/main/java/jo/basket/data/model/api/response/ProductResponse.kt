package jo.basket.data.model.api.response

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import jo.basket.data.model.Product


class ProductResponse {

    @SerializedName("httpCode")
    @Expose
    var code: Int = 0

    @SerializedName("Message")
    @Expose
    var message: String? = null

    @SerializedName("product_detail")
    @Expose
    var productDetail: Product? = null

    @SerializedName("featured_products")
    @Expose
    var featuredProducts: List<Product>? = null

}