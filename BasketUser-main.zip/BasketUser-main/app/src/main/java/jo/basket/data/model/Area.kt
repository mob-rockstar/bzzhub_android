package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.realm.RealmList
import io.realm.RealmObject
import io.realm.RealmResults
import io.realm.annotations.LinkingObjects
import io.realm.annotations.PrimaryKey

open class Area : RealmObject() {
    @LinkingObjects("areas")
    val city: RealmResults<City>? = null

    var stores: RealmList<Store> = RealmList<Store>()

    @PrimaryKey
    @SerializedName("id")
    @Expose
    var id: Int = 0

    @SerializedName("zone_name")
    @Expose
    var zoneName: String? = null

    @SerializedName("created_date")
    @Expose
    var createdDate: String? = null

    @SerializedName("updated_date")
    @Expose
    var updatedDate: String? = null

    override fun toString(): String {
        return zoneName ?: ""
    }
}