package jo.basket.data.model

data class BadgeData(
    val badge: Int
)