package jo.basket.data.model.api.response


import com.google.gson.annotations.SerializedName
import jo.basket.data.model.NotificationSettingsDetails

data class NotificationSettingResponse(
    @field:SerializedName("httpCode")
    val code: Int = 0,
    @field: SerializedName("Message")
    val message: String,
    @field: SerializedName("notification_settings_details")
    val notificationSettingsDetails: NotificationSettingsDetails?
)