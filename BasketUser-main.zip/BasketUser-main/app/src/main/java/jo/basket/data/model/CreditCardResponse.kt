package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

open class CreditCardResponse {
    @SerializedName("httpCode")
    @Expose
    val httpCode = 0

    @SerializedName("popup_title")
    @Expose
    val title: String? = null

    @SerializedName("popup_description")
    @Expose
    val description: String? = null

    @SerializedName("Message")
    @Expose
    val message: String? = null

    @SerializedName("status")
    @Expose
    val status: Int? = null

}
