package jo.basket.data.model


import com.google.gson.annotations.SerializedName
import io.realm.RealmObject
import io.realm.annotations.PrimaryKey

open class ContactSettings : RealmObject() {
    @PrimaryKey
    @SerializedName("contact_mail")
    var contactMail: String? = ""

    @SerializedName("customer_care")
    var customerCare: String? = ""

    @SerializedName("shopper_care")
    var shopperCare: String? = ""

    @SerializedName("support_mail")
    var supportMail: String? = ""
}