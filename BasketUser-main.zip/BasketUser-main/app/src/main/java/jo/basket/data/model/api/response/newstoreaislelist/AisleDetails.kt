package jo.basket.data.model.api.response.newstoreaislelist

data class AisleDetails(
    val app_banner_image: String,
    val id: Int,
    val name: String
)