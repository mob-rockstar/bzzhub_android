package jo.basket.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector
import jo.basket.ui.reward.code.RewardCodeFragment
import jo.basket.ui.reward.gamerule.RewardRuleOfGameFragment
import jo.basket.ui.reward.history.RewardHistoryFragment
import jo.basket.ui.reward.main.RewardMainFragment

@Module
abstract class FragmentRewardModule {
    @ContributesAndroidInjector
    abstract fun contributeRewardMainFragment(): RewardMainFragment

    @ContributesAndroidInjector
    abstract fun contributeRewardHistoryFragment(): RewardHistoryFragment

    @ContributesAndroidInjector
    abstract fun contributeRewardCodeFragment(): RewardCodeFragment

    @ContributesAndroidInjector
    abstract fun contributeRewardRuleOfGameFragment(): RewardRuleOfGameFragment

}