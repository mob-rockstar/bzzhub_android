package jo.basket.ui.component.dialog.bottomservice

import android.app.Dialog
import android.app.Service
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.Window
import android.view.WindowManager
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import jo.basket.R
import jo.basket.databinding.DialogSelectBottomTabBinding

class BottomServiceDialog {

    lateinit var dialog: Dialog

    fun openDialog(context: Context, listener: OnSelectedListener, currentTab: Int, serviceList: List<jo.basket.data.model.Service>) {
        dialog = Dialog(context, R.style.PauseDialog)
        val binding = DataBindingUtil.inflate<DialogSelectBottomTabBinding>(
            LayoutInflater.from(context),
            R.layout.dialog_select_bottom_tab,
            null,
            false
        )
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(binding.root)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val serviceAdapter = BottomServiceAdapter{
            serviceType ->
            listener.onSelected(serviceType)
            dialog.dismiss()
        }
        serviceAdapter.setItems(serviceList)
        if (currentTab != -1){
            serviceAdapter.setSelectedTab(currentTab)
        }

        binding.rvServiceType.layoutManager =
          GridLayoutManager(context, serviceList.size)
        binding.rvServiceType.adapter = serviceAdapter

        binding.layoutOutside.setOnClickListener {
            dialog.dismiss()
        }

        val lp = WindowManager.LayoutParams()
        val window = dialog.window
        lp.copyFrom(window!!.attributes)
        lp.width = WindowManager.LayoutParams.MATCH_PARENT
        lp.height = WindowManager.LayoutParams.MATCH_PARENT
        window.attributes = lp
        dialog.setCanceledOnTouchOutside(true)

        dialog.setCancelable(true)
        dialog.show()
    }

    fun dismissDialog() {
        dialog.dismiss()
    }

    companion object {
        private var instance: BottomServiceDialog? = null


        private val Instance: BottomServiceDialog
            get() {
                if (instance == null) {
                    instance = BottomServiceDialog()
                }
                return instance!!
            }

        fun openDialog(context: Context, listener: OnSelectedListener, currentTab: Int, serviceList: List<jo.basket.data.model.Service>) {
            Instance.openDialog(context, listener, currentTab, serviceList)
        }
    }

    interface OnSelectedListener {
        fun onSelected(serviceType: jo.basket.data.model.Service)
    }
}