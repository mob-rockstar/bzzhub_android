package jo.basket.data.model


import com.google.gson.annotations.SerializedName

data class HintSuggestion(
    var objectID: String,
    var popularity: Int,
    var query: String
)