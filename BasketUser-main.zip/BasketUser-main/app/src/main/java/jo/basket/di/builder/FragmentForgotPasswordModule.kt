package jo.basket.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector
import jo.basket.ui.forgotpassword.fragment.ForgotPasswordChangePasswordFragment
import jo.basket.ui.forgotpassword.fragment.ForgotPasswordMobileFragment
import jo.basket.ui.forgotpassword.fragment.ForgotPasswordOtpFragment


@Module
abstract class FragmentForgotPasswordModule {

    @ContributesAndroidInjector
    abstract fun contributeForgotPasswordMobileFragment(): ForgotPasswordMobileFragment

    @ContributesAndroidInjector
    abstract fun contributeForgotPasswordOtpFragment(): ForgotPasswordOtpFragment

    @ContributesAndroidInjector
    abstract fun contributeForgotPasswordChangePasswordFragment(): ForgotPasswordChangePasswordFragment

}
