package jo.basket.data.model


import com.google.gson.annotations.SerializedName

data class Country(
    @SerializedName("country_name")
    var countryName: String,
    @SerializedName("created_date")
    var createdDate: String,
    var id: Int,
    @SerializedName("updated_date")
    var updatedDate: String
)