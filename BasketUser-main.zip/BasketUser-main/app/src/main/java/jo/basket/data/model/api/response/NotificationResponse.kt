package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.Notification

data class NotificationResponse(
    @SerializedName("httpCode")
    var httpCode: Int,
    @SerializedName("Message")
    var message: String? = null,
    @SerializedName("notification_list")
    var notificationList: List<Notification>? = null
)