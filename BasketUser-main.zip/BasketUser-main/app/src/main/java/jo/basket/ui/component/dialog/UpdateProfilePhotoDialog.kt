package jo.basket.ui.component.dialog

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.Window
import androidx.databinding.DataBindingUtil
import jo.basket.R
import jo.basket.databinding.DialogUpdateProfilePictureBinding
import jo.basket.utils.PopupUtils

class UpdateProfilePhotoDialog {
    lateinit var dialog: Dialog

    fun openDialog(context: Context, onUpdate: () -> Unit, onRemove: ()->Unit){
        val dialog = Dialog(context)
        val binding = DataBindingUtil.inflate<DialogUpdateProfilePictureBinding>(
            LayoutInflater.from(context),
            R.layout.dialog_update_profile_picture,
            null,
            false
        )

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(binding.root)

        binding.tvRemove.setOnClickListener {
            onRemove()
            dialog.dismiss()
        }

        binding.tvUpdate.setOnClickListener {
            onUpdate()
            dialog.dismiss()
        }

        binding.ivCancel.setOnClickListener {
            dialog.dismiss()
        }

        PopupUtils.setDefaultDialogProperty(dialog)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
    }

    companion object {
        private var instance: UpdateProfilePhotoDialog? = null
        private val Instance: UpdateProfilePhotoDialog
            get() {
                if (instance == null) {
                    instance = UpdateProfilePhotoDialog()
                }
                return instance!!
            }

        fun openDialog(context: Context, onUpdate: () -> Unit, onRemove: ()-> Unit) {
            Instance.openDialog(context, onUpdate, onRemove)
        }
    }
}