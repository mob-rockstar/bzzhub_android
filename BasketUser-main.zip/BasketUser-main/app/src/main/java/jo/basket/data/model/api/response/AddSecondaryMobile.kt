package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName


data class AddSecondaryMobile (

    @SerializedName("message" ) var message : String? = null,
    @SerializedName("status"  ) var status  : Int?    = null

)