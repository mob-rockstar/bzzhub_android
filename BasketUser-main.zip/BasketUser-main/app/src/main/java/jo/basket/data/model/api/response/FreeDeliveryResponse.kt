package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName


class FreeDeliveryResponse : SimpleResponse() {
    @field:SerializedName("show_popup")
    val showPopup: Int? = null

    @field:SerializedName("refresh_delay")
    val refreshDelay: Long? = null
}