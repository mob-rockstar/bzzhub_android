package jo.basket.di

/**
 * Marks an activity / fragment injectable.
 */
interface Injectable
