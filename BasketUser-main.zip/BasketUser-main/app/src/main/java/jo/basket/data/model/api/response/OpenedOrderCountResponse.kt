package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.OpenedOrder

data class OpenedOrderCountResponse(
    @SerializedName("data")
    var data: OpenedOrder,
    @SerializedName("message")
    var message: String,
    @SerializedName("status")
    var status: Int
)