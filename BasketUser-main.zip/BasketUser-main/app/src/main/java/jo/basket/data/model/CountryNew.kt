package jo.basket.data.model


import com.google.gson.annotations.SerializedName

data class CountryNew(
    @SerializedName("city_list")
    var cityList: List<City>,
    var id: Int,
    var name: String,
    @SerializedName("country_flag_url")
    var countryFlag: String
)