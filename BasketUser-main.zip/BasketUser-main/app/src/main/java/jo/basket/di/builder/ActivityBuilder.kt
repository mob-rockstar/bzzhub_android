package jo.basket.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector
import jo.basket.ui.accountsetting.AccountSettingsActivity
import jo.basket.ui.cart.CartActivity
import jo.basket.ui.checkout.CheckoutActivity
import jo.basket.ui.deliverypricing.DeliveryTimeActivity
import jo.basket.ui.deliverypromotion.DeliveryPromotionActivity
import jo.basket.ui.forgotpassword.ForgotPasswordActivity
import jo.basket.ui.freedelivery.FreeDeliveryActivity
import jo.basket.ui.geofencing.GeoFencingActivity
import jo.basket.ui.guid.GuidActivity
import jo.basket.ui.invitefriend.InviteFriendActivity
import jo.basket.ui.language.LanguageActivity
import jo.basket.ui.location.LocationActivity
import jo.basket.ui.login.LoginActivity
import jo.basket.ui.main.MainActivity
import jo.basket.ui.makecomplain.AddComplainActivity
import jo.basket.ui.makecomplain.MakeComplainActivity
import jo.basket.ui.servicelist.ServiceListActivity
import jo.basket.ui.membership.MembershipActivity
import jo.basket.ui.notification.NotificationListActivity
import jo.basket.ui.nps.NPSActivity
import jo.basket.ui.order.OrderActivity
import jo.basket.ui.payment.PaymentActivity
import jo.basket.ui.product.ProductActivity
import jo.basket.ui.profile.ProfileActivity
import jo.basket.ui.profile.ProfileActivityNew
import jo.basket.ui.promocodes.PromoCodesActivity
import jo.basket.ui.replacementsuggestion.CartReplacementSuggestionActivity
import jo.basket.ui.restaurant.RestaurantActivity
import jo.basket.ui.reward.RewardActivity
import jo.basket.ui.shoppinglist.ShoppingListActivity
import jo.basket.ui.splash.SplashActivity
import jo.basket.ui.store.StoreActivity
import jo.basket.ui.terms.TermsAndPolicyActivity
import jo.basket.ui.wallet.WalletActivity


@Module
abstract class ActivityBuilder {

    @ContributesAndroidInjector(modules = [FragmentSplashViewModule::class])
    abstract fun bindSplashActivity(): SplashActivity

    @ContributesAndroidInjector(modules = [FragmentLoginModule::class])
    abstract fun bindLoginActivity(): LoginActivity

    @ContributesAndroidInjector(modules = [FragmentForgotPasswordModule::class])
    abstract fun bindForgotPasswordActivity(): ForgotPasswordActivity

    @ContributesAndroidInjector(modules = [FragmentLocationModule::class])
    abstract fun bindLocationActivity(): LocationActivity

    @ContributesAndroidInjector
    abstract fun bindTermsAndPolicyActivity(): TermsAndPolicyActivity

    @ContributesAndroidInjector
    abstract fun bindingMakeComplainActivity(): MakeComplainActivity

    @ContributesAndroidInjector
    abstract fun bindingAddComplainActivity(): AddComplainActivity


    @ContributesAndroidInjector(modules = [FragmentMainModule::class])
    abstract fun bindMainActivity(): MainActivity

    @ContributesAndroidInjector(modules = [FragmentStoreModule::class])
    abstract fun bindStoreActivity(): StoreActivity

    @ContributesAndroidInjector()
    abstract fun bindDeliveryPromotionActivity(): DeliveryPromotionActivity

    @ContributesAndroidInjector(modules = [FragmentProductModule::class])
    abstract fun bindProductActivity(): ProductActivity

    @ContributesAndroidInjector(modules = [FragmentCartModule::class])
    abstract fun bindCartActivity(): CartActivity

    @ContributesAndroidInjector(modules = [FragmentCheckoutModule::class])
    abstract fun bindCheckoutActivity(): CheckoutActivity

    @ContributesAndroidInjector
    abstract fun bindPaymentActivity(): PaymentActivity

    @ContributesAndroidInjector(modules = [FragmentOrderModule::class])
    abstract fun bindOrderActivity(): OrderActivity

    @ContributesAndroidInjector
    abstract fun bindNotificationListActivity(): NotificationListActivity

    @ContributesAndroidInjector(modules = [FragmentPromoCodesModule::class])
    abstract fun bindPromoCodesActivity(): PromoCodesActivity

    @ContributesAndroidInjector(modules = [FragmentProfileModule::class])
    abstract fun bindProfileActivity(): ProfileActivity

    @ContributesAndroidInjector(modules = [FragmentAccountSettingModule::class])
    abstract fun bindAccountSettingsActivity(): AccountSettingsActivity

    @ContributesAndroidInjector(modules = [FragmentDeliveryTimeModule::class])
    abstract fun bindDeliveryTimeActivity(): DeliveryTimeActivity

    @ContributesAndroidInjector
    abstract fun bindGuidActivity(): GuidActivity

    @ContributesAndroidInjector(modules = [FragmentMembershipModule::class])
    abstract fun bindMembershipActivity(): MembershipActivity

    @ContributesAndroidInjector(modules = [FragmentGeoFencingModule::class])
    abstract fun bindGeoFencingActivity(): GeoFencingActivity

    @ContributesAndroidInjector
    abstract fun bindFreeDeliveryActivity(): FreeDeliveryActivity

    @ContributesAndroidInjector(modules = [FragmentCartReplacementSuggestionModule::class])
    abstract fun bindCartReplacementSuggestionActivity(): CartReplacementSuggestionActivity

    @ContributesAndroidInjector(modules = [FragmentRewardModule::class])
    abstract fun bindCartReplacementRewardActivity(): RewardActivity

    @ContributesAndroidInjector(modules = [FragmentWalletModule::class])
    abstract fun bindWalletActivity(): WalletActivity

    @ContributesAndroidInjector(modules = [FragmentNPSModule::class])
    abstract fun bindCartNPSActivity(): NPSActivity

    @ContributesAndroidInjector(modules = [FragmentInviteFriendModule::class])
    abstract fun bindInviteFriendActivity(): InviteFriendActivity

    @ContributesAndroidInjector(modules = [FragmentLanguageModule::class])
    abstract fun bindLanguageActivity(): LanguageActivity

    @ContributesAndroidInjector
    abstract fun bindCustomShoppingListActivity(): ShoppingListActivity

    @ContributesAndroidInjector(modules = [FragmentProfileNewModule::class])
    abstract fun bindProfileActivityNew(): ProfileActivityNew

    @ContributesAndroidInjector(modules = [FragmentRestaurantModule::class])
    abstract fun bindRestaurantActivity(): RestaurantActivity

    @ContributesAndroidInjector(modules = [FragmentServiceListModule::class])
    abstract fun bindServiceListActivity(): ServiceListActivity
}