package jo.basket.data.model.payment


data class PaymentListResponse(
    var `data`: List<PaymentData>,
    var message: String,
    var status: Int
)