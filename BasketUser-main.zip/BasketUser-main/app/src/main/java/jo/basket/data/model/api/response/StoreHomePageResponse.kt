package jo.basket.data.model.api.response

import com.google.gson.JsonElement
import com.google.gson.JsonNull
import com.google.gson.annotations.SerializedName


class StoreHomePageResponse {

    @field:SerializedName("httpCode")
    var code: Int = 0

    @field:SerializedName("Message")
    var message: String? = null

    @field:SerializedName("status")
    var status: Int? = null



    @field:SerializedName("vendor_name")
    val vendorName: String? = null

    @field:SerializedName("outlet_more_info")
    val outletMoreInfo: String? = null

    @field:SerializedName("outlet_pricing_and_delivery_info")
    val outletPricingAndDeliveryInfo: String? = null

    @field:SerializedName("outlet_status_flag")
    val outletStatusFlag: Int = 0

    @field:SerializedName("next_delivery_slot")
    val nextDeliverySlot: JsonElement = JsonNull()

    @field:SerializedName("total_running_orders")
    val totalRunningOrders: Int = 0

    @field:SerializedName("running_order_id")
    val runningOrderId: Int = 0

}