package jo.basket.data.model

import com.google.gson.annotations.SerializedName

class UserMembership {

    @field:SerializedName("name")
    var name: String? = null

    @field:SerializedName("description")
    var desc: String? = null

    @field:SerializedName("image")
    var image: String? = null

    @field:SerializedName("id")
    var id: Int = 0

    @field:SerializedName("type")
    var type: Int? = null

    @field:SerializedName("duration")
    var duration: Int? = null

    @field:SerializedName("amount")
    var amount: String? = null

    @field:SerializedName("min_order_amount")
    var minOrderAmount: String? = null

    @field:SerializedName("start_date")
    var startDate: String? = null

    @field:SerializedName("end_date")
    var endDate: String? = null

    @field:SerializedName("status")
    var status: Int? = null

    @field:SerializedName("is_cancel")
    var isCancel: Int? = null

    @field:SerializedName("cancel_label")
    var cancelLabel: String? = null
}