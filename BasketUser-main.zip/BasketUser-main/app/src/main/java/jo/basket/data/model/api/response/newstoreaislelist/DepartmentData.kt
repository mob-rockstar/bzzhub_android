package jo.basket.data.model.api.response.newstoreaislelist

import jo.basket.data.model.Product

data class DepartmentData(
    val aisle_details: AisleDetails,
    val department_details: DepartmentDetails,
    val products: ArrayList<Product>
)