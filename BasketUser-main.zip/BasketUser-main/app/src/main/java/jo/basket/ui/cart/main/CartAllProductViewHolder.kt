package jo.basket.ui.cart.main

import  android.graphics.Paint
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.daimajia.swipe.SimpleSwipeListener
import com.daimajia.swipe.SwipeLayout
import jo.basket.R
import jo.basket.data.local.prefs.PreferenceManager
import jo.basket.data.model.Product
import jo.basket.data.model.api.response.Outlet
import jo.basket.data.model.api.response.ProductImages
import jo.basket.databinding.RecyclerAllItemCartProductBinding
import jo.basket.databinding.RecyclerItemCartProductBinding
import jo.basket.utils.FormatterUtils
import jo.basket.utils.GlideApp
import java.util.Locale


class CartAllProductViewHolder(
    val binding: RecyclerAllItemCartProductBinding,
) : RecyclerView.ViewHolder(binding.root) {

    private var mProduct: Outlet? = null

    fun update(product: Outlet) {
        binding.executePendingBindings()
        val context = binding.root.context

        mProduct = product

        // Set Product Image
        GlideApp.with(context).load(product.logoImage).diskCacheStrategy(
            DiskCacheStrategy.ALL
        ).fitCenter()
            .error(R.drawable.placeholder300x300).format(
                DecodeFormat.PREFER_ARGB_8888
            ).into(binding.ivProduct)
        /*if (product.productImage != null) {
            GlideApp.with(context).load(product.productImage).diskCacheStrategy(
                DiskCacheStrategy.ALL
            ).fitCenter()
                .error(R.drawable.placeholder300x300).format(
                    DecodeFormat.PREFER_ARGB_8888
                ).into(binding.ivProduct)
        }*/

    }


}