package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.realm.RealmList
import io.realm.RealmObject
import io.realm.RealmResults
import io.realm.annotations.LinkingObjects
import io.realm.annotations.PrimaryKey

open class NewHomePageData: RealmObject() {
    @LinkingObjects("homePages")
    val store: RealmResults<Store>? = null

    @SerializedName("aisles")
    @Expose
    var aisles: RealmList<Aisle>? = null

    @SerializedName("banner")
    @Expose
    var banner: String? = null

    @SerializedName("header_banner_image")
    @Expose
    var header_banner_image: String? = null

    @SerializedName("id")
    @Expose
    @PrimaryKey
    var id: Int? = null

    @SerializedName("image")
    @Expose
    var image: String? = null

    @SerializedName("name")
    @Expose
    var name: String? = null

    @SerializedName("promotions_list")
    @Expose
    var promotions_list: RealmList<NewPromotionData>? = null

    @SerializedName("section_type")
    @Expose
    var section_type: String? = null

    @SerializedName("product_count")
    @Expose
    var productCount: Int? = null
}