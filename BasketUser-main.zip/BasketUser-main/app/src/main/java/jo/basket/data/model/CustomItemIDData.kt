package jo.basket.data.model


import com.google.gson.annotations.SerializedName

data class CustomItemIDData(
    @SerializedName("item_id")
    var itemId: Int
)