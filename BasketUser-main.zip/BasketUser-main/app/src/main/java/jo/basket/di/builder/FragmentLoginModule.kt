package jo.basket.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector
import jo.basket.ui.login.fragment.*
import jo.basket.ui.login.fragment.slider.LoginTypeCartFragment
import jo.basket.ui.login.fragment.slider.LoginTypeOrderFragment
import jo.basket.ui.login.fragment.slider.LoginTypeShopperFragment
import jo.basket.ui.login.fragment.slider.LoginTypeStoreFragment

@Module
abstract class FragmentLoginModule {

    @ContributesAndroidInjector
    abstract fun contributeLoginTypeFragment(): LoginTypeFragment

    @ContributesAndroidInjector
    abstract fun contributeLoginPhonenumberFragment(): LoginPhonenumberFragment

    @ContributesAndroidInjector
    abstract fun contributeLoginOtpFragment(): LoginOtpFragment

    @ContributesAndroidInjector
    abstract fun contributeLoginPasswordFragment(): LoginPasswordFragment

    @ContributesAndroidInjector
    abstract fun contributeLoginSocialFragment(): LoginSocialFragment

    @ContributesAndroidInjector
    abstract fun contributeLoginInformationFragment(): LoginInformationFragment

    @ContributesAndroidInjector
    abstract fun contributeLoginUserInfoFragment(): LoginUserInfoFragment

    @ContributesAndroidInjector
    abstract fun contributeLoginTypeStoreFragment(): LoginTypeStoreFragment

    @ContributesAndroidInjector
    abstract fun contributeLoginTypeOrderFragment(): LoginTypeOrderFragment

    @ContributesAndroidInjector
    abstract fun contributeLoginTypeShopperFragment(): LoginTypeShopperFragment

    @ContributesAndroidInjector
    abstract fun contributeLoginTypeCartFragment(): LoginTypeCartFragment

}
