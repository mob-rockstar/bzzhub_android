package jo.basket.data.model

open class SortedContact {
    var initial: String = ""
    var contactList: ArrayList<Contact> = ArrayList()
}