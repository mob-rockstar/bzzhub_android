package jo.basket.data.model.api.response

import jo.basket.data.model.BadgeData

data class UnreadNotificationResponse(
    val `data`: BadgeData,
    val message: String,
    val status: Int
)