package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.LowInStockSuggestedItem

class LowInStockSuggestionListResponse {
    @field:SerializedName("data")
    val data: ArrayList<LowInStockSuggestedItem>? = null

    @field:SerializedName("status")
    val code: Int = 0

    @field:SerializedName("message")
    val message: String? = null
}