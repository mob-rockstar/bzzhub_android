package jo.basket.data.model.payfort

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class PayResponseBody {

    @SerializedName("amount")
    @Expose
    var amount: String? = null

    @SerializedName("response_code")
    @Expose
    var responseCode: String? = null

    @SerializedName("card_number")
    @Expose
    var cardNumber: String? = null

    @SerializedName("signature")
    @Expose
    var signature: String? = null

    @SerializedName("merchant_identifier")
    @Expose
    var merchantIdentifier: String? = null

    @SerializedName("access_code")
    @Expose
    var accessCode: String? = null

    @SerializedName("payment_option")
    @Expose
    var paymentOption: String? = null

    @SerializedName("expiry_date")
    @Expose
    var expiryDate: String? = null

    @SerializedName("customer_ip")
    @Expose
    var customerIp: String? = null

    @SerializedName("language")
    @Expose
    var language: String? = null

    @SerializedName("eci")
    @Expose
    var eci: String? = null

    @SerializedName("fort_id")
    @Expose
    var fortId: String? = null

    @SerializedName("command")
    @Expose
    var command: String? = null

    @SerializedName("response_message")
    @Expose
    var responseMessage: String? = null

    @SerializedName("merchant_reference")
    @Expose
    var merchantReference: String? = null

    @SerializedName("authorization_code")
    @Expose
    var authorizationCode: String? = null

    @SerializedName("customer_email")
    @Expose
    var customerEmail: String? = null

    @SerializedName("token_name")
    @Expose
    var tokenName: String? = null

    @SerializedName("currency")
    @Expose
    var currency: String? = null

    @SerializedName("status")
    @Expose
    var status: String? = null

}