package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName


class SimpleStatusResponse {

    @field:SerializedName("status")
    val code: Int = 0

    @field:SerializedName("message")
    val message: String? = null

    @field:SerializedName("error")
    val error: String? = null

}