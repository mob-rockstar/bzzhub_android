package jo.basket.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector
import jo.basket.ui.main.about.AboutAppFragment
import jo.basket.ui.main.language.LanguageSettingsFragment
import jo.basket.ui.main.order.OrderFragment
import jo.basket.ui.main.store.SearchFragment
import jo.basket.ui.main.store.StoreFilterByTypeFragment
import jo.basket.ui.main.store.StoreFragment
import jo.basket.ui.main.store.StoreSpecialListFragment
import jo.basket.ui.main.store.ViewAllStoreFragment
import jo.basket.ui.main.type.StoreTypeNewFragment


@Module
abstract class FragmentMainModule {

    @ContributesAndroidInjector
    abstract fun contributeStoreFragment(): StoreFragment

    @ContributesAndroidInjector
    abstract fun contributeStoreTypeNewFragment(): StoreTypeNewFragment

    @ContributesAndroidInjector
    abstract fun contributeOrderFragment(): OrderFragment

    @ContributesAndroidInjector
    abstract fun contributeAboutFragment(): AboutAppFragment

    @ContributesAndroidInjector
    abstract fun contributeLanguageSettingsFragment(): LanguageSettingsFragment

    @ContributesAndroidInjector
    abstract fun contributeSearchFragment(): SearchFragment

    @ContributesAndroidInjector
    abstract fun contributeStoreFilterByTypeFragment(): StoreFilterByTypeFragment

    @ContributesAndroidInjector
    abstract fun contributeStoreSpecialListFragment(): StoreSpecialListFragment
    @ContributesAndroidInjector
    abstract fun contributeViewAllStoreFragment(): ViewAllStoreFragment
}
