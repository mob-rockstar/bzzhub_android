package jo.basket.ui.base


import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.IdRes
import androidx.annotation.LayoutRes
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProviders
import dagger.android.support.AndroidSupportInjection
import jo.basket.R
import jo.basket.data.local.prefs.PreferenceManager
import jo.basket.di.Injectable
import jo.basket.di.factory.ViewModelProviderFactory
import jo.basket.ui.base.navigator.Navigator
import jo.basket.utils.PopupUtils
import jo.basket.utils.analytics.BasketAnalyticsManager
import javax.inject.Inject
import androidx.lifecycle.ViewModelProvider





abstract class BaseFragment<T : ViewDataBinding?, V : BaseViewModel?> : Fragment(), Injectable {

    @Inject
    lateinit var viewModelFactory: ViewModelProviderFactory

    @Inject
    lateinit var navigator: Navigator

    lateinit var baseActivity: BaseActivity<*, *>
        private set

    private var mRootView: View? = null
    var viewDataBinding: T? = null
        private set
    private var mViewModel: V? = null
    var isViewAlive = true

    /**
     * Override for set binding variable
     *
     * @return variable id
     */
    private val bindingVariable: Int = 0

    /**
     * @return layout resource id
     */
    @get:LayoutRes
    abstract val layoutId: Int

    /**
     * Override for set view model
     *
     * @return view model instance
     */
    abstract val viewModel: V

    var progressView: View? = null


    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is BaseActivity<*, *>) {
            baseActivity = context
            baseActivity.onFragmentAttached()
        }
    }

    protected open fun <T : ViewModel> getViewModel(cls: java.lang.Class<T>): T {
        return ViewModelProvider(this)[cls]
    }

    protected open fun <T : ViewModel> getViewModel(
        fregmentActivity: FragmentActivity,
        cls: java.lang.Class<T>
    ): T {
        return ViewModelProvider(fregmentActivity)[cls]
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        performDependencyInjection()
        super.onCreate(savedInstanceState)
        mViewModel = viewModel
        setHasOptionsMenu(false)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        viewDataBinding = DataBindingUtil.inflate<T>(inflater, layoutId, container, false)
        mRootView = viewDataBinding!!.root
        return mRootView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewDataBinding!!.setVariable(bindingVariable, mViewModel)
        viewDataBinding!!.lifecycleOwner = this
        viewDataBinding!!.executePendingBindings()
        mViewModel?.isLoading!!.observe(baseActivity, { consumeResponse(it) })
    }

    override fun onDestroyView() {
        super.onDestroyView()
        isViewAlive = false
        viewDataBinding = null
    }

    open fun consumeResponse(o: Boolean) {
        if (o) {
            showLoading()
        } else {
            hideLoading()
        }
    }

    fun showLoading() {
        if (progressView != null) {
            progressView!!.visibility = View.VISIBLE
        }
    }

    fun hideLoading() {
        if (progressView != null) {
            progressView!!.visibility = View.GONE
        }
    }

    val isNetworkConnected: Boolean
        get() = baseActivity.isNetworkConnected


    private fun performDependencyInjection() {
        AndroidSupportInjection.inject(this)
    }

    interface Callback {
        fun onFragmentAttached()
        fun onFragmentDetached(tag: String?)
    }


    private fun showSuccessCaseFor(successView: View, errorView: View) {
        successView.visibility = View.VISIBLE
        errorView.visibility = View.GONE
    }

    private fun showErrorCaseFor(successView: View, errorView: View) {
        successView.visibility = View.GONE
        errorView.visibility = View.VISIBLE
    }

    fun onError(message: String) {
        PopupUtils.showAlertDialog(baseActivity, getString(R.string.h_err_dialog), message)
    }

    fun onError(title: String, message: String) {
        PopupUtils.showAlertDialog(baseActivity, title, message)
    }


    fun startActivity(activityClass: Class<out Activity>) {
        navigator.startActivity(baseActivity, activityClass)
        applyAnimation()
    }

    override fun startActivity(intent: Intent){
        super.startActivity(intent)
        applyAnimation()
    }

    private fun applyAnimation(){
        if (PreferenceManager.currentUserLanguage == 1){
            baseActivity.overridePendingTransition(R.anim.activity_slide_in, R.anim.activity_slide_out)
        }else{
            baseActivity.overridePendingTransition(R.anim.activity_slide_in_ar, R.anim.activity_slide_out_ar)
        }
    }

    fun finishActivity() {
        navigator.finishActivity(baseActivity)
    }

    fun finishActivityWithResult(resultCode: Int, resultIntentFun: (Intent.() -> Unit)? = null) {
        navigator.finishActivityWithResult(baseActivity, resultCode, resultIntentFun)
    }

    fun addFragment(@IdRes containerId: Int, fragment: Fragment, fragmentTag: String? = null) {
        navigator.addFragmentAndAddToBackStack(baseActivity, containerId, fragment, fragmentTag)
    }

    fun replaceFragment(@IdRes containerId: Int, fragment: Fragment, fragmentTag: String? = null) {
        navigator.replaceFragmentAndAddToBackStack(baseActivity, containerId, fragment, fragmentTag)
    }

    fun replaceFragmentDirectly(
        @IdRes containerId: Int,
        fragment: Fragment,
        fragmentTag: String? = null
    ) {
        navigator.replaceFragment(baseActivity, containerId, fragment, fragmentTag)
    }

    fun popBackStack() {
        navigator.popFragmentBackStackImmediate(baseActivity)

    }

    fun showDialogFragment(fragment: DialogFragment) {
        navigator.showDialogFragment<DialogFragment>(baseActivity, fragment)
    }

    fun getDisplayMetrics() : DisplayMetrics{
        val outMetrics = DisplayMetrics()

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            val display = baseActivity.display
            display?.getRealMetrics(outMetrics)
        } else {
            @Suppress("DEPRECATION")
            val display = baseActivity.windowManager.defaultDisplay
            @Suppress("DEPRECATION")
            display.getMetrics(outMetrics)
        }

        return outMetrics
    }
}