package jo.basket.ui.checkout

import android.os.Bundle
import android.view.View
import androidx.core.content.ContextCompat
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import jo.basket.R
import jo.basket.databinding.FragmentCheckoutMapBinding
import jo.basket.di.Injectable
import jo.basket.ui.base.BaseFragment
import jo.basket.utils.ImageUtils


class CheckoutMapFragment(private val onPlaceOrderClicked :() -> Unit, private val onChangeAddressClicked :() -> Unit)  :
    BaseFragment<FragmentCheckoutMapBinding?, CheckoutViewModel>(),
    Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_checkout_map

    override val viewModel: CheckoutViewModel
        get() {
            return getViewModel(baseActivity, CheckoutViewModel::class.java)
        }

    private var mapFragment: SupportMapFragment? = null
    private lateinit var userMap: GoogleMap

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initMap()
        initMarker()
        initAddress()
        initButtonClickListener()
    }

    private fun initAddress(){
        viewDataBinding?.ivAddress?.setImageDrawable(
            ContextCompat.getDrawable(
                baseActivity, ImageUtils.getBitmapFromAddressType(
                    viewModel.checkoutDetail?.getUserSelectedAddress()?.addressTypeId ?: 0, 1
                )
            )
        )
        viewDataBinding?.tvAddress?.visibility = View.VISIBLE
        viewDataBinding?.tvAddressType?.text =
            viewModel.checkoutDetail?.getUserSelectedAddress()?.addressType
        viewDataBinding?.tvAddress?.text = viewModel.checkoutDetail?.getUserSelectedAddress()?.address
    }

    private fun initButtonClickListener(){
        viewDataBinding?.apply {
            tvEditAddress.setOnClickListener {
                onChangeAddressClicked()
                popBackStack()
            }

            btnPlaceOrder.setOnClickListener {
                onPlaceOrderClicked()
                popBackStack()
            }

            ivClose.setOnClickListener {
                popBackStack()
            }
        }
    }

    private fun initMap() {
        mapFragment =
            childFragmentManager.findFragmentById(R.id.fragment_map) as SupportMapFragment
        mapFragment?.view?.isClickable = false
        mapFragment?.getMapAsync { map ->
            map.uiSettings.isMapToolbarEnabled = false
            val userLatLng =
                LatLng(31.95989489221491, 35.92947017401457)
            map.moveCamera(CameraUpdateFactory.newLatLng(userLatLng))
            userMap = map
        }
    }

    private fun initMarker() {
        viewDataBinding?.ivMarker?.visibility =
            if (viewModel.checkoutDetail?.getUserSelectedAddress() == null) View.GONE else View.VISIBLE
        // user address
        mapFragment?.getMapAsync { map ->
            val userLatLng =
                LatLng(
                    viewModel.checkoutDetail?.getUserSelectedAddress()?.latitude ?: 31.95989489221491,
                    viewModel.checkoutDetail?.getUserSelectedAddress()?.longtitude ?: 35.92947017401457
                )
            map.animateCamera(CameraUpdateFactory.newLatLng(userLatLng))
            userMap = map
        }
    }

}