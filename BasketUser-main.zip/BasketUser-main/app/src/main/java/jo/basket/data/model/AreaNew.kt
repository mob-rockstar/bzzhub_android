package jo.basket.data.model


import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.realm.RealmList
import io.realm.RealmObject
import io.realm.annotations.PrimaryKey

open class AreaNew: RealmObject() {

    var stores: RealmList<Store> = RealmList<Store>()

    @SerializedName("city_id")
    @Expose
    var cityId: Int = 0
    @SerializedName("city_name")
    @Expose
    var cityName: String = ""
    @PrimaryKey
    @SerializedName("zone_id")
    @Expose
    var zoneId: Int = 0
    @SerializedName("zone_name")
    @Expose
    var zoneName: String = ""
}

