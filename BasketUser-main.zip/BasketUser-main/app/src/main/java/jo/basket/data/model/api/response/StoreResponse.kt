package jo.basket.data.model.api.response

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import jo.basket.data.model.Banner
import jo.basket.data.model.Service
import jo.basket.data.model.Store

class StoreResponse {

    @SerializedName("httpCode")
    @Expose
    val code: Int = 0

    @SerializedName("Message")
    @Expose
    val message: String? = null

    @SerializedName("store_list")
    @Expose
    var storeList: List<Store>? = null

    @SerializedName("express_store_id")
    @Expose
    val expressStoreId: Int = 0

    @field:SerializedName("banner_list")
    var bannerList: ArrayList<Banner> = ArrayList()

    @SerializedName("business_text")
    @Expose
    var businessText: String? = null

    @SerializedName("need_order_rating")
    @Expose
    val needOrderRating: Int = 0

    @SerializedName("last_completed_order_id")
    @Expose
    val lastCompletedOrder: Int = 0

    @SerializedName("scrolling_duration_seconds")
    @Expose
    val scrollDuration: Int = 0

}