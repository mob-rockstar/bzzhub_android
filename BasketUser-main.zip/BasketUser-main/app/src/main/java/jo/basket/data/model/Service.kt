package jo.basket.data.model

import android.graphics.drawable.Drawable
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.realm.RealmObject
import io.realm.annotations.PrimaryKey

data class Service(
    val id: Int,
    val is_express: Int,
    val name: String,
    val service_logo: String
)