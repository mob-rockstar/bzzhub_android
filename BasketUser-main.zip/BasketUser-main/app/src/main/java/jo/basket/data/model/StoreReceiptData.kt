package jo.basket.data.model

open class StoreReceiptData(private val mUrl : String, private  val mRotation : Float) {
    var imageURL: String = mUrl
    var rotation  = mRotation
}