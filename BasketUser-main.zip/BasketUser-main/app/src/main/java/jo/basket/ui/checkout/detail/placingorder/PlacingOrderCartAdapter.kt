package jo.basket.ui.checkout.detail.placingorder

import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import jo.basket.R
import jo.basket.data.model.Cart
import jo.basket.databinding.RecyclerItemPlacingOrderBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter

// Adapter to Handle List of Carts While placing Order
class PlacingOrderCartAdapter : BaseRecyclerViewAdapter<Cart, RecyclerItemPlacingOrderBinding>() {

    override val layoutId: Int
        get() = R.layout.recycler_item_placing_order

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return PlacingOrderViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as PlacingOrderViewHolder
        // Set Store Name
        holder.binding.tvStoreName.text = (items[position].displayName)
        // Set Delivery Time
        holder.binding.tvDeliveryTime.text = (items[position].deliveryTime)
        // Set RecyclerView
        holder.binding.recyclerView.layoutManager = (
                LinearLayoutManager(
                    holder.itemView.context,
                    LinearLayoutManager.HORIZONTAL,
                    false
                )
                )
        val placingOrderProductAdapter = PlacingOrderProductAdapter()
        placingOrderProductAdapter.setItems(items[position].products!!)
        holder.binding.recyclerView.adapter = placingOrderProductAdapter
    }

    inner class PlacingOrderViewHolder(val binding: RecyclerItemPlacingOrderBinding) :
        RecyclerView.ViewHolder(binding.root)
}