package jo.basket.data.remote

import io.socket.client.IO
import io.socket.client.Socket
import jo.basket.BuildConfig
import jo.basket.data.local.prefs.PreferenceManager
import jo.basket.data.model.User
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SocketManager @Inject constructor() {
    var chatSocket: Socket? = null // Instance for Basket Chat service
    var basketLocationService: Socket? = null // Instance for Basket Realtime service

    private fun setConnectionListener() {

        // Chat Service connection
        chatSocket?.on(Socket.EVENT_CONNECT_ERROR) { a ->
            Timber.tag("ChatSocket").v("Connection Error")
            Timber.tag("ChatSocket").v(a[0].toString())
        }
        chatSocket?.on(Socket.EVENT_CONNECT_TIMEOUT) {
            Timber.tag("ChatSocket").v("Connection Timeout")
        }
        chatSocket?.on(Socket.EVENT_DISCONNECT) {
            Timber.tag("ChatSocket").v("Disconnected")
        }

        chatSocket?.on(Socket.EVENT_CONNECT) {
            Timber.tag("ChatSocket").v("Connected")
        }

        //Basket Realtime service connection
        basketLocationService?.on(Socket.EVENT_CONNECT) {
            Timber.tag("BasketLocationService").v("Connected")
        }
        basketLocationService?.on(Socket.EVENT_CONNECT_ERROR) { a ->
            Timber.tag("BasketLocationService").v("Connection Error")
            Timber.tag("BasketLocationService").v(a[0].toString())
        }
        basketLocationService?.on(Socket.EVENT_CONNECT_TIMEOUT) {
            Timber.tag("BasketLocationService").v("Connection Timeout")
        }
        basketLocationService?.on(Socket.EVENT_DISCONNECT) {
            Timber.tag("BasketLocationService").v("Disconnected")
        }
    }

    fun init(userData: User) {
        val opts = IO.Options()
        //Connect Socket with UserId, UserToken, SocketToken
        opts.query =
            "user_id=${userData.userId}&user_token=${userData.token}&user_type=1&token=${PreferenceManager.socketToken}"
        val chatOpts = IO.Options()
        chatOpts.query = "user_id=${userData.userId}" +
                "&token=${PreferenceManager.socketToken}" +
                "&user_type=customer" +
                "&user_name=${userData.firstName}%20${userData.lastName}" +
                "&user_photo=${userData.imageUrl}" +
                "&push_notification_tokens=${PreferenceManager.userChatToken}" +
                "&device_platform=android"
        Timber.tag("ChatOptIs").d(chatOpts.query)
        chatSocket = IO.socket(BuildConfig.CHAT_SERVICE_URL, chatOpts)
        basketLocationService = IO.socket(BuildConfig.REAL_TIME_SERVICE_URL, opts)
        setConnectionListener()
    }

    fun connect() {
        Timber.tag("Socket").v("Start connection")
        basketLocationService?.connect()

    }

    fun disconnect() {
        basketLocationService?.disconnect()
    }

    fun isConnected(): Boolean {
        return chatSocket != null && chatSocket!!.connected()
    }

    fun isChatSocketConnected(): Boolean {
        return chatSocket != null && chatSocket!!.connected()
    }

    fun isRealtimeServiceConnected(): Boolean {
        return basketLocationService!!.connected()
    }

    companion object {
        const val SOCKET_EVENT_ORDER_STATUS = "order_status"

        const val CHAT_MESSAGE_TYPE_TEXT = "text"
        const val CHAT_MESSAGE_TYPE_IMAGE = "image"
        const val CHAT_MESSAGE_TYPE_VIDEO = "video"
        const val CHAT_MESSAGE_TYPE_VOICE = "voice"

        const val CHAT_EVENT_CREATE_ROOM = "chat:room:create"
        const val CHAT_EVENT_JOIN_ROOM = "chat:room:join"
        const val CHAT_EVENT_LEAVE_ROOM = "chat:room:leave"
        const val CHAT_EVENT_CHECK_ONLINE_STATUS = "chat:user:check:online:status"
        const val CHAT_EVENT_GET_HISTORY = "chat:room:history"
        const val CHAT_EVENT_SEND_MESSAGE = "chat:room:send:message"
        const val CHAT_EVENT_SEND_RECEIVED = "chat:room:send:received:status"
        const val CHAT_EVENT_SEND_READ = "chat:room:send:read:status"
        const val CHAT_EVENT_SEND_TYPING = "chat:room:send:typing:status"
        const val CHAT_EVENT_GET_USER_LIST = "chat:room:get:users"

        const val CHAT_EVENT_RECEIVE_MESSAGE = "chat:room:listen:messages"
        const val CHAT_EVENT_STATUS_RECEIVED = "chat:room:listen:received:status"
        const val CHAT_EVENT_STATUS_READ = "chat:room:listen:read:status"
        const val CHAT_EVENT_STATUS_TYPING = "chat:room:listen:typing:status"

        const val CHAT_KEY_ROOM_ID = "order_id"
        const val CHAT_KEY_USER_ID = "user_id"
        const val CHAT_KEY_USER_TYPE = "user_type"
        const val CHAT_KEY_MESSAGE_ID = "message_id"
        const val CHAT_KEY_MESSAGE_TYPE = "message_type"
        const val CHAT_KEY_MESSAGE_CONTENT = "message_content"
        const val CHAT_KEY_IS_TYPING = "is_typing"

        const val MAP_EVENT_SHOPPER_LOCATION = "shopper:single:location:"
    }

}