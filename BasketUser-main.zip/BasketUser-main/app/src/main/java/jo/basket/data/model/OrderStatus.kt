package jo.basket.data.model

import com.google.gson.annotations.SerializedName

data class OrderStatus(
    @SerializedName("order_outlet_id")
    val orderOutletId: Int = 0,
    @SerializedName("order_status")
    val orderStatus: Int = 0,
    @SerializedName("pending_items")
    val pendingItems: Int = 0,
    @SerializedName("shopped_items")
    val shoppedItems: Int = 0,
    @SerializedName("shopper_name")
    val shopperName: String = "",
    @SerializedName("state")
    val state: Int = 0,
    @SerializedName("total_order_items")
    val totalOrderItems: Int = 0
)