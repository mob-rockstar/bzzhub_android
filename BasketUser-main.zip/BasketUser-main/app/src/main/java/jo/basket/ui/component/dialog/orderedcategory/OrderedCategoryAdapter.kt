package jo.basket.ui.component.dialog.orderedcategory

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import jo.basket.R
import jo.basket.data.model.Aisle
import jo.basket.data.model.Category
import jo.basket.databinding.RecyclerItemRestaurantCategoryBinding

class OrderedCategoryAdapter (
    private var categories: ArrayList<Category> = ArrayList(),
    private var selected: Int,
    private var onItemSelected: (mItemPosition : Int) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {


    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return RestaurantCategoryViewHolder(
            DataBindingUtil.inflate(
                LayoutInflater.from(viewGroup.context),
                R.layout.recycler_item_restaurant_category,
                viewGroup,
                false
            )
        )
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as RestaurantCategoryViewHolder

        val context = holder.itemView.context

        holder.binding.tvCategoryName.text = categories[position].name
        holder.binding.tvCategoryName.setTextColor(ContextCompat.getColor(context,
            if (selected == position) R.color.accent else R.color.md_grey_900))
        if (selected == position) holder.binding.ivTick.visibility = View.VISIBLE
        else holder.binding.ivTick.visibility = View.GONE

        holder.itemView.setOnClickListener {
            selected = position
            onItemSelected(position)
            notifyDataSetChanged()
        }
    }

    fun setOnItemSelected( onItemSelected: (mItemPosition : Int) -> Unit){
        this.onItemSelected = onItemSelected
    }

    override fun getItemCount(): Int {
        return categories.size
    }

    fun setCategories(categories: ArrayList<Category> = ArrayList(), selected: Int){
        this.categories = categories
        this.selected = selected
        notifyDataSetChanged()
    }

    fun setSelected(position: Int){
        selected = position
        notifyDataSetChanged()
    }

    internal class RestaurantCategoryViewHolder(val binding: RecyclerItemRestaurantCategoryBinding)
        :  RecyclerView.ViewHolder(binding.root)
}