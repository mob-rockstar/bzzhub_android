package jo.basket.ui.cart.main

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.daimajia.swipe.SwipeLayout
import jo.basket.R
import jo.basket.data.model.Cart
import jo.basket.data.model.Product
import jo.basket.databinding.RecyclerItemCartProductBinding
import jo.basket.databinding.RecyclerItemCartStoreHeaderBinding
import jo.basket.databinding.RecyclerItemPopularPickListBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter
import jo.basket.ui.store.OnAmountChangeListener
import jo.basket.ui.store.department.store.StoreCategoryProductsAdapter
import jo.basket.utils.FormatterUtils
import jo.basket.utils.GlideApp
import jo.basket.utils.PopupUtils

//Adapter to handle List of Store Carts
class CartStoresAdapter : BaseRecyclerViewAdapter<Product, RecyclerItemCartProductBinding>() {

    private var topSellingProductAdapter: StoreCategoryProductsAdapter? = null
    private var listener: OnCartActionListener? = null
    private var isExpressStore = false
    private var topSellingProduct: ArrayList<Product> = ArrayList()
    private var cart: Cart? = null
    private var overallSubtotal : Double = 0.0
    override val layoutId: Int
        get() = R.layout.recycler_item_cart_product

    private var openedLayout: SwipeLayout? = null

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            VIEW_TYPE_POPULAR_PRODUCTS -> {
                FeaturedProductViewHolder(
                    DataBindingUtil.inflate(
                        LayoutInflater.from(viewGroup.context),
                        R.layout.recycler_item_popular_pick_list,
                        viewGroup,
                        false
                    )
                )
            }

            VIEW_TYPE_CART_STORE_HEADER -> {
                CartHeaderViewHolder(
                    DataBindingUtil.inflate(
                        LayoutInflater.from(viewGroup.context),
                        R.layout.recycler_item_cart_store_header,
                        viewGroup,
                        false
                    )
                )
            }

            else -> {
                val binding = createBindedView(viewGroup)
                return CartProductViewHolder(binding) { layout: SwipeLayout? ->
                    if (openedLayout != null && openedLayout != layout) openedLayout?.close()
                    openedLayout = layout
                }
            }
        }

    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        if (getItemViewType(position) == VIEW_TYPE_CART_STORE_HEADER) {

            val holder = viewHolder as CartHeaderViewHolder
            val context = holder.binding.root.context

            holder.binding.apply {
                if (cart != null){
                    layoutHeader.visibility = VISIBLE
                    progressBar.visibility = GONE

                    val layoutParams = holder.binding.layoutMain.layoutParams
                    layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
                    holder.binding.layoutMain.layoutParams = layoutParams
                }else{
                    layoutHeader.visibility = GONE
                    progressBar.visibility = VISIBLE
                }
                // Set Store name and amount
                tvStoreName.text = cart?.displayName
                tvAmount.text =
                    FormatterUtils.formatHTMLString(
                        FormatterUtils.formatPrice(
                            cart?.outletSubtotal ?: 0.0
                        )
                    )
                // Set Error message if existing
                tvMessage.text = cart?.checkoutPermissionDetails?.cartUserMessage


                if (cart?.checkoutPermissionDetails?.cartUserMessage != null
                    && cart?.checkoutPermissionDetails?.cartUserMessage!!.isNotEmpty()
                ) {
                    if (!isExpressStore) {
                        layoutMessage.visibility = VISIBLE
                    } else {
                        if (cart?.checkoutPermissionDetails?.checkoutPermission == 1) {
                            layoutMessage.visibility = GONE
                        } else {
                            layoutMessage.visibility = VISIBLE
                        }
                    }
                } else {
                    layoutMessage.visibility = GONE
                }

                // User tapped 'Clear' option (To remove all store cart)
                tvClear.setOnClickListener {
                    PopupUtils.showConfirmDialog(
                        context,
                        context.getString(R.string.str_title_clear_cart),
                        context.getString(R.string.are_you_sure)
                    ) {
                        listener?.onRemoveCart(cart!!)
                    }
                }

                ivLogo.setOnClickListener {
                    listener?.onLogoSelected(cart!!)
                }
                if (cart?.storeId == 499){
                    tvTitleNextDelivery.visibility = GONE
                    tvDeliveryTime.visibility = GONE
                    tvStoreStatus.visibility = VISIBLE
                    tvStoreStatus.apply {


                        Log.d("TAG", "CardtStoreAdapter: "+cart?.storeDisabled +cart?.storeStatus)
                        text =
                            context.resources.getString(if (cart?.storeDisabled == 1 || cart?.storeStatus ==context.resources.getString(
                                    R.string.str_status_closed
                                )) R.string.str_closed else R.string.str_open)
                        setTextColor(
                            ContextCompat.getColorStateList(
                                context,
                                if (cart?.storeDisabled == 1 || cart?.storeStatus == "Closed") R.color.color_red_badge else R.color.accent
                            )
                        )
                    }
                }else{
                    tvTitleNextDelivery.visibility = VISIBLE
                    tvDeliveryTime.visibility = VISIBLE
                    tvStoreStatus.visibility = GONE
                }
                tvDeliveryTime.visibility = if (cart?.isGridView == 1 || cart?.storeId == 499) GONE else VISIBLE



                //   binding.ivNextDelivery.setOnClickListener { openNextDelivery(listener) }
                layoutNextDelivery.setOnClickListener {
                    listener?.onOpenNextDelivery(
                        cart!!
                    )
                }

//                tvDeliveryTime.text =
//                    if (cart?.storeDisabled == 1 || cart?.storeStatus == context.resources.getString(
//                            R.string.str_status_closed
//                        )
//                    ) {
//                        ivLock.setImageDrawable(
//                            ContextCompat.getDrawable(
//                                context,
//                                R.drawable.ic_store_closed
//                            )
//                        )
//                        tvTitleNextDelivery.visibility = GONE
//                        if (cart?.storeDisabled == 1) {
//                            tvDeliveryTime.setTextColor(
//                                ContextCompat.getColorStateList(
//                                    context,
//                                    R.color.color_orange
//                                )
//                            )
//
//                            context.resources.getString(R.string.str_busy)
//                        } else {
//                            tvDeliveryTime.setTextColor(
//                                ContextCompat.getColorStateList(
//                                    context,
//                                    R.color.color_red_badge
//                                )
//                            )
//                            context.resources.getString(R.string.str_status_closed)
//                        }
//                    } else {
//
//                        val isCartValid =  overallSubtotal > (cart?.outletDeliverySettings?.minOrderAmount ?: 0.0)
//
//
//                        ivLock.setImageDrawable(
//                            ContextCompat.getDrawable(
//                                context,
//                                if (isCartValid)
//                                R.drawable.ic_party else R.drawable.ic_amount_locked_cart
//                             )
//                        )
//                        if (cart?.getNextDeliveryTime()?.deliverySlotNickName != null && cart?.getNextDeliveryTime()?.deliveryTime != null){
//
//                        }
//                        tvTitleNextDelivery.visibility =
//                            if (cart?.isGridView == 1 || cart?.storeId == 499) GONE else VISIBLE
//
//                        """ ${cart?.getNextDeliveryTime()?.deliverySlotNickName} ${cart?.getNextDeliveryTime()?.deliveryTime}"""
//                    }

                tvDeliveryTime.text = "" // Set an empty string initially

                if (cart?.storeDisabled == 1 || cart?.storeStatus == context.resources.getString(
                        R.string.str_status_closed
                    )
                ) {
                    ivLock.setImageDrawable(
                        ContextCompat.getDrawable(
                            context,
                            R.drawable.ic_store_closed
                        )
                    )
                    tvTitleNextDelivery.visibility = View.GONE
                    if (cart?.storeDisabled == 1) {
                        tvDeliveryTime.setTextColor(
                            ContextCompat.getColorStateList(
                                context,
                                R.color.color_orange
                            )
                        )

                        tvDeliveryTime.text = context.resources.getString(R.string.str_busy)
                        tvDeliveryTime.visibility = View.VISIBLE // Make the TextView visible
                    } else {
                        tvDeliveryTime.setTextColor(
                            ContextCompat.getColorStateList(
                                context,
                                R.color.color_red_badge
                            )
                        )
                        tvDeliveryTime.text = context.resources.getString(R.string.str_status_closed)
                        tvDeliveryTime.visibility = View.VISIBLE // Make the TextView visible
                    }
                } else {
                    val isCartValid = overallSubtotal > (cart?.outletDeliverySettings?.minOrderAmount ?: 0.0)

                    ivLock.setImageDrawable(
                        ContextCompat.getDrawable(
                            context,
                            if (isCartValid)
                                R.drawable.ic_party
                            else R.drawable.ic_amount_locked_cart
                        )
                    )

                    // Check if delivery time and slot nickname are available
                    val deliverySlotNickName = cart?.getNextDeliveryTime()?.deliverySlotNickName
                    val deliveryTime = cart?.getNextDeliveryTime()?.deliveryTime

                    if (deliverySlotNickName != null && deliveryTime != null) {
                        // If data is available, update text and set visibility to VISIBLE
                        tvDeliveryTime.text = "$deliverySlotNickName $deliveryTime"
                        tvDeliveryTime.visibility = View.VISIBLE
                    } else {
                        // If data is not available, hide the TextView
                        tvDeliveryTime.visibility = View.GONE
                    }

                    tvTitleNextDelivery.visibility =
                            if (cart?.isGridView == 1 || cart?.storeId == 499) GONE else VISIBLE
                }


                // Set Store Logo Image for Each Items
                GlideApp.with(context).load(cart?.logoImage).diskCacheStrategy(
                    DiskCacheStrategy.ALL
                ).fitCenter().error(R.drawable.placeholder300x300).format(
                    DecodeFormat.PREFER_ARGB_8888
                )
                    .into(ivLogo)
            }

        }
        else if (getItemViewType(position) == VIEW_TYPE_POPULAR_PRODUCTS) {
            val holder = viewHolder as FeaturedProductViewHolder
            val context = holder.binding.root.context
            if (holder.binding.rvPopularPick.layoutManager == null) {
                holder.binding.rvPopularPick.layoutManager =
                    LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            }
            if (topSellingProductAdapter == null) {
                topSellingProductAdapter =
                    StoreCategoryProductsAdapter(context, topSellingProduct, object :
                        OnAmountChangeListener {
                        override fun onChange(
                            product: Product,
                            amount: Double,
                            isAmountPopupRunning: Boolean,
                        ) {
                            listener?.onProductAmountChange(product, amount)
                        }
                    })
                holder.binding.rvPopularPick.setHasFixedSize(true)
                holder.binding.rvPopularPick.isNestedScrollingEnabled = false
                holder.binding.rvPopularPick.adapter = topSellingProductAdapter
            } else {
                if (holder.binding.rvPopularPick.adapter == null) {
                    holder.binding.rvPopularPick.adapter = topSellingProductAdapter
                }
                topSellingProductAdapter?.setItems(topSellingProduct)
            }
            holder.binding.tvYouAlsoLike.visibility =
                if (topSellingProduct.isEmpty()) GONE else VISIBLE

        } else {
            val holder = viewHolder as CartProductViewHolder
            // Init UI using ViewHolder
            if (items.isNotEmpty()) {
                holder.update(items[position - 1], cart?.isGridView, listener)
            }
        }
    }

    override fun setItems(itemList: List<Product>) {
        items.clear()
        items.addAll(itemList)
        notifyDataSetChanged()
    }

    fun setCartData(mCart: Cart, overallSubtotal: Double) {
        this@CartStoresAdapter.overallSubtotal = overallSubtotal
        cart = mCart
        notifyItemChanged(0)
    }

    fun setTopSellingItems(productList: List<Product>) {
        topSellingProduct.clear()
        topSellingProduct.addAll(productList)
        notifyItemChanged(items.size + 1)
    }

    fun setOnCartActionListener(listener: OnCartActionListener) {
        this.listener = listener
    }

    fun isExpress(): Boolean {
        return isExpressStore
    }

    override fun getItemCount(): Int {
        return items.size + 2
    }

    fun setExpress(mExpress: Boolean) {
        isExpressStore = mExpress
    }

    override fun getItemViewType(position: Int): Int {
        return when (position) {
            0 -> VIEW_TYPE_CART_STORE_HEADER
            items.size + 1 -> VIEW_TYPE_POPULAR_PRODUCTS
            else -> VIEW_TYPE_CART_PRODUCTS
        }
    }

    companion object {
        const val VIEW_TYPE_CART_STORE_HEADER = 1
        const val VIEW_TYPE_CART_PRODUCTS = 2
        const val VIEW_TYPE_POPULAR_PRODUCTS = 3
    }

    interface OnCartActionListener {

        fun onRemoveCart(cart: Cart)

        fun onSelectProduct(product: Product)

        fun onSelectProductInstruction(product: Product)

        fun onProductAmountChange(product: Product, amount: Double)

        fun onRemoveProduct(product: Product)

        fun onOpenNextDelivery(cart: Cart)

        fun onLogoSelected(cart: Cart)

    }

    inner class FeaturedProductViewHolder(val binding: RecyclerItemPopularPickListBinding) :
        RecyclerView.ViewHolder(binding.root)

    inner class CartHeaderViewHolder(val binding: RecyclerItemCartStoreHeaderBinding) :
        RecyclerView.ViewHolder(binding.root)
}