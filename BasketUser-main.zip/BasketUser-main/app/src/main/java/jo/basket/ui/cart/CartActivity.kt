package jo.basket.ui.cart

import android.os.Bundle
import android.util.Log
import android.widget.TextView
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import jo.basket.R
import jo.basket.data.local.db.RealmManager
import jo.basket.data.local.prefs.PreferenceManager
import jo.basket.databinding.ActivityCartBinding
import jo.basket.ui.base.BaseActivity
import jo.basket.ui.cart.main.CartMainFragment
import javax.inject.Inject

// Activity contains 'MyCart' Flow
class CartActivity : BaseActivity<ActivityCartBinding?, CartViewModel>(),
    HasAndroidInjector {

    override val layoutId: Int
        get() = R.layout.activity_cart

    override val viewModel: CartViewModel
        get() {
            return getViewModel(CartViewModel::class.java)
        }

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        var yourStringData = intent.getStringExtra("FromDepartment")


        if (yourStringData == null){
            yourStringData = "2"
        }
        Log.d("TAG", "onCreate: CartActivity"+yourStringData)


        initToolbar()
        replaceFragmentDirectly(R.id.cart_fragment, CartMainFragment.newInstance(yourStringData!!,viewDataBinding?.toolbar!!.cartImage1,viewDataBinding?.toolbar!!.cartImage2,
            viewDataBinding?.toolbar!!.view1,viewDataBinding?.toolbar!!.view2,viewDataBinding?.toolbar!!.secondItem,viewDataBinding?.toolbar!!.textAllCart,
            viewDataBinding?.toolbar!!.allCartLayout,viewDataBinding?.toolbar!!.tvTitle,viewDataBinding?.toolbar!!.cartImageLayout))
    }

    private fun initToolbar() {
        val tvShop = findViewById<TextView>(R.id.tv_shop)
        val city = RealmManager.getLocalCityDetail(PreferenceManager.currentUserCityId)
        tvShop.text = if (!city?.cityName.isNullOrEmpty()) resources.getString(
            R.string.str_shopping_in,
            city?.cityName
        ) else ""
    }

    override fun onBackPressed() {
        if (!viewModel.isFoodRunning){
            super.onBackPressed()
        }
    }

}