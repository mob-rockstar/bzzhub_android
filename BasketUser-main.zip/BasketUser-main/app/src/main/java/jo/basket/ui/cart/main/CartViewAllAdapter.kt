package jo.basket.ui.cart.main

import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.load.engine.DiskCacheStrategy
import jo.basket.R
import jo.basket.data.model.api.response.Outlet
import jo.basket.databinding.RecyclerItemAllCartStoreHeaderBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter
import jo.basket.utils.GlideApp

class CartViewAllAdapter (): BaseRecyclerViewAdapter<Outlet, RecyclerItemAllCartStoreHeaderBinding>() {

    private var topSellingProductAdapter: CartViewProductAdapter? = null
    private var listener: OnCartActionListener? = null
    override val layoutId: Int
        get() = R.layout.recycler_item_all_cart_store_header

    var serviceType: Int = 0
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

        return StoreTypeViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as StoreTypeViewHolder
        val cartList = items[position]


        holder.binding.tvStoreType.text = cartList.displayName
        val context = holder.binding.root.context

        // Set store Logo Image
        GlideApp.with(context).load(cartList.logoImage ?: "").diskCacheStrategy(
            DiskCacheStrategy.ALL
        ).fitCenter().into(holder.binding.ivStoreType)

        holder.binding.switchCart.setOnClickListener {
            listener?.onItemClickList(cartList.outletId)
        }

        if (holder.binding.allProduct.layoutManager == null) {
            holder.binding.allProduct.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        }
        topSellingProductAdapter = CartViewProductAdapter()
        topSellingProductAdapter?.setItems(cartList.productImages)
        holder.binding.allProduct.isNestedScrollingEnabled = false
        holder.binding.allProduct.adapter = topSellingProductAdapter
    }

    interface OnCartActionListener {
        fun onItemClickList(outletId: Int?)
    }

    fun setOnCartActionListener(listener: OnCartActionListener) {
        this.listener = listener
    }


    override fun getItemCount(): Int {
        return items.size
    }

    inner class StoreTypeViewHolder(val binding: RecyclerItemAllCartStoreHeaderBinding) :
        RecyclerView.ViewHolder(binding.root)

}