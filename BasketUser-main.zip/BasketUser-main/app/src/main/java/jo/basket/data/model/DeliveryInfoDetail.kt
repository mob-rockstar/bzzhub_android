package jo.basket.data.model


import com.google.gson.annotations.SerializedName

data class DeliveryInfoDetail(
    var amount: Double,
    var currency: String,
    var id: Int,
    @SerializedName("outlet_count")
    var outletCount: Int,
    var title: String
)