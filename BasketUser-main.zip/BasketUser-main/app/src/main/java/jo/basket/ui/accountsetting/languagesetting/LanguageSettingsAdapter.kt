package jo.basket.ui.accountsetting.languagesetting

import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import jo.basket.R
import jo.basket.data.model.Language
import jo.basket.databinding.RecyclerItemLanguageSettingBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter

class LanguageSettingsAdapter :
    BaseRecyclerViewAdapter<Language, RecyclerItemLanguageSettingBinding>() {

    override val layoutId: Int
        get() = R.layout.recycler_item_language_setting

    var currentUserLanguageID: Int = -1
    var selectedListener: OnLanguageSelectedListener? = null

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return LanguageSettingViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder: LanguageSettingViewHolder = viewHolder as LanguageSettingViewHolder
        val item = items[position]
        holder.binding.run {
            // Set Name of Language
            tvLanguage.text = item.name
            if (currentUserLanguageID == item.id)
                ivCheck.visibility = VISIBLE
            else ivCheck.visibility = GONE
        }

        holder.itemView.setOnClickListener {
            //If Language option is Changed
            if (currentUserLanguageID != item.id) {
                selectedListener!!.onSelect(item.id, item.name)
            }
        }
    }

    fun setCurrentLanguage(languageID: Int) {
        currentUserLanguageID = languageID
        notifyDataSetChanged()
    }

    inner class LanguageSettingViewHolder(val binding: RecyclerItemLanguageSettingBinding) :
        RecyclerView.ViewHolder(binding.root)

    interface OnLanguageSelectedListener {
        fun onSelect(languageID: Int, languageName: String)
    }
}