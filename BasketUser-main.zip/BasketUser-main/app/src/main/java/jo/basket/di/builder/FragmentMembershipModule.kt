package jo.basket.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector
import jo.basket.ui.membership.cancelmembership.MembershipCancelFragment
import jo.basket.ui.membership.detail.MembershipDetailFragment
import jo.basket.ui.membership.history.MembershipPaymentHistoryFragment
import jo.basket.ui.membership.membershiplist.MembershipListFragment
import jo.basket.ui.membership.payment.MembershipPaymentFragment
import jo.basket.ui.membership.successpayment.MembershipSuccessPaymentFragment

@Module
abstract class FragmentMembershipModule {

    @ContributesAndroidInjector
    abstract fun contributeMembershipListFragment(): MembershipListFragment

    @ContributesAndroidInjector
    abstract fun contributeMembershipDetailFragment(): MembershipDetailFragment


    @ContributesAndroidInjector
    abstract fun contributeMembershipPaymentFragment(): MembershipPaymentFragment

    @ContributesAndroidInjector
    abstract fun contributeMembershipSuccessPaymentFragment(): MembershipSuccessPaymentFragment

    @ContributesAndroidInjector
    abstract fun contributeMembershipPaymentHistoryFragment(): MembershipPaymentHistoryFragment

    @ContributesAndroidInjector
    abstract fun contributeMembershipCancelFragment(): MembershipCancelFragment
}