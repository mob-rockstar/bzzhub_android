package jo.basket.data.model.api.response.newstoreaislelist

data class DepartmentDetails(
    val app_banner_image: String,
    val id: Int,
    val image: String,
    val mobile_banner_image: String,
    val name: String,
    val web_banner_image: String
)