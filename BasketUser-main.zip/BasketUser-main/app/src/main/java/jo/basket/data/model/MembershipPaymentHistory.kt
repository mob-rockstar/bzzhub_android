package jo.basket.data.model


import com.google.gson.annotations.SerializedName

data class MembershipPaymentHistory(
    @SerializedName("card_label")
    var cardLabel: String,
    @SerializedName("created_date")
    var createdDate: String,
    @SerializedName("end_date")
    var endDate: String,
    var id: Int,
    @SerializedName("membership_amount")
    var membershipAmount: String,
    @SerializedName("start_date")
    var startDate: String
)