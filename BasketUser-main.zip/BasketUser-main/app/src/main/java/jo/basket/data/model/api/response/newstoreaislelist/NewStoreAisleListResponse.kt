package jo.basket.data.model.api.response.newstoreaislelist

data class NewStoreAisleListResponse(
    val `data`: DepartmentData,
    val message: String,
    val status: Int
)