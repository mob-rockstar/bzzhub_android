package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.ProductHint


class ProductHintsResponse {

    @field:SerializedName("httpCode")
    var code: Int? = 0

    @field:SerializedName("Message")
    var message: String? = null

    @field:SerializedName("product_list")
    val hints: List<ProductHint>? = null

}