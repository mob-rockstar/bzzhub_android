package jo.basket.data.model.api.response.validateAddress

data class Data(
    var city_id: Int,
    var country_id: Int,
    var location_id: Int
)