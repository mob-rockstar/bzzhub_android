package jo.basket.ui.component

import android.content.Context
import android.content.Context.VIBRATOR_SERVICE
import android.graphics.drawable.ColorDrawable
import android.os.*
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.PopupWindow
import android.widget.TextView
import androidx.databinding.DataBindingUtil
import jo.basket.R
import jo.basket.databinding.PopupAddItemBinding
import jo.basket.utils.FormatterUtils
import jo.basket.utils.Global


class EditAmountPopup(
    private val initAmount: Double,
    private val increment: Double,
    private val unit: String,
    private val mOnDismissListener: OnDismissListener?
) {

    private lateinit var tvAmount: TextView
    private lateinit var btnDecrease: ImageView
    private lateinit var btnIncease: ImageView
    private lateinit var vibrator: Vibrator
    private var window: PopupWindow? = null
    private var originalPos: IntArray = IntArray(2)
    private var amount: Double = initAmount

    private var mRunnable = Runnable { window?.dismiss() }
    private val handler = Handler(Looper.getMainLooper())

    fun show(v: View) {
        val view = initView(v.context)

        view.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        window = PopupWindow(
            view,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            true
        )
        window?.setBackgroundDrawable(ColorDrawable(android.graphics.Color.TRANSPARENT))
        window?.animationStyle = R.style.PopupAnimation
        window?.isOutsideTouchable = true
        window?.isFocusable = false

        v.getLocationInWindow(originalPos)
        window?.showAtLocation(
            v,
            0,
            originalPos.first() - view.measuredWidth + v.width + view.paddingRight + 20,
            originalPos[1] - view.paddingTop - 20
        )
        window?.setOnDismissListener {
            mOnDismissListener?.onDismiss(amount, false)
            currentPopup = null
            window = null
            handler.removeCallbacks(mRunnable)
        }

        tvAmount.text = "${FormatterUtils.formatDouble(amount)} $unit"

        btnDecrease.setOnClickListener {
            vibrate()
            if (amount == increment) {
                amount = 0.0
                window?.dismiss()
            } else {
                decrease()
            }
            mOnDismissListener?.onDismiss(amount, true)
        }
        btnIncease.setOnClickListener {
            vibrate()
            increase()
            mOnDismissListener?.onDismiss(amount, true)
        }

        updateUI()

        currentPopup = window
        handler.postDelayed(mRunnable, POPUP_DELAY_TIME)
    }

    private fun initView(context: Context): View {
        val binding = DataBindingUtil.inflate<PopupAddItemBinding>(
            LayoutInflater.from(context),
            R.layout.popup_add_item,
            null,
            false
        )
        tvAmount = binding.tvAmount
        btnDecrease = binding.ivDecrease
        btnIncease = binding.ivIncrease
        vibrator = context.getSystemService(VIBRATOR_SERVICE) as Vibrator
        return binding.root
    }

    private fun increase() {
        amount += increment
        updateUI()
        resetTimer()
    }

    private fun decrease() {
        amount -= increment
        updateUI()
        resetTimer()
    }

    private fun resetTimer() {
        handler.removeCallbacks(mRunnable)
        handler.postDelayed(mRunnable, POPUP_DELAY_TIME)
    }

    private fun updateUI() {
        tvAmount.text = "${FormatterUtils.formatDouble(amount)} $unit"
        if (amount == increment) {
            btnDecrease.setImageResource(R.drawable.ic_garbage_product)
        } else {
            btnDecrease.setImageResource(R.drawable.ic_decrese_product_amount)
        }
    }

    private fun vibrate() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
        }else{
            vibrator.vibrate(vibratePattern, -1)
        }
    }

    companion object {
        private val vibratePattern = longArrayOf(10, 25)
        private const val POPUP_DELAY_TIME: Long = 1000
        var currentPopup: PopupWindow? = null
    }

    interface OnDismissListener {
        fun onDismiss(amount: Double, isAmountPopupRunning: Boolean)
    }
}
