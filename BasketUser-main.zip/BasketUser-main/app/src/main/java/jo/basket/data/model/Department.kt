package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.realm.RealmList
import io.realm.RealmObject
import io.realm.RealmResults
import io.realm.annotations.LinkingObjects
import io.realm.annotations.PrimaryKey

open class Department : RealmObject() {
    @LinkingObjects("departments")
    val stores: RealmResults<Store>? = null

    var subcategories: RealmList<Category>? = null

    @SerializedName("id")
    @Expose
    @PrimaryKey
    var id: Int? = null

    @SerializedName("name")
    @Expose
    var name: String? = null

    @SerializedName("image")
    @Expose
    var image: String? = null

    @SerializedName("banner")
    @Expose
    var banner: String? = null

    @SerializedName("app_banner_image")
    @Expose
    var appBannerImage: String? = null

    @SerializedName("sort_order")
    @Expose
    var sortOrder: Int? = null

    @SerializedName("created_date")
    @Expose
    var createdDate: String? = null

    @SerializedName("updated_date")
    @Expose
    var updatedDate: String? = null
}