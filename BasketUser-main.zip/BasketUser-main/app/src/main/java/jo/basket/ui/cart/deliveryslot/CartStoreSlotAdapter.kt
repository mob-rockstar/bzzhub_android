package jo.basket.ui.cart.deliveryslot

import android.content.Context
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import jo.basket.R
import jo.basket.data.model.CartDelivery
import jo.basket.databinding.RecyclerItemCartStoreSlotBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter

// Adapter to handle CartDeliverySlots
class CartStoreSlotAdapter(private val mContext: Context) :
    BaseRecyclerViewAdapter<CartDelivery, RecyclerItemCartStoreSlotBinding>() {

    override val layoutId: Int
        get() = R.layout.recycler_item_cart_store_slot

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return StoreViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as StoreViewHolder
        val storeDeliverySlot = items[position]
        // Set Store Name
        holder.binding.tvStoreName.text = storeDeliverySlot.storeName
        // Set Delivery Time List
        holder.binding.rvDeliveryTime.layoutManager = LinearLayoutManager(mContext)
        val cartDeliveryTimeAdapter = CartDeliveryTimeAdapter(mContext)
        cartDeliveryTimeAdapter.setItems(storeDeliverySlot.timeList)
        holder.binding.rvDeliveryTime.adapter = cartDeliveryTimeAdapter
    }

    inner class StoreViewHolder(val binding: RecyclerItemCartStoreSlotBinding) :
        RecyclerView.ViewHolder(binding.root)
}