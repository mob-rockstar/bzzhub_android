package jo.basket.ui.component.imageslider.Transformations;

import android.view.View;

import jo.basket.ui.component.imageslider.SliderPager;

public class SimpleTransformation implements SliderPager.PageTransformer {
    @Override
    public void transformPage(View page, float position) {

    }
}