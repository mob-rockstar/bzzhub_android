package jo.basket.data.model


import com.google.gson.annotations.SerializedName

data class ReplaceSuggestionProduct(
    @SerializedName("approx_weight")
    var approxWeight: String,
    @SerializedName("each_suffix")
    var eachSuffix: Any,
    @SerializedName("label_value")
    var labelValue: String,
    @SerializedName("original_price")
    var originalPrice: String,
    @SerializedName("our_selling_price")
    var ourSellingPrice: String,
    @SerializedName("outlet_id")
    var outletId: Int,
    @SerializedName("outlet_item_id")
    var outletItemId: Int,
    @SerializedName("product_id")
    var productId: Int,
    @SerializedName("product_info_image")
    var productInfoImage: String,
    @SerializedName("product_name")
    var productName: String,
    @SerializedName("size_label")
    var sizeLabel: Int,
    @SerializedName("sold_per")
    var soldPer: Int,
    @SerializedName("sold_per_label")
    var soldPerLabel: String,
    var unit: String
)