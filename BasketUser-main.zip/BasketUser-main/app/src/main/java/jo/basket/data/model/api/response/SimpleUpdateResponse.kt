package jo.basket.data.model.api.response


data class SimpleUpdateResponse(
    var message: String,
    var status: Int
)