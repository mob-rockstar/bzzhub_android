package jo.basket.ui.component.dialog.bottomservice

import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import jo.basket.R
import jo.basket.data.model.Service
import jo.basket.databinding.RecyclerItemBottomTabBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter

class BottomServiceAdapter (private val onServiceTypeSelected: (serviceType: Service) -> Unit) :
    BaseRecyclerViewAdapter<Service, RecyclerItemBottomTabBinding>() {

    override val layoutId: Int
        get() = R.layout.recycler_item_bottom_tab

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = createBindedView(viewGroup)
        return StoreServiceViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as StoreServiceViewHolder
        val service = items[position]

        // Set store type name
        holder.binding.tvServiceType.text = service.name
        val context =  holder.binding.root.context

        // If store type selected, make bit larger
        if (selected == position) {
            holder.binding.tvServiceType.background = ContextCompat.getDrawable(context, R.drawable.bg_round_green_12dp)
            holder.binding.tvServiceType.setTextColor(ContextCompat.getColor(context, R.color.md_white_1000))
        } else {
            holder.binding.tvServiceType.background = ContextCompat.getDrawable(context, R.drawable.bg_round_grey_light_12dp)
            holder.binding.tvServiceType.setTextColor(ContextCompat.getColor(context, R.color.md_grey_800))
        }

        holder.itemView.setOnClickListener {
            if (service.is_express == 0){
                setSelection(position)
            }else{
                onServiceTypeSelected(items[position])
            }
        }
    }

    override fun setItems(itemList: List<Service>) {
        super.setItems(itemList)
        if (selected == -1) selected = 0
    }

    override fun setSelection(position: Int) {
        super.setSelection(position)
        onServiceTypeSelected(items[position])
    }

    fun setSelectedTab(position: Int){
        super.setSelection(position)
    }

    inner class StoreServiceViewHolder(val binding: RecyclerItemBottomTabBinding) :
        RecyclerView.ViewHolder(binding.root)
}