package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


open class DeliveryDay {

    @SerializedName("day")
    @Expose
    var day: String? = null

    @SerializedName("week_date")
    @Expose
    var weekDate: String? = null

    @SerializedName("time")
    @Expose
    var times: List<DeliveryTime>? = null

}