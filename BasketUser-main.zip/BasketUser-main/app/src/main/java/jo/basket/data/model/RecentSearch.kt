package jo.basket.data.model

data class RecentSearch(
    val id: Int,
    val search_keyword: String
)