package jo.basket.ui.base

import android.annotation.TargetApi
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import androidx.annotation.IdRes
import androidx.annotation.LayoutRes
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import dagger.android.AndroidInjection
import io.github.inflationx.viewpump.ViewPumpContextWrapper
import jo.basket.BR
import jo.basket.R
import jo.basket.data.local.prefs.PreferenceManager
import jo.basket.di.factory.ViewModelProviderFactory
import jo.basket.ui.base.navigator.Navigator
import jo.basket.utils.AppConstants
import jo.basket.utils.CommonUtils
import jo.basket.utils.NetworkUtils
import jo.basket.utils.PopupUtils
import javax.inject.Inject


abstract class BaseActivity<T : ViewDataBinding?, V : BaseViewModel> : AppCompatActivity(),
    BaseFragment.Callback {

    @Inject
    lateinit var viewModelFactory: ViewModelProviderFactory

    @Inject
    lateinit var navigator: Navigator

    var progressView: View? = null

    var viewDataBinding: T? = null
        private set

    private var mViewModel: V? = null
    private var deviceID: String =""
    /**
     * Override for set binding variable
     *
     * @return variable id
     */
    private val bindingVariable: Int = BR._all

    /**
     * @return layout resource id
     */
    @get:LayoutRes
    abstract val layoutId: Int

    /**
     * Override for set view model
     *
     * @return view model instance
     */
    abstract val viewModel: V

//    lateinit var validator: Validator


    override fun onFragmentAttached() {}
    override fun onFragmentDetached(tag: String?) {}
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase))
    }


    protected open fun <T : ViewModel> getViewModel(cls: java.lang.Class<T>): T {
        return ViewModelProvider(this)[cls]
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        performDependencyInjection()
        setLocale()
        super.onCreate(savedInstanceState)
        performDataBinding()
//        validator = Validator(this)
    }

    override fun onBackPressed() {
        if (viewModel.isLoading.value == false) {
            super.onBackPressed()
        }
    }

    private fun setLocale() {
        if (PreferenceManager.currentUserLanguage == 1) {
            CommonUtils.setLocale(this, AppConstants.ENGLISH)
        } else {
            CommonUtils.setLocale(this, AppConstants.ARABIC)
        }
    }

    @TargetApi(Build.VERSION_CODES.M)
    fun hasPermission(permission: String?): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                permission?.let { checkSelfPermission(it) } == PackageManager.PERMISSION_GRANTED
    }

    val isNetworkConnected: Boolean
        get() = NetworkUtils.isNetworkConnected(applicationContext)


    fun performDependencyInjection() {
        AndroidInjection.inject(this)
    }

    @TargetApi(Build.VERSION_CODES.M)
    fun requestPermissionsSafely(permissions: Array<String?>?, requestCode: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            permissions?.let { requestPermissions(it, requestCode) }
        }
    }

    fun showLoading() {
        if (progressView != null) {
            progressView!!.visibility = View.VISIBLE
        }
    }

    fun hideLoading() {
        if (progressView != null) {
            progressView!!.visibility = View.GONE
        }
    }

    private fun performDataBinding() {
        viewDataBinding = DataBindingUtil.setContentView<T>(this, layoutId)
        mViewModel = if (mViewModel == null) viewModel else mViewModel
        viewDataBinding!!.setVariable(bindingVariable, mViewModel)
        viewDataBinding!!.executePendingBindings()
        mViewModel?.isLoading!!.observe(this, Observer { consumeResponse(it) })

    }

    open fun consumeResponse(o: Boolean) {
        if (o) {
            showLoading()
        } else {
            hideLoading()
        }
    }

    fun onError(message: String) {
        PopupUtils.showAlertDialog(this, getString(R.string.h_err_dialog), message)
    }

    fun startActivity(activityClass: Class<out Activity>) {
        navigator.startActivity(this, activityClass)
        applyAnimation()

    }

    override fun startActivity(intent: Intent){
        super.startActivity(intent)
        applyAnimation()
    }

    private fun applyAnimation(){
        if (PreferenceManager.currentUserLanguage == 1){
            overridePendingTransition(R.anim.activity_slide_in, R.anim.activity_slide_out)
        }else{
            overridePendingTransition(R.anim.activity_slide_in_ar, R.anim.activity_slide_out_ar)
        }
    }

    fun addFragment(@IdRes containerId: Int, fragment: Fragment) {
        navigator.addFragmentAndAddToBackStack(this, containerId, fragment)
    }

    fun replaceFragment(@IdRes containerId: Int, fragment: Fragment) {
        navigator.replaceFragmentAndAddToBackStack(this, containerId, fragment)
    }

    fun replaceFragmentDirectly(@IdRes containerId: Int, fragment: Fragment) {
        navigator.replaceFragmentDirectly(this, containerId, fragment)
    }

    fun popFragment() {
        navigator.popFragmentBackStackImmediate(this)
    }

    fun showDialogFragment(fragment: DialogFragment) {
        navigator.showDialogFragment<DialogFragment>(this, fragment)
    }


    fun getDeviceID() : String{
        if (deviceID.isEmpty()){
            deviceID = Settings.Secure.getString(this.contentResolver,
                Settings.Secure.ANDROID_ID)
        }

        return deviceID
    }

}