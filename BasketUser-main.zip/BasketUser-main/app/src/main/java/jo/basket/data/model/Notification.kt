package jo.basket.data.model

import com.google.gson.annotations.SerializedName

open class Notification {
    @SerializedName("body")
    var body: String? = ""

    @SerializedName("created_date")
    var createdDate: String = ""

    @SerializedName("expire_date")
    var expireDate: String? = ""

    @SerializedName("id")
    var id: Int? = null

    @SerializedName("image")
    var image: String? = ""

    @SerializedName("orders_outlets_id")
    var ordersOutletsId: Int? = null

    @SerializedName("read_status")
    var readStatus: Int? = 0

    @SerializedName("sent_before")
    var sentBefore: String? = null

    @SerializedName("title")
    var title: String? = ""

    @SerializedName("type")
    var type: Int? = null

    @SerializedName("type_label")
    var typeLabel: String? = ""
}