package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.MembershipRenewal
import jo.basket.data.model.PreferredPayment
import jo.basket.data.model.UserMembership

class MembershipDetailResponse {
    @field:SerializedName("httpCode")
    var httpCode: Int? = null

    @field:SerializedName("Message")
    var message: String? = null

    @field:SerializedName("membership")
    var membership: UserMembership? = null

    @field:SerializedName("preferred_payment")
    var preferredPayment: PreferredPayment? = null

    @field:SerializedName("membership_renewal")
    var membershipRenewal: MembershipRenewal? = null
}