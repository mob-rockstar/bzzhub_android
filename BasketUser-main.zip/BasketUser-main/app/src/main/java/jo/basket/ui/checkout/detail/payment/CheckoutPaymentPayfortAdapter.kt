package jo.basket.ui.checkout.detail.payment

import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import jo.basket.R
import jo.basket.data.model.PaymentMethod
import jo.basket.databinding.RecyclerItemCheckoutPaymentBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter
import jo.basket.utils.ImageUtils

class CheckoutPaymentPayfortAdapter(
    private val paymentId: Int,
    private val listener: CheckoutPaymentAdapterNew.OnSelectPaymentListener?,
    private val isCreditCardEnable: Int,
    private val isSelected: Int
) :
    BaseRecyclerViewAdapter<PaymentMethod, RecyclerItemCheckoutPaymentBinding>() {

    override val layoutId: Int
        get() = R.layout.recycler_item_checkout_payment

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = createBindedView(viewGroup)
        return PaymentMethodViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as PaymentMethodViewHolder
        val context = viewHolder.itemView.context
        val paymentMethod = items[position]

        // Payment name
        holder.binding.tvPaymentType.text =
            paymentMethod.cardLabel

 //      holder.binding.tvCardNumber.text = paymentMethod.cardNumber

        if (paymentMethod.defaultStatus == 1 && isCreditCardEnable == 1 && isSelected == 1) {
            holder.binding.ivSelect.setImageDrawable(ContextCompat.getDrawable(context,
                R.drawable.ic_radio_checked_checkout))
        } else {
            holder.binding.ivSelect.setImageDrawable(ContextCompat.getDrawable(context,
                R.drawable.ic_radio_checkout))
        }

        holder.itemView.setOnClickListener {
            if (paymentMethod.defaultStatus != 1 || isSelected != 1) {
                listener?.onPaymentSelected(paymentId,
                    paymentMethod.cardId!!,
                    paymentMethod.cardLabel!!,
                    paymentMethod)
            }
        }

        if (isCreditCardEnable != 1) {
            holder.binding.ivSelect.setColorFilter(ContextCompat.getColor(context,
                R.color.md_grey_350))
            holder.binding.tvCardNumber.setTextColor(ContextCompat.getColor(context,
                R.color.md_grey_350))
            holder.binding.tvPaymentType.setTextColor(ContextCompat.getColor(context,
                R.color.md_grey_350))
            holder.binding.ivPaymentType.alpha = 0.2f
        } else {
            holder.binding.ivSelect.colorFilter = null
            holder.binding.tvPaymentType.setTextColor(ContextCompat.getColor(context,
                R.color.md_grey_800))
            holder.binding.tvCardNumber.setTextColor(ContextCompat.getColor(context,
                R.color.accent))
            holder.binding.ivPaymentType.alpha = 1.0f
        }
        holder.binding.ivPaymentType.setImageDrawable(ImageUtils.getPaymentCardIcon(context, paymentMethod.paymentOption ?: ""))

        holder.itemView.isClickable = isCreditCardEnable == 1
        holder.itemView.isEnabled = isCreditCardEnable == 1
    }

    inner class PaymentMethodViewHolder(val binding: RecyclerItemCheckoutPaymentBinding) :
        RecyclerView.ViewHolder(binding.root)
}