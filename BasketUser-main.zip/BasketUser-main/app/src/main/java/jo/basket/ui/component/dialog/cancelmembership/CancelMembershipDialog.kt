package jo.basket.ui.component.dialog.cancelmembership

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.Window
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import jo.basket.R
import jo.basket.databinding.DialogCancelMembershipBinding
import jo.basket.utils.PopupUtils

class CancelMembershipDialog {

    private var tvConfirm: TextView ?= null
    private var mContext: Context ?= null

    fun openDialog(context: Context, onConfirmed : ()-> Unit) {
        mContext = context
        val dialog = Dialog(context)
        val binding = DataBindingUtil.inflate<DialogCancelMembershipBinding>(
            LayoutInflater.from(context),
            R.layout.dialog_cancel_membership,
            null,
            false
        )

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(binding.root)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        binding.tvClose.setOnClickListener {
            dialog.dismiss()
        }

        tvConfirm = binding.tvCancel

        tvConfirm?.setOnClickListener {
                onConfirmed()
            dialog.dismiss()
        }


        PopupUtils.setDefaultDialogProperty(dialog)
        dialog.show()

    }

    private fun enableConfirmButton(){
        if (tvConfirm != null){
            tvConfirm?.isClickable = true
            tvConfirm?.isFocusable = true
            tvConfirm?.background = (ContextCompat.getDrawable(mContext!!,R.drawable.bg_round_green))
        }
    }

    companion object {
        private var instance: CancelMembershipDialog? = null
        private val Instance: CancelMembershipDialog
            get() {
                if (instance == null) {
                    instance = CancelMembershipDialog()
                }
                return instance!!
            }

        fun openDialog(context: Context, onConfirmed : ()-> Unit) {
            Instance.openDialog(context, onConfirmed)
        }

    }
}