package jo.basket.ui.checkout.detail.payment

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import jo.basket.R
import jo.basket.data.model.PaymentMethod
import jo.basket.data.model.payment.PaymentData
import jo.basket.databinding.RecyclerItemCheckoutPaymentBinding
import jo.basket.databinding.RecyclerItemCheckoutPaymentPayfortBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter
import jo.basket.utils.AppConstants.VIEW_TYPE_NON_CREDIT_CARD
import jo.basket.utils.AppConstants.VIEW_TYPE_PAYFORT
import jo.basket.utils.ImageUtils

class CheckoutPaymentAdapterNew : BaseRecyclerViewAdapter<PaymentData, RecyclerItemCheckoutPaymentBinding>() {

    var listener: OnSelectPaymentListener? = null

    override val layoutId: Int
        get() = R.layout.recycler_item_checkout_payment

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == VIEW_TYPE_NON_CREDIT_CARD) {
            val binding = createBindedView(viewGroup)
            PaymentMethodViewHolder(binding)
        } else {
            val binding = DataBindingUtil.inflate<RecyclerItemCheckoutPaymentPayfortBinding>(
                LayoutInflater.from(viewGroup.context),
                R.layout.recycler_item_checkout_payment_payfort,
                viewGroup,
                false
            )
            CheckoutPaymentPayfortViewHolder(binding)
        }
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val paymentMethod = items[position]
        if (getItemViewType(position) == VIEW_TYPE_NON_CREDIT_CARD) {
            val holder = viewHolder as PaymentMethodViewHolder
            val context = viewHolder.itemView.context

            holder.binding.ivPaymentType.setImageDrawable(ImageUtils.getPaymentIconFromPaymentMode(context, paymentMethod.paymentType))

            // Payment name
            holder.binding.tvPaymentType.text =
                paymentMethod.name

            holder.binding.tvCardNumber.text = ""

            if ((paymentMethod.defaultStatus == 1 && paymentMethod.isCodEnable == 1 && paymentMethod.paymentType == 1)
                || (paymentMethod.defaultStatus == 1 && paymentMethod.isBringCCMachine == 1 && paymentMethod.paymentType == 3)
            ) {
                holder.binding.ivSelect.setImageDrawable(ContextCompat.getDrawable(context,
                    R.drawable.ic_radio_checked_checkout))
            } else {
                holder.binding.ivSelect.setImageDrawable(ContextCompat.getDrawable(context,
                    R.drawable.ic_radio_checkout))
            }

            if ((paymentMethod.isCodEnable != 1 && paymentMethod.paymentType == 1)
                || paymentMethod.paymentType == 3 && paymentMethod.isBringCCMachine != 1
            ) {
                holder.binding.ivSelect.setColorFilter(ContextCompat.getColor(context,
                    R.color.md_grey_350))
                holder.binding.tvCardNumber.setTextColor(ContextCompat.getColor(context,
                    R.color.md_grey_350))
                holder.binding.tvPaymentType.setTextColor(ContextCompat.getColor(context,
                    R.color.md_grey_350))
                holder.binding.ivPaymentType.alpha = 0.3f
            } else {
                holder.binding.ivSelect.colorFilter = null
                holder.binding.tvPaymentType.setTextColor(ContextCompat.getColor(context,
                    R.color.md_grey_800))
                holder.binding.tvCardNumber.setTextColor(ContextCompat.getColor(context,
                    R.color.accent))
                holder.binding.ivPaymentType.alpha = 1.0f
            }

            if (paymentMethod.paymentType == 1) {
                holder.itemView.isClickable = paymentMethod.isCodEnable == 1
                holder.itemView.isEnabled = paymentMethod.isCodEnable == 1
            } else if (paymentMethod.paymentType == 3) {
                holder.itemView.isClickable = paymentMethod.isBringCCMachine == 1
                holder.itemView.isEnabled = paymentMethod.isBringCCMachine == 1
            }

            holder.itemView.setOnClickListener {
                if (paymentMethod.defaultStatus != 1) {
                    listener?.onPaymentSelected(paymentMethod.id, 0, paymentMethod.name, null)
                }
            }
        } else {
            val holder = viewHolder as CheckoutPaymentPayfortViewHolder
            holder.update(listener, paymentMethod)
        }
    }

    override fun getItemViewType(position: Int): Int {
        return if (items[position].paymentType == 1 || items[position].paymentType == 3) VIEW_TYPE_NON_CREDIT_CARD else VIEW_TYPE_PAYFORT
    }

    fun getDefaultPaymentType(): Int {
        var defaultPaymentType = 2
        for (paymentData in items) {
            if ((paymentData.defaultStatus == 1 && paymentData.isCodEnable == 1 && paymentData.paymentType == 1)
                || (paymentData.defaultStatus == 1 && paymentData.isBringCCMachine == 1 && paymentData.paymentType == 3)) {
                defaultPaymentType = paymentData.paymentType
            }
        }

        return defaultPaymentType
    }

    fun getSelectedPaymentID(): Int {
        var defaultPaymentId = 0
        for (paymentData in items) {
            if (paymentData.defaultStatus == 1 && paymentData.paymentType == 1 && paymentData.isCodEnable == 1) {
                defaultPaymentId = paymentData.id
            } else if (paymentData.defaultStatus == 1 && paymentData.paymentType == 3 && paymentData.isBringCCMachine == 1){
                defaultPaymentId = paymentData.id
            }
        }

        if (defaultPaymentId == 0) {
            for (paymentData in items) {
                for (card in paymentData.cards) {
                    if (card.defaultStatus == 1 && paymentData.defaultStatus == 1 && paymentData.isCreditCardEnable == 1 && paymentData.paymentType == 2) {
                        defaultPaymentId = paymentData.id
                    }
                }
            }
        }


        return defaultPaymentId
    }

    fun getSelectedPaymentName(): String {
        var paymentName = ""
        for (paymentData in items) {
            if (paymentData.defaultStatus == 1 && paymentData.paymentType == 1 && paymentData.isCodEnable == 1) {
                paymentName = paymentData.name
            } else if (paymentData.defaultStatus == 1 && paymentData.paymentType == 3 && paymentData.isBringCCMachine == 1){
                paymentName = paymentData.name
            }
        }
        if (paymentName.isEmpty()) {
            for (paymentData in items) {
                for (card in paymentData.cards) {
                    if ((paymentData.isCreditCardEnable == 1) && card.defaultStatus == 1 && paymentData.paymentType == 2) {
                        paymentName = card.cardLabel ?: ""
                    }
                }
            }
        }

        return paymentName
    }

    fun getCreditCardPaymentId(): Int {
        var paymentId = 24
        for (paymentData in items) {
            if (paymentData.isCreditCardEnable == 1 && paymentData.paymentType == 2) {
                paymentId = paymentData.id
            }
        }

        return paymentId
    }

    fun getSelectedCardId(): Int {
        var cardInt = 0
        for (paymentData in items) {
            for (card in paymentData.cards) {
                if (paymentData.isCreditCardEnable == 1 && card.defaultStatus == 1) {
                    cardInt = card.cardId!!
                }
            }
        }

        return cardInt
    }

    interface OnSelectPaymentListener {
        fun onPaymentSelected(
            paymentId: Int,
            cardId: Int,
            paymentName: String,
            paymentMethod: PaymentMethod?,
        )
    }

    inner class PaymentMethodViewHolder(val binding: RecyclerItemCheckoutPaymentBinding) :
        RecyclerView.ViewHolder(binding.root)
}