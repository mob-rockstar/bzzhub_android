package jo.basket.data.local.db.realm

import io.realm.Realm

abstract class BaseRepo {

    val realm: Realm
        get() = Realm.getDefaultInstance()

}