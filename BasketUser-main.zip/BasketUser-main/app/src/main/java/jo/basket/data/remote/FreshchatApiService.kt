package com.app.basketiodriver.data.remote

import android.content.Context
import io.reactivex.Single
import com.google.gson.GsonBuilder
import com.google.gson.JsonObject
import com.jakewharton.retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import jo.basket.data.remote.BasicAuthInterceptor
import okhttp3.Cache
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.File
import java.util.Objects
import java.util.concurrent.TimeUnit

object FreshchatApiService {

    val FRESHCHAT_BASE_URL = "https://basket-help.freshdesk.com/api/v2/"
    val user = "cCXIMBC8l9CiugEpWwZj"
    val password = "Basket@1234"

    private lateinit var apiInterface: FreshchatApiInterface

    fun init(context : Context) {
        // BasicAuthInterceptor to OkHttp client
        val client =  OkHttpClient.Builder()
            .addInterceptor(BasicAuthInterceptor(user, password))
            .connectTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .readTimeout(50, TimeUnit.SECONDS)
            .build()

        val gson = GsonBuilder()
            .setLenient()
            .create()

        // add OkHttp client to Retrofit instance
        apiInterface = Retrofit.Builder()
            .baseUrl(FRESHCHAT_BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
            .build()
            .create(FreshchatApiInterface::class.java)
    }



    fun createTicket(description : String, priority : Int, email : String,status : Int,type : String,subject : String,
                     ordersOutletsId : Long,userPhoneNumber : String,outletName : String,) : Single<JsonObject>{
        var ccEmails: List<String> = listOf()
        val requestBody : HashMap<String, Any>  = HashMap<String, Any>()
        requestBody["description"] = description
        requestBody["subject"] = subject
        requestBody["email"] = email
        requestBody["priority"] = priority
        requestBody["status"] = status
        requestBody["cc_emails"] = ccEmails
        requestBody["type"] = type


        val customFieldsJson = HashMap<String, Any>()
        customFieldsJson["cf_bid"] = ordersOutletsId
//        customFieldsJson["cf_customer_phone"] =  userPhoneNumber.replace("+","").toLong()
        customFieldsJson["cf_store_name"] = outletName
        requestBody["custom_fields"] = customFieldsJson


        return apiInterface.createTicket(requestBody)
    }
}