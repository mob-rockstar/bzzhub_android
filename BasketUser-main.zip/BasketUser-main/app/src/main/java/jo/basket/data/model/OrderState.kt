package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.realm.RealmObject


open class OrderState : RealmObject() {

    @SerializedName("order_badge")
    @Expose
    var orderBadge: String? = null

    @SerializedName("main_order_badge")
    @Expose
    var mainOrderBadge: String? = null

    @SerializedName("state")
    @Expose
    var state: Int = 0

    @SerializedName("created_date")
    @Expose
    var createdDate: String? = null

}