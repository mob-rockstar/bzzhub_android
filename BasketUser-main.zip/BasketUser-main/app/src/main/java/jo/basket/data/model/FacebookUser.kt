package jo.basket.data.model

import com.google.gson.annotations.SerializedName


class FacebookUser {

    @field:SerializedName("id")
    val id: String? = null

    @field:SerializedName("email")
    val email: String? = ""

    @field:SerializedName("first_name")
    val firstName: String? = ""

    @field:SerializedName("last_name")
    val lastName: String? = ""

}