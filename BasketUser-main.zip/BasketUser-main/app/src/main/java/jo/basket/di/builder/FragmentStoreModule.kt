package jo.basket.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector
import jo.basket.ui.main.about.AboutAppFragment
import jo.basket.ui.store.ClosedCartFragment
import jo.basket.ui.store.CommitRequestSuccessFragment
import jo.basket.ui.store.all.store.AllProductExpressFragment
import jo.basket.ui.store.all.store.AllProductServiceStoreFragment
import jo.basket.ui.store.all.store.AllProductsFragmentNew
import jo.basket.ui.store.all.store.ExpressVideoFragment
import jo.basket.ui.store.category.CategoryFragment
import jo.basket.ui.store.customproduct.CustomProductExpressFragment
import jo.basket.ui.store.customproduct.CustomProductFragment
import jo.basket.ui.store.department.store.DepartmentStoreExpressFragment
import jo.basket.ui.store.department.store.DepartmentStoreFragment
import jo.basket.ui.store.department.store.DepartmentStoreProductListFragment
import jo.basket.ui.store.favorite.MyFavoriteFragment
import jo.basket.ui.store.featured.FeaturedFragment
import jo.basket.ui.store.help.HelpFragment
import jo.basket.ui.store.language.LanguageSettingsFragment
import jo.basket.ui.store.order.OrderFragment
import jo.basket.ui.store.ordered.ExpressOrderedFragment
import jo.basket.ui.store.ordered.OrderedFragment
import jo.basket.ui.store.search.SearchFragment
import jo.basket.ui.store.shoppinglist.ShoppingListFragment
import jo.basket.ui.store.tap.StoreTapFragment


@Module
abstract class FragmentStoreModule {

    @ContributesAndroidInjector
    abstract fun contributeStoreTapFragment(): StoreTapFragment

    @ContributesAndroidInjector
    abstract fun contributeAllProductsFragment(): AllProductsFragmentNew

    @ContributesAndroidInjector
    abstract fun contributeAllProductsExpressFragment(): AllProductExpressFragment

    @ContributesAndroidInjector
    abstract fun contributeAllProductServiceStoreFragment(): AllProductServiceStoreFragment

 /*   @ContributesAndroidInjector
    abstract fun contributeBrowseFragment(): BrowseFragment*/

    @ContributesAndroidInjector
    abstract fun contributeOrderedFragment(): OrderedFragment

    @ContributesAndroidInjector
    abstract fun contributeHelpFragment(): HelpFragment

    @ContributesAndroidInjector
    abstract fun contributeExpressOrderedFragment(): ExpressOrderedFragment

    @ContributesAndroidInjector
    abstract fun contributeDepartmentNewFragment(): DepartmentStoreFragment

    @ContributesAndroidInjector
    abstract fun contributeCategoryFragment(): CategoryFragment

    @ContributesAndroidInjector
    abstract fun contributeMyFavoriteFragment(): MyFavoriteFragment

    @ContributesAndroidInjector
    abstract fun contributeSearchFragment(): SearchFragment

    @ContributesAndroidInjector
    abstract fun contributeCustomProductFragment(): CustomProductFragment

    @ContributesAndroidInjector
    abstract fun contributeCustomProductExpressFragment(): CustomProductExpressFragment

    @ContributesAndroidInjector
    abstract fun contributeFeaturedFragment(): FeaturedFragment

    @ContributesAndroidInjector
    abstract fun contributeShoppingListFragment(): ShoppingListFragment

    @ContributesAndroidInjector
    abstract fun contributeDepartmentStoreProductListFragment(): DepartmentStoreProductListFragment

    @ContributesAndroidInjector
    abstract fun contributeDepartmentStoreExpressFragment(): DepartmentStoreExpressFragment

    @ContributesAndroidInjector
    abstract fun contributeCommitRequestSuccessFragment(): CommitRequestSuccessFragment

    @ContributesAndroidInjector
    abstract fun contributeClosedCartFragment(): ClosedCartFragment

    @ContributesAndroidInjector
    abstract fun contributeOrderFragment(): OrderFragment

    @ContributesAndroidInjector
    abstract fun contributeAboutFragment(): AboutAppFragment

    @ContributesAndroidInjector
    abstract fun contributeLanguageSettingsFragment(): LanguageSettingsFragment

    @ContributesAndroidInjector
    abstract fun contributeExpressVideoFragment(): ExpressVideoFragment
}
