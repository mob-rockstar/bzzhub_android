package jo.basket.data.model

import com.google.gson.annotations.SerializedName

class ExpressData {
    @field:SerializedName("amount")
    var amount: String? = null

    @field:SerializedName("response_code")
    var responseCode: String? = null

    @field:SerializedName("card_number")
    var cardNumber: String? = null

    @field:SerializedName("signature")
    var signature: String? = null

    @field:SerializedName("merchant_identifier")
    var merchantIdentifier: String? = null

    @field:SerializedName("access_code")
    var accessCode: String? = null

    @field:SerializedName("payment_option")
    var paymentOption: String? = null

    @field:SerializedName("expiry_date")
    var expiryDate: String? = null

    @field:SerializedName("customer_ip")
    var customerIp: String? = null

    @field:SerializedName("language")
    var language: String? = null

    @field:SerializedName("eci")
    var eci: String? = null

    @field:SerializedName("fort_id")
    var fortId: String? = null

    @field:SerializedName("command")
    var command: String? = null

    @field:SerializedName("3ds_url")
    var _3dsUrl: String? = null

    @field:SerializedName("response_message")
    var responseMessage: String? = null

    @field:SerializedName("merchant_reference")
    var merchantReference: String? = null

    @field:SerializedName("customer_email")
    var customerEmail: String? = null

    @field:SerializedName("currency")
    var currency: String? = null

    @field:SerializedName("status")
    var status: String? = null
}