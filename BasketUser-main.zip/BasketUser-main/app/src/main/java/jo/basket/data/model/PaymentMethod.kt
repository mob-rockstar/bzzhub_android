package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import java.io.Serializable

open class PaymentMethod : Serializable {

    @SerializedName("type")
    @Expose
    var type: Int? = null

    @SerializedName("payment_mode")
    @Expose
    var paymentMode: Int? = null

    @SerializedName("available")
    @Expose
    var available: Int? = null

    @SerializedName("name")
    @Expose
    var name: String? = null

    @SerializedName("payment_id")
    @Expose
    var paymentId: Int? = null

    @SerializedName("card_id")
    @Expose
    var cardId: Int? = null

    @SerializedName("card_number")
    @Expose
    var cardNumber: String? = null

    @SerializedName("payment_option")
    @Expose
    var paymentOption: String? = null

    @SerializedName("card_holder_name")
    @Expose
    var cardHolderName: String? = null

    @SerializedName("card_label")
    @Expose
    var cardLabel: String? = null

    @SerializedName("token_name")
    @Expose
    var tokenName: String? = null

    @SerializedName("default_status")
    @Expose
    var defaultStatus: Int? = null

    @SerializedName("created_date")
    @Expose
    var createdDate: String? = null

}
