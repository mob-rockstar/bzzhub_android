package jo.basket.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector
import jo.basket.ui.nps.complete.NPSRatingCompleteFragment
import jo.basket.ui.nps.rating.NPSRatingFragment

@Module
abstract class FragmentNPSModule{
    @ContributesAndroidInjector
    abstract fun contributeNPSRatingFragment(): NPSRatingFragment

    @ContributesAndroidInjector
    abstract fun contributeNPSRatingCompleteFragment(): NPSRatingCompleteFragment
}