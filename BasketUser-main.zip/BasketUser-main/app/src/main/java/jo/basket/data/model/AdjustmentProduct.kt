package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class AdjustmentProduct : ShoppedProduct() {

    @SerializedName("qty_difference")
    @Expose
    var qtyDifference: Int? = null

    @SerializedName("price_difference")
    @Expose
    var priceDifference: Int? = null

    @SerializedName("qty_difference_label")
    @Expose
    var qtyDifferenceLabel: String? = null

    @SerializedName("price_difference_label")
    @Expose
    var priceDifferenceLabel: String? = null

    @SerializedName("ordered_approx_weight")
    @Expose
    var orderedApproxWeight: Double? = null

    @SerializedName("ordered_our_selling_price")
    @Expose
    var orderedOurSellingPrice: Double? = null

    @SerializedName("ordered_item_unit_price_selling")
    @Expose
    var orderedItemUnitPriceSelling: Double? =
        null

    @SerializedName("ordered_qty")
    @Expose
    var orderedQty: Int? = null

    @SerializedName("ordered_item_total")
    @Expose
    var orderedItemTotal: Double? = null

    @SerializedName("promo_item")
    @Expose
    var promo_item: Int? = null

    @SerializedName("display_saving_per_unit")
    @Expose
    var display_saving_per_unit: String? = null

}