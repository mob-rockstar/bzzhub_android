package jo.basket.ui.checkout.detail.product

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import jo.basket.R
import jo.basket.data.local.db.RealmManager
import jo.basket.data.model.Product
import jo.basket.databinding.RecyclerItemCartProductBinding
import jo.basket.databinding.RecyclerItemCheckoutCartProductBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter

class CheckoutCartProductAdapter(private var listener: CheckoutCartStoreAdapter.OnCartActionListener?) :
    BaseRecyclerViewAdapter<Product, RecyclerItemCheckoutCartProductBinding>() {

    var outletId = 0
    override val layoutId: Int
        get() = R.layout.recycler_item_checkout_cart_product

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = createBindedView(viewGroup)
        return CheckoutCartProductViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as CheckoutCartProductViewHolder
        // Update Item using ViewHolder
        val store = RealmManager.getLocalStore(outletId)
       holder.update(items[position], listener, store?.isGridView)

        holder.itemView.setOnClickListener {
        //    setSelection(position)
            listener?.onSelectProduct(items[position])
        }
    }

    override fun setItems(itemList: List<Product>) {
        items.clear()
        for ( item in itemList){
            if (item.cartQty != 0.0) items.add(item)
        }
    }
}