package jo.basket.data.model.api

import com.google.gson.annotations.SerializedName


class ServerResponse<T> {

    @field:SerializedName("response")
    val response: T? = null

}