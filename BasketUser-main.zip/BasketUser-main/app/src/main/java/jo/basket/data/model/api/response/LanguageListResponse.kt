package jo.basket.data.model.api.response


import com.google.gson.annotations.SerializedName
import jo.basket.data.model.Language

data class LanguageListResponse(
    @field:SerializedName("httpCode")
    val code: Int = 0,
    @field:SerializedName("language_list")
    var languageList: List<Language>,
    @field:SerializedName("Message")
    var message: String
)