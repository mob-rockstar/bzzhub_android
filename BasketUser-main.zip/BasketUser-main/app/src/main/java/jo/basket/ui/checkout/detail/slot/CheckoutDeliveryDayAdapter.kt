package jo.basket.ui.checkout.detail.slot

import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import jo.basket.R
import jo.basket.data.local.prefs.PreferenceManager
import jo.basket.data.model.Cart
import jo.basket.data.model.DeliveryDay
import jo.basket.databinding.RecyclerItemCheckoutDeliveryDayBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter
import jo.basket.utils.AppConstants
import jo.basket.utils.DateUtils
import java.text.SimpleDateFormat
import java.util.*

class CheckoutDeliveryDayAdapter :
    BaseRecyclerViewAdapter<DeliveryDay, RecyclerItemCheckoutDeliveryDayBinding>() {

    override val layoutId: Int
        get() = R.layout.recycler_item_checkout_delivery_day

    var listener: OnDaySelectedListener? = null
    var cart: Cart? = null

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = createBindedView(viewGroup)
        return DeliveryDayViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as DeliveryDayViewHolder
        val context = holder.itemView.context
        val day = items[position]
        val parser =
            SimpleDateFormat("dd-MM-yyyy", if (PreferenceManager.currentUserLanguage == 2) Locale(
                AppConstants.ARABIC) else Locale(AppConstants.ENGLISH))
/*        val formatter = SimpleDateFormat("MMM d",
            if (PreferenceManager.currentUserLanguage == 2) Locale(AppConstants.ARABIC) else Locale(
                AppConstants.ENGLISH))*/
        val formatter = SimpleDateFormat("MMM d", Locale(AppConstants.ENGLISH))

        if (selected == position) {
            holder.binding.layoutBackground.setCardBackgroundColor(ContextCompat.getColor(context,
                R.color.accent))
            holder.binding.tvWeekDay.setTextColor(ContextCompat.getColor(context,
                R.color.md_white_1000))
            holder.binding.tvDay.setTextColor(ContextCompat.getColor(context,
                R.color.md_white_1000))
        } else {
            holder.binding.layoutBackground.setCardBackgroundColor(ContextCompat.getColor(context,
                R.color.md_grey_75))
            holder.binding.tvWeekDay.setTextColor(ContextCompat.getColor(context,
                R.color.md_black_1000))
            holder.binding.tvDay.setTextColor(ContextCompat.getColor(context,
                R.color.md_black_1000))
        }

        when {
            DateUtils.compareDateWithToday(day.weekDate!!) -> {
                holder.binding.tvWeekDay.text = context.resources.getString(R.string.today)
            }
            PreferenceManager.currentUserLanguage == 1 -> {
                day.day!!.take(3).also { holder.binding.tvWeekDay.text = it }
            }
            else -> {
                day.day!!.also { holder.binding.tvWeekDay.text = it }
            }
        }

        holder.binding.tvDay.text = formatter.format(parser.parse(day.weekDate!!)!!)

        /*     holder.binding.tvDay.visibility =
                 if  (DateUtils.compareDateWithToday(day.weekDate!!)) INVISIBLE
                     else VISIBLE*/

        holder.binding.tvWeekDay.isAllCaps = !DateUtils.compareDateWithToday(day.weekDate!!)

        holder.itemView.setOnClickListener {
            setSelection(position)
        }
    }

    fun setOnItemSelectListener(listener: OnDaySelectedListener) {
        this.listener = listener
    }

    //Set item list, default selected item is first one
    override fun setItems(itemList: List<DeliveryDay>) {
        super.setItems(itemList)
    }

    fun setCart() {

    }


    //Change selected item position
    override fun setSelection(position: Int) {
        super.setSelection(position)
        if (items.isNotEmpty()) {
            listener?.onDaySelected(items[position])
        }
    }

    interface OnDaySelectedListener {
        fun onDaySelected(day: DeliveryDay)
    }

    inner class DeliveryDayViewHolder(val binding: RecyclerItemCheckoutDeliveryDayBinding) :
        RecyclerView.ViewHolder(binding.root)
}