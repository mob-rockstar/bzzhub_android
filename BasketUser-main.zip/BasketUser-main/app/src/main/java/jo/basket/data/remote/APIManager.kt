package jo.basket.data.remote

import android.content.Context
import android.util.Log
import com.google.gson.GsonBuilder
import com.google.gson.JsonObject
import com.jakewharton.retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import io.reactivex.Single
import jo.basket.BuildConfig
import jo.basket.data.local.prefs.PreferenceManager
import jo.basket.data.model.CreditCardResponse
import jo.basket.data.model.WalletHistoryResponse
import jo.basket.data.model.api.ServerResponse
import jo.basket.data.model.api.response.*
import jo.basket.data.model.api.response.base.BaseResponse
import jo.basket.data.model.api.response.newstoreaislelist.NewStoreAisleListResponse
import jo.basket.data.model.api.response.service.ServiceListResponse
import jo.basket.data.model.api.response.validateAddress.ValidateAddressResponse
import jo.basket.data.model.currency.CurrencyResponse
import jo.basket.data.model.payment.PaymentListResponse
import jo.basket.utils.AppConstants
import okhttp3.Cache
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.File
import java.net.URLEncoder
import java.util.concurrent.TimeUnit


object APIManager {

    private const val CACHE_FILE_NAME = "basket_http_cache"

    private lateinit var apiInterface: ApiInterface

    private var USER_TYPE = "customer"

    private var EVENT_CONVERSION_NAME = "product_added_to_cart"

    private val IS_CART = "cart"
    private val IS_CHECKOUT = "checkout"

    private var defaultDepartmentItemCount = 50
    private var isLatestApp = 1

    private val langCode: Int
        get() = if (PreferenceManager.currentUserLanguage > 2) 2 else PreferenceManager.currentUserLanguage
    private val userId: Long
        get() = PreferenceManager.currentUserId ?: 0
    private val countryId: Int
        get() = PreferenceManager.currentUserCountryId
    private val cityId: Int
        get() = PreferenceManager.currentUserCityId
    private val areaId: Int
        get() = PreferenceManager.currentUserAreaId
    private val userMobile: String
        get() = PreferenceManager.currentUserMobile ?: ""
    private val token: String
        get() = PreferenceManager.accessToken ?: ""
    private val fcmToken: String
        get() = PreferenceManager.fcmToken ?: ""
    private val deviceId: String
        get() = PreferenceManager.deviceId ?: ""

    private val storeId: Int
        get() = PreferenceManager.currentUserStoreId ?: 0

    private val REQUEST_FROM = 1


    fun init(context: Context) {
        // cache
        val cacheFile = File(context.cacheDir, CACHE_FILE_NAME)
        cacheFile.mkdir()
        val cache = Cache(cacheFile, 20 * 1000 * 1000)

        // OKHttp
        val okHttpClient = OkHttpClient.Builder()
            .connectTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .addInterceptor(LoggingInterceptor())
            .cache(cache)
            .build()

        // Retrofit
        val retrofit = Retrofit.Builder()
            .baseUrl(BuildConfig.BASE_URL)
            .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
            .addConverterFactory(
                GsonConverterFactory.create(
                    GsonBuilder()
                        .setLenient()
                        .create()
                )
            )
            .client(okHttpClient).build()

        apiInterface = retrofit.create(ApiInterface::class.java)


    }

    // API to get maintenance detail
    fun maintenanceDetails(): Single<MaintenanceResponse> {
        return apiInterface.maintenanceDetails()
            .map { serverResponse: ServerResponse<MaintenanceResponse>? -> serverResponse!!.response }
    }

    // API to check version number is allowed
    fun checkVersion(
        version: String,
        buildVersion: Int,
        appId: String
    ): Single<AppVersionResponse> {
        return apiInterface.checkVersion(AppConstants.DEVICE_TYPE, version, buildVersion, appId)
            .map { serverResponse: ServerResponse<AppVersionResponse>? -> serverResponse!!.response }
    }

    // API to get CMS detail - Privacy policy, terms and conditions
    fun getCmsDetail(cmsUrl: String): Single<CmsResponse> {
        return apiInterface.getCmsDetail(langCode, cmsUrl)
            .map { serverResponse: ServerResponse<CmsResponse>? -> serverResponse!!.response }
    }

    // API to check if Free delivery service is existing
    fun checkFreeDelivery(): Single<FreeDeliveryResponse> {
        return apiInterface.checkFreeDelivery(langCode, token, userId)
            .map { serverResponse: ServerResponse<FreeDeliveryResponse>? -> serverResponse!!.response }
    }

    //API to check disable Free Delivery
    fun disableFreeDelivery(): Single<SimpleResponse> {
        return apiInterface.disableFreeDeliveryPopup(langCode, token, userId)
            .map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    // API to verify mobile number - Send OTP to specific mobile number
    fun verifyMobile(
        countryCode: String,
        mobile: String,
        deviceId: String
    ): Single<VerifyMobileResponse> {
        return apiInterface.verifyMobile(
            langCode,
            AppConstants.PLATFORM,
            countryCode,
            mobile,
            deviceId,
            fcmToken,
            0
        )

    }

    // API to verify OTP (Received via SMS)
    fun verifyOtp(userId: Long, otp: String,deviceId: String): Single<LoginResponse> {
        return apiInterface.verifyOtp(langCode, userId, otp, deviceId, fcmToken)
    }

    //API to verify social OTP
    fun getSocialOTP(userId: Long): Single<VerifyMobileResponse> {
        return apiInterface.getSocialOTP(langCode, userId)
    }


    // API to Login with Password
    fun loginWithPassword(userId: Long, password: String): Single<LoginResponse> {
        return apiInterface.loginWithPassword(langCode, userId, password)
    }

    //API to set First name and Last name of customer
    fun updateCustomerName(
        userId: Long,
        firstName: String,
        lastName: String
    ): Single<LoginResponse> {
        return apiInterface.updateCustomerName(langCode, userId, firstName, lastName)
    }

    //API to set Email and Password of customer
    fun updateCustomerEmailAndPassword(
        userId: Long,
        email: String,
        password: String
    ): Single<LoginResponse> {
        return apiInterface.updateCustomerEmailAndPassword(langCode, userId, email, password)
    }

    // API for Customer Regular sign up
    fun customerRegularSignUp(
        userId: Long,
        firstName: String,
        lastName: String,
        email: String,
        password: String
    ): Single<NormalSignUpResponse> {
        return apiInterface.customerRegularSignUp(
            langCode,
            userId,
            firstName,
            lastName,
            email,
            password
        )
    }

    //API to set Gender of Customer
    fun updateCustomerGender(
        userId: Long,
        email: String,
        gender: String
    ): Single<LoginResponse> {
        return apiInterface.updateCustomerEmailAndPassword(langCode, userId, email, gender)
    }

    //API to change password
    fun changePassword(userId: Long, password: String): Single<LoginResponse> {
        return apiInterface.changePassword(langCode, userId, password)
    }

    // API to login with existing social media (FaceBook and google for now)
    fun loginWithSocial(
        socialType: String,
        socialId: String?,
        deviceId: String
    ): Single<LoginResponse> {
        return apiInterface.loginWithSocial(
            langCode,
            socialType,
            socialId,
            AppConstants.PLATFORM,
            deviceId,
            fcmToken
        )
    }

    // API to sign up with new social media account
    fun signupWithSocial(
        socialType: String,
        socialId: String?,
        firstName: String,
        lastName: String,
        countryCode: String,
        mobile: String,
        email: String,
        birthday: String,
        gender: String,
        deviceId: String
    ): Single<LoginResponse> {
   //     BasketAnalyticsManager.signUp()
        return apiInterface.signupWithSocial(
            langCode,
            socialType,
            socialId,
            firstName,
            lastName,
            countryCode,
            mobile,
            email,
            birthday,
            gender,
            AppConstants.PLATFORM,
            deviceId,
            fcmToken
        )
    }

    // API to check Basket App news
    fun getAppNews(): Single<AppNewsResponse> {
        return apiInterface.getAppNews(langCode, userId, token)
    }

    // API to update user's FCM token
    fun updateFcmToken(): Single<LoginResponse> {
        return apiInterface.updateFcmToken(langCode, userId, token, fcmToken)
    }

    // API to update user's location
    fun updateUserLocation(countryId: Int, cityId: Int, areaId: Int): Single<BaseResponse> {
        return apiInterface.updateUserLocation(langCode, token, userId, countryId, cityId, areaId)
            .map { serverResponse: ServerResponse<BaseResponse>? -> serverResponse!!.response }
    }

    fun getCurrencyCode(countryId: Int): Single<CurrencyResponse> {
        return apiInterface.getCurrencyCode(langCode, countryId)
    }

    // Google-API to do reverse Geo0coding
    fun getGoogleAddress(latitude: Double, longitude: Double): Single<JsonObject> {
        return apiInterface.callGoogleAPI(
            "https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=${AppConstants.GOOGLE_MAP_API_KEY}"
        )
    }

    // Google-API to get suggested address list
    fun getAddressSuggestionList(keyword: String): Single<JsonObject> {
        return apiInterface.callGoogleAPI(
            "https://maps.googleapis.com/maps/api/place/autocomplete/json?sensor=false&key=${AppConstants.GOOGLE_MAP_API_KEY}&input=${
                URLEncoder.encode(
                    keyword,
                    "utf8"
                )
            }"
        )
    }

    // Google API to get detail of address
    fun getAddressDetail(placeId: String): Single<JsonObject> {
        return apiInterface.callGoogleAPI(
            "https://maps.googleapis.com/maps/api/place/details/json?place_id=${placeId}&key=${AppConstants.GOOGLE_MAP_API_KEY}"
        )
    }

    // API to perform Logout
    fun logout(): Single<BaseResponse> {
        return apiInterface.logout(langCode, token, userId, fcmToken)
            .map { serverResponse: ServerResponse<BaseResponse>? -> serverResponse!!.response }
    }

    // API to get list of countryNCities
    fun getCountryNCities(): Single<CountryCityResponse> {
        return apiInterface.getCountryCityList(userId, langCode, token)

    }

    // API to get list of cities
    fun getCities(): Single<CityResponse> {
        return apiInterface.getCities(langCode, token)
            .map { serverResponse: ServerResponse<CityResponse>? -> serverResponse!!.response }
    }

    // API to get list of cities
    fun getCityAreas(countryId: Int): Single<CityAreaListResponse> {
        return apiInterface.getCityAreaList(userId, langCode, token, countryId)
    }

    // API to get list of address
    fun getAreas(cityId: Int): Single<AreaResponse> {
        return apiInterface.getAreas(langCode, token, cityId)
            .map { serverResponse: ServerResponse<AreaResponse>? -> serverResponse!!.response }
    }

    // API to get list of stores
    fun getStores(cityId: Int, areaId: Int, lat: Double, lng: Double, serviceTypeId: Int): Single<StoreResponse> {
        return apiInterface.getStores(langCode, userId,  token, countryId , cityId, areaId, 0 ,
            if (lat != 0.0) lat.toString() else "",
            if (lng != 0.0) lng.toString() else "", serviceTypeId) .map { serverResponse: ServerResponse<StoreResponse>? -> serverResponse!!.response }
        Log.d("TAG", "getOldStores: "+cityId+" "+areaId+" "+lat+" "+lng+" "+langCode+" "+userId+" "+token+" "+countryId)

    }

    // API to get list of stores
    fun getOldStores(cityId: Int, areaId: Int, lat: Float,
                  lng: Float): Single<StoreResponse> {
        return apiInterface.getOldStores(langCode, userId,  token, countryId , cityId, areaId, 0 ,
            if (lat != 0.0f) lat.toString() else "",
            if (lng != 0.0f) lng.toString() else "") .map { serverResponse: ServerResponse<StoreResponse>? -> serverResponse!!.response }


    }

    fun getServiceList(lat: Double,
                  lng: Double): Single<ServiceListResponse> {
        return apiInterface.getServiceList(langCode, userId, token, lat.toString(),
            lng.toString(),"iOS")
    }
    fun searchProductEventClick(
        queryId: String,
        objectIds: ArrayList<String>,
        positions: ArrayList<Int>
    ): Single<SimpleResponse> {
        return apiInterface.searchProductEventClick(
            langCode,
            token,
            userId,
            queryId,
            objectIds,
            positions
        )
    }

    fun searchProductEventConversion(
        queryId: String,
        objectIds: ArrayList<String>
    ): Single<SimpleResponse> {
        return apiInterface.searchProductEventConversion(
            langCode,
            token,
            userId,
            EVENT_CONVERSION_NAME,
            objectIds,
            queryId
        )
    }

    fun getPickUpServiceAvailability(): Single<PickupServiceAvailabilityResponse> {
        return apiInterface.getPickUpServiceAvailability(langCode, userId, token)
    }

    fun updatePickUpServiceDemand(
        countryId: Int,
        cityId: Int,
        areaId: Int,
        latitude: Double,
        longitude: Double
    ): Single<PickupServiceAvailabilityResponse> {
        return apiInterface.updatePickUpServiceDemand(
            langCode,
            userId,
            token,
            countryId,
            cityId,
            areaId,
            latitude,
            longitude
        )
    }

    fun updateUserSelectedStore(storeId: Int): Single<SimpleResponse> {
        return apiInterface.updateUserSelectedStore(langCode, userId, token, storeId)
    }

    //API to get list of departments for particular stores
    fun getStoreDepartments(storeId: Int): Single<StoreDepartmentResponse> {
        return apiInterface.getStoreDepartments(langCode, userId, token, storeId)
            .map { serverResponse: ServerResponse<StoreDepartmentResponse>? -> serverResponse!!.response }
    }

    // API to get Homepage data of particular store
    fun getStoreHomePages(storeId: Int): Single<StoreHomePageResponse> {
        return apiInterface.getStoreHomePages(langCode, userId, token, storeId, 0)
            .map { serverResponse: ServerResponse<StoreHomePageResponse>? -> serverResponse!!.response }
    }

    // API to get Homepage data of particular store
    fun getNewStoreHomePages(storeId: Int, vendorId: Int): Single<NewStoreHomePageResponse> {
        return apiInterface.getNewStoreHomePages(langCode, userId, token, storeId, 0, vendorId, countryId, cityId)
    }

    // API to get Store delivery information
    fun getOutletPricingDeliveryInfo(
        storeId: Int,
        cityId: Int,
        countryId: Int
    ): Single<DeliveryPricingResponse> {
        return apiInterface.getOutletPricingDeliveryInfo(
            langCode,
            userId,
            token,
            storeId,
            cityId,
            countryId
        )
    }

    // API to get ordered products of store
    fun getOrderedProducts(storeId: Int, searchKey: String): Single<OrderedProductsResponse> {
        return apiInterface.getOrderedProducts(langCode, userId, token, storeId, searchKey)
            .map { serverResponse: ServerResponse<OrderedProductsResponse>? -> serverResponse!!.response }
    }

    // Get aisle list for particular department
    fun getDepartmentCategories(
        storeId: Int,
        departmentId: Int,
        vendorId: Int,
        sectionTypeId: Int
    ): Single<StoreCategoryResponse> {
        return apiInterface.getDepartmentCategories(
            langCode,
            userId,
            token,
            storeId,
            departmentId,
            vendorId,
            sectionTypeId
        )
            .map { serverResponse: ServerResponse<StoreCategoryResponse>? -> serverResponse!!.response }
    }

    fun getNewAisleList(
        storeId: Int,
        departmentId: Int,
        departmentType: String,
        aisleId: Int,
        offset: Int,
    ): Single<NewStoreAisleListResponse>{
        return  apiInterface.getNewDepartmentCategories(
            langCode, userId, token, storeId, departmentId, departmentType, aisleId, offset, defaultDepartmentItemCount
        )
    }

    // Get list of products - from the aisle
    fun getCategoryProducts(
        storeId: Int,
        departmentId: Int,
        categoryId: Int,
        sectionTypeId: Int
    ): Single<StoreProductsResponse> {
        return apiInterface.getCategoryProducts(
            langCode,
            userId,
            token,
            storeId,
            departmentId,
            categoryId,
            sectionTypeId
        )
            .map { serverResponse: ServerResponse<StoreProductsResponse>? -> serverResponse!!.response }
    }

    // Get list of products marked as favorite from a particular store
    fun getFavoriteProducts(storeId: Int): Single<StoreProductsResponse> {
        return apiInterface.getFavoriteProducts(langCode, userId, token, storeId)
            .map { serverResponse: ServerResponse<StoreProductsResponse>? -> serverResponse!!.response }
    }

    // Get List of promotion products
    fun getPromotionProducts(storeId: Int, promotionId: Int): Single<PromotionProductsResponse> {
        return apiInterface.getPromotionProducts(langCode, userId, token, storeId, promotionId)
            .map { serverResponse: ServerResponse<PromotionProductsResponse>? -> serverResponse!!.response }
    }

    // Get List of featured products
    fun getFeaturedProducts(storeId: Int): Single<StoreProductsResponse> {
        return apiInterface.getFeaturedProducts(langCode, userId, token, storeId)
            .map { serverResponse: ServerResponse<StoreProductsResponse>? -> serverResponse!!.response }
    }

    // Get list of Ramadan products
    fun getRamadanProducts(storeId: Int): Single<StoreProductsResponse> {
        return apiInterface.getRamadanProducts(langCode, userId, token, storeId)
            .map { serverResponse: ServerResponse<StoreProductsResponse>? -> serverResponse!!.response }
    }

    // Add items to cart
    fun addToCart(
        storeId: Int,
        productId: Int,
        note: String?,
        amount: Double,
        vendorId: Int,
        cartDetailId: Int = 0,
        customItemString : String = "",
        showProductDetail: Int? = 0
    ): Single<AddCartResponse> {
    /*    if (amount == 0.0)
            BasketAnalyticsManager.removeFromCart(0, storeId, productId, amount, 0.0)
        else
            BasketAnalyticsManager.addToCart(0, storeId, productId, amount, amount)*/

        return apiInterface.addToCart(
            langCode,
            userId,
            token,
            storeId,
            productId,
            note,
            amount,
            vendorId,
            countryId,
            cityId,
            cartDetailId,
            customItemString,
            showProductDetail ?: 0
        ).map { serverResponse: ServerResponse<AddCartResponse>? -> serverResponse!!.response }
    }

    // Give suggestion to shoppers if product is out of stock
    fun replaceLowInStockItem(
        cartOutletId: Int,
        cartOutletItemId: Int,
        customerSuggestionType: Int,
        customerSuggestionItemId: Int,
        note: String = ""
    ): Single<SimpleResponse> {
        return apiInterface.replaceLowInStockItem(
            langCode,
            userId,
            token,
            cartOutletId,
            cartOutletItemId,
            customerSuggestionType,
            customerSuggestionItemId,
            note
        )
            .map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    // Get List of suggestion products for particular item
    fun getLowRunningSuggestionList(
        storeId: Int,
        productSearch: String,
        outletItemId: Int,
        offset: Int,
        count: Int,
        isFromSearch: Int
    ): Single<LowInStockSuggestionListResponse> {
        return apiInterface.getLowRunningSuggestionList(
            langCode,
            userId,
            token,
            storeId,
            productSearch,
            outletItemId,
            offset,
            count,
            isFromSearch
        )
    }

    // Add Custom product to cart - mainly to be used to add note for custom product
    fun addCustomItemToCart(
        storeId: Int,
        cartDetailId: Int,
        note: String?,
        amount: Double,
        vendorId: Int
    ): Single<SimpleResponse> {
        return apiInterface.addCustomItemToCart(
            langCode,
            userId,
            token,
            storeId,
            cartDetailId,
            note,
            amount,
            countryId,
            cityId
        ).map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    //Add product to favorite list
    fun addToFavorite(productId: Int): Single<SimpleResponse> {
        return apiInterface.addToFavorite(langCode, userId, token, productId)
            .map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    // Remove product from favorite list
    fun removeFromFavorite(productId: Int): Single<SimpleResponse> {
        return apiInterface.removeFromFavorite(langCode, userId, token, productId)
            .map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    // Add note for items in cart
    fun addNote(storeId: Int, outletItemId: Int, note: String): Single<SimpleResponse> {
        return apiInterface.addNote(langCode, userId, token, outletItemId, note)
            .map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    // Add Custom product to cart
    fun addCustomProduct(
        productName: String,
        unit: String,
        quantity: Double,
        instruction: String,
        outletId: Int,
        price: String,
        departmentId: Int,
        productImage: File?
    ): Single<SimpleResponse> {

        var image: MultipartBody.Part? = null
        image = if (productImage != null) {
            val requestFile: RequestBody =
                productImage.asRequestBody("image/png".toMediaTypeOrNull())
            MultipartBody.Part.createFormData("product_image", productImage.name, requestFile)
        } else {
            val attachmentEmpty = "".toRequestBody("image/png".toMediaTypeOrNull())
            MultipartBody.Part.createFormData("product_image", "", attachmentEmpty)
        }

        return apiInterface.addCustomItemToCart(
            langCode.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            userId.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            token.toRequestBody("text/plain".toMediaTypeOrNull()),
            outletId.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            productName.toRequestBody("text/plain".toMediaTypeOrNull()),
            unit.toRequestBody("text/plain".toMediaTypeOrNull()),
            quantity.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            price.toRequestBody("text/plain".toMediaTypeOrNull()),
            instruction.toRequestBody("text/plain".toMediaTypeOrNull()),
            departmentId.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            image
        ).map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    // Get search hint list of store
    fun getProductHints(query: String, storeId: Int): Single<HintSuggestionResponse> {
        return apiInterface.getProductSuggestionHintList(langCode, userId, token, query, storeId)
            .map { serverResponse: ServerResponse<HintSuggestionResponse>? -> serverResponse!!.response }
    }

    // Clear search history
    fun clearSearchHistory(storeId: Int): Single<SimpleResponse> {
        return  apiInterface.clearSearchHistory(langCode, userId, token, storeId)
    }

    // Search existing stores
    fun searchStores(storeId: Int, search: String): Single<StoreResponse> {
        return apiInterface.searchStores(langCode, userId, token, cityId, areaId, storeId, search)
            .map { serverResponse: ServerResponse<StoreResponse>? -> serverResponse!!.response }
    }

    // Search products with keyword
    fun searchProducts(
        storeId: Int,
        service_id: Int,
        search: String,
        offset: Int,
        count: Int,
        order_by: Int
    ): Single<SearchProductsResponse> {
        return apiInterface.searchProducts(langCode, userId, token, storeId, search, offset, count,service_id,order_by)
            .map { serverResponse: ServerResponse<SearchProductsResponse>? -> serverResponse!!.response }
    }

    // Get all products from cart
    fun getMyCart(storeId: Int): Single<MyCartResponse> {
        return apiInterface.getMyCart(langCode, userId, token,
            if (PreferenceManager.currentUserId == 0L) 0 else if (countryId == 0) 46 else countryId , cityId, areaId, storeId)
            .map { serverResponse: ServerResponse<MyCartResponse>? -> serverResponse!!.response }
    }
    fun getStoreAllMyCart(serviceId: String): Single<StoreMyCartResponse> {
        return apiInterface.getStoreAllMyCart(langCode, userId, token,
            if (PreferenceManager.currentUserId == 0L) 0 else if (countryId == 0) 46 else countryId , cityId, areaId, serviceId).map { serverResponse: StoreMyCartResponse? -> serverResponse!! }
    }

    // Get count of products added in cart
    fun getCartCount(): Single<CartCountResponse> {
        return apiInterface.getCartCount(langCode, userId, token, countryId, cityId, storeId)
            .map { serverResponse: ServerResponse<CartCountResponse>? -> serverResponse!!.response }
    }

    // Remove all products from a particular store in cart
    fun removeCart(storeId: Int): Single<SimpleResponse> {
        return apiInterface.removeCart(langCode, userId, token, storeId)
            .map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    // remove particular product from store
    fun removeProductFromCart(cartDetailID: Int): Single<SimpleResponse> {
        return apiInterface.removeProductFromCart(langCode, userId, token, cartDetailID)
            .map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    // Add all products from a store (added in cart) to specific order
    fun addCartItemsToOrder(storeId: Int, orderStoreId: Int): Single<SimpleResponse> {
        return apiInterface.addCartItemsToOrder(langCode, userId, token, storeId, orderStoreId)
            .map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    // Get checkout detail information
    fun getCheckoutDetail(isFromCart: Boolean, storeId: Int, cartId: String): Single<CheckoutResponse> {
        return apiInterface.getCheckoutDetail(langCode, userId, token, countryId, cityId, areaId, storeId, if (isFromCart) IS_CART else IS_CHECKOUT)
            .map { serverResponse: ServerResponse<CheckoutResponse>? -> serverResponse!!.response }
    }

    // Get list of delivery time slots
    fun getDeliverySlots(outletID: Int): Single<DeliverySlotsResponse> {
        return apiInterface.getDeliverySlots(langCode, userId, token, countryId, cityId, outletID)
            .map { serverResponse: ServerResponse<DeliverySlotsResponse>? -> serverResponse!!.response }
    }

    // Update checkout delivery instruction
    fun updateDeliveryInstruction(instruction: String): Single<SimpleResponse> {
        return apiInterface.updateDeliveryInstruction(langCode, userId, token, instruction)
            .map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    // Pay with credit card
    fun queryOnlinePayment(
        countryId: Int,
        cityId: Int,
        paymentId: Int,
        cardId: Int,
        instruction: String,
        cvv: String,
        adjustIDType: String,
        adjustIDValue: String,
        adjustADID: String,
        shopperTipAmount: Float
    ): Single<OnlinePaymentResponse> {
        return apiInterface.payToOrder(
            langCode,
            userId,
            token,
            countryId,
            cityId,
            paymentId,
            cardId,
            instruction,
            cvv,
            PreferenceManager.userCurrencyCode,
            AppConstants.ORDER_TYPE_DELIVERY,
            AppConstants.USER_TYPE,
            storeId,
            adjustIDType,
            adjustIDValue,
            adjustADID,
            shopperTipAmount
            //1
        ).map { serverResponse: ServerResponse<OnlinePaymentResponse>? -> serverResponse!!.response }
    }

    fun captureOnlinePayment(
        cardId: Int,
        orderId: Int,
        orderStoreId: Int,
    ): Single<PayByCardResponse> {
        return apiInterface.captureOnlinePayment(
            langCode,
            userId,
            token,
            PreferenceManager.userCurrencyCode,
            cardId,
            orderId,
            orderStoreId,
        )
    }

    fun expressCapacity(
        outletId: Int
    ): Single<SimpleResponse>{
        return apiInterface.expressCapacity(
            langCode,
            userId,
            token,
            outletId
        )
    }

    fun updatePaymentMethodForOrder(
        cardId: Int,
        orderId: Int,
        orderOutletId: Int,
        paymentGatewayId: Int
    ): Single<PayByCardResponse>{
        return apiInterface.updatePaymentMethodForOrder(
            langCode, userId, token, cardId, orderId, orderOutletId, paymentGatewayId
        )
    }

    // Order with cash-on-delivery option
    fun offlinePayment(
        countryId: Int,
        cityId: Int,
        paymentId: Int,
        instruction: String,
        adjustIDType: String,
        adjustIDValue: String,
        adjustADID: String,
    ): Single<SimpleResponse> {
        return apiInterface.offlinePayment(
            langCode,
            userId,
            token,
            countryId,
            cityId,
            paymentId,
            instruction,
            PreferenceManager.userCurrencyCode,
            AppConstants.ORDER_TYPE_DELIVERY,
            AppConstants.USER_TYPE,
            fcmToken,
            deviceId,
            AppConstants.PLATFORM,
            storeId,
            adjustIDType,
            adjustIDValue,
            adjustADID,
        ).map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    //Update delivery address to checkout
    fun updateDeliveryAddress(addressId: Int): Single<SimpleResponse> {
        return apiInterface.updateDeliveryAddress(langCode, userId, token, addressId)
            .map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    //Update delivery time
    fun updateDeliverySlot(
        storeId: Int,
        deliveryDay: String,
        deliverySlotTimeId: Int,
        deliveryTime: String
    ): Single<SimpleResponse> {
        return apiInterface.updateDeliverySlot(
            langCode,
            userId,
            token,
            countryId,
            cityId,
            storeId,
            deliveryDay,
            deliverySlotTimeId,
            deliveryTime
        ).map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    // Apply promo code to checkout products
    fun addPromoCodeToCart(promoCode: String): Single<SimpleResponse> {
        return apiInterface.addPromoCodeToCart(langCode, userId, token, cityId, promoCode, storeId)
            .map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    // Remove promo code to checkout products
    fun removePromoFromCart(): Single<SimpleResponse> {
        return apiInterface.removePromoFromCart(langCode, userId, token)
            .map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    // Get payment list of customer
    fun getPaymentMethods(pageId: Int): Single<PaymentMethodsResponse> {
        return apiInterface.getPaymentMethods(langCode, userId, token, pageId)
            .map { serverResponse: ServerResponse<PaymentMethodsResponse>? -> serverResponse!!.response }
    }

    // Get payment list of customer
    fun getNewPaymentMethods(countryId: Int, pageId: Int): Single<PaymentListResponse> {
        return apiInterface.getPaymentListNew(langCode, userId, token, countryId, cityId, pageId)
    }

    // Update payment method information (visa, credit card)
    fun updatePaymentMethod(paymentId: Int, cardId: Int?): Single<SimpleResponse> {
        return apiInterface.updatePaymentMethod(langCode, userId, token, paymentId, cardId, PreferenceManager.currentUserStoreId)
            .map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    //Add credit card as payment method
    fun addCreditCard(
        cardNumber: String,
        merchantReference: String,
        tokenName: String,
        cardHolderName: String,
        paymentOption: String,
        responseCode: String,
        responseMessage: String,
        expiryDate: String,
        serviceCommand: String,
        fortId: String,
        sdkToken: String,
        pageId: Int,
        outletId: Int?= null,
        selectedPaymentId: Int? = null
    ): Single<CreditCardResponse> {
        return apiInterface.addUserCard(
            langCode,
            userId,
            token,
            cardNumber,
            merchantReference,
            tokenName,
            cardHolderName,
            paymentOption,
            responseCode,
            responseMessage,
            expiryDate,
            serviceCommand,
            fortId,
            sdkToken,
            AppConstants.USER_TYPE,
            countryId,
            cityId,
            pageId,
            outletId,
            selectedPaymentId
        ).map { serverResponse: ServerResponse<CreditCardResponse>? -> serverResponse!!.response }
    }

    // Delete credit card from customer's payment method list
    fun deleteCreditCard(cardId: Int): Single<SimpleResponse> {
        return apiInterface.deleteCreditCard(langCode, userId, token, cardId)
            .map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    // Get list of orders (currently 5 orders each page)
    fun getOrderHistory(offset: Int, count: Int, filterType: Int): Single<OrderResponseNew> {
        return apiInterface.getOrderHistory(langCode, userId, token, offset, count, countryId, cityId, filterType)
    }

    // Add all items from particular order to cart
    fun addAllOrderItemsToCart(storeId: Int, orderStoreId: Int): Single<SimpleStatusResponse> {
        return apiInterface.addAllOrderItemsToCart(langCode, userId, token, storeId, orderStoreId)
    }

    // Get detail of particular order
    fun getOrderDetail(orderId: Int, orderStoreId: Int): Single<OrderDetailResponse> {
        return apiInterface.getOrderDetail(langCode, userId, token, orderId, orderStoreId)
            .map { serverResponse: ServerResponse<OrderDetailResponse>? -> serverResponse!!.response }
    }

    // Get delivery slot of order
    fun getOrderDeliverySlots(storeId: Int, orderStoreId: Int): Single<DeliverySlotsResponse> {
        return apiInterface.getOrderDeliverySlots(
            langCode,
            userId,
            token,
            countryId,
            cityId,
            storeId,
            orderStoreId
        )
            .map { serverResponse: ServerResponse<DeliverySlotsResponse>? -> serverResponse!!.response }
    }

    // Update delivery slot of order - will be possible before shopper started shopping
    fun updateOrderDeliverySlot(
        storeId: Int,
        orderStoreId: Int,
        deliveryDay: String,
        deliverySlotTimeId: Int,
        deliveryTime: String,

    ): Single<SimpleResponse> {
        return apiInterface.updateOrderDeliverySlot(
            langCode,
            userId,
            token,
            countryId,
            cityId,
            storeId,
            orderStoreId,
            deliveryDay,
            deliverySlotTimeId,
            deliveryTime
        ).map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    // Add product to order
    fun addToOrder(
        note: String,
        storeId: Int,
        orderStoreId: Int,
        productId: Int,
        amount: Double
    ): Single<SimpleResponse> {

        return apiInterface.addToOrder(
            langCode,
            userId,
            token,
            note,
            storeId,
            orderStoreId,
            productId,
            amount
        ).map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    // Get detail of order (product lists and status - shopped, refunded, replaced) for completed orders
    fun getCompleteOrderDetail(orderStoreId: Int): Single<CompleteOrderDetailResponse> {
        return apiInterface.getCompleteOrderDetail(langCode, userId, token, orderStoreId)
            .map { serverResponse: ServerResponse<CompleteOrderDetailResponse>? ->
                val shoppedItems = serverResponse?.response?.storeOrderDetail?.shoppedItemList
                if (!shoppedItems.isNullOrEmpty()) {
                    for (shoppedItem in shoppedItems) {
                        shoppedItem.convertJsonToList()
                    }
                }
                serverResponse!!.response
            }
    }

    //Get detail of order for 'Before started shopping' orders
    fun getStoreOrderDetail(orderStoreId: Int): Single<StoreOrderDetailResponse> {
        return apiInterface.getStoreOrderDetail(langCode, userId, token, orderStoreId)
            .map { serverResponse: ServerResponse<StoreOrderDetailResponse>? -> serverResponse!!.response }
    }

    // Get detail of product, with storeId and productId
    fun getProductDetail(storeId: Int, productId: Int, cartDetailId: Int?= 0): Single<ProductResponse> {
        return apiInterface.getProductDetail(langCode, userId, token, storeId, productId, cartDetailId?:0, if (cartDetailId != null && cartDetailId != 0) 1 else 0)
            .map { serverResponse: ServerResponse<ProductResponse>? -> serverResponse!!.response }
    }

    // Get list of items for 'Shopping and delivering' status Orders
    fun getShoppingItems(orderStoreId: Int): Single<ShoppingItemsResponse> {
        return apiInterface.getShoppingItems(langCode, userId, token, orderStoreId)
    }

    // Give suggestion to shopper for a replacement
    fun replaceItemWithCustomerSuggestionDetail(
        orderId: Int,
        orderStoreId: Int,
        productId: Int,
        suggestionType: Int,
        suggestionProductId: Int,
        amount: Double?,
        suggestionFrom: Int?,
        note: String
    ): Single<SimpleUpdateResponse> {
        return apiInterface.replaceItemWithCustomerSuggestionDetail(
            langCode,
            userId,
            token,
            orderStoreId,
            productId,
            suggestionType,
            suggestionProductId,
            amount,
            suggestionFrom,
            note
        )
    }

    // Approve shopper's replacement suggestion
    fun approveReplaceOrderItem(
        orderId: Int,
        orderStoreId: Int,
        productId: Int,
        approveType: Int, replaceItemID: Int,  isMultipleReplacement: Boolean , requestFrom : Int
    ): Single<SimpleStatusResponse> {
        return apiInterface.approveReplaceOrderItem(
            langCode,
            userId,
            token,
            orderStoreId,
            productId,
            approveType,
            requestFrom,  replaceItemID,
      //      if (isMultipleReplacement && approveType != ShoppingFragment.APPROVE_TYPE_REFUND) 1 else 0,  replaceItemID,
        )
    }

    fun addSecondaryMobile(
        mobileNumber: String,
    ): Single<AddSecondaryMobile> {
        return apiInterface.addSecondaryMobile(
            userId,
            token,
            mobileNumber,
        )
    }

    fun verifySecondaryMobile(
        mobileNumber: String,
        otp: String,
    ): Single<VerifyMobileResponse> {
        return apiInterface.verifySecondaryMobile(
            userId,
            token,
            otp,
            mobileNumber,
        )
    }

    //Get rating detail of a particular order - Rated or not
    fun getLastOrderRatings(orderStoreId: Int): Single<OrderRatingsResponse> {
        return apiInterface.getLastOrderRatings(langCode, userId, token, orderStoreId)
            .map { serverResponse: ServerResponse<OrderRatingsResponse>? -> serverResponse!!.response }
    }

    //Get rating detail of a particular order - Rated or not
    fun getOrderRatings(orderStoreId: Int): Single<OrderRatingsResponse> {
        return apiInterface.getOrderRatings(langCode, userId, token, orderStoreId)
            .map { serverResponse: ServerResponse<OrderRatingsResponse>? -> serverResponse!!.response }
    }

    //Get rating detail of a particular order - for Rating completed order
    fun rateOrder(
        orderId: Int,
        orderStoreId: Int,
        shopperRating: Float,
        driverRating: Float,
        comments: String,
    ): Single<SimpleResponse> {
        return apiInterface.rateOrder(
            langCode,
            userId,
            token,
            orderStoreId,
            shopperRating,
            driverRating,
            comments
        ).map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    //Get rating detail of a particular order - for Rating completed order
    fun skipOrderRating(orderStoreId: Int): Single<SimpleResponse> {
        return apiInterface.skipOrderRating(langCode, userId, token, orderStoreId)
    }

    // Cancel order Reason List
    fun getCancelOrderReasonList(pageType: Int): Single<CancelReasonListResponse> {
        return apiInterface.getCancelOrderReasonList(langCode, userId, token, pageType)
    }

    // Cancel order
    fun cancelOrder(
        orderStoreId: Int,
        outletTotal: Float,
        reasonId: Int,
        cancelReasonComment: String
    ): Single<SimpleResponse> {
        return apiInterface.cancelOrder(
            langCode,
            userId,
            token,
            orderStoreId,
            reasonId,
            cancelReasonComment
        )
            .map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    // Get Notification list of user
    fun getNotificationList(): Single<NotificationResponse> {
        return apiInterface.getNotificationList(langCode, userId, token)
            .map { notificationResponse: ServerResponse<NotificationResponse>? -> notificationResponse!!.response }
    }

    // Mark a particular notification as read
    fun readNotification(notificationID: Int): Single<SimpleResponse> {
        return apiInterface.readNotification(langCode, userId, token, notificationID)
            .map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    // Mark all notification as read
    fun readAllNotifications(): Single<SimpleResponse> {
        return apiInterface.readAllNotifications(langCode, userId, token)
            .map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    // Mark all notification as read
    fun removeAllNotifications(): Single<SimpleResponse> {
        return apiInterface.removeAllNotifications(langCode, userId, token)
            .map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    // Get information of Basket Support (Email and Mobile)
    fun getSupportInformation(): Single<ContactInfoResponse> {
        return apiInterface.getSupportInformation()
            .map { serverResponse: ServerResponse<ContactInfoResponse>? -> serverResponse!!.response }
    }

    // Update customer profile information
    fun updateProfile(
        firstName: String,
        lastName: String,
        email: String,
        mobile: String,
        gender: String
    ): Single<ProfileResponse> {
        return apiInterface.updateProfile(
            langCode,
            userId,
            token,
            firstName,
            lastName,
            email,
            mobile,
            gender
        ).map { profileResponse: ServerResponse<ProfileResponse>? -> profileResponse!!.response }
    }

    // Remove Profile Image
    fun removeProfileImage():Single<SimpleResponse>{
        return apiInterface.removeProfileImage(langCode, userId, token)
    }

    // Update customer profile image
    fun updateProfileImage(profileImage: File?): Single<ProfileImageResponse> {

        var image: MultipartBody.Part? = null
        image = if (profileImage != null) {
            val requestFile: RequestBody =
                profileImage.asRequestBody("image/png".toMediaTypeOrNull())
            MultipartBody.Part.createFormData("image", profileImage.name, requestFile)
        } else {
            val attachmentEmpty = "".toRequestBody("image/png".toMediaTypeOrNull())
            MultipartBody.Part.createFormData("image", "", attachmentEmpty)
        }

        return apiInterface.updateProfileImage(
            langCode.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            userId.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            token.toRequestBody("text/plain".toMediaTypeOrNull()),
            image
        ).map { serverResponse: ProfileImageResponse? -> serverResponse }
    }

    // Change customer password
    fun changePassword(password: String): Single<SimpleResponse> {
        return apiInterface.changePassword(langCode, userMobile, token, password, password)
            .map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    //Get list of application information
    fun getAppInfo(): Single<AboutAppResponse> {
        return apiInterface.getAppInfo(langCode)
            .map { serverResponse: ServerResponse<AboutAppResponse>? -> serverResponse!!.response }
    }

    //Get List of address types
    fun getAddressTypes(): Single<AddressTypeResponse> {
        return apiInterface.getAddressTypes(langCode)
            .map { serverResponse: ServerResponse<AddressTypeResponse>? -> serverResponse!!.response }
    }

    // Add address to user
    fun addAddress(
        countryId: Int,
        cityId: Int?,
        locationId: Int?,
        lat: Double,
        lng: Double,
        addressType: Int,
        address: String?,
        departmentBuilding: String?,
        additionalInfo: String?,
    ): Single<AddAddressResponse> {
     //   BasketAnalyticsManager.addAddress()
        return apiInterface.addAddress(
            langCode,
            userId,
            token,
            countryId,
            cityId,
            locationId,
            lat,
            lng,
            addressType,
            address,
            departmentBuilding,
            additionalInfo,
            isLatestApp
        )
            .map { serverResponse: ServerResponse<AddAddressResponse>? -> serverResponse!!.response }
    }

    //validate address if it's delivering with latitude and longitude
    fun validateAddress(
        lat: Double,
        lng: Double,
    ): Single<ValidateAddressResponse>{
        return apiInterface.validateAddress(
            langCode, userId, token, lat, lng
        )
    }

    // Update user address
    fun updateAddress(
        addressId: Int,
        countryId: Int,
        cityId: Int,
        locationId: Int,
        lat: Double,
        lng: Double,
        addressType: Int,
        address: String?,
        departmentBuilding: String?,
        nearLandmark: String?,
        additionalInfo: String?
    ): Single<SimpleResponse> {
        return apiInterface.updateAddress(
            langCode,
            userId,
            token,
            addressId,
            countryId,
            cityId,
            locationId,
            lat,
            lng,
            addressType,
            address,
            departmentBuilding,
            nearLandmark,
            additionalInfo,
        )
            .map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    //Delete user's selected address
    fun deleteAddress(addressId: Int): Single<SimpleResponse> {
        return apiInterface.deleteAddress(langCode, userId, token, addressId)
            .map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    // Get Notification settings information of customer
    fun getNotificationSettings(): Single<NotificationSettingResponse> {
        return apiInterface.getNotificationSettings(langCode, userId, token)
            .map { serverResponse: ServerResponse<NotificationSettingResponse>? -> serverResponse!!.response }
    }

    //Update notification setting
    fun updateNotificationSettings(
        enablePush: Int,
        updateSMS: Int,
        updateCall: Int,
        promoEmail: Int,
        promoPush: Int,
        promoSMS: Int
    ): Single<SimpleResponse> {
        return apiInterface.updateNotificationSettings(
            langCode,
            userId,
            token,
            enablePush,
            updateSMS,
            updateCall,
            promoEmail,
            promoPush,
            promoSMS
        )
            .map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    // Get list of country
    fun getCountryList(): Single<CountrySettingResponse> {
        return apiInterface.getCountryList(langCode, userId, token)
            .map { serverResponse: ServerResponse<CountrySettingResponse>? -> serverResponse!!.response }
    }

    // Update country selection
    fun updateCountrySettings(countryId: Int): Single<SimpleUpdateResponse> {
        return apiInterface.updateCountrySetting(langCode, userId, token, countryId)
    }

    // Get language options
    fun getLanguageList(): Single<LanguageListResponse> {
        return apiInterface.getLanguageList()
            .map { serverResponse: ServerResponse<LanguageListResponse>? -> serverResponse!!.response }
    }

    // Update language setting
    fun updateLanguageSetting(languageID: Int): Single<SimpleUpdateResponse> {
        return apiInterface.updateLanguageSetting(languageID, userId, token)
    }

    // Get Loyalty card list
    fun getLoyaltyCardList(): Single<LoyaltyCardListResponse> {
        return apiInterface.getLoyaltyCardList(langCode, userId, token, countryId, cityId)
            .map { serverResponse: ServerResponse<LoyaltyCardListResponse>? -> serverResponse!!.response }
    }

    // Add Loyalty card
    fun addLoyaltyCard(vendorId: Int, cardNumber: String): Single<SimpleUpdateResponse> {
        return apiInterface.addLoyaltyCard(
            langCode,
            userId,
            token,
            countryId,
            cityId,
            vendorId,
            cardNumber
        )
    }

    // Update Loyalty card
    fun updateLoyaltyCard(
        vendorId: Int,
        cardNumber: String,
        loyaltyCardID: Int
    ): Single<SimpleUpdateResponse> {
        return apiInterface.updateLoyaltyCard(
            langCode,
            userId,
            token,
            countryId,
            cityId,
            vendorId,
            cardNumber,
            loyaltyCardID
        )
    }

    //Remove Loyalty card
    fun removeLoyaltyCard(loyaltyCardID: Int): Single<SimpleUpdateResponse> {
        return apiInterface.removeLoyaltyCard(langCode, userId, token, loyaltyCardID)
    }

    // Get promo code information
    fun getPromoCodes(): Single<PromoCodeResponse> {
        return apiInterface.getPromoCodes(langCode, userId, token)
            .map { serverResponse: ServerResponse<PromoCodeResponse>? -> serverResponse!!.response }
    }

    // Add promo code to account
    fun addPromoCodeToAccount(promoCode: String): Single<SimpleResponse> {
        return apiInterface.addPromoCodeToAccount(langCode, userId, token, promoCode)
            .map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    // Remove promo code from account
    fun removePromoCodeFromAccount(promoId: Int): Single<SimpleResponse> {
        return apiInterface.removePromoCodeFromAccount(langCode, userId, token, promoId)
            .map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    // Get in-completed orders count
    fun getOpenedOrderCount(): Single<OpenedOrderCountResponse> {
        return apiInterface.getOpenedOrderCount(langCode, userId, token)
    }

    // Get Order Receipt information
    fun getOrderReceipt(orderId: Int): Single<ReceiptResponse> {
        return apiInterface.getOrderReceipt(langCode, userId, token, orderId)
    }

    // Get Store Receipt Response
    fun getStoreReceipt(orderStoreId: Int): Single<StoreReceiptResponse> {
        return apiInterface.getStoreReceipt(
            langCode,
            userId,
            token,
            countryId,
            cityId,
            orderStoreId
        )
    }

    //Get Replacement suggestion list of order
    fun getReplacementSuggestionList(
        orderStoreId: Int,
        productSearch: String,
        orderItemId: Int,
        offset: Int,
        count: Int,
        isFromSearch: Int
    ): Single<ReplacementSuggestionResponse> {
        return apiInterface.getReplacementSuggestionList(
            langCode,
            userId,
            token,
            orderStoreId,
            productSearch,
            orderItemId,
            offset,
            count,
            isFromSearch
        )
    }

    //Get token of socket server
    fun getSocketToken(): Single<SocketTokenResponse> {
        return apiInterface.getSocketToken(langCode, userId, token)
    }

    // Get membership status of users
    fun getUserMembershipDetails(): Single<UserMembershipDetailResponse> {
        return apiInterface.getUserMembershipDetail(langCode, userId, token, countryId, cityId)
    }

    // Get membership list
    fun getMembershipList(): Single<MembershipListResponse> {
        return apiInterface.getMembershipList(langCode, countryId, token, cityId)
            .map { serverResponse: ServerResponse<MembershipListResponse>? -> serverResponse!!.response }
    }

    // Pay for membership
    fun checkoutExpress(
        cardId: Int,
        membershipId: Int,
        paymentGatewayId: Int
    ): Single<ExpressCheckoutResponse> {
        return apiInterface.checkoutExpress(
            langCode,
            userId,
            token,
            cardId,
            membershipId,
            paymentGatewayId,

            )
            .map { serverResponse: ServerResponse<ExpressCheckoutResponse>? -> serverResponse!!.response }
    }

    // Update payment method for membership
    fun updateMembershipPayment(cardId: Int): Single<SimpleResponse> {
        return apiInterface.updateMembershipPayment(
            langCode, userId,
            token, cardId
        ).map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    fun getMembershipPaymentHistory(): Single<MembershipPaymentHistoryResponse> {
        return apiInterface.getMembershipPaymentHistory(
            langCode, userId, token, countryId, cityId
        )
    }

    // Update customer membership plan
    fun updateMembershipPlan(planId: Int): Single<SimpleResponse> {
        return apiInterface.updateMembershipPlan(langCode, userId, token, planId)
            .map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    fun cancelMembership(cancelId: Int, cancelReasonTitle: String, cancelReasonComment: String): Single<SimpleResponse> {
        return apiInterface.cancelMembership(langCode, userId, token, cancelId, cancelReasonTitle, cancelReasonComment)
            .map { serverResponse: ServerResponse<SimpleResponse>? -> serverResponse!!.response }
    }

    // Get Address List
    fun getAddressList(): Single<AddressListResponse> {
        return apiInterface.getAddressList(langCode, userId, token, countryId, cityId)
            .map { serverResponse: ServerResponse<AddressListResponse>? -> serverResponse!!.response }
    }

    // Upload Chat attachment
    fun uploadChatAttachment(
        attachment: File,
        messageType: String,
        orderStoreId: Int,
        userType: String,
        userId: Long
    ): Single<jo.basket.data.model.chat.BaseResponse> {
        val requestFile: RequestBody =
            attachment.asRequestBody("multipart/form-data".toMediaTypeOrNull())
        // MultipartBody.Part is used to send also the actual file name
        val attachmentBody = MultipartBody.Part.createFormData("file", attachment.name, requestFile)
        val messageTypeBody: RequestBody =
            messageType.toRequestBody("text/plain".toMediaTypeOrNull())
        val orderStoreIdBody: RequestBody =
            orderStoreId.toString().toRequestBody("text/plain".toMediaTypeOrNull())
        val userTypeBody: RequestBody = userType.toRequestBody("text/plain".toMediaTypeOrNull())
        val userIdBody: RequestBody =
            userId.toString().toRequestBody("text/plain".toMediaTypeOrNull())

        return apiInterface.uploadChatAttachment(
            PreferenceManager.socketToken!!,
            attachmentBody,
            messageTypeBody,
            orderStoreIdBody,
            userTypeBody,
            userIdBody
        )
    }

    // Get All Active Firebase Token of current User
    fun getActiveDeviceTokenList(): Single<ActiveDeviceTokenResponse> {
        return apiInterface.getDeviceTokenList(langCode, userId, token, USER_TYPE)
    }

    // Get Wallet Transaction History
    fun getWalletTransactions(): Single<WalletHistoryResponse> {
        return apiInterface.getWalletTransactions(langCode, userId, token)
    }

    // Add or Edit Custom Product
    fun manageShoppingItems(
        storeId: Int,
        cartItemId: Int,
        quantity: Double, productName: String
    ): Single<AddCustomItemResponse> {
/*        val requestFile: RequestBody =
            attachment.asRequestBody("multipart/form-data".toMediaTypeOrNull())
        // MultipartBody.Part is used to send also the actual file name
        val attachmentBody = MultipartBody.Part.createFormData("custom_product_image", attachment.name, requestFile)

        val cartIemIdBody: RequestBody =
            cartItemId.toString().toRequestBody("text/plain".toMediaTypeOrNull())
        val quantityBody: RequestBody = quantity.toString().toRequestBody("text/plain".toMediaTypeOrNull())
        val productNameBody: RequestBody = productName.toRequestBody("text/plain".toMediaTypeOrNull())
        val noteBody: RequestBody = note.toRequestBody("text/plain".toMediaTypeOrNull())*/
        return apiInterface.manageShoppingItems(
            langCode,
            userId,
            token,
            countryId,
            cityId,
            cartItemId,
            storeId,
            quantity,
            "",
            productName
        )
    }

    // Get Custom Shopping Items List
    fun getCustomShoppingItemsList(
        storeId: Int
    ): Single<CustomItemListResponse> {
        return apiInterface.getCustomShoppingItemsList(langCode, userId, token, countryId, cityId, storeId)
    }

    fun getSplashADSList(
    ): Single<SplashADSResponse>{
        return apiInterface.getSplashADS(langCode, userId, token, if (PreferenceManager.currentUserId == 0L) 0 else countryId, cityId)
    }

    fun getLocalPayfortToken(
         deviceId: String
    ): Single<PayfortTokenResponse>{
        return apiInterface.getLocalPayfortToken(langCode, userId, token, countryId, cityId, deviceId)
    }

    fun updateMembershipRenewalSetting(
        reminder: Int
    ): Single<SimpleResponse> {
        return apiInterface.updateMembershipRenewalSetting(langCode, userId, token, reminder)
    }

    fun getUnreadBadgeCount() : Single<UnreadNotificationResponse>{
        return apiInterface.getUnreadBadgeCount(userId, token)
    }

    fun addCustomProductToExpress(productName: String) : Single<SimpleResponse>{
        return apiInterface.addCustomProductToExpress(userId, token, storeId, productName)
    }

    fun notifyForExpress() : Single<SimpleResponse>{
        return  apiInterface.notifyForExpress(langCode, userId, token)
    }

    fun deactivateAccount() : Single<SimpleResponse>{
        return  apiInterface.deactivateAccount(langCode, userId, token)
    }

    fun updateCartQty(
        storeId: Int,
        productId: Int,
        note: String?,
        amount: Double,
        cartDetailId: Int,
        customItemString: String,
        vendorId: Int
    ) :  Single<AddCartResponse>{
        return apiInterface.updateCartQty(langCode, userId, cartDetailId, countryId, cityId, token, note, storeId, productId,  if (amount < 0.0) 0.0 else amount, customItemString, vendorId)
            .map { serverResponse: ServerResponse<AddCartResponse>? -> serverResponse!!.response }
    }

    fun payTipForShopper(
        orderId: Int,
        orderStoreId: Int,
        cardId: Int,
        paymentGatewayId: Int,
        shopperTipAmount: Float,
    )  :  Single<SimpleResponse>{
        return apiInterface.payTipForShopper(langCode, userId, token, orderId, orderStoreId, cardId, paymentGatewayId, shopperTipAmount )
    }
}