package jo.basket.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector
import jo.basket.ui.profile.ChangePasswordFragment

@Module
abstract class FragmentProfileModule {

    @ContributesAndroidInjector
    abstract fun contributeChangePasswordFragment(): ChangePasswordFragment

}