package jo.basket

import android.Manifest
import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.LifecycleObserver
import androidx.multidex.MultiDex
import com.adjust.sdk.*
import com.app.basketiodriver.data.remote.FreshchatApiService
import com.appboy.Appboy
import com.appboy.AppboyLifecycleCallbackListener
import com.braze.configuration.BrazeConfig
import com.facebook.appevents.AppEventsLogger
import com.freshchat.consumer.sdk.Freshchat
import com.freshchat.consumer.sdk.FreshchatConfig
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseApp
import com.google.firebase.crashlytics.FirebaseCrashlytics
import com.google.firebase.messaging.FirebaseMessaging
import com.vanniktech.emoji.EmojiManager
import com.vanniktech.emoji.google.GoogleEmojiProvider
import dagger.android.AndroidInjector
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import io.github.inflationx.calligraphy3.CalligraphyConfig
import io.github.inflationx.calligraphy3.CalligraphyInterceptor
import io.github.inflationx.viewpump.ViewPump
import io.reactivex.android.schedulers.AndroidSchedulers
import io.realm.Realm
import io.realm.RealmConfiguration
import jo.basket.data.local.prefs.PreferenceManager
import jo.basket.data.remote.APIManager
import jo.basket.di.AppInjector
import jo.basket.ui.main.MainActivity
import jo.basket.utils.*
import jo.basket.utils.analytics.BasketAnalyticsManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import timber.log.Timber
import java.util.*
import javax.inject.Inject


// Basket App Class
class BasketApp : Application(), HasAndroidInjector, LifecycleObserver,
    Application.ActivityLifecycleCallbacks {

    private var activityReferences = 0
    private var isActivityChangingConfigurations = false

    private var mRunnable = Runnable { closeApp() }
    private val handler = Handler(Looper.getMainLooper())
    private var lastActivity: Activity? = null
    private var intent: Intent? = null
    private var isAppForeground = true

    @Inject
    lateinit var activityDispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    @Inject
    lateinit var mCalligraphyConfig: CalligraphyConfig

    override fun androidInjector(): AndroidInjector<Any> {
        return activityDispatchingAndroidInjector
    }

    override fun onCreate() {
        super.onCreate()
        FirebaseApp.initializeApp(this)
        initRealm()
        // Init Basket Custom Manager Classes
        initManagerClasses()

        // Set Realm Configuration
//        setRealmConfiguration()

        AppInjector.init(this)
        ViewPump.init(
            ViewPump.builder()
                .addInterceptor(CalligraphyInterceptor(mCalligraphyConfig))
                .build()
        )
        // Init Debug Options
        initDebugOptions()

        if (PreferenceManager.currentUserLanguageRaw == 0) {
            if (Locale.getDefault().displayLanguage == "العربية" ||
                Locale.getDefault().displayLanguage.equals("arabic", true)
            ) {
                PreferenceManager.currentUserLanguage = 3
            }
        }


        this.registerActivityLifecycleCallbacks(this)
        this.registerActivityLifecycleCallbacks(AppboyLifecycleCallbackListener())

        initBraze()

//        CoroutineScope(Dispatchers.IO).launch {
//            // Perform the WebView destruction operation here
//            WebStorage.getInstance().deleteAllData();
//
//
//        }


        FreshchatApiService.init(this)
        // check internet connectivity
        NetworkUtils.ConnectivityTask().execute()

        //Emoji install
        EmojiManager.install(GoogleEmojiProvider())
    }

    private fun initRealm(){
        Realm.init(this)

        val configuration =
            RealmConfiguration.Builder().allowWritesOnUiThread(true).
            allowQueriesOnUiThread(true)
                .schemaVersion(REALM_SCHEMA_VERSION)
                .deleteRealmIfMigrationNeeded()
                .name(AppConstants.DB_NAME)
                .build()
        Realm.setDefaultConfiguration(configuration)
    }
    private fun initManagerClasses() {
        AppLogger.init()
        APIManager.init(this)
        PreferenceManager.init(this)
        ResUtils.context = this


//        Realm.init(this)

        // Init Adjust SDK
        initAdjustSDK()

        initUxCam()
        AppEventsLogger.activateApp(this)
        BasketAnalyticsManager.init(this)

    }

    private fun initBraze() {
        val appboyConfig = BrazeConfig.Builder()
            .setIsFirebaseCloudMessagingRegistrationEnabled(true)
            .setAutomaticGeofenceRequestsEnabled(false).setHandlePushDeepLinksAutomatically(true)
            .setPushDeepLinkBackStackActivityEnabled(true)
            .setPushDeepLinkBackStackActivityClass(MainActivity::class.java)
            //  .setFirebaseCloudMessagingSenderIdKey(resources.getString(R.string.firebase_sender_id))
            .setFirebaseCloudMessagingSenderIdKey(BuildConfig.Firebase_sender_id)
            .build()

      //  AppboyLocationService.requestInitialization(this)
        Appboy.configure(this, appboyConfig)

        FirebaseMessaging.getInstance().token.addOnCompleteListener { task: Task<String?> ->
            if (task.isSuccessful) {
                val token = task.result
                Appboy.getInstance(applicationContext).registerAppboyPushMessages(token)
            }
        }

    }

    // Enable Debug only for 'Debug' build
    private fun initDebugOptions() {
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }
        if (!BuildConfig.DEBUG) {
            FirebaseCrashlytics.getInstance().setCrashlyticsCollectionEnabled(true)
        }

    }



    private fun setRealmConfiguration() {
        val configuration =
            RealmConfiguration.Builder().allowWritesOnUiThread(true).
            allowQueriesOnUiThread(true)
                .schemaVersion(REALM_SCHEMA_VERSION)
                .deleteRealmIfMigrationNeeded()
                .name(AppConstants.DB_NAME)
                .build()
        Realm.setDefaultConfiguration(configuration)
    }

    override fun attachBaseContext(base: Context) {
        MultiDex.install(this)
        super.attachBaseContext(base)
    }


    // Set Environment, Adjustment Tracking callback
    private fun initAdjustSDK() {
        if (NetworkUtils.isNetworkConnected(applicationContext)) {
            val environment = AdjustConfig.ENVIRONMENT_PRODUCTION
            val config = AdjustConfig(this, AppConstants.KEY_ADJUST_TOKEN, environment)

            config.setOnAttributionChangedListener { }


            config.setOnEventTrackingSucceededListener { eventSuccessResponseData: AdjustEventSuccess ->
                Timber.tag("AdjustmentMessage").v(
                    "%s%s",
                    eventSuccessResponseData.message,
                    eventSuccessResponseData.eventToken
                )
            }

            config.setOnEventTrackingFailedListener { eventFailureResponseData: AdjustEventFailure ->
                Timber.tag("AdjustmentMessage").v(
                    "%s%s",
                    eventFailureResponseData.message,
                    eventFailureResponseData.eventToken
                )
            }

            config.setOnSessionTrackingSucceededListener { sessionSuccessResponseData: AdjustSessionSuccess ->
                Timber.tag("AdjustmentMessage")
                    .v("%s%s", sessionSuccessResponseData.message, sessionSuccessResponseData.adid)
            }

            config.setOnSessionTrackingFailedListener { sessionFailureResponseData: AdjustSessionFailure ->
                Timber.tag("AdjustmentMessage")
                    .v("%s%s", sessionFailureResponseData.message, sessionFailureResponseData.adid)
            }
            Adjust.onCreate(config)
        }
    }

    private fun initUxCam() {
        //     UXCam.startWithKey(AppConstants.KEY_UXCAM_APP)
    }

    private fun closeApp() {
        lastActivity?.finishAffinity()
    }

    override fun onActivityPaused(activity: Activity) {
        Adjust.onPause()
    }

    override fun onActivityStarted(activity: Activity) {
        isAppForeground = true
        if (++activityReferences == 1 && !isActivityChangingConfigurations) {
            handler.removeCallbacks(mRunnable)
            EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_APP_IN_FOREGROUND))
        }
    }

    override fun onActivityDestroyed(activity: Activity) {
    }

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {
    }

    override fun onActivityStopped(activity: Activity) {
        isAppForeground = false
        isActivityChangingConfigurations = activity.isChangingConfigurations
        if (--activityReferences == 0 && !isActivityChangingConfigurations) {
            lastActivity = activity
            handler.postDelayed(mRunnable, 1800L * 1000)
            EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_APP_IN_BACKGROUND))
        }
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
    }

    override fun onActivityResumed(activity: Activity) {
        Adjust.onResume()
    }

    fun setIntent(mIntent: Intent) {
        intent = mIntent
    }

    override fun onTerminate() {
        if (intent != null) stopService(intent)
        super.onTerminate()
    }

    companion object {
        private val REALM_SCHEMA_VERSION: Long = 2

        private var instance: BasketApp? = null
         val Instance: BasketApp
            get() {
                if (instance == null) {
                    instance = BasketApp()
                }
                return instance!!
            }

        fun setIntent(intent: Intent) {
            Instance.setIntent(intent)
        }

        fun isAppForeground(): Boolean{
            return  Instance.isAppForeground
        }

    }
}
