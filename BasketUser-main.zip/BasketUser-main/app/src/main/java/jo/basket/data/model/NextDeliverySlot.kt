package jo.basket.data.model

import com.google.gson.annotations.SerializedName


open class NextDeliverySlot {

    @field:SerializedName("label")
    var label: String? = ""

    @field:SerializedName("slot")
    var slot: String? = ""

}