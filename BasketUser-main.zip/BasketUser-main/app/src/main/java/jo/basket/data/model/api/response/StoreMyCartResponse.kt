package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName


data class StoreMyCartResponse (

    @SerializedName("data"    ) var data    : ArrayList<Outlet> = arrayListOf(),
    @SerializedName("message" ) var message : String?         = null,
    @SerializedName("status"  ) var status  : Int?            = null

)

data class ProductImages (

    @SerializedName("product_image"      ) var productImage     : String? = null,
    @SerializedName("product_info_image" ) var productInfoImage : String? = null

)
data class Outlet (

    @SerializedName("outlet_id"      ) var outletId      : Int?                     = null,
    @SerializedName("outlet_name"    ) var outletName    : String?                  = null,
    @SerializedName("display_name"   ) var displayName   : String?                  = null,
    @SerializedName("vendor_id"      ) var vendorId      : Int?                     = null,
    @SerializedName("logo_image"     ) var logoImage     : String?                  = null,
    @SerializedName("product_images" ) var productImages : ArrayList<ProductImages> = arrayListOf()

)
