package jo.basket.ui.base.recyclerview

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import jo.basket.databinding.RecyclerItemLoaderBinding

class LoaderViewHolder(val binding: RecyclerItemLoaderBinding) :
    RecyclerView.ViewHolder(binding.root) {

    fun show() {
        binding.progressBar.visibility = View.VISIBLE
    }

    fun hide() {
        binding.progressBar.visibility = View.GONE
    }

}