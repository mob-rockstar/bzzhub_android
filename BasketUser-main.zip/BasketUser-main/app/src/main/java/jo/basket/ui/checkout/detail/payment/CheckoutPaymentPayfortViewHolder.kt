package jo.basket.ui.checkout.detail.payment

import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import jo.basket.data.model.payment.PaymentData
import jo.basket.databinding.RecyclerItemCheckoutPaymentPayfortBinding

class CheckoutPaymentPayfortViewHolder(val binding: RecyclerItemCheckoutPaymentPayfortBinding) :
    RecyclerView.ViewHolder(binding.root) {

    private var adapter: CheckoutPaymentPayfortAdapter? = null

    fun update(
        listener: CheckoutPaymentAdapterNew.OnSelectPaymentListener?,
        paymentData: PaymentData,
    ) {
        binding.executePendingBindings()
        val context = binding.root.context

        //    if (paymentData.isCreditCardEnable == 1){
        val childLayoutManager = LinearLayoutManager(context, RecyclerView.VERTICAL, false)
        binding.recyclerView.layoutManager = childLayoutManager
        binding.recyclerView.setHasFixedSize(true)
        binding.recyclerView.isNestedScrollingEnabled = false

        adapter =
            CheckoutPaymentPayfortAdapter(paymentData.id, listener, paymentData.isCreditCardEnable, paymentData.defaultStatus)
        adapter?.setItems(paymentData.cards)
        binding.recyclerView.adapter = adapter
        //    }
    }
}