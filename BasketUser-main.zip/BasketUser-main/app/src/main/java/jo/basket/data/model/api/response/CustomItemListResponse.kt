package jo.basket.data.model.api.response

import jo.basket.data.model.CustomProduct


data class CustomItemListResponse(
    var `data`: List<CustomProduct>,
    var message: String,
    var status: Int
)