package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.Profile

data class ProfileImageResponse(
    var data: Profile,
    var status: Int = 0,
    @SerializedName("Message")
    var message: String? = null
)