package jo.basket.data.model

import com.google.gson.annotations.SerializedName

class PreferredPayment {
    @field:SerializedName("card_number")
    var cardNumber: String? = null

    @field:SerializedName("card_label")
    var cardLabel: String? = null

    @field:SerializedName("payment_option")
    var paymentOption: String? = null
}