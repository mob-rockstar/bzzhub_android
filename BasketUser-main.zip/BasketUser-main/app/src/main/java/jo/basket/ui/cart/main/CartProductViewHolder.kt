package jo.basket.ui.cart.main

import  android.graphics.Paint
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.daimajia.swipe.SimpleSwipeListener
import com.daimajia.swipe.SwipeLayout
import jo.basket.R
import jo.basket.data.local.prefs.PreferenceManager
import jo.basket.data.model.Product
import jo.basket.databinding.RecyclerItemCartProductBinding
import jo.basket.utils.FormatterUtils
import jo.basket.utils.GlideApp
import jo.basket.utils.ProductInfoFormatter
import java.util.Locale


class CartProductViewHolder(
    val binding: RecyclerItemCartProductBinding,
    private val onOpenSwipeLayout: (layout: SwipeLayout?) -> Unit,
) : RecyclerView.ViewHolder(binding.root) {

    private var mListener: CartStoresAdapter.OnCartActionListener? = null
//    private var mListenerAll: AllCartStoresAdapter.OnAllCartActionListener? = null
    private var mProduct: Product? = null
    private var mAmount: Double? = null

    fun update(product: Product, isGridView: Int?, listener: CartStoresAdapter.OnCartActionListener?) {
        binding.executePendingBindings()
        val context = binding.root.context

        mProduct = product

        mListener = listener

        // Set Layout Swipe Mode
        binding.layoutSwipe.showMode = SwipeLayout.ShowMode.PullOut
        binding.layoutSwipe.isLeftSwipeEnabled = false
        binding.layoutSwipe.isRightSwipeEnabled = true
        binding.layoutSwipe.addSwipeListener(object : SimpleSwipeListener() {
            override fun onOpen(layout: SwipeLayout?) {
                onOpenSwipeLayout(layout)
            }
        })

        // Set Product Image
        if (product.productImage != null) {
            GlideApp.with(context).load(product.productImage).diskCacheStrategy(
                DiskCacheStrategy.ALL
            ).fitCenter()
                .error(R.drawable.placeholder300x300).format(
                    DecodeFormat.PREFER_ARGB_8888
                ).into(binding.ivProduct)
        }
        // Set Product name and count
        binding.tvCount.text = FormatterUtils.formatDouble(product.cartQty)

        //      binding.tvCount.visibility = if (product.statusAvailable == 1) VISIBLE else INVISIBLE
        //      binding.tvCount.isClickable = product.statusAvailable == 1
        //      binding.tvCount.isFocusable = product.statusAvailable == 1

        binding.tvProductName.text = product.name?.trim()

        // Set Product amount base on sold per value
//        if (product.soldPer == 3) {
//            binding.tvOriginalPrice.text =
//                FormatterUtils.formatHTMLString(
//                    FormatterUtils.formatPrice(product.cartQty!! * product.approxWeight!! * product.ourSellingPrice)
//                )
//        } else {
//            binding.tvOriginalPrice.text =
//                FormatterUtils.formatHTMLString(FormatterUtils.formatPrice(product.cartQty!! * product.ourSellingPrice))
//        }

        // If 'Note' is not empty, show Note
        binding.layoutNote.visibility =
            if (product.cartNotes.isNullOrEmpty()) GONE else VISIBLE

        binding.tvInstruction.text = if (product.cartNotes == null ||
            product.cartNotes!!.isEmpty()
        ) context.resources.getString(R.string.add_notes)
        else context.resources.getString(R.string.edit_notes)

        // Show out of stock value
        binding.layoutOutOfStock.visibility =
            if (product.statusAvailable == 1) GONE else VISIBLE
        val info = ProductInfoFormatter.getFormattedPrice(product)
        binding.layoutOption.visibility = if (product.statusAvailable == 1) VISIBLE else GONE
        if (product.promo_item == 1 && product.savingPerUnit != null && product.savingPerUnit!! > 0.0) {
            binding.tvOriginalPrice.apply {
                visibility = VISIBLE
                text = FormatterUtils.formatHTMLString(info.originalPrice!!)
                paintFlags = Paint.STRIKE_THRU_TEXT_FLAG or Paint.SUBPIXEL_TEXT_FLAG or Paint.ANTI_ALIAS_FLAG
            }
            binding.tvAmount.apply {
                text = FormatterUtils.formatHTMLString(info.price!!)
                setTextColor(ContextCompat.getColor(context, R.color.colorBlack))
            }

        }else{
            binding.tvOriginalPrice.visibility = GONE
            binding.tvAmount.apply {
                val pattern = Regex("each")
                text = FormatterUtils.formatHTMLString(info.price!!).replace(pattern,"")
                setTextColor(ContextCompat.getColor(context, R.color.colorBlack))
            }
        }
        // If Item is Promo Item
        if (product.promo_item == 1 && product.savingPerUnit != null && product.savingPerUnit!! > 0.0 && isGridView != 1) {
//            binding.tvOriginalPrice.visibility = View.VISIBLE
//            binding.tvOriginalPrice.text =
//                FormatterUtils.formatHTMLString(
//                    FormatterUtils.formatPrice(product.cartQty!! * product.approxWeight!! * (product.ourSellingPrice +(product.savingPerUnit ?: 0.0)))
//                )
//
//            // Set Amount text color red
//            binding.tvOriginalPrice.setTextColor(
//                ContextCompat.getColor(
//                    context,
//                    R.color.color_price_promo
//                )
//            )


//            if (product.soldPer == 3) {
//                binding.tvOriginalPrice.text =
//                    FormatterUtils.formatHTMLString(
//                        FormatterUtils.formatPrice(product.cartQty!! * product.approxWeight!! * (product.ourSellingPrice +(product.savingPerUnit ?: 0.0)))
//                    )
//            } else {
//                binding.tvOriginalPrice.text =
//                    FormatterUtils.formatHTMLString(FormatterUtils.formatPrice(product.cartQty!! * (product.ourSellingPrice +(product.savingPerUnit ?: 0.0))))
//            }

        }
        else {
            // If Not Promo Item
//            binding.tvOriginalPrice.visibility = View.GONE
//            if (product.soldPer == 3) {
//                binding.tvOriginalPrice.text =
//                    FormatterUtils.formatHTMLString(FormatterUtils.formatPrice(product.cartQty!! * product.approxWeight!! * product.originalPrice!!))
//            } else {
//                binding.tvOriginalPrice.text =
//                    FormatterUtils.formatHTMLString(FormatterUtils.formatPrice(product.cartQty!! * product.originalPrice!!))
//            }
        }

        binding.tvProductAmount.text =
            if (isGridView == 1) ""
            else {
                if (product.additionalQuestionAnswers != null && product.additionalQuestionAnswers != "") {
                    binding.tvProductAmount.maxLines = 2
                    product.additionalQuestionAnswers
                } else {
                    if (product.soldPer == 1)
                        context.resources.getString(
                            R.string.str_currency_format,
                            String.format(Locale.US, "%.2f", product.ourSellingPrice),
                            PreferenceManager.userCurrencyCode,
                            "~ (${product.labelValue?.trim()}${product.unit?.trim()})"
                        )
                    else
                        context.resources.getString(
                            R.string.str_at_currency_per_formatter,
                            String.format(Locale.US, "%.2f", product.ourSellingPrice),
                            PreferenceManager.userCurrencyCode,
                            product.unit?.trim()
                        )
                }
            }

        binding.tvUnitCount.text = if (product.soldPer == 2) product.unit?.trim() else ""

        binding.tvNote.text =
            FormatterUtils.formatHTMLString(
                """<span style='color:#43B02A'>
                |${context.resources.getString(R.string.instructions)} </span> ${product.cartNotes!!}""".trimMargin()
            )

        //  Tap instruction Layout
        binding.layoutInstruction.setOnClickListener { listener?.onSelectProductInstruction(product) }
        //  Tap 'Remove'
        binding.tvRemove.setOnClickListener { listener?.onRemoveProduct(product) }
        // Tap 'Delete' Layout
        binding.layoutDelete.setOnClickListener { listener?.onRemoveProduct(product) }
        // Tap Product itself
        binding.layoutMain.setOnClickListener { listener?.onSelectProduct(product) }

        initAmountPopup(product, listener)
    }

//    fun update(product: Product, isGridView: Int?, listener: AllCartStoresAdapter.OnAllCartActionListener?) {
//        binding.executePendingBindings()
//        val context = binding.root.context
//
//        mProduct = product
//
//        mListenerAll = listener
//
//        // Set Layout Swipe Mode
//        binding.layoutSwipe.showMode = SwipeLayout.ShowMode.PullOut
//        binding.layoutSwipe.isLeftSwipeEnabled = false
//        binding.layoutSwipe.isRightSwipeEnabled = true
//        binding.layoutSwipe.addSwipeListener(object : SimpleSwipeListener() {
//            override fun onOpen(layout: SwipeLayout?) {
//                onOpenSwipeLayout(layout)
//            }
//        })
//
//        // Set Product Image
//        if (product.productImage != null) {
//            GlideApp.with(context).load(product.productImage).diskCacheStrategy(
//                DiskCacheStrategy.ALL
//            ).fitCenter()
//                .error(R.drawable.placeholder300x300).format(
//                    DecodeFormat.PREFER_ARGB_8888
//                ).into(binding.ivProduct)
//        }
//        // Set Product name and count
//        binding.tvCount.text = FormatterUtils.formatDouble(product.cartQty)
//
//        //      binding.tvCount.visibility = if (product.statusAvailable == 1) VISIBLE else INVISIBLE
//        //      binding.tvCount.isClickable = product.statusAvailable == 1
//        //      binding.tvCount.isFocusable = product.statusAvailable == 1
//
//        binding.tvProductName.text = product.name?.trim()
//
//        // Set Product amount base on sold per value
//        if (product.soldPer == 3) {
//            binding.tvAmount.text =
//                FormatterUtils.formatHTMLString(
//                    FormatterUtils.formatPrice(product.cartQty!! * product.approxWeight!! * product.ourSellingPrice)
//                )
//        } else {
//            binding.tvAmount.text =
//                FormatterUtils.formatHTMLString(FormatterUtils.formatPrice(product.cartQty!! * product.ourSellingPrice))
//        }
//
//        // If 'Note' is not empty, show Note
//        binding.layoutNote.visibility =
//            if (product.cartNotes.isNullOrEmpty()) GONE else VISIBLE
//
//        binding.tvInstruction.text = if (product.cartNotes == null ||
//            product.cartNotes!!.isEmpty()
//        ) context.resources.getString(R.string.add_notes)
//        else context.resources.getString(R.string.edit_notes)
//
//        // Show out of stock value
//        binding.layoutOutOfStock.visibility =
//            if (product.statusAvailable == 1) GONE else VISIBLE
//
//        binding.layoutOption.visibility = if (product.statusAvailable == 1) VISIBLE else GONE
//
//        // If Item is Promo Item
//        if (product.promo_item == 1 && product.savingPerUnit != null && product.savingPerUnit!! > 0.0 && isGridView != 1) {
//            binding.tvOriginalPrice.paintFlags =
//                Paint.STRIKE_THRU_TEXT_FLAG or Paint.SUBPIXEL_TEXT_FLAG or Paint.ANTI_ALIAS_FLAG
//
//            // Set Amount text color red
//            binding.tvAmount.setTextColor(
//                ContextCompat.getColor(
//                    context,
//                    R.color.color_price_promo
//                )
//            )
//            binding.tvOriginalPrice.visibility = View.VISIBLE
//
//            if (product.soldPer == 3) {
//                binding.tvOriginalPrice.text =
//                    FormatterUtils.formatHTMLString(
//                        FormatterUtils.formatPrice(product.cartQty!! * product.approxWeight!! * (product.ourSellingPrice +(product.savingPerUnit ?: 0.0)))
//                    )
//            } else {
//                binding.tvOriginalPrice.text =
//                    FormatterUtils.formatHTMLString(FormatterUtils.formatPrice(product.cartQty!! * (product.ourSellingPrice +(product.savingPerUnit ?: 0.0))))
//            }
//
//        } else {
//            // If Not Promo Item
//            binding.tvOriginalPrice.visibility = View.GONE
//            if (product.soldPer == 3) {
//                binding.tvOriginalPrice.text =
//                    FormatterUtils.formatHTMLString(FormatterUtils.formatPrice(product.cartQty!! * product.approxWeight!! * product.originalPrice!!))
//            } else {
//                binding.tvOriginalPrice.text =
//                    FormatterUtils.formatHTMLString(FormatterUtils.formatPrice(product.cartQty!! * product.originalPrice!!))
//            }
//        }
//
//        binding.tvProductAmount.text =
//            if (isGridView == 1) ""
//            else {
//                if (product.additionalQuestionAnswers != null && product.additionalQuestionAnswers != "") {
//                    binding.tvProductAmount.maxLines = 2
//                    product.additionalQuestionAnswers
//                } else {
//                    if (product.soldPer == 1)
//                        context.resources.getString(
//                            R.string.str_currency_format,
//                            String.format(Locale.US, "%.2f", product.ourSellingPrice),
//                            PreferenceManager.userCurrencyCode,
//                            "~ (${product.labelValue?.trim()}${product.unit?.trim()})"
//                        )
//                    else
//                        context.resources.getString(
//                            R.string.str_at_currency_per_formatter,
//                            String.format(Locale.US, "%.2f", product.ourSellingPrice),
//                            PreferenceManager.userCurrencyCode,
//                            product.unit?.trim()
//                        )
//                }
//            }
//
//        binding.tvUnitCount.text = if (product.soldPer == 2) product.unit?.trim() else ""
//
//        binding.tvNote.text =
//            FormatterUtils.formatHTMLString(
//                """<span style='color:#43B02A'>
//                |${context.resources.getString(R.string.instructions)} </span> ${product.cartNotes!!}""".trimMargin()
//            )
//
//        //  Tap instruction Layout
//        binding.layoutInstruction.setOnClickListener { listener?.onSelectProductInstruction(product) }
//        //  Tap 'Remove'
//        binding.tvRemove.setOnClickListener { listener?.onRemoveProduct(product) }
//        // Tap 'Delete' Layout
//        binding.layoutDelete.setOnClickListener { listener?.onRemoveProduct(product) }
//        // Tap Product itself
//        binding.layoutMain.setOnClickListener { listener?.onSelectProduct(product) }
//
//    }

    private fun initAmountPopup(
        product: Product,
        listener: CartStoresAdapter.OnCartActionListener?,
    ) {
        val increment: Double
        var unit: String = ""

        if (product.soldPer == 2) {
            unit = product.unit ?: ""
            increment = when {
                unit.equals("g", true) -> {
                    50.0
                }
                product.allowGrams == 1 -> {
                    0.05
                }
                else -> {
                    0.25
                }
            }
        } else {
            increment = 1.0
        }

        binding.layoutIncrease.setOnClickListener {
            var amount =
                if (product.cartQty != null && product.cartQty!! > 0) product.cartQty!! else 0.0
            amount += increment
            listener?.onProductAmountChange(product, amount)
        }

        binding.layoutDecrease.setOnClickListener {
            var amount =
                if (product.cartQty != null && product.cartQty!! > 0) product.cartQty!! else 0.0
            amount -= increment
            listener?.onProductAmountChange(product, amount)
        }
        /*     binding.tvCount.setOnClickListener { v ->
                 if (product.statusAvailable == 1){
                     EditAmountPopup(
                         if (product.cartQty != null && product.cartQty!! > 0) product.cartQty!! else increment,
                         increment,
                         unit,
                         object : EditAmountPopup.OnDismissListener {
                             override fun onDismiss(amount: Double, isAmountPopupRunning: Boolean) {
                                 if (product.statusAvailable == 0) {
                                     Toast.makeText(
                                         binding.root.context,
                                         "Can't add out of stock product",
                                         Toast.LENGTH_SHORT
                                     ).show()
                                 } else if (product.cartQty != amount) {
                                     listener?.onProductAmountChange(product, amount)
                                 }
                             }
                         }
                     ).show(v)
                 }
             }*/
    }

}