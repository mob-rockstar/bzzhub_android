package jo.basket.mediapicker.Video;

public interface VideoPickerBuilderBase {

    VideoPicker.Builder mode(VideoPicker.Mode mode);

    VideoPicker.Builder directory(String directory);

    VideoPicker.Builder directory(VideoPicker.Directory directory);

    VideoPicker.Builder extension(VideoPicker.Extension extension);

    VideoPicker.Builder enableDebuggingMode(boolean debug);

    VideoPicker build();

}
