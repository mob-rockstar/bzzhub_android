package jo.basket.data.model



data class AppNews(val title: String, val description: String)