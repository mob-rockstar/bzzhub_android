package jo.basket.ui.checkout.detail

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.location.Location
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.telephony.TelephonyManager
import android.text.*
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import android.view.Window
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.adjust.sdk.Adjust
import com.bumptech.glide.Glide
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.i18n.phonenumbers.NumberParseException
import com.google.i18n.phonenumbers.PhoneNumberUtil
import com.google.i18n.phonenumbers.Phonenumber
import com.hbb20.CountryCodePicker
import com.huawei.secure.android.common.util.ScreenUtil
import com.payfort.fortpaymentsdk.FortSdk
import com.payfort.fortpaymentsdk.callbacks.FortCallBackManager
import com.payfort.fortpaymentsdk.domain.model.FortRequest
import jo.basket.R
import jo.basket.data.local.db.RealmManager
import jo.basket.data.local.prefs.PreferenceManager
import jo.basket.data.model.*
import jo.basket.data.model.api.response.*
import jo.basket.data.model.api.response.base.ErrorResponse
import jo.basket.data.model.payfort.TokenResponse
import jo.basket.data.model.payment.PaymentData
import jo.basket.databinding.FragmentCheckoutDetailBinding
import jo.basket.di.Injectable
import jo.basket.service.GPSTrackService
import jo.basket.ui.base.BaseInputFragment
import jo.basket.ui.base.HandleResponse
import jo.basket.ui.checkout.CheckoutActivity
import jo.basket.ui.checkout.CheckoutViewModel
import jo.basket.ui.checkout.detail.address.CheckoutAddressAdapter
import jo.basket.ui.checkout.detail.payment.CheckoutPaymentAdapterNew
import jo.basket.ui.checkout.detail.product.CheckoutCartStoreAdapter
import jo.basket.ui.checkout.detail.product.CheckoutHorizontalProductAdapter
import jo.basket.ui.checkout.detail.slot.CheckoutDeliveryTimeAdapter
import jo.basket.ui.checkout.detail.storetotal.StoreTotalAdapter
import jo.basket.ui.component.dialog.ShopperTipAmountDialog
import jo.basket.ui.component.dialog.promo.DialogPromo
import jo.basket.ui.component.dialog.verifyDialog.VerifyDialog
import jo.basket.ui.location.LocationActivity
import jo.basket.ui.login.fragment.LoginOtpFragment
import jo.basket.ui.main.MainActivity
import jo.basket.ui.product.ProductActivity
import jo.basket.utils.*
import jo.basket.utils.PopupUtils.setDefaultDialogProperty
import jo.basket.utils.analytics.BasketAnalyticsManager
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import timber.log.Timber
import java.util.*
import kotlin.collections.ArrayList


// Main Fragment of Checkout Detail Page
// Whole checkout information would be displayed in this page
class CheckoutDetailFragment :
    BaseInputFragment<FragmentCheckoutDetailBinding?, CheckoutViewModel>(),
    CheckoutAddressAdapter.OnAddressSelectedListener,
    CheckoutDeliveryTimeAdapter.OnChangeTimeSelectedListener,
    CheckoutPaymentAdapterNew.OnSelectPaymentListener,
    CheckoutHorizontalProductAdapter.OnHorizontalProductSelectedListener, Injectable {

    private val checkoutAddressAdapter: CheckoutAddressAdapter = CheckoutAddressAdapter()
    private val deliveryTimeAdapter: CheckoutDeliveryTimeAdapter = CheckoutDeliveryTimeAdapter()

    private var instruction: String = ""
    private var selectedAddress: Address? = null
    private var isValid: Boolean = false
    private var errorMessage = StringBuilder()
    private var userData: User? = null
    private var deliverySlot: StoreDeliverySlot? = null

    private var payfortEnvironmentMode = FortSdk.ENVIRONMENT.PRODUCTION
    private var payfortPaymentMode: Int = AppConstants.PAYFORT_MODE_PRODUCTION
    private var payfortDeviceId: String? = null
    private var fortCallback: FortCallBackManager? = null

    private var productList = ArrayList<Product>()
    private var productsAdapter = CheckoutHorizontalProductAdapter()
    private var isProductViewExpanded = false
    private var checkoutCartStoreAdapter = CheckoutCartStoreAdapter()
    private var isCheckoutPossible = true
    private var isPageLoadedFirst = true

    private var subtotalAdapter = StoreTotalAdapter()

    private var paymentData: List<PaymentData> = ArrayList()
    private var cartList: List<Cart> = ArrayList()

    private var checkoutPaymentAdapter = CheckoutPaymentAdapterNew()

    private var clickedShopperTipPosition = -1
    private var countryCodePicker: CountryCodePicker? = null
    private var countryCode = ""
    private var phoneUtil: PhoneNumberUtil? = null
    private var maxLength = 15
    private var isChangedTextByUser: Boolean = true
    val fArray = arrayOfNulls<InputFilter>(1)
    private var strMobile: String = ""
    private lateinit var userMap: GoogleMap
    var store: Store? = null

    override val layoutId: Int
        get() = R.layout.fragment_checkout_detail
    private var validPhoneNumber: Boolean = false
    override val viewModel: CheckoutViewModel
        get() {
            return getViewModel(baseActivity, CheckoutViewModel::class.java)
        }

    // prevent double tapping variables
    private var lastClickTime: Long = 0
    private var adjustADID = ""
    private var adjustGoogleId = ""
    private var adjustFireId = ""
    private var mapFragment: SupportMapFragment? = null
    private lateinit var gpsTracker: GPSTrackService
    private lateinit var edittext_instruction: EditText

    private var isFromCart = true

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        gpsTracker = GPSTrackService(baseActivity)
        userData = PreferenceManager.userData
        progressView = viewDataBinding?.progressBar
        // Init Payfort Parameters
        fortCallback = FortCallBackManager.Factory.create()

        initToolbar()
        initCountryCode()
        //initMobileInput()
        initMap()
        viewDataBinding?.tvPaymentType?.visibility = VISIBLE
        edittext_instruction = view.findViewById(R.id.edittext_instruction)
        initListeners()
        initRecyclerView()

        adjustADID = Adjust.getAdid() ?: ""
        Adjust.getGoogleAdId(
            baseActivity
        ) { googleAdId -> adjustGoogleId = googleAdId ?: "" }
        adjustFireId = Adjust.getAmazonAdId(baseActivity) ?: ""

        getCheckoutDetail()
        /*
                showDialogFragment(
                    WaitFoodOrderFragment(
                        0, 0
                    )
                )*/
//        Log.d("TAG", "mayank===>: "+viewModel.checkoutDetail?.secondaryMobile.toString())
//        Log.d("TAG", "mayank===>: "+viewModel.checkoutDetail?.cartId.toString())


        viewDataBinding?.submit?.setOnClickListener {
            KeyboardUtils.hideKeyboard(baseActivity)
            sendMobile()
//            viewModel.addSecondaryMobile()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppConstants.IS_CHECKOUT_RUNNING = true
        EventBus.getDefault().register(this)
    }

    private fun initMobileInput() {

        val editTextMobile = viewDataBinding?.edittextMobileNumber!!

        editTextMobile.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                // Reformat mobile number with spacings
                if (isChangedTextByUser) {
                    reformatMobileNumber(editTextMobile)
                    isChangedTextByUser = true

                    validateNextButton()

                    fArray[0] = InputFilter.LengthFilter(maxLength)
                    editTextMobile.filters = fArray
                }

            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }
        })

//        Handler(Looper.getMainLooper()).postDelayed({
//            editTextMobile.requestFocus()
//            KeyboardUtils.showKeyboard(baseActivity, editTextMobile)
//        }, 200)
    }

    private fun reformatMobileNumber(editTextMobile: EditText) {

        val phoneNumberUtil: PhoneNumberUtil = PhoneNumberUtil.getInstance()

        var phoneNumberPN: Phonenumber.PhoneNumber? = null

        try {
            phoneNumberPN = phoneNumberUtil.parse(countryCode +
                    editTextMobile.text.toString(), countryCodePicker?.selectedCountryNameCode!!)
            val phoneNumber = phoneNumberUtil.formatByPattern(
                phoneNumberPN,
                PhoneNumberUtil.PhoneNumberFormat.NATIONAL,
                FormatterUtils.mobileNumberFormatterList()
            )
            isChangedTextByUser = false
            editTextMobile.setText(phoneNumber)
            phoneNumber.replace("""[$, ]""".toRegex(), "").also { strMobile = it }

            val pos = editTextMobile.text!!.length
            editTextMobile.setSelection(pos)
        } catch (e: NumberParseException) {
            e.printStackTrace()
        }
    }

    private fun initCountryCode() {
        countryCodePicker = viewDataBinding?.countryPicker

        var countryNameCode =  (baseActivity.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager).simCountryIso
        if (countryNameCode == null || countryNameCode.isEmpty()){
            countryNameCode = Locale.getDefault().country
        }
        if (countryNameCode == null || countryNameCode.isEmpty()) countryNameCode = "JO"

        val phoneCode = CommonUtils.getPhoneCodeFromCountryNameCode(baseActivity, countryNameCode.uppercase())

        viewDataBinding?.countryPicker?.setCountryForPhoneCode(phoneCode.toInt())

        // User Changed Country Code
        countryCodePicker?.setOnCountryChangeListener {
            countryCode = countryCodePicker?.selectedCountryCodeWithPlus!!
            viewDataBinding?.iCountryFlag?.setImageResource(ImageUtils.getCountryFlag(
                countryCodePicker!!))
            validateNextButton()
        }

        // Set Default Country Code and Flag
        countryCode = countryCodePicker?.selectedCountryCodeWithPlus!!
        viewDataBinding?.iCountryFlag?.setImageResource(ImageUtils.getCountryFlag(countryCodePicker!!))

        //Once Selected Country Code Layout
        viewDataBinding?.layoutCountryCode?.setOnClickListener {
            countryCodePicker?.launchCountrySelectionDialog("JO")
        }
    }

    private fun sendMobile() {
        KeyboardUtils.hideKeyboard(baseActivity)
        if (validPhoneNumber) {
            viewModel.addSecondaryMobile(countryCode + strMobile,
                object : HandleResponse<AddSecondaryMobile> {
                    override fun handleErrorResponse(error: ErrorResponse?) {
                        if (NetworkUtils.isNetworkConnected(baseActivity) &&!(error?.message ?:"").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)) {
                            this@CheckoutDetailFragment.onError(
                                error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                            )
                        } else {
                            NetworkUtils.showNoInternetDialog(
                                baseActivity,
                                object : NetworkUtils.OnConnectedListener {
                                    override fun onConnected() {
                                        try {
                                            sendMobile()
                                        } catch (e1: Exception) {
                                            e1.printStackTrace()
                                        }
                                    }
                                })
                        }
                    }

                    override fun handleSuccessRespons(successResponse: AddSecondaryMobile) {
                        if (successResponse.status   == 200) {
                            // If success response from the server
//                            verifyMobile()
                            VerifyDialog.openDialog(baseActivity) { otpCode ->
//                                addPromoCode(promoCode)
                                verifyMobile(otpCode)
                            }
                            Toast.makeText(requireContext(), "Otp send successfully", Toast.LENGTH_SHORT).show()
                        } else {
                            this@CheckoutDetailFragment.onError(successResponse.message ?: AppConstants.DEFAULT_ERROR_MESSAGE)
                            return
                        }
                    }
                }
            )
        } else {
            viewDataBinding?.tvErrorMessage?.visibility = View.VISIBLE
        }
    }

    private fun verifyMobile(otpCode:String) {
        KeyboardUtils.hideKeyboard(baseActivity)
        viewModel.verifySecondaryMobile(countryCode + strMobile,otpCode, object : HandleResponse<VerifyMobileResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(baseActivity) && !(error?.message ?: "").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)) {
                    this@CheckoutDetailFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    NetworkUtils.showNoInternetDialog(baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    verifyMobile(otpCode)
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(response: VerifyMobileResponse) {
                if (response.code == 200) {
                    //Broadcast event 'Promo code added' so checkout detail information could be updated
                    Log.d("TAG", "verifySuccesssFully: ")
                    viewDataBinding?.edittextMobileNumber?.isEnabled = false
                    viewDataBinding?.mobileNumberText?.visibility = View.VISIBLE
                    viewDataBinding?.layoutMobile?.visibility = View.GONE
                    viewDataBinding?.mobileNumberText?.text = viewModel.checkoutDetail?.secondaryMobile.toString()
                    EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_PROMO_CODE_CHANGED))
                    VerifyDialog.dismissDialog()
                } else {
                    VerifyDialog.setErrorMessage(response.message ?: "")
                }
            }
        })
    }

    private fun validateNextButton() {
        maxLength = if (isValidFullNumber()) {
//            enableNextButton()
            validPhoneNumber = true
            viewDataBinding?.edittextMobileNumber?.text.toString().trim().length
        } else {
//            disableNextButton()
            15
        }

    }
    private fun enableNextButton() {
        validPhoneNumber = true
        viewDataBinding?.edittextMobileNumber?.text.toString().trim().length
        viewDataBinding?.submit?.isClickable = true
        viewDataBinding?.submit?.isEnabled = true
        viewDataBinding?.submit?.setTextColor(resources.getColor(R.color.unselected))
    }
    private fun disableNextButton() {
        validPhoneNumber = false
        viewDataBinding?.tvErrorMessage?.visibility = View.GONE
        viewDataBinding?.submit?.isClickable = false
        viewDataBinding?.submit?.isEnabled = false
       viewDataBinding?.submit?.setTextColor(resources.getColor(R.color.unselected))
    }

    private fun isValidFullNumber(): Boolean {
        return try {
            (countryCode.contains("962") &&
                    (((strMobile.startsWith("78") || (strMobile.startsWith("77") || (strMobile.startsWith(
                        "79")  || (strMobile.startsWith("73"))))) && strMobile.length == 9)
                            || ((strMobile.startsWith("078") || (strMobile.startsWith("077") || strMobile.startsWith(
                        "079"))) && strMobile.length == 10)))
                    ||
                    (getPhoneUtil() != null && getPhoneUtil()?.parse(countryCode + strMobile,
                        countryCodePicker?.selectedCountryNameCode ?: "") != null &&
                            (getPhoneUtil()?.isValidNumber(
                                getPhoneUtil()?.parse(countryCode + strMobile  + "",
                                    countryCodePicker?.selectedCountryNameCode ?: "")) ?: false))
        } catch (e: NumberParseException) { false }
    }

    private fun getPhoneUtil(): PhoneNumberUtil? {
        if (phoneUtil == null) {
            phoneUtil = PhoneNumberUtil.getInstance()
        }
        return phoneUtil
    }

    private fun initToolbar() {
        viewDataBinding?.toolbar?.ivBack?.setOnClickListener {
            EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_RELOAD_CART))
            finishActivity()
        }

        viewDataBinding?.toolbar?.tvTitle?.text =
            baseActivity.resources.getString(R.string.str_order_status_checkout)
    }

    // Override Listener from BasInputFragment
    override fun setupKeyboardHidingListener(view: View) {
        super.setupKeyboardHidingListener(view)
        // Set up touch listener for non-text box views to hide keyboard.

        view.setOnTouchListener { _, _ ->

            // If Tap outside of service fee, then hide ServiceFee Layout
            if (view.id != viewDataBinding?.ivServiceFee?.id) if (viewDataBinding?.layoutServiceFeeInfo?.visibility == VISIBLE) {
                viewDataBinding?.layoutServiceFeeInfo?.visibility = GONE
            }

            if (view.id != viewDataBinding?.ivDeliveryFee?.id) if (viewDataBinding?.layoutDeliveryFeeInfo?.visibility == VISIBLE) {
                viewDataBinding?.layoutDeliveryFeeInfo?.visibility = GONE
            }
            // If Tap outside of EditText - Hide Keyboard
            if (view !is EditText) {
                KeyboardUtils.hideKeyboard(baseActivity)
            }
            false
        }

        //If a layout container, iterate over children and seed recursion.
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                val innerView = view.getChildAt(i)
                setupKeyboardHidingListener(innerView)
            }
        }

        viewDataBinding?.edittextInstruction?.apply {
            setOnClickListener {
                viewDataBinding?.layoutContainer?.descendantFocusability =
                    ViewGroup.FOCUS_BEFORE_DESCENDANTS
                requestFocus()
            }
        }
    }

    private fun initListeners() {

        // If Service fee description dialog is visible - hide it, else- show it
        viewDataBinding?.ivServiceFee?.setOnClickListener {
            if (viewDataBinding?.layoutServiceFeeInfo?.visibility == VISIBLE) {
                viewDataBinding?.layoutServiceFeeInfo?.visibility = GONE
            } else {
                viewDataBinding?.layoutServiceFeeInfo?.visibility = VISIBLE
            }
        }

        viewDataBinding?.layoutTitleDeliveryInstruction?.setOnClickListener {
            //          onInstructionClicked()
        }

        /*        viewDataBinding?.tvContinueInstruction?.setOnClickListener {
                    onInstructionClicked()
                    //     onPaymentClicked()
                }*/

        viewDataBinding?.ivDeliveryFee?.setOnClickListener {
            if (viewDataBinding?.layoutDeliveryFeeInfo?.visibility == VISIBLE) {
                viewDataBinding?.layoutDeliveryFeeInfo?.visibility = GONE

            } else {
                viewDataBinding?.layoutDeliveryFeeInfo?.visibility = VISIBLE
            }
        }


        viewDataBinding?.ivDeletePromo?.setOnClickListener {
            // Remove applied promo code
            removePromoFromCart()
        }

        // 'Place Order' Button is clicked
        viewDataBinding?.btnPlaceOrder?.setOnClickListener {
            KeyboardUtils.hideKeyboard(baseActivity)
            if (SystemClock.elapsedRealtime() - lastClickTime > 1000) {
                lastClickTime = SystemClock.elapsedRealtime()

                (baseActivity as CheckoutActivity).addMapFragment({ placeOrder() },
                    { getCheckoutDetail(1) })
            }
        }
    }

    private fun placeOrder() {
        if (isValid) {

            instruction = viewDataBinding?.edittextInstruction?.text.toString().trim()
            // Payment Option is 'Cash On Delivery'
            if (checkoutPaymentAdapter.getDefaultPaymentType() == 2 && checkoutPaymentAdapter.getSelectedCardId() != 0) {  // Payment Option is CreditCard
                // Dialog to enter 'CVV'
                queryOnlinePayment("")
            } else {
                offlinePay()
            }
        } else {// If some of information missed (Delivery time or Address)
            if (errorMessage.isNotEmpty()) showMissingInfoDialog(errorMessage.toString())
        }
    }

    private fun isCreditCardOrder(): Boolean {
        return (checkoutPaymentAdapter.getDefaultPaymentType() == 2 && checkoutPaymentAdapter.getSelectedCardId() != 0 && checkoutPaymentAdapter.getSelectedPaymentID() != 0)
    }

    // Init RecyclerView Details
    private fun initRecyclerView() {
        viewDataBinding?.rvAddress?.setHasFixedSize(true)
        viewDataBinding?.rvAddress?.layoutManager =
            LinearLayoutManager(baseActivity, LinearLayoutManager.VERTICAL, false)
        checkoutAddressAdapter.addressSelectedListener = this@CheckoutDetailFragment
        viewDataBinding?.rvAddress?.adapter = checkoutAddressAdapter

        viewDataBinding?.recyclerViewSubtotal?.setHasFixedSize(true)
        viewDataBinding?.recyclerViewSubtotal?.layoutManager =
            LinearLayoutManager(baseActivity, LinearLayoutManager.VERTICAL, false)
        viewDataBinding?.recyclerViewSubtotal?.adapter = subtotalAdapter


        viewDataBinding?.rvDeliveryTime?.setHasFixedSize(true)
        deliveryTimeAdapter.setOnItemSelectListener(this@CheckoutDetailFragment)
        viewDataBinding?.rvDeliveryTime?.layoutManager =
            LinearLayoutManager(baseActivity, LinearLayoutManager.VERTICAL, false)
        viewDataBinding?.rvDeliveryTime?.adapter = deliveryTimeAdapter

        viewDataBinding?.rvPayment?.setHasFixedSize(true)
        viewDataBinding?.rvPayment?.layoutManager = LinearLayoutManager(
            baseActivity, LinearLayoutManager.VERTICAL, false
        )
        checkoutPaymentAdapter.listener = this@CheckoutDetailFragment
        viewDataBinding?.rvPayment?.adapter = checkoutPaymentAdapter

        initProductRecyclerView(isProductViewExpanded)
    }

    private fun initProductRecyclerView(isExpanded: Boolean) {
        viewDataBinding?.rvProduct?.setHasFixedSize(true)
        viewDataBinding?.rvProduct?.isNestedScrollingEnabled = false
        setProductRecyclerViewOrientation(isExpanded)
        viewDataBinding?.rvProduct?.adapter = productsAdapter
    }

    private fun setProductRecyclerViewOrientation(isExpanded: Boolean) {
        viewDataBinding?.rvProduct?.layoutManager = LinearLayoutManager(
            baseActivity,
            if (isExpanded) LinearLayoutManager.VERTICAL else LinearLayoutManager.HORIZONTAL,
            false
        )
    }

    private fun updateCheckoutUI(sectionToLoad: Int) {

        for (cart in viewModel.checkoutDetail?.carts!!) {
            if (cart.checkoutPermissionDetails == null || cart.checkoutPermissionDetails?.checkoutPermission!! != 1) {
                isCheckoutPossible = false
            }
        }

        if (sectionToLoad == 0) {
            checkHeavyOrder()
        }

        if (sectionToLoad == 0 || sectionToLoad == 1) {
            initAddressView()
        }

        if (sectionToLoad == 0 || sectionToLoad == 1 || sectionToLoad == 2) {
            if (sectionToLoad == 1 && isCheckoutPossible) {
                initTimeView(true)
            } else {
                initTimeView(isPageLoadedFirst)
            }
        }

        viewDataBinding?.rvDeliveryTime?.visibility = if (store?.isGridView == 1) GONE else VISIBLE

        if (sectionToLoad == 0 || sectionToLoad == 3) {
            paymentData = viewModel.checkoutDetail?.paymentList ?: ArrayList()
            updatePaymentUI()
            initPaymentView()
        }

        viewDataBinding?.layoutShopperTip?.visibility = if (isCreditCardOrder()) {
            initShopperTipLayout()
            VISIBLE
        } else GONE

        if (sectionToLoad == 0 || sectionToLoad == 4) {
            initProductView()
        } else {
            productList = ConverterUtils.getProductList(viewModel.checkoutDetail!!)
        }
//
//        Log.d("TAG", "updateCheckoutUI: "+cartList.get(0).displayName)
       // viewDataBinding?.tvProductCount?.text = baseActivity.resources.getString(R.string.str_items_decimal_format, productList.size)

        viewDataBinding?.tvProductCount?.text =  productList.size.toString() +" "+ baseActivity.resources.getString(R.string.str_items_decimal_format)

        subtotalAdapter.setItems(viewModel.checkoutDetail!!.carts)
        viewDataBinding?.tvCharges?.text =
            if (viewModel.checkoutDetail!!.overallDeliveryTotal != 0.0) formatPrice(viewModel.checkoutDetail!!.overallDeliveryTotal)
            else ResUtils.getString(R.string.str_free)
        viewDataBinding?.tvServiceFee?.text =
            if (viewModel.checkoutDetail!!.overallServiceFee != 0.0) formatPrice(viewModel.checkoutDetail!!.overallServiceFee)
            else ResUtils.getString(R.string.str_free)
        viewDataBinding?.tvDeliveryDiscount?.text =
            formatPrice(viewModel.checkoutDetail!!.overallFreeDeliveryDiscount)
        if (viewModel.checkoutDetail?.savingMessages != null) {
            if (viewModel.checkoutDetail?.savingMessages?.title != null) {
                viewDataBinding?.tvDeliveryTitle?.text =
                    viewModel.checkoutDetail?.savingMessages?.title
            }
            viewDataBinding?.tvDeliveryDiscount?.text =
                formatPrice(viewModel.checkoutDetail!!.savingMessages!!.amount!!)
        }

        viewDataBinding?.layoutDeliveryDiscount?.visibility =
            if (viewModel.checkoutDetail?.overallFreeDeliveryDiscount != 0.0) VISIBLE else GONE

        val cartList = viewModel.checkoutDetail!!.carts
        Log.d("TAG", "updateCheckoutUI: "+cartList.get(0).displayName)
        viewDataBinding?.tvStoreName?.setText(cartList.get(0).displayName)
        val incentiveDiscount = if (cartList.isNotEmpty()) {
            cartList.first().incentivizing_discount
        } else 0.0

        if (viewModel.checkoutDetail!!.overallMembershipDiscount == 0.0 && incentiveDiscount == 0.0) {
            viewDataBinding?.tvTitleMembershipDiscount?.visibility = GONE
            viewDataBinding?.tvMembershipDiscount?.visibility = GONE
        } else {
            viewDataBinding?.tvTitleMembershipDiscount?.visibility = VISIBLE
            viewDataBinding?.tvMembershipDiscount?.visibility = VISIBLE

            viewDataBinding?.tvMembershipDiscount?.text = formatPrice(
                if (viewModel.checkoutDetail!!.overallMembershipDiscount != 0.0) (viewModel.checkoutDetail!!.overallMembershipDiscount + viewModel.checkoutDetail!!.overallServiceFeeDiscount)
                else incentiveDiscount
            )
        }

        resetTotal()

        viewDataBinding?.tvTaxPercent?.visibility =
            if (viewModel.checkoutDetail?.carts != null && viewModel.checkoutDetail?.carts!!.isNotEmpty()) {
                if (viewModel.checkoutDetail?.carts!![0].outletIncludedTaxAmount != 0.0) {
                    viewDataBinding?.tvTaxPercent?.text =
                        "${baseActivity.resources.getString(R.string.str_tax_included_percentage)} ${PreferenceManager.userCurrencyCode}${viewModel.checkoutDetail?.carts!![0].outletIncludedTaxAmount.toString()})"
                    VISIBLE
                } else {
                    GONE
                }
            } else GONE

        // promo
        viewDataBinding?.layoutPromo?.visibility =
            if (viewModel.checkoutDetail?.mPromoDetails != null) View.VISIBLE else View.GONE
        if (viewModel.checkoutDetail?.mPromoDetails != null) {
            viewDataBinding?.tvPromoDiscount?.text =
                """-${formatPrice(viewModel.checkoutDetail?.overall_promo_delivery_discount)}"""
            if (viewModel.checkoutDetail?.overall_promo_delivery_discount != null && viewModel.checkoutDetail?.overall_promo_delivery_discount!! > 0.0) {
                BasketAnalyticsManager.promoCodeApplied(
                    viewModel.checkoutDetail?.mPromoDetails?.promoCode ?: "",
                    viewModel.checkoutDetail?.overall_promo_delivery_discount!!
                )
            }
            viewDataBinding?.tvPromoCode?.text = viewModel.checkoutDetail?.mPromoDetails?.promoCode
        }

        viewDataBinding?.tvCartMassage?.text = viewModel.checkoutDetail?.message
        viewDataBinding?.tvPromo?.setOnClickListener {
            if (SystemClock.elapsedRealtime() - lastClickTime > 1000) {
                lastClickTime = SystemClock.elapsedRealtime()
                DialogPromo.openDialog(baseActivity) { promoCode ->
                    addPromoCode(promoCode)
                }
            }
        }

        if (viewModel.checkoutDetail?.deliveryInfoDetails != null && viewModel.checkoutDetail?.deliveryInfoDetails?.size == 3) {
            val deliveryInfoDetail = viewModel.checkoutDetail?.deliveryInfoDetails

            """${deliveryInfoDetail?.first()?.currency} ${viewModel.checkoutDetail?.overallDeliveryTotal}""".also {
                viewDataBinding?.deliveryFeeInfo?.tvBasicDeliveryFee?.text = it
            }
            """${deliveryInfoDetail?.first()?.currency} ${viewModel.checkoutDetail?.overallServiceFee}""".also {
                viewDataBinding?.deliveryFeeInfo?.tvOrderTotalThresholder?.text = it
            }
            """${deliveryInfoDetail?.last()?.currency} ${viewModel.checkoutDetail?.overallIncludedTaxAmount}""".also {
                viewDataBinding?.deliveryFeeInfo?.tvOneHrDeliveryFee?.text = it
            }
            """${deliveryInfoDetail?.last()?.currency} ${viewModel.checkoutDetail?.overallFreeDeliveryDiscount}""".also {
                viewDataBinding?.deliveryFeeInfo?.tvDiscount?.text = it
            }
        }
        refreshCreditCardWarningPopup(checkoutPaymentAdapter.getSelectedCardId() ?: 0)
        initWalletOption()
        checkValidation()

        with(viewDataBinding?.layoutShopperMobile!!) {
            layoutSelectMobileNumber.setOnClickListener {
                onMobileLayoutClicked()
            }

            tvContinue.setOnClickListener {
                onMobileLayoutClicked()
            }
        }
    }

    private fun resetTotal(){
        viewDataBinding?.tvTotal?.text =
            formatPrice((viewModel.checkoutDetail!!.overallTotal ?: 0.0) + getShopperTipValue())
    }

    private fun initShopperTipLayout() {

        viewDataBinding?.shopperTip!!.apply {
            Glide.with(baseActivity).asGif().load(R.raw.icon_shopper_tip)
                .into(ivShopperTip)

            ivInfo.setOnClickListener {
                PopupUtils.showShopperTipInstruction(baseActivity)
            }

            tvOptionZero.text = if (store?.express == 1) "0.25" else "None"

            tvOptionZero.setOnClickListener {
                KeyboardUtils.hideKeyboard(baseActivity)
                if (clickedShopperTipPosition == 0) {
                    clickedShopperTipPosition = -1
                    tvOptionZero.background = ContextCompat.getDrawable(
                        baseActivity,
                        R.drawable.bg_round_light_grey_10
                    )
                } else {
                    clickedShopperTipPosition = 0
                    tvOptionZero.background = ContextCompat.getDrawable(
                        baseActivity,
                        R.drawable.bg_round_light_grey_green_outline_10
                    )
                    tvOptionOne.background =
                        ContextCompat.getDrawable(baseActivity, R.drawable.bg_round_light_grey_10)
                    tvOptionTwo.background =
                        ContextCompat.getDrawable(baseActivity, R.drawable.bg_round_light_grey_10)
                }
                resetTotal()
            }

            tvOptionOne.setOnClickListener {
                KeyboardUtils.hideKeyboard(baseActivity)
                if (clickedShopperTipPosition == 1) {
                    clickedShopperTipPosition = -1
                    tvOptionOne.background = ContextCompat.getDrawable(
                        baseActivity,
                        R.drawable.bg_round_light_grey_10
                    )
                } else {
                    clickedShopperTipPosition = 1
                    tvOptionOne.background = ContextCompat.getDrawable(
                        baseActivity,
                        R.drawable.bg_round_light_grey_green_outline_10
                    )
                    tvOptionZero.background =
                        ContextCompat.getDrawable(baseActivity, R.drawable.bg_round_light_grey_10)
                    tvOptionTwo.background =
                        ContextCompat.getDrawable(baseActivity, R.drawable.bg_round_light_grey_10)
                }
                resetTotal()
            }

            tvOptionTwo.setOnClickListener {
                KeyboardUtils.hideKeyboard(baseActivity)
                if (clickedShopperTipPosition == 2) {
                    clickedShopperTipPosition = -1
                    tvOptionTwo.background = ContextCompat.getDrawable(
                        baseActivity,
                        R.drawable.bg_round_light_grey_10
                    )
                } else {
                    clickedShopperTipPosition = 2
                    tvOptionTwo.background = ContextCompat.getDrawable(
                        baseActivity,
                        R.drawable.bg_round_light_grey_green_outline_10
                    )
                    tvOptionOne.background =
                        ContextCompat.getDrawable(baseActivity, R.drawable.bg_round_light_grey_10)
                    tvOptionZero.background =
                        ContextCompat.getDrawable(baseActivity, R.drawable.bg_round_light_grey_10)
                }

                resetTotal()
            }

            tvOptionManual.setOnClickListener {
                clickedShopperTipPosition = 3
                tvOptionManual.background = ContextCompat.getDrawable(
                    baseActivity,
                    R.drawable.bg_round_light_grey_green_outline_10
                )
                tvOptionTwo.background = ContextCompat.getDrawable(
                    baseActivity,
                    R.drawable.bg_round_light_grey_10
                )
                tvOptionOne.background =
                    ContextCompat.getDrawable(baseActivity, R.drawable.bg_round_light_grey_10)
                tvOptionZero.background =
                    ContextCompat.getDrawable(baseActivity, R.drawable.bg_round_light_grey_10)
                ShopperTipAmountDialog.openDialog(baseActivity) { amount ->
                    tvOptionManual.setText(amount.toString())
                    resetTotal()
                }
            }

            tvConfirm.visibility = GONE
        }
    }

    private fun getShopperTipValue(): Float {
        return when (clickedShopperTipPosition) {
            -1 -> 0.0f
            0 -> if (store?.express == 1) 0.25f else 0.0f
            1 -> 0.5f
            2 -> 0.75f
            3 -> viewDataBinding?.shopperTip?.tvOptionManual?.text.toString().trim().toFloatOrNull() ?: 0.0f
            else -> 0.0f
        }
    }

    private fun checkHeavyOrder() {
        if (viewModel.checkoutDetail?.isHeavyOrder == 1) {
            PopupUtils.showCustomizedAlert(
                baseActivity,
                true,
                baseActivity.resources.getString(R.string.str_heavy_item_content),
                baseActivity.resources.getString(R.string.str_continue)
            ) {

            }
        }
    }

    private fun onMobileLayoutClicked() {
        with(viewDataBinding?.layoutShopperMobile!!) {
            layoutShopperMobileDetail.visibility =
                if (layoutShopperMobileDetail.visibility == VISIBLE) {
                    GONE
                } else VISIBLE
            ivDropDownShopperMobile.rotation =
                if (layoutShopperMobileDetail.visibility == VISIBLE) {
                    180.0f
                } else 0.0f
        }
    }

    private fun initAddressView() {

        viewDataBinding?.layoutSelectAddress?.setOnClickListener {
            if (viewDataBinding?.layoutAddress?.visibility == VISIBLE) {
                initAddressText()
                hideAddressList()
                viewDataBinding?.tvEditAddress?.visibility = VISIBLE
            } else {
                viewDataBinding?.layoutAddress?.visibility = VISIBLE
                viewDataBinding?.tvFarFromLocation?.visibility = GONE
                setEmptyAddressText()
                initTimeView(false)
                hideContentInstruction()
                //     hidePaymentList()
                isProductViewExpanded = true
                resetProductRecyclerView()
                viewDataBinding?.tvEditAddress?.visibility = GONE
            }
        }

        initAddressText()

        initMarker()


        viewDataBinding?.tvAddAddress?.setOnClickListener {
            startActivity(
                LocationActivity.newIntent(
                    baseActivity, AppConstants.LOCATION_MODE_ADD_ADDRESS_SIDE_MENU, true
                )
            )
        }

        val contentAddress = viewModel.checkoutDetail?.addressList!! as ArrayList
        contentAddress.sortWith(compareBy<Address> { 1 - (it.available ?: 0) })

        checkoutAddressAdapter.setItems(contentAddress)
    }

    private fun hideAddressList() {
        viewDataBinding?.layoutAddress?.visibility = GONE
    }


    private fun hideContentInstruction() {
        viewDataBinding?.layoutContentInstruction?.visibility = GONE

    }

    private fun initAddressText() {
        // address
        if (viewModel.checkoutDetail?.getUserSelectedAddress() == null) {
            setEmptyAddressText()
        } else {
            fillAddressDetails()
        }
    }

    private fun setEmptyAddressText() {
        viewDataBinding?.ivAddress?.setImageDrawable(
            ContextCompat.getDrawable(
                baseActivity, ImageUtils.getBitmapFromAddressType(
                    0, 0
                )
            )
        )
        viewDataBinding?.tvAddressType?.setText(R.string.choose_address)
        viewDataBinding?.tvAddress?.visibility = GONE
        viewDataBinding?.tvEditAddress?.text = baseActivity.resources.getString(R.string.str_add)

        viewDataBinding?.layoutAddress?.visibility = VISIBLE
    }

    private fun fillAddressDetails() {
        viewDataBinding?.ivAddress?.setImageDrawable(
            ContextCompat.getDrawable(
                baseActivity, ImageUtils.getBitmapFromAddressType(
                    viewModel.checkoutDetail?.getUserSelectedAddress()?.addressTypeId ?: 0, 1
                )
            )
        )
        viewDataBinding?.tvAddress?.visibility = VISIBLE
        viewDataBinding?.tvAddressType?.text =
            viewModel.checkoutDetail?.getUserSelectedAddress()?.addressType
        viewDataBinding?.tvAddress?.text =
            viewModel.checkoutDetail?.getUserSelectedAddress()?.address
        viewDataBinding?.tvEditAddress?.text = baseActivity.resources.getString(R.string.change)

        viewDataBinding?.layoutAddress?.visibility = GONE
        calculateDistance(viewModel.checkoutDetail?.getUserSelectedAddress()!!)
    }

    private fun calculateDistance(address: UserSelectedAddress) {
        val locationA = Location("point A")

        locationA.latitude = address.latitude ?: 0.0
        locationA.longitude = address.longtitude ?: 0.0

        val locationB = Location("point B")
        locationB.latitude = gpsTracker.latitude ?: 0.0
        locationB.longitude = gpsTracker.longitude ?: 0.0

        val distance = locationA.distanceTo(locationB)
        viewDataBinding?.tvFarFromLocation?.visibility =
            if (locationB.latitude != 0.0 && locationB.longitude != 0.0 && distance > 1000) {
                VISIBLE
            } else GONE
    }

    private fun initTimeView(expandView: Boolean = false) {
        // payment
        viewDataBinding?.tvPaymentType?.text = checkoutPaymentAdapter.getSelectedPaymentName()
            .ifEmpty { baseActivity.resources.getString(R.string.str_choose_payment_method) }

        viewDataBinding?.ivPayment?.setImageDrawable(
            ContextCompat.getDrawable(
                baseActivity,
                if (checkoutPaymentAdapter.getSelectedCardId() == 0) R.drawable.ic_cash_on_delivery else R.drawable.ic_payment_method_checkout
            )
        )

        viewDataBinding?.layoutSelectPayment?.setOnClickListener {
            onPaymentClicked()
        }

        viewDataBinding?.ivDropDownPayment?.setOnClickListener {
            onPaymentClicked()
        }

        deliveryTimeAdapter.setItems(viewModel.checkoutDetail?.carts ?: ArrayList<Cart>())
        if (expandView) deliveryTimeAdapter.setSelection(0)
    }

    private fun initPaymentView() {
    }

    private fun initProductView() {

        productList = ConverterUtils.getProductList(viewModel.checkoutDetail!!)
        if (isProductViewExpanded) {
            checkoutCartStoreAdapter.setItems(viewModel.checkoutDetail?.carts!!)
            viewDataBinding?.rvProduct?.visibility = GONE
            viewDataBinding?.rvProduct?.adapter = checkoutCartStoreAdapter
            viewDataBinding?.rvProduct?.visibility = VISIBLE
            setProductRecyclerViewOrientation(isProductViewExpanded)
        } else {
            productsAdapter.setItems(productList)
        }

        productsAdapter.listener = this
        viewDataBinding?.layoutProduct?.setOnClickListener {
            resetProductRecyclerView()
        }

        viewDataBinding?.rvProduct?.setOnClickListener {
            resetProductRecyclerView()
        }
    }

    private fun updateProductList(product: Product) {
        if (cartList.isNotEmpty()) {

            for (i in cartList.indices) {
                for (j in cartList[i].products!!.indices) {

                    if (cartList[i].products!![j].productId == product.productId) {
                        (cartList[i].products!! as ArrayList)[j] = product
                    }
                }
            }
        }

        checkoutCartStoreAdapter.setItems(cartList)
    }

    private fun resetProductRecyclerView() {
        if (isProductViewExpanded) {

            viewDataBinding?.ivDropDownProduct?.setImageDrawable(
                ContextCompat.getDrawable(
                    baseActivity, R.drawable.ic_arrow_down
                )
            )
            productList = ConverterUtils.getProductList(viewModel.checkoutDetail!!)
            productsAdapter.setItems(productList)
            viewDataBinding?.rvProduct?.visibility = GONE
            viewDataBinding?.rvProduct?.adapter = productsAdapter
            viewDataBinding?.rvProduct?.visibility = VISIBLE
        } else {

            viewDataBinding?.ivDropDownProduct?.setImageDrawable(
                ContextCompat.getDrawable(
                    baseActivity, R.drawable.ic_close_black_24dp
                )
            )
            cartList = viewModel.checkoutDetail?.carts!!
            checkoutCartStoreAdapter.setItems(cartList)
            viewDataBinding?.rvProduct?.visibility = GONE
            viewDataBinding?.rvProduct?.adapter = checkoutCartStoreAdapter
            viewDataBinding?.rvProduct?.visibility = VISIBLE

            initTimeView(false)
            //     hidePaymentList()
            hideAddressList()
            hideContentInstruction()

            checkoutCartStoreAdapter.setOnCartActionListener(object :
                CheckoutCartStoreAdapter.OnCartActionListener {

                // User tapped 'Instruction' for Product
                override fun onSelectProductInstruction(product: Product) {
                    if (SystemClock.elapsedRealtime() - lastClickTime > 1000) {
                        lastClickTime = SystemClock.elapsedRealtime()
                        val intent = ProductActivity.newIntent(context, product, 0, true)
                        startActivity(intent)

                    }
                }

                // User tapped 'Amount' view
                override fun onProductAmountChange(product: Product, amount: Double) {
                    if (store?.isGridView == 1) {
                        updateCart(product, amount)
                    } else {
                        addToCart(product, amount)
                    }
                }

                // User Tapped 'Remove' view for Product
                override fun onRemoveProduct(product: Product) {
                    if (SystemClock.elapsedRealtime() - lastClickTime > 1000) {
                        lastClickTime = SystemClock.elapsedRealtime()
                        removeProductFromCart(product)
                    }
                }

                override fun onSelectProduct(product: Product) {
                    if (SystemClock.elapsedRealtime() - lastClickTime > 1000) {
                        lastClickTime = SystemClock.elapsedRealtime()
                        if (store?.isGridView != 1) {
                            val intent = ProductActivity.newIntent(baseActivity, product)
                            startActivity(intent)
                        }
                    }
                }
            })
        }
        isProductViewExpanded = !isProductViewExpanded
        setProductRecyclerViewOrientation(isProductViewExpanded)
    }

    // Check validation of 'Checkout' button with  selected checkout data
    private fun checkValidation() {
        isValid = true

        if (checkoutPaymentAdapter.getSelectedPaymentID() == 0) {
            isValid = false
            errorMessage.clear()
            errorMessage.append(resources.getString(R.string.str_choose_payment_method))
        }

        if (viewModel.checkoutDetail?.getUserSelectedAddress() == null) {
            errorMessage.clear()
            isValid = false
            errorMessage.append(resources.getString(R.string.err_address))
        } else {
            for (cart in viewModel.checkoutDetail!!.carts) {
                if (cart.deliveryTime.isNullOrEmpty()) {
                    errorMessage.clear()
                    isValid = false
                    errorMessage.append(resources.getString(R.string.choose_delivery_time))
                }
            }
        }

        for (cart in viewModel.checkoutDetail?.carts!!) {
            if (cart.checkoutPermissionDetails == null || cart.checkoutPermissionDetails?.checkoutPermission!! != 1) {
                isValid = false
            }
        }

        viewDataBinding?.btnPlaceOrder?.background = ContextCompat.getDrawable(
            baseActivity,
            if (isValid) R.drawable.bg_round_green_16dp else R.drawable.bg_round_grey_200_16dp
        )
    }

    private fun formatPrice(price: Double?): Spanned? { //Formatting Price
        val priceString = String.format(Locale.US, "%.2f", price ?: 0.0)
        return FormatterUtils.formatHTMLString("$priceString ${PreferenceManager.userCurrencyCode}")
    }

    // Show missing information (missing address or missing delivery slot)
    private fun showMissingInfoDialog(content: String) {
        val dialog = Dialog(baseActivity)

        val view = LayoutInflater.from(context).inflate(R.layout.dialog_checkout_missing, null)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(view)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        view.findViewById<TextView>(R.id.tv_content).text = content
        view.findViewById<TextView>(R.id.tv_ok).setOnClickListener { dialog.dismiss() }

        setDefaultDialogProperty(dialog)
        dialog.show()
    }


    // Update Checkout Delivery Slot
    private fun updateDeliverySlot(cart: Cart, time: DeliveryTime) {
        viewModel.updateDeliverySlot(cart.storeId,
            time.deliveryDate!!,
            time.id,
            time.deliveryTime!!,
            object : HandleResponse<SimpleResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (NetworkUtils.isNetworkConnected(baseActivity) && !(error?.message
                            ?: "").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)
                    ) {
                        this@CheckoutDetailFragment.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        NetworkUtils.showNoInternetDialog(baseActivity,
                            object : NetworkUtils.OnConnectedListener {
                                override fun onConnected() {
                                    try {
                                        updateDeliverySlot(cart, time)
                                    } catch (e1: Exception) {
                                        e1.printStackTrace()
                                    }
                                }
                            })
                    }
                }

                override fun handleSuccessRespons(successResponse: SimpleResponse) {
                    getCheckoutDetail(2)  // Reload only Delivery Slot view
                }
            })
    }

    // Update Checkout Delivery Address
    private fun updateDeliveryAddress(addressId: Int) {
        showLoading()
        viewModel.updateDeliveryAddress(addressId, object : HandleResponse<SimpleResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                hideLoading()
                if (NetworkUtils.isNetworkConnected(baseActivity) && !(error?.message
                        ?: "").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)
                ) {
                    this@CheckoutDetailFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    NetworkUtils.showNoInternetDialog(baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    updateDeliveryAddress(addressId)
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(successResponse: SimpleResponse) {
                hideLoading()
                getCheckoutDetail(1)  // Reload only AddressView
                viewDataBinding?.layoutAddress?.visibility = GONE
                //       viewDataBinding?.tvEditAddress?.visibility = GONE
            }
        })
    }

    private fun gotoOrderList() {
        val intent = MainActivity.newIntent(activity, 3)
        startActivity(intent)
        //Send Event broadcast to finish existing activities
        EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_RESTART))
    }

    // Get user checkout detail information
    private fun getCheckoutDetail(sectionToLoad: Int = 0) {
        viewModel.getCheckoutDetail(isFromCart,viewModel.checkoutDetail?.cartId.toString(), object : HandleResponse<CheckoutResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(baseActivity) && !(error?.message
                        ?: "").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)
                ) {
                    this@CheckoutDetailFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    NetworkUtils.showNoInternetDialog(baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    getCheckoutDetail()
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(successResponse: CheckoutResponse) {
                isFromCart = false
                viewDataBinding?.layoutFirstLoad?.visibility = GONE
                if (successResponse.code == 200) {
                    viewModel.checkoutDetail = successResponse
                    Log.d("TAG", "mayank===>: "+viewModel.checkoutDetail?.secondaryMobile.toString())
                    Log.d("TAG", "mayank===>: "+viewModel.checkoutDetail?.cartId.toString())
                    if(!viewModel.checkoutDetail?.secondaryMobile.isNullOrEmpty()){
                        viewDataBinding?.edittextMobileNumber?.isEnabled = false
                        viewDataBinding?.mobileNumberText?.visibility = View.VISIBLE
                        viewDataBinding?.layoutMobile?.visibility = View.GONE
                        viewDataBinding?.mobileNumberText?.setText(viewModel.checkoutDetail?.secondaryMobile.toString())
                    }
                    if (successResponse.carts.isNotEmpty()) {
                        store = RealmManager.getLocalStore(successResponse.carts[0].storeId)
                    }
                    if (sectionToLoad == 0) {
                        logCheckoutEvent()
                    }
                    updateCheckoutUI(sectionToLoad)
                } else {
                    this@CheckoutDetailFragment.onError(
                        successResponse.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                }
            }
        })
    }

    private fun logCheckoutEvent() {
        var productCount = 0
        var outletNames = ""
        var productList = ""
        var totalItemCount = 0.0
        var isCPGItem = false
        if (viewModel.checkoutDetail?.carts != null && viewModel.checkoutDetail?.carts!!.isNotEmpty()) {
            for (cart in viewModel.checkoutDetail?.carts!!) {
                productCount += cart.products?.size ?: 0
                outletNames += cart.outletName + ","
                if (cart.products != null && cart.products!!.isNotEmpty()) {
                    for (product in cart.products!!) {
                        if (product.promo_item == 1) isCPGItem = true
                        productList += """${product.name},"""
                        totalItemCount += product.cartQty ?: 0.0
                    }
                }
            }
        }

        if (viewModel.checkoutDetail?.carts!!.isNotEmpty()) {
            RealmManager.getLocalStore(viewModel.checkoutDetail?.carts!!.first().storeId) ?: null
        } else null

        with(deliveryTimeAdapter) {
            isExpress = store?.express == 1
            service_type_id = store?.serviceTypeId!!
            notifyDataSetChanged()
        }

        BasketAnalyticsManager.beginCheckoutNew(
            if (outletNames.isNotEmpty()) StringUtils.removeLastCharacter(outletNames) else "",
            if (productList.isNotEmpty()) StringUtils.removeLastCharacter(productList) else "",
            viewModel.checkoutDetail?.carts?.size ?: 0,
            viewModel.checkoutDetail?.overallSubtotal ?: 0.0,
            productCount,
            totalItemCount,
            store?.express ?: 0,
            AppConstants.isMember,
            isCPGItem
        )
    }

    private fun logPurchaseEvent(payment: String) {
        var outletNames = ""
        var productList = ""
        var itemList = ArrayList<String>()
        var outletCount = 0
        val totalAmount = viewModel.checkoutDetail?.overallTotal ?: 0.0
        val subtotal = viewModel.checkoutDetail?.overallSubtotal ?: 0.0
        var deliverySlots = ""
        var isCPGItem = false

        val store: Store? = if (viewModel.checkoutDetail?.carts!!.isNotEmpty()) {
            RealmManager.getLocalStore(viewModel.checkoutDetail?.carts!!.first().storeId) ?: null
        } else null

        val deliveryArea = RealmManager.getLocalAreaDetail(
            viewModel.checkoutDetail?.getUserSelectedAddress()?.locationId ?: 0
        )?.zoneName ?: ""
        var departmentNameList = ""

        val deliveryFee = viewModel.checkoutDetail?.overallDeliveryTotal ?: 0.0
        val serviceFee = viewModel.checkoutDetail?.overallServiceFee ?: 0.0
        val promoTitle = viewModel.checkoutDetail?.mPromoDetails?.promoCode ?: ""
        var productCount = 0
        var totalItemCount = 0.0
        if (viewModel.checkoutDetail?.carts != null && viewModel.checkoutDetail?.carts!!.isNotEmpty()) {
            outletCount = viewModel.checkoutDetail?.carts?.size ?: 0
            for (cart in viewModel.checkoutDetail?.carts!!) {
                deliverySlots += cart.deliveryTime ?: ""
                productCount += cart.products?.size ?: 0
                outletNames += cart.displayName
                if (cart.products != null && cart.products!!.isNotEmpty()) {
                    for (product in cart.products!!) {
                        if (product.promo_item == 1) isCPGItem = true
                        productList += """${product.name},"""
                        var itemString = ""
                        itemString = product.name ?: "undefined name" + ", "
                        departmentNameList += """${product.departmentName},"""
                        totalItemCount += product.cartQty ?: 0.0

                    }
                }
            }
        }

        BasketAnalyticsManager.purchase(
            if (outletNames.isNotEmpty()) StringUtils.removeLastCharacter(outletNames) else "",
            if (productList.isNotEmpty()) StringUtils.removeLastCharacter(productList) else "",
            outletCount,
            productCount,
            totalAmount,
            subtotal,
            deliveryArea,
            payment,
            if (deliverySlots.isNotEmpty()) StringUtils.removeLastCharacter(deliverySlots) else "",
            deliveryFee,
            serviceFee,
            promoTitle,
            departmentNameList,
            totalItemCount,
            viewModel.checkoutDetail?.overallServiceFeeDiscount ?: 0.0,
            viewModel.checkoutDetail?.carts?.first()?.products ?: ArrayList(),
            store?.express ?: 0,
            AppConstants.isMember,
            isCPGItem,
            viewModel.checkoutDetail?.firstOrder == 0
        )
    }

    private fun updateDeliveryInstruction() {
        viewModel.updateDeliveryInstruction(instruction)
    }

    // Checkout with 'Cash On Delivery Option'
    private fun offlinePay() {
        //    showLoading()
        val address = viewModel.checkoutDetail!!.getUserSelectedAddress()

        viewDataBinding?.loadingBar?.visibility = VISIBLE
        viewModel.offlinePayment(

            address!!.countryId,
            address.cityId,
            checkoutPaymentAdapter.getSelectedPaymentID(),
            instruction,
            if (adjustGoogleId.isNotEmpty()) AppConstants.ADJUST_GPS_ADID else AppConstants.ADJUST_FIRE_ADID,
            if (adjustGoogleId.isNotEmpty()) adjustGoogleId else adjustFireId,
            adjustADID,
            object : HandleResponse<SimpleResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    viewDataBinding?.loadingBar?.visibility = GONE
                    hideLoading()
                    if (NetworkUtils.isNetworkConnected(baseActivity) && !(error?.message
                            ?: "").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)
                    ) {
                        PopupUtils.showPlaceOrderFailDialog(
                            baseActivity, error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        NetworkUtils.showNoInternetDialog(baseActivity,
                            object : NetworkUtils.OnConnectedListener {
                                override fun onConnected() {
                                    try {
                                        offlinePay()
                                    } catch (e1: Exception) {
                                        e1.printStackTrace()
                                    }
                                }
                            })
                    }
                }

                override fun handleSuccessRespons(successResponse: SimpleResponse) {
                    viewDataBinding?.loadingBar?.visibility = GONE
                    hideLoading()
                    if (successResponse.code == 200) {
                        logPurchaseEvent("COD")
                        if (viewModel.checkoutDetail?.firstOrder == 0) {
                            BasketAnalyticsManager.setFirstOrderDate(DateUtils.getGMT())
                        } else {
                            BasketAnalyticsManager.setLastOrderDate(DateUtils.getGMT())
                        }
                        if (viewModel.checkoutDetail?.mPromoDetails != null && viewModel.checkoutDetail?.mPromoDetails?.promoCode != null) {
                            BasketAnalyticsManager.usedPromoCode(
                                arrayOf(
                                    viewModel.checkoutDetail?.mPromoDetails?.promoCode ?: ""
                                )
                            )
                        }
                        if (store?.isGridView == 1) {
                            showDialogFragment(
                                WaitFoodOrderFragment(
                                    successResponse.orderId ?: 0,
                                    successResponse.orderOutletId ?: 0
                                )
                            )
                        } else {
                            PopupUtils.orderPlacingDialog(
                                baseActivity, viewModel.checkoutDetail!!.carts
                            ) {
                                gotoOrderList()
                            }
                        }
                    } else {
                        PopupUtils.showPlaceOrderFailDialog(
                            baseActivity,
                            successResponse.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )

                        if (successResponse.message == baseActivity.resources.getString(R.string.str_keep_quality_service)) {
                            expressCapacity(
                                viewModel.checkoutDetail?.carts?.first()?.storeId ?: 0
                            )
                        }

                        if (successResponse.code == 400) {
                            BasketAnalyticsManager.setCapacityReached(
                                viewModel.checkoutDetail?.carts?.first()?.storeId ?: 0,
                                DateUtils.getGMT()
                            )
                        }
                    }
                }
            })
    }

    // Checkout with Credit Card
    private fun queryOnlinePayment(cvv: String) {
        viewDataBinding?.loadingBar?.visibility = VISIBLE
        val address = viewModel.checkoutDetail!!.getUserSelectedAddress()
        viewModel.queryOnlinePayment(address!!.countryId,
            address.cityId,
            checkoutPaymentAdapter.getSelectedPaymentID(),
            checkoutPaymentAdapter.getSelectedCardId(),
            instruction,
            cvv,
            if (adjustGoogleId.isNotEmpty()) AppConstants.ADJUST_GPS_ADID else AppConstants.ADJUST_FIRE_ADID,
            if (adjustGoogleId.isNotEmpty()) adjustGoogleId else adjustFireId,
            adjustADID, getShopperTipValue(),
            object : HandleResponse<OnlinePaymentResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    viewDataBinding?.loadingBar?.visibility = GONE
                    if (NetworkUtils.isNetworkConnected(baseActivity) && !(error?.message
                            ?: "").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)
                    ) {
                        PopupUtils.showPlaceOrderFailDialog(
                            baseActivity, error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        NetworkUtils.showNoInternetDialog(baseActivity,
                            object : NetworkUtils.OnConnectedListener {
                                override fun onConnected() {
                                    try {
                                        queryOnlinePayment(cvv)
                                    } catch (e1: Exception) {
                                        e1.printStackTrace()
                                    }
                                }
                            })
                    }
                }

                override fun handleSuccessRespons(response: OnlinePaymentResponse) {
                    viewDataBinding?.loadingBar?.visibility = GONE
                    if (response.code == 200) {
                        logPurchaseEvent("CC")
                        if (viewModel.checkoutDetail?.firstOrder == 0) {
                            BasketAnalyticsManager.setFirstOrderDate(DateUtils.getGMT())
                        } else {
                            BasketAnalyticsManager.setLastOrderDate(DateUtils.getGMT())
                        }

                        if (store?.isGridView != 1) {
                            PopupUtils.orderPlacingDialog(
                                baseActivity, viewModel.checkoutDetail!!.carts
                            ) {
                                gotoOrderList()
                            }
                        } else {
                            showDialogFragment(
                                WaitFoodOrderFragment(
                                    response.orderId ?: 0,
                                    response.orderOutletId ?: 0
                                )
                            )
                            //     showDialogFragment(WaitFoodOrderFragment(response.))
                        }
                    } else {
                        PopupUtils.showPlaceOrderFailDialog(
                            baseActivity, response.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )

                        if (response.message == baseActivity.resources.getString(R.string.str_keep_quality_service)) {
                            expressCapacity(
                                viewModel.checkoutDetail?.carts?.first()?.storeId ?: 0
                            )
                        }

                        if (response.code == 400) {
                            BasketAnalyticsManager.setCapacityReached(
                                viewModel.checkoutDetail?.carts?.first()?.storeId ?: 0,
                                DateUtils.getGMT()
                            )
                        }
                    }
                }
            })
    }

    private fun expressCapacity(outletId: Int) {
        viewModel.expressCapacity(outletId, object : HandleResponse<SimpleResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {

            }

            override fun handleSuccessRespons(successResponse: SimpleResponse) {

            }
        })
    }

    // Remove applied Promo Code
    private fun removePromoFromCart() {
        viewModel.removePromoFromCart(object : HandleResponse<SimpleResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(baseActivity) && !(error?.message
                        ?: "").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)
                ) {
                    this@CheckoutDetailFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    NetworkUtils.showNoInternetDialog(baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    removePromoFromCart()
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(successResponse: SimpleResponse) {
                if (successResponse.code == 200) {
                    getCheckoutDetail(5)
                } else {
                    this@CheckoutDetailFragment.onError(
                        successResponse.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                }
            }
        })
    }


    override fun onAddressSelected(address: Address, mInstruction: String) {
        selectedAddress = address
        updateDeliveryAddress(address.id)

        BasketAnalyticsManager.setCurrentLocation(
            viewModel.getCountryWithId(address.countryId ?: 0)?.countryName ?: "",
            RealmManager.getLocalCityDetail(address.cityId ?: 0)?.cityName ?: "",
            RealmManager.getLocalAreaDetail(address.locationId ?: 0)?.zoneName ?: ""
        )
        updateDeliveryInstruction()
    }

    // Get Delivery slot list
    private fun getDeliverySlots(cart: Cart, position: Int) {
        viewModel.getDeliverySlots(cart.storeId, object : HandleResponse<DeliverySlotsResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(baseActivity) && !(error?.message
                        ?: "").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)
                ) {
                    popBackStack()
                } else {
                    NetworkUtils.showNoInternetDialog(baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    getDeliverySlots(cart, position)
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(response: DeliverySlotsResponse) {
                if (response.code == 200 && response.storeDeliverySlots != null) {
                    initSlots(response.storeDeliverySlots!!, cart, position)
                } else {
                    popBackStack()
                }
            }
        })
    }

    private fun initSlots(deliverySlots: List<StoreDeliverySlot>, cart: Cart, position: Int) {
        deliverySlot = null
        for (slot in deliverySlots) {
            if (slot.storeId == cart.storeId) {
                deliverySlot = slot
                break
            }
        }

        if (deliverySlot == null) {
            popBackStack()
            return
        }

        var selection = 0
        val deliveryDays = ArrayList<DeliveryDay>(deliverySlot!!.deliveryDays ?: emptyList())
        // check if first day is available
        if (deliveryDays.isNotEmpty()) {
            val times = deliveryDays.first().times
            var isAvailableDay = false
            if (times != null) {
                for (time in times) {
                    if (time.available == 1) {
                        isAvailableDay = true
                        break
                    }
                }
            }
            // Remove Empty Day
            if (!isAvailableDay) {
                deliveryDays.first().times = null
            }
        }
        val sortedDeliveryDays = ArrayList<DeliveryDay>()
        for (deliveryDay in deliveryDays) {
            if (deliveryDay.times != null && deliveryDay.times!!.isNotEmpty()) {
                sortedDeliveryDays.add(deliveryDay)
            } else {
                deliveryDay.times = null
                sortedDeliveryDays.add(deliveryDay)
            }
        }

        for (i in sortedDeliveryDays.indices) {
            if (sortedDeliveryDays[i].weekDate!! == cart.deliveryDate) selection = i
        }

        deliveryTimeAdapter.deliveryDayAdapter.setItems(sortedDeliveryDays)
        deliveryTimeAdapter.deliveryDayAdapter.setSelection(selection)

        deliveryTimeAdapter.rvDeliveryDay?.smoothScrollToPosition(selection)
    }

    override fun onChangeTimeSelected(cart: Cart, position: Int) {
        if (cart.isGridView != 1) {
            getDeliverySlots(cart, position)
        }
    }

    override fun onTimeSelected(cart: Cart, deliveryTime: DeliveryTime) {
        updateDeliverySlot(cart, deliveryTime)
    }

    private fun updatePaymentUI() {
        var isCreditCardEnabled = false
        for (paymentMethod in paymentData) {
            if (paymentMethod.paymentType == 2) {
                payfortPaymentMode = paymentMethod.paymentMode
                payfortEnvironmentMode =
                    if (payfortPaymentMode == AppConstants.PAYFORT_MODE_PRODUCTION) {
                        AppConstants.PAYFORT_URL = AppConstants.PAYFORT_URL_LIVE
                        FortSdk.ENVIRONMENT.PRODUCTION
                    } else {
                        AppConstants.PAYFORT_URL = AppConstants.PAYFORT_URL_SANDBOX
                        FortSdk.ENVIRONMENT.TEST
                    }

                isCreditCardEnabled = (paymentMethod.isCreditCardEnable == 1)
            }
        }
        viewDataBinding?.tvAddPayment?.visibility = if (isCreditCardEnabled) VISIBLE else GONE

        payfortDeviceId = FortSdk.getDeviceId(baseActivity)
        checkoutPaymentAdapter.setItems(paymentData)

        viewDataBinding?.tvAddPayment?.setOnClickListener {
            payfortDeviceId = FortSdk.getDeviceId(baseActivity)
            if (SystemClock.elapsedRealtime() - lastClickTime > 1500 && !(baseActivity as CheckoutActivity).isPaymentScreenOpened) {
                // Get Payfort Token
                getLocalPayfortToken(payfortDeviceId!!)
                (baseActivity as CheckoutActivity).isPaymentScreenOpened = true
            }
        }

        refreshCreditCardWarningPopup(checkoutPaymentAdapter.getSelectedCardId())
    }

    override fun onPaymentSelected(
        paymentId: Int,
        cardId: Int,
        paymentName: String,
        paymentMethod: PaymentMethod?,
    ) {
        updatePaymentMethod(paymentId, cardId)

        if (viewDataBinding?.rvPayment?.visibility== VISIBLE){
            viewDataBinding?.rvPayment?.visibility = GONE
            viewDataBinding?.tvPaymentType?.text = paymentName.toString()
            viewDataBinding?.ivDropDownPayment?.setImageDrawable(
                ContextCompat.getDrawable(
                    baseActivity, R.drawable.ic_arrow_down
                )
            )

        }else{
            viewDataBinding?.rvPayment?.visibility = VISIBLE
            viewDataBinding?.ivDropDownPayment?.setImageDrawable(
                ContextCompat.getDrawable(
                    baseActivity, R.drawable.ic_close_black_24dp
                )
            )
        }

        //  refreshCreditCardWarningPopup(cardId)
        /*
                viewDataBinding?.ivPayment?.setImageDrawable(ContextCompat.getDrawable(baseActivity,
                    if (cardId == 0) R.drawable.ic_cash_on_delivery else R.drawable.ic_payment_method_checkout))
        */
    }

    private fun refreshCreditCardWarningPopup(
        cardId: Int
    ) {
        if (cardId != 0) {
            viewDataBinding?.layoutCreditCardWarning?.visibility = GONE
            //        viewDataBinding?.layoutCreditCardWarning?.visibility = VISIBLE
            viewDataBinding?.tvWarningCreditCard?.text = baseActivity.resources.getString(
                R.string.str_checkout_charge_card, String.format(
                    Locale.US, "%.2f", viewModel.checkoutDetail?.preAuthorizationAmount ?: 0.0
                )
            )
        } else {
            viewDataBinding?.layoutCreditCardWarning?.visibility = GONE
        }
    }


    // Update payment method
    private fun updatePaymentMethod(paymentId: Int, cardId: Int) {
        viewModel.updatePaymentMethod(paymentId, cardId, object : HandleResponse<SimpleResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(baseActivity) && !(error?.message
                        ?: "").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)
                ) {

                    this@CheckoutDetailFragment.onError(error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE)
                    Log.d("TAG", "handleErrorResponse: "+error?.message.toString())
                } else {
                    NetworkUtils.showNoInternetDialog(baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    updatePaymentMethod(paymentId, cardId)
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(response: SimpleResponse) {
                if (response.code == 200) {
                    //        viewDataBinding?.layoutPaymentList?.visibility = GONE
                    BasketAnalyticsManager.updatePaymentMethodAttribute(
                        arrayOf(if (cardId == 0) "COD" else "CC")
                    )
                    updateLocalPaymentData(paymentId, cardId)

                    getCheckoutDetail(3)
                    Log.d("TAG", "handleErrorResponse: "+response.code)
                } else {
                    this@CheckoutDetailFragment.onError(
                        response.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                }
            }
        })
    }

    private fun updateLocalPaymentData(paymentId: Int, cardId: Int) {
        if (cardId == 0) {
            for (paymentMethod in paymentData) {
                paymentMethod.defaultStatus = if (paymentMethod.id == paymentId) 1
                else 0
                for (card in paymentMethod.cards) {
                    card.defaultStatus = 0
                }
            }
        } else {
            for (paymentMethod in paymentData) {
                paymentMethod.defaultStatus = 0
                for (card in paymentMethod.cards) {
                    card.defaultStatus = if (card.cardId == cardId) 1 else 0
                }
            }
        }

        //      BasketAnalyticsManager.addPaymentInfoNew(if (cardId == 0) "CC" else "COD")
        viewModel.checkoutDetail?.paymentList = paymentData
    }

    // Add promo code to cart
    private fun addPromoCode(promoCode: String) {
        viewModel.addPromoCodeToCart(promoCode, object : HandleResponse<SimpleResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(baseActivity) && !(error?.message
                        ?: "").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)
                ) {
                    this@CheckoutDetailFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    NetworkUtils.showNoInternetDialog(baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    addPromoCode(promoCode)
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(response: SimpleResponse) {
                if (response.code == 200) {
                    //Broadcast event 'Promo code added' so checkout detail information could be updated
                    EventBus.getDefault()
                        .post(MessageEvent(AppConstants.MESSAGE_PROMO_CODE_CHANGED))
                    DialogPromo.dismissDialog()

                } else {
                    BasketAnalyticsManager.promoCodeDeclined(promoCode)
                    DialogPromo.setErrorMessage(response.message ?: "")
                }
            }
        })
    }


    fun getLocalPayfortToken(deviceId: String) {
        viewModel.getLocalPayfortToken(deviceId, object : HandleResponse<PayfortTokenResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(baseActivity) && !(error?.message
                        ?: "").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)
                ) {
                    this@CheckoutDetailFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    NetworkUtils.showNoInternetDialog(baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    getLocalPayfortToken(deviceId)
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(successResponse: PayfortTokenResponse) {
                if (successResponse.status == 200) {
                    createAddCardRequest(createMap(successResponse.data.sdk_token)!!)
                } else {
                    this@CheckoutDetailFragment.onError(
                        successResponse.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                }
            }
        })
    }

    // Create Request (Map request)
    private fun createMap(token: String): Map<String, Any>? {
        val requestMap: MutableMap<String, Any> = HashMap()
        requestMap["amount"] = AppConstants.PAYFORT_CREDIT_CARD_AUTHORIZATION_AMOUNT
        requestMap["currency"] = StringUtils.getCurrencyForPayment()
        requestMap["customer_email"] = "${PreferenceManager.currentUserId}@basket.jo"
        requestMap["language"] = AppConstants.PAYFORT_LANGUAGE
        requestMap["merchant_reference"] = Date().time.toString()
        requestMap["command"] = AppConstants.PAYFORT_MODE_AUTHORIZATION
        requestMap["sdk_token"] = token
        return requestMap
    }

    // Open Add Credit Card page
    private fun createAddCardRequest(requestMap: Map<String, Any>) {
        val fortRequest = FortRequest()
        fortRequest.requestMap = requestMap

        (activity as CheckoutActivity).addCreditCardRequest(requestMap, payfortEnvironmentMode)
    }

    // Add Credit Card
    fun addCreditCard(fortData: Map<String, Any>) {
        viewModel.addCreditCard(fortData,
            viewModel.checkoutDetail?.carts?.first()?.storeId ?: 0,
            checkoutPaymentAdapter.getCreditCardPaymentId(),
            object : HandleResponse<CreditCardResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (NetworkUtils.isNetworkConnected(baseActivity) && !(error?.message
                            ?: "").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)
                    ) {
                        this@CheckoutDetailFragment.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        NetworkUtils.showNoInternetDialog(baseActivity,
                            object : NetworkUtils.OnConnectedListener {
                                override fun onConnected() {
                                    try {
                                        addCreditCard(fortData)
                                    } catch (e1: Exception) {
                                        e1.printStackTrace()
                                    }
                                }
                            })
                    }
                }

                override fun handleSuccessRespons(response: CreditCardResponse) {
                    if (response.httpCode == 200) {
                        BasketAnalyticsManager.updatePaymentMethodAttribute(
                            arrayOf("CC")
                        )
                        BasketAnalyticsManager.addPaymentInfoNew("CC")
                        //     getPaymentMethodNew()
                        getCheckoutDetail(3)
                    } else {
                        this@CheckoutDetailFragment.onError(
                            response.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    }
                }
            })
    }

    // Add items to cart
    private fun addToCart(product: Product, amount: Double) {
        product.cartQty = amount

        updateProductList(product)
        viewModel.addToCart(product, amount, object : HandleResponse<AddCartResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(baseActivity) && !(error?.message
                        ?: "").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)
                ) {
                    this@CheckoutDetailFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    NetworkUtils.showNoInternetDialog(baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    addToCart(product, amount)
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(response: AddCartResponse) {
                if (response.code == 200) {
                    viewModel.updateLocalProduct(product, false)
                    getCheckoutDetail(10)  // Reload only ProductList
                } else {
                    getCheckoutDetail(4)  // Reload only ProductList
                    this@CheckoutDetailFragment.onError(
                        response.message
                    )
                }
            }
        })
    }

    // Add items to cart
    private fun updateCart(product: Product, amount: Double) {
        product.cartQty = if (amount < 0.0) 0.0 else amount
        updateProductList(product)
        viewModel.updateToCart(
            product,
            amount,
            store?.vendorId ?: 0,
            object : HandleResponse<AddCartResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (NetworkUtils.isNetworkConnected(baseActivity) && !(error?.message
                            ?: "").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)
                    ) {
                        this@CheckoutDetailFragment.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        NetworkUtils.showNoInternetDialog(baseActivity,
                            object : NetworkUtils.OnConnectedListener {
                                override fun onConnected() {
                                    try {
                                        addToCart(product, amount)
                                    } catch (e1: Exception) {
                                        e1.printStackTrace()
                                    }
                                }
                            })
                    }
                }

                override fun handleSuccessRespons(response: AddCartResponse) {
                    if (response.code == 200) {
                        viewModel.updateLocalProduct(product, false)
                        getCheckoutDetail(10)  // Reload only ProductList
                    } else {
                        getCheckoutDetail(4)  // Reload only ProductList
                        this@CheckoutDetailFragment.onError(
                            response.message ?: ""
                        )
                    }
                }
            })
    }

    private fun initWalletOption() {
        viewDataBinding?.tvUserMyBalance?.text = baseActivity.resources.getString(
            R.string.str_use_wallet, PreferenceManager.userCurrencyCode, "10.20"
        )
    }

    private fun onInstructionClicked() {
        instruction = viewDataBinding?.edittextInstruction?.text.toString().trim()
        if (viewDataBinding?.layoutContentInstruction?.visibility == VISIBLE) {
            viewDataBinding?.tvInstruction?.visibility =
                if (instruction.isNotEmpty()) VISIBLE else GONE
            viewDataBinding?.tvInstruction?.text = instruction
            hideContentInstruction()
        } else {
            viewDataBinding?.layoutContainer?.descendantFocusability =
                ViewGroup.FOCUS_BEFORE_DESCENDANTS
            viewDataBinding?.tvInstruction?.visibility = GONE
            viewDataBinding?.layoutContentInstruction?.visibility = VISIBLE
            viewDataBinding?.edittextInstruction?.requestFocus()
            initTimeView(false)
            //      hidePaymentList()
            hideAddressList()
            isProductViewExpanded = true
            resetProductRecyclerView()
        }
    }

    private fun onPaymentClicked() {
        if (viewDataBinding?.rvPayment?.visibility == VISIBLE) {
            viewDataBinding?.tvPaymentType?.text = checkoutPaymentAdapter.getSelectedPaymentName().ifEmpty { baseActivity.resources.getString(R.string.str_choose_payment_method) }
            viewDataBinding?.rvPayment?.visibility = GONE
            viewDataBinding?.ivDropDownPayment?.setImageDrawable(
                ContextCompat.getDrawable(
                    baseActivity, R.drawable.ic_arrow_down
                )
            )
        } else {
            viewDataBinding?.tvPaymentType?.text =
                baseActivity.resources.getString(R.string.str_choose_payment_method)
            viewDataBinding?.rvPayment?.visibility = VISIBLE
            initTimeView(false)
            hideContentInstruction()
            hideAddressList()
            isProductViewExpanded = true
            viewDataBinding?.ivDropDownPayment?.setImageDrawable(
                ContextCompat.getDrawable(
                    baseActivity, R.drawable.ic_close_black_24dp
                )
            )
            resetProductRecyclerView()
        }
    }

    // Remove product from cart
    private fun removeProductFromCart(product: Product) {
        viewModel.removeProductFromCart(product, object : HandleResponse<SimpleResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(baseActivity) && !(error?.message
                        ?: "").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)
                ) {
                    this@CheckoutDetailFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    NetworkUtils.showNoInternetDialog(baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    removeProductFromCart(product)
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(successResponse: SimpleResponse) {
                if (successResponse.code == 200) {
                    BasketAnalyticsManager.removeItemFromCartNew(
                        RealmManager.getLocalStore(product.outletId ?: 0)?.outletName ?: "",
                        product.name ?: "",
                        0
                    )
                    getCheckoutDetail(4)
                } else {
                    this@CheckoutDetailFragment.onError(
                        successResponse.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                }
            }
        })
    }

    private fun initMap() {
        mapFragment = childFragmentManager.findFragmentById(R.id.fragment_map) as SupportMapFragment
        mapFragment?.view?.isClickable = false
        mapFragment?.getMapAsync { map ->
            map.uiSettings.isMapToolbarEnabled = false
            val userLatLng = LatLng(31.95989489221491, 35.92947017401457)
            map.moveCamera(CameraUpdateFactory.newLatLng(userLatLng))
            userMap = map
        }
    }

    private fun initMarker() {
        viewDataBinding?.ivMarker?.visibility =
            if (viewModel.checkoutDetail?.getUserSelectedAddress() == null) GONE else VISIBLE
        // user address
        mapFragment?.getMapAsync { map ->
            val userLatLng = LatLng(
                viewModel.checkoutDetail?.getUserSelectedAddress()?.latitude ?: 32.0,
                viewModel.checkoutDetail?.getUserSelectedAddress()?.longtitude ?: 36.0
            )
            map.animateCamera(CameraUpdateFactory.newLatLng(userLatLng))
            userMap = map
        }
    }

    override fun onHorizontalProductSelected() {
        resetProductRecyclerView()
    }

    override fun onDestroy() {
        EventBus.getDefault().unregister(this)

        AppConstants.IS_CHECKOUT_RUNNING = false
        super.onDestroy()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        fortCallback!!.onActivityResult(requestCode, resultCode, data)
    }

    override fun onEditAddress(address: Address) {
        startActivity(
            LocationActivity.newIntentEditAddress(
                baseActivity, AppConstants.LOCATION_MODE_EDIT_ADDRESS, address
            )
        )
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        when (event.message) {
            AppConstants.MESSAGE_PROMO_CODE_CHANGED -> {
                getCheckoutDetail(5)
            }

            AppConstants.MESSAGE_DELIVERY_ADDRESS_CHANGED -> {
                getCheckoutDetail(1)
            }

            AppConstants.MESSAGE_PRODUCT_CHANGED -> {
                getCheckoutDetail(10)
            }

            AppConstants.MESSAGE_CHECKOUT_PRODUCT_UPDATED -> {
                getCheckoutDetail(4)
            }

            AppConstants.MESSAGE_RESTART -> {
                finishActivity()
            }

            AppConstants.MESSAGE_CHECKOUT_DELIVERY_TIME_OPENED -> {
                //       hidePaymentList()
                if (!isPageLoadedFirst) {
                    hideAddressList()
                }
                // if (!isPageLoadedFirst) viewDataBinding?.layoutContentInstruction?.visibility = VISIBLE
                isPageLoadedFirst = false
                isProductViewExpanded = true
                resetProductRecyclerView()
            }

            AppConstants.MESSAGE_COUNTRY_CHANGED -> {
                getCheckoutDetail(1)
            }

            AppConstants.MESSAGE_ORDER_REJECTED_FOOD -> {
                EventBus.getDefault()
                    .post(MessageEvent(AppConstants.MESSAGE_FINISH_CART))
                finishActivity()
            }
        }
    }
}