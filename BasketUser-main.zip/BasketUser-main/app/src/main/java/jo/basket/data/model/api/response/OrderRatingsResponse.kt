package jo.basket.data.model.api.response

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import jo.basket.data.model.Driver
import jo.basket.data.model.OrderDetail
import jo.basket.data.model.Shopper

class OrderRatingsResponse {
    @SerializedName("httpCode")
    @Expose
    var code = 0

    @SerializedName("Message")
    @Expose
    var message: String? = null

    @SerializedName("rating_comments")
    @Expose
    var ratingComments: String? = null

    @SerializedName("shopper_detail")
    @Expose
    var shopperDetails: Shopper? = null

    @SerializedName("driver_detail")
    @Expose
    var driverDetails: Driver? = null

    @SerializedName("shopping_rating")
    @Expose
    var shopperRating: Float? = null

    @SerializedName("delivery_rating")
    @Expose
    var driverRating: Float? = null

    @SerializedName("overall_rating")
    @Expose
    var overallRating: Float? = null

    @SerializedName("order_outlet_detail")
    @Expose
    var orderDetail: OrderDetail? = null

    @SerializedName("rating_reasons")
    @Expose
    var rating_reasons: List<Any>? = null
}