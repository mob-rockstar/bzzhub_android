package jo.basket.ui.accountsetting.countrysetting

import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import jo.basket.R
import jo.basket.data.local.prefs.PreferenceManager
import jo.basket.data.model.api.response.CountrySettingResponse
import jo.basket.data.model.api.response.SimpleUpdateResponse
import jo.basket.data.model.api.response.base.ErrorResponse
import jo.basket.databinding.DialogCountrySettingsBinding
import jo.basket.di.Injectable
import jo.basket.ui.accountsetting.AccountSettingViewModel
import jo.basket.ui.base.BaseInputDialogFragment
import jo.basket.ui.base.HandleResponse
import jo.basket.utils.AppConstants
import jo.basket.utils.NetworkUtils

//Screen to Display country list of current user, and selection status
class CountrySettingsFragment :
    BaseInputDialogFragment<DialogCountrySettingsBinding?, AccountSettingViewModel>(),
    Injectable, CountrySettingsAdapter.OnCountrySelectListener {

    private var countrySettingsAdapter = CountrySettingsAdapter()

    override val layoutId: Int
        get() = R.layout.dialog_country_settings

    override val viewModel: AccountSettingViewModel
        get() {
            return getViewModel(baseActivity, AccountSettingViewModel::class.java)
        }

    // Set width and height of dialog to Full Screen
    override fun getTheme(): Int {
        return R.style.FullScreenDialogFragmentTheme
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initToolBar()

        progressView = viewDataBinding!!.progressBar

        initRecyclerView()
        getCountryList()
    }

    // Define and set properties of RecyclerView
    private fun initRecyclerView() {
        viewDataBinding!!.recyclerView.run {
            layoutManager = LinearLayoutManager(baseActivity)
            adapter = countrySettingsAdapter
        }
    }

    //Set Toolbar title, back-button click listener
    private fun initToolBar() {
        viewDataBinding!!.toolbar.tvTitle.text =
            baseActivity.resources.getString(R.string.str_country_settings)
        viewDataBinding!!.toolbar.ivBack.setOnClickListener { dismiss() }
    }

    //Get Country List from the server
    private fun getCountryList() {
        viewModel.getCountryList(object : HandleResponse<CountrySettingResponse> {
            // Error while calling API
            override fun handleErrorResponse(error: ErrorResponse?) {
                // Network is connected - Error message from the server
                 if (NetworkUtils.isNetworkConnected(baseActivity) &&!(error?.message ?:"").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)) {
                    this@CountrySettingsFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    //Network is not connected, 'No Internet' Dialog will be displayed
                    NetworkUtils.showNoInternetDialog(
                        baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    getCountryList()
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(successResponse: CountrySettingResponse) {
                if (successResponse.code == 200) {
                    //Display countryLists to RecyclerView
                    countrySettingsAdapter.setItems(successResponse.countryList!!)
                    countrySettingsAdapter.selectedListener = this@CountrySettingsFragment
                } else {
                    // Show Error message from API
                    this@CountrySettingsFragment.onError(
                        successResponse.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                }
            }
        })
    }

    override fun onSelect(countryID: Int) {
        viewModel.updateCountrySelection(countryID, object : HandleResponse<SimpleUpdateResponse> {
            // Error while calling API
            override fun handleErrorResponse(error: ErrorResponse?) {
                // Network is connected - Error message from the server
                 if (NetworkUtils.isNetworkConnected(baseActivity) &&!(error?.message ?:"").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)) {
                    this@CountrySettingsFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    //Network is not connected, 'No Internet' Dialog will be displayed
                    NetworkUtils.showNoInternetDialog(
                        baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    onSelect(countryID)
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(successResponse: SimpleUpdateResponse) {
                if (successResponse.status == 200) {
                    // Save selected country to Local DB
                    PreferenceManager.currentUserCountryId = countryID

                    // Update UI
                    countrySettingsAdapter.setCountryID(countryID)
                } else {
                    // Show Error message from API
                    this@CountrySettingsFragment.onError(
                        successResponse.message
                    )
                }
            }
        })
    }
}