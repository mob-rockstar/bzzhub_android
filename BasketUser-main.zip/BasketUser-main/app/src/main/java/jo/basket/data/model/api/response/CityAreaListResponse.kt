package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.CityArea

class CityAreaListResponse {
    @field:SerializedName("status")
    val code: Int = 0

    @field:SerializedName("message")
    val message: String? = null

    @field:SerializedName("data")
    val itemList: ArrayList<CityArea> ?= null
}