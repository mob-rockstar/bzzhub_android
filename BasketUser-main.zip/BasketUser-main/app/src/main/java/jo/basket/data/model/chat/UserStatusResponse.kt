package jo.basket.data.model.chat

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

open class UserStatusResponse {

    @SerializedName("user_id")
    @Expose
    var user_id: String? = null

    @SerializedName("user_type")
    @Expose
    var user_type: String? = null

    @SerializedName("is_online")
    @Expose
    var is_online: String? = "false"

}