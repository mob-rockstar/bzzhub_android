package jo.basket.data.model.api.response

import jo.basket.data.model.LoyaltyCard


data class LoyaltyCardListResponse(
    var `data`: List<LoyaltyCard>? = null,
    var httpCode: Int = 0
)