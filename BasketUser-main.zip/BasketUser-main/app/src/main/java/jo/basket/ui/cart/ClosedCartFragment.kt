package jo.basket.ui.cart

import android.os.Bundle
import android.view.View
import jo.basket.R
import jo.basket.databinding.FragmentStoreClosedCartBinding
import jo.basket.di.Injectable
import jo.basket.ui.base.BaseDialogFragment

class ClosedCartFragment : BaseDialogFragment<FragmentStoreClosedCartBinding?, CartViewModel>(),
    Injectable {

    override val layoutId: Int
        get() = R.layout.fragment_store_closed_cart

    override val viewModel: CartViewModel
        get() {
            return getViewModel(baseActivity, CartViewModel::class.java)
        }

    // Set Full screen
    override fun getTheme(): Int {
        return R.style.FullScreenDialogFragmentTheme
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        viewDataBinding?.ivClose?.setOnClickListener {
            dismiss()
            finishActivity()
        }
        viewDataBinding?.tvBackToProducts?.setOnClickListener {
            dismiss()
            finishActivity()
        }
    }

}