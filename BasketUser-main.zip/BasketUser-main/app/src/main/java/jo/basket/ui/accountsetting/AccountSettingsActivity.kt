package jo.basket.ui.accountsetting

import android.content.Intent
import android.os.Bundle
import android.view.View.GONE
import android.view.View.VISIBLE
import dagger.android.AndroidInjector
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import jo.basket.R
import jo.basket.data.local.prefs.PreferenceManager
import jo.basket.data.model.api.response.SimpleResponse
import jo.basket.data.model.api.response.base.BaseResponse
import jo.basket.data.model.api.response.base.ErrorResponse
import jo.basket.databinding.ActivityAccountSettingsBinding
import jo.basket.ui.accountsetting.languagesetting.LanguageSettingsFragment
import jo.basket.ui.accountsetting.loyaltycard.LoyaltyCardListFragment
import jo.basket.ui.accountsetting.notificationsetting.NotificationSettingsFragment
import jo.basket.ui.base.BaseActivity
import jo.basket.ui.base.HandleResponse
import jo.basket.ui.location.LocationActivity
import jo.basket.ui.login.LoginActivity
import jo.basket.utils.*
import jo.basket.utils.analytics.BasketAnalyticsManager
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import rx.Single
import javax.inject.Inject

// Activity Contains Account Setting Flow
class AccountSettingsActivity :
    BaseActivity<ActivityAccountSettingsBinding?, AccountSettingViewModel>(),
    HasAndroidInjector {

    override val layoutId: Int
        get() = R.layout.activity_account_settings

    override val viewModel: AccountSettingViewModel
        get() {
            return getViewModel(AccountSettingViewModel::class.java)
        }

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector(): AndroidInjector<Any> = dispatchingAndroidInjector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        EventBus.getDefault().register(this)

        viewDataBinding?.layoutDeactivateAccount?.visibility =
            if (PreferenceManager.currentUserId != 0L) VISIBLE else GONE

        initToolbar()
        loadCountryFlag()
        initClickListeners()
    }

    //Once got event broadcast (when Logout success), finish current Activity
    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        when (event.message) {
            AppConstants.MESSAGE_RESTART -> {
                finish()
            }
            AppConstants.MESSAGE_COUNTRY_CHANGED -> {
                loadCountryFlag()
            }
        }
    }

    fun initToolbar() {
        viewDataBinding?.toolbar!!.tvTitle.text =
            resources.getString(R.string.str_account_settings)

        viewDataBinding?.toolbar?.ivBack!!.setOnClickListener { finish() }
    }

    private fun loadCountryFlag() {

        viewDataBinding?.tvCountryName?.text =
            resources.getString(
                if (PreferenceManager.currentUserCountryId == 46) R.string.str_country_name_jordan
                else R.string.str_country_name_saudi
            )

        GlideApp.with(this).load(PreferenceManager.countryFlag).fitCenter()
            .placeholder(R.drawable.ic_flag_jo)
            .error(R.drawable.ic_flag_jo).into(viewDataBinding?.ivFlag!!)
    }


    private fun initClickListeners() {
        //Tap Notification Button, Open Notification Screen
        viewDataBinding?.layoutNotification?.setOnClickListener {
            showDialogFragment(NotificationSettingsFragment())
        }

        viewDataBinding?.layoutLogout?.setOnClickListener {
            openLogoutDialog()
        }

        //Tap 'Country' button, Open Country Selection Screen
        viewDataBinding?.layoutCountry?.setOnClickListener {
            startActivity(
                LocationActivity.newIntent(
                    this@AccountSettingsActivity,
                    AppConstants.LOCATION_MODE_SELECT_COUNTRY
                )
            )
            //   showDialogFragment(CountrySettingsFragment())
        }

        // Tap 'Language' button, Open Language Selection Screen
        viewDataBinding?.layoutLanguage?.setOnClickListener {
            showDialogFragment(LanguageSettingsFragment())
        }

        //Tap 'Loyalty Card' button, Open LoyaltyCard Screen
        viewDataBinding?.layoutLoyaltyCard?.setOnClickListener {
            showDialogFragment(LoyaltyCardListFragment())
        }

        viewDataBinding?.layoutDeactivateAccount?.setOnClickListener {
            deActivateAccount()
        }
    }

    private fun deActivateAccount() {
        viewModel.deactivateAccount(
            object : HandleResponse<SimpleResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (NetworkUtils.isNetworkConnected(this@AccountSettingsActivity) && !(error?.message
                            ?: "").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)
                    ) {
                        onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        NetworkUtils.showNoInternetDialog(
                            this@AccountSettingsActivity,
                            object : NetworkUtils.OnConnectedListener {
                                override fun onConnected() {
                                    try {
                                        deActivateAccount()
                                    } catch (e1: Exception) {
                                        e1.printStackTrace()
                                    }
                                }
                            })
                    }
                }

                override fun handleSuccessRespons(successResponse: SimpleResponse) {
                    // need to force logout even get error from API
                    PreferenceManager.currentUserLoggedInMode =
                        PreferenceManager.LoggedInMode.LOGGED_IN_MODE_LOGGED_OUT
                    // If Logout action success, return to Login Screen
                    gotoLoginActivity()
                    //Send Event broadcast to finish existing activities
                    EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_RESTART))
                }
            }
        )
    }

    // Logout confirmation dialog
    private fun openLogoutDialog() {
        PopupUtils.showLogoutDialog(this) { logout() }
/*        PopupUtils.showConfirmDialog(
            this,
            "",
            getString(R.string.str_are_you_sure_logout)
        ) {
            logout()
        }*/
    }

    private fun logout() {
        BasketAnalyticsManager.logout()
        viewModel.logout(object : HandleResponse<BaseResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                // need to force logout even get error from API
                PreferenceManager.currentUserLoggedInMode =
                    PreferenceManager.LoggedInMode.LOGGED_IN_MODE_LOGGED_OUT

                // If Logout action success, return to Login Screen
                gotoLoginActivity()
                //Send Event broadcast to finish existing activities
                EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_RESTART))
            }

            override fun handleSuccessRespons(response: BaseResponse) {
                // need to force logout even get error from API
                PreferenceManager.currentUserLoggedInMode =
                    PreferenceManager.LoggedInMode.LOGGED_IN_MODE_LOGGED_OUT
                // If Logout action success, return to Login Screen
                gotoLoginActivity()
                //Send Event broadcast to finish existing activities
                EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_RESTART))
            }
        })
    }

    // Open Login Activity
    fun gotoLoginActivity() {
        val intent = Intent(this@AccountSettingsActivity, LoginActivity::class.java)
        intent.putExtra(AppConstants.KEY_TYPE_LOGOUT, true)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        startActivity(intent)
    }

    override fun onDestroy() {
        EventBus.getDefault().unregister(this)
        super.onDestroy()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }
}
