package jo.basket.ui.component.dialog.addresspicker

import android.content.Context
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import jo.basket.R
import jo.basket.data.local.db.RealmManager
import jo.basket.data.model.Address
import jo.basket.databinding.RecyclerItemPickAddressBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter
import jo.basket.utils.ImageUtils


// List Of Address
class AddressPickerAdapter: BaseRecyclerViewAdapter<Address, RecyclerItemPickAddressBinding>() {

    override val layoutId: Int
        get() = R.layout.recycler_item_pick_address

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return AddressViewHolder(createBindedView(viewGroup))
    }

    var mContext: Context? = null
    var mSelectedListener: SelectedListener? = null

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder: AddressViewHolder = viewHolder as AddressViewHolder

        val address = items[position]

        // Address Type Name
        holder.binding.tvAddressType.text = """${address.addressType} - ${
            address.locationName
        }""" ?: ""

        // Address Name Text
        holder.binding.tvAddress.text = address.address

        val selected = (address.isSelected == 1)

        holder.binding.ivSelected.visibility = if (selected) View.VISIBLE else View.GONE
        holder.binding.viewMask.visibility = if (selected) View.VISIBLE else View.GONE

        val icon = ImageUtils.getBitmapFromAddressType(address.addressTypeId!!, address.isSelected ?: 0)

        holder.binding.ivAddressType.setImageResource(icon)
        holder.binding.layoutAddress.setOnClickListener {
            mSelectedListener?.onAddressSelected(address)
        }
    }


    interface SelectedListener {
        fun onAddressSelected(address: Address)
    }

    fun setOnSelectListener(listener: SelectedListener) {
        mSelectedListener = listener
    }

    inner class AddressViewHolder(val binding: RecyclerItemPickAddressBinding) :
        RecyclerView.ViewHolder(binding.root)
}