package jo.basket.data.model.api.response

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.realm.RealmList
import jo.basket.data.model.Store
import jo.basket.data.model.StoreType

class StoreResponseData {
    @SerializedName("stores")
    @Expose
    var storeList: List<Store>? = null

    @SerializedName("express_store_id")
    @Expose
    val expressStoreId: Int = 0

    @SerializedName("business_text")
    @Expose
    var businessText: String? = null

    @SerializedName("need_order_rating")
    @Expose
    val needOrderRating: Int = 0

    @SerializedName("last_completed_order_id")
    @Expose
    val lastCompletedOrder: Int = 0

    @SerializedName("store_types")
    @Expose
    var types: RealmList<StoreType>? = null

}
