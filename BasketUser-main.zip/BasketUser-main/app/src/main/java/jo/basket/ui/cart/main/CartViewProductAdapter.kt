package jo.basket.ui.cart.main

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.load.engine.DiskCacheStrategy
import jo.basket.R
import jo.basket.data.local.prefs.PreferenceManager
import jo.basket.data.model.Banner
import jo.basket.data.model.Service
import jo.basket.data.model.Store
import jo.basket.data.model.StoreType
import jo.basket.data.model.api.response.Outlet
import jo.basket.data.model.api.response.ProductImages
import jo.basket.databinding.RecyclerAllItemCartProductBinding
import jo.basket.databinding.RecyclerItemAllCartStoreHeaderBinding
import jo.basket.databinding.RecyclerItemAllStoreTitleBinding
import jo.basket.databinding.RecyclerItemBestStoreBinding
import jo.basket.databinding.RecyclerItemStoreBannerSliderBinding
import jo.basket.databinding.RecyclerItemStoreBusinessTextBinding
import jo.basket.databinding.RecyclerItemStoreExpressButtonBinding
import jo.basket.databinding.RecyclerItemStoreTypeListBinding
import jo.basket.databinding.RecyclerItemStoreTypeSearchBinding
import jo.basket.databinding.RecyclerItemStoreTypeViewAllBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter
import jo.basket.ui.component.imageslider.SliderView
import jo.basket.utils.AppConstants
import jo.basket.utils.GlideApp
import jo.basket.utils.analytics.BasketAnalyticsManager

class CartViewProductAdapter (): BaseRecyclerViewAdapter<ProductImages, RecyclerAllItemCartProductBinding>() {

    override val layoutId: Int
        get() = R.layout.recycler_all_item_cart_product

    var serviceType: Int = 0
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

        return StoreTypeViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as StoreTypeViewHolder
        val cartList = items[position]

        val context = holder.binding.root.context

        // Set store Logo Image
        GlideApp.with(context).load(cartList.productImage ?: "").diskCacheStrategy(
            DiskCacheStrategy.ALL
        ).fitCenter().into(holder.binding.ivProduct)

    }

    override fun getItemCount(): Int {
        return items.size
    }

    inner class StoreTypeViewHolder(val binding: RecyclerAllItemCartProductBinding) :
        RecyclerView.ViewHolder(binding.root)

}