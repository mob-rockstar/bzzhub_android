package jo.basket.ui.checkout.detail.product

import android.view.View
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import jo.basket.R
import jo.basket.data.local.prefs.PreferenceManager
import jo.basket.data.model.Product
import jo.basket.databinding.RecyclerItemCheckoutCartProductBinding
import jo.basket.ui.component.EditAmountPopup
import jo.basket.utils.FormatterUtils
import jo.basket.utils.GlideApp
import jo.basket.utils.ResUtils

class CheckoutCartProductViewHolder(
    val binding: RecyclerItemCheckoutCartProductBinding
) : RecyclerView.ViewHolder(binding.root) {

    fun update(
        product: Product,
        listener: CheckoutCartStoreAdapter.OnCartActionListener?,
        isGridView: Int?
    ) {
        binding.executePendingBindings()
        val context = binding.root.context

        // Set Product Image
        if (product.productImage != null) {
            GlideApp.with(context).load(product.productImage).diskCacheStrategy(
                DiskCacheStrategy.ALL
            ).fitCenter()
                .error(R.drawable.placeholder300x300).format(
                    DecodeFormat.PREFER_ARGB_8888
                ).into(binding.ivProduct)
        }
        // Set Product name and count
        binding.tvCount.text = FormatterUtils.formatDouble(product.cartQty)
        binding.tvProductName.text = product.name?.replace(
            "\n",
            ""
        )?.replace("\r", "")


        // If 'Note' is not empty, show Note
        binding.layoutNote.visibility =
            if (product.cartNotes.isNullOrEmpty()) View.GONE else View.VISIBLE

        binding.tvProductAmount.text =
            if (isGridView == 1) ""
            else {
                if (product.additionalQuestionAnswers != null && product.additionalQuestionAnswers != "") {
                    product.additionalQuestionAnswers?.replace("/", ",")
                } else {
                    if (product.soldPer == 1) {
                        context.resources.getString(
                            R.string.str_currency_format,
                            product.ourSellingPrice.toString(), PreferenceManager.userCurrencyCode,
                            "~ (${product.labelValue?.trim()}${product.unit?.trim()})"
                        )
                    } else {
                        context.resources.getString(
                            R.string.str_at_currency_per_formatter,
                            PreferenceManager.userCurrencyCode,
                            product.ourSellingPrice.toString(),
                            product.unit?.trim()
                        )
                    }
                }
            }

        binding.tvNote.text =
            FormatterUtils.formatHTMLString(
                """<span style='color:#43B02A'>
                |${ResUtils.getString(R.string.instructions)} </span> ${product.cartNotes!!}""".trimMargin()
            )

        binding.tvInstruction.text =
            if (product.cartNotes == null || product?.cartNotes!!.isEmpty()) ResUtils.getString(R.string.instructions)
            else ResUtils.getString(R.string.str_edit_instructions)

        //  Tap instruction Layout
        binding.layoutInstruction.setOnClickListener { listener?.onSelectProductInstruction(product) }
        //  Tap 'Remove'
        binding.layoutRemove.setOnClickListener { listener?.onRemoveProduct(product) }

        //  if (product.itemType == 1) {
        initAmountPopup(product, listener)
        //      }
    }

    private fun initAmountPopup(
        product: Product,
        listener: CheckoutCartStoreAdapter.OnCartActionListener?
    ) {
        val increment: Double
        var unit: String = ""

        if (product.soldPer == 2) {
            unit = product.unit ?: ""
            increment = when {
                unit.equals("g", true) -> {
                    50.0
                }

                product.allowGrams == 1 -> {
                    0.05
                }

                else -> {
                    0.25
                }
            }
        } else {
            increment = 1.0
        }
        binding.tvCount.setOnClickListener { v ->
            EditAmountPopup(
                if (product.cartQty != null && product.cartQty!! > 0) product.cartQty!! else increment,
                increment,
                unit,
                object : EditAmountPopup.OnDismissListener {
                    override fun onDismiss(amount: Double, isAmountPopupRunning: Boolean) {
                        if (product.statusAvailable == 0) {
                            Toast.makeText(
                                binding.root.context,
                                "Can't add out of stock product",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else if (product.cartQty != amount) {
                            listener?.onProductAmountChange(product, amount)
                        }
                    }
                }
            ).show(v)
        }
    }
}
