package jo.basket.ui.component.dialog.cancelorder

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.Window
import android.widget.EditText
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.widget.NestedScrollView
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import jo.basket.R
import jo.basket.data.model.CancelReason
import jo.basket.databinding.DialogCancelOrderBinding
import jo.basket.utils.PopupUtils
import timber.log.Timber

class CancelOrderDialog {

    private val reasons: ArrayList<CancelReason> = ArrayList()
    private var mCancelReason : CancelReason?= null
    private var tvConfirm: TextView?= null
    private var mContext: Context?= null
    private var otherOptionId: Int = 0
    private var edittextComment: EditText?= null
    private var nestedScrollView: NestedScrollView? = null
    private var tvBack: TextView ?= null

    private val adapter: CancelOrderAdapter = CancelOrderAdapter{cancelReason ->
        this.mCancelReason = cancelReason
        if (otherOptionId == cancelReason.id){
            edittextComment?.visibility = VISIBLE
            Handler(Looper.getMainLooper()).postDelayed({
                nestedScrollView?.smoothScrollTo(0, nestedScrollView?.bottom!!)
            }, 200)

            if (this.edittextComment?.text.toString().trim().isNotEmpty()){
                enableConfirmButton()
            }else disableConfirmButton()

            edittextComment?.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int,
                ) {

                }

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {

                }

                override fun afterTextChanged(s: Editable?) {
                    if (s.toString().trim().isNotEmpty()) {
                        enableConfirmButton()
                    } else{
                        disableConfirmButton()
                    }
                }
            })
        }else {
            edittextComment?.visibility = GONE
            enableConfirmButton()
        }

    }

    fun setReasons(reasonList: List<CancelReason>) {
        this.reasons.clear()
        this.reasons.addAll(reasonList)
        if (reasonList.isNotEmpty()){
            this.otherOptionId = reasonList[reasonList.size -1].id
        }

        adapter.setItems(reasons)
    }

    fun openDialog(context: Context, onConfirmed : (cancelReason: CancelReason, comment: String)-> Unit) {
        mContext = context

        val dialog = Dialog(context)
        val binding = DataBindingUtil.inflate<DialogCancelOrderBinding>(
            LayoutInflater.from(context),
            R.layout.dialog_cancel_order,
            null,
            false
        )

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(binding.root)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        binding.ivClose.setOnClickListener {
            dialog.dismiss()
        }
        nestedScrollView = binding.layoutBody
        edittextComment = binding.edittextComment
        tvConfirm = binding.tvSelect
        tvBack = binding.tvBack

        tvBack?.setOnClickListener {
            dialog.dismiss()
        }

        tvConfirm?.setOnClickListener {
            if (mCancelReason != null) {
                if ((edittextComment?.visibility == VISIBLE && edittextComment?.text.toString()
                        .trim().isNotEmpty()) || edittextComment?.visibility == GONE
                ) {
                    onConfirmed(
                        mCancelReason!!,
                        if (binding.edittextComment.visibility == VISIBLE)
                            binding.edittextComment.text.toString().trim()
                        else ""
                    )
                    dialog.dismiss()
                }
            }
        }

        dialog.setOnDismissListener {
            mCancelReason = null
        }

        binding.recyclerView.layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)

        binding.recyclerView.adapter = adapter
        PopupUtils.setDefaultDialogProperty(dialog)
        dialog.show()
    }

    private fun enableConfirmButton(){
        if (tvConfirm != null){
            tvConfirm?.isClickable = true
            tvConfirm?.isFocusable = true
            tvConfirm?.background = (ContextCompat.getDrawable(mContext!!,R.drawable.bg_round_green))
        }
    }

    private fun disableConfirmButton(){
        if (tvConfirm != null){
            tvConfirm?.isClickable = false
            tvConfirm?.isFocusable = false
            tvConfirm?.background = (ContextCompat.getDrawable(mContext!!,R.drawable.bg_round_grey_8dp))
        }
    }

    companion object {
        private var instance: CancelOrderDialog? = null
        private val Instance: CancelOrderDialog
            get() {
                if (instance == null) {
                    instance = CancelOrderDialog()
                }
                return instance!!
            }

        fun openDialog(context: Context, onConfirmed : (cancelReason: CancelReason, comment: String)-> Unit) {
            Instance.openDialog(context, onConfirmed)
        }

        fun setReasons(reasonList: List<CancelReason>) {
            Instance.setReasons(reasonList)
        }
    }
}