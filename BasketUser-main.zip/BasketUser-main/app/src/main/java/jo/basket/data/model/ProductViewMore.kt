package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.realm.RealmObject
import io.realm.RealmResults
import io.realm.annotations.LinkingObjects
import io.realm.annotations.PrimaryKey

open class ProductViewMore : RealmObject() {
    @LinkingObjects("productsViewMore")
    val subcategories: RealmResults<Category>? = null

    @PrimaryKey
    @SerializedName("product_id")
    @Expose
    var productId: Int? = null

    @SerializedName("popularity_index")
    @Expose
    var popularityIndex: Int? = null

    @SerializedName("product_name")
    @Expose
    var productName: String? = null

    @SerializedName("product_url")
    @Expose
    var productUrl: String? = null

    @SerializedName("description")
    @Expose
    var description: String? = null

    @SerializedName("product_image")
    @Expose
    var productImage: String? = null

    @SerializedName("product_info_image")
    @Expose
    var productInfoImage: String? = null

    @SerializedName("vendor_id")
    @Expose
    var vendorId: Int? = null

    @SerializedName("outlet_id")
    @Expose
    var outletId: Int? = null

    @SerializedName("our_selling_price")
    @Expose
    var ourSellingPrice: Double? = null

    @SerializedName("original_price")
    @Expose
    var originalPrice: Double? = null

    @SerializedName("tax_id")
    @Expose
    var taxId: Int? = null

    @SerializedName("tax_included")
    @Expose
    var taxIncluded: Int? = null

    @SerializedName("outlet_item_id")
    @Expose
    var outletItemId: Int? = null

    @SerializedName("sold_per")
    @Expose
    var soldPer: Int? = null

    @SerializedName("approx_weight")
    @Expose
    var approxWeight: Double? = null

    @SerializedName("size_label")
    @Expose
    var sizeLabel: Double? = null

    @SerializedName("label_value")
    @Expose
    var labelValue: String? = null

    @SerializedName("each_suffix")
    @Expose
    var eachSuffix: Double? = null

    @SerializedName("allow_grams")
    @Expose
    var allowGrams: Int? = null

    @SerializedName("brand_id")
    @Expose
    var brandId: Int? = null

    @SerializedName("created_date")
    @Expose
    var createdDate: String? = null

    @SerializedName("updated_date")
    @Expose
    var updatedDate: String? = null

    @SerializedName("final_our_selling_price")
    @Expose
    var productCount: Double? = null

    @SerializedName("product_cart")
    @Expose
    var productCart: Double? = null

    @SerializedName("cart_qty")
    @Expose
    var cartQty: Double? = null

    @SerializedName("is_favorited")
    @Expose
    var isFavorited: Int? = null

    @SerializedName("cart_notes")
    @Expose
    var cartNotes: String? = null

    @SerializedName("sold_per_label")
    @Expose
    var soldPerLabel: String? = null

    @SerializedName("unit")
    @Expose
    var unit: String? = null
    var finalOurSellingPrice: Double? = null

    @SerializedName("status_available")
    @Expose
    var statusAvailable: Int? = null

    @SerializedName("status_available_label")
    @Expose
    var statusAvailableLabel: String? = null

    @SerializedName("department_id")
    @Expose
    var departmentId: Int? = null

    @SerializedName("department_name")
    @Expose
    var departmentName: String? = null

    @SerializedName("aisle_id")
    @Expose
    var aisleId: Int? = null

    @SerializedName("aisle_name")
    @Expose
    var aisleName: String? = null
    var ordered: Boolean = false

    @SerializedName("promo_item")
    @Expose
    var promo_item: Int? = null

    @SerializedName("display_saving_per_unit")
    @Expose
    var display_saving_per_unit: String? = null

    @SerializedName("brand_title")
    @Expose
    var brand_title: String? = null
}