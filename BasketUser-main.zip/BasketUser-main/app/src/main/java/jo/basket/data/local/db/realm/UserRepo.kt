package jo.basket.data.local.db.realm

import jo.basket.data.model.User

class UserRepo : BaseRepo() {

    fun getByField(field: String?, value: String?, detached: Boolean = true): User? {
        var realmUser: User? = realm.where(User::class.java).equalTo(field ?: "", value).findFirst()
        if (detached && realmUser != null) {
            realmUser = realm.copyFromRealm<User>(realmUser)
        }
        return realmUser
    }

    fun save(user: User) {
        realm.executeTransaction { r -> r.copyToRealmOrUpdate(user) }
    }

    fun load(): User? {
        var realmUser: User? = realm.where(User::class.java).findFirst()
        if (realmUser != null) {
            realmUser = realm.copyFromRealm<User>(realmUser)
        }
        return realmUser
    }

    fun delete(realmUser: User) {
        if (realmUser.isValid) {
            realm.executeTransaction { realmUser.deleteFromRealm() }
        }
    }

    fun detach(user: User): User {
        return if (user.isManaged) {
            realm.copyFromRealm(user)
        } else {
            user
        }
    }
}