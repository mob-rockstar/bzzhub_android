package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


data class CancelReason(
    var id: Int,
    var name: String,
    @SerializedName("reason_en")
    @Expose
    var reason: String? = null
){
    override fun toString(): String {
        return name!!
    }
}