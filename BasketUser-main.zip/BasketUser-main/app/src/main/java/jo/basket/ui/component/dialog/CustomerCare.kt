package jo.basket.ui.component.dialog

import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.view.LayoutInflater
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.Window
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import jo.basket.R
import jo.basket.data.local.prefs.PreferenceManager
import jo.basket.data.model.ContactSettings
import jo.basket.data.model.PreferredPayment
import jo.basket.databinding.DialogHelpBinding
import jo.basket.utils.PopupUtils
import jo.basket.utils.analytics.BasketAnalyticsManager

//Dialog to show Options to contact Customer Support
class CustomerCare {

    fun openDialog(context: Context, contactSettings: ContactSettings, gotoLiveChat: () -> Unit) {
        val dialog = Dialog(context)
        val binding = DataBindingUtil.inflate<DialogHelpBinding>(
            LayoutInflater.from(context),
            R.layout.dialog_help,
            null,
            false
        )

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(binding.root)

        binding.tvEmail.text = contactSettings.contactMail
        binding.tvMobile.text = contactSettings.customerCare

        binding.layoutEmail.setOnClickListener {
            //Track Analytics
            BasketAnalyticsManager.helpChoice("Email")
            openEmailClient(context, contactSettings)
        }

        binding.layoutMobile.setOnClickListener {
            //Track Analytics
       //     BasketAnalyticsManager.helpCall()
            BasketAnalyticsManager.helpChoice("Mobile")
            openDialPad(context, contactSettings)
        }

        binding.ivClose.setOnClickListener {
            dialog.dismiss()
        }

        binding.layoutLiveChat.setOnClickListener {
            gotoLiveChat()
        }

        binding.layoutLiveChat.visibility =
            if (jo.basket.data.local.prefs.PreferenceManager.currentUserId == 0L) GONE else VISIBLE

        PopupUtils.setDefaultDialogProperty(dialog)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
    }

    //Open Email client to contact Customer Support
    private fun openEmailClient(context: Context, contactSettings: ContactSettings) {
        val i = Intent(Intent.ACTION_SEND)
        i.type = "message/rfc822"
        i.putExtra(
            Intent.EXTRA_EMAIL,
            arrayOf<String>(contactSettings.contactMail!!)
        )
        try {
            context.startActivity(Intent.createChooser(i, "Send mail..."))
        } catch (ex: ActivityNotFoundException) {
            Toast.makeText(context, "There are no email clients installed.", Toast.LENGTH_SHORT)
                .show()
        }
    }

    //Open Number Dial-Pad to contact Customer Support
    private fun openDialPad(context: Context, contactSettings: ContactSettings) {
        val intent = Intent(Intent.ACTION_DIAL)
        intent.data = Uri.parse("tel:" + contactSettings.customerCare)
        context.startActivity(intent)
    }

    companion object {
        private var instance: CustomerCare? = null
        private val Instance: CustomerCare
            get() {
                if (instance == null) {
                    instance = CustomerCare()
                }
                return instance!!
            }

        fun openDialog(context: Context, contactSettings: ContactSettings, gotoLiveChat: () -> Unit) {
            Instance.openDialog(context, contactSettings, gotoLiveChat)
        }
    }
}