package jo.basket.data.model


import com.google.gson.annotations.SerializedName

data class NotificationSettingsDetails(
    var id: Int?,
    @SerializedName("order_update_call_before_checkout")
    var orderUpdateCallBeforeCheckout: Int?,
    @SerializedName("order_update_push_notification")
    var orderUpdatePushNotification: Int?,
    @SerializedName("order_update_sms")
    var orderUpdateSms: Int?,
    @SerializedName("promo_marketing_email")
    var promoMarketingEmail: Int?,
    @SerializedName("promo_marketing_push_notification")
    var promoMarketingPushNotification: Int?,
    @SerializedName("promo_marketing_sms")
    var promoMarketingSms: Int?
)