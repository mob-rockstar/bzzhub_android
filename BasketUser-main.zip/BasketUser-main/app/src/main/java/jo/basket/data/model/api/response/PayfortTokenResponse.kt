package jo.basket.data.model.api.response

data class PayfortTokenResponse(
    val `data`: Data,
    val message: String,
    val status: Int
)

data class Data(
    val sdk_token: String
)