package jo.basket.ui.component.snack

import android.content.res.ColorStateList
import android.text.TextUtils
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.annotation.ColorInt
import androidx.annotation.StringRes
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.content.ContextCompat
import com.google.android.material.snackbar.BaseTransientBottomBar
import com.google.android.material.snackbar.BaseTransientBottomBar.BaseCallback.DISMISS_EVENT_ACTION
import jo.basket.R
import timber.log.Timber


class Snackbar(
    parent: ViewGroup,
    content: SnackbarView
) : BaseTransientBottomBar<Snackbar>(parent, content, content) {

    private var hasAction = false

    init {
        getView().setBackgroundColor(
            ContextCompat.getColor(
                view.context,
                android.R.color.transparent
            )
        )
        getView().setPadding(0, 0, 0, 0)
    }

    fun setText(message: CharSequence): Snackbar {
        val contentLayout = view.getChildAt(0) as SnackbarView

        contentLayout.tvMsg.text = message
        //Adjust text size base on text length
        if (message.toString().trim().length > 20) {
            contentLayout.tvMsg.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 13.3f)
        } else {
            contentLayout.tvMsg.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15.3f)
        }
        return this
    }

    fun setText(@StringRes resId: Int): Snackbar {
        return this.setText(context.getText(resId))
    }

    fun setAction(@StringRes resId: Int, listener: ((View) -> Unit)?): Snackbar {
        return this.setAction(context.getText(resId), listener)
    }

    // Set action text
    fun setAction(
        text: CharSequence?,
        listener: ((View) -> Unit)?
    ): Snackbar {
        val contentLayout = view.getChildAt(0) as SnackbarView
        val tv: TextView = contentLayout.tvAction
        if (!TextUtils.isEmpty(text) && listener != null) {
            this.hasAction = true
            tv.visibility = View.VISIBLE
            tv.text = text
            tv.setOnClickListener { view ->
                listener(view)
                dispatchDismiss(DISMISS_EVENT_ACTION)
            }
        } else {
            tv.visibility = View.GONE
            tv.setOnClickListener(null as View.OnClickListener?)
            this.hasAction = false
        }
        return this
    }

    fun setActionTextColor(colors: ColorStateList?): Snackbar {
        val contentLayout = view.getChildAt(0) as SnackbarView
        val tv: TextView = contentLayout.tvAction
        tv.setTextColor(colors)
        return this
    }

    fun setActionTextColor(@ColorInt color: Int): Snackbar {
        val contentLayout = view.getChildAt(0) as SnackbarView
        val tv: TextView = contentLayout.tvAction
        tv.setTextColor(color)
        return this
    }

    companion object {
        const val LENGTH_INDEFINITE = -2
        const val LENGTH_SHORT = -1
        const val LENGTH_LONG = 0

        fun make(
            view: View,
            message: String,
            duretion: Int,
            listener: View.OnClickListener? = null,
            action_lable: String? = null
        ): Snackbar {
            // We inflate our custom view
            try {

                // First we find a suitable parent for our custom view
                val parent = findSuitableParent(view) ?: throw IllegalArgumentException(
                    "No suitable parent found from the given view. Please provide a valid view."
                )

                val view = LayoutInflater.from(view.context).inflate(
                    R.layout.layout_snackbar,
                    parent,
                    false
                )
                val snackView = view.findViewById<SnackbarView>(R.id.snack_constraint)
                // We create and return our Snackbar
                snackView.tvMsg.text = message
                action_lable?.let {
                    snackView.tvAction.text = action_lable
                    snackView.tvAction.setOnClickListener {
                        listener?.onClick(snackView.tvAction)
                    }
                }

                return Snackbar(parent, snackView).setDuration(duretion)
            } catch (e: Exception) {
                Timber.v(e)
                throw java.lang.IllegalArgumentException("No suitable parent found from the given view. Please provide a valid view.")
            }

        }

        private fun findSuitableParent(startView: View): ViewGroup? {
            var view: View? = startView
            var fallback: ViewGroup? = null
            do {
                if (view is CoordinatorLayout) {
                    return view
                }
                if (view is FrameLayout) {
                    if (view.getId() == android.R.id.content) {
                        return view
                    }
                    fallback = view
                }
                if (view != null) {
                    val parent = view.parent
                    view = if (parent is View) parent else null
                }
            } while (view != null)
            return fallback
        }

    }

}