package jo.basket.ui.cart.deliveryslot

import android.content.Context
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import jo.basket.R
import jo.basket.data.model.DeliveryTime
import jo.basket.databinding.RecyclerItemCartDeliveryTimeBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter
import jo.basket.utils.FormatterUtils
import kotlinx.parcelize.Parcelize

class CartDeliveryTimeAdapter(private val mContext: Context) :
    BaseRecyclerViewAdapter<DeliveryTime, RecyclerItemCartDeliveryTimeBinding>() {

    override val layoutId: Int
        get() = R.layout.recycler_item_cart_delivery_time

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return TimeViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as TimeViewHolder
        val time = items[position]
        holder.binding.tvDeliveryLabel.text = time.deliveryTime
        // If Price is '0', set value as 'Free'
        holder.binding.tvDeliveryPrice.text =
            if (time.deliveryCharge!! == 0.0) mContext.resources.getString(R.string.str_free) else FormatterUtils.formatPrice(
                time.deliveryCharge!!
            )
    }

    inner class TimeViewHolder(val binding: RecyclerItemCartDeliveryTimeBinding) :
        RecyclerView.ViewHolder(binding.root)
}
