package jo.basket.data.local.db.realm

import jo.basket.data.model.ContactSettings

class ContactSettingRepo : BaseRepo() {

    fun save(contactSettings: ContactSettings) {
            realm.executeTransaction { r -> r.copyToRealmOrUpdate(contactSettings) }
    }

    fun load(): ContactSettings? {
        var realmContactSettings: ContactSettings? =
            realm.where(ContactSettings::class.java).findFirst()
        if (realmContactSettings != null) {
            realmContactSettings = realm.copyFromRealm<ContactSettings>(realmContactSettings)
        }
        return realmContactSettings
    }

    fun delete(contactSettings: ContactSettings) {
        if (contactSettings.isValid) {
            realm.executeTransaction { contactSettings.deleteFromRealm() }
        }
    }

    fun detach(contactSettings: ContactSettings): ContactSettings {
        return if (contactSettings.isManaged) {
            realm.copyFromRealm(contactSettings)
        } else {
            contactSettings
        }
    }
}