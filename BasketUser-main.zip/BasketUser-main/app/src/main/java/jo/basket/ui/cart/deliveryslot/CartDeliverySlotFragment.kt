package jo.basket.ui.cart.deliveryslot

import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import jo.basket.R
import jo.basket.data.model.api.response.DeliverySlotsResponse
import jo.basket.data.model.api.response.base.ErrorResponse
import jo.basket.databinding.FragmentCartDeliverySlotBinding
import jo.basket.di.Injectable
import jo.basket.ui.base.BaseDialogFragment
import jo.basket.ui.base.HandleResponse
import jo.basket.ui.cart.CartViewModel
import jo.basket.utils.NetworkUtils
import jo.basket.utils.ResUtils

// Screen to show Delivery Slot for Cart
class CartDeliverySlotFragment :
    BaseDialogFragment<FragmentCartDeliverySlotBinding?, CartViewModel>(),
    Injectable {

    var cartStoreSotAdapter: CartStoreSlotAdapter? = null
    override val layoutId: Int
        get() = R.layout.fragment_cart_delivery_slot

    override val viewModel: CartViewModel
        get() {
            return getViewModel(baseActivity, CartViewModel::class.java)
        }

    // Set Full screen
    override fun getTheme(): Int {
        return R.style.FullScreenDialogFragmentTheme
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        progressView = viewDataBinding?.progressBar
        initToolbar()
        initRecyclerView()
        getCartDeliverySlots()
    }

    // Init Toolbar title and action
    private fun initToolbar() {
        viewDataBinding?.toolbar!!.collapsingToolbar.title =
            baseActivity.resources.getString(R.string.cartTitle)

        viewDataBinding?.toolbar?.collapsingToolbar?.setExpandedTitleTypeface(
            ResUtils.getTypeFaceWithPath(ResUtils.getExpandedTitleFont())
        )
        viewDataBinding?.toolbar?.collapsingToolbar?.setCollapsedTitleTypeface(
            ResUtils.getTypeFaceWithPath(ResUtils.getCollapsedTitleFont())
        )
        viewDataBinding?.toolbar!!.ivBack.setOnClickListener { dismiss() }
    }

    // Set Recyclerview Title
    private fun initRecyclerView() {
        viewDataBinding?.recyclerView!!.layoutManager = LinearLayoutManager(baseActivity)
        cartStoreSotAdapter = CartStoreSlotAdapter(baseActivity)
        viewDataBinding?.recyclerView!!.adapter = cartStoreSotAdapter
    }

    // Get cart delivery slot list
    fun getCartDeliverySlots() {
/*        viewModel.getDeliverySlots(object : HandleResponse<DeliverySlotsResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                 if (NetworkUtils.isNetworkConnected(baseActivity) &&!(error?.message ?:"").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)) {
                    popBackStack()
                } else {
                    NetworkUtils.showNoInternetDialog(
                        baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    getCartDeliverySlots()
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(successResponse: DeliverySlotsResponse) {
                if (successResponse.code == 200 && successResponse.storeDeliverySlots != null) {
                    cartStoreSotAdapter?.setItems(viewModel.cartDeliveries!!)
                } else {
                    dismiss()
                }
            }
        })*/
    }

}