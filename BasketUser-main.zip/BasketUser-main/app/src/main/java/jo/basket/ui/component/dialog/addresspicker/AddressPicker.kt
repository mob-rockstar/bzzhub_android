package jo.basket.ui.component.dialog.addresspicker

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import androidx.databinding.DataBindingUtil
import jo.basket.R
import jo.basket.data.model.Address
import jo.basket.databinding.DialogPickAddressBinding
import android.graphics.drawable.ColorDrawable
import android.view.Window
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import jo.basket.utils.PopupUtils

class AddressPicker {

    private var adapter: AddressPickerAdapter = AddressPickerAdapter()
    private var currentAddressString : String = ""
    var isDialogRunning = false
    var dialog: Dialog ?= null

    fun setAddressList(context: Context, addressList: List<Address>) {
        adapter.mContext = context
        adapter.setItems(addressList)
    }

    fun openDialog(context: Context, locationEnabled: Boolean, listener: OnAddressPickListener?) {
        dialog = Dialog(context)
        isDialogRunning = true
        val binding = DataBindingUtil.inflate<DialogPickAddressBinding>(
            LayoutInflater.from(context),
            R.layout.dialog_pick_address,
            null,
            false
        )
        dialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog?.setContentView(binding.root)


        initRecyclerView(context, binding?.rvAddress!!)
        binding.ivClose.setOnClickListener {
            listener?.onClose()
        }

        adapter.setOnSelectListener(object : AddressPickerAdapter.SelectedListener {
            override fun onAddressSelected(address: Address) {
                dialog?.dismiss()
                listener?.onPick(address)
            }
        })

        binding.layoutAddHomeAddress.setOnClickListener{
            dialog?.dismiss()
            listener?.onAddHomeAddress()
        }

        binding.layoutAddWorkAddress.setOnClickListener {
            dialog?.dismiss()
            listener?.onAddWorkAddress()
        }

        binding.layoutAddOtherAddress.setOnClickListener {
            dialog?.dismiss()
            listener?.onAddOtherAddress()
        }

        dialog?.setOnDismissListener {
            isDialogRunning = false
        }

        PopupUtils.setDefaultDialogProperty(dialog!!)
        dialog!!.show()

    }

    fun dismissDialog(){
        dialog?.dismiss()
    }

    fun initRecyclerView(context: Context, recyclerView: RecyclerView) {
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = adapter
    }

    companion object {
        private var instance: AddressPicker? = null
        private val Instance: AddressPicker
            get() {
                if (instance == null) {
                    instance = AddressPicker()
                }
                return instance!!
            }

        fun setAddressList(context: Context, addresses: List<Address>) {
            Instance.setAddressList(context, addresses)
        }

        fun openDialog(context: Context, locationEnabled: Boolean, listener: OnAddressPickListener? = null) {
            Instance.openDialog(context, locationEnabled, listener)
        }

        fun setCurrentAddress(currentAddress: String) {
        }

        fun isDialogRunning(): Boolean{
            return Instance.isDialogRunning
        }

        fun dismissDialog(){
            return Instance.dismissDialog()
        }

    }

    interface OnAddressPickListener {
        fun onPick(address: Address)
        fun onAddHomeAddress()
        fun onAddWorkAddress()
        fun onAddOtherAddress()
        fun onClose()
    }
}