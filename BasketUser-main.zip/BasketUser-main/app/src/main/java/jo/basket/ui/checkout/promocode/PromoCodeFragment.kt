package jo.basket.ui.checkout.promocode

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import jo.basket.R
import jo.basket.data.model.api.response.SimpleResponse
import jo.basket.data.model.api.response.base.ErrorResponse
import jo.basket.databinding.DialogCheckoutPromoBinding
import jo.basket.di.Injectable
import jo.basket.ui.base.BaseInputDialogFragment
import jo.basket.ui.base.HandleResponse
import jo.basket.ui.checkout.CheckoutViewModel
import jo.basket.utils.*
import jo.basket.utils.analytics.BasketAnalyticsManager
import org.greenrobot.eventbus.EventBus

// Promo Code screen for Cart
class PromoCodeFragment : BaseInputDialogFragment<DialogCheckoutPromoBinding?, CheckoutViewModel>(),
    Injectable {

    private var promoCode: String = ""

    override val layoutId: Int
        get() = R.layout.dialog_checkout_promo

    override val viewModel: CheckoutViewModel
        get() {
            return getViewModel(baseActivity, CheckoutViewModel::class.java)
        }

    // Set full screen theme
    override fun getTheme(): Int {
        return R.style.FullScreenDialogFragmentTheme
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initToolbar()

        viewDataBinding!!.tvInvalid.visibility = View.GONE

        //Enable or disable 'Redeem' button base on promo code content
        viewDataBinding!!.etPromoCode.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                promoCode = viewDataBinding!!.etPromoCode.text.toString().trim()
                if (promoCode.isEmpty()) {
                    setRedeemButtonEnabled(false)
                } else {
                    setRedeemButtonEnabled(true)
                }
            }

            override fun afterTextChanged(s: Editable) {}
        })

        // Redeem button disabled by default
        setRedeemButtonEnabled(false)
        viewDataBinding!!.btRedeem.setOnClickListener { addPromoCode() }
    }

    private fun initToolbar() {
        viewDataBinding!!.toolbar.ivBack.setOnClickListener { dismiss() }
        viewDataBinding!!.toolbar.tvTitle.text = resources.getString(R.string.promo_codes)
    }

    private fun setRedeemButtonEnabled(isEnabled: Boolean) {
        viewDataBinding!!.btRedeem.isEnabled = isEnabled
        viewDataBinding!!.btRedeem.isClickable = isEnabled
        if (isEnabled) {
            viewDataBinding!!.btRedeem.background =
                ContextCompat.getDrawable(baseActivity, R.drawable.bg_round_green)
            viewDataBinding!!.btRedeem.setTextColor(
                ContextCompat.getColor(
                    baseActivity,
                    R.color.md_white_1000
                )
            )
        } else {
            viewDataBinding!!.btRedeem.background =
                ContextCompat.getDrawable(baseActivity, R.drawable.bg_round_grey_light)
            viewDataBinding!!.btRedeem.setTextColor(
                ContextCompat.getColor(
                    baseActivity,
                    R.color.md_grey_600
                )
            )
        }
    }

    // Open add-promo success dialog
    private fun openSuccessDialog() {

        PopupUtils.showAlertDialog(baseActivity,baseActivity.resources.getString(R.string.promo_code),
            ResUtils.getString(R.string.str_promo_code_added_successfully))
/*
        val dialog = Dialog(baseActivity)

        val view = LayoutInflater.from(baseActivity).inflate(R.layout.dialog_confirm_success, null)

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(view)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val layoutOutside = view.findViewById(R.id.layout_outside) as LinearLayout
        layoutOutside.setOnClickListener {
            dialog.dismiss()
            dismiss()
        }

        val tvOk = view.findViewById(R.id.tv_ok) as TextView
        tvOk.setOnClickListener {
            dialog.dismiss()
            dismiss()
        }
        PopupUtils.setDefaultDialogProperty(dialog)
        dialog.show()*/
    }


    // Add promo code to cart
    private fun addPromoCode() {
        viewDataBinding!!.tvInvalid.visibility = View.GONE
        viewModel.addPromoCodeToCart(promoCode, object : HandleResponse<SimpleResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                 if (NetworkUtils.isNetworkConnected(baseActivity) &&!(error?.message ?:"").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)) {
                    this@PromoCodeFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    NetworkUtils.showNoInternetDialog(
                        baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    addPromoCode()
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(response: SimpleResponse) {
                if (response.code == 200) {
                    //Broadcast event 'Promo code added' so checkout detail information could be updated
                    EventBus.getDefault()
                        .post(MessageEvent(AppConstants.MESSAGE_PROMO_CODE_CHANGED))
                    openSuccessDialog()
                } else {
                    viewDataBinding!!.tvInvalid.text = response.message ?: ""
                    viewDataBinding!!.tvInvalid.visibility = View.VISIBLE
                }
            }
        })
    }
}