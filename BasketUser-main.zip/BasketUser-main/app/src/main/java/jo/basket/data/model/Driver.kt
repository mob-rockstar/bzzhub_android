package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Driver {

    @SerializedName("driver_id")
    @Expose
    var id: Int = 0

    @SerializedName("driver_first_name")
    @Expose
    var firstName: String? = null

    @SerializedName("driver_last_name")
    @Expose
    var lastName: String? = null

    @SerializedName("driver_mobile_number")
    @Expose
    var mobileNumber: String? = null

    @SerializedName("driver_image")
    @Expose
    var image: String? = null

}