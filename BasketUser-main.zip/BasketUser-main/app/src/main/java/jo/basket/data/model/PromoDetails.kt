package jo.basket.data.model

import com.google.gson.annotations.SerializedName
import io.realm.RealmObject


open class PromoDetails : RealmObject() {

    @field:SerializedName("promo_code")
    var promoCode: String? = null

    @field:SerializedName("title")
    var title: String? = null

    @field:SerializedName("description")
    var description: String? = null

    @field:SerializedName("overall_promo_total_amount")
    var amount: Double? = null

}