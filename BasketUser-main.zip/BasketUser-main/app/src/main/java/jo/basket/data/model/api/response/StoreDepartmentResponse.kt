package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.Department
import jo.basket.data.model.OutletDetails


class StoreDepartmentResponse {

    @field:SerializedName("httpCode")
    var code: Int? = 0

    @field:SerializedName("Message")
    var message: String? = null

    @field:SerializedName("department_list")
    val departments: List<Department>? = null

    @field:SerializedName("outlet_details")
    val outletDetail: OutletDetails? = null

}