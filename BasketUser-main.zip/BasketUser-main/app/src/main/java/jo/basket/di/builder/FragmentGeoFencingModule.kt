package jo.basket.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector
import jo.basket.ui.geofencing.map.PickLocationFragment
import jo.basket.ui.geofencing.suggestion.GeoFencingAddressSuggestionFragment

@Module
abstract class FragmentGeoFencingModule {

    @ContributesAndroidInjector
    abstract fun contributePickLocationFragment(): PickLocationFragment

    @ContributesAndroidInjector
    abstract fun contributeGeoFencingAddressSuggestionFragment(): GeoFencingAddressSuggestionFragment
}