package jo.basket.ui.base

import jo.basket.data.model.api.response.base.ErrorResponse

interface HandleResponse<T> {

    fun handleErrorResponse(error: ErrorResponse?)
    fun handleSuccessRespons(successResponse: T)

}