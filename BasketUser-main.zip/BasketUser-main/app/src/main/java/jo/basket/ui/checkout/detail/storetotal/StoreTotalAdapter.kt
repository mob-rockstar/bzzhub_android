package jo.basket.ui.checkout.detail.storetotal

import android.text.Spanned
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import jo.basket.R
import jo.basket.data.local.prefs.PreferenceManager
import jo.basket.data.model.Cart
import jo.basket.databinding.RecyclerItemCheckoutSubtotalBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter
import jo.basket.utils.FormatterUtils
import java.util.*

class StoreTotalAdapter : BaseRecyclerViewAdapter<Cart, RecyclerItemCheckoutSubtotalBinding>() {


    override val layoutId: Int
        get() = R.layout.recycler_item_checkout_subtotal

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = createBindedView(viewGroup)
        return StoreTotalViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as StoreTotalViewHolder
        val context = viewHolder.itemView.context

        val cart = items[position]
        holder.binding.tvStoreName.text =
            if (items.size == 1)
                context.resources.getString(R.string.sub_total)
            else cart.displayName

        holder.binding.tvSubTotal.text = formatPrice(cart.outletSubtotal)

    }

    private fun formatPrice(price: Double?): Spanned? { //Formatting Price
        val priceString = String.format(Locale.US, "%.2f", price ?: 0.0)
        return FormatterUtils.formatHTMLString("$priceString ${PreferenceManager.userCurrencyCode}")
    }

    inner class StoreTotalViewHolder(val binding: RecyclerItemCheckoutSubtotalBinding) :
        RecyclerView.ViewHolder(binding.root)
}