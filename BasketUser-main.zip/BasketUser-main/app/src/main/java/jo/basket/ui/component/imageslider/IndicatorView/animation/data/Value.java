package jo.basket.ui.component.imageslider.IndicatorView.animation.data;

public interface Value {/*empty*/}
