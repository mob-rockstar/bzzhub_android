package jo.basket.di.factory

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider.NewInstanceFactory
import jo.basket.ui.accountsetting.AccountSettingViewModel
import jo.basket.ui.cart.CartViewModel
import jo.basket.ui.checkout.CheckoutViewModel
import jo.basket.ui.deliverypricing.DeliveryTimeViewModel
import jo.basket.ui.deliverypromotion.DeliveryPromotionViewModel
import jo.basket.ui.forgotpassword.ForgotPasswordViewModel
import jo.basket.ui.freedelivery.FreeDeliveryViewModel
import jo.basket.ui.geofencing.GeoFencingViewModel
import jo.basket.ui.guid.GuidViewModel
import jo.basket.ui.invitefriend.InviteFriendViewModel
import jo.basket.ui.language.LanguageViewModel
import jo.basket.ui.location.LocationViewModel
import jo.basket.ui.login.LoginViewModel
import jo.basket.ui.main.MainViewModel
import jo.basket.ui.membership.MembershipViewModel
import jo.basket.ui.notification.NotificationViewModel
import jo.basket.ui.nps.NPSViewModel
import jo.basket.ui.order.OrderViewModel
import jo.basket.ui.payment.PaymentViewModel
import jo.basket.ui.product.ProductViewModel
import jo.basket.ui.profile.ProfileViewModel
import jo.basket.ui.promocodes.PromoCodesViewModel
import jo.basket.ui.replacementsuggestion.CartReplacementViewModel
import jo.basket.ui.restaurant.RestaurantViewModel
import jo.basket.ui.reward.RewardViewModel
import jo.basket.ui.servicelist.ServiceListViewModel
import jo.basket.ui.shoppinglist.ShoppingListViewModel
import jo.basket.ui.splash.SplashViewModel
import jo.basket.ui.store.StoreViewModel
import jo.basket.ui.terms.TermsAndPolicyViewModel
import jo.basket.ui.wallet.WalletViewModel
import javax.inject.Inject
import javax.inject.Singleton


@Singleton
class ViewModelProviderFactory @Inject constructor() : NewInstanceFactory() {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        when {
            modelClass.isAssignableFrom(SplashViewModel::class.java) -> {
                return SplashViewModel() as T
            }
            modelClass.isAssignableFrom(LoginViewModel::class.java) -> {
                return LoginViewModel() as T
            }
            modelClass.isAssignableFrom(ForgotPasswordViewModel::class.java) -> {
                return ForgotPasswordViewModel() as T
            }
            modelClass.isAssignableFrom(LocationViewModel::class.java) -> {
                return LocationViewModel() as T
            }
            modelClass.isAssignableFrom(TermsAndPolicyViewModel::class.java) -> {
                return TermsAndPolicyViewModel() as T
            }
            modelClass.isAssignableFrom(MainViewModel::class.java) -> {
                return MainViewModel() as T
            }
            modelClass.isAssignableFrom(StoreViewModel::class.java) -> {
                return StoreViewModel() as T
            }
            modelClass.isAssignableFrom(DeliveryPromotionViewModel::class.java) -> {
                return DeliveryPromotionViewModel() as T
            }
            modelClass.isAssignableFrom(ProductViewModel::class.java) -> {
                return ProductViewModel() as T
            }
            modelClass.isAssignableFrom(CartViewModel::class.java) -> {
                return CartViewModel() as T
            }
            modelClass.isAssignableFrom(CheckoutViewModel::class.java) -> {
                return CheckoutViewModel() as T
            }
            modelClass.isAssignableFrom(PaymentViewModel::class.java) -> {
                return PaymentViewModel() as T
            }
            modelClass.isAssignableFrom(OrderViewModel::class.java) -> {
                return OrderViewModel() as T
            }
            modelClass.isAssignableFrom(NotificationViewModel::class.java) -> {
                return NotificationViewModel() as T
            }
            modelClass.isAssignableFrom(PromoCodesViewModel::class.java) -> {
                return PromoCodesViewModel() as T
            }
            modelClass.isAssignableFrom(ProfileViewModel::class.java) -> {
                return ProfileViewModel() as T
            }
            modelClass.isAssignableFrom(AccountSettingViewModel::class.java) -> {
                return AccountSettingViewModel() as T
            }
            modelClass.isAssignableFrom(DeliveryTimeViewModel::class.java) -> {
                return DeliveryTimeViewModel() as T
            }
            modelClass.isAssignableFrom(GuidViewModel::class.java) -> {
                return GuidViewModel() as T
            }
            modelClass.isAssignableFrom(MembershipViewModel::class.java) -> {
                return MembershipViewModel() as T
            }
            modelClass.isAssignableFrom(GeoFencingViewModel::class.java) -> {
                return GeoFencingViewModel() as T
            }
            modelClass.isAssignableFrom(FreeDeliveryViewModel::class.java) -> {
                return FreeDeliveryViewModel() as T
            }
            modelClass.isAssignableFrom(CartReplacementViewModel::class.java) -> {
                return CartReplacementViewModel() as T
            }
            modelClass.isAssignableFrom(RewardViewModel::class.java) -> {
                return RewardViewModel() as T
            }
            modelClass.isAssignableFrom(WalletViewModel::class.java) -> {
                return WalletViewModel() as T
            }
            modelClass.isAssignableFrom(NPSViewModel::class.java) -> {
                return NPSViewModel() as T
            }
            modelClass.isAssignableFrom(InviteFriendViewModel::class.java) -> {
                return InviteFriendViewModel() as T
            }
            modelClass.isAssignableFrom(LanguageViewModel::class.java) -> {
                return LanguageViewModel() as T
            }
            modelClass.isAssignableFrom(ShoppingListViewModel::class.java) -> {
                return ShoppingListViewModel() as T
            }
            modelClass.isAssignableFrom(RestaurantViewModel::class.java) -> {
                return RestaurantViewModel() as T
            }
            modelClass.isAssignableFrom(ServiceListViewModel::class.java) -> {
                return ServiceListViewModel() as T
            }
            else -> throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
        }
    }
}
