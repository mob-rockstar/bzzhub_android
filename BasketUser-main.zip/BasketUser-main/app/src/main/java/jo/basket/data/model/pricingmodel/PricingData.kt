package jo.basket.data.model.pricingmodel


import com.google.gson.annotations.SerializedName

data class PricingData(
    @SerializedName("outlet_delivery_info")
    var outletDeliveryInfo: OutletDeliveryInfo,
    @SerializedName("outlet_info")
    var outletInfo: OutletInfo,
    @SerializedName("outlet_opening_hours")
    var outletOpeningHours: OutletOpeningHours
)