package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


open class ShoppedProduct {

    @SerializedName("item_type")
    @Expose
    var itemType: Int? = null

    @SerializedName("outlet_item_id")
    @Expose
    var outletItemId: Int? = null

    @SerializedName("product_name")
    @Expose
    var productName: String? = null

    @SerializedName("product_image")
    @Expose
    var productImage: String? = null

    @SerializedName("product_info_image")
    @Expose
    var productInfoImage: String? = null

    @SerializedName("sold_per")
    @Expose
    var soldPer: Int? = null

    @SerializedName("sold_per_label")
    @Expose
    var soldPerLabel: String? = null

    @SerializedName("label_value")
    @Expose
    var labelValue: String? = null

    @SerializedName("size_label")
    @Expose
    var sizeLabel: Int? = null

    @SerializedName("each_suffix")
    @Expose
    var eachSuffix: Int? = null

    @SerializedName("actual_approx_weight")
    @Expose
    var actualApproxWeight: String? = null

    @SerializedName("actual_selling_price")
    @Expose
    var actualSellingPrice: Double? = null

    @SerializedName("actual_item_unit_price")
    @Expose
    var actualItemUnitPrice: Double? = null

    @SerializedName("unit")
    @Expose
    var unit: String? = null

    @SerializedName("actual_qty")
    @Expose
    var actualQty: Double? = null

    @SerializedName("actual_item_total")
    @Expose
    var actualItemTotal: Double? = null

    @SerializedName("customer_item_notes")
    @Expose
    var customerItemNotes: String? = null

}