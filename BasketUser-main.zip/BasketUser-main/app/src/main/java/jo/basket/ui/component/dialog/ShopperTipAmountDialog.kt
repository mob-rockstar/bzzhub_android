package jo.basket.ui.component.dialog

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.Window
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import jo.basket.R
import jo.basket.databinding.DialogEnterShopperTipBinding
import jo.basket.utils.PopupUtils

class ShopperTipAmountDialog {

    lateinit var dialog: Dialog

    fun openDialog(context: Context, onOK: (amount: Float) -> Unit) {
        val dialog = Dialog(context)
        val binding = DataBindingUtil.inflate<DialogEnterShopperTipBinding>(
            LayoutInflater.from(context),
            R.layout.dialog_enter_shopper_tip,
            null,
            false
        )
        this@ShopperTipAmountDialog.dialog = dialog

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(binding.root)

        binding.apply {
            tvRedeem.setOnClickListener {
                val amount = etAmount.text.toString().trim()
                if (amount.toFloatOrNull() != null){
                    onOK(amount.toFloat())
                    dismissDialog()
                }else{
                    Toast.makeText(context, "Enter valid amount", Toast.LENGTH_LONG).show()
                }
            }

            tvCancel.setOnClickListener {
                dismissDialog()
            }
        }


        PopupUtils.setDefaultDialogProperty(dialog)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
    }

    fun dismissDialog() {
        dialog.dismiss()
    }

    companion object {
        private var instance: ShopperTipAmountDialog? = null


        private val Instance: ShopperTipAmountDialog
            get() {
                if (instance == null) {
                    instance = ShopperTipAmountDialog()
                }
                return instance!!
            }

        fun openDialog(context: Context, onOK :(amount: Float) -> Unit) {
            Instance.openDialog(context){
                amount -> onOK(amount)
            }
        }
    }

    interface OnSelectedListener {
        fun onSelected(position: Int)
    }
}