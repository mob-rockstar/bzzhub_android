package jo.basket.ui.component.dialog.payment

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.Window
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import jo.basket.R
import jo.basket.data.model.PaymentMethod
import jo.basket.databinding.DialogMembershipPaymentBinding
import jo.basket.utils.PopupUtils

class MembershipPaymentDialog {

    private var dialog: Dialog ?= null
    private val paymentMethods: ArrayList<PaymentMethod> = ArrayList()
    private var mContext: Context ?= null
    private var onApplyPaymentListener: OnApplyPaymentListener? = null

    private val adapter: MembershipPaymentAdapter = MembershipPaymentAdapter(){
        paymentMethods->
        onItemSelected(paymentMethods)
    }

    fun setPaymentMethods(paymentList: List<PaymentMethod>) {
        this.paymentMethods.clear()
        this.paymentMethods.addAll(paymentList)
        adapter.setItems(paymentMethods)
    }

    fun openDialog(context: Context,onApplyPaymentListener: OnApplyPaymentListener,
    onAddCreditCard: ()-> Unit) {
        mContext = context
        dialog = Dialog(context)

        val binding = DataBindingUtil.inflate<DialogMembershipPaymentBinding>(
            LayoutInflater.from(context),
            R.layout.dialog_membership_payment,
            null,
            false
        )
        this.onApplyPaymentListener = onApplyPaymentListener

        dialog!!.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog!!.setContentView(binding.root)
        dialog!!.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        binding.ivCancel.setOnClickListener {
            dialog!!.dismiss()
        }

        binding.tvAddCreditCard.setOnClickListener {
            onAddCreditCard()
        }

        binding.recyclerView.layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)

        adapter.setItems(paymentMethods)
        binding.recyclerView.adapter = adapter
        PopupUtils.setDefaultDialogProperty(dialog!!)
        dialog!!.show()

    }

    fun onItemSelected(paymentMethod: PaymentMethod){
        dialog!!.dismiss()
        onApplyPaymentListener?.onApply(paymentMethod)
    }

    companion object {
        private var instance: MembershipPaymentDialog? = null
        private val Instance: MembershipPaymentDialog
            get() {
                if (instance == null) {
                    instance = MembershipPaymentDialog()
                }
                return instance!!
            }

        fun openDialog(context: Context, onApplyPaymentListener: OnApplyPaymentListener, onAddCreditCard: () -> Unit) {
            Instance.openDialog(context, onApplyPaymentListener, onAddCreditCard)
        }

        fun setPaymentMethods(paymentList: List<PaymentMethod>) {
            Instance.setPaymentMethods(paymentList)
        }
    }

    interface OnApplyPaymentListener {
        fun onApply(selectedPayment : PaymentMethod)
    }
}