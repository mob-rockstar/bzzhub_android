package jo.basket.service

import android.app.PendingIntent
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import androidx.core.app.NotificationCompat.*
import androidx.core.content.ContextCompat
import com.braze.push.BrazeFirebaseMessagingService
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import jo.basket.BasketApp
import jo.basket.R
import jo.basket.data.local.prefs.PreferenceManager
import jo.basket.ui.main.MainActivity
import jo.basket.ui.notification.NotificationListActivity
import jo.basket.ui.order.OrderActivity
import jo.basket.ui.store.StoreActivity
import jo.basket.utils.AppConstants
import jo.basket.utils.AppConstants.ARG_BY
import jo.basket.utils.AppConstants.ARG_REDIRECTION_FROM
import jo.basket.utils.AppConstants.ARG_REDIRECTION_TO
import jo.basket.utils.AppConstants.ARG_TITLE
import jo.basket.utils.AppConstants.ARG_USER_ID
import jo.basket.utils.AppConstants.KEY_TYPE_ZENDESK_CHAT
import jo.basket.utils.MessageEvent
import jo.basket.utils.NotificationUtils
import me.leolin.shortcutbadger.ShortcutBadger
import org.greenrobot.eventbus.EventBus
import org.json.JSONObject
import timber.log.Timber
import java.io.IOException
import java.net.URL

//Firebase Messaging Service class
class FCMService : FirebaseMessagingService() {

    private var ARG_IMAGE: String = "image"

    //When received Notification From the Firebase
    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Timber.tag("notificationPayLoad").d(remoteMessage.data.toString())
        when {

            BrazeFirebaseMessagingService.handleBrazeRemoteMessage(this, remoteMessage) -> {
                // This Remote Message originated from Braze and a push notification was displayed.
                // No further action is needed.
                val intent = Intent(this, MainActivity::class.java)
                intent.putExtra(ARG_REDIRECTION_FROM, "braze")
                intent.putExtra("url", remoteMessage.data["uri"].toString())

       //         val notification = BrazeNotificationFactory.getInstance().createNotification(remoteMessage as BrazeNotificationPayload)

            }
            remoteMessage.data.isNotEmpty() -> {
                Timber.tag("notificationPayLoad").d("Data is Not Null")
                val builder = Builder(this, BASKET_CHANNEL_NAME)
                try {
                    if (remoteMessage.data[KEY_PAYLOAD] != null) {
                        //        val pushData: PushData =
                        //              pushNotificationsProvider.processPushNotification(remoteMessage.data)
                        var intent = Intent(this, OrderActivity::class.java)
                        val payloadJson = JSONObject(remoteMessage.data[KEY_PAYLOAD]!!)
                        var image: String? = null
                        var orderStatus = 0
                        var title = ""
                        var content = remoteMessage.data[KEY_BODY]
                        when (val messageType =
                            payloadJson.getString(AppConstants.KEY_NOTIFICATION_TYPE)) {
                            //Notification from the Admin Panel (Promo-codes and others update)
                            AppConstants.KEY_TYPE_ADMIN -> {

                                PreferenceManager
                                intent = if (payloadJson.has(ARG_REDIRECTION_TO) && payloadJson.get(
                                        ARG_REDIRECTION_TO
                                    ).toString().isNotEmpty() && payloadJson.get(
                                        ARG_REDIRECTION_TO
                                    ).toString() != "0"
                                ) {
                                    PreferenceManager.currentUserStoreId = payloadJson.getInt(
                                        ARG_REDIRECTION_TO
                                    )
                                    Intent(this, StoreActivity::class.java)
                                } else {
                                    Intent(this, NotificationListActivity::class.java)
                                }
                                intent.putExtra(ARG_REDIRECTION_FROM, "notification")
                                image = if (payloadJson.has(ARG_IMAGE)) {
                                    payloadJson.getString(ARG_IMAGE)
                                } else ""
                                title = ""

                                if (true){
                                    val redirectionValue  =  (payloadJson.get(ARG_REDIRECTION_TO).toString().toIntOrNull())
                                    PreferenceManager.lastReceivedStorePayload = redirectionValue ?: 0
                                    PreferenceManager.lastReceivedImagePayload =
                                        if (payloadJson.has(ARG_IMAGE)) {
                                            payloadJson.getString(ARG_IMAGE)
                                        } else ""
                                    PreferenceManager.lastReceivedPopupText = if (payloadJson.has("popup_button_text")) {
                                        payloadJson.getString("popup_button_text")
                                    } else ""
                                    PreferenceManager.lastReceivedMessage = remoteMessage.data[KEY_BODY] ?: ""
                                    PreferenceManager.lastReceivedTitle = remoteMessage.data[KEY_TITLE] ?: ""
                                }
                            }

                            // User's First Order
                            AppConstants.KEY_TYPE_FIRST_ORDER -> {
                                intent = Intent(this, MainActivity::class.java)
                                intent.putExtra(AppConstants.ARG_FIRST_ORDER, true)
                            }
                            //New Device Login Notification
                            AppConstants.KEY_TYPE_LOGOUT -> {
                                title = ""
                            }

                            AppConstants.KEY_TYPE_SILENT_NOTIFICATION -> {
                                val badgeCount = remoteMessage.data["badge"]?.toIntOrNull()
                                if (badgeCount != null) {
                                    ShortcutBadger.applyCount(applicationContext, badgeCount)
                                }
                            }

                            else -> {
                                if (payloadJson.has(AppConstants.ARG_ORDER_STATUS)) {
                                    orderStatus = payloadJson.getInt(AppConstants.ARG_ORDER_STATUS)
                                }
                                if (orderStatus != 1 && messageType != AppConstants.KEY_TYPE_NEW_MESSAGE) {
                                    intent = Intent(this, OrderActivity::class.java)
                                    intent.putExtra(AppConstants.KEY_NOTIFICATION_TYPE, messageType)
                                } else {
                                    intent = Intent(this, MainActivity::class.java)
                                    intent.putExtra(
                                        AppConstants.ARG_DEFAULT_TAB,
                                        if (orderStatus == 1) 1 else 2
                                    )
                                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }

                                when (messageType) {
                                    //New Chat Message from the Shopper
                                    AppConstants.KEY_TYPE_NEW_MESSAGE -> {
                                        intent.putExtra(
                                            AppConstants.ARG_ORDER_STORE_ID, payloadJson.getInt(
                                                AppConstants.ARG_ORDER_ID
                                            )
                                        )
                                        //    image = if (remoteMessage.data.containsKey(ARG_IMAGE)) {
                                        //        remoteMessage.data[ARG_IMAGE]
                                        //     }else ""
                                        val shopperName =
                                            if (remoteMessage.data.containsKey(ARG_TITLE)) {
                                                remoteMessage.data[ARG_TITLE].toString()
                                            } else ""
                                        val shopperId = if (payloadJson.has(ARG_BY)) {
                                            val shopperDetail =
                                                JSONObject(payloadJson[ARG_BY]!!.toString())
                                            if (shopperDetail.has(ARG_USER_ID)) {
                                                shopperDetail[ARG_USER_ID].toString().toInt()
                                            } else 0
                                        } else {
                                            0
                                        }
                                        val shopperImage = if (payloadJson.has("user_photo")) {
                                            payloadJson.get("user_photo").toString()
                                        } else ""
                                        intent.putExtra(AppConstants.KEY_NOTIFICATION_TYPE, messageType)
                                        intent.putExtra(ARG_USER_ID, shopperId)
                                        intent.putExtra(ARG_TITLE, shopperName)
                                        intent.putExtra(ARG_IMAGE, shopperImage)
                                        title = ""

                                    }
                                    AppConstants.KEY_TYPE_ORDER_ITEM_UPDATE -> {
                                        //   intent.putExtra(ARG_ORDER_STATUS, payloadJson.getInt(ARG_ORDER_STATUS))
                                        intent.putExtra(
                                            AppConstants.ARG_ORDER_ID,
                                            payloadJson.getInt(AppConstants.ARG_ORDER_ID)
                                        )
                                        intent.putExtra(
                                            AppConstants.ARG_ORDER_STORE_ID,
                                            payloadJson.getInt(AppConstants.ARG_ORDERS_OUTLETS_ID)
                                        )
                                        intent.putExtra(
                                            AppConstants.ARG_OUTLET_ID,
                                            payloadJson.getInt(AppConstants.ARG_OUTLET_ID)
                                        )

                                        title = if (payloadJson.has("sender_name")) {
                                            payloadJson.get("sender_name").toString()
                                        } else ""

                                        image = if (remoteMessage.data[ARG_IMAGE] != null) {
                                            remoteMessage.data[ARG_IMAGE].toString()
                                        } else ""
                                        intent.putExtra(AppConstants.KEY_NOTIFICATION_TYPE, messageType)
                                    }

                                    // Order Update notification from the server
                                    AppConstants.KEY_TYPE_ORDER_UPDATE -> {
                                        //   intent.putExtra(ARG_ORDER_STATUS, payloadJson.getInt(ARG_ORDER_STATUS))
                                        intent.putExtra(
                                            AppConstants.ARG_ORDER_ID,
                                            payloadJson.getInt(AppConstants.ARG_ORDER_ID)
                                        )
                                        if (payloadJson.has(AppConstants.ARG_ORDERS_OUTLETS_ID)) {
                                            intent.putExtra(
                                                AppConstants.ARG_ORDER_STORE_ID,
                                                payloadJson.getInt(AppConstants.ARG_ORDERS_OUTLETS_ID)
                                            )
                                        }
                                        if (payloadJson.has(AppConstants.ARG_STORE_ID)) {
                                            intent.putExtra(
                                                AppConstants.ARG_STORE_ID,
                                                payloadJson.getInt(AppConstants.ARG_STORE_ID)
                                            )
                                        }

                                        title = if (payloadJson.has("sender_name")) {
                                            payloadJson.get("sender_name").toString()
                                        } else ""

                                        intent.putExtra(AppConstants.KEY_NOTIFICATION_TYPE, messageType)
                                        image = if (remoteMessage.data[ARG_IMAGE] != null) {
                                            remoteMessage.data[ARG_IMAGE].toString()
                                        } else ""
                                    }
                                    // Suggestion Notification to Rate completed Order
                                    AppConstants.KEY_TYPE_RATE_ORDER -> {
                                        intent.putExtra(AppConstants.ARG_RATING_COMPLETE, 0)
                                        intent.putExtra(
                                            AppConstants.ARG_ORDER_STORE_ID,
                                            payloadJson.getInt(AppConstants.ARG_ORDERS_OUTLETS_ID)
                                        )
                                        intent.putExtra(
                                            AppConstants.ARG_ORDER_ID,
                                            payloadJson.getInt(AppConstants.ARG_ORDER_ID)
                                        )
                                        image = if (remoteMessage.data[ARG_IMAGE] != null) {
                                            remoteMessage.data[ARG_IMAGE].toString()
                                        } else ""
                                    }
                                    AppConstants.KEY_TYPE_EARLY_DELIVERY -> {
                                        intent.putExtra(AppConstants.ARG_RATING_COMPLETE, 0)
                                        intent.putExtra(
                                            AppConstants.ARG_ORDER_STORE_ID,
                                            payloadJson.getInt(AppConstants.ARG_ORDER_OUTLET_ID)
                                        )
                                        intent.putExtra(
                                            AppConstants.ARG_ORDER_ID,
                                            payloadJson.getInt(AppConstants.ARG_ORDER_ID)
                                        )
                                        image = if (remoteMessage.data[ARG_IMAGE] != null) {
                                            remoteMessage.data[ARG_IMAGE].toString()
                                        } else ""
                                    }

                                    "restaurant_order_updates" ->{
                                        var orderStatus =  if (payloadJson.has("order_status")){
                                            payloadJson.getInt("order_status")
                                        } else 0

                                        val orderOutletId =  if (payloadJson.has(AppConstants.ARG_ORDERS_OUTLETS_ID)){
                                            payloadJson.getInt(AppConstants.ARG_ORDERS_OUTLETS_ID)
                                        } else 0

                                        val orderId = if (payloadJson.has(AppConstants.ARG_ORDER_ID)){
                                            payloadJson.getInt(AppConstants.ARG_ORDER_ID)
                                        } else 0

                                        intent.putExtra(
                                            AppConstants.ARG_ORDER_STORE_ID,
                                            orderOutletId
                                        )
                                        intent.putExtra(
                                            AppConstants.ARG_ORDER_ID,
                                            orderId
                                        )

                                        if (orderId != 0 && orderOutletId != 0){
                                            if (orderStatus in 2..3){
                                                EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_ORDER_REJECTED_FOOD))
                                            }else{
                                                EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_FOOD_ORDER_ACCEPTED))
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        val contentIntent: PendingIntent =
                            PendingIntent.getActivity(
                                this,
                                if (orderStatus == 1) 1 else 0,
                                if (payloadJson.getString(AppConstants.KEY_NOTIFICATION_TYPE) == "restaurant_order_updates") Intent() else intent,
                                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                            )

                        if (payloadJson.getString(AppConstants.KEY_NOTIFICATION_TYPE)
                            != AppConstants.KEY_TYPE_SILENT_NOTIFICATION
                        ) {

                            if (image != null && image.isNotEmpty()) {
                                try {
                                    val url = URL(image)
                                    val bitmapIcon = BitmapFactory.decodeStream(
                                        url.openConnection().getInputStream()
                                    )
                                    showNotificationWithIcon(
                                        title.ifEmpty { remoteMessage.data[KEY_TITLE] },
                                        content,
                                        contentIntent,
                                        bitmapIcon
                                    )
                                } catch (e: IOException) {
                                    val bitmapIcon = BitmapFactory.decodeResource(
                                        resources,
                                        R.drawable.ic_profile_green
                                    )
                                    showNotificationWithIcon(
                                        title.ifEmpty { remoteMessage.data[KEY_TITLE] },
                                        content,
                                        contentIntent,
                                        bitmapIcon
                                    )
                                    println(e)
                                }
    //                        CustomStyleNotification(remoteMessage.data[KEY_TITLE], content, contentIntent, image).execute()
                            } else {
                                val notificationContent =content!!.replace("\n", "")
                                NotificationUtils.displaySimpleNotification(
                                        builder,
                                        applicationContext,
                                        notificationContent,
                                        remoteMessage.data[KEY_TITLE]!!,
                                        contentIntent
                                    )

                            }
                        }
                    }else{
                        Timber.tag("notificationPayLoad").d("Unexpected case")
                    }
                } catch (e: Exception) {
                    Timber.tag("notificationPayLoad").d(e.message)
                    e.printStackTrace()
                }
            }
            else -> {
                Timber.tag("notificationPayLoad").d("Null Message Received")
            }
        }

    }

    // New token generated from the Firebase
    override fun onNewToken(newToken: String) {
        super.onNewToken(newToken)
        Timber.tag("NewTokenValue").d(newToken)
        PreferenceManager.fcmToken = newToken
    }

    companion object {
        const val BASKET_CHANNEL_NAME = "Basket Notification Channel"
        const val BASKET_NOTIFICATION_NAME = "Basket"

        const val KEY_PAYLOAD = "payload"

        const val KEY_BODY = "body"
        const val KEY_TITLE = "title"

        const val KEY_MESSAGE_TYPE = "message_type"
    }

    /* inner class CustomStyleNotification(val title: String?, val content: String?, val pendingIntent: PendingIntent?, val imageUrl: String)
         : AsyncTask<String?, Void?, Bitmap?>() {
         override fun doInBackground(vararg params: String?): Bitmap? {
             val inputStream: InputStream
             try {
                 val url = URL(imageUrl)
                 val connection = url.openConnection() as HttpURLConnection
                 connection.doInput = true
                 connection.connect()
                 inputStream = connection.inputStream
                 return BitmapFactory.decodeStream(inputStream)
             } catch (e: MalformedURLException) {
                 e.printStackTrace()
             } catch (e: IOException) {
                 e.printStackTrace()
             }
             return null
         }

         @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
         override fun onPostExecute(result: Bitmap?) {
             super.onPostExecute(result)
             this@FCMService.showNotificationWithIcon(title, content, pendingIntent, result)
         }
     }*/

    private fun showNotificationWithIcon(
        title: String?,
        content: String?,
        pendingIntent: PendingIntent?,
        bitmap: Bitmap?,
    ) {
        val builder =
            Builder(this, BASKET_CHANNEL_NAME).setSmallIcon(R.drawable.ic_logo_notification)
                .setColor(ContextCompat.getColor(applicationContext, R.color.accent))
                .setContentTitle(title).setContentText(content)
                .setPriority(PRIORITY_HIGH).setContentIntent(pendingIntent)
                .setDefaults(DEFAULT_SOUND or DEFAULT_LIGHTS or DEFAULT_VIBRATE)
                .setLargeIcon(bitmap)
                .setAutoCancel(true)

        NotificationUtils.displayNotification(this, builder)
    }
}
