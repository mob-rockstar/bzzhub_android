package jo.basket.data.model.api.response


import com.google.gson.annotations.SerializedName
import jo.basket.data.model.CMS

data class AboutAppResponse(
    @SerializedName("cms_list")
    var cmsList: List<CMS>,
    var httpCode: Int,
    @SerializedName("Message")
    var message: String
)