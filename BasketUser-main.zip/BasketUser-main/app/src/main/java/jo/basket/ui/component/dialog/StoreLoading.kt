package jo.basket.ui.component.dialog

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.ImageView
import com.bumptech.glide.Glide
import de.hdodenhof.circleimageview.CircleImageView
import jo.basket.R
import jo.basket.data.model.Store

//Loading Dialog To show users Store is Loading
class StoreLoading {
    lateinit var dialog: Dialog

    fun openDialog(context: Context, store: Store) {
        dialog = Dialog(context, R.style.LoadingDialog)
        val layoutInter: LayoutInflater = LayoutInflater.from(context)
        val view: View = layoutInter.inflate(R.layout.dialog_store_loading, null)
        dialog.window
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(view)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        Glide.with(context).load(store.logoImage)
            .into(view.findViewById(R.id.iv_store) as CircleImageView)
        Glide.with(context).asGif().load(R.raw.ic_load_store)
            .into(view.findViewById(R.id.iv_loading) as ImageView)

        val lp = WindowManager.LayoutParams()
        val window = dialog.window
        lp.copyFrom(window!!.attributes)
        lp.width = WindowManager.LayoutParams.MATCH_PARENT
        lp.height = WindowManager.LayoutParams.MATCH_PARENT
        window.attributes = lp
        dialog.setCanceledOnTouchOutside(true)

        dialog.setCancelable(true)
        dialog.show()
    }

    fun dismissDialog() {
        dialog.dismiss()
    }

    companion object {
        private var instance: StoreLoading? = null
        private val Instance: StoreLoading
            get() {
                if (instance == null) {
                    instance = StoreLoading()
                }
                return instance!!
            }

        fun openDialog(context: Context, store: Store) {
            Instance.openDialog(context, store)
        }

        fun dismissDialog() {
            Instance.dismissDialog()
        }
    }
}