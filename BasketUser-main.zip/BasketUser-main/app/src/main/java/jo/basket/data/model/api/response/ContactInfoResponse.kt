package jo.basket.data.model.api.response


import com.google.gson.annotations.SerializedName
import jo.basket.data.model.ContactSettings

data class ContactInfoResponse(
    @SerializedName("contact_settings")
    var contactSettings: ContactSettings? = null,
    @field:SerializedName("httpCode")
    val code: Int = 0,
    @SerializedName("Message")
    var message: String
)