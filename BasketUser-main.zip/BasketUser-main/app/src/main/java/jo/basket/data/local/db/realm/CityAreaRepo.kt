package jo.basket.data.local.db.realm

import jo.basket.data.model.AreaNew
import jo.basket.data.model.CityArea

class CityAreaRepo : BaseRepo() {

    fun getCityByID(id: Int, detached: Boolean = true): CityArea? {
        var realmCity: CityArea? = realm.where(CityArea::class.java).equalTo("id", id).findFirst()
        if (detached && realmCity != null) {
            realmCity = realm.copyFromRealm<CityArea>(realmCity)
        }
        return realmCity
    }

    fun getAreaByID(id: Int, detached: Boolean = true): AreaNew?{
        var realmArea: AreaNew? = realm.where(AreaNew::class.java).equalTo("zoneId", id).findFirst()
        if (detached && realmArea != null) {
            realmArea = realm.copyFromRealm<AreaNew>(realmArea)
        }
        return realmArea
    }

    fun saveArea(area: AreaNew){
        realm.executeTransaction { r -> r.copyToRealmOrUpdate(area) }
    }

    fun save(city: CityArea) {
        realm.executeTransaction { r -> r.copyToRealmOrUpdate(city) }
    }

    fun delete(city: CityArea) {
        if (city.isValid) {
            realm.executeTransaction { city.deleteFromRealm() }
        }
    }

    fun detach(city: CityArea): CityArea {
        return if (city.isManaged) {
            realm.copyFromRealm(city)
        } else {
            city
        }
    }
}