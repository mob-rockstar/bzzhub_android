package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.realm.RealmList
import io.realm.RealmObject
import io.realm.annotations.PrimaryKey


open class OrderDetail {

    @PrimaryKey
    @SerializedName("order_id")
    @Expose
    var id: Int = 0

    @SerializedName("outlet_id")
    @Expose
    var outletId: Int? = 0

    @SerializedName("outlet_name")
    @Expose
    var outletName: String? = null

    @SerializedName("invoice_id")
    @Expose
    var invoiceId: String? = null

    @SerializedName("order_key_formated")
    @Expose
    var orderKey: String? = null

    @SerializedName("order_comments")
    @Expose
    var orderComments: String? = null

    @SerializedName("delivery_instructions")
    @Expose
    var deliveryInstructions: String? = null

    @SerializedName("order_list")
    @Expose
    var storeOrders: List<StoreOrder>? = null

    @SerializedName("overall_subtotal")
    @Expose
    var overallSubtotal = 0f

    @SerializedName("overall_included_tax_amount")
    @Expose
    var overallIncludedTaxAmount = 0f

    @SerializedName("overall_basic_delivery_fee")
    @Expose
    var overallBasicDeliveryFee = 0f

    @SerializedName("overall_under_threshold_fee")
    @Expose
    var overallUnderThresholdFee = 0f

    @SerializedName("overall_one_hour_delivery_fee")
    @Expose
    var overallOneHourDeliveryFee = 0f

    @SerializedName("overall_basic_plus_under_threshold")
    @Expose
    var overallBasicPlusUnderThreshold = 0f

    @SerializedName("overall_delivery_total")
    @Expose
    var overallDeliveryTotal = 0f

    @SerializedName("overall_free_delivery_discount")
    @Expose
    var overallFreeDeliveryDiscount = 0f

    @SerializedName("overall_membership_discount")
    @Expose
    var overallMembershipDiscount = 0f

    @SerializedName("overall_service_tax")
    @Expose
    var overallServiceTax = 0f

    @SerializedName("pre_authorization_amount")
    @Expose
    var preAuthorizationAmount = 0f

    @SerializedName("capture_amount")
    @Expose
    var captureAmount = 0f

    @SerializedName("overall_total")
    @Expose
    var overallTotal = 0f

    @SerializedName("overall_service_fee")
    @Expose
    var overallServiceFee = 0f

    @SerializedName("overall_shopper_adjustment")
    @Expose
    var overallShopperAdjustment = 0f

    @SerializedName("order_cancelled_date")
    @Expose
    var orderCancelledDate: String? = null

    @SerializedName("promo_code_details")
    @Expose
    var mPromoDetails: PromoDetails? = null

    @SerializedName("shopping_completed_time")
    @Expose
    var shoppingCompletedTime: String? = null

    @SerializedName("payment_status")
    @Expose
    var paymentStatus = 0

    @SerializedName("active_payment_methods")
    @Expose
    var activePaymentMethods : ArrayList<ActivePaymentMethod> ?= null
}