package jo.basket.data.model

import com.google.gson.annotations.SerializedName

class MembershipCancelTitle {
    @field:SerializedName("httpCode")
    var httpCode: Int? = null

    @field:SerializedName("Title")
    var title: String? = null

    @field:SerializedName("Body")
    var body: String? = null

    @field:SerializedName("End_date")
    var endDate: String? = null
}