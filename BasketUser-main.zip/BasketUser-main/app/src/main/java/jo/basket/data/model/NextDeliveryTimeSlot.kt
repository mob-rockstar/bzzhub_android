package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


open class NextDeliveryTimeSlot {

    @SerializedName("available")
    @Expose
    var available: Int? = null

    @SerializedName("delivery_charge")
    @Expose
    var deliveryCharge: Double? = null

    @SerializedName("outlet_delivery_total")
    @Expose
    var outletDeliveryTotal: Double? = null

    @SerializedName("outlet_under_threshold_amount")
    @Expose
    var outletUnderThresholdAmount: Double? = null

    @SerializedName("one_hr_fee")
    @Expose
    var oneHrFee: Double? = null

    @SerializedName("delivery_time")
    @Expose
    var deliveryTime: String? = null

    @SerializedName("delivery_date")
    @Expose
    var deliveryDate: String? = null

    @SerializedName("delivery_slot_nick_name")
    @Expose
    var deliverySlotNickName: String? = null

    @SerializedName("delivery_permission")
    @Expose
    var deliveryPermission: Int? = null

    @SerializedName("min_order_permission")
    @Expose
    var minOrderPermission: Int? = null

    @SerializedName("customer_message")
    @Expose
    var customerMessage: String? = null

}