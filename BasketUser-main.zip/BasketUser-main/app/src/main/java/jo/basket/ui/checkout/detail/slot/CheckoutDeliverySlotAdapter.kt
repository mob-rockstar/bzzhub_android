package jo.basket.ui.checkout.detail.slot

import android.view.View
import android.view.View.*
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import jo.basket.R
import jo.basket.data.model.Cart
import jo.basket.data.model.DeliveryTime
import jo.basket.databinding.RecyclerItemCheckoutDeliverySlotBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter
import jo.basket.utils.FormatterUtils
import jo.basket.utils.ResUtils

class CheckoutDeliverySlotAdapter :
    BaseRecyclerViewAdapter<DeliveryTime, RecyclerItemCheckoutDeliverySlotBinding>() {

    var cart: Cart? = null
    var listener: OnSelectTimeListener? = null

    override val layoutId: Int
        get() = R.layout.recycler_item_checkout_delivery_slot

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = createBindedView(viewGroup)
        return DeliverySlotViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as DeliverySlotViewHolder
        val context = viewHolder.itemView.context
        val deliveryTime: DeliveryTime? = items[position]

        if (deliveryTime != null) {
            holder.binding.tvDeliveryDuration.text = deliveryTime.label ?: deliveryTime.deliveryTime

            if (deliveryTime.available == 0) {
                holder.binding.ivSelect.visibility = INVISIBLE
                holder.binding.tvDeliveryPrice.setText(R.string.str_not_available)
            } else {
                holder.binding.ivSelect.visibility = VISIBLE
                holder.binding.tvDeliveryPrice.text =
                    if (deliveryTime.deliveryCharge == 0.0) ResUtils.getString(R.string.str_free) else FormatterUtils.formatPrice(
                        deliveryTime.deliveryCharge
                    )
            }

            holder.binding.tvDeliveryDuration.setTextColor(
                ContextCompat.getColor(
                    context,
                    R.color.md_black_1000
                )
            )
            holder.binding.tvDeliveryPrice.setTextColor(
                ContextCompat.getColor(
                    context,
                    R.color.accent
                )
            )

            if (position == selected) {
                holder.binding.ivSelect.setImageDrawable(ContextCompat.getDrawable(context,
                    R.drawable.ic_radio_checked_membership))
                holder.binding.cvConfirm.visibility = VISIBLE
            } else {
                holder.binding.ivSelect.setImageDrawable(ContextCompat.getDrawable(context,
                    R.drawable.ic_radio_membership))
                holder.binding.cvConfirm.visibility = GONE
            }

            holder.binding.tvDeliveryDuration.visibility = View.VISIBLE
            holder.binding.tvDeliveryPrice.visibility = View.VISIBLE
        } else {
            holder.binding.tvDeliveryDuration.visibility = View.INVISIBLE
            holder.binding.tvDeliveryPrice.visibility = View.INVISIBLE
            holder.binding.root.setOnClickListener(null)
        }

        holder.itemView.setOnClickListener {
            if (deliveryTime!!.available != 0 && selected != position) {
                listener?.onTimeSelected(cart!!, deliveryTime!!)
            }
        }

        holder.binding.cvConfirm.setOnClickListener {
            listener?.onTimeSelected(cart!!, deliveryTime!!)
        }
    }

    fun getItems(): List<DeliveryTime>{
        return items
    }

    interface OnSelectTimeListener {
        fun onTimeSelected(cart: Cart, deliveryTime: DeliveryTime)
    }

    inner class DeliverySlotViewHolder(val binding: RecyclerItemCheckoutDeliverySlotBinding) :
        RecyclerView.ViewHolder(binding.root)
}