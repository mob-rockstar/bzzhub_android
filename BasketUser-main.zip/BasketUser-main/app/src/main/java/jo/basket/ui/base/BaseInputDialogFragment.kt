package jo.basket.ui.base

import android.content.Context
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.DialogFragment


abstract class BaseInputDialogFragment<T : ViewDataBinding?, V : BaseViewModel?> :
    BaseDialogFragment<T, V>() {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupKeyboardHidingListner(view)
    }

    fun showDialogFragment(fragment: DialogFragment) {
        navigator.showDialogFragment<DialogFragment>(baseActivity, fragment)
    }

    private fun setupKeyboardHidingListner(view: View) {
        // Set up touch listener for non-text box views to hide keyboard.
        if (view !is EditText) {
            view.setOnTouchListener { v, event ->
                val inputMethodManager =
                    context!!.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                inputMethodManager.hideSoftInputFromWindow(view.windowToken, 0)
                false
            }
        }

        //If a layout container, iterate over children and seed recursion.
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                val innerView = view.getChildAt(i)
                setupKeyboardHidingListner(innerView)
            }
        }
    }

}