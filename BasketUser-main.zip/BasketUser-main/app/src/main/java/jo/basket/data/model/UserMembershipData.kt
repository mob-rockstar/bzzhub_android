package jo.basket.data.model


import com.google.gson.annotations.SerializedName

data class UserMembershipData(
    @SerializedName("card_label")
    var cardLabel: String,
    @SerializedName("last_payment_date")
    var lastPaymentDate: String,
    @SerializedName("membership_packages")
    var membershipPackages: ArrayList<UserMembership>,
    @SerializedName("membership_renew_date")
    var membershipRenewDate: String,
    @SerializedName("membership_minimum_order_amount")
    var membershipMinOrderAmount: String,
    @SerializedName("user_membership_details")
    var userMembershipDetails: UserMembershipDetails,
    @SerializedName("membership_reminder")
    var membershipReminder : Int

)