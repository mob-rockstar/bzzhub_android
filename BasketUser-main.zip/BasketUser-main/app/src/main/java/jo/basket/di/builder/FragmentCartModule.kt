package jo.basket.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector
import jo.basket.ui.cart.ClosedCartFragment
import jo.basket.ui.cart.deliveryslot.CartDeliverySlotFragment
import jo.basket.ui.cart.main.CartAllFragment
import jo.basket.ui.cart.main.CartMainFragment
import jo.basket.ui.cart.main.WaitFoodOrderFragment

@Module
abstract class FragmentCartModule {

    @ContributesAndroidInjector
    abstract fun contributeMainFragment(): CartMainFragment

    @ContributesAndroidInjector
    abstract fun contributeCartAllFragment(): CartAllFragment

    @ContributesAndroidInjector
    abstract fun contributeDeliverySlotFragment(): CartDeliverySlotFragment

    @ContributesAndroidInjector
    abstract fun contributeClosedCartFragment(): ClosedCartFragment

    @ContributesAndroidInjector
    abstract fun contributeWaitFoodOrderFragment(): WaitFoodOrderFragment
}