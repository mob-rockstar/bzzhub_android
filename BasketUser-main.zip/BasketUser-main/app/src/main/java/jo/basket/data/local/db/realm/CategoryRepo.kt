package jo.basket.data.local.db.realm

import io.realm.RealmList
import jo.basket.data.model.Category

class CategoryRepo : BaseRepo() {

    fun findAll(detached: Boolean = true): List<Category> {
        val realmResults = realm.where(Category::class.java).findAll()

        return if (detached) {
            realm.copyFromRealm(realmResults)
        } else {
            realmResults
        }
    }

    fun findInDepartment(departmentId: Int, detached: Boolean = true): List<Category> {
        val realmResults =
            realm.where(Category::class.java).equalTo("departmentId", departmentId).findAll()

        return if (detached) {
            realm.copyFromRealm(realmResults)
        } else {
            realmResults
        }
    }

    fun getById(id: Int, detached: Boolean = true): Category? {
        var realmCategory: Category? =
            realm.where(Category::class.java).equalTo("id", id).findFirst()
        if (detached && realmCategory != null) {
            realmCategory = realm.copyFromRealm<Category>(realmCategory)
        }
        return realmCategory
    }

    fun getByField(field: String?, value: String?, detached: Boolean = true): Category? {
        var realmCategory: Category? =
            realm.where(Category::class.java).equalTo(field!!, value).findFirst()
        if (detached && realmCategory != null) {
            realmCategory = realm.copyFromRealm<Category>(realmCategory)
        }
        return realmCategory
    }

    fun save(category: Category, reserveChild: Boolean = false) {
        if (reserveChild) {
            // try to preserve existing products
            val tempCategory = category.clone()
            tempCategory.fullProducts = RealmList()
            val realmCategory: Category? =
                realm.where(Category::class.java).equalTo("id", category.id).findFirst()
            if (realmCategory != null) {
                tempCategory.fullProducts = realmCategory.fullProducts
            }
            realm.executeTransaction { r -> r.copyToRealmOrUpdate(tempCategory) }
        } else {
            realm.executeTransaction { r -> r.copyToRealmOrUpdate(category) }
        }
    }

    fun delete(category: Category) {
        if (category.isValid) {
            realm.executeTransaction {
                category.deleteFromRealm()
            }
        }
    }

    fun detach(category: Category): Category {
        return if (category.isManaged) {
            realm.copyFromRealm(category)
        } else {
            category
        }
    }
}