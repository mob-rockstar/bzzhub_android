package jo.basket.data.model.api.response.customAdditionalRequest

data class Title(
    val lang: String,
    val text: String
)