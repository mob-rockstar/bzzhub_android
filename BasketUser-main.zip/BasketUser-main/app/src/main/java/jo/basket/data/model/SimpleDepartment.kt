package jo.basket.data.model

class SimpleDepartment(var id: Int, var name: String?) {
    override fun toString(): String {
        return name!!
    }
}