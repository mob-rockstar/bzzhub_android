package jo.basket.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector
import jo.basket.ui.splash.ads.UserADSFragment

@Module
abstract class FragmentSplashViewModule {
    @ContributesAndroidInjector
    abstract fun contributeUserADSFragment(): UserADSFragment
}