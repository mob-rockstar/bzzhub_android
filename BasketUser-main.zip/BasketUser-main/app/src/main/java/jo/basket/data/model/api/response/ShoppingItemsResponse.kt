package jo.basket.data.model.api.response

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize


@Parcelize
data class ShoppingItemsResponse(
    @SerializedName("data")
    var listRealTimeShoppingData: List<Data?>? = null,
    @SerializedName("message")
    var message: String? = null,
    @SerializedName("status")
    var code: Int = 0
) : Parcelable {
    @Parcelize
    data class Data(
        @SerializedName("order_delivery_slot")
        var orderDeliverySlot: String? = null,
        @SerializedName("order_items_list")
        var orderItemsList: List<OrderItems?>? = null,
        @SerializedName("order_outlet_id")
        var orderOutletId: Int? = null,
        @SerializedName("order_shopper_name")
        var orderShopperName: String? = null,
        @SerializedName("total_items_shopped")
        var totalItemsShopped: Int? = null,
        @SerializedName("total_order_found_items")
        var totalOrderFoundItems: Int? = null,
        @SerializedName("total_order_items")
        var totalOrderItems: Int? = null
    ) : Parcelable {
        @Parcelize
        data class OrderItems(
            @SerializedName("product_list")
            var productList: List<Product>? = null,
            @SerializedName("type_id")
            var typeId: Int? = null,
            @SerializedName("type_label")
            var typeLabel: String? = null,
            @SerializedName("type_name")
            var typeName: String? = null
        ) : Parcelable {
            @Parcelize
            data class Product(
                @SerializedName("id")
                var id: Int = 0,
                @SerializedName("actual_approx_weight")
                var actualApproxWeight: Double = 0.0,
                @SerializedName("actual_item_total")
                var actualItemTotal: Double? = null,
                @SerializedName("actual_item_unit_price")
                var actualItemUnitPrice: Double? = null,
                @SerializedName("actual_qty")
                var actualQty: Float = 0F,
                @SerializedName("actual_selling_price")
                var actualSellingPrice: Double? = null,
                @SerializedName("customer_item_notes")
                var customerItemNotes: String? = null,
                @SerializedName("customer_replacement_id")
                var customerReplacementId: Int? = null,
                @SerializedName("customer_suggestion")
                var customerSuggestion: Int? = null,
                @SerializedName("department_name")
                var departmentName: String? = null,
                @SerializedName("each_suffix")
                var eachSuffix: Double? = null,
                @SerializedName("item_qty")
                var itemQty: Float = 0F,
                @SerializedName("item_type")
                var itemType: Int? = null,
                @SerializedName("label_value")
                var labelValue: String? = null,
                @SerializedName("old_actual_approx_weight")
                var oldActualApproxWeight: Double = 0.0,
                @SerializedName("old_actual_item_total")
                var oldActualItemTotal: Double? = null,
                @SerializedName("old_actual_item_unit_price")
                var oldActualItemUnitPrice: Double? = null,
                @SerializedName("old_actual_qty")
                var oldActualQty: Float = 0F,
                @SerializedName("old_actual_selling_price")
                var oldActualSellingPrice: Double = 0.0,
                @SerializedName("old_customer_item_notes")
                var oldCustomerItemNotes: String? = null,
                @SerializedName("old_each_suffix")
                var oldEachSuffix: Double? = null,
                @SerializedName("old_label_value")
                var oldLabelValue: String? = null,
                @SerializedName("old_outlet_item_id")
                var oldOutletItemId: Int? = null,
                @SerializedName("old_product_image")
                var oldProductImage: String? = null,
                @SerializedName("old_product_info_image")
                var oldProductInfoImage: String? = null,
                @SerializedName("old_product_name")
                var oldProductName: String? = null,
                @SerializedName("old_size_label")
                var oldSizeLabel: Int? = null,
                @SerializedName("old_sold_per")
                var oldSoldPer: Int? = null,
                @SerializedName("old_sold_per_label")
                var oldSoldPerLabel: String? = null,
                @SerializedName("old_unit")
                var oldUnit: String? = null,
                @SerializedName("ordered_approx_weight")
                var orderedApproxWeight: Double? = null,
                @SerializedName("ordered_item_total")
                var orderedItemTotal: Double? = null,
                @SerializedName("ordered_item_unit_price_selling")
                var orderedItemUnitPriceSelling: Double? = null,
                @SerializedName("ordered_our_selling_price")
                var orderedOurSellingPrice: Double? = null,
                @SerializedName("ordered_qty")
                var orderedQty: Float? = null,
                @SerializedName("our_selling_price")
                var ourSellingPrice: Double = 0.0,
                @SerializedName("outlet_item_id")
                var outletItemId: Int? = null,
                @SerializedName("pending_review")
                var pendingReview: Int? = null,
                @SerializedName("price_difference")
                var priceDifference: Int? = null,
                @SerializedName("price_difference_label")
                var priceDifferenceLabel: String? = null,
                @SerializedName("product_image")
                var productImage: String? = null,
                @SerializedName("product_info_image")
                var productInfoImage: String? = null,
                @SerializedName("product_name")
                var productName: String? = null,
                @SerializedName("promo_item")
                var promoItem: Int? = null,
                @SerializedName("qty_difference")
                var qtyDifference: Float? = null,
                @SerializedName("qty_difference_label")
                var qtyDifferenceLabel: String? = null,
                @SerializedName("replace_label")
                var replaceLabel: String? = null,
                @SerializedName("size_label")
                var sizeLabel: Int? = null,
                @SerializedName("sold_per")
                var soldPer: Int? = null,
                @SerializedName("sold_per_label")
                var soldPerLabel: String = "",
                @SerializedName("unit")
                var unit: String? = null,
                @SerializedName("replacement_item_list")
                var replacementItemList: List<ReplaceItem>? = null,
            ) : Parcelable {
                @Parcelize
                data class ReplaceItem(
                    @SerializedName("actaul_weight_for_approx_items")
                    val actualWeightForApproxItems: String?= null,
                    @SerializedName("actual_approx_weight")
                    val actual_approx_weight: Double ?= null,
                    @SerializedName("actual_qty")
                    val actualQty: Double ?= null,
                    @SerializedName("actual_selling_price")
                    val actualSellingPrice: Double ?= null,
                    @SerializedName("aisle")
                    val aisle: Int ?= null,
                    @SerializedName("approx_weight")
                    val approxWeight: Double ?= null,
                    @SerializedName("custom_product_image")
                    val customProductImage: String ?= null,
                    @SerializedName("custom_product_name")
                    val customProductName: String ?= null,
                    @SerializedName("department_name")
                    val departmentName: String ?= null,
                    @SerializedName("department_url")
                    val departmentURL: String ?= null,
                    @SerializedName("does_not_contain")
                    val doesNotContain: Int ?= null,
                    @SerializedName("each_suffix")
                    val eachSuffix: Double ?= null,
                    @SerializedName("instore_location_id")
                    val inStoreLocationId: Int ?= null,
                    @SerializedName("instore_master_location_id")
                    val inStoreMasterLocationId: Int ?= null,
                    @SerializedName("instore_sublocation_id")
                    val inStoreSubLocationId: Int ?= null,
                    @SerializedName("item_found")
                    val itemFound: Int ?= null,
                    @SerializedName("item_qty")
                    val itemQty: Double ?= null,
                    @SerializedName("item_shopping_status")
                    val itemShoppingStatus: Int ?= null,
                    @SerializedName("item_type")
                    val itemType: Int ?= null,
                    @SerializedName("item_unit_price_actual")
                    val itemUnitPriceActual: Double ?= null,
                    @SerializedName("item_unit_price_selling")
                    val item_unit_price_selling: Double ?= null,
                    @SerializedName("item_unit_tax_value")
                    val itemUnitTaxValue: String ?= null,
                    @SerializedName("label_value")
                    val labelValue: String ?= null,
                    @SerializedName("measuring_unit")
                    val measuringUnit: String ?= null,
                    @SerializedName("new_item_id")
                    val newItemId: Int ?= null,
                    @SerializedName("notes")
                    val notes: String ?= null,
                    @SerializedName("order_outlet_item_replacement_id")
                    val orderOutletItemReplacementId: Int ?= null,
                    @SerializedName("orders_outlets_items_id")
                    val ordersOutletItemId: Int ?= null,
                    @SerializedName("our_selling_price")
                    val ourSellingPrice: Double ?= null,
                    @SerializedName("price_difference_approved")
                    val priceDifferenceApproved: Int ?= null,
                    @SerializedName("price_difference_reported")
                    val priceDifferenceReported: Int ?= null,
                    val product_image: String,
                    val product_info_image: String,
                    val product_name: String,
                    val quantity_difference: Int,
                    val quantity_difference_approved: Int,
                    val replacement_fullfilled: Int,
                    val replacement_item_id: Int,
                    val replacement_requested: Int,
                    val return_item: Int,
                    val shopper_tips: String,
                    val size_label: Int,
                    val sold_per: Int,
                    val upc: String,
                    val upc_type: Int
                ) : Parcelable
            }
        }
    }
}