package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.realm.RealmObject
import io.realm.annotations.PrimaryKey


open class ProductHistory : RealmObject() {

    @PrimaryKey
    @SerializedName("orders_outlets_items_id")
    @Expose
    var id: Int = 0

    @SerializedName("item_type")
    @Expose
    var itemType: Int = 0

    @SerializedName("item_status")
    @Expose
    var itemStatus: String? = null

    @SerializedName("product_id")
    @Expose
    var productId: Int = 0

    @SerializedName("is_favorited")
    @Expose
    var isFavorited: Int? = null

    @SerializedName("product_name")
    @Expose
    var productName: String? = null

    @SerializedName("description")
    @Expose
    var description: String? = null

    @SerializedName("product_image")
    @Expose
    var productImage: String? = null

    @SerializedName("product_info_image")
    @Expose
    var productInfoImage: String? = null

    @SerializedName("our_selling_price")
    @Expose
    var ourSellingPrice: Double? = null

    @SerializedName("original_price")
    @Expose
    var originalPrice: Double? = null

    @SerializedName("outlet_item_id")
    @Expose
    var outletItemId: Int? = null

    @SerializedName("sold_per")
    @Expose
    var soldPer: Int? = null

    @SerializedName("sold_per_label")
    @Expose
    var soldPerLabel: String? = null

    @SerializedName("unit")
    @Expose
    var unit: String? = null

    @SerializedName("approx_weight")
    @Expose
    var approxWeight: Double? = null

    @SerializedName("size_label")
    @Expose
    var sizeLabel: Double? = null

    @SerializedName("label_value")
    @Expose
    var labelValue: String? = null

    @SerializedName("each_suffix")
    @Expose
    var eachSuffix: Double? = null

    @SerializedName("allow_grams")
    @Expose
    var allowGrams: Int? = null

    @SerializedName("product_cart")
    @Expose
    var productCart: Double? = null

    @SerializedName("cart_qty")
    @Expose
    var cartQty: Double? = null

    @SerializedName("cart_notes")
    @Expose
    var cartNotes: String? = null

    @SerializedName("cart_detail_id")
    @Expose
    var cartDetailId: Int? = null

    @SerializedName("status_available")
    @Expose
    var statusAvailable: Int? = null

    @SerializedName("status_available_label")
    @Expose
    var statusAvailableLabel: String? = null

    @SerializedName("featured_item")
    @Expose
    var featuredItem: Int? = null

    @SerializedName("vendor_id")
    @Expose
    var vendorId: Int? = null

    @SerializedName("outlet_id")
    @Expose
    var outletId: Int? = null

    @SerializedName("outlet_name")
    @Expose
    var outletName: String? = null

    @SerializedName("department_id")
    @Expose
    var departmentId: Int? = null

    @SerializedName("department_name")
    @Expose
    var departmentName: String? = null

    @SerializedName("aisle_id")
    @Expose
    var aisleId: Int? = null

    @SerializedName("aisle_name")
    @Expose
    var aisleName: String? = null

    @SerializedName("brand_id")
    @Expose
    var brandId: Int? = null

    @SerializedName("brand_title")
    @Expose
    var brandTitle: String? = null

}