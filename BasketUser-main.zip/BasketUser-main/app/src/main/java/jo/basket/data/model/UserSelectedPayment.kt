package jo.basket.data.model

import com.google.gson.annotations.SerializedName
import java.util.*


class UserSelectedPayment {

    @field:SerializedName("card_details")
    val cardDetails:Object? = null

    @field:SerializedName("payment_gateway_id")
    val paymentGatewayId: Int = 0

    @field:SerializedName("payment_gateway_name")
    val paymentGatewayName: String? = null

}