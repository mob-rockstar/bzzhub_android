package jo.basket.data.model.api


data class ActiveDeviceToken(
    var platform: String,
    var token: String
)