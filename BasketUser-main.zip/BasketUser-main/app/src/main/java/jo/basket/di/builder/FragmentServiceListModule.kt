package jo.basket.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector
import jo.basket.ui.servicelist.LanguageSettingsFragment
import jo.basket.ui.servicelist.WaitFoodOrderFragment
import jo.basket.ui.servicelist.about.AboutAppFragment
import jo.basket.ui.servicelist.help.HelpFragment
import jo.basket.ui.servicelist.order.OrderFragment
import jo.basket.ui.servicelist.service.ServiceListFragment

@Module
abstract class FragmentServiceListModule {
    @ContributesAndroidInjector
    abstract fun contributeLanguageSettingsFragment(): LanguageSettingsFragment

    @ContributesAndroidInjector
    abstract fun contributeServiceListFragment(): ServiceListFragment

    @ContributesAndroidInjector
    abstract fun contributeOrderFragment(): OrderFragment

    @ContributesAndroidInjector
    abstract fun contributeHelpFragment(): HelpFragment

    @ContributesAndroidInjector
    abstract fun contributeAboutAppFragment(): AboutAppFragment

    @ContributesAndroidInjector
    abstract fun contributeWaitFoodOrderFragment(): WaitFoodOrderFragment

}