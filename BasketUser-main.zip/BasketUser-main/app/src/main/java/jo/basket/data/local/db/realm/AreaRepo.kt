package jo.basket.data.local.db.realm


import jo.basket.data.model.Area

class AreaRepo : BaseRepo() {

    fun findAll(detached: Boolean = true): List<Area> {
        val realmResults = realm.where(Area::class.java).findAll()

        return if (detached) {
            realm.copyFromRealm(realmResults)
        } else {
            realmResults
        }
    }

    fun findInCity(cityId: Int, detached: Boolean = true): List<Area> {
        val realmResults = realm.where(Area::class.java).equalTo("city.id", cityId).findAll()

        return if (detached) {
            realm.copyFromRealm(realmResults)
        } else {
            realmResults
        }
    }

    fun getById(id: Int, detached: Boolean = true): Area? {
        var realmArea: Area? = realm.where(Area::class.java).equalTo("id", id).findFirst()
        if (detached && realmArea != null) {
            realmArea = realm.copyFromRealm<Area>(realmArea)
        }
        return realmArea
    }

    fun getByField(field: String?, value: String?, detached: Boolean = true): Area? {
        var realmArea: Area? = realm.where(Area::class.java).equalTo(field!!, value).findFirst()
        if (detached && realmArea != null) {
            realmArea = realm.copyFromRealm<Area>(realmArea)
        }
        return realmArea
    }

    fun save(area: Area) {
        realm.executeTransaction { r -> r.copyToRealmOrUpdate(area) }
    }

    fun delete(area: Area) {
        if (area.isValid) {
            realm.executeTransaction {
                area.deleteFromRealm()
            }
        }
    }

    fun detach(area: Area): Area {
        return if (area.isManaged) {
            realm.copyFromRealm(area)
        } else {
            area
        }
    }
}