package jo.basket.data.model


import com.google.gson.annotations.SerializedName

data class SplashADSData(
    @SerializedName("city_id")
    var cityId: Int,
    @SerializedName("country_id")
    var countryId: Int,
    @SerializedName("description_ar")
    var descriptionAr: String,
    @SerializedName("description_en")
    var descriptionEn: String,
    var id: Int,
    @SerializedName("image_android")
    var imageAndroid: String,
    @SerializedName("image_ios")
    var imageIos: String,
    @SerializedName("image_web")
    var imageWeb: String,
    @SerializedName("title_ar")
    var titleAr: String,
    @SerializedName("title_en")
    var titleEn: String
)