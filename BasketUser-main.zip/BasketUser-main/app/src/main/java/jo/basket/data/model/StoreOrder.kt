package jo.basket.data.model

import com.google.gson.JsonElement
import com.google.gson.JsonNull
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.realm.RealmList
import io.realm.RealmObject
import io.realm.annotations.PrimaryKey


open class StoreOrder {

    @SerializedName("orders_outlets_id")
    @Expose
    var id: Int = 0

    @SerializedName("order_id")
    @Expose
    var orderId: Int = 0

    @SerializedName("is_custom_store")
    @Expose
    var isCustomStore: Int = 0

    @SerializedName("is_grid_view")
    @Expose
    var isGridView: Int? = 0

    @SerializedName("shopper_tip_amount")
    @Expose
    var shopperTipAmount: String? = ""

    @SerializedName("user_complaint")
    @Expose
    var userComplaint: Int? = 0

    @SerializedName("incentivizing_discount")
    @Expose
    var incentivizingDiscount: Double? = 0.0

    @SerializedName("restaurant_order_expire_timer")
    @Expose
    var timeLeft: Long? = 0

    @SerializedName("is_express")
    @Expose
    var isExpress: Int = 0

    @SerializedName("is_without_slots ")
    @Expose
    var isWithoutSlot: Int = 0

    @SerializedName("vendor_id")
    @Expose
    var vendorId: Int = 0

    @SerializedName("outlet_id")
    @Expose
    var storeId: Int = 0

    @SerializedName("outlet_name")
    @Expose
    var outletName: String? = null

    @SerializedName("outlet_order_tracking_message")
    @Expose
    var orderTrackingMesasge: String? = null

    @SerializedName("display_name")
    @Expose
    var displayName: String? = null

    @SerializedName("vendor_logo")
    @Expose
    var vendorLogo: String? = null

    @SerializedName("order_status")
    @Expose
    var orderStatus: Int = 0

    @SerializedName("payment_status")
    @Expose
    var paymentStatus: Int = 0

    @SerializedName("total_items")
    @Expose
    var totalItems: Int = 0

    @SerializedName("overall_total_amount")
    @Expose
    var overallTotalAmount: Double = 0.0

    @SerializedName("ordered_date_time")
    @Expose
    var createdDate: String? = null

    @SerializedName("delivery_date_time")
    @Expose
    var deliveryDateTime: String? = null

    @SerializedName("delivery_date")
    @Expose
    var deliveryDate: String? = null

    @SerializedName("delivery_day")
    @Expose
    var deliveryDay: String? = null

    @SerializedName("delivery_slot")
    @Expose
    var deliverySlot: String? = null

    @SerializedName("order_status_name")
    @Expose
    var orderStatusName: String? = null

    @SerializedName("cancel_order_permission")
    @Expose
    var cancelOrderPermission = 0

    @SerializedName("shopper_detail")
    @Expose
    var shopperDetail: JsonElement = JsonNull()

    @SerializedName("outlet_basic_delivery_fee")
    @Expose
    var outletBasicDeliveryFee = 0f

    @SerializedName("outlet_one_hour_delivery_fee")
    @Expose
    var outletOneHourDeliveryFee = 0f

    @SerializedName("outlet_included_tax_amount")
    @Expose
    var outletIncludedTaxAmount = 0f

    @SerializedName("outlet_service_tax")
    @Expose
    var outletServiceTax = 0f

    @SerializedName("outlet_under_threshold_fee")
    @Expose
    var outletUnderThresholdFee = 0f

    @SerializedName("outlet_free_delivery_discount")
    @Expose
    var outletFreeDeliveryDiscount = 0f

    @SerializedName("outlet_basic_plus_under_threshold")
    @Expose
    var outletBasicPlusUnderThreshold = 0f

    @SerializedName("outlet_total_delivery_fee")
    @Expose
    var outletTotalDeliveryFee = 0f

    @SerializedName("outlet_subtotal")
    @Expose
    var outletSubtotal = 0f

    @SerializedName("outlet_total")
    @Expose
    var outletTotal = 0.0

    @SerializedName("outlets_items_count")
    @Expose
    var outletsItemsCount = 0f

    @SerializedName("outlet_shopped_items")
    @Expose
    var outletsShoppedItemCount = 0

    @SerializedName("outlet_pending_review_items")
    @Expose
    var outletsPendingReviewItemCount = 0

    @SerializedName("rating_completed")
    @Expose
    var rating_completed: Int? = null

    @SerializedName("product_list")
    @Expose
    var products = RealmList<ProductHistory>()

}