package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.Category
import jo.basket.data.model.Product


class OrderedProductsResponse {

    @field:SerializedName("httpCode")
    var code: Int? = 0

    @field:SerializedName("Message")
    var message: String? = null

    @field:SerializedName("my_items")
    val myItems: List<Category>? = null

    @field:SerializedName("outlet_id")
    val store_id: Int = 0

    @field:SerializedName("outlet_name")
    var store_name: String? = null

}