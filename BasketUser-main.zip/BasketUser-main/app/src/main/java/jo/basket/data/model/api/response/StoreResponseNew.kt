package jo.basket.data.model.api.response

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class StoreResponseNew {
    @SerializedName("data")
    @Expose
    val data: StoreResponseData ?= null

    @SerializedName("message")
    @Expose
    val message: String ?= null

    @SerializedName("status")
    @Expose
    val status: Int ?= null

}