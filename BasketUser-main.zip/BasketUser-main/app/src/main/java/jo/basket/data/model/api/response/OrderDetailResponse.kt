package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.OrderDetail
import jo.basket.data.model.UserSelectedAddress
import jo.basket.data.model.UserSelectedPayment
import jo.basket.data.model.UserSelectedPaymentMethod


class OrderDetailResponse {

    @field:SerializedName("httpCode")
    val code: Int = 0

    @field:SerializedName("Message")
    val message: String? = null

    @field:SerializedName("user_selected_address")
    val userSelectedAddress: UserSelectedAddress? = null

    @field:SerializedName("user_selected_payment")
    val userSelectedPayment: UserSelectedPayment? = null

    @field:SerializedName("user_selected_payment_method")
    val userSelectedPaymentMethod: UserSelectedPaymentMethod? = null

    @field:SerializedName("order_detail")
    val orderDetail: OrderDetail? = null

}