package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.realm.RealmObject
import io.realm.annotations.PrimaryKey

open class Shopper : RealmObject() {

    @PrimaryKey
    @SerializedName("shopper_id")
    @Expose
    var id: Int = 0

    @SerializedName("shopper_first_name")
    @Expose
    var firstName: String? = null

    @SerializedName("shopper_last_name")
    @Expose
    var lastName: String? = null

    @SerializedName("shopper_mobile_number")
    @Expose
    var mobileNumber: String? = null

    @SerializedName("shopper_image")
    @Expose
    var image: String? = null

}