package jo.basket.data.model


import com.google.gson.annotations.SerializedName

data class CustomProduct(
    @SerializedName("cart_id")
    var cartId: Int,
    @SerializedName("cart_outlet_id")
    var cartOutletId: Int,
    @SerializedName("custom_product_image")
    var customProductImage: String,
    var id: Int,
    var notes: String,
    @SerializedName("product_name")
    var productName: String,
    var quantity: Double
)