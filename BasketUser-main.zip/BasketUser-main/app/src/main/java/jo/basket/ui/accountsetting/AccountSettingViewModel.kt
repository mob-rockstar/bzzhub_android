package jo.basket.ui.accountsetting

import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import jo.basket.data.local.db.RealmManager
import jo.basket.data.local.prefs.PreferenceManager
import jo.basket.data.model.LoyaltyCard
import jo.basket.data.model.api.response.*
import jo.basket.data.model.api.response.base.BaseResponse
import jo.basket.data.remote.APIManager
import jo.basket.ui.base.BaseViewModel
import jo.basket.ui.base.HandleResponse
import jo.basket.utils.analytics.BasketAnalyticsManager
import timber.log.Timber

class AccountSettingViewModel : BaseViewModel() {

    var loyaltyCard: LoyaltyCard? = null

    //Call logout API
    fun logout(handleResponse: HandleResponse<BaseResponse>) {
        compositeDisposable.add(APIManager.logout()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    //Get user's notification settings detail
    fun getNotificationSettings(handleResponse: HandleResponse<NotificationSettingResponse>) {
        setIsLoading(true)
        compositeDisposable.add(APIManager.getNotificationSettings()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    //Update user's notification setting
    fun updateNotificationSettings(
        enablePush: Int, updateSMS: Int, updateCall: Int, promoEmail: Int, promoPush: Int,
        promoSMS: Int
    ) {

        compositeDisposable.add(APIManager.updateNotificationSettings(
            enablePush,
            updateSMS,
            updateCall,
            promoEmail,
            promoPush,
            promoSMS
        )
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { },
                { x ->
                    Timber.tag("notificationSettings").d(x)
                }
            ))
    }

    // Get city list from API
    fun getCountryNCities(handleResponse: HandleResponse<CountryCityResponse>) {
        compositeDisposable.add(APIManager.getCountryNCities()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }


    // Get country List of users
    fun getCountryList(handleResponse: HandleResponse<CountrySettingResponse>) {
        setIsLoading(true)
        compositeDisposable.add(APIManager.getCountryList()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)

                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    //Change user's country selection
    fun updateCountrySelection(
        countryId: Int,
        handleResponse: HandleResponse<SimpleUpdateResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.add(APIManager.updateCountrySettings(countryId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    // Get area list from API
    fun getAreas(cityId: Int, handleResponse: HandleResponse<AreaResponse>) {
        compositeDisposable.add(APIManager.getAreas(cityId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        if (result.code == 200 && result.areaList != null) {
                            RealmManager.setLocalAreaData(cityId, result.areaList!!)
                        }
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }


    //Get Language List
    fun getLanguageList(handleResponse: HandleResponse<LanguageListResponse>) {
        setIsLoading(true)
        compositeDisposable.add(APIManager.getLanguageList()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    //Change User's Language setting
    fun updateLanguageSettings(
        languageID: Int,
        handleResponse: HandleResponse<SimpleUpdateResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.add(APIManager.updateLanguageSetting(languageID)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    //Get User's Loyalty Card list
    fun getLoyaltyCardList(handleResponse: HandleResponse<LoyaltyCardListResponse>) {
        setIsLoading(true)
        compositeDisposable.add(APIManager.getLoyaltyCardList()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    //Add Loyalty Card
    fun addCard(
        vendorId: Int,
        cardNumber: String,
        handleResponse: HandleResponse<SimpleUpdateResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.add(APIManager.addLoyaltyCard(vendorId, cardNumber)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    //Update Loyalty Card information
    fun updateCard(
        vendorId: Int,
        cardNumber: String,
        loyaltyCardId: Int,
        handleResponse: HandleResponse<SimpleUpdateResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.add(APIManager.updateLoyaltyCard(vendorId, cardNumber, loyaltyCardId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    //Remove Loyalty Card
    fun removeCard(loyaltyCardId: Int, handleResponse: HandleResponse<SimpleUpdateResponse>) {
        setIsLoading(true)
        compositeDisposable.add(APIManager.removeLoyaltyCard(loyaltyCardId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    // Get city list from API
    fun getCityNAreas(handleResponse: HandleResponse<CityAreaListResponse>) {
        compositeDisposable.add(APIManager.getCityAreas(PreferenceManager.currentUserCountryId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        if (result.code == 200 && result.itemList != null) {
                            RealmManager.setLocalCityAreaData(result.itemList)
                        }
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    // Get address List
    fun getAddressList(handleResponse: HandleResponse<AddressListResponse>) {
        setIsLoading(true)
        compositeDisposable.addAll(APIManager.getAddressList()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        if (result.code == 200 && result.addressList!= null){
                            RealmManager.setLocalAddressData(result.addressList!!)
                        }
                        handleResponse.handleSuccessRespons(result)
                    }
                }
            ) { x ->
                run {

                    setIsLoading(false)
                    handleResponse.handleErrorResponse(getThrowableError(x))
                }
            })
    }

    //Call logout API
    fun deactivateAccount(handleResponse: HandleResponse<SimpleResponse>) {
        compositeDisposable.add(APIManager.deactivateAccount()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

}