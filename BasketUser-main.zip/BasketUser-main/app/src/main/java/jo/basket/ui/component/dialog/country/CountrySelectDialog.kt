package jo.basket.ui.component.dialog.country

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.Window
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.SnapHelper
import jo.basket.R
import jo.basket.data.model.Country
import jo.basket.databinding.DialogChooseCountryBinding
import jo.basket.ui.component.snap.GravitySnapHelper
import jo.basket.utils.PopupUtils
import timber.log.Timber


class CountrySelectDialog {

    private val countryList: ArrayList<Country> = ArrayList()
    private lateinit var dialog: Dialog
    private var mContext: Context?= null
    private var mListener: OnSelectedListener? = null
    private var selectedCountry: Country? = null

    private var adapter: CountryAdapter = CountryAdapter { country ->
        if (country == selectedCountry){
            mListener?.onSelected(country)
            dismissDialog()
        }
    }

    fun setCountries(countries: List<Country>) {
        this.countryList.clear()
        this.countryList.addAll(countries)
        adapter.setItems(countryList)
    }

    fun openDialog(context: Context, listener: OnSelectedListener) {
        mListener = listener
        mContext = context
        dialog = Dialog(context)
        val binding = DataBindingUtil.inflate<DialogChooseCountryBinding>(
            LayoutInflater.from(context),
            R.layout.dialog_choose_country,
            null,
            false
        )

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(binding.root)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
/*        val layoutManager = CarouselLayoutManager(CarouselLayoutManager.VERTICAL)
        layoutManager.maxVisibleItems = 1
        layoutManager.setPostLayoutListener(CarouselZoomPostLayoutListener())

        binding.recyclerView.layoutManager = layoutManager
        binding.recyclerView.setHasFixedSize(true)

        val snapHelperTop: SnapHelper = GravitySnapHelper(Gravity.CENTER_VERTICAL)
        snapHelperTop.attachToRecyclerView(binding.recyclerView)
        layoutManager.addOnItemSelectionListener { adapterPosition ->
            if (CarouselLayoutManager.INVALID_POSITION != adapterPosition) {
                selectedCountry = countryList[adapterPosition]
            }
        }

        binding.layoutCancel.setOnClickListener { dialog.dismiss() }
        binding.recyclerView.adapter = adapter
        val centerScrollListener = CenterScrollListener()
        binding.recyclerView.addOnScrollListener(centerScrollListener)*/
        
        PopupUtils.setDefaultDialogProperty(dialog)
        dialog.show()
    }

    fun dismissDialog(){
        dialog.dismiss()
    }

    companion object {
        private var instance: CountrySelectDialog? = null

        private val Instance: CountrySelectDialog
            get() {
                if (instance == null) {
                    instance = CountrySelectDialog()
                }
                return instance!!
            }

        fun openDialog(context: Context, listener: OnSelectedListener) {
            Instance.openDialog(context, listener)
        }

        fun setCountries(countries: List<Country>) {
            Instance.setCountries(countries)
        }
    }

    interface OnSelectedListener {
        fun onSelected(country: Country)
    }
}