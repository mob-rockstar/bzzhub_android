package jo.basket.data.model


import com.google.gson.annotations.SerializedName

data class Language(
    @SerializedName("created_date")
    var createdDate: String,
    var id: Int,
    @SerializedName("language_code")
    var languageCode: String,
    var name: String,
    @SerializedName("updated_date")
    var updatedDate: String
)