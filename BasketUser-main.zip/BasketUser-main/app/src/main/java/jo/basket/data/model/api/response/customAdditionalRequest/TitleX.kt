package jo.basket.data.model.api.response.customAdditionalRequest

data class TitleX(
    val lang: String,
    val text: String
)