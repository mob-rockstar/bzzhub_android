package jo.basket.data.model.pricingmodel


import com.google.gson.annotations.SerializedName

data class OutletInfo(
    @SerializedName("outlet_address")
    var outletAddress: String,
    @SerializedName("outlet_banner")
    var outletBanner: String,
    @SerializedName("outlet_id")
    var outletId: Int,
    @SerializedName("outlet_logo")
    var outletLogo: String,
    @SerializedName("outlet_name")
    var outletName: String,
    @SerializedName("display_name")
    var displayName: String,
    @SerializedName("store_type")
    var storeType: List<String>,
    @SerializedName("vendor_id")
    var vendorId: Int
)