package jo.basket.data.model

import com.google.gson.annotations.SerializedName

data class OpenedOrder(
    @SerializedName("order_count")
    var orderCount: Int,
    @SerializedName("show_notification_popup")
    var showNotificationPopup: Int,
    @SerializedName("wallet_balance")
    var walletBalance: String?,
    @SerializedName("show_notification_details")
    var notificationDetails: List<NotificationDetails>? = null
) {

    inner class NotificationDetails {
        @field:SerializedName("id")
        var id: Int? = null

        @field:SerializedName("notification_title")
        var title: String? = null

        @field:SerializedName("notification_body")
        var body: String? = null

        @field:SerializedName("popup_button_text")
        var buttonText: String? = null
    }
}



