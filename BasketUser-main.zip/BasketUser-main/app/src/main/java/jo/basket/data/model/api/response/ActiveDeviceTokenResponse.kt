package jo.basket.data.model.api.response

import jo.basket.data.model.api.ActiveDeviceToken


data class ActiveDeviceTokenResponse(
    var `data`: ArrayList<ActiveDeviceToken>,
    var message: String,
    var status: Int
)