package jo.basket.data.local.db.realm

import jo.basket.data.model.Product

class ProductRepo : BaseRepo() {

    fun findAll(detached: Boolean = true): List<Product> {
        val realmResults = realm.where(Product::class.java).findAll()

        return if (detached) {
            realm.copyFromRealm(realmResults)
        } else {
            realmResults
        }
    }

    fun findInCategory(categoryId: Int, detached: Boolean = true): List<Product> {
        val realmResults =
            realm.where(Product::class.java).equalTo("category.id", categoryId).findAll()

        return if (detached) {
            realm.copyFromRealm(realmResults)
        } else {
            realmResults
        }
    }

    fun findFavoritesInStore(storeId: Int, detached: Boolean = true): List<Product> {
        val favorite = 1
        val realmResults = realm.where(Product::class.java).equalTo("outletId", storeId)
            .equalTo("isFavorited", favorite).findAll()

        return if (detached) {
            realm.copyFromRealm(realmResults)
        } else {
            realmResults
        }
    }

    fun findFeaturedInStore(storeId: Int, detached: Boolean = true): List<Product> {
        val featured = 1
        val realmResults = realm.where(Product::class.java).equalTo("outletId", storeId)
            .equalTo("featured", featured).findAll()

        return if (detached) {
            realm.copyFromRealm(realmResults)
        } else {
            realmResults
        }
    }

    fun getById(id: Int, detached: Boolean = true): Product? {
        var realmProduct: Product? = realm.where(Product::class.java).equalTo("id", id).findFirst()
        if (detached && realmProduct != null) {
            realmProduct = realm.copyFromRealm<Product>(realmProduct)
        }
        return realmProduct
    }

    fun getByField(field: String?, value: String?, detached: Boolean = true): Product? {
        var realmProduct: Product? =
            realm.where(Product::class.java).equalTo(field, value).findFirst()
        if (detached && realmProduct != null) {
            realmProduct = realm.copyFromRealm<Product>(realmProduct)
        }
        return realmProduct
    }

    fun save(product: Product) {
        realm.executeTransaction { r -> r.copyToRealmOrUpdate(product) }
    }

    fun delete(realmProduct: Product) {
        if (realmProduct.isValid) {
            realm.executeTransaction { realmProduct.deleteFromRealm() }
        }
    }

    fun detach(product: Product): Product {
        return if (product.isManaged) {
            realm.copyFromRealm(product)
        } else {
            product
        }
    }
}