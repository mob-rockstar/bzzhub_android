package jo.basket.data.model.orderreceipt


import com.google.gson.annotations.SerializedName

data class OrderReceipt(
    @SerializedName("order_receipt_detail")
    var orderReceiptDetail: ReceiptDetail
)