package jo.basket.ui.component.imageslider.IndicatorView.animation.data.type;


import jo.basket.ui.component.imageslider.IndicatorView.animation.data.Value;

public class SlideAnimationValue implements Value {

    private int coordinate;

    public int getCoordinate() {
        return coordinate;
    }

    public void setCoordinate(int coordinate) {
        this.coordinate = coordinate;
    }
}
