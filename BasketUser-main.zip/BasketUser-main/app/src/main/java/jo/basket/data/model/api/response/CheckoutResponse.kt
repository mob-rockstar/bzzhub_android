package jo.basket.data.model.api.response

import com.google.gson.GsonBuilder
import com.google.gson.JsonElement
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import jo.basket.data.model.*
import jo.basket.data.model.payment.PaymentData
import java.util.*
import kotlin.collections.ArrayList

open class CheckoutResponse {

    @field:SerializedName("httpCode")
    val code: Int = 0

    @field:SerializedName("Message")
    val message: String? = null

    @field:SerializedName("secondary_mobile_number")
    val secondaryMobile: String? = null

    @field:SerializedName("user_selected_address")
    val userSelectedAddress: JsonElement? = null

    @field:SerializedName("user_selected_payment")
    val userSelectedPayment: UserSelectedPayment? = null

    @field:SerializedName("user_selected_payment_method")
    var userSelectedPaymentMethod: PaymentMethod? = null

    @field:SerializedName("cart_list")
    var carts: List<Cart> = ArrayList()

    @field:SerializedName("cart_id")
    val cartId: Int? = null

    @field:SerializedName("overall_subtotal")
    val overallSubtotal: Double? = null

    @field:SerializedName("overall_included_tax_amount")
    val overallIncludedTaxAmount: Double? = null

    @field:SerializedName("overall_basic_delivery_charge")
    val overallBasicDeliveryCharge: Double? = null

    @field:SerializedName("overall_under_threshold_fee")
    val overallUnderThresholdFee: Double? = null

    @field:SerializedName("overall_one_hour_delivery_fee")
    val overallOneHourDeliveryFee: Double? = null

    @field:SerializedName("overall_basic_plus_under_threshold")
    val overallBasicPlusUnderThreshold: Double? = null

    @field:SerializedName("overall_delivery_total")
    val overallDeliveryTotal: Double? = null

    @field:SerializedName("overall_free_delivery_discount")
    val overallFreeDeliveryDiscount: Double? = null

    @field:SerializedName("overall_promo_delivery_discount")
    val overall_promo_delivery_discount: Double? = null

    @field:SerializedName("overall_membership_discount")
    val overallMembershipDiscount: Double = 0.0

    @field:SerializedName("overall_service_fee_discount")
    val overallServiceFeeDiscount: Double = 0.0

    @field:SerializedName("pre_authorization_amount")
    val preAuthorizationAmount: Double? = null

    @field:SerializedName("overall_total")
    val overallTotal: Double? = null

    @field:SerializedName("address_list")
    val addressList: List<Address> = ArrayList<Address>()

    @field:SerializedName("payment_gateway_list")
    val paymentGateway: List<PaymentGateway>? = null

    @field:SerializedName("promo_code_details")
    val mPromoDetails: PromoDetails? = null

    @field:SerializedName("savings_message")
    val savingMessages: SavingMessages? = null

    @field:SerializedName("overall_service_fee")
    val overallServiceFee: Double? = null

    @field:SerializedName("is_first_order")
    val firstOrder: Int? = 0

    @field:SerializedName("is_heavy_order")
    val isHeavyOrder: Int? = 0

    @field:SerializedName("payment_methods")
    var paymentList: List<PaymentData> ? = null

    @field:SerializedName("delivery_info_details")
    val deliveryInfoDetails: List<DeliveryInfoDetail> ?= null

    @field:SerializedName("checkout_permission_details")
    val checkoutPermissionDetails: CheckoutPermissionDetails? = null

    fun getUserSelectedAddress(): UserSelectedAddress? {
        if (userSelectedAddress != null && userSelectedAddress.isJsonObject) {
            return GsonBuilder().create()
                .fromJson(userSelectedAddress, UserSelectedAddress::class.java)
        }
        return null
    }

    inner class SavingMessages {
        @field:SerializedName("heading")
        var heading: String? = null

        @field:SerializedName("title")
        var title: String? = null

        @field:SerializedName("amount")
        var amount: Double? = null
    }

}