package jo.basket.ui.component.dialog.sortNfilter

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.Window
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import jo.basket.R
import jo.basket.data.model.Brand
import jo.basket.databinding.DialogProductFilterNSortBinding
import jo.basket.utils.PopupUtils

//Class To Dialog which Shows Filter Options
class SortNFilter{
    private val brands: ArrayList<Brand> = ArrayList()
    private val filterAdapter: BrandFilterAdapter = BrandFilterAdapter()
    private val adapter: ProductSortAdapter = ProductSortAdapter()

    fun setBrands(brandList: List<Brand>) {
        brands.clear()
        brands.addAll(brandList)
        filterAdapter.setBrands(brandList)
    }

    fun setSelectedBrands(brandList: ArrayList<Brand>) {
        filterAdapter.setSelectedBrands(brandList)
    }

    fun openDialog(context: Context, listener: OnApplyFilterListener?) {
        val dialog = Dialog(context)
        val binding = DataBindingUtil.inflate<DialogProductFilterNSortBinding>(
            LayoutInflater.from(context),
            R.layout.dialog_product_filter_n_sort,
            null,
            false
        )

        val sortTitleList = ArrayList<String>()
        sortTitleList.addAll(context.resources.getStringArray(R.array.sort_titles))
        adapter.setItems(sortTitleList)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(binding.root)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        binding.rvBrands.layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        binding.rvBrands.adapter = filterAdapter
        filterAdapter.init()
        filterAdapter.setOnChangeFilterListener(object : BrandFilterAdapter.OnChangeFilterListener {
            override fun onChange(position: Int) {
                binding.tvReset.visibility =
                    if (filterAdapter.selectedBrands.isEmpty()) View.GONE else View.VISIBLE
            }
        })

        binding?.layoutBrandTitle?.setOnClickListener {
            if (binding.rvBrands.visibility == VISIBLE) {
                binding.rvBrands.visibility = GONE
                binding.ivDropDownBrand.setImageDrawable(ContextCompat.getDrawable(context,R.drawable.ic_arrow_down))
            }else{
                binding.rvBrands.visibility = VISIBLE
                binding.rvSorts.visibility = GONE
                binding.ivDropDownSort.setImageDrawable(ContextCompat.getDrawable(context,R.drawable.ic_arrow_down))
                binding.ivDropDownBrand.setImageDrawable(ContextCompat.getDrawable(context,R.drawable.ic_close))
            }
        }

        binding?.layoutSortTitle?.setOnClickListener {
            if (binding.rvSorts.visibility == VISIBLE) {
                binding.rvSorts.visibility = GONE
                binding.ivDropDownSort.setImageDrawable(ContextCompat.getDrawable(context,R.drawable.ic_arrow_down))
            }else{
                binding.rvSorts.visibility = VISIBLE
                binding.rvBrands.visibility = GONE
                binding.ivDropDownSort.setImageDrawable(ContextCompat.getDrawable(context,R.drawable.ic_close))
                binding.ivDropDownBrand.setImageDrawable(ContextCompat.getDrawable(context,R.drawable.ic_arrow_down))
            }
        }

        // If brand list is not expanded- show 'expand' option, else - hide
     //   binding.tvExpandable.visibility = if (brands.size > 3) View.VISIBLE else View.GONE
        binding.tvExpandable.visibility = if (brands.size > 3) View.GONE else View.GONE
        filterAdapter.expand()
/*
        // If tap 'expand' option, expand brand list
        binding.tvExpandable.setOnClickListener {
            filterAdapter.expand()
            binding.tvExpandable.visibility = View.GONE
        }*/

        // Reset all brands selection
        binding.tvReset.visibility =
            if (filterAdapter.selectedBrands.isEmpty() || adapter.selectedSortIndex == 0) View.GONE else View.VISIBLE
        binding.tvReset.setOnClickListener {
            reset()
            adapter.reset()
        }

        binding.rvSorts.layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        binding.rvSorts.adapter = adapter

        // Apply filter
        binding.layoutApply.setOnClickListener {
            listener?.onApply(filterAdapter.selectedBrands, SortType.from(adapter.selectedSortIndex))
            dialog.dismiss()
        }

        binding.ivBack.setOnClickListener { dialog.dismiss() }
        PopupUtils.setDefaultDialogProperty(dialog)
        dialog.show()
    }

    private fun reset() {
        filterAdapter.resetFilters()
    }

    companion object {
        private var instance: SortNFilter? = null
        private val Instance: SortNFilter
            get() {
                if (instance == null) {
                    instance = SortNFilter()
                }
                return instance!!
            }

        fun setBrands(brands: List<Brand>) {
            Instance.setBrands(brands)
        }

        // reset sort options
        fun reset() {
          Instance.adapter.reset()
        }

        fun setSelectedBrands(brands: ArrayList<Brand>) {
            Instance.setSelectedBrands(brands)
        }

        fun openDialog(context: Context, listener: OnApplyFilterListener? = null) {
            Instance.openDialog(context, listener)
        }
    }


    interface OnApplyFilterListener {
        fun onApply(selectedBrands: List<Brand>, selectedSortType: SortType)
    }

    enum class SortType(val value: Int) {
        BEST_MATCH(0), ALPHABETICALLY(1),LOWEST_PRICE(2), HIGHEST_PRICE(3);

        companion object {
            fun from(value: Int) = SortType.values().first { it.ordinal == value }
        }
    }

    interface OnApplySortListener {
        fun onApply(selectedSortType: SortType)
    }
}