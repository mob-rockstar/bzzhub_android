package jo.basket.data.local.db.realm

import jo.basket.data.model.AddressType

class AddressTypeRepo : BaseRepo() {

    fun findAll(detached: Boolean = true): List<AddressType> {
        val realmResults = realm.where(AddressType::class.java).findAll()

        return if (detached) {
            realm.copyFromRealm(realmResults)
        } else {
            realmResults
        }
    }

    fun getById(id: Int, detached: Boolean = true): AddressType? {
        var realmAddressType: AddressType? =
            realm.where(AddressType::class.java).equalTo("id", id).findFirst()
        if (detached && realmAddressType != null) {
            realmAddressType = realm.copyFromRealm<AddressType>(realmAddressType)
        }
        return realmAddressType
    }

    fun getByField(field: String?, value: String?, detached: Boolean = true): AddressType? {
        var realmAddressType: AddressType? =
            realm.where(AddressType::class.java).equalTo(field!!, value).findFirst()
        if (detached && realmAddressType != null) {
            realmAddressType = realm.copyFromRealm<AddressType>(realmAddressType)
        }
        return realmAddressType
    }

    fun save(addressType: AddressType) {
        realm.executeTransaction { r -> r.copyToRealmOrUpdate(addressType) }
    }

    fun delete(addressType: AddressType) {
        if (addressType.isValid) {
            realm.executeTransaction {
                addressType.deleteFromRealm()
            }
        }
    }

    fun detach(addressType: AddressType): AddressType {
        return if (addressType.isManaged) {
            realm.copyFromRealm(addressType)
        } else {
            addressType
        }
    }
}