package jo.basket.data.model.chat


import com.google.gson.annotations.SerializedName

data class Shopper(
    var identifier: String,
    var name: String,
    var photo: String,
    var role: String
)