package jo.basket.data.model.pricingmodel

import com.google.gson.annotations.SerializedName

data class OutletDeliveryInfo(
    @SerializedName("delivery_charges")
    var deliveryCharges: List<PricingDeliveryCharge>,
    @SerializedName("outlet_delivery_info")
    var outletDeliveryInfo: String,
    @SerializedName("price_label")
    var priceLabel: String
)