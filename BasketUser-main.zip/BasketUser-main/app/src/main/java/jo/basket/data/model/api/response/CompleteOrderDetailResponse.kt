package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.Shopper
import jo.basket.data.model.StoreOrderDetail


class CompleteOrderDetailResponse {

    @field:SerializedName("httpCode")
    val code: Int = 0

    @field:SerializedName("Message")
    val message: String? = null

    @field:SerializedName("shopper_detail")
    var shopper: Shopper? = null

    @field:SerializedName("order_outlet_detail")
    val storeOrderDetail: StoreOrderDetail? = null

    @field:SerializedName("total_order_count")
    val totalOrderCount: Int = 0

    @field:SerializedName("current_order_count")
    val currentOrderCount: Int = 0

}