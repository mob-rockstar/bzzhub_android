package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class ReplacementProduct : ShoppedProduct() {

    @SerializedName("replace_label")
    @Expose
    var replaceLabel: String? = null

    @SerializedName("old_outlet_item_id")
    @Expose
    var oldOutletItemId: Int? = null

    @SerializedName("old_product_name")
    @Expose
    var oldProductName: String? = null

    @SerializedName("old_product_image")
    @Expose
    var oldProductImage: String? = null

    @SerializedName("old_product_info_image")
    @Expose
    var oldProductInfoImage: String? = null

    @SerializedName("old_sold_per")
    @Expose
    var oldSoldPer: Int? = null

    @SerializedName("old_sold_per_label")
    @Expose
    var oldSoldPerLabel: String? = null

    @SerializedName("old_label_value")
    @Expose
    var oldLabelValue: String? = null

    @SerializedName("old_size_label")
    @Expose
    var oldSizeLabel: Int? = null

    @SerializedName("old_each_suffix")
    @Expose
    var oldEachSuffix: Int? = null

    @SerializedName("old_actual_approx_weight")
    @Expose
    var oldActualApproxWeight: Double? = null

    @SerializedName("old_actual_selling_price")
    @Expose
    var oldActualSellingPrice: Double? = null

    @SerializedName("old_actual_item_unit_price")
    @Expose
    var oldActualItemUnitPrice: Double? = null

    @SerializedName("old_unit")
    @Expose
    var oldUnit: String? = null

    @SerializedName("old_actual_qty")
    @Expose
    var oldActualQty: Double? = null

    @SerializedName("old_actual_item_total")
    @Expose
    var oldActualItemTotal: Double? = null

    @SerializedName("old_customer_item_notes")
    @Expose
    var oldCustomerItemNotes: String? = null

    @SerializedName("promo_item")
    @Expose
    var promo_item: Int? = null

    @SerializedName("display_saving_per_unit")
    @Expose
    var displaySavingPerUnit: String? = null

}