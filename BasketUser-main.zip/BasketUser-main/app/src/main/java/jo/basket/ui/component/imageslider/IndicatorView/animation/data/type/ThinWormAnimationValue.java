package jo.basket.ui.component.imageslider.IndicatorView.animation.data.type;


import jo.basket.ui.component.imageslider.IndicatorView.animation.data.Value;

public class ThinWormAnimationValue extends WormAnimationValue implements Value {

    private int height;

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }
}
