package jo.basket.ui.cart.main

import android.media.MediaPlayer
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import jo.basket.R
import jo.basket.data.model.api.response.OrderDetailResponse
import jo.basket.data.model.api.response.base.ErrorResponse
import jo.basket.databinding.DialogWaitCheckoutFoodBinding
import jo.basket.di.Injectable
import jo.basket.ui.base.BaseDialogFragment
import jo.basket.ui.base.HandleResponse
import jo.basket.ui.cart.CartViewModel
import jo.basket.ui.checkout.CheckoutViewModel
import jo.basket.ui.main.MainActivity
import jo.basket.utils.AppConstants
import jo.basket.utils.MessageEvent
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.util.concurrent.TimeUnit

class WaitFoodOrderFragment(
    private val timeLeft: Long,
    private val orderId: Int,
    private val orderStoreId: Int
) :
    BaseDialogFragment<DialogWaitCheckoutFoodBinding?, CartViewModel>(),
    Injectable, Animation.AnimationListener {


    override val layoutId: Int
        get() = R.layout.dialog_wait_checkout_food

    override val viewModel: CartViewModel
        get() {
            return getViewModel(baseActivity, CartViewModel::class.java)
        }

    // Set Full screen Dialog

    private var isFoodScreeningRunning = false
    override fun getTheme(): Int {
        return R.style.FullScreenDialogFragmentTheme
    }

    private var countDownTime: Long = 60 * 1000
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        isCancelable = false

        // load the animation
        val animBlink = AnimationUtils.loadAnimation(
            baseActivity.applicationContext,
            R.anim.bliking
        )

        // set animation listener
        animBlink.setAnimationListener(this)

        viewDataBinding?.tvTimeAccept?.animation = animBlink

        // load the animation
        val animBlinkImage = AnimationUtils.loadAnimation(
            baseActivity.applicationContext,
            R.anim.bliking_late
        )

        // set animation listener
        animBlinkImage.setAnimationListener(this)

        viewDataBinding?.ivWaitAcceptOrder?.animation = animBlinkImage

        // load the animation
        val animScale = AnimationUtils.loadAnimation(
            baseActivity.applicationContext,
            R.anim.scale
        )

        // set animation listener
        animBlinkImage.setAnimationListener(this)

        viewDataBinding?.ivWait?.animation = animScale

        if (timeLeft> 0) countDownTime = timeLeft

        runCountDownTimer(countDownTime)
        if (orderId != 0 && orderStoreId != 0) {
            startUpdates()
        }

        viewDataBinding?.ivClose!!.setOnClickListener {
            finishActivity()
        }
    }

    fun startUpdates() {
        val lifecycle = viewLifecycleOwner // in Fragment

        lifecycle.lifecycleScope.launch {
            lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
                // this block is automatically executed when moving into
                // the started state, and cancelled when stopping.
                while (true) {
                    getOrderDetail() // the function to repeat
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        isFoodScreeningRunning = true
        viewModel.isFoodRunning = true
        EventBus.getDefault().register(this)
    }

    private fun runCountDownTimer(time: Long) {

        object : CountDownTimer(time, 1000) {
            // adjust the milli seconds here
            override fun onTick(millisUntilFinished: Long) {
                viewDataBinding?.tvTimeRemaining?.text = buildString {
                    append("")
                    append(
                        String.format(
                            "%02d : %02d",
                            TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished),
                            TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) -
                                    TimeUnit.MINUTES.toSeconds(
                                        TimeUnit.MILLISECONDS.toMinutes(
                                            millisUntilFinished
                                        )
                                    )
                        )
                    )
                }
            }

            override fun onFinish() {
                runCountDownTimer(60 * 1000)
            }
        }.start()
    }

    override fun onAnimationStart(animation: Animation?) {

    }

    override fun onAnimationEnd(animation: Animation?) {

    }

    override fun onAnimationRepeat(animation: Animation?) {

    }

    override fun onDestroy() {
        super.onDestroy()
        viewModel.isFoodRunning = false
        isFoodScreeningRunning = false
        EventBus.getDefault().unregister(this)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        when (event.message) {
            AppConstants.MESSAGE_FOOD_ORDER_ACCEPTED -> {
                if (isFoodScreeningRunning) {
                    playSoundNGoToOrderDetail()
                }
            }
        }
    }

    private fun getOrderDetail() {
        viewModel.getOrderDetail(orderId, orderStoreId, object :
            HandleResponse<OrderDetailResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {

            }

            override fun handleSuccessRespons(successResponse: OrderDetailResponse) {
                if (successResponse.orderDetail?.storeOrders!![0].orderStatus > 1 && successResponse.orderDetail.storeOrders!![0].orderStatus != 29) {
                    playSoundNGoToOrderDetail()
                    viewDataBinding?.layoutWaitAcceptOrder!!.visibility = VISIBLE
                    viewDataBinding?.layoutOrderRejected!!.visibility = GONE
                } else if (successResponse.orderDetail.storeOrders!![0].orderStatus == 29) {
                    initRejectUI()
                } else if (successResponse.orderDetail.storeOrders!![0].orderStatus == 28) {
                    initNotRespondingUI()
                }
            }
        })
    }

    private fun initRejectUI() {
        viewDataBinding?.apply {
            layoutWaitAcceptOrder.visibility = GONE
            layoutOrderRejected.visibility = VISIBLE
            tvOk.setOnClickListener {
                EventBus.getDefault()
                    .post(MessageEvent(AppConstants.MESSAGE_FINISH_CART))
                finishActivity()
            }
            tvOrderStatus.text = baseActivity.resources.getString(R.string.str_order_rejected)
            tvStatusDescription.text =
                baseActivity.resources.getString(R.string.str_your_order_rejected)
            "${baseActivity.resources.getString(R.string.str_reason)}: ${
                baseActivity.resources.getString(R.string.str_we_are_closed)
            }".also { tvReason.text = it }
        }
    }

    private fun initNotRespondingUI() {
        viewDataBinding?.apply {
            layoutWaitAcceptOrder.visibility = GONE
            layoutOrderRejected.visibility = VISIBLE
            tvOk.setOnClickListener {
                EventBus.getDefault()
                    .post(MessageEvent(AppConstants.MESSAGE_FINISH_CART))
                finishActivity()
            }
            tvOrderStatus.text =
                baseActivity.resources.getString(R.string.str_restaurant_not_respond)
            tvStatusDescription.text =
                baseActivity.resources.getString(R.string.str_description_restaurant_not_respond)
            tvReason.visibility = View.GONE
        }
    }

    private fun gotoOrderList() {
        val intent = MainActivity.newIntent(activity, 3)
        startActivity(intent)
        //Send Event broadcast to finish existing activities
        EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_RESTART))
    }

    private fun playSoundNGoToOrderDetail() {
        val mp = MediaPlayer.create(baseActivity, R.raw.sound_order_success)
        mp.start()

        gotoOrderList()
    }
}