package jo.basket.data.model

class Contact(val initial: String ,val name: String, val phoneNumber: String, val email: String)