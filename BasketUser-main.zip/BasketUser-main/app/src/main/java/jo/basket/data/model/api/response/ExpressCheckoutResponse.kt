package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.ExpressData

class ExpressCheckoutResponse {
    @field:SerializedName("httpCode")
    var httpCode: Int? = null

    @field:SerializedName("Message")
    var message: String? = null

    @field:SerializedName("data")
    var expressData: ExpressData? = null
}