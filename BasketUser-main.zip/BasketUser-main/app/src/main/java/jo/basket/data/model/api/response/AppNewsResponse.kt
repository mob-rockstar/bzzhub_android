package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.AppNews


class AppNewsResponse {

    @field:SerializedName("status")
    var code: Int? = 0

    @field:SerializedName("message")
    var message: String? = null

    @field:SerializedName("enabled")
    var enabled: Boolean = false

    @field:SerializedName("data")
    val data: AppNews? = null

}