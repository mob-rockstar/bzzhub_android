package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.CancelReason


class CancelReasonListResponse {
    @field:SerializedName("status")
    var code: Int = 0

    @field:SerializedName("message")
    var message: String? = null

    @field:SerializedName("data")
    var data: List<CancelReason>? = null
}