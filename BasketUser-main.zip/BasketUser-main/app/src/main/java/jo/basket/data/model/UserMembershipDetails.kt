package jo.basket.data.model


import com.google.gson.annotations.SerializedName

data class UserMembershipDetails(
    @SerializedName("is_cancelled")
    var isCancelled: Int,
    @SerializedName("membership_amount")
    var membershipAmount: String,
    @SerializedName("membership_renew_date")
    var membershipRenewDate: String,
    var name: String
)