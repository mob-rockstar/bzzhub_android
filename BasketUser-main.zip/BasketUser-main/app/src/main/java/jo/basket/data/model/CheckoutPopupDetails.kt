package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

open class CheckoutPopupDetails {
    @SerializedName("title")
    @Expose
    var title: String? = null

    @SerializedName("message")
    @Expose
    var message: String? = null

    @SerializedName("dismiss_btn_label")
    @Expose
    var btnLabel: String? = null
}