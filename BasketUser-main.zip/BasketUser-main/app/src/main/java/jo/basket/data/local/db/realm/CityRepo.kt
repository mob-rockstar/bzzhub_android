package jo.basket.data.local.db.realm


import jo.basket.data.model.City

class CityRepo : BaseRepo() {

    fun findAll(detached: Boolean = true): List<City> {
        val realmResults = realm.where(City::class.java).findAll()

        return if (detached) {
            realm.copyFromRealm(realmResults)
        } else {
            realmResults
        }
    }

    fun getById(id: Int, detached: Boolean = true): City? {
        var realmCity: City? = realm.where(City::class.java).equalTo("id", id).findFirst()
        if (detached && realmCity != null) {
            realmCity = realm.copyFromRealm<City>(realmCity)
        }
        return realmCity
    }

    fun getByField(field: String?, value: String?, detached: Boolean = true): City? {
        var realmCity: City? = realm.where(City::class.java).equalTo(field!!, value).findFirst()
        if (detached && realmCity != null) {
            realmCity = realm.copyFromRealm<City>(realmCity)
        }
        return realmCity
    }

    fun save(city: City) {
        realm.executeTransaction { r -> r.copyToRealmOrUpdate(city) }
    }

    fun delete(city: City) {
        if (city.isValid) {
            realm.executeTransaction { city.deleteFromRealm() }
        }
    }

    fun detach(city: City): City {
        return if (city.isManaged) {
            realm.copyFromRealm(city)
        } else {
            city
        }
    }
}