package jo.basket.data.model

import com.google.gson.annotations.SerializedName


open class PromoCode(

    @SerializedName("promo_id")
    var id: Int,
    @SerializedName("title")
    var title: String,
    @SerializedName("promo_code")
    var code: String,
    @SerializedName("minimum_order_amount")
    var minimum_order_amount: Double,
    @SerializedName("start_date")
    var start_date: String,
    @SerializedName("end_date")
    var end_date: String

)