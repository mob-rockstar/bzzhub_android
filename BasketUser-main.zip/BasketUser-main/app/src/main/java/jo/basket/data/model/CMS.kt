package jo.basket.data.model


import com.google.gson.annotations.SerializedName

data class CMS(
    @SerializedName("created_date")
    var createdDate: String,
    var id: Int,
    var status: Int,
    var title: String,
    @SerializedName("updated_date")
    var updatedDate: String,
    var url: String,
    @SerializedName("url_index")
    var urlIndex: String
)