package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


open class PaymentGateway {

    @SerializedName("payment_gateway_id")
    @Expose
    var id: Int = 0

    @SerializedName("name")
    @Expose
    var name: String? = null

    @SerializedName("currency_id")
    @Expose
    var currencyId: Int? = null

    @SerializedName("merchant_key")
    @Expose
    var merchantKey: String? = null

    @SerializedName("merchant_secret_key")
    @Expose
    var merchantSecretKey: String? = null

    @SerializedName("merchant_password")
    @Expose
    var merchantPassword: String? = null

    @SerializedName("payment_mode")
    @Expose
    var paymentMode: String? = null

    @SerializedName("commision")
    @Expose
    var commision: Int? = null

    @SerializedName("account_id")
    @Expose
    var account_id: String? = null

    @SerializedName("payment_type")
    @Expose
    var paymentType: Int? = null

    @SerializedName("created_date")
    @Expose
    var createdDate: String? = null

    @SerializedName("updated_date")
    @Expose
    var updatedDate: String? = null

    @SerializedName("user_card_list")
    @Expose
    var userCardList: List<Any>? = null

}