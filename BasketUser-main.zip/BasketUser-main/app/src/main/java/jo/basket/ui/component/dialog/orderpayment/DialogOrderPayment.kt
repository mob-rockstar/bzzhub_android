package jo.basket.ui.component.dialog.orderpayment

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.Window
import android.widget.TextView
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import jo.basket.R
import jo.basket.data.model.ActivePaymentMethod
import jo.basket.databinding.DialogOrderPaymentListBinding
import jo.basket.ui.order.detail.payment.OrderPaymentAdapter
import jo.basket.utils.PopupUtils

class DialogOrderPayment {

    private var mContext: Context? = null
    private var dialog: Dialog? = null
    private val paymentAdapter: OrderPaymentAdapter = OrderPaymentAdapter{
        showRetryPayment()
    }
    private var mRetryPayment: TextView?= null

    fun openDialog(
        mListener: OrderPaymentAdapter.OnSelectPaymentListener, context: Context,
        onAddNew: () -> Unit,
        onPaymentMethodSelected :()-> Unit
    ) {
        mContext = context
        dialog = Dialog(context)
        val binding = DataBindingUtil.inflate<DialogOrderPaymentListBinding>(
            LayoutInflater.from(context),
            R.layout.dialog_order_payment_list,
            null,
            false
        )

        dialog!!.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog!!.setContentView(binding.root)
        dialog!!.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        paymentAdapter.setSelection(-1)

        binding.apply {
            val linearLayoutManager = LinearLayoutManager(mContext)
            recyclerView.layoutManager = linearLayoutManager
            recyclerView.adapter = paymentAdapter

            layoutOutside.setOnClickListener {
                dismissDialog()
            }

            paymentAdapter.listener = mListener

            tvAdd.setOnClickListener {
                onAddNew()
            }

            mRetryPayment = tvRetryPayment
            tvRetryPayment.visibility = GONE
            tvRetryPayment.setOnClickListener {
                onPaymentMethodSelected()
                dismissDialog()
/*
                mListener.onPaymentSelected(paymentAdapter.mSelectedPaymentId,
                paymentAdapter.mSelectedCardId, paymentAdapter.mSelectedPaymentName,
                paymentAdapter.mSelectedCardLabel, paymentAdapter.mSelectedPaymentMode, paymentAdapter.mSelectedPaymentType)
*/

            }
        }

        PopupUtils.setDefaultDialogProperty(dialog!!)
        dialog?.show()
    }

    fun showRetryPayment(){
        mRetryPayment?.visibility = VISIBLE
    }

    fun setPaymentList(paymentList: ArrayList<ActivePaymentMethod>) {
        paymentAdapter.setItems(paymentList)
    }

    fun setPaymentDetails(
        paymentId: Int,
        cardId: Int,
        paymentName: String,
        cardLabel: String?,
        paymentMode: Int,
        paymentType: Int,
    ) {
        paymentAdapter.setPaymentDetails(
            paymentId,
            cardId,
            paymentMode,
            paymentName,
            cardLabel ?: "",
            paymentType
        )
    }

    fun getCreditPaymentId(): Int {
        return paymentAdapter.getCreditCardPaymentId()
    }

    fun dismissDialog() {
        if (dialog != null) {
            dialog!!.dismiss()
        }
    }

    companion object {
        private var instance: DialogOrderPayment? = null
        private val Instance: DialogOrderPayment
            get() {
                if (instance == null) {
                    instance = DialogOrderPayment()
                }
                return instance!!
            }

        fun openDialog(
            listener: OrderPaymentAdapter.OnSelectPaymentListener,
            context: Context,
            onAddNew: () -> Unit,
            onPaymentMethodSelected :()-> Unit
        ) {
            Instance.openDialog(listener, context , {onAddNew()}, {onPaymentMethodSelected()})
        }

        fun dismissDialog() {
            Instance.dismissDialog()
        }

        fun setPaymentDetails(
            paymentId: Int,
            cardId: Int,
            paymentName: String,
            cardLabel: String?,
            paymentMode: Int,
            paymentType: Int,
        ) {
            Instance.setPaymentDetails(
                paymentId,
                cardId,
                paymentName,
                cardLabel,
                paymentMode,
                paymentType
            )
        }

        fun getCreditCardPaymentId(): Int {
            return Instance.getCreditPaymentId()
        }

        fun setPaymentList(paymentList: ArrayList<ActivePaymentMethod>) {
            Instance.setPaymentList(paymentList)
        }
    }
}