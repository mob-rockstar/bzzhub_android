package jo.basket.data.model.payment


import com.google.gson.annotations.SerializedName
import jo.basket.data.model.PaymentMethod

data class PaymentData(
    var cards: List<PaymentMethod>,
    @SerializedName("is_selected")
    var defaultStatus: Int,
    var id: Int,
    @SerializedName("is_credit_card_enable")
    var isCreditCardEnable: Int,
    @SerializedName("is_cod_enable")
    var isCodEnable: Int,
    @SerializedName("is_bring_cc_machine")
    var isBringCCMachine: Int,
    var name: String,
    @SerializedName("payment_mode")
    var paymentMode: Int,
    @SerializedName("payment_type")
    var paymentType: Int,
    @SerializedName("merchant_key")
    var merchantKey: String,
    @SerializedName("account_id")
    var accountId: String,
    @SerializedName("merchant_secret_key")
    var accountSecretKey: String,


)