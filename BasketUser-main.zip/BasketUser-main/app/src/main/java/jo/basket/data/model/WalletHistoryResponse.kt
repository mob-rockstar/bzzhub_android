package jo.basket.data.model

import com.google.gson.annotations.SerializedName


data class WalletHistoryResponse(
    @field:SerializedName("data")
    var walletData: WalletData,
    var message: String,
    var status: Int
)