package jo.basket.ui.checkout.detail.product

import android.util.Log
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import jo.basket.R
import jo.basket.data.model.DeliveryDay
import jo.basket.data.model.Product
import jo.basket.databinding.RecyclerItemCheckoutHorizontalProductBinding
import jo.basket.databinding.RecyclerItemCheckoutProductBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter
import jo.basket.utils.GlideApp
import kotlin.math.log

// Adapter to handle Product List inside CheckoutStoreAdapter
class CheckoutHorizontalProductAdapter :
    BaseRecyclerViewAdapter<Product, RecyclerItemCheckoutHorizontalProductBinding>() {

    override val layoutId: Int
        get() = R.layout.recycler_item_checkout_horizontal_product

    var listener: OnHorizontalProductSelectedListener? = null

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = createBindedView(viewGroup)
        return ProductViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as ProductViewHolder
        val context = holder.itemView.context

        holder.itemView.setOnClickListener { listener?.onHorizontalProductSelected() }

        if (items[position].productImage!= null) {
            GlideApp.with(context).load(items[position].productImage).diskCacheStrategy(
                DiskCacheStrategy.ALL).centerCrop()
                .error(R.drawable.placeholder300x300).format(
                    DecodeFormat.PREFER_ARGB_8888).into(holder.binding.ivProduct)
        }
    }

    interface OnHorizontalProductSelectedListener {
        fun onHorizontalProductSelected()
    }

    inner class ProductViewHolder(val binding: RecyclerItemCheckoutHorizontalProductBinding) :
        RecyclerView.ViewHolder(binding.root)

}