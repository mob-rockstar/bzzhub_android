package jo.basket.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector
import jo.basket.ui.profile.ChangeEmailFragment
import jo.basket.ui.profile.ChangeNameFragment
import jo.basket.ui.profile.ChangePasswordFragment

@Module
abstract class FragmentProfileNewModule {

    @ContributesAndroidInjector
    abstract fun contributeChangePasswordFragment(): ChangePasswordFragment

    @ContributesAndroidInjector
    abstract fun contributeChangeNameFragment(): ChangeNameFragment

    @ContributesAndroidInjector
    abstract fun contributeChangeEmailFragment(): ChangeEmailFragment
}