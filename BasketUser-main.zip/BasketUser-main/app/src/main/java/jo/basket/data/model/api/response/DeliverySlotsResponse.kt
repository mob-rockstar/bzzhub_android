package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.StoreDeliverySlot


class DeliverySlotsResponse {

    @field:SerializedName("httpCode")
    val code: Int = 0

    @field:SerializedName("Message")
    val message: String? = null

    @field:SerializedName("outlet_delivery_slot")
    var storeDeliverySlots: List<StoreDeliverySlot>? = null

}