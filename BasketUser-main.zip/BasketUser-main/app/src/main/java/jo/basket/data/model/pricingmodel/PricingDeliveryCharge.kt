package jo.basket.data.model.pricingmodel


import com.google.gson.annotations.SerializedName

data class PricingDeliveryCharge(
    var day: String,
    var slots: List<Slot>,
    @SerializedName("week_date")
    var weekDate: String
)