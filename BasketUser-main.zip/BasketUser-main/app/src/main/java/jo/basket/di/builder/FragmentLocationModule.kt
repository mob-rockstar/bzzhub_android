package jo.basket.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector
import jo.basket.ui.location.addressnew.LocationAddressNewFragment
import jo.basket.ui.location.area.LocationAreaFragment
import jo.basket.ui.location.citynarea.LocationCityNAreaFragment
import jo.basket.ui.location.citynew.LocationCityNewFragment
import jo.basket.ui.location.detail.AddressTypeFragment
import jo.basket.ui.location.detail.LocationDetailFragment
import jo.basket.ui.location.hmap.LocationHuaweiMapFragment
import jo.basket.ui.location.map.LocationMapFragment


@Module
abstract class FragmentLocationModule {

    @ContributesAndroidInjector
    abstract fun contributeLocationAddressNewFragment(): LocationAddressNewFragment

    @ContributesAndroidInjector
    abstract fun contributeLocationCityNAreaFragment(): LocationCityNAreaFragment

    @ContributesAndroidInjector
    abstract fun contributeLocationCityNewFragment(): LocationCityNewFragment

    @ContributesAndroidInjector
    abstract fun contributeLocationAreaFragment(): LocationAreaFragment

    @ContributesAndroidInjector
    abstract fun contributeLocationMapFragment(): LocationMapFragment

    @ContributesAndroidInjector
    abstract fun contributeLocationDetailFragment(): LocationDetailFragment

    @ContributesAndroidInjector
    abstract fun contributeAddressTypeFragment(): AddressTypeFragment

    @ContributesAndroidInjector
    abstract fun contributeLocationHuaweiMapFragment(): LocationHuaweiMapFragment

}
