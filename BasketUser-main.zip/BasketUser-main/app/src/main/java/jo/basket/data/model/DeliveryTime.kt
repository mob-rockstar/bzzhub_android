package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


open class DeliveryTime {

    @SerializedName("id")
    @Expose
    var id: Int = 0

    @SerializedName("day")
    @Expose
    var day: Int? = null

    @SerializedName("start_time")
    @Expose
    var startTime: String? = null

    @SerializedName("end_time")
    @Expose
    var endTime: String? = null

    @SerializedName("available")
    @Expose
    var available: Int? = null

    @SerializedName("delivery_charge")
    @Expose
    var deliveryCharge: Double? = null

    @SerializedName("delivery_date")
    @Expose
    var deliveryDate: String? = null

    @SerializedName("delivery_time")
    @Expose
    var deliveryTime: String? = null

    @SerializedName("label")
    @Expose
    var label: String? = null

    @SerializedName("delivery_time_interval_id")
    @Expose
    var deliveryTimeIntervalId: Int? = null

}