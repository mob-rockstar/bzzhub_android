package jo.basket.ui.accountsetting.loyaltycard

import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import jo.basket.R
import jo.basket.data.model.LoyaltyCard
import jo.basket.databinding.RecyclerItemLoyaltyCardBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter

class LoyaltyCardAdapter : BaseRecyclerViewAdapter<LoyaltyCard, RecyclerItemLoyaltyCardBinding>() {

    var loyaltyCardSelectListener: OnLoyaltyCardSelectListener? = null

    override val layoutId: Int
        get() = R.layout.recycler_item_loyalty_card

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return LoyaltyCardViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {

        val holder = viewHolder as LoyaltyCardViewHolder
        val item = items[position]
        holder.binding.run {
            val mContext = holder.itemView.context
            Glide.with(mContext).load(item.logoImage).apply(
                RequestOptions().fitCenter().placeholder(R.drawable.placeholder300x300)
                    .error(R.drawable.placeholder300x300)
            ).into(ivCard)
            tvVendorName.text = item.vendorName
            tvCardName.text = item.loyaltyCardName

            if (item.loyaltyCardNumber.isEmpty()) {
                tvCardNumber.visibility = GONE
            } else
                tvCardNumber.visibility = VISIBLE
            tvCardNumber.text = item.loyaltyCardNumber
            tvAdd.text = mContext.resources.getString(
                if (item.loyaltyCardNumber.isEmpty()) R.string.str_add else R.string.edit
            )
            tvAdd.setOnClickListener {
                loyaltyCardSelectListener?.onSelect(item)
            }
        }
    }

    interface OnLoyaltyCardSelectListener {
        fun onSelect(loyaltyCard: LoyaltyCard)
    }

    inner class LoyaltyCardViewHolder(val binding: RecyclerItemLoyaltyCardBinding) :
        RecyclerView.ViewHolder(binding.root)
}