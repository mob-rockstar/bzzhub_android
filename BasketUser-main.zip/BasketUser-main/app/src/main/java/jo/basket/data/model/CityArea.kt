package jo.basket.data.model


import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.realm.RealmList
import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import java.io.Serializable

open class CityArea: RealmObject() , Serializable {
    @SerializedName("areas_list")
    @Expose
    var areasList: RealmList<AreaNew> = RealmList()

    @PrimaryKey
    @SerializedName("id")
    @Expose
    var id: Int ?= null

    @SerializedName("name")
    @Expose
    var name: String ?= null

    var selected : Int = -1
}

