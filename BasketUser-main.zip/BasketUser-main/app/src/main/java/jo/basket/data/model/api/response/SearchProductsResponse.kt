package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.Banner
import jo.basket.data.model.Product


class SearchProductsResponse {

    @field:SerializedName("httpCode")
    var code: Int? = 0

    @field:SerializedName("Message")
    var message: String? = null

    @field:SerializedName("product_list")
    val products: List<Product>? = null

    @field:SerializedName("banners_list")
    val bannerList: ArrayList<Banner>? = null

    @field:SerializedName("algolia_query_id")
    var queryId: String? = null
}