package jo.basket.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector
import jo.basket.ui.replacementsuggestion.FullImageFragment
import jo.basket.ui.replacementsuggestion.product.CartReplacementProductDetailFragment

@Module
abstract class FragmentCartReplacementSuggestionModule {
    @ContributesAndroidInjector
    abstract fun contributeCartReplacementProductDetailFragment(): CartReplacementProductDetailFragment

    @ContributesAndroidInjector
    abstract fun contributeFullImageFragment(): FullImageFragment
}