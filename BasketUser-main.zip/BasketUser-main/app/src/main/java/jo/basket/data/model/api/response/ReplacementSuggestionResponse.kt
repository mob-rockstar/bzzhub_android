package jo.basket.data.model.api.response

import jo.basket.data.model.ReplaceSuggestionProduct


data class ReplacementSuggestionResponse(
    var `data`: List<ReplaceSuggestionProduct>,
    var message: String,
    var status: Int
)