package jo.basket.data.model.api.response


import com.google.gson.annotations.SerializedName
import jo.basket.data.model.orderreceipt.OrderReceipt

open class ReceiptResponse {

    @SerializedName("data")
    var data: List<OrderReceipt>? = null

    @SerializedName("outlet_subtotal")
    var outletSubtotal: Double? = null

    @SerializedName("outlet_total_delivery_fee")
    var outletTotalDeliveryFee: Double? = null

    @SerializedName("overall_total")
    var overallTotal: Double? = null

    @SerializedName("pre_authorization_amount")
    var preAuthorizationAmount: Double? = null

    @SerializedName("authorization_text")
    var authorizationText: String? = null

    @SerializedName("total_found_items")
    var totalFoundItems: Int? = null

    @SerializedName("total_adjustment_items")
    var totalAdjustmentItems: Int? = null

    @SerializedName("overall_service_fee")
    var overallServiceFee: Float? = null

    @SerializedName("total_promo_amount")
    var totalPromoAmount: Double? = null

    @SerializedName("total_shopper_adjustment")
    var totalShopperAdjustment: Float? = null

    @SerializedName("message")
    var message: String? = null

    @SerializedName("status")
    var status: Int? = null

}