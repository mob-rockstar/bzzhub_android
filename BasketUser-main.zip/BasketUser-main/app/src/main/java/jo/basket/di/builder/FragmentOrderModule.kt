package jo.basket.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector
import jo.basket.ui.order.WaitFoodOrderFragment
import jo.basket.ui.order.addproduct.AddProductFragment
import jo.basket.ui.order.chat.ChatFragment
import jo.basket.ui.order.chat.FullScreenVideoPreviewFragment
import jo.basket.ui.order.chat.ShopperAvatarFragment
import jo.basket.ui.order.deliverytime.DeliverySlotFragment
import jo.basket.ui.order.detail.OrderDetailNewFragment
import jo.basket.ui.order.map.DeliveryTrackingFragment
import jo.basket.ui.order.otheroption.OtherOptionsFragment
import jo.basket.ui.order.possiblereplacement.PossibleReplacementFragment
import jo.basket.ui.order.products.OrderProductDetailFragment
import jo.basket.ui.order.products.OrderProductsFragment
import jo.basket.ui.order.rating.OrderRatingFragment
import jo.basket.ui.order.receipt.OrderReceiptFragment
import jo.basket.ui.order.refund.RefundFragment
import jo.basket.ui.order.shopping.FullImageFragment
import jo.basket.ui.order.shopping.ShoppingFragment
import jo.basket.ui.order.storereceipt.StoreReceiptFragment
import jo.basket.ui.order.storereceipt.StoreReceiptFullImageFragment


@Module
abstract class FragmentOrderModule {

    @ContributesAndroidInjector
    abstract fun contributeOrderDetailNewFragment(): OrderDetailNewFragment

    @ContributesAndroidInjector
    abstract fun contributeDeliverySlotFragment(): DeliverySlotFragment

    @ContributesAndroidInjector
    abstract fun contributeOrderProductsFragment(): OrderProductsFragment

    @ContributesAndroidInjector
    abstract fun contributeOrderProductDetailFragment(): OrderProductDetailFragment

    @ContributesAndroidInjector
    abstract fun contributeShoppingFragment(): ShoppingFragment

    @ContributesAndroidInjector
    abstract fun contributeAddProductFragment(): AddProductFragment

    @ContributesAndroidInjector
    abstract fun contributeFullImageFragment(): FullImageFragment

    @ContributesAndroidInjector
    abstract fun contributeDeliveryTrackingFragment(): DeliveryTrackingFragment

    @ContributesAndroidInjector
    abstract fun contributeChatFragment(): ChatFragment

    @ContributesAndroidInjector
    abstract fun contributeFullScreenVideoPreviewFragment(): FullScreenVideoPreviewFragment

    @ContributesAndroidInjector
    abstract fun contributeOrderRatingFragment(): OrderRatingFragment

    @ContributesAndroidInjector
    abstract fun contributeOrderReceiptFragment(): OrderReceiptFragment

    @ContributesAndroidInjector
    abstract fun contributeStoreReceiptFragmentFragment(): StoreReceiptFragment

    @ContributesAndroidInjector
    abstract fun contributeOtherOptionsFragment(): OtherOptionsFragment

    @ContributesAndroidInjector
    abstract fun contributePossibleReplacementFragment(): PossibleReplacementFragment

    @ContributesAndroidInjector
    abstract fun contributeRefundFragment(): RefundFragment

    @ContributesAndroidInjector
    abstract fun contributeShopperAvatarFragment(): ShopperAvatarFragment

    @ContributesAndroidInjector
    abstract fun contributeStoreReceiptFullImageFragment(): StoreReceiptFullImageFragment

    @ContributesAndroidInjector
    abstract fun contributeWaitFoodOrderFragment(): WaitFoodOrderFragment
}
