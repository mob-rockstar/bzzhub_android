package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.Order


class OrderResponse {

    @field:SerializedName("httpCode")
    val code: Int = 0

    @field:SerializedName("Message")
    val message: String? = null

    @field:SerializedName("my_order_list")
    var orders: List<Order> = emptyList()

    @field:SerializedName("total_items")
    val totalItems: Int = 0

    @field:SerializedName("total_order_count")
    val totalOrderCount: Int = 0

    @field:SerializedName("current_order_count")
    val currentOrderCount: Int = 0

}