package jo.basket.data.model


import com.google.gson.annotations.SerializedName
import java.io.Serializable

 class LowInStockSuggestedItem : Serializable{
     @SerializedName("approx_weight")
     var approxWeight: String = ""
     @SerializedName("each_suffix")
     var eachSuffix: Double? = 0.0
     @SerializedName("label_value")
     var labelValue: String = ""
     @SerializedName("original_price")
     var originalPrice: String = ""
     @SerializedName("our_selling_price")
     var ourSellingPrice: String = ""
     @SerializedName("outlet_id")
     var outletId: Int = 0
     @SerializedName("outlet_item_id")
     var outletItemId: Int = 0
     @SerializedName("product_id")
     var productId: Int? = 0
     @SerializedName("product_info_image")
     var productInfoImage: String = ""
     @SerializedName("product_name")
     var productName: String = ""
     @SerializedName("size_label")
     var sizeLabel: Int = 0
     @SerializedName("sold_per")
     var soldPer: Int = 0
     @SerializedName("sold_per_label")
     var soldPerLabel: String = ""
     var unit: String = ""
 }
