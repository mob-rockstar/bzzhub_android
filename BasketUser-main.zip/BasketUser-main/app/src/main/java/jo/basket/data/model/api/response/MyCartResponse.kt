package jo.basket.data.model.api.response

import com.google.gson.annotations.SerializedName
import jo.basket.data.model.Cart


class MyCartResponse {

    @field:SerializedName("httpCode")
    val code: Int = 0

    @field:SerializedName("Message")
    val message: String? = null

    @field:SerializedName("cart_list")
    var carts: List<Cart> = emptyList()

    @field:SerializedName("cart_id")
    val cartId: Int = 0

    @field:SerializedName("overall_subtotal")
    val overallSubtotal: Double? = null

    @field:SerializedName("overall_included_tax_amount")
    val overallIncludedTaxAmount: Double? = null

    @field:SerializedName("overall_basic_delivery_charge")
    val overallBasicDeliveryCharge: Double? = null

    @field:SerializedName("overall_under_threshold_fee")
    val overallUnderThresholdFee: Double? = null

    @field:SerializedName("overall_one_hour_delivery_fee")
    val overallOneHourDeliveryFee: Double? = null

    @field:SerializedName("overall_basic_plus_under_threshold")
    val overallBasicPlusUnderThreshold: Double? = null

    @field:SerializedName("overall_delivery_total")
    val overallDeliveryTotal: Double? = null

    @field:SerializedName("overall_free_delivery_discount")
    val overallFreeDeliveryDiscount: Double? = null

    @field:SerializedName("overall_service_tax")
    val overallServiceTax: Double? = null

    @field:SerializedName("overall_promo_code_amount")
    val overallPromoCodeAmount: Double? = null

    @field:SerializedName("delivery_instructions")
    val deliveryInstructions: String? = null

}