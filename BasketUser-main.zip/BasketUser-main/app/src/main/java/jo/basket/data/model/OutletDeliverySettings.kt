package jo.basket.data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


open class OutletDeliverySettings {

    @SerializedName("threshold_amount")
    @Expose
    var thresholdAmount: Int? = null

    @SerializedName("one_hour_fee")
    @Expose
    var oneHourFee: Int? = null

    @SerializedName("under_threshold_amount")
    @Expose
    var underThresholdAmount: Int? = null

    @SerializedName("delivery_charge")
    @Expose
    var deliveryCharge: Double? = null

    @SerializedName("service_tax")
    @Expose
    var serviceTax: Int? = null

    @SerializedName("pre_authorization")
    @Expose
    var preAuthorization: Double? = null

    @SerializedName("min_pre_authorization")
    @Expose
    var minPreAuthorization: Double? = null

    @SerializedName("first_fee_delivery_promo")
    @Expose
    var firstFeeDeliveryPromo: Int? = null

    @SerializedName("min_order_amount")
    @Expose
    var minOrderAmount: Double? = null

}