package jo.basket.ui.component.dialog.sortNfilter

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import jo.basket.R
import jo.basket.databinding.RecyclerItemProductSortBinding
import jo.basket.ui.base.recyclerview.BaseRecyclerViewAdapter

class ProductSortAdapter :
    BaseRecyclerViewAdapter<String, RecyclerItemProductSortBinding>() {

    val selectedSortIndex: Int
        get() = if (selected == -1) 0 else selected

    private var onChangeFilterListener: OnChangeSortListener? = null

    init {
   //     items.addAll(ResUtils.getStringArray(R.array.sort_titles))
    }

    override val layoutId: Int
        get() = R.layout.recycler_item_product_sort

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return ProductSortViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as ProductSortViewHolder

        holder.binding.tvSort.text = items[position].trim()
        holder.binding.ivRadio.setImageResource(if (selected == position) R.drawable.ic_radio_checked else R.drawable.ic_radio)

        holder.binding.layoutSort.setOnClickListener {
            setSelection(position)
            onChangeFilterListener?.onChange(position)
        }
    }

    fun setOnChangeSortListener(listener: OnChangeSortListener) {
        onChangeFilterListener = listener
    }

    fun reset() {
        setSelection(0)
    }

    inner class ProductSortViewHolder(val binding: RecyclerItemProductSortBinding) :
        RecyclerView.ViewHolder(binding.root)


    interface OnChangeSortListener {
        fun onChange(position: Int)
    }
}