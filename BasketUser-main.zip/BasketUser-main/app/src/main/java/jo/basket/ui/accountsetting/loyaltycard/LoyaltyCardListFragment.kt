package jo.basket.ui.accountsetting.loyaltycard

import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import jo.basket.R
import jo.basket.data.model.LoyaltyCard
import jo.basket.data.model.api.response.LoyaltyCardListResponse
import jo.basket.data.model.api.response.base.ErrorResponse
import jo.basket.databinding.DialogLoyaltyCardListBinding
import jo.basket.di.Injectable
import jo.basket.ui.accountsetting.AccountSettingViewModel
import jo.basket.ui.accountsetting.AccountSettingsActivity
import jo.basket.ui.base.BaseInputDialogFragment
import jo.basket.ui.base.HandleResponse
import jo.basket.utils.AppConstants
import jo.basket.utils.MessageEvent
import jo.basket.utils.NetworkUtils
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode

// Screen to display List of Loyalty Card Information
class LoyaltyCardListFragment :
    BaseInputDialogFragment<DialogLoyaltyCardListBinding?, AccountSettingViewModel>(),
    LoyaltyCardAdapter.OnLoyaltyCardSelectListener, Injectable {

    var loyaltyCardAdapter = LoyaltyCardAdapter()

    override val layoutId: Int
        get() = R.layout.dialog_loyalty_card_list

    override val viewModel: AccountSettingViewModel
        get() {
            return getViewModel(baseActivity, AccountSettingViewModel::class.java)
        }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        EventBus.getDefault().register(this)

        initToolbar()
        initRecyclerView()

        progressView = viewDataBinding!!.progressBar
        getLoyaltyCard()
    }

    // Set Full Screen Theme
    override fun getTheme(): Int {
        return R.style.FullScreenDialogFragmentTheme
    }

    fun initToolbar() {
        viewDataBinding!!.toolbar.tvTitle.text =
            baseActivity.resources.getString(R.string.str_loyalty_card)
        viewDataBinding!!.toolbar.ivBack.setOnClickListener { dismiss() }
    }

    private fun initRecyclerView() {
        viewDataBinding!!.recyclerView.run {
            layoutManager = LinearLayoutManager(baseActivity)
            adapter = loyaltyCardAdapter
        }
        loyaltyCardAdapter.loyaltyCardSelectListener = this
    }

    // Get Loyalty Card list of current user
    fun getLoyaltyCard() {
        viewModel.getLoyaltyCardList(object : HandleResponse<LoyaltyCardListResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                 if (NetworkUtils.isNetworkConnected(baseActivity) &&!(error?.message ?:"").lowercase().contains(AppConstants.UNABLE_TO_RESOLVE_NETWORK)) {
                    this@LoyaltyCardListFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    NetworkUtils.showNoInternetDialog(
                        baseActivity,
                        object : NetworkUtils.OnConnectedListener {
                            override fun onConnected() {
                                try {
                                    getLoyaltyCard()
                                } catch (e1: Exception) {
                                    e1.printStackTrace()
                                }
                            }
                        })
                }
            }

            override fun handleSuccessRespons(successResponse: LoyaltyCardListResponse) {
                if (successResponse.httpCode == 200) {
                    loyaltyCardAdapter.setItems(successResponse.data!!)
                } else {
                    this@LoyaltyCardListFragment.onError(
                        AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                }
            }
        })
    }

    override fun onSelect(loyaltyCard: LoyaltyCard) {
        viewModel.loyaltyCard = loyaltyCard
        (baseActivity as AccountSettingsActivity).showDialogFragment(AddOrRemoveLoyaltyCardFragment())
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        // If LoyaltyCard list changed (From AddOrRemoveLoyaltyCardFragment), get card list agin
        if (event.message == AppConstants.MESSAGE_LOYALTY_CARD_CHANGED) {
            getLoyaltyCard()
        }
    }
}
