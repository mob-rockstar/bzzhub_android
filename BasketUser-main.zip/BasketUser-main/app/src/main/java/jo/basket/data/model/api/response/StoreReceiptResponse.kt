package jo.basket.data.model.api.response


data class StoreReceiptResponse(
    var `data`: List<String>,
    var message: String,
    var status: Int
)