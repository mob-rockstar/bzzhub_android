package jo.basket.data.model

import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import com.google.gson.reflect.TypeToken
import java.lang.reflect.Type
import java.text.ParseException
import java.util.*


open class ShoppedProductItem {

    @SerializedName("type_name")
    @Expose
    var typeName: String? = null

    @SerializedName("type_label")
    @Expose
    var typeLabel: String? = null

    @SerializedName("type_id")
    @Expose
    var typeId: Int? = null

    @SerializedName("product_list")
    @Expose
    var listJson: JsonArray? = null
    var products: List<ShoppedProduct>? = null


    private fun getProductClass(): Type {
        return when (typeId) {
            1 -> {
                object :
                    TypeToken<ArrayList<AdjustmentProduct>?>() {}.type
            }
            2 -> {
                object :
                    TypeToken<ArrayList<ReplacementProduct>?>() {}.type
            }
            else -> {
                object :
                    TypeToken<ArrayList<ShoppedProduct>?>() {}.type
            }
        }
    }


    @Throws(ParseException::class)
    open fun convertJsonToList() {
        if (listJson != null) {
            products = Gson().fromJson<List<ShoppedProduct>>(listJson, getProductClass())
        } else {
            throw ParseException("Can't deserializes nullable array", 0)
        }
    }

}