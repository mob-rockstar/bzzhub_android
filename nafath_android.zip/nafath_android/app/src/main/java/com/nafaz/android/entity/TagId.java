package com.nafaz.android.entity;


import com.nafaz.android.R;

public interface TagId {
    int POSITION = R.string.position;
    int ITEM_ID = R.string.item_id;
}
