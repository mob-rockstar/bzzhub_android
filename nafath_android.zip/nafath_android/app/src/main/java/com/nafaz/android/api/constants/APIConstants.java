package com.nafaz.android.api.constants;

public class APIConstants {

    public interface ResponseCode {
        int CODE_200 = 200;
        int CODE_100 = 100;
    }
}
