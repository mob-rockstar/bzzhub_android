package com.nafaz.android.entity;

public class AccountHistory {
}
