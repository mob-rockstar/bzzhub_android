package com.nafaz.android.ui.activity;

import android.os.Bundle;

import com.nafaz.android.R;
import com.nafaz.android.ui.base.BaseActivity;

public class EmailVerificationActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email_verification);
    }
}
