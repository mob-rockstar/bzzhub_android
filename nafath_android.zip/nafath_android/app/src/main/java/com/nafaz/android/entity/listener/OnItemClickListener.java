package com.nafaz.android.entity.listener;

import android.view.View;

public interface OnItemClickListener {

    void onItemClick(View v);
}
