package com.nafaz.android.ui.fragment;

import androidx.lifecycle.ViewModel;

public class NafadhFaceCaptureViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
