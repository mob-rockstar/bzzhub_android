package com.universal.alhamrani.ecrusbintegration

class ReconData {
    var id = 0
    var card_scheme_ar: String? = null
    var card_scheme_en: String? = null
    var transaction_flag_ar: String? = null
    var transaction_flag_en: String? = null
    var transaction_flag: String? = null
    var card_scheme_short_name: String? = null
    var total_db_amount: String? = null
    var total_cr_amount: String? = null
    var total_naqd_amount: String? = null
    var total_cash_advance_amount: String? = null
    var total_authorization_amount: String? = null
    var total_amount: String? = null
    var mada_total_db: String? = null
    var mada_total_db_count: String? = null
    var mada_total_cr: String? = null
    var mada_total_cr_count: String? = null
    var mada_total_cashback: String? = null
    var mada_total_cashadvance: String? = null
    var mada_auth_count: String? = null
    var mada_totals: String? = null
    var pos_total_db: String? = null
    var pos_total_db_count: String? = null
    var pos_total_cr: String? = null
    var pos_total_cr_count: String? = null
    var pos_total_cashback: String? = null
    var pos_total_cashadvance: String? = null
    var pos_auth_count: String? = null
    var pos_totals: String? = null
    var pos_details_purchase_off_count: String? = null
    var pos_details_purchase_off: String? = null
    var pos_details_purchase_on: String? = null
    var pos_details_purchase_on_count: String? = null
    var pos_details_cashback_count: String? = null
    var pos_details_cashback: String? = null
    var pos_details_reversal: String? = null
    var pos_details_reversal_count: String? = null
    var pos_details_refund_count: String? = null
    var pos_details_refund: String? = null
    var pos_details_completion: String? = null
    var pos_details_completion_count: String? = null
}