package com.universal.alhamrani.ecrusbintegration


import android.Manifest
import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.os.Environment
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.hoho.android.usbserial.driver.*
import com.hoho.android.usbserial.util.SerialInputOutputManager
import java.io.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors


class AlhamraniLibrary:AppCompatActivity() {

    var port: UsbSerialPort? = null
    var isProcessing = false
    lateinit var filter: IntentFilter
    lateinit var driver: UsbSerialDriver
    lateinit var connection: UsbDeviceConnection
    private val ACTION_USB_PERMISSION = "com.android.example.USB_PERMISSION"
    lateinit var usbManager: UsbManager
    lateinit var permissionIntent: PendingIntent
    var MSGID : String = ""


    fun sendTransaction(
        msg_id: String,
        ecr_no: String,
        ecr_receipt_no: String,
        amount: String,
        field1: String,
        field2: String,
        field3: String,
        field4: String,
        field5: String
    ) {
        logs("-----------------START LOG TXN VERSION 1.0.0 (02-25-2021) ---------------------");
        MSGID = msg_id
        Thread(Runnable {

            sendStartCommand()
            isProcessing = true

            //format amount
            var formattedAmount = amount.replace(".", "")
            formattedAmount = formattedAmount.padStart(12, '0')
            // end format

            val Msg_ID = msg_id.toByteArray()
            val ECR_No = ecr_no.toByteArray()
            val ECR_Recpt_No = ecr_receipt_no.toByteArray()
            val Trans_Amount = formattedAmount.toByteArray()
            val field1 = field1.toByteArray()
            val field2 = field2.toByteArray()
            val field3 = field3.toByteArray()
            val field4 = field4.toByteArray()
            val field5 = field5.toByteArray()

            var out = ByteArrayOutputStream()

            val STX = 2
            val ETX = 3
            val FS = 28
            var LRC: Int = 0

            out.write(STX)
            out.write(Msg_ID)
            out.write(ECR_No)
            out.write(FS)
            out.write(ECR_Recpt_No)
            out.write(FS)
            out.write(Trans_Amount)
            out.write(FS)
            out.write(field1)
            out.write(FS)
            out.write(field2)
            out.write(FS)
            out.write(field3)
            out.write(FS)
            out.write(field4)
            out.write(FS)
            out.write(field5)
            out.write(ETX)

            val LRCByte = out.toByteArray()
            logs("SENDING TRANSACTION : " + String(out.toByteArray()))
            var send = "SENDING TRANSACTION : "
            for (d in out.toByteArray()) {
                send = send.plus(" ").plus(String.format("%02X", d))
            }

            var x = 1
            while (x < LRCByte.size) {
                LRC = LRC xor LRCByte.get(x).toInt()
                ++x
            }

            out.write(LRC)

            try {
                port?.write(out.toByteArray(), 3000)
                logs("SENDING TRANSACTION SUCCESS : " + send)

            } catch (ex: java.lang.Exception) {
                logs("SENDING TRANSACTION FAILED " + ex.localizedMessage)
            }
        }).start()
    }

    var usbReceiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {

            if (ACTION_USB_PERMISSION == intent.action) { // check USB PERMISSION IF GRANTED OR NOT
                synchronized(this) {

                    if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                        if (initializeAU()) {
                            initListener(context)
                        }
                    } else {
                        //  Log.d(TAG, "permission denied for device $device")
                    }
                }
            } else if (UsbManager.ACTION_USB_DEVICE_DETACHED == intent.action) {
                //   disableButton()
                logs("USB DEVICE IS DE-TACHED")
            } else if (UsbManager.ACTION_USB_DEVICE_ATTACHED == intent.action) {
                logs("USB DEVICE IS ATTACHED")
                if (!intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                    requestPermission(context)
                } else {
                    if (initializeAU()) {
                        initListener(context)
                    }
                }
            }

        }
    }

    fun initListener(context: Context) {
        var port = getInitializedPort()
        var usbIoManager = SerialInputOutputManager(
            port,
            context as SerialInputOutputManager.Listener
        )
        Executors.newSingleThreadExecutor().submit(usbIoManager)
        // enableButton()
    }


    fun requestPermission(appContext: Context) {

        filter = IntentFilter(ACTION_USB_PERMISSION)
        filter.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
        filter.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)

        appContext.registerReceiver(usbReceiver, filter)

        if (ContextCompat.checkSelfPermission(
                appContext as Activity,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
            == PackageManager.PERMISSION_DENIED
        ) {
            ActivityCompat
                .requestPermissions(
                    appContext as Activity, arrayOf(
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ),
                    10
                );
        }

        logs("REQUESTING PERMISSION")

        permissionIntent = PendingIntent.getBroadcast(
            appContext,
            0,
            Intent(ACTION_USB_PERMISSION),
            0
        )
        usbManager = appContext.getSystemService(Context.USB_SERVICE) as UsbManager
        // GET DRIVER HERE FOR DEVICE
        val deviceList: HashMap<String, UsbDevice> = usbManager.deviceList
        if (deviceList.size != 0) {
            usbManager.requestPermission(
                deviceList.get(deviceList.iterator().next().key),
                permissionIntent
            )
        }

    }

    fun initializeAU() : Boolean {

        logs("INITIALIZING USB PORT");
        // CUSTOM DRIVER FOR INGENICO ADDING
        try {
            val customTable = ProbeTable()

            customTable.addProduct(2816, 87, CdcAcmSerialDriver::class.java) // UPT INGENICO
            customTable.addProduct(2816, 131, CdcAcmSerialDriver::class.java) // Link/2500
            customTable.addProduct(2816, 85, CdcAcmSerialDriver::class.java) // MOVE 2500
            customTable.addProduct(2816, 83, CdcAcmSerialDriver::class.java) // MOVE 3500
            customTable.addProduct(2816, 84, CdcAcmSerialDriver::class.java) // DESK 3500
            customTable.addProduct(1947, 40, CdcAcmSerialDriver::class.java) // ICT2xx INGENICO

            val prober = UsbSerialProber(customTable)
            //    Find all available drivers from attached devices.

            val availableDrivers = prober.findAllDrivers(usbManager)

            if (availableDrivers.isEmpty()) {
                logs("NO DRIVER AVAILABLE FOR  DEVICE");
                logs("NEED TO ADD CUSTOM DRIVER");

                return false
            } else {
                logs("DRIVER IS AVAILABLE " + availableDrivers.get(0).device.productName);
                // Open a connection to the first available driver.
                driver = availableDrivers.get(0)

                connection = usbManager.openDevice(driver.device)

                portOpen()

                return  true
            }
        } catch (ex: Exception) {
            logs("ERROR INITIALIZE PORT-" + ex.localizedMessage)
            return false
        }

    }

    fun portOpen() {

        port = driver.getPorts().get(0)

        try {
            port?.open(connection)
            port?.setParameters(19200, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)

            logs("PORT SUCCESSFULLY OPEN!")
        } catch (e: IOException) {
            Log.e("ERROR OPENNING", "ERROR OPENING PORT")
            logs("ERROR OPENNING ERROR OPENING PORT")
        } finally {

        }
    }

    fun getInitializedPort() : UsbSerialPort?{
        return port
    }

    fun logs(logmessage: String) {

        val file_format = SimpleDateFormat("yyyy-MM-dd")
        val date_and_time = SimpleDateFormat("yyyy-MM-dd hh:mm:ss")
        val currentDate = file_format.format(Date())

        var appPath = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            Environment.getStorageDirectory()
        } else {
            Environment.getExternalStorageDirectory()
        }

        val au_dir = File(appPath.absolutePath + "/Download/AU_logs")
        val au_log = File(au_dir.absolutePath + "/" + currentDate + ".txt")
        try {
            if (!au_dir.exists()) {
                var result =  au_dir.mkdirs()
                Log.v("", result.toString())
            }

            if (!au_log.exists()) {
              au_log.createNewFile()
            }

            val fw = FileWriter(au_log, true)
            fw.write(date_and_time.format(Date()) + " - " + logmessage + "\r")
            fw.close()

        } catch (e: IOException) {
            Log.v("", "")
        }

    }

    fun parseResponse(result: ByteArray): Response {
        var response = Response()
        var response_hex = ""
        var cases = 0
        var index = 0

        logs("DATA RECEIVED - LENGTH :" + result!!.size)


        if (result.size == 1) {
            logs("ACK DATA RECEIVED  : ACK")
        } else {
            // send ack
            var ack =  ByteArray(1)
            ack[0] = 6
            port?.write(ack, 3000)

            for (d in result) {
                response_hex = response_hex.plus(" ").plus(String.format("%02X", d))
            }

            logs("DATA RECEIVED (HEX) :" + response_hex!!)
            logs("DATA RECEIVED (STRING) :" + String(result!!))
                // logs("TRYING TO PARSE RESPONSE")
        }
        //Thread.sleep(500)
        val numBytesRead = port?.read(result, 3000)


        if (result.isNotEmpty()) {

            // checking the buffer if ACK is still appended
            //if (result!![numBytesRead - 1]?.toInt() != 6) {
                try {
                    for (i in 1..(result.size - 1)) {

                        if (result[i].toInt() == 28) {
                            when (cases) {
                                0 -> {  // extra fields

                                    index = i + 1
                                    cases++
                                }
                                1 -> { // RESPONSE CODE
                                    response.response_code =
                                        String(result.copyOfRange(index, i))
                                    index = i + 1
                                    cases++
                                }
                                2 -> { // ECR NUM
                                    response.ecr_number = String(result.copyOfRange(index, i))
                                    index = i + 1
                                    cases++

                                }
                                3 -> { // ECR RECEIPT NUM
                                    response.ecr_receipt_number =
                                        String(result.copyOfRange(index, i))
                                    index = i + 1
                                    cases++
                                }
                                4 -> { // AMOUNT
                                    response.amount = String(result.copyOfRange(index, i))
                                    index = i + 1
                                    cases++
                                }
                                5 -> { //CARD NUMBER
                                    response.card_number = String(result.copyOfRange(index, i))
                                    index = i + 1
                                    cases++
                                }
                                6 -> { //CARD EXPIRY
                                    response.card_expiry = String(result.copyOfRange(index, i))
                                    index = i + 1
                                    cases++
                                }
                                7 -> { // CARD TYPE
                                    response.card_type = String(result.copyOfRange(index, i))
                                    index = i + 1
                                    cases++
                                }
                                8 -> { //AUTH CODE
                                    response.auth_code = String(result.copyOfRange(index, i))
                                    index = i + 1
                                    cases++
                                }
                                9 -> { // TXN DATE

                                    response.trans_date = String(result.copyOfRange(index, i))
                                    index = i + 1
                                    cases++


                                }
                                10 -> { // TXN TIME
                                    response.trans_time = String(result.copyOfRange(index, i))
                                    index = i + 1
                                    cases++

                                }
                                11 -> { //RRN
                                    response.rrn = String(result.copyOfRange(index, i))
                                    index = i + 1
                                    cases++


                                }
                                12 -> { // TID
                                    response.tid = String(result.copyOfRange(index, i))
                                    index = i + 1
                                    cases++
                                }

                            }
                        }

                    }

                } catch (e: Exception) {
                    Log.e("ERROR PARSING ", e.message!!)
                }

            if(result.size > 1) {
                logs("-----------------END TXN LOG---------------------");
            }


        }

        return response
    }

    fun sendStartCommand() {

        try {
            logs("SENDING LOGIN SCRIPT")

            var enqlrc = 0
            val sENQ = ByteArray(4)
            sENQ[0] = 2
            sENQ[1] = 5
            enqlrc = enqlrc xor 5
            sENQ[2] = 3
            sENQ[3] = (enqlrc xor 3).toByte()

            port?.write(sENQ, 0)
            logs("SUCCESS SENDING LOGIN SCRIPT")
        } catch (e: Exception) {
            logs("ERROR  LOGIN SCRIPT " + e.localizedMessage)
        }
    }



}
