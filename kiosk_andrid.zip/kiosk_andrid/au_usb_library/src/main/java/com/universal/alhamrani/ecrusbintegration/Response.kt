package com.universal.alhamrani.ecrusbintegration

class Response {
    public var response_code : String? = ""
    public var ecr_number : String? = ""
    public var ecr_receipt_number : String? = ""

    public var amount : String? = ""
    public var card_number : String? = ""
    public var card_expiry : String? = ""
    public var card_type : String? = ""
    public var trans_date : String? = ""
    public var trans_time : String? = ""
    public var rrn : String? = ""
    public var tid : String? = ""
    public var auth_code : String? = ""
    public var card_data_input_type : Byte? = null

    //public lateinit var recon_data : MutableList<ReconData>
}