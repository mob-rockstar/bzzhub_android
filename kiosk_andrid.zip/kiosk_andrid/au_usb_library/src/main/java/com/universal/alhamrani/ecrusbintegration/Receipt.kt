package com.universal.alhamrani.ecrusbintegration

class Receipt {
    lateinit var receipt_data: ByteArray
    var arab_merchant: String? = null
    var merchant: String? = null
    var address: String? = null
    var arab_address: String? = null
    var city_arab: String? = null
    var city: String? = null
    var start_date: String? = null
    var start_time: String? = null
    var bank: String? = null
    var MID: String? = null
    var TID: String? = null
    var card_detail: String? = null
    var MCC: String? = null
    var STAN: String? = null
    var SW_VER: String? = null
    var RRN: String? = null
    var card_scheme_en: String? = null
    var card_scheme_ar: String? = null
    var transaction_type_en: String? = null
    var transaction_type_ar: String? = null
    var transaction_typetxt_en: String? = null
    var transaction_typetxt_ar: String? = null
    var transaction_en: String? = null
    var transaction_ar: String? = null
    var cashback_amount_en: String? = null
    var cashback_amount_ar: String? = null
    var response_txt_ar: String? = null
    var response_txt_en: String? = null
    var response_en: String? = null
    var response_ar: String? = null
    var footer_mada_en: String? = null
    var footer_mada_ar: String? = null
    var footer_rcpt_en: String? = null
    var footer_rcpt_ar: String? = null
    var footer_copyreceipt_en: String? = null
    var footer_copyreceipt_ar: String? = null
    var emv_data: String? = null
    var auth_code_en: String? = null
    var auth_code_ar: String? = null
    var end_date: String? = null
    var end_time: String? = null
    var campaign_message: String? = null
    var signature_text1_en: String? = null
    var signature_text1_ar: String? = null
    var signature_text2_en: String? = null
    var signature_text2_ar: String? = null
}