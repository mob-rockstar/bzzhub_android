package com.blazma.kiosk.util

import android.app.Activity
import android.content.Context
import android.net.ConnectivityManager
import java.text.SimpleDateFormat
import java.util.*
import java.util.regex.Matcher
import java.util.regex.Pattern

object Helper {
    private const val EMAIL_PATTERN =
        "(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"" +
                "(?:[\\x01-\\x07\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01" +
                "-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x07\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])"

    fun isInternetAvailable(activity: Activity): Boolean {
        val cm = activity.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetwork = cm.activeNetworkInfo
        val connectivity = activeNetwork != null && activeNetwork.isConnectedOrConnecting
        if (connectivity) {
            return true
        }
        return false
    }

    fun isValidEmail(mEmail: String?): Boolean {
        val pattern = Pattern.compile(EMAIL_PATTERN)
        val matcher: Matcher = pattern.matcher(mEmail!!)
        return matcher.matches()
    }

    fun getDateFormat(dateStr: String?): String {
        return try {
            if(dateStr == null) ""
            val formatter = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.'000000Z'", Locale.ENGLISH)
            val date = formatter.parse(dateStr!!)
            val pattern =  SimpleDateFormat("d MMM yyyy", Locale.ENGLISH)
            pattern.format(date!!)
        } catch (e: Exception){
            ""
        }
    }

    fun getDate(dateStr: String): Date {
        val formatter = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.'000000Z'")
        formatter.setTimeZone(TimeZone.getTimeZone("UTC"))
        val date = formatter.parse(dateStr)

        val formatter2 = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.'000000Z'")
        formatter2.setTimeZone(TimeZone.getDefault())
        val ourDate = formatter2.format(date)

        val formatter3 = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.'000000Z'")
        val localDate = formatter3.parse(ourDate)

        return localDate
    }

    fun isOneHourDifference(dateStr: String): Boolean {
        val formatter = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.'000000Z'", Locale.ENGLISH)
        val date = formatter.parse(dateStr)
        val offset: Int = TimeZone.getDefault().rawOffset + TimeZone.getDefault().dstSavings
        if(date != null){
            val cal: Calendar = Calendar.getInstance()
            val currentDate = cal.time
            val diff: Long = currentDate.time - (date!!.time + offset)
            val seconds = diff / 1000
            val minutes = seconds / 60
            val hours = minutes / 60
            return hours < 1
        }else{
            return false
        }
    }
}