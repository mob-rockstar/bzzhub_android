package com.blazma.kiosk.ui.main

import android.content.Intent
import android.os.Bundle
import java.lang.IllegalStateException
import android.graphics.Color
import android.util.Log
import androidx.appcompat.app.AlertDialog
import com.scandit.datacapture.barcode.capture.*
import com.scandit.datacapture.barcode.data.Symbology
import com.scandit.datacapture.barcode.ui.overlay.BarcodeCaptureOverlay
import com.scandit.datacapture.core.capture.DataCaptureContext
import com.scandit.datacapture.core.data.FrameData
import com.scandit.datacapture.core.source.Camera
import com.scandit.datacapture.core.source.FrameSourceState
import com.scandit.datacapture.core.ui.DataCaptureView
import com.scandit.datacapture.core.ui.style.Brush
import com.scandit.datacapture.core.ui.viewfinder.RectangularViewfinder
import com.scandit.datacapture.core.ui.viewfinder.RectangularViewfinderStyle
import java.util.HashSet
import com.scandit.datacapture.barcode.capture.BarcodeCapture
import com.scandit.datacapture.barcode.capture.BarcodeCaptureSession
import com.scandit.datacapture.barcode.capture.BarcodeCaptureSettings
import com.scandit.datacapture.barcode.data.Barcode

class ScanActivity: CameraPermissionActivity(), BarcodeCaptureListener{

    val SCANDIT_LICENSE_KEY = "ASlhFJqBDhXYEzgshAUAaCUMxci2HEeZb1FlO+0b0tQucfjsBF9GpuxsyIguV+x6g3iaw+54t1h4CP8UQWztBhItkiQbfMxNRyRpo5dyC9+BFtb1JEcw9AwrfDnMPIwbyg+J85AHsN5tgZIXuzT0k99FYHHV/saUdhYO6BxsIspK9+Di57MxOUE1LCr6hkPQRvqYebM14IR1m3SI1knKnDidRnmwXp8pFkCEK8er5XMEyTKWfjGdbDoLS1rtsyg3D/txQwKBFoTSth76+rXo1sxsv5wSqQi2PA9mjU0i8/hHqA6IUG3bTfBl/vO21SLjFswEwb0xvGCgtMrjKFl6Y4PC2GMNmZc9llK7Rthd4Up1oyxE4i1QSZ0aGKEVZ5SZp56RUyGb6OR0dQOf59oMj92FjXuWfFGRfyXd+dogoF3PiRBbKATp2NktptwRxAfV8FvW62CMpJkqgzP9Y6xQcrJqIHTtQnZwqf043SFJv6Rb0vaBJxC61b4Xzcg4xGsFXIBNbiskDHTXK8f0q4V/4LOkiuq3QGrHxdbD2a0GVrm74eUnuDkRE5xQ4QTRgIgr02D0jqhHzxmYH6CB/YnevnvM270IVQ0hF8CayJAYR++dFkl00/ygl+9wDpHU3ulYGFYtTss1mfg3Nedz5sQ4v2lCjnXq5NQgprvVIpDNs8ZVTpGcBynfZ1N25JDCwpsAJXMWoWbl8S6TZA6wVS8m3vS0571ngzBVddSiStJHTzKbaJLJC8LDvEKbKwNJ7a+XM6jf+0TW6KmyHIgU2rwMZe97Bm3Rmxd/9mNTGhFXHwvpRI2ms02ARg=="

    private var dataCaptureContext: DataCaptureContext? = null
    private var barcodeCapture: BarcodeCapture? = null
    private var camera: Camera? = null
    private var dataCaptureView: DataCaptureView? = null

    private var dialog: AlertDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize and start the barcode recognition.
        initializeAndStartBarcodeScanning()
//        goToOrderScreen()
    }

    private fun initializeAndStartBarcodeScanning() {
        // Create data capture context using your license key.
        dataCaptureContext = DataCaptureContext.forLicenseKey(SCANDIT_LICENSE_KEY)

        // Use the default camera with the recommended camera settings for the BarcodeCapture mode
        // and set it as the frame source of the context. The camera is off by default and must be
        // turned on to start streaming frames to the data capture context for recognition.
        // See resumeFrameSource and pauseFrameSource below.
        camera = Camera.getDefaultCamera(BarcodeCapture.createRecommendedCameraSettings())
        if (camera != null) {
            dataCaptureContext!!.setFrameSource(camera)
        } else {
            throw IllegalStateException("Sample depends on a camera, which failed to initialize.")
        }
        val barcodeCaptureSettings = BarcodeCaptureSettings()
        val symbologies = HashSet<Symbology>()
        symbologies.add(Symbology.EAN13_UPCA)
        symbologies.add(Symbology.EAN8)
        symbologies.add(Symbology.UPCE)
        symbologies.add(Symbology.CODE11)
        symbologies.add(Symbology.QR)
        symbologies.add(Symbology.CODE39)
        symbologies.add(Symbology.CODE128)

        barcodeCaptureSettings.enableSymbologies(symbologies)

        // Create new barcode capture mode with the settings from above.
        barcodeCapture =
            BarcodeCapture.forDataCaptureContext(dataCaptureContext, barcodeCaptureSettings)

        // Register self as a listener to get informed whenever a new barcode got recognized.
        barcodeCapture!!.addListener(this)

        // To visualize the on-going barcode capturing process on screen, setup a data capture view
        // that renders the camera preview. The view must be connected to the data capture context.
        dataCaptureView = DataCaptureView.newInstance(this, dataCaptureContext)

        // Add a barcode capture overlay to the data capture view to render the location of captured
        // barcodes on top of the video preview.
        // This is optional, but recommended for better visual feedback.
        val overlay = BarcodeCaptureOverlay.newInstance(
            barcodeCapture!!,
            dataCaptureView
        )
        overlay.viewfinder = RectangularViewfinder(RectangularViewfinderStyle.SQUARE)

        // Adjust the overlay's barcode highlighting to match the new viewfinder styles and improve
        // the visibility of feedback. With 6.10 we will introduce this visual treatment as a new
        // style for the overlay.
        val brush = Brush(Color.TRANSPARENT, Color.WHITE, 3f)
        overlay.brush = brush
        setContentView(dataCaptureView)
    }

    override fun onPause() {
        pauseFrameSource()
        super.onPause()
    }

    override fun onDestroy() {
        barcodeCapture!!.removeListener(this)
        dataCaptureContext!!.removeMode(barcodeCapture!!)
        super.onDestroy()
    }

    private fun pauseFrameSource() {
        // Switch camera off to stop streaming frames.
        // The camera is stopped asynchronously and will take some time to completely turn off.
        // Until it is completely stopped, it is still possible to receive further results, hence
        // it's a good idea to first disable barcode capture as well.
        barcodeCapture?.isEnabled = false
        camera!!.switchToDesiredState(FrameSourceState.OFF, null)
    }

    override fun onResume() {
        super.onResume()

        // Check for camera permission and request it, if it hasn't yet been granted.
        // Once we have the permission the onCameraPermissionGranted() method will be called.
        requestCameraPermission()
    }

    override fun onCameraPermissionGranted() {
        resumeFrameSource()
    }

    private fun resumeFrameSource() {
        dismissScannedCodesDialog()

        // Switch camera on to start streaming frames.
        // The camera is started asynchronously and will take some time to completely turn on.
        barcodeCapture?.isEnabled = true
        camera!!.switchToDesiredState(FrameSourceState.ON, null)
    }

    private fun dismissScannedCodesDialog() {
        if (dialog != null) {
            dialog!!.dismiss()
            dialog = null
        }
    }

    private fun showResult(result: String) {
        barcodeCapture?.isEnabled = true
//        val builder = AlertDialog.Builder(this)
//        dialog = builder.setCancelable(false)
//            .setTitle(result)
//            .setPositiveButton(
//                R.string.ok
//            ) { dialog, which -> barcodeCapture?.isEnabled = true }
//            .create()
//        dialog!!.show()
        var orderId = result.substring(result.lastIndexOf("/") + 1)
        val intent = Intent(this@ScanActivity, MyOrderActivity::class.java)
        intent.putExtra("orderId", orderId)
        Log.e("oder id", orderId)
        startActivity(intent)
        finish()
    }

    fun goToOrderScreen(){
        val intent = Intent(this@ScanActivity, MyOrderActivity::class.java)
        intent.putExtra("orderId", "1801905")
        startActivity(intent)
        finish()
    }

    override fun onBarcodeScanned(
        barcodeCapture: BarcodeCapture,
        session: BarcodeCaptureSession,
        data: FrameData
    ) {
        if (session.newlyRecognizedBarcodes.isEmpty()) return

        val barcode: Barcode = session.newlyRecognizedBarcodes.get(0)
        barcodeCapture.isEnabled = false
        val result = barcode.data
        runOnUiThread {
            if (result != null) {
                showResult(result)
            }
        }
    }
}