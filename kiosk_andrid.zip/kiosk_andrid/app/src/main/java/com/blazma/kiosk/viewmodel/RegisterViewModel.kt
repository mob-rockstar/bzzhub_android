package com.blazma.kiosk.viewmodel

import android.annotation.SuppressLint
import android.app.Activity
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.blazma.kiosk.restapi.RetrofitClient
import com.blazma.kiosk.restapi.model.RestObservable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class RegisterViewModel :ViewModel() {
    var _mResponse: MutableLiveData<RestObservable> = MutableLiveData()
    val mResponse: LiveData<RestObservable> = _mResponse

    var _mResponseNationalities: MutableLiveData<RestObservable> = MutableLiveData()
    val mResponseNationalities: LiveData<RestObservable> = _mResponseNationalities

    var _mResponseAddMember: MutableLiveData<RestObservable> = MutableLiveData()
    val mResponseAddMember: LiveData<RestObservable> = _mResponseAddMember

    @SuppressLint("CheckResult")
    fun register(activity: Activity, showLoader:Boolean, map: HashMap<String, String>) {
        RetrofitClient.getApiService().register(map)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { _mResponse.value = RestObservable.loading(activity, showLoader) }
            .subscribe(
                { _mResponse.value = RestObservable.success(it) },
                { _mResponse.value = RestObservable.error(activity, it) }
            )
    }

    @SuppressLint("CheckResult")
    fun getNationalities(activity: Activity, showLoader:Boolean) {
        RetrofitClient.getApiService().getNationalities()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { _mResponseNationalities.value = RestObservable.loading(activity,showLoader) }
            .subscribe(
                { _mResponseNationalities.value = RestObservable.success(it) },
                { _mResponseNationalities.value = RestObservable.error(activity,it) }
            )
    }

    @SuppressLint("CheckResult")
    fun addMember(activity: Activity, showLoader: Boolean, userId: String, token: String, map: HashMap<String, String>) {
        RetrofitClient.getApiService().addMember(userId, token, userId, map)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { _mResponseAddMember.value = RestObservable.loading(activity, showLoader) }
            .subscribe(
                { _mResponseAddMember.value = RestObservable.success(it) },
                { _mResponseAddMember.value = RestObservable.error(activity, it) }
            )
    }
}