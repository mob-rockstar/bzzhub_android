package com.blazma.kiosk.model

data class ProviderDetail(
    val ID : String,
    val NAME_EN : String,
    val NAME_AR: String,
    val DESC_EN : String?,
    val DESC_AR : String?,
    val GPS_LATITUDE : String,
    val GPS_LONGITUDE : String,
    val STATE : Int,
    val IMAGE_URL : String,
    val WEBSITE_LOGO : String,
    val DISTANCE : String,
    val CITYSTATE: CityState,
    val allTests: List<Pill>
)