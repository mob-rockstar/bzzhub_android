package com.blazma.kiosk.model

data class Category(
    val ID : String,
    val NAME_EN : String,
    val NAME_AR: String,
    val LAB_CATEGORY_TYPE_ID : Int,
)