package com.blazma.kiosk.util

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import com.blazma.kiosk.R
import java.util.*

class ProgressHUD(context: Context, theme: Int) : Dialog(context, theme) {

    companion object {
        fun create(context: Context): ProgressHUD {
            val dialogLoading = ProgressHUD(context, R.style.DialogTheme)
            dialogLoading.setTitle("")
            dialogLoading.setContentView(R.layout.progressview)

            dialogLoading.setCancelable(false)
            Objects.requireNonNull<Window>(dialogLoading.getWindow())
                .setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialogLoading.window!!.attributes.gravity = Gravity.CENTER
            dialogLoading.window!!.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
//            val lp = dialogLoading.window!!.attributes
//            lp.dimAmount = 0.2f
//            dialogLoading.window!!.attributes = lp
//            dialogLoading.getWindow ()!!.setLayout(
//                ViewGroup.LayoutParams.MATCH_PARENT,
//                ViewGroup.LayoutParams.MATCH_PARENT
//            )
            dialogLoading.show()
           return dialogLoading
        }
    }
}