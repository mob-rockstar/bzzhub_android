package com.blazma.kiosk.ui.main

import android.annotation.SuppressLint
import android.app.Dialog
import android.os.Bundle
import android.text.Html
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.blazma.kiosk.R
import com.blazma.kiosk.databinding.SheetPillDetailBinding
import com.blazma.kiosk.model.Pill
import com.blazma.kiosk.util.LocaleHelper
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class PillDetailSheetFragment(clickListener: OnClickListener, item: Pill?): BottomSheetDialogFragment() {

    private lateinit var binding: SheetPillDetailBinding
    private var listener = clickListener
    private var test: Pill? = item

    companion object {
        fun newInstance(clickListener: OnClickListener, item: Pill?): PillDetailSheetFragment {
            return PillDetailSheetFragment(clickListener, item)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = SheetPillDetailBinding.inflate(layoutInflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initView()
    }

    @SuppressLint("RestrictedApi")
    override fun setupDialog(dialog: Dialog, style: Int) {
        super.setupDialog(dialog, style)
        val rootView = View.inflate(context, R.layout.sheet_pill_detail, null)
        dialog.setContentView(rootView)

        val bottomSheet = dialog.window?.findViewById(com.google.android.material.R.id.design_bottom_sheet) as FrameLayout
        val behaviour = BottomSheetBehavior.from(bottomSheet)

        behaviour.state = BottomSheetBehavior.STATE_EXPANDED
    }

    private fun initView() {
        binding.imgBack.setOnClickListener{
            this@PillDetailSheetFragment.dismiss()
        }

        binding.btAddToCart.setOnClickListener{
            this@PillDetailSheetFragment.dismiss()
            listener.addCart()
        }

        binding.tvPrice.text = test?.PRICE
        binding.tvHours.text = getString(R.string.within_hours, test?.HOURS)
        if(context?.let { LocaleHelper.getLanguage(it) } == "en"){
            binding.tvDesc.text = Html.fromHtml(test?.DESC_EN)
        }else{
            binding.tvDesc.text = Html.fromHtml(test?.DESC_AR)
        }
    }

    interface OnClickListener{
        fun addCart()
    }
}