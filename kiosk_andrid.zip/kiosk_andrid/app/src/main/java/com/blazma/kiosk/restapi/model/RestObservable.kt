package com.blazma.kiosk.restapi.model

import android.annotation.TargetApi
import android.app.Activity
import android.content.ContentValues.TAG
import android.os.Build
import android.util.Log
import android.widget.Toast
import com.blazma.kiosk.restapi.RetrofitClient
import com.blazma.kiosk.ui.main.model.MessageEventModel
import com.blazma.kiosk.util.Constants
import com.blazma.kiosk.util.ProgressHUD
import com.jakewharton.retrofit2.adapter.rxjava2.HttpException
import io.reactivex.annotations.NonNull
import okhttp3.ResponseBody
import org.greenrobot.eventbus.EventBus
import retrofit2.Response
import java.io.IOException
import javax.net.ssl.HttpsURLConnection

class RestObservable(
    val status: Status,
    val data: Any?,
    val error: Any?
) {
    companion object {
        var mProgressDialog: ProgressHUD? = null

        @TargetApi(Build.VERSION_CODES.LOLLIPOP)
        fun loading(activity: Activity, showLoader: Boolean): RestObservable {
            if (showLoader) {
                mProgressDialog = ProgressHUD.create(activity)
                mProgressDialog!!.show()
            }else{
                if (mProgressDialog != null && mProgressDialog!!.isShowing)
                    mProgressDialog!!.dismiss()
            }

            Log.e("REST", "Loading")
            return RestObservable(Status.LOADING, null, null)
        }

        fun success(@NonNull data: Any): RestObservable {
            if (mProgressDialog != null && mProgressDialog!!.isShowing)
                mProgressDialog!!.dismiss()
            return RestObservable(Status.SUCCESS, data, null)
        }

        fun error(activity: Activity, @NonNull error: Throwable): RestObservable {
            var response:Response<*>? = null
            if (mProgressDialog != null && mProgressDialog!!.isShowing)
                mProgressDialog!!.dismiss()
            try {
                // We had non-200 http error
                if (error is HttpException) {
                    val httpException = error as HttpException
                    response = httpException.response()
                    when(httpException.code())
                    {
                        HttpsURLConnection.HTTP_UNAUTHORIZED ->
                        {
                            return RestObservable(
                                    Status.ERROR,
                                    null,
                                    "Session Expired ! Login Again "
                            )
                        }
                        HttpsURLConnection.HTTP_FORBIDDEN ->
                        {
                            EventBus.getDefault().post(MessageEventModel(Constants.UNAUTHORIZED))
                            return RestObservable(
                                Status.ERROR,
                                null,
                                "Session Expired ! Login Again "
                            )
                        }
                        else ->{
                            return RestObservable(
                                    Status.ERROR,
                                    null,
                                    callErrorMethod(activity, response.errorBody())
                            )
                        }
                    }
                    Log.i(TAG, error.message() + " / " + error.javaClass)
                }
                // A network error happened
                if (error is IOException) {
                    Log.i(TAG, error.message + " / " + error.javaClass)
                    return RestObservable(Status.ERROR, null, "Server not responding")
                }
                Log.i(TAG, error.message + " / " + error.javaClass)
            } catch (e: Exception) {
                Log.i(TAG, e.message!!)
                return RestObservable(Status.ERROR, null, error)
            }

            return RestObservable(Status.ERROR, null, error)
        }

        private fun callErrorMethod(activity: Activity, responseBody: ResponseBody?): String {
            val converter = RetrofitClient.getRetrofit()
                .responseBodyConverter<RestError>(
                    RestError::class.java,
                    arrayOfNulls<Annotation>(0)
                )
            try {
                val errorResponse = converter.convert(responseBody!!)
                return if (errorResponse!!.httpStatus == Constants.errorCode) {
                    Toast.makeText(
                        activity,
                        "Session Expired ! Login Again ",
                        Toast.LENGTH_SHORT
                    ).show()
                    "Session Expired ! Login Again"!!
                } else /*if (errorResponse!!.code == 400)*/ {
                    val errorMessage = errorResponse.errorMessage
                    errorMessage!!
                }

            } catch (e: IOException) {
                return "Server not responding"
            }
        }
    }
}
