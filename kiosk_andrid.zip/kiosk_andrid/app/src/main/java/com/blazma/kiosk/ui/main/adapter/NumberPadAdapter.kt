package com.blazma.kiosk.ui.main.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.blazma.kiosk.databinding.RowNumberPadBinding
import com.blazma.kiosk.util.DebouncedOnClickListener

class NumberPadAdapter(onClickListener: OnClickListener, context: Context?) : RecyclerView.Adapter<NumberPadAdapter.ViewHolder>() {

    private var items: List<String>? = null
    private val onClickListener = onClickListener
    private val context: Context? = context

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = RowNumberPadBinding
            .inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int = items?.size?: 0

    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(items?.get(position), position)

    @SuppressLint("NotifyDataSetChanged")
    fun setData(list: List<String>?){
        items = list
        notifyDataSetChanged()
    }

    inner class ViewHolder(val binding: RowNumberPadBinding) : RecyclerView.ViewHolder(binding.root) {
        @SuppressLint("NotifyDataSetChanged", "StringFormatMatches")
        fun bind(item: String?, position: Int) {
            binding.cvRow.setOnClickListener(object : DebouncedOnClickListener() {
                override fun onDebouncedClick(v: View?) {
                    onClickListener.onClick(item)
                }
            })
            if(item == "b"){
                binding.imgDone.visibility = View.GONE
                binding.imgDelete.visibility = View.VISIBLE
                binding.tvNumber.visibility = View.GONE
            }else if(item == "d"){
                binding.imgDone.visibility = View.VISIBLE
                binding.imgDelete.visibility = View.GONE
                binding.tvNumber.visibility = View.GONE
            }else{
                binding.imgDone.visibility = View.GONE
                binding.imgDelete.visibility = View.GONE
                binding.tvNumber.visibility = View.VISIBLE
                binding.tvNumber.text = item
            }
        }
    }

    interface OnClickListener{
        fun onClick(item: String?)
    }
}
