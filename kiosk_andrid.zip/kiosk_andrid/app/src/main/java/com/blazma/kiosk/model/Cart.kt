package com.blazma.kiosk.model

data class Cart(
    var packages : List<Package>,
    val packages_amount: String,
    val base_amount: String,
    val packages_count: String,
    val tax_amount: String,
    val extra_amount: String,
    val delivery_amount: String,
    val wallet_amount: String,
    val discount_amount: String,
    val coupon: String,
    val net_total: String,
)