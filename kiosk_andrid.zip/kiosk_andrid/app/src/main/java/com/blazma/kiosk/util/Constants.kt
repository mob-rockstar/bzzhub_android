package com.blazma.kiosk.util

object Constants {
    const val BASEURL = "https://deltapcr.com/"
    const val errorCode = 401

    const val FIREBASE_KEY = "firebase"
    const val USER_KEY = "user"
    const val USER_TOKEN = "user_token"

    //Event bus
    const val CART_ADD_WITH_MEMBER = 100
    const val CART_RELOAD = 101
    const val UNAUTHORIZED = 102

}