package com.blazma.kiosk.model

data class Order(
    val ID : String,
    val PAYMENT_METHOD_ID :  String,
    val BASE_AMOUNT: String,
    val TAX_AMOUNT :  String,
    val DISCOUNT_AMOUNT: String,
    val DELIVERY_AMOUNT :  String,
    val WALLET_AMOUNT :  String,
    val TOTAL_AMOUNT : String,
    val COUPON_CODE :  String,
    val ORDER_STATUS_ID : String,
    val DELIVERY_ADDRESS : String?,
    val DELIVERY_LATITIUDE : String?,
    val DELIVERY_LONGTITUDE : String?,
    val END_USER_ID :  String,
    val CREATE_DATE :  String,
    val UPDATE_DATE :  String,
)