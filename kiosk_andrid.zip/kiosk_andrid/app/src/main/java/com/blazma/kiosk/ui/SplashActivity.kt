package com.blazma.kiosk.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.blazma.kiosk.databinding.ActivitySplashBinding
import com.blazma.kiosk.util.LocaleHelper

class SplashActivity: AppCompatActivity() {

    private lateinit var binding: ActivitySplashBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        initView()
    }

    private fun initView(){
        LocaleHelper.onAttach(this)
        startActivity(Intent(this, WelcomeActivity::class.java))
    }
}