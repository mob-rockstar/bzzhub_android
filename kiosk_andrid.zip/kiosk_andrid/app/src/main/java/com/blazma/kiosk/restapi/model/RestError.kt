package com.blazma.kiosk.restapi.model

import com.google.gson.annotations.SerializedName

class RestError
{
    @SerializedName("httpStatus")
    var httpStatus: Int = 0

    @SerializedName("errorMessage")
    var errorMessage: String? = null
}