package com.blazma.kiosk.model

data class Package(
    val ID : String,
    val NAME_EN :  String,
    val NAME_AR: String,
    val PRICE :  String,
    val HOURS: String,
    val SMART_DESC_EN :  String?,
    val SMART_DESC_AR :  String?,
    val OLD_PRICE : String?,
    val IS_OFFER :  String?,
    val SHOW_SUMMARY : Boolean?,
    val DESC_EN : String?,
    val DESC_AR : String?,
    val MOBILE_IMAGE_URL_EN : String?,
    val MOBILE_IMAGE_URL_AR :  String?,
    val members: List<Member>?
)