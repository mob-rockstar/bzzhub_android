package com.blazma.kiosk.ui.main

import android.os.Bundle
import com.blazma.kiosk.databinding.ActivityPaymentCardBinding
import com.blazma.kiosk.ui.BaseActivity
import com.blazma.kiosk.util.InfoFailDialog

class PaymentCardActivity: BaseActivity() {

    private lateinit var binding: ActivityPaymentCardBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPaymentCardBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        initView()
    }

    private fun initView() {
//        InfoFailDialog.create(this, object : InfoFailDialog.OnClickListener{
//            override fun onClick() {
//                finish()
//            }
//        })
        if(intent != null){
            val totalPrice = intent.getStringExtra("total_price")
            binding.tvTotal.text = totalPrice
        }
    }
}