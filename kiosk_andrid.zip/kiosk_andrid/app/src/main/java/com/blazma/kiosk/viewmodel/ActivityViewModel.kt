package com.blazma.kiosk.viewmodel

import android.annotation.SuppressLint
import android.app.Activity
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.blazma.kiosk.model.Cart
import com.blazma.kiosk.restapi.RetrofitClient
import com.blazma.kiosk.restapi.model.RestObservable
import com.blazma.kiosk.ui.BaseActivity
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import com.google.gson.JsonArray

import com.google.gson.JsonObject

class ActivityViewModel :ViewModel() {
    var _mResponse: MutableLiveData<RestObservable> = MutableLiveData()
    val mResponse: LiveData<RestObservable> = _mResponse

    var _mResponseCart: MutableLiveData<RestObservable> = MutableLiveData()
    val mResponseCart: LiveData<RestObservable> = _mResponseCart

    var _mResponseViewCart: MutableLiveData<RestObservable> = MutableLiveData()
    val mResponseViewCart: LiveData<RestObservable> = _mResponseViewCart

    var _mResponseRemoveCart: MutableLiveData<RestObservable> = MutableLiveData()
    val mResponseRemoveCart: LiveData<RestObservable> = _mResponseRemoveCart

    var _mResponseGetOrder: MutableLiveData<RestObservable> = MutableLiveData()
    val mResponseGetOrder: LiveData<RestObservable> = _mResponseGetOrder

    var _mResponseSetOrder: MutableLiveData<RestObservable> = MutableLiveData()
    val mResponseSetOrder: LiveData<RestObservable> = _mResponseSetOrder


    var _mResponseAddOrder: MutableLiveData<RestObservable> = MutableLiveData()
    val mResponseAddOrder: LiveData<RestObservable> = _mResponseAddOrder

    @SuppressLint("CheckResult")
    fun getProviderDetail(
        activity: Activity,
        showLoader: Boolean,
        search: String?,
        categoryId: String?
    ) {
        RetrofitClient.getApiService().getProviderDetails(search, categoryId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { _mResponse.value = RestObservable.loading(activity, showLoader) }
            .subscribe(
                { _mResponse.value = RestObservable.success(it) },
                { _mResponse.value = RestObservable.error(activity, it) }
            )
    }

    @SuppressLint("CheckResult")
    fun addCart(activity: Activity, showLoader: Boolean, userId: String, token: String, map: HashMap<String, String>) {
        RetrofitClient.getApiService().addCart(userId, token, map)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { _mResponseCart.value = RestObservable.loading(activity, showLoader) }
            .subscribe(
                { _mResponseCart.value = RestObservable.success(it) },
                { _mResponseCart.value = RestObservable.error(activity, it) }
            )
    }

    @SuppressLint("CheckResult")
    fun viewCart(activity: Activity, showLoader: Boolean, userId: String, token: String) {
        RetrofitClient.getApiService().viewCart(userId, token)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { _mResponseViewCart.value = RestObservable.loading(activity, showLoader) }
            .subscribe(
                { _mResponseViewCart.value = RestObservable.success(it) },
                { _mResponseViewCart.value = RestObservable.error(activity, it) }
            )
    }

    @SuppressLint("CheckResult")
    fun removeCart(activity: Activity, showLoader: Boolean, userId: String, token: String, cartId: String) {
        RetrofitClient.getApiService().removeCart(userId, token, cartId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { _mResponseRemoveCart.value = RestObservable.loading(activity, showLoader) }
            .subscribe(
                { _mResponseRemoveCart.value = RestObservable.success(it) },
                { _mResponseRemoveCart.value = RestObservable.error(activity, it) }
            )
    }

    @SuppressLint("CheckResult")
    fun getOrder(activity: Activity, showLoader: Boolean, orderId: String) {
        RetrofitClient.getApiService().getOrder("4", "ce3a252deb3deaebb2ace5de1", orderId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { _mResponseGetOrder.value = RestObservable.loading(activity, showLoader) }
            .subscribe(
                { _mResponseGetOrder.value = RestObservable.success(it) },
                { _mResponseGetOrder.value = RestObservable.error(activity, it) }
            )
    }

    @SuppressLint("CheckResult")
    fun setOrderPaid(activity: Activity, showLoader: Boolean, orderId: String) {
        RetrofitClient.getApiService().setOrderPaid("4", "ce3a252deb3deaebb2ace5de1", orderId)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { _mResponseSetOrder.value = RestObservable.loading(activity, showLoader) }
            .subscribe(
                { _mResponseSetOrder.value = RestObservable.success(it) },
                { _mResponseSetOrder.value = RestObservable.error(activity, it) }
            )
    }

    @SuppressLint("CheckResult")
    fun addOrder(activity: Activity, showLoader: Boolean, userId: String, token: String, map: HashMap<String, String>) {
        RetrofitClient.getApiService().addOrder(userId, token, map)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { _mResponseAddOrder.value = RestObservable.loading(activity, showLoader) }
            .subscribe(
                { _mResponseAddOrder.value = RestObservable.success(it) },
                { _mResponseAddOrder.value = RestObservable.error(activity, it) }
            )
    }
}