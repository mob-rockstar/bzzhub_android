package com.blazma.kiosk.ui.main

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.GridLayoutManager
import com.blazma.kiosk.databinding.ActivityMobileNumberBinding
import com.blazma.kiosk.restapi.model.Status
import com.blazma.kiosk.ui.BaseActivity
import com.blazma.kiosk.ui.main.adapter.NumberPadAdapter
import com.blazma.kiosk.ui.main.model.MessageEventModel
import com.blazma.kiosk.util.*
import com.blazma.kiosk.viewmodel.MobileNumberViewModel
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.reflect.TypeToken
import org.greenrobot.eventbus.EventBus

class MobileNumberActivity: BaseActivity() {

    private lateinit var binding: ActivityMobileNumberBinding
    private lateinit var numberPadAdapter: NumberPadAdapter
    private val viewModel: MobileNumberViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMobileNumberBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        initView()
    }

    private fun initView() {
        binding.header.spnLanguage.adapter = langAdapter
        binding.header.spnLanguage.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            var count = 0
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if(count > 0){
                    changeLocalLanguage(position)
                }
                count++
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {

            }
        }
        if(LocaleHelper.getLanguage(this) == "en"){
            binding.header.spnLanguage.setSelection(0)
        }else{
            binding.header.spnLanguage.setSelection(1)
        }

        binding.imgBack.setOnClickListener(object : DebouncedOnClickListener(){
            override fun onDebouncedClick(v: View?) {
                finish()
            }
        })

        binding.btSendCode.setOnClickListener(object : DebouncedOnClickListener(){
            override fun onDebouncedClick(v: View?) {
                sign()
            }
        })

        numberPadAdapter = NumberPadAdapter(object : NumberPadAdapter.OnClickListener{
            override fun onClick(item: String?) {
                if(item == "b"){
                    val str = binding.etMobileNumber.text.toString()
                    if(str.length > 0){
                        val result = str.substring(0, str.length - 1)
                        binding.etMobileNumber.setText(result)
                    }
                }else if(item == "d"){
                    sign()
                }else{
                    binding.etMobileNumber.setText(binding.etMobileNumber.text.toString() + item)
                }
            }

        }, this)
        val list = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "b", "0", "d")
        numberPadAdapter.setData(list)
        val layoutManager = GridLayoutManager(this, 3)
        binding.rvNumber.adapter = numberPadAdapter
        binding.rvNumber.layoutManager = layoutManager

        subscribeUI()
    }

    private fun sign(){
        val map = HashMap<String, String>()
        map.put("mobile_no", binding.etMobileNumber.text.toString())
        map.put("country_code", "+962")
        viewModel.signInUsingMobileNo(this, true, map)
    }

    private fun subscribeUI(){
        viewModel.mResponse.observe(this, Observer { result ->
            when (result.status) {
                Status.SUCCESS -> {
                    val jsonObject = result.data as JsonObject
                    if (jsonObject.get("success").asBoolean) {
                        val intent = Intent(this@MobileNumberActivity, VerificationCodeActivity::class.java)
                        intent.putExtra("no", binding.etMobileNumber.text.toString())
                        startActivity(intent)
                    }else{
                        showAlerterError(jsonObject.get("errorMessage")?.asString)
                    }
                }
                Status.ERROR -> {
                    if (result.data != null) {
                        showAlerterError(result.data as String)
                    } else {
                        showAlerterError(result.error!!.toString())
                    }
                }
                Status.LOADING -> {

                }
            }
        })
    }
}