package com.blazma.kiosk.ui.main.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import androidx.recyclerview.widget.RecyclerView
import com.blazma.kiosk.R
import com.blazma.kiosk.databinding.RowCartBinding
import com.blazma.kiosk.databinding.RowHomeBinding
import com.blazma.kiosk.model.Cart
import com.blazma.kiosk.model.Package
import com.blazma.kiosk.util.DebouncedOnClickListener
import com.blazma.kiosk.util.LocaleHelper
import com.blazma.kiosk.util.PrefUtils

class CartAdapter(onClickListener: OnClickListener, context: Context?) : RecyclerView.Adapter<CartAdapter.ViewHolder>() {

    private var items: List<Package>? = null
    private val onClickListener = onClickListener
    private val context: Context? = context

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = RowCartBinding
            .inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int = items?.size?: 0

    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(items?.get(position), position)

    @SuppressLint("NotifyDataSetChanged")
    fun setData(pck: List<Package>?){
        items = pck
        notifyDataSetChanged()
    }

    inner class ViewHolder(val binding: RowCartBinding) : RecyclerView.ViewHolder(binding.root) {
        @SuppressLint("NotifyDataSetChanged", "StringFormatMatches")
        fun bind(item: Package?, position: Int) {
            binding.imgClose.setOnClickListener(object : DebouncedOnClickListener() {
                override fun onDebouncedClick(v: View?) {
                    if(item != null && item.members != null && item.members.size > 0){
                        onClickListener.onRemoveFromCart(item.members[0].CART_ID)
                    }
                }
            })

            binding.tvPrice.text = item?.PRICE
            if(item?.HOURS == null){
                binding.llTime.visibility = View.GONE
            }else{
                binding.llTime.visibility = View.VISIBLE
                if (context != null) {
                    binding.tvHours.text = context.getString(R.string.within_hours, item?.HOURS)
                }
            }

            if(context?.let { LocaleHelper.getLanguage(it) } == "en"){
                binding.tvName.text = item?.NAME_EN
            }else{
                binding.tvName.text = item?.NAME_AR
            }
        }
    }

    interface OnClickListener{
        fun onRemoveFromCart(cartId: String)
    }
}
