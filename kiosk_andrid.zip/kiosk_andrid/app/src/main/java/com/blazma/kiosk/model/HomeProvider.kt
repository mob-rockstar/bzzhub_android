package com.blazma.kiosk.model

data class HomeProvider(
    val filters : Filter,
    val categories : List<Category>,
    val providerDetails: ProviderDetail,
    val LAB_CATEGORY_TYPE_ID : Int,
)