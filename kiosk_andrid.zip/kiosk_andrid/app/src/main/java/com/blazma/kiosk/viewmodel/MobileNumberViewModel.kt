package com.blazma.kiosk.viewmodel

import android.annotation.SuppressLint
import android.app.Activity
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.blazma.kiosk.restapi.RetrofitClient
import com.blazma.kiosk.restapi.model.RestObservable
import com.blazma.kiosk.ui.BaseActivity
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class MobileNumberViewModel :ViewModel() {

    var _mResponse: MutableLiveData<RestObservable> = MutableLiveData()
    val mResponse: LiveData<RestObservable> = _mResponse

    @SuppressLint("CheckResult")
    fun signInUsingMobileNo(activity: Activity, showLoader:Boolean, map: HashMap<String, String>) {
        RetrofitClient.getApiService().signInUsingMobileNo(map)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { _mResponse.value = RestObservable.loading(activity, showLoader) }
            .subscribe(
                { _mResponse.value = RestObservable.success(it) },
                { _mResponse.value = RestObservable.error(activity, it) }
            )
    }
}