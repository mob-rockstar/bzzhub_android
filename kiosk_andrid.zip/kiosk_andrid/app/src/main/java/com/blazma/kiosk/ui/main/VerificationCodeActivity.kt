package com.blazma.kiosk.ui.main

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.GridLayoutManager
import com.blazma.kiosk.R
import com.blazma.kiosk.databinding.ActivityVerificationCodeBinding
import com.blazma.kiosk.model.User
import com.blazma.kiosk.restapi.model.Status
import com.blazma.kiosk.ui.BaseActivity
import com.blazma.kiosk.ui.main.adapter.NumberPadAdapter
import com.blazma.kiosk.util.DebouncedOnClickListener
import com.blazma.kiosk.util.LocaleHelper
import com.blazma.kiosk.util.PrefUtils
import com.blazma.kiosk.util.showAlerterError
import com.blazma.kiosk.viewmodel.VerifyCodeViewModel
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.reflect.TypeToken

class VerificationCodeActivity: BaseActivity() {

    private lateinit var binding: ActivityVerificationCodeBinding
    private lateinit var numberPadAdapter: NumberPadAdapter
    private val viewModel: VerifyCodeViewModel by viewModels()
    private var mobileNo = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVerificationCodeBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        initView()
    }


    private fun initView() {
        binding.header.spnLanguage.adapter = langAdapter
        binding.header.spnLanguage.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            var count = 0
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if(count > 0){
                    changeLocalLanguage(position)
                }
                count++
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {

            }
        }
        if(LocaleHelper.getLanguage(this) == "en"){
            binding.header.spnLanguage.setSelection(0)
        }else{
            binding.header.spnLanguage.setSelection(1)
        }

        if(intent != null){
            mobileNo = intent.getStringExtra("no").toString()
            binding.tvVerificationCode.text = getString(R.string.enter_verification_code,  "966"+mobileNo)
        }
        binding.imgBack.setOnClickListener(object : DebouncedOnClickListener(){
            override fun onDebouncedClick(v: View?) {
                finish()
            }
        })

        numberPadAdapter = NumberPadAdapter(object : NumberPadAdapter.OnClickListener{
            override fun onClick(item: String?) {
                if(item == "b"){
                    val str = binding.pinview.text.toString()
                    val result = str.substring(0, str.length - 1)
                    binding.pinview.setText(result)
                }else if(item == "d"){
                    if(binding.pinview.text.toString().length == 5){
                        verifyCode()
                    }
                }else{
                    binding.pinview.setText(binding.pinview.text.toString() + item)
                }
            }

        }, this)
        val list = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "b", "0", "d")
        numberPadAdapter.setData(list)
        val layoutManager = GridLayoutManager(this, 3)
        binding.rvNumber.adapter = numberPadAdapter
        binding.rvNumber.layoutManager = layoutManager

        binding.btContinue.setOnClickListener(object : DebouncedOnClickListener(){
            override fun onDebouncedClick(v: View?) {
                if(binding.pinview.text.toString().length == 5){
                    verifyCode()
                }
            }
        })

        subscribeUI()
    }

    private fun verifyCode(){
        val map = HashMap<String, String>()
        map.put("mobile_no", mobileNo)
        map.put("country_code", "+962")
        map.put("verification_code", binding.pinview.text.toString())
        viewModel.verifyMobileNo(this, true, map)
    }

    private fun subscribeUI(){
        viewModel.mResponse.observe(this, Observer { result ->
            when (result.status) {
                Status.SUCCESS -> {
                    val jsonObject = result.data as JsonObject
                    if (jsonObject.get("success").asBoolean) {
                        val gson = Gson()
                        val type = object : TypeToken<User>() {}.type
                        val resObj = jsonObject.get("response").asJsonObject
                        var userSignType = -1
                        if(resObj.get("userSignType") == null){
                            if(resObj.get("UserSignType") == null){

                            }else{
                                userSignType = resObj.get("UserSignType").asInt
                            }
                        }else{
                            userSignType = resObj.get("userSignType").asInt
                        }
                        if(userSignType == 1){
                            //already registered
                            val userObj = gson.fromJson<User>(resObj.get("user").asJsonObject, type)
                            PrefUtils.with(this@VerificationCodeActivity).saveUser(userObj)
                            var intent = Intent(this@VerificationCodeActivity, MainActivity::class.java)
                            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                            startActivity(intent)
                        }else {// if(userSignType == 0){
                            val intent = Intent(this@VerificationCodeActivity, RegisterActivity::class.java)
                            intent.putExtra("no", mobileNo)
                            startActivity(intent)
                        }
                    }else{
                        showAlerterError(jsonObject.get("errorMessage")?.asString)
                    }
                }
                Status.ERROR -> {
                    if (result.data != null) {
                        showAlerterError(result.data as String)
                    } else {
                        showAlerterError(result.error!!.toString())
                    }
                }
                Status.LOADING -> {

                }
            }
        })
    }
}