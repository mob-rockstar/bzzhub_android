package com.blazma.kiosk.model

data class Member(
    val FULL_NAME : String,
    val CART_ID :  String,
    val NATIONALITY_ID: String,
    val DATE_OF_BIRTH :  String,
    val GENDER_ID :  String,
    val MOBILE_NUMBER :  String,
)