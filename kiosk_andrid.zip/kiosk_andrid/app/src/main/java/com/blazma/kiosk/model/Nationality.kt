package com.blazma.kiosk.model

data class Nationality(
    val id : String,
    val icon: String,
    val name : String,
    val ar_name : String,
    val code : String,
    val dial_code : String,
    val iso_2 : String,
    val priority : String?,
    val HESN_PLUS_NATIONALITY_ID : String,
)