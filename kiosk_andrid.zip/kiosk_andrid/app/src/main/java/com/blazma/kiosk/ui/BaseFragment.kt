package com.blazma.kiosk.ui

import android.annotation.SuppressLint
import android.content.Context
import androidx.fragment.app.Fragment
import android.view.ViewGroup

import android.view.View

import android.view.View.OnTouchListener

import android.widget.EditText
import com.blazma.kiosk.util.hideSoftKeyboard


open class BaseFragment() : Fragment() {
    protected lateinit var mActivity: BaseActivity

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is BaseActivity) {
            mActivity = context
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    open fun setupUI(view: View) {
        // Set up touch listener for non-text box views to hide keyboard.
        if (view !is EditText) {
            view.setOnTouchListener(OnTouchListener { v, event ->
                mActivity.hideSoftKeyboard()
                false
            })
        }
//        else{
//            view.setOnFocusChangeListener(object : View.OnFocusChangeListener{
//                override fun onFocusChange(view: View?, hasFocus: Boolean) {
//                    if(hasFocus){
//                        (view as EditText).setBackgroundResource(R.drawable.round_bk_border_active)
//                    }else{
//                        (view as EditText).setBackgroundResource(R.drawable.round_bk_border_inactive)
//                    }
//                }
//            })
//        }
        //If a layout container, iterate over children and seed recursion.
        if (view is ViewGroup) {
            for (i in 0 until (view as ViewGroup).childCount) {
                val innerView: View = (view as ViewGroup).getChildAt(i)
                setupUI(innerView)
            }
        }
    }
}