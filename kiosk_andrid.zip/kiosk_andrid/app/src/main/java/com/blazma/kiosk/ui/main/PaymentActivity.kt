//package com.blazma.kiosk.ui.main
//
//import android.Manifest
//import android.app.Activity
//import android.content.BroadcastReceiver
//import android.content.Context
//import android.content.Intent
//import android.content.IntentFilter
//import android.content.pm.PackageManager
//import android.hardware.usb.UsbManager
//import android.opengl.Visibility
//import androidx.appcompat.app.AppCompatActivity
//import android.os.Bundle
//import android.os.Handler
//import android.util.Log
//import android.view.View
//import android.widget.*
//import androidx.appcompat.app.AlertDialog
//import androidx.core.app.ActivityCompat
//import androidx.core.content.ContextCompat
//import com.blazma.kiosk.R
//import com.hoho.android.usbserial.util.SerialInputOutputManager
//import com.universal.alhamrani.ecrusbintegration.AlhamraniLibrary
//import com.universal.alhamrani.ecrusbintegration.Response
//
//import java.lang.Exception
//import java.util.concurrent.Executors
//
//lateinit var filter: IntentFilter
//private val ACTION_USB_PERMISSION = "com.android.example.USB_PERMISSION"
//lateinit var spinnerTransaction: Spinner
//var transaction_type: String = "PUR"
//
//lateinit var sendButton: Button
//lateinit var tvDeviceName: TextView
//lateinit var etAmount: EditText
//lateinit var etEcr_no: EditText
//lateinit var etEcr_Receipt: EditText
//lateinit var etRRN: EditText
//lateinit var etPan: EditText
//lateinit var processalertDialog : AlertDialog
//lateinit var amount_wrapper : LinearLayout
//lateinit var  ecr_no_wrapper : LinearLayout
//lateinit var  ecr_receipt_wrapper : LinearLayout
//lateinit var  rrn_wrapper : LinearLayout
//lateinit var  card_no_wrapper : LinearLayout
//// Storage Permissions
//private val REQUEST_EXTERNAL_STORAGE = 1
//private val PERMISSIONS_STORAGE = arrayOf(
//    Manifest.permission.READ_EXTERNAL_STORAGE,
//    Manifest.permission.WRITE_EXTERNAL_STORAGE
//)
//
//var alhamraniLibrary = AlhamraniLibrary()
//class PaymentActivity : AppCompatActivity(), SerialInputOutputManager.Listener {
//
//    private var totalPrice: String?= null
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_payment)
//
//        spinnerTransaction = findViewById(R.id.transactionspinner) as Spinner
////        tvDeviceName = findViewById(R.id.usbdevice) as TextView
//        sendButton = findViewById(R.id.sendbutton) as Button
//        etAmount = findViewById(R.id.amount) as EditText
//        etEcr_Receipt = findViewById(R.id.ecr_receipt) as EditText
//        etEcr_no = findViewById(R.id.ecr_no) as EditText
//        etRRN = findViewById(R.id.rrn) as EditText
//        etPan = findViewById(R.id.pan) as EditText
//
//        amount_wrapper = findViewById(R.id.amountwrapper) as LinearLayout
//        ecr_no_wrapper = findViewById(R.id.ecr_no_wrapper) as LinearLayout
//        ecr_receipt_wrapper = findViewById(R.id.ecr_receipt_no_wrapper) as LinearLayout
//        rrn_wrapper = findViewById(R.id.rrn_wrapper) as LinearLayout
//        card_no_wrapper = findViewById(R.id.card_no_wrapper) as LinearLayout
//
//
//        if(intent != null){
//            totalPrice = intent.getStringExtra("total_price")
//            etAmount.setText(totalPrice)
//        }
//
//        populateSpinner()
//
//        //1ST STEP
//        alhamraniLibrary.requestPermission(this)
//        //2nd STEP
//        var is_success = alhamraniLibrary.initializeAU()
//
//        if(is_success) {
//            //3RD STEP add listener
//            initListener()
//        }
////
////        sendButton.text = getString(R.string.button_no_connection)
////        tvDeviceName.text = getString(R.string.no_connection)
//
//        // Set an on item selected listener for spinner object
//        spinnerTransaction.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
//            override fun onItemSelected(
//                parent: AdapterView<*>,
//                view: View,
//                position: Int,
//                id: Long
//            ) {
//                // Display the selected item text on text view
//                when (position) {
//                    0 -> {
//                        transaction_type = "PUR"
//                        etRRN.isEnabled = false
//                        etPan.isEnabled = false
//                        amount_wrapper.visibility = View.VISIBLE
//                        ecr_no_wrapper.visibility = View.VISIBLE
//                        ecr_receipt_wrapper.visibility = View.VISIBLE
//                        rrn_wrapper.visibility = View.INVISIBLE
//                        card_no_wrapper.visibility = View.INVISIBLE
//                    }
//                    1 -> {
//                        transaction_type = "REF"
//                        etRRN.isEnabled = true
//                        etPan.isEnabled = true
//                        amount_wrapper.visibility = View.VISIBLE
//                        ecr_no_wrapper.visibility = View.VISIBLE
//                        ecr_receipt_wrapper.visibility = View.VISIBLE
//                        rrn_wrapper.visibility = View.VISIBLE
//                        card_no_wrapper.visibility = View.VISIBLE
//                    }
//                }
//
//            }
//
//            override fun onNothingSelected(parent: AdapterView<*>) {
//                // Another interface callback
//            }
//        }
//
//        sendButton.setOnClickListener {
//
//            disableButton()
//            showloader()
//            sendButton.isEnabled = false
//            sendButton.text = getString(R.string.sending)
//
//            alhamraniLibrary.sendTransaction(transaction_type,etEcr_no.text.toString(),
//                etEcr_Receipt.text.toString(), etAmount.text.toString(),"", etRRN.text.toString(),
//                etPan.text.toString(),"","")
//
//            Handler().postDelayed({
//                enableButton()
//                processalertDialog.dismiss()
//            }, 60000)
//
//        }
//    }
//
//
//    //3RD STEP
//    fun initListener(){
//        var port = alhamraniLibrary.getInitializedPort()
//        var usbIoManager = SerialInputOutputManager(port,this )
//        Executors.newSingleThreadExecutor().submit(usbIoManager)
//        enableButton()
//    }
//
//    fun populateSpinner() {
//        // Initializing an ArrayAdapter
//        val adapter = ArrayAdapter(
//            this, // Context
//            android.R.layout.simple_spinner_item,// Layout
//            resources.getStringArray(R.array.transaction_type)
//        )
//        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line)
//        spinnerTransaction.adapter = adapter
//    }
//
//    fun enableButton() {
//        sendButton.isEnabled = true
//        sendButton.text = getString(com.universal.alhamrani.ecrusbintegration.R.string.normal_state_send)
//    }
//
//    fun disableButton() {
//        sendButton.isEnabled = false
//        sendButton.text = getString(com.universal.alhamrani.ecrusbintegration.R.string.button_no_connection)
//        // tvDeviceName.text = getString(com.universal.alhamrani.ecrusbintegration.R.string.no_connection)
//    }
//
//    override fun onNewData(data: ByteArray?) {
//        if(data != null){
//            var response = alhamraniLibrary.parseResponse(data!!)
//            // make sure  size is greater than 6 for proper response to be shown
//            if(data!!.size > 6) {
//                runOnUiThread({
//                    enableButton()
//                    updateUIForResponse(response)
//                })
//            }
//        }
//    }
//
//    override fun onRunError(e: Exception?) {
//        enableButton()
//        Log.v("ERROR","")
//    }
//
//    fun showloader(){
//        val dialogBuilder = AlertDialog.Builder(this)
//        dialogBuilder.setCancelable(false)
//        val inflater = this.layoutInflater
//        val dialogView = inflater.inflate(R.layout.processing_layout, null)
//        dialogBuilder.setView(dialogView)
//        processalertDialog = dialogBuilder.create()
//
//        processalertDialog.show()
//
//    }
//
//    fun updateUIForResponse(result: Response) {
//        processalertDialog.dismiss()
//        val dialogBuilder = AlertDialog.Builder(this)
//        dialogBuilder.setCancelable(false)
//        val inflater = this.layoutInflater
//        val dialogView = inflater.inflate(R.layout.response_layout, null)
//        dialogBuilder.setView(dialogView)
//
//        val imgResponse = dialogView.findViewById(R.id.image_response) as ImageView
//        val tvActionStatus = dialogView.findViewById(R.id.action_status) as TextView
//        val tvecr_number = dialogView.findViewById(R.id.ecr_no) as TextView
//        val tvecr_receipt_number = dialogView.findViewById(R.id.ecrreceipt_no) as TextView
//        val tvamount = dialogView.findViewById(R.id.amount) as TextView
//        val tvresponse_code = dialogView.findViewById(R.id.response_code) as TextView
//        val tvauth_code = dialogView.findViewById(R.id.authcode) as TextView
//        val tvcard_number = dialogView.findViewById(R.id.card_number) as TextView
//        val tvcardtype = dialogView.findViewById(R.id.card_type) as TextView
//        val tvexpiry = dialogView.findViewById(R.id.card_expiry) as TextView
//        val tvtransdate_and_time =
//            dialogView.findViewById(R.id.transaction_date_and_time) as TextView
//        val tvrrn = dialogView.findViewById(R.id.rrn) as TextView
//        val tvtid = dialogView.findViewById(R.id.tid) as TextView
//        val closeButton = dialogView.findViewById(R.id.close) as Button
//
//
//        if (result.response_code == "000" ||
//            result.response_code  == "001" ||
//            result.response_code  == "003" ||
//            result.response_code  == "007" ||
//            result.response_code  == "087" ||
//            result.response_code  == "089" ||
//            result.response_code  == "300" ||
//            result.response_code  == "400" ||
//            result.response_code  == "500" ||
//            result.response_code  == "800"
//        ) { // APPROVED
//
//            imgResponse.background = getDrawable(R.drawable.check)
//            tvActionStatus.text = "APPROVE"
//        } else { // DECLINE
//            imgResponse.background = getDrawable(R.drawable.wrong)
//            tvActionStatus.text = "DECLINE"
//        }
//
//        tvecr_number.text = "ECR NUMBER : " + result.ecr_number
//        tvecr_receipt_number.text = "ECR RECEIPT : " + result.ecr_receipt_number
//        tvamount.text = "AMOUNT :" + result.amount
//        tvresponse_code.text = "RESPONSE CODE : " + result.response_code
//        tvcard_number.text = "CARD NUMBER : " + result.card_number
//        tvexpiry.text = "CARD EXPIRY : " + result.card_expiry
//        tvcardtype.text = "CARD TYPE : " + result.card_type
//        tvtransdate_and_time.text = "TRANSACTION DATE & TIME : ${result.trans_date + ' ' + result.trans_time}"
//        tvrrn.text = "RRN : " + result.rrn
//        tvtid.text = "TID : " + result.tid
//        tvauth_code.text = "AUTH CODE :" + result.auth_code
//
//
//        val alertDialog = dialogBuilder.create()
//
//        closeButton.setOnClickListener {
//            alertDialog.dismiss()
//        }
//
//        alertDialog.show()
//
//    }
//}