package com.blazma.kiosk.ui.main

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.blazma.kiosk.R
import com.blazma.kiosk.databinding.SheetCartBinding
import com.blazma.kiosk.model.Cart
import com.blazma.kiosk.model.Package
import com.blazma.kiosk.restapi.model.Status
import com.blazma.kiosk.ui.main.adapter.CartAdapter
import com.blazma.kiosk.ui.main.model.MessageEventModel
import com.blazma.kiosk.util.Constants
import com.blazma.kiosk.util.DebouncedOnClickListener
import com.blazma.kiosk.util.PrefUtils
import com.blazma.kiosk.util.showAlerterError
import com.blazma.kiosk.viewmodel.ActivityViewModel
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.reflect.TypeToken
import org.greenrobot.eventbus.EventBus
import org.json.JSONObject

class CartSheetFragment(activity: MainActivity): BottomSheetDialogFragment() {

    private lateinit var binding: SheetCartBinding
    private lateinit var cartAdapter: CartAdapter
    private val viewModel: ActivityViewModel by activityViewModels()
    private var packageList: ArrayList<Package> = ArrayList()
    private var cart: Cart? = null
    private var activity = activity
    private var isRemove = false

    companion object {
        fun newInstance(activity: MainActivity): CartSheetFragment {
            val fragment = CartSheetFragment(activity)
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = SheetCartBinding.inflate(layoutInflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initView()
    }

    @SuppressLint("RestrictedApi")
    override fun setupDialog(dialog: Dialog, style: Int) {
        super.setupDialog(dialog, style)
        val rootView = View.inflate(context, R.layout.sheet_cart, null)
        dialog.setContentView(rootView)

        val bottomSheet = dialog.window?.findViewById(com.google.android.material.R.id.design_bottom_sheet) as FrameLayout
        val behaviour = BottomSheetBehavior.from(bottomSheet)

        behaviour.state = BottomSheetBehavior.STATE_EXPANDED
    }

    private fun hide(){
       dismiss()
    }

    private fun initView() {
        binding.imgBack.setOnClickListener{
            hide()
        }
        cartAdapter = CartAdapter(object : CartAdapter.OnClickListener {
            override fun onRemoveFromCart(cartId: String) {
                removeCart(cartId)
            }

        }, context)
        binding.rvCart.adapter = cartAdapter

        binding.btCheckout.setOnClickListener(object : DebouncedOnClickListener(){
            override fun onDebouncedClick(v: View?) {
                hide()
                startActivity(Intent(activity, MyOrderActivity::class.java))
            }

        })
        subscribeUI()
        viewModel.viewCart(activity, true, PrefUtils.with(activity).getUser()!!.ID, PrefUtils.with(activity).getUser()!!.ACCESS_TOKEN)
    }


    ///////////////////////////////////////////////////////////////////
    ////////////////////// API ////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////
    private fun removeCart(cartId: String){
        isRemove = true
        viewModel.removeCart(activity, true,PrefUtils.with(activity).getUser()!!.ID,
            PrefUtils.with(activity).getUser()!!.ACCESS_TOKEN, cartId)
    }

    private fun showPrice(){
        if(cart != null){
            binding.tvCount.text = "x" + cart!!.packages_count
            binding.tvTotal.text = cart!!.net_total
            binding.tvTax.text = cart!!.tax_amount
            binding.tvSubTotal.text = cart!!.packages_amount
        }
    }

    private fun filterPackage(list: List<Package>){
        packageList.clear()
        for(pack in list){
            if(pack.members != null){
                for(member in pack.members){
                    var tempPackage = com.blazma.kiosk.model.Package(pack.ID, pack.NAME_EN, pack.NAME_AR, pack.PRICE, pack.HOURS,
                        pack.SMART_DESC_EN, pack.SMART_DESC_AR, pack.OLD_PRICE, pack.IS_OFFER, pack.SHOW_SUMMARY, pack.DESC_EN, pack.DESC_AR,
                        pack.MOBILE_IMAGE_URL_EN, pack.MOBILE_IMAGE_URL_AR, listOf(member))
                    packageList.add(tempPackage)
                }
            }
        }
        cartAdapter.setData(packageList)
    }

    private fun subscribeUI(){
        viewModel.mResponseViewCart.observe(viewLifecycleOwner, Observer { result ->
            when (result.status) {
                Status.SUCCESS -> {
                    val jsonObject = result.data as JsonObject
                    if (jsonObject.get("success").asBoolean) {
                        try{
                            val gson = Gson()
                            val type = object : TypeToken<Cart>() {}.type
                            cart = gson.fromJson<Cart>(jsonObject.get("response").asJsonObject.get("cart").asJsonObject, type)
                            if(cart?.packages?.isNotEmpty() == true){
                                filterPackage(cart?.packages!!)
                                showPrice()
                                binding.btCheckout.visibility = View.VISIBLE
                            }else{
                                binding.btCheckout.visibility = View.GONE
                            }
                        }catch (e: Exception){

                        }

                    }else{
//                        showAlerterError(jsonObject.get("errorMessage")?.asString)
                    }
                }
//                Status.ERROR -> {
//                    if (result.data != null) {
//                        showAlerterError(result.data as String)
//                    } else {
//                        showAlerterError(result.error!!.toString())
//                    }
//                }
//                Status.LOADING -> {
//
//                }
            }
        })

        viewModel.mResponseRemoveCart.observe(viewLifecycleOwner, Observer { result ->
            when (result.status) {
                Status.SUCCESS -> {
                    val jsonObject = result.data as JsonObject
                    if (jsonObject.get("success").asBoolean) {
                        try{
                            val gson = Gson()
                            val type = object : TypeToken<Cart>() {}.type
                            var obj = jsonObject.get("response").asJsonObject.get("cart")
                            if(!obj.isJsonNull){
                                val cartObj = gson.fromJson<Cart>(obj.asJsonObject, type)
                                cartObj.packages = cartObj.packages.filter { it -> it.ID != cartObj.packages[0].ID }
                                cartAdapter.setData(cartObj.packages)
                                showPrice()
                                EventBus.getDefault().post(MessageEventModel(Constants.CART_RELOAD))
                            }else{
                                if(isRemove){
                                    EventBus.getDefault().post(MessageEventModel(Constants.CART_RELOAD))
                                    hide()
                                }
                            }
                            isRemove = false
                        }catch (ex: Exception){

                        }
                    }else{
                        activity.showAlerterError(jsonObject.get("errorMessage")?.asString)
                    }
                }
                Status.ERROR -> {
                    if (result.data != null) {
                        activity.showAlerterError(result.data as String)
                    } else {
                        activity.showAlerterError(result.error!!.toString())
                    }
                }
                Status.LOADING -> {

                }
            }
        })
    }
}