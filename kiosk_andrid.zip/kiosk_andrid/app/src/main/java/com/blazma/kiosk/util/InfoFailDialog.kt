package com.blazma.kiosk.util

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.*
import com.blazma.kiosk.R
import com.blazma.kiosk.databinding.DialogFailInfoBinding
import java.util.*

class InfoFailDialog(context: Context, theme: Int) : Dialog(context, theme) {

    interface OnClickListener{
        fun onTry()
        fun onStartOver()
    }

    companion object {
        fun create(context: Context, onClickListener: OnClickListener): InfoFailDialog {
            val dialog = InfoFailDialog(context, R.style.DialogTheme)

            val binding = DialogFailInfoBinding.inflate(LayoutInflater.from(context))
            val view = binding.root
            dialog.setContentView(view)

            binding.btTryAgain.setOnClickListener{
                onClickListener.onTry()
            }

            binding.btStartOver.setOnClickListener{
                onClickListener.onStartOver()
            }

            dialog.setCancelable(false)
            Objects.requireNonNull<Window>(dialog.getWindow()).setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.show()

            return dialog
        }
    }
}