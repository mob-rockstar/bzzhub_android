package com.blazma.kiosk.util

import android.app.Activity
import com.tapadoo.alerter.Alerter
import com.blazma.kiosk.R

fun Activity.showAlerterError(msg: String?) {
    try{
        if (msg != null) {
            Alerter.create(this)
//                .setBackgroundColorRes(R.color.colorButton)
                .enableSwipeToDismiss()
                .setText(msg)
                .show()
        }
    }catch (ex : Exception){
        ex.printStackTrace()
    }
}

fun Activity.showAlerterSuccess(msg: String?) {
    try{
        if (msg != null) {
            Alerter.create(this)
                .setBackgroundColorRes(R.color.colorPrimary)
                .enableSwipeToDismiss()
                .setText(msg)
                .show()
        }
    }catch (ex : Exception){
        ex.printStackTrace()
    }
}