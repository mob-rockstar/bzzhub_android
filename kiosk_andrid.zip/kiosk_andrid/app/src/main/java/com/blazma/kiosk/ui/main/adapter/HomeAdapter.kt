package com.blazma.kiosk.ui.main.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.text.Html
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import androidx.recyclerview.widget.RecyclerView
import com.blazma.kiosk.R
import com.blazma.kiosk.databinding.RowHomeBinding
import com.blazma.kiosk.model.Pill
import com.blazma.kiosk.util.DebouncedOnClickListener
import com.blazma.kiosk.util.LocaleHelper
import com.bumptech.glide.Glide

class HomeAdapter(onClickListener: OnClickListener, context: Context?) : RecyclerView.Adapter<HomeAdapter.ViewHolder>() {

    private var items: List<Pill>? = null
    private val onClickListener = onClickListener
    private val context: Context? = context

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = RowHomeBinding
            .inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int = items?.size?: 0

    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(items?.get(position), position)

    @SuppressLint("NotifyDataSetChanged")
    fun setData(data: List<Pill>?){
        items = data
        notifyDataSetChanged()
    }

    inner class ViewHolder(val binding: RowHomeBinding) : RecyclerView.ViewHolder(binding.root) {
        @SuppressLint("NotifyDataSetChanged", "StringFormatMatches")
        fun bind(item: Pill?, position: Int) {
            binding.cvRow.setOnClickListener(object : DebouncedOnClickListener() {
                override fun onDebouncedClick(v: View?) {
                    onClickListener.onClick(item)
                }
            })

            binding.imgAdd.setOnClickListener(object : DebouncedOnClickListener() {
                override fun onDebouncedClick(v: View?) {
                    onClickListener.onAddToCart(item)
                }
            })

            if(context != null){
                binding.tvPrice.text = item?.PRICE
                if(item?.HOURS == null){
                    binding.llTime.visibility = View.GONE
                }else{
                    binding.llTime.visibility = View.VISIBLE
                    binding.tvHours.text = context.getString(R.string.within_hours, item?.HOURS)
                }
                binding.tvHours.text = context.getString(R.string.within_hours, item?.HOURS)
                if(LocaleHelper.getLanguage(context).equals("en")){
                    Glide.with(context).load(item?.MOBILE_IMAGE_URL_EN).into(binding.imgPill)
                    binding.tvName.text = item?.NAME_EN
                    binding.tvDesc.setText(Html.fromHtml(item?.DESC_EN))
                }else{
                    Glide.with(context).load(item?.MOBILE_IMAGE_URL_AR).into(binding.imgPill)
                    binding.tvName.text = item?.NAME_AR
                    binding.tvDesc.setText(Html.fromHtml(item?.DESC_AR))
                }
            }
        }
    }

    interface OnClickListener{
        fun onClick(item: Pill?)
        fun onAddToCart(item: Pill?)
    }
}
