package com.blazma.kiosk.ui.main.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import androidx.recyclerview.widget.RecyclerView
import com.blazma.kiosk.databinding.RowPillKindBinding
import com.blazma.kiosk.model.Category
import com.blazma.kiosk.util.DebouncedOnClickListener
import com.blazma.kiosk.util.LocaleHelper

class PillKindAdapter(onClickListener: OnClickListener, context: Context?) : RecyclerView.Adapter<PillKindAdapter.ViewHolder>() {

    private var items: List<Category>? = null
    private val onClickListener = onClickListener
    private val context: Context? = context
    private var selectedItem: String? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = RowPillKindBinding
            .inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int = items?.size?: 0

    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(items?.get(position), position)

    @SuppressLint("NotifyDataSetChanged")
    fun setData(data: List<Category>, selectedCategory: String?){
        items = data
        if(selectedCategory == null || selectedCategory.isEmpty()){
            if(data.isNotEmpty()){
                selectedItem = data[0].ID
            }
        }else{
            selectedItem = selectedCategory
        }
        notifyDataSetChanged()
    }

    inner class ViewHolder(val binding: RowPillKindBinding) : RecyclerView.ViewHolder(binding.root) {
        @SuppressLint("NotifyDataSetChanged", "StringFormatMatches")
        fun bind(item: Category?, position: Int) {
            if(context?.let { LocaleHelper.getLanguage(it) } == "en"){
                binding.tvName.text = item?.NAME_EN
            }else{
                binding.tvName.text = item?.NAME_AR
            }

            binding.llRow.setOnClickListener(object : DebouncedOnClickListener() {
                override fun onDebouncedClick(v: View?) {
                    onClickListener.onClick(item)
                    selectedItem = item?.ID
                    notifyDataSetChanged()
                }
            })

            if(selectedItem == item?.ID){
                binding.llRow.alpha = 1.0f
            }else{
                binding.llRow.alpha = 0.25f
            }
        }
    }

    interface OnClickListener{
        fun onClick(item: Category?)
    }
}
