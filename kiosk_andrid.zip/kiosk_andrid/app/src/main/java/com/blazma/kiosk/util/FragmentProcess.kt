package com.blazma.kiosk.util

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager

object FragmentProcess {
    fun addFragment(supportFragment: FragmentManager, mFragment: Fragment, container: Int) {
        val transaction = supportFragment.beginTransaction()
        transaction.add(container, mFragment, mFragment.javaClass.simpleName)
        transaction.addToBackStack(mFragment.javaClass.simpleName)
        transaction.commitAllowingStateLoss()
    }
    fun replaceFragment(supportFragment: FragmentManager, fragment: Fragment, layout: Int) {
        val transaction = supportFragment.beginTransaction()
        transaction.replace(layout, fragment, fragment.javaClass.simpleName)
        transaction.addToBackStack(fragment.javaClass.simpleName)
        transaction.commitAllowingStateLoss()
    }

    fun popFragment(supportFragment: FragmentManager) {
        val backStackCount = supportFragment.backStackEntryCount
        if(backStackCount > 0)
            supportFragment.popBackStack()
    }

    fun clearBackStack(supportFragment: FragmentManager) {
        supportFragment.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE)
    }

    fun getCurrentFragment(supportFragment: FragmentManager): Fragment? {
        try {
            val index  = supportFragment.backStackEntryCount - 1
            val backEntry: FragmentManager.BackStackEntry = supportFragment.getBackStackEntryAt(index)
            val tag = backEntry.name
            return supportFragment.findFragmentByTag(tag)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }

    fun getFragmentCount(supportFragment: FragmentManager): Int {
        return supportFragment.backStackEntryCount
    }
}