package com.blazma.kiosk.restapi

import com.google.gson.JsonObject
import io.reactivex.Observable
import retrofit2.http.*

interface RequestInterface {
    @GET("api/v1/nationalities")
    fun getNationalities(): Observable<JsonObject>

    @FormUrlEncoded
    @POST("api/v1/mobile/authentication")
    fun signInUsingMobileNo(@FieldMap map: HashMap<String, String>): Observable<JsonObject>

    @FormUrlEncoded
    @POST("api/v1/mobile/verification")
    fun verifyMobileNo(@FieldMap map: HashMap<String, String>): Observable<JsonObject>

    @FormUrlEncoded
    @POST("api/v1/mobile/registeration")
    fun register(@FieldMap map: HashMap<String, String>): Observable<JsonObject>

    @FormUrlEncoded
    @POST("api/v1/cart")
    fun addCart(@Header("end-user-id") userId: String, @Header("access-token") token: String, @FieldMap map: HashMap<String, String>): Observable<JsonObject>

    @GET("api/v1/cart")
    fun viewCart(@Header("end-user-id") userId: String, @Header("access-token") token: String): Observable<JsonObject>

    @FormUrlEncoded
    @HTTP(method="DELETE", hasBody=true, path="api/v1/cart")
    fun removeCart(@Header("end-user-id") userId: String, @Header("access-token") token: String, @Field("cart_id") cartId: String): Observable<JsonObject>

    @FormUrlEncoded
    @POST("api/v1/profile/{user_id}/member")
    fun addMember(@Header("end-user-id") userId: String, @Header("access-token") token: String,
                  @Path("user_id") user_id: String,
                  @FieldMap map: HashMap<String, String>): Observable<JsonObject>

    @GET("api/v1/orders/{order_id}")
    fun getOrder( @Header("profile-id") profileId: String, @Header("api-key") apiKey: String,
                 @Path("order_id") orderId: String): Observable<JsonObject>

    @FormUrlEncoded
    @POST("api/v1/orders")
    fun addOrder(@Header("end-user-id") userId: String, @Header("access-token") token: String, @FieldMap map: HashMap<String, String>): Observable<JsonObject>









//    @GET("api/v1/providers/40")
//    fun getProviderDetails(@Query("search") search: String?, @Query("category_id") category_id: String?): Observable<JsonObject>
//
//    @POST("api/v1/orders/{order_id}/payment?system-user-id=4848")
//    fun setOrderPaid( @Header("profile-id") profileId: String, @Header("api-key") apiKey: String,
//                      @Path("order_id") orderId: String): Observable<JsonObject>


//    @GET("api/v1/providers/39")
//    fun getProviderDetails(@Query("search") search: String?, @Query("category_id") category_id: String?): Observable<JsonObject>
//
//    @POST("api/v1/orders/{order_id}/payment?system-user-id=4962")
//    fun setOrderPaid( @Header("profile-id") profileId: String, @Header("api-key") apiKey: String,
//                      @Path("order_id") orderId: String): Observable<JsonObject>


//    @GET("api/v1/providers/40")
//    fun getProviderDetails(@Query("search") search: String?, @Query("category_id") category_id: String?): Observable<JsonObject>
//
//    @POST("api/v1/orders/{order_id}/payment?system-user-id=4958")
//    fun setOrderPaid( @Header("profile-id") profileId: String, @Header("api-key") apiKey: String,
//                      @Path("order_id") orderId: String): Observable<JsonObject>
//
//
//    @GET("api/v1/providers/36")
//    fun getProviderDetails(@Query("search") search: String?, @Query("category_id") category_id: String?): Observable<JsonObject>
//
//    @POST("api/v1/orders/{order_id}/payment?system-user-id=4959")
//    fun setOrderPaid( @Header("profile-id") profileId: String, @Header("api-key") apiKey: String,
//                      @Path("order_id") orderId: String): Observable<JsonObject>
//
//
//    @GET("api/v1/providers/36")
//    fun getProviderDetails(@Query("search") search: String?, @Query("category_id") category_id: String?): Observable<JsonObject>
//
//    @POST("api/v1/orders/{order_id}/payment?system-user-id=4960")
//    fun setOrderPaid( @Header("profile-id") profileId: String, @Header("api-key") apiKey: String,
//                      @Path("order_id") orderId: String): Observable<JsonObject>
//
//
//    @GET("api/v1/providers/39")
//    fun getProviderDetails(@Query("search") search: String?, @Query("category_id") category_id: String?): Observable<JsonObject>
//
//    @POST("api/v1/orders/{order_id}/payment?system-user-id=4961")
//    fun setOrderPaid( @Header("profile-id") profileId: String, @Header("api-key") apiKey: String,
//                      @Path("order_id") orderId: String): Observable<JsonObject>

    @GET("api/v1/providers/939")
    fun getProviderDetails(@Query("search") search: String?, @Query("category_id") category_id: String?): Observable<JsonObject>

    @POST("api/v1/orders/{order_id}/payment?system-user-id=5011")
    fun setOrderPaid( @Header("profile-id") profileId: String, @Header("api-key") apiKey: String,
                      @Path("order_id") orderId: String): Observable<JsonObject>
}