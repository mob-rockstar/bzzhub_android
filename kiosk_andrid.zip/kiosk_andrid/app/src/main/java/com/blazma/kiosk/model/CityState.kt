package com.blazma.kiosk.model

data class CityState(
    val STATE_ID : Int,
    val ENG_NAME : String,
    val ARABIC_NAME: String,
    val CITY_ID : Int,
)