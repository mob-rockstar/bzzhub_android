package com.blazma.kiosk.ui.main

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import com.blazma.kiosk.viewmodel.ActivityViewModel
import com.blazma.kiosk.ui.BaseActivity
import com.blazma.kiosk.databinding.ActivityMainBinding
import com.blazma.kiosk.ui.main.adapter.PillKindAdapter
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.GridLayoutManager
import com.blazma.kiosk.model.Category
import com.blazma.kiosk.model.HomeProvider
import com.blazma.kiosk.model.Pill
import com.blazma.kiosk.restapi.model.Status
import com.blazma.kiosk.ui.main.adapter.HomeAdapter
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.reflect.TypeToken
import android.os.Handler
import com.blazma.kiosk.model.Cart
import com.blazma.kiosk.ui.main.model.MessageEventModel
import com.blazma.kiosk.util.*
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.util.HashMap
import com.blazma.kiosk.model.Package
import com.blazma.kiosk.ui.WelcomeActivity
import org.greenrobot.eventbus.EventBus

class MainActivity: BaseActivity() {

    companion object {
        var providerId: String? = null
    }

    private lateinit var binding: ActivityMainBinding
    private val viewModel: ActivityViewModel by viewModels()
    private lateinit var pillKindAdapter: PillKindAdapter
    private lateinit var homeAdapter: HomeAdapter
    private var last_text_edit: Long = 0
    private var delay: Long = 1000
    private var handler = Handler()
    private var allPills: List<Pill>? = null
    private var isFirst = true
    private var packageList: ArrayList<Package> = ArrayList()

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEventModel) {
        if(event.message == Constants.CART_RELOAD){
            viewCart(false)
        }else if(event.message == Constants.UNAUTHORIZED){
            startActivity(Intent(this, MobileNumberActivity::class.java))
        }
    }

    private val input_finish_checker = Runnable {
        if (System.currentTimeMillis() > last_text_edit + delay - 500) {
            viewModel.getProviderDetail(this@MainActivity, true, binding.etSearch.getText().toString(), null)
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        EventBus.getDefault().register(this)
        initView()
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }

    private fun initView() {
        setupUI(binding.parent)
        binding.header.spnLanguage.adapter = langAdapter
        binding.header.spnLanguage.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            var count = 0
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if(count > 0){
                    changeLocalLanguage(position)
                }
                count++
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {

            }
        }
        if(LocaleHelper.getLanguage(this) == "en"){
            binding.header.spnLanguage.setSelection(0)
        }else{
            binding.header.spnLanguage.setSelection(1)
        }

        pillKindAdapter = PillKindAdapter(object : PillKindAdapter.OnClickListener {
            override fun onClick(item: Category?) {
                viewModel.getProviderDetail(this@MainActivity, true, null, item?.ID)
            }

        }, this)

        binding.rvPillKind.adapter = pillKindAdapter
        val layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.rvPillKind.layoutManager = layoutManager

        homeAdapter = HomeAdapter(object : HomeAdapter.OnClickListener {
            override fun onClick(item: Pill?) {
                PillDetailSheetFragment.newInstance(object : PillDetailSheetFragment.OnClickListener{
                    override fun addCart() {
                        if(isLoggedIn()){
                            item?.ID?.let { addCart(it) }
                        }else{
                            startActivity(Intent(this@MainActivity, MobileNumberActivity::class.java))
                        }
                    }

                }, item).show(supportFragmentManager, null)
            }

            override fun onAddToCart(item: Pill?) {
                if(isLoggedIn()){
                    item?.ID?.let { addCart(it) }
                }else{
                    startActivity(Intent(this@MainActivity, MobileNumberActivity::class.java))
                }
            }

        }, this)
        val homeLayoutManager = GridLayoutManager(this, 2)
        binding.rvPills.layoutManager = homeLayoutManager
        binding.rvPills.adapter = homeAdapter

        binding.csCart.setOnClickListener(object : DebouncedOnClickListener(){
            override fun onDebouncedClick(v: View?) {
                if(isLoggedIn()){
                    goToCart()
                }else{
                    startActivity(Intent(this@MainActivity, MobileNumberActivity::class.java))
                }
            }
        })

        binding.header.llStartOver.setOnClickListener(object : DebouncedOnClickListener(){
            override fun onDebouncedClick(v: View?) {
                startActivity(Intent(this@MainActivity, WelcomeActivity::class.java))
            }
        })

        binding.etSearch.addTextChangedListener(object : TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                handler.removeCallbacks(input_finish_checker)
            }

            override fun afterTextChanged(s: Editable?) {
                if (s != null) {
                    if (s.length > 0) {
                        last_text_edit = System.currentTimeMillis()
                        handler.postDelayed(input_finish_checker, delay)
                    }else{
                        homeAdapter.setData(allPills)
                    }
                }
            }
        })

        subscribeUI()

        if(isLoggedIn()){
            viewCart(false)
        }
        viewModel.getProviderDetail(this, true, null, null)
    }

    private fun goToCart(){
        CartSheetFragment.newInstance(this@MainActivity).show(supportFragmentManager, null)
    }

    private fun isLoggedIn(): Boolean{
        val isLogged = PrefUtils.with(this).getUser() != null
        if(!isLogged)
            startActivity(Intent(this@MainActivity, MobileNumberActivity::class.java))
        return isLogged
    }

    private fun filterPackage(list: List<Package>){
        packageList.clear()
        for(pack in list){
            if(pack.members != null) {
                for (member in pack.members) {
                    var tempPackage = com.blazma.kiosk.model.Package(
                        pack.ID,
                        pack.NAME_EN,
                        pack.NAME_AR,
                        pack.PRICE,
                        pack.HOURS,
                        pack.SMART_DESC_EN,
                        pack.SMART_DESC_AR,
                        pack.OLD_PRICE,
                        pack.IS_OFFER,
                        pack.SHOW_SUMMARY,
                        pack.DESC_EN,
                        pack.DESC_AR,
                        pack.MOBILE_IMAGE_URL_EN,
                        pack.MOBILE_IMAGE_URL_AR,
                        listOf(member)
                    )
                    packageList.add(tempPackage)
                }
            }
        }
    }


    private fun showCartCount(){
        if(packageList.size > 0){
            binding.csCartCount.visibility = View.VISIBLE
            binding.tvCartCount.text = packageList.size.toString()
        }else{
            binding.csCartCount.visibility = View.GONE
        }
    }

    ///////////////////////////////////////////////////////////////////
    ////////////////////// API ////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////

    private fun addCart(testId: String){
        packageList.forEach{
            if(it.ID == testId){
                return
            }
        }
        val map = HashMap<String, String>()
        providerId?.let { map.put("lab_id", it) }
        map.put("type", "1")
        map.put("test_ids[0]", testId)
        viewModel.addCart(this, true, PrefUtils.with(this).getUser()!!.ID, PrefUtils.with(this).getUser()!!.ACCESS_TOKEN, map)
    }

    private fun viewCart(showLoader: Boolean){
        viewModel.viewCart(this, showLoader, PrefUtils.with(this).getUser()!!.ID, PrefUtils.with(this).getUser()!!.ACCESS_TOKEN)
    }

    private fun subscribeUI(){
        //Provider Details
        viewModel.mResponse.observe(this, Observer { result ->
            when (result.status) {
                Status.SUCCESS -> {
                    val jsonObject = result.data as JsonObject
                    if (jsonObject.get("success").asBoolean) {
                        val gson = Gson()
                        val type = object : TypeToken<HomeProvider>() {}.type
                        val obj = gson.fromJson<HomeProvider>(jsonObject.get("response").asJsonObject, type)
                        providerId = obj.providerDetails.ID
                        homeAdapter.setData(obj.providerDetails.allTests)
                        pillKindAdapter.setData(obj.categories, obj.filters.category_id)
                        if(isFirst){
                            allPills = obj.providerDetails.allTests
                            isFirst = false
                        }
                    }else{
                        showAlerterError(jsonObject.get("errorMessage")?.asString)
                    }
                }
                Status.ERROR -> {
                    if (result.data != null) {
                        showAlerterError(result.data as String)
                    } else {
                        showAlerterError(result.error!!.toString())
                    }
                }
                Status.LOADING -> {

                }
            }
        })

        //Add Cart
        viewModel.mResponseCart.observe(this, Observer { result ->
            when (result.status) {
                Status.SUCCESS -> {
                    val jsonObject = result.data as JsonObject
                    if (jsonObject.get("success").asBoolean) {
                        val gson = Gson()
                        val type = object : TypeToken<Cart>() {}.type
                        val cartObj = gson.fromJson<Cart>(jsonObject.get("response").asJsonObject.get("cart").asJsonObject, type)
                        if(cartObj.packages.isNotEmpty()){
                            filterPackage(cartObj.packages)
                        }
                        showCartCount()
                        goToCart()
                    }else{
                        showAlerterError(jsonObject.get("errorMessage")?.asString)
                    }
                }
                Status.ERROR -> {
                    if (result.data != null) {
                        showAlerterError(result.data as String)
                    } else {
                        showAlerterError(result.error!!.toString())
                    }
                }
                Status.LOADING -> {

                }
            }
        })

        //View Cart
        viewModel.mResponseViewCart.observe(this, Observer { result ->
            when (result.status) {
                Status.SUCCESS -> {
                    val jsonObject = result.data as JsonObject
                    if (jsonObject.get("success").asBoolean) {
                        try{
                            val gson = Gson()
                            val type = object : TypeToken<Cart>() {}.type
                            val cartObj = gson.fromJson<Cart>(jsonObject.get("response").asJsonObject.get("cart").asJsonObject, type)
                            if(cartObj.packages.isNotEmpty()){
                                filterPackage(cartObj.packages)
                            }
                            showCartCount()
                        }catch (e: Exception){
                            packageList.clear()
                            showCartCount()
                        }
                    }else{
                        showAlerterError(jsonObject.get("errorMessage")?.asString)
                    }
                }
                Status.ERROR -> {
                    if (result.data != null) {
                        showAlerterError(result.data as String)
                    } else {
                        showAlerterError(result.error!!.toString())
                    }
                }
//                Status.LOADING -> {
//
//                }
            }
        })
    }
}