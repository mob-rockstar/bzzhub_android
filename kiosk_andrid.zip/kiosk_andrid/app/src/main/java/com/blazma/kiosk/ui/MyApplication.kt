package com.blazma.kiosk.ui

import android.app.Application
import android.util.Log
import com.google.firebase.FirebaseApp


class MyApplication: Application(), AppLifecycleHandler.AppLifecycleDelegates {

    private var lifecycleHandler: AppLifecycleHandler? = null

    override fun onCreate() {
        super.onCreate()
        FirebaseApp.initializeApp(this)
        lifecycleHandler = AppLifecycleHandler(this)
        registerLifecycleHandler(lifecycleHandler!!)
    }

    private fun registerLifecycleHandler(lifeCycleHandler: AppLifecycleHandler) {
        registerActivityLifecycleCallbacks(lifeCycleHandler)
        registerComponentCallbacks(lifeCycleHandler)
    }

    override fun onAppBackgrounded() {
        Log.e("MyApplication", "onAppBackgrounded")
//        EventBus.getDefault().post(MessageEventModel(Constants.ON_APP_BACKGROUNDED))
    }

    override fun onAppForegrounded() {
        Log.e("MyApplication", "onAppForegrounded")
//        EventBus.getDefault().post(MessageEventModel(Constants.ON_APP_FOREGROUNDED))
    }
}