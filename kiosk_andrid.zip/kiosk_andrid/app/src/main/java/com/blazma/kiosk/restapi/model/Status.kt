package com.blazma.kiosk.restapi.model

enum class Status {
    LOADING,
    SUCCESS,
    ERROR,
    COMPLETED
}