package com.blazma.kiosk.ui.main.model

data class MessageEventModel(
    val message: Int,
    val data: Any?
) {
    constructor(message: Int) : this(message, null)
}