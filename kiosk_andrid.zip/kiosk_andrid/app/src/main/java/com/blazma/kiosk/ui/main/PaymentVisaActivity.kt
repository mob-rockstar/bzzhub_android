package com.blazma.kiosk.ui.main

import android.os.Bundle
import com.blazma.kiosk.ui.BaseActivity
import com.blazma.kiosk.databinding.ActivityPaymentVisaBinding
import com.blazma.kiosk.util.InfoSuccessDialog

class PaymentVisaActivity: BaseActivity() {

    private lateinit var binding: ActivityPaymentVisaBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPaymentVisaBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        initView()
    }

    private fun initView() {
//        InfoSuccessDialog.create(this, object : InfoSuccessDialog.OnClickListener{
//            override fun onClick() {
//               finish()
//            }
//        })
        if(intent != null){
            val totalPrice = intent.getStringExtra("total_price")
            binding.tvTotal.text = totalPrice
        }
    }
}