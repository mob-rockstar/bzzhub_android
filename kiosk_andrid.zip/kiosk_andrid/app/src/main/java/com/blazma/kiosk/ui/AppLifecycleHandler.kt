package com.blazma.kiosk.ui

import android.app.Activity
import android.app.Application
import android.content.ComponentCallbacks2
import android.content.res.Configuration
import android.os.Bundle

class AppLifecycleHandler(delegates: AppLifecycleDelegates): Application.ActivityLifecycleCallbacks, ComponentCallbacks2 {
    var lifecycleDelegates: AppLifecycleDelegates? = null
    var appInForeground = false

   init {
       lifecycleDelegates = delegates
   }

    override fun onActivityCreated(p0: Activity, p1: Bundle?) {

    }

    override fun onActivityStarted(p0: Activity) {

    }

    override fun onActivityResumed(p0: Activity) {
        if (!appInForeground) {
            appInForeground = true
            lifecycleDelegates?.onAppForegrounded()
        }
    }

    override fun onActivityPaused(p0: Activity) {

    }

    override fun onActivityStopped(p0: Activity) {

    }

    override fun onActivitySaveInstanceState(p0: Activity, p1: Bundle) {

    }

    override fun onActivityDestroyed(p0: Activity) {

    }

    override fun onConfigurationChanged(p0: Configuration) {

    }

    override fun onLowMemory() {

    }

    override fun onTrimMemory(level: Int) {
        if (level == ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN) {
            appInForeground = false
            // lifecycleDelegate instance was passed in on the constructor
            lifecycleDelegates?.onAppBackgrounded()
        }
    }

    interface AppLifecycleDelegates {
        fun onAppBackgrounded()
        fun onAppForegrounded()
    }
}