package com.blazma.kiosk.ui.main

import android.app.DatePickerDialog
import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import androidx.activity.viewModels
import com.blazma.kiosk.R
import com.blazma.kiosk.databinding.ActivityRegisterBinding
import com.blazma.kiosk.model.User
import com.blazma.kiosk.restapi.model.Status
import com.blazma.kiosk.ui.BaseActivity
import com.blazma.kiosk.ui.CustomDropDownAdapter
import com.blazma.kiosk.viewmodel.RegisterViewModel
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.reflect.TypeToken
import java.util.*
import androidx.lifecycle.Observer
import com.blazma.kiosk.model.HomeProvider
import com.blazma.kiosk.model.Nationality
import com.blazma.kiosk.ui.NationalityDropDownAdapter
import com.blazma.kiosk.ui.main.model.MessageEventModel
import com.blazma.kiosk.util.*
import org.greenrobot.eventbus.EventBus
import kotlin.collections.ArrayList

class RegisterActivity: BaseActivity() {

    private lateinit var binding: ActivityRegisterBinding
    private val viewModel: RegisterViewModel by viewModels()
    private var nationalityList : List<Nationality>? = null
    private var selectedGender = ""
    private var selectedIdType = ""
    private var birthYear = 0
    private var birthMonth = 0
    private var birthDay = 0
    private var mobileNo = ""
    private var testId = ""
    private var isAddMember = false
    private lateinit var dialog: Dialog
    private val idTypeList = listOf( "national_id", "res_no", "border_no", "gulf_id")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        initView()
    }

    private fun showDatePicker(){
        val c = Calendar.getInstance()
        val year = c.get(Calendar.YEAR)
        val month = c.get(Calendar.MONTH)
        val day = c.get(Calendar.DAY_OF_MONTH)
        val dpd = DatePickerDialog(this, DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->
            binding.etDate.setText("${year}-${monthOfYear + 1}-${dayOfMonth}")
            birthYear  = year
            birthMonth = monthOfYear + 1
            birthDay = dayOfMonth

        }, year, month, day)

        dpd.show()
    }

    private fun initView() {
        setupUI(binding.parent)
        dialog= Dialog(this, R.style.Theme_Dialog)
        dialog.setContentView(R.layout.dialog_spinner)

        if(intent != null){
            mobileNo = intent.getStringExtra("no").toString()
            isAddMember = intent.getBooleanExtra("isAddMember", false)
            testId = intent.getStringExtra("test_id").toString()
        }

        binding.imgBack.setOnClickListener(object : DebouncedOnClickListener(){
            override fun onDebouncedClick(v: View?) {
                finish()
            }
        })

        binding.etDate.setOnClickListener(object : DebouncedOnClickListener(){
            override fun onDebouncedClick(v: View?) {
                showDatePicker()
            }
        })

        binding.header.spnLanguage.adapter = langAdapter
        binding.header.spnLanguage.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            var count = 0
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if(count > 0){
                    changeLocalLanguage(position)
                }
                count++
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {

            }
        }
        if(LocaleHelper.getLanguage(this) == "en"){
            binding.header.spnLanguage.setSelection(0)
        }else{
            binding.header.spnLanguage.setSelection(1)
        }

        val modelList: ArrayList<String> = ArrayList()
        modelList.add(getString(R.string.male))
        modelList.add(getString(R.string.female))
        var genderAdapter = CustomDropDownAdapter(this, modelList)
        binding.spnGender.adapter = genderAdapter
        binding.spnGender.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedGender = modelList[position]
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {

            }
        }

        val modelListIDType: ArrayList<String> = ArrayList()
        modelListIDType.add(getString(R.string.national_id))
        modelListIDType.add(getString(R.string.iqamah_no))
        modelListIDType.add(getString(R.string.borders_no))
        modelListIDType.add(getString(R.string.gulf_id))
        var idTypeAdapter = CustomDropDownAdapter(this, modelListIDType)
        binding.spnIdType.adapter = idTypeAdapter
        binding.spnIdType.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedIdType = idTypeList[position]
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {

            }
        }

        binding.tvNationality.setOnClickListener{
           dialog.show()
        }

        binding.btSave.setOnClickListener(object : DebouncedOnClickListener(){
            override fun onDebouncedClick(v: View?) {
               if(checkValid()){
                   if(isAddMember){
                       addMember()
                   }else{
                       register()
                   }
               }
            }
        })

        if(isAddMember){
            binding.tvMobileNo.visibility = View.VISIBLE
            binding.etMobileNumber.visibility = View.VISIBLE
        }else{
            binding.tvMobileNo.visibility = View.GONE
            binding.etMobileNumber.visibility = View.GONE
        }

        subscribeUI()
        viewModel.getNationalities(this, true)
    }

    private fun initSpinner(){
        val editText: EditText = dialog.findViewById(R.id.edit_text)
        val listView: ListView = dialog.findViewById(R.id.list_view)
        if(nationalityList != null) {
            var list: ArrayList<String> = ArrayList()
            val isEng = LocaleHelper.getLanguage(this@RegisterActivity) == "en"
            nationalityList!!.forEach {
                if (isEng) {
                    list.add(it.name)
                } else {
                    list.add(it.ar_name)
                }
            }
            val adapter: ArrayAdapter<String> =
                ArrayAdapter(this@RegisterActivity, android.R.layout.simple_list_item_1, list)
            listView.adapter = adapter
            editText.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(
                    s: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                }

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    adapter.filter.filter(s)
                }

                override fun afterTextChanged(s: Editable?) {}
            })

            listView.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id -> // when item selected from list
                    // set selected item on textView
                    binding.tvNationality.setText(adapter.getItem(position))
                    // Dismiss dialog
                    dialog.dismiss()
                }
        }
    }

    private fun checkValid(): Boolean{
        if(binding.etName.text.toString().isEmpty()){
            showAlerterError(getString(R.string.name_required))
            return false
        }

        if(isAddMember){
            if(binding.etMobileNumber.text.toString().isEmpty()){
                showAlerterError(getString(R.string.mobile_no_required))
                return false
            }
        }

        if(binding.tvNationality.text.toString().isEmpty()){
            showAlerterError(getString(R.string.nationality_required))
            return false
        }

//        if(binding.etPassport.text.toString().isEmpty()){
//            showAlerterError(getString(R.string.passport_required))
//            return false
//        }

        if(selectedIdType == ""){
            showAlerterError(getString(R.string.id_type_required))
            return false
        }

        if(binding.etIdNumber.text.toString().isEmpty()){
            showAlerterError(getString(R.string.id_number_required))
            return false
        }

        if(birthYear == 0 || birthMonth == 0 || birthDay == 0){
            showAlerterError(getString(R.string.birthday_required))
            return false
        }

        if(selectedGender == ""){
            showAlerterError(getString(R.string.gender_required))
            return false
        }

        return true
    }

    private fun register(){
        val map = HashMap<String, String>()
        map.put("full_name", binding.etName.text.toString())
        if(nationalityList != null){
            val curNationality = binding.tvNationality.text.toString()
            val nationality = nationalityList!!.find { it.name ==  curNationality || it.ar_name == curNationality}
            if(nationality != null){
                map.put("nationality", nationality.id)
            }
        }
        map.put("mobile_no", mobileNo)
        map.put("identification", binding.etIdNumber.text.toString())
        map.put("identification_type", selectedIdType)
        map.put("birth_month", birthMonth.toString())
        map.put("birth_day", birthDay.toString())
        map.put("birth_year", birthYear.toString())
        map.put("gender_id", if(selectedGender == getString(R.string.male)) "1" else "2")
        if(binding.etPassport.text.toString().isNotEmpty()){
            map.put("passport_number", binding.etPassport.text.toString())
        }
        viewModel.register(this, true, map)
    }

    private fun addMember(){
        val map = HashMap<String, String>()
        map.put("full_name", binding.etName.text.toString())
        if(nationalityList != null){
            val curNationality = binding.tvNationality.text.toString()
            val nationality = nationalityList!!.find { it.name ==  curNationality || it.ar_name == curNationality}
            if(nationality != null){
                map.put("nationality", nationality.id)
            }
        }
        map.put("mobile_no", binding.etMobileNumber.text.toString())
        map.put("identification", binding.etIdNumber.text.toString())
        map.put("identification_type", selectedIdType)
        map.put("birth_month", birthMonth.toString())
        map.put("birth_day", birthDay.toString())
        map.put("birth_year", birthYear.toString())
        map.put("gender_id", if(selectedGender == getString(R.string.male)) "1" else "2")
        if(binding.etPassport.text.toString().isNotEmpty()){
            map.put("passport_number", binding.etPassport.text.toString())
        }
        viewModel.addMember(this, true, PrefUtils.with(this).getUser()!!.ID, PrefUtils.with(this).getUser()!!.ACCESS_TOKEN, map)
    }

    private fun subscribeUI(){
        viewModel.mResponse.observe(this, Observer { result ->
            when (result.status) {
                Status.SUCCESS -> {
                    val jsonObject = result.data as JsonObject
                    if (jsonObject.get("success").asBoolean) {
                        val gson = Gson()
                        val type = object : TypeToken<User>() {}.type
                        val userObj = gson.fromJson<User>(jsonObject.get("response").asJsonObject, type)
                        PrefUtils.with(this@RegisterActivity).saveUser(userObj)

                        var intent = Intent(this@RegisterActivity, MainActivity::class.java)
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        startActivity(intent)
                    }else{
                        showAlerterError(jsonObject.get("errorMessage")?.asString)
                    }
                }
                Status.ERROR -> {
                    if (result.data != null) {
                        showAlerterError(result.data as String)
                    } else {
                        showAlerterError(result.error!!.toString())
                    }
                }
                Status.LOADING -> {

                }
            }
        })

        viewModel.mResponseNationalities.observe(this, Observer { result ->
            when (result.status) {
                Status.SUCCESS -> {
                    val jsonObject = result.data as JsonObject
                    if (jsonObject.get("success").asBoolean) {
                        val gson = Gson()
                        val type = object : TypeToken<List<Nationality>>() {}.type
                        nationalityList = gson.fromJson<List<Nationality>>(jsonObject.get("response").asJsonArray, type)
                        initSpinner()
                    }else{
                        showAlerterError(jsonObject.get("errorMessage")?.asString)
                    }
                }
                Status.ERROR -> {
                    if (result.data != null) {
                        showAlerterError(result.data as String)
                    } else {
                        showAlerterError(result.error!!.toString())
                    }
                }
                Status.LOADING -> {

                }
            }
        })

        viewModel.mResponseAddMember.observe(this, Observer { result ->
            when (result.status) {
                Status.SUCCESS -> {
                    val jsonObject = result.data as JsonObject
                    if (jsonObject.get("success").asBoolean) {
                        val res = jsonObject.get("response").asJsonObject
                        val id = res.get("ID").asString
                        val ids = listOf(id, testId)
                        EventBus.getDefault().post(MessageEventModel(Constants.CART_ADD_WITH_MEMBER, ids))
                        finish()
                    }else{
                        showAlerterError(jsonObject.get("errorMessage")?.asString)
                    }
                }
                Status.ERROR -> {
                    if (result.data != null) {
                        showAlerterError(result.data as String)
                    } else {
                        showAlerterError(result.error!!.toString())
                    }
                }
                Status.LOADING -> {

                }
            }
        })
    }
}