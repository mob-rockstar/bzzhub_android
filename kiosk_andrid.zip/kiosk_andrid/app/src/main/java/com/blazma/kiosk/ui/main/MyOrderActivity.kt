package com.blazma.kiosk.ui.main

import android.Manifest
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.*
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import com.blazma.kiosk.viewmodel.ActivityViewModel
import com.blazma.kiosk.ui.BaseActivity
import androidx.lifecycle.Observer
import com.blazma.kiosk.R
import com.blazma.kiosk.databinding.ActivityMyOrderBinding
import com.blazma.kiosk.model.Cart
import com.blazma.kiosk.model.Order
import com.blazma.kiosk.model.Package
import com.blazma.kiosk.restapi.model.Status
import com.blazma.kiosk.ui.WelcomeActivity
import com.blazma.kiosk.ui.main.adapter.MyOrderAdapter
import com.blazma.kiosk.ui.main.model.MessageEventModel
import com.blazma.kiosk.util.*
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.reflect.TypeToken
import com.hoho.android.usbserial.util.SerialInputOutputManager
import com.universal.alhamrani.ecrusbintegration.AlhamraniLibrary
import com.universal.alhamrani.ecrusbintegration.Response
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors
import kotlin.collections.ArrayList

lateinit var filter: IntentFilter
lateinit var processalertDialog : AlertDialog
private val ACTION_USB_PERMISSION = "com.android.example.USB_PERMISSION"
lateinit var spinnerTransaction: Spinner
var transaction_type: String = "PUR"
// Storage Permissions
private val REQUEST_EXTERNAL_STORAGE = 1
private val PERMISSIONS_STORAGE = arrayOf(
    Manifest.permission.READ_EXTERNAL_STORAGE,
    Manifest.permission.WRITE_EXTERNAL_STORAGE
)
var alhamraniLibrary = AlhamraniLibrary()

class MyOrderActivity: BaseActivity(), SerialInputOutputManager.Listener {

    private lateinit var binding: ActivityMyOrderBinding
    private val viewModel: ActivityViewModel by viewModels()
    private lateinit var myOrderAdapter: MyOrderAdapter
    private var packageList: ArrayList<Package> = ArrayList()
    private var cart: Cart? = null

    private var scanOrderId: String? = null
    private var isPayWithCash = true
    private var orderId: String? = null
    private var totalPrice = ""

    private val handler = Handler()
    private val handlerCallback = Runnable {
        // Perform any required operation on disconnect
        goToWelcome()
    }

    private var isRemove = false

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEventModel) {
        if(event.message == Constants.CART_ADD_WITH_MEMBER){
            val ids = event.data as List<*>
            if(ids.size == 2){
                addCartWithMember(ids[0] as String, ids[1] as String)
            }
        }else if(event.message == Constants.CART_RELOAD){
            viewCart(false)
        }else if(event.message == Constants.UNAUTHORIZED){
            startActivity(Intent(this, MobileNumberActivity::class.java))
        }
    }

    override fun onNewData(data: ByteArray?) {
        if(data != null){
            var response = alhamraniLibrary.parseResponse(data!!)
            // make sure  size is greater than 6 for proper response to be shown
            if(data!!.size > 6) {
                runOnUiThread({
                    enableButton()
                    updateUIForResponse(response)
                })
            }
        }
    }

    override fun onRunError(e: java.lang.Exception?) {
        enableButton()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMyOrderBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        EventBus.getDefault().register(this)
        initView()
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
        handler.removeCallbacks(handlerCallback)
    }

    private fun initView() {
        initPayment()

        if(intent != null){
            scanOrderId = intent.getStringExtra("orderId")
        }

        val sdf = SimpleDateFormat("dd MMM")
        val currentDate = sdf.format(Date())
        binding.tvDate.text = currentDate
        val sdHour = SimpleDateFormat("hh:mm")
        val currentHour = sdHour.format(Date())
        binding.tvTime.text = currentHour

        binding.header.spnLanguage.adapter = langAdapter
        binding.header.spnLanguage.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            var count = 0
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if(count > 0){
                    changeLocalLanguage(position)
                }
                count++
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {

            }
        }
        if(LocaleHelper.getLanguage(this) == "en"){
            binding.header.spnLanguage.setSelection(0)
        }else{
            binding.header.spnLanguage.setSelection(1)
        }

        binding.header.llStartOver.setOnClickListener(object : DebouncedOnClickListener(){
            override fun onDebouncedClick(v: View?) {
                startActivity(Intent(this@MyOrderActivity, WelcomeActivity::class.java))
            }
        })

        myOrderAdapter = MyOrderAdapter(object : MyOrderAdapter.OnClickListener {
            override fun onRemoveFromCart(cartId: String) {
               removeCart(cartId)
            }

            override fun onAddMember(cartId: String) {
                val intent = Intent(this@MyOrderActivity, RegisterActivity::class.java)
                intent.putExtra("isAddMember", true)
                intent.putExtra("test_id", cartId)
                intent.putExtra("no", PrefUtils.with(this@MyOrderActivity).getUser()?.MOBILE_NUMBER)
                startActivity(intent)
            }

        }, this, scanOrderId == null)
        binding.rvMyOrder.adapter = myOrderAdapter

        binding.imgBack.setOnClickListener(object : DebouncedOnClickListener(){
            override fun onDebouncedClick(v: View?) {
                finish()
            }
        })

        binding.btPayCash.setOnClickListener(object : DebouncedOnClickListener(){
            override fun onDebouncedClick(v: View?) {
                if(cart != null){
                    isPayWithCash = true
                    addOrder("1")
                }
            }
        })

        binding.btPayVisa.setOnClickListener(object : DebouncedOnClickListener(){
            override fun onDebouncedClick(v: View?) {
                isPayWithCash = false
                if(scanOrderId != null){
                    //QR Scan
                    if(totalPrice == "")
                        return
                    sendTransaction(totalPrice)
                }else{
                    if(cart == null){
                        return
                    }
                    addOrder("2")
                }
            }
        })

        subscribeUI()
        if(scanOrderId != null){
            //from QR Code Scan
            binding.tvOrderId.text = "#" + scanOrderId
            binding.btPayCash.visibility = View.GONE
            getOrder(true)
        }else{
            //from cart
            binding.btPayCash.visibility = View.VISIBLE
            viewCart(true)
        }
    }

    private fun viewCart(showLoader: Boolean){
        viewModel.viewCart(this, showLoader, PrefUtils.with(this).getUser()!!.ID, PrefUtils.with(this).getUser()!!.ACCESS_TOKEN)
    }

    private fun getOrder(showLoader: Boolean){
        scanOrderId?.let { viewModel.getOrder(this, showLoader, it) }
    }

    private fun showPrice(){
        if(cart != null){
            binding.tvTotal.text = cart!!.net_total
            binding.tvTax.text = cart!!.tax_amount
            binding.tvSubTotal.text = cart!!.base_amount
            binding.tvPackageCount.text =""+ cart!!.packages_count + "x"
        }
    }

    private fun showPrice(total: String, tax: String){
        binding.tvTotal.text = total
        binding.tvTax.text = tax
        binding.csSubTotal.visibility = View.GONE
    }

    private fun showFailDlg(){
        EventBus.getDefault().post(MessageEventModel(Constants.CART_RELOAD))
        InfoFailDialog.create(this, object : InfoFailDialog.OnClickListener{
            override fun onTry() {
                finish()
            }

            override fun onStartOver() {
               goToWelcome()
            }
        })
    }

    private fun goToWelcome(){
        val i = Intent(this@MyOrderActivity, WelcomeActivity::class.java)
        i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(i)
    }

    private fun showSuccessDlg(title: String, description: String){
        PrefUtils.with(this).clear()
        EventBus.getDefault().post(MessageEventModel(Constants.CART_RELOAD))
        InfoSuccessDialog.create(this, title, description, object : InfoSuccessDialog.OnClickListener{
            override fun onClick() {
                goToWelcome()
            }
        })

        handler.postDelayed(handlerCallback, 10000)
    }

    private fun initPayment(){
        alhamraniLibrary.requestPermission(this)
        var is_success = alhamraniLibrary.initializeAU()
        if(is_success) {
            initListener()
        }
    }

    fun sendTransaction(amount: String){
        var price = 100 * amount.toFloat()
        var formattedPrice = String.format("%.2f", price).replace(".00", "")
        disableButton()
        showloader()
        alhamraniLibrary.sendTransaction(transaction_type,"123",
           "1234567890", formattedPrice,"", "",
           "","","")

        Handler(Looper.getMainLooper()).postDelayed({
            enableButton()
            processalertDialog.dismiss()
        }, 60000)
    }

    fun initListener(){
        var port = alhamraniLibrary.getInitializedPort()
        var usbIoManager = SerialInputOutputManager(port,this )
        Executors.newSingleThreadExecutor().submit(usbIoManager)
        enableButton()
    }

    fun enableButton() {
        binding.btPayVisa.isEnabled = true
    }

    fun disableButton() {
        binding.btPayVisa.isEnabled = false
    }

    fun showloader(){
        val dialogBuilder = AlertDialog.Builder(this)
        dialogBuilder.setCancelable(false)
        val inflater = this.layoutInflater
        val dialogView = inflater.inflate(R.layout.processing_layout, null)
        dialogBuilder.setView(dialogView)
        processalertDialog = dialogBuilder.create()

        processalertDialog.show()

    }

    fun updateUIForResponse(result: Response) {
        processalertDialog.dismiss()

        if (result.response_code == "000" ||
            result.response_code  == "001" ||
            result.response_code  == "003" ||
            result.response_code  == "007" ||
            result.response_code  == "087" ||
            result.response_code  == "089" ||
            result.response_code  == "300" ||
            result.response_code  == "400" ||
            result.response_code  == "500" ||
            result.response_code  == "800"
        ) { // APPROVED
            if(scanOrderId != null){
                setOrderPaid(scanOrderId!!)
            }else{
                orderId?.let { setOrderPaid(it) }
            }
        } else { // DECLINE
            showFailDlg()
        }
    }

    private fun filterPackage(list: List<Package>){
        packageList.clear()
        for(pack in list){
            if(pack.members != null){
                for(member in pack.members){
                    var tempPackage = com.blazma.kiosk.model.Package(pack.ID, pack.NAME_EN, pack.NAME_AR, pack.PRICE, pack.HOURS,
                        pack.SMART_DESC_EN, pack.SMART_DESC_AR, pack.OLD_PRICE, pack.IS_OFFER, pack.SHOW_SUMMARY, pack.DESC_EN, pack.DESC_AR,
                        pack.MOBILE_IMAGE_URL_EN, pack.MOBILE_IMAGE_URL_AR, listOf(member))
                    packageList.add(tempPackage)
                }
            }
        }
        myOrderAdapter.setData(packageList)
    }

    ///////////////////////////////////////////////////////////////////
    ////////////////////// API ////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////

    private fun setOrderPaid(orderId: String){
        viewModel.setOrderPaid(this, true, orderId)
    }

    private fun addCartWithMember(memberId: String, testId: String){
        val map = HashMap<String, String>()
        MainActivity.providerId?.let { map.put("lab_id", it) }
        map.put("type", "1")
        map.put("test_ids[0]", testId)
        map.put("member_id", memberId)
        viewModel.addCart(this, true, PrefUtils.with(this).getUser()!!.ID, PrefUtils.with(this).getUser()!!.ACCESS_TOKEN, map)
    }

    private fun removeCart(cartId: String){
        isRemove = true
        viewModel.removeCart(this, true,PrefUtils.with(this).getUser()!!.ID,
            PrefUtils.with(this).getUser()!!.ACCESS_TOKEN, cartId)
    }

    private fun addOrder(payment_method_id: String){
        val map = HashMap<String, String>()
        map.put("payment_method_id", payment_method_id)
        MainActivity.providerId?.let { map.put("hospital_id", it) }
        viewModel.addOrder(this, true, PrefUtils.with(this).getUser()!!.ID, PrefUtils.with(this).getUser()!!.ACCESS_TOKEN, map)
    }

    private fun subscribeUI(){
        viewModel.mResponseViewCart.observe(this, Observer { result ->
            when (result.status) {
                Status.SUCCESS -> {
                    val jsonObject = result.data as JsonObject
                    if (jsonObject.get("success").asBoolean) {
                        try{
                            val gson = Gson()
                            val type = object : TypeToken<Cart>() {}.type
                            cart = gson.fromJson<Cart>(jsonObject.get("response").asJsonObject.get("cart").asJsonObject, type)
                            if(cart?.packages?.isNotEmpty() == true){
                                filterPackage(cart?.packages!!)
                                showPrice()
                            }
                        }catch (e: Exception){
                            packageList.clear()
                            myOrderAdapter.setData(packageList)
                        }
                    }else{
//                        showAlerterError(jsonObject.get("errorMessage")?.asString)
                    }
                }
//                Status.ERROR -> {
//                    if (result.data != null) {
//                        showAlerterError(result.data as String)
//                    } else {
//                        showAlerterError(result.error!!.toString())
//                    }
//                }
//                Status.LOADING -> {
//
//                }
            }
        })

        viewModel.mResponseRemoveCart.observe(this, Observer { result ->
            when (result.status) {
                Status.SUCCESS -> {
                    val jsonObject = result.data as JsonObject
                    if (jsonObject.get("success").asBoolean) {
                        try{
                            val gson = Gson()
                            val type = object : TypeToken<Cart>() {}.type
                            var obj = jsonObject.get("response").asJsonObject.get("cart")
                            if(!obj.isJsonNull){
                                val cartObj = gson.fromJson<Cart>(obj.asJsonObject, type)
                                cartObj.packages = cartObj.packages.filter { it -> it.ID != cartObj.packages[0].ID }
                                filterPackage(cartObj.packages)
                                showPrice()
                                EventBus.getDefault().post(MessageEventModel(Constants.CART_RELOAD))
                            }else{
                                if(isRemove){
                                    EventBus.getDefault().post(MessageEventModel(Constants.CART_RELOAD))
                                    finish()
                                }
                            }
                            isRemove = false
                        }catch (ex: Exception){

                        }
                    }else{
                        showAlerterError(jsonObject.get("errorMessage")?.asString)
                    }
                }
                Status.ERROR -> {
                    if (result.data != null) {
                        showAlerterError(result.data as String)
                    } else {
                        showAlerterError(result.error!!.toString())
                    }
                }
                Status.LOADING -> {

                }
            }
        })

        viewModel.mResponseGetOrder.observe(this, Observer { result ->
            when (result.status) {
                Status.SUCCESS -> {
                    val jsonObject = result.data as JsonObject
                    if (jsonObject.get("success").asBoolean) {
                        val gson = Gson()
                        val type = object : TypeToken<List<Package>>() {}.type
                        totalPrice = jsonObject.get("response").asJsonObject.get("TOTAL_AMOUNT").asString
                        val tax = jsonObject.get("response").asJsonObject.get("TAX_AMOUNT").asString
                        val list = gson.fromJson<List<Package>>(jsonObject.get("response").asJsonObject.get("eNDUSERLABORDERPACKAGES").asJsonArray, type)
                        if(list.isNotEmpty()){
                            filterPackage(list)
                            showPrice(totalPrice, tax)
                        }
                        val isPaid = jsonObject.get("response").asJsonObject.get("IS_PAID").asInt
                        if(isPaid == 1){
                            showSuccessDlg(getString(R.string.your_order_alredy_paid), "")
                        }
                    }else{
                        showAlerterError(jsonObject.get("errorMessage")?.asString)
                    }
                }
                Status.ERROR -> {
                    if (result.data != null) {
                        showAlerterError(result.data as String)
                    } else {
                        showAlerterError(result.error!!.toString())
                    }
                }
                Status.LOADING -> {

                }
            }
        })

        viewModel.mResponseAddOrder.observe(this, Observer { result ->
            when (result.status) {
                Status.SUCCESS -> {
                    val jsonObject = result.data as JsonObject
                    if (jsonObject.get("success").asBoolean) {
                        val gson = Gson()
                        val type = object : TypeToken<Order>() {}.type
                        val orderObj = gson.fromJson<Order>(jsonObject.get("response").asJsonObject.get("data").asJsonObject, type)
                        orderId = orderObj.ID
                        binding.tvOrderId.text = "#" + orderId
                        if(isPayWithCash){
                            showSuccessDlg(getString(R.string.order_created), getString(R.string.thank_order_created))
                        }else{
                            sendTransaction(cart!!.net_total)
                        }
                    }else{
                        showFailDlg()
                    }
                }
                Status.ERROR -> {
                    showFailDlg()
                }
                Status.LOADING -> {

                }
            }
        })

        //Add Cart
        viewModel.mResponseCart.observe(this, Observer { result ->
            when (result.status) {
                Status.SUCCESS -> {
                    val jsonObject = result.data as JsonObject
                    if (jsonObject.get("success").asBoolean) {
                        val gson = Gson()
                        val type = object : TypeToken<Cart>() {}.type
                        val cartObj = gson.fromJson<Cart>(jsonObject.get("response").asJsonObject.get("cart").asJsonObject, type)
                        if(cartObj.packages.isNotEmpty()){
                            filterPackage(cartObj.packages)
                            EventBus.getDefault().post(MessageEventModel(Constants.CART_RELOAD))
                        }
                    }else{
                        showAlerterError(jsonObject.get("errorMessage")?.asString)
                    }
                }
                Status.ERROR -> {
                    if (result.data != null) {
                        showAlerterError(result.data as String)
                    } else {
                        showAlerterError(result.error!!.toString())
                    }
                }
                Status.LOADING -> {

                }
            }
        })

        viewModel.mResponseSetOrder.observe(this, Observer { result ->
            when (result.status) {
                Status.SUCCESS -> {
                    val jsonObject = result.data as JsonObject
                    if (jsonObject.get("success").asBoolean) {
                        showSuccessDlg(getString(R.string.order_created), getString(R.string.thank_order_created))
                    }else{
                        showFailDlg()
                    }
                }
                Status.ERROR -> {
                    showFailDlg()
                }
                Status.LOADING -> {

                }
            }
        })
    }
}