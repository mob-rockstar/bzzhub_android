package com.blazma.kiosk.ui.main.model

data class FilterModel(val name: String, val url: Int) {

}