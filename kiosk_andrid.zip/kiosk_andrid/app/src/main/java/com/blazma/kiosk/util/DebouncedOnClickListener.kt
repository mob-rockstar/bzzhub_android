package com.blazma.kiosk.util

import android.os.SystemClock
import android.view.View
import java.util.*

abstract class DebouncedOnClickListener(private val minimumIntervalMillis: Long = 500) : View.OnClickListener {
    private val lastClickMap: MutableMap<View, Long>

    abstract fun onDebouncedClick(v: View?)
    override fun onClick(clickedView: View) {
        val previousClickTimestamp = lastClickMap[clickedView]
        val currentTimestamp: Long = SystemClock.uptimeMillis()
        lastClickMap[clickedView] = currentTimestamp
        if (previousClickTimestamp == null || Math.abs(currentTimestamp - previousClickTimestamp) > minimumIntervalMillis) {
            onDebouncedClick(clickedView)
        }
    }

    init {
        lastClickMap = WeakHashMap()
    }
}