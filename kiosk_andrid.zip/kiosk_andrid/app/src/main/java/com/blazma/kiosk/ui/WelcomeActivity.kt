package com.blazma.kiosk.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.blazma.kiosk.R
import com.blazma.kiosk.databinding.ActivityWelcomeBinding
import com.blazma.kiosk.ui.main.MainActivity
import com.blazma.kiosk.ui.main.MobileNumberActivity
import com.blazma.kiosk.ui.main.ScanActivity
import com.blazma.kiosk.util.DebouncedOnClickListener
import com.blazma.kiosk.util.LocaleHelper
import com.blazma.kiosk.util.PrefUtils
import java.lang.Exception
import java.util.*
import android.R.attr.data
import com.blazma.kiosk.ui.main.MyOrderActivity


class WelcomeActivity: AppCompatActivity() {

    private lateinit var binding: ActivityWelcomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWelcomeBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        initView()
    }

    fun changeLocalLanguage(id: Int){
        if(id == 0){
            LocaleHelper.changeLocale(this,"en", "US")
        }else{
            LocaleHelper.changeLocale(this, "ar", "SA")
        }
        restart()
    }

    fun restart() {
        Objects.requireNonNull(this).finish()
        startActivity(intent)
    }

    private fun initView(){
        LocaleHelper.onAttach(this)
        PrefUtils.with(this).clear()
        val modelList: ArrayList<String> = ArrayList()
        modelList.add(getString(R.string.english))
        modelList.add(getString(R.string.arabic))
        var langAdapter = CustomDropDownAdapter(this, modelList)

        binding.header.spnLanguage.adapter = langAdapter
        binding.header.spnLanguage.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            var count = 0
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if(count > 0){
                    changeLocalLanguage(position)
                }
                count++
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {

            }
        }
        if(LocaleHelper.getLanguage(this) == "en"){
            binding.header.spnLanguage.setSelection(0)
        }else{
            binding.header.spnLanguage.setSelection(1)
        }

        binding.llNewReserve.setOnClickListener(object : DebouncedOnClickListener(){
            override fun onDebouncedClick(v: View?) {
                startActivity(Intent(this@WelcomeActivity, MobileNumberActivity::class.java))
            }
        })

        binding.llPay.setOnClickListener(object : DebouncedOnClickListener(){
            override fun onDebouncedClick(v: View?) {
                if(checkPermission()){
                    startScan()
                }else{
                    requestPermission()
                }
            }
        })
    }

    private fun startScan(){
        startActivity(Intent(this@WelcomeActivity, ScanActivity::class.java))

//        try {
//            val intent = Intent("com.google.zxing.client.android.SCAN")
//            intent.putExtra("SCAN_MODE", "QR_CODE_MODE") // "PRODUCT_MODE for bar codes
//            startActivityForResult(intent, 0)
//        } catch (e: Exception) {
//            val marketUri: Uri = Uri.parse("market://details?id=com.google.zxing.client.android")
//            val marketIntent = Intent(Intent.ACTION_VIEW, marketUri)
//            startActivity(marketIntent)
//        }
    }

    private fun checkPermission(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) === PackageManager.PERMISSION_GRANTED
    }

    private fun requestPermission() {
        ActivityCompat.requestPermissions(
            this, arrayOf<String>(Manifest.permission.CAMERA),
            55
        )
    }

//    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        super.onActivityResult(requestCode, resultCode, data)
//        if (requestCode === 0) {
//            if (resultCode === RESULT_OK) {
//                val result = data?.getStringExtra("SCAN_RESULT")
//                if(result != null){
//                    var orderId = result.substring(result.lastIndexOf("/") + 1)
//                    val intent = Intent(this@WelcomeActivity, MyOrderActivity::class.java)
//                    intent.putExtra("orderId", orderId)
//                    startActivity(intent)
//                    finish()
//                }
//            }
//        }
//    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            55 -> if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startScan()
            }
        }
    }
}