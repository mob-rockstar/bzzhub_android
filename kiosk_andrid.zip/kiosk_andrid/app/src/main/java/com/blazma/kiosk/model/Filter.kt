package com.blazma.kiosk.model

data class Filter(
    val category_id : String,
    val search : String,
    val lat: String,
    val long : String,
)