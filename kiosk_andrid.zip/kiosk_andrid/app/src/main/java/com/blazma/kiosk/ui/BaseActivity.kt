package com.blazma.kiosk.ui

import android.annotation.SuppressLint
import android.app.admin.DevicePolicyManager
import android.app.admin.SystemUpdatePolicy
import android.content.*
import android.os.*
import android.provider.Settings
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.blazma.kiosk.MyDeviceAdminReceiver
import com.blazma.kiosk.R
import com.blazma.kiosk.ui.main.MainActivity
import com.blazma.kiosk.util.LocaleHelper
import com.blazma.kiosk.util.PrefUtils
import com.blazma.kiosk.util.hideSoftKeyboard
import java.util.*

abstract class BaseActivity : AppCompatActivity(){
    private lateinit var mAdminComponentName: ComponentName
    private lateinit var mDevicePolicyManager: DevicePolicyManager
    lateinit var langAdapter: CustomDropDownAdapter

    val DISCONNECT_TIMEOUT: Long = 180000// 3 min

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

//        mAdminComponentName = MyDeviceAdminReceiver.getComponentName(this)
//        mDevicePolicyManager = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
//
//        mDevicePolicyManager.removeActiveAdmin(mAdminComponentName)
//
//        val isAdmin = isAdmin()

//        setKioskPolicies(true, isAdmin)

        val modelList: ArrayList<String> = ArrayList()
        modelList.add(getString(R.string.english))
        modelList.add(getString(R.string.arabic))
        langAdapter = CustomDropDownAdapter(this, modelList)
    }

//    private fun isAdmin() = mDevicePolicyManager.isDeviceOwnerApp(packageName)
//
//    private fun setKioskPolicies(enable: Boolean, isAdmin: Boolean) {
//        if (isAdmin) {
//            setRestrictions(enable)
//            enableStayOnWhilePluggedIn(enable)
//            setUpdatePolicy(enable)
//            setAsHomeApp(enable)
//            setKeyGuardEnabled(enable)
//        }
//        setLockTask(enable, isAdmin)
//        setImmersiveMode(enable)
//    }

    // region restrictions
//    private fun setRestrictions(disallow: Boolean) {
//        setUserRestriction(UserManager.DISALLOW_SAFE_BOOT, disallow)
//        setUserRestriction(UserManager.DISALLOW_FACTORY_RESET, disallow)
//        setUserRestriction(UserManager.DISALLOW_ADD_USER, disallow)
//        setUserRestriction(UserManager.DISALLOW_MOUNT_PHYSICAL_MEDIA, disallow)
//        setUserRestriction(UserManager.DISALLOW_ADJUST_VOLUME, disallow)
//        mDevicePolicyManager.setStatusBarDisabled(mAdminComponentName, disallow)
//    }
//
//    private fun setUserRestriction(restriction: String, disallow: Boolean) = if (disallow) {
//        mDevicePolicyManager.addUserRestriction(mAdminComponentName, restriction)
//    } else {
//        mDevicePolicyManager.clearUserRestriction(mAdminComponentName, restriction)
//    }
    // endregion

//    private fun enableStayOnWhilePluggedIn(active: Boolean) = if (active) {
//        mDevicePolicyManager.setGlobalSetting(
//            mAdminComponentName,
//            Settings.Global.STAY_ON_WHILE_PLUGGED_IN,
//            (BatteryManager.BATTERY_PLUGGED_AC
//                    or BatteryManager.BATTERY_PLUGGED_USB
//                    or BatteryManager.BATTERY_PLUGGED_WIRELESS).toString()
//        )
//    } else {
//        mDevicePolicyManager.setGlobalSetting(mAdminComponentName, Settings.Global.STAY_ON_WHILE_PLUGGED_IN, "0")
//    }
//
//    private fun setLockTask(start: Boolean, isAdmin: Boolean) {
//        if (isAdmin) {
//            mDevicePolicyManager.setLockTaskPackages(
//                mAdminComponentName, if (start) arrayOf(packageName) else arrayOf()
//            )
//        }
//        if (start) {
//            startLockTask()
//        } else {
//            stopLockTask()
//        }
//    }
//
//    private fun setUpdatePolicy(enable: Boolean) {
//        if (enable) {
//            mDevicePolicyManager.setSystemUpdatePolicy(
//                mAdminComponentName,
//                SystemUpdatePolicy.createWindowedInstallPolicy(60, 120)
//            )
//        } else {
//            mDevicePolicyManager.setSystemUpdatePolicy(mAdminComponentName, null)
//        }
//    }
//
//    private fun setAsHomeApp(enable: Boolean) {
//        if (enable) {
//            val intentFilter = IntentFilter(Intent.ACTION_MAIN).apply {
//                addCategory(Intent.CATEGORY_HOME)
//                addCategory(Intent.CATEGORY_DEFAULT)
//            }
//            mDevicePolicyManager.addPersistentPreferredActivity(
//                mAdminComponentName, intentFilter, ComponentName(packageName, BaseActivity::class.java.name)
//            )
//        } else {
//            mDevicePolicyManager.clearPackagePersistentPreferredActivities(
//                mAdminComponentName, packageName
//            )
//        }
//    }
//
//    private fun setKeyGuardEnabled(enable: Boolean) {
//        mDevicePolicyManager.setKeyguardDisabled(mAdminComponentName, !enable)
//    }
//
//    private fun setImmersiveMode(enable: Boolean) {
//        if (enable) {
//            val flags = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
//                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
//                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
//                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
//                    or View.SYSTEM_UI_FLAG_FULLSCREEN
//                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
//            window.decorView.systemUiVisibility = flags
//        } else {
//            val flags = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
//                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
//                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
//            window.decorView.systemUiVisibility = flags
//        }
//    }

    fun goBack(){
        val backstack_count = supportFragmentManager.backStackEntryCount
        if (backstack_count <= 1) {
            finish()
        } else if (backstack_count > 1) {
            supportFragmentManager.popBackStack()
        }
    }

    open fun restart() {
        Objects.requireNonNull(this).finish()
        startActivity(intent)
    }

    override fun onBackPressed() {
        goBack()
    }

    fun changeLocalLanguage(id: Int){
        if(id == 0){
            LocaleHelper.changeLocale(this,"en", "US")
        }else{
            LocaleHelper.changeLocale(this, "ar", "SA")
        }
        restart()
//        val i = Intent(this, WelcomeActivity::class.java)
//        i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
//        startActivity(i)
    }

    @SuppressLint("ClickableViewAccessibility")
    open fun setupUI(view: View) {
        // Set up touch listener for non-text box views to hide keyboard.
        if (view !is EditText) {
            view.setOnTouchListener(View.OnTouchListener { v, event ->
                hideSoftKeyboard()
                false
            })
        }
        if (view is ViewGroup) {
            for (i in 0 until (view as ViewGroup).childCount) {
                val innerView: View = (view as ViewGroup).getChildAt(i)
                setupUI(innerView)
            }
        }
    }


    private val disconnectHandler = Handler()
    private val disconnectCallback = Runnable {
        // Perform any required operation on disconnect
        val i = Intent(this, WelcomeActivity::class.java)
        i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(i)
    }

    open fun resetDisconnectTimer() {
        disconnectHandler.removeCallbacks(disconnectCallback)
        disconnectHandler.postDelayed(disconnectCallback, DISCONNECT_TIMEOUT)
    }

    open fun stopDisconnectTimer() {
        disconnectHandler.removeCallbacks(disconnectCallback)
    }

    override fun onUserInteraction() {
        resetDisconnectTimer()
    }

    override fun onResume() {
        super.onResume()
        resetDisconnectTimer()
    }

    override fun onStop() {
        super.onStop()
        stopDisconnectTimer()
    }

}
