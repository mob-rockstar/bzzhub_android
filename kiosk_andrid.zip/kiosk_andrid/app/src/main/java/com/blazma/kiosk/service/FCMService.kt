package com.blazma.kiosk.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.media.AudioAttributes
import android.os.Build
import android.util.Log
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import org.json.JSONException
import org.json.JSONObject

class FCMService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        Log.d(TAG, "Refreshed token: $token")

    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        Log.d(TAG, "From: " + remoteMessage.from)

        // Check if message contains a data payload.
        if (remoteMessage.data.isNotEmpty()) {
            Log.d(TAG, "Push Message data payload: " + remoteMessage.data)
            var title: String? = ""
            var bodyMessage: String? = ""
            var notificationJson: JSONObject? = null
            try {
                notificationJson = JSONObject(remoteMessage.data as Map<*, *>)
                bodyMessage = notificationJson.getString("body")
            } catch (e: JSONException) {
                e.printStackTrace()
            }
            val chanelId = "courialId"

            val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager

            // show the notification
//            val mBuilder = NotificationCompat.Builder(this, chanelId)
//                    .setContentTitle(title)
//                    .setContentText(bodyMessage)
//                    .setAutoCancel(true)
//                    .setColor(resources.getColor(R.color.orange))
//                    .setPriority(NotificationCompat.PRIORITY_HIGH)
//            mBuilder.setSmallIcon(R.drawable.ic_notificaion)

            // Create the NotificationChannel, but only on API 26+ because
            // the NotificationChannel class is new and not in the support library
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                mBuilder.setChannelId(chanelId)
                val name: CharSequence = CHANNEL_NAME
                val importance = NotificationManager.IMPORTANCE_DEFAULT
                val channel = NotificationChannel(chanelId, name, importance)
                channel.description = CHANNEL_DESCRIPTION
                channel.setShowBadge(true)
                val attributes = AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .build()
                notificationManager.createNotificationChannel(channel)
            }
//            notificationManager.notify(System.currentTimeMillis().toInt(), mBuilder.build())
        }

        // Check if message contains a notification payload.
        if (remoteMessage.notification != null) {
            Log.d(TAG, "Message Notification Body: " + remoteMessage.notification!!.body)
        }
    }

    companion object {
        private const val TAG = "FCM Service"
        private const val CHANNEL_NAME = "Courial Notification Channel"
        private const val CHANNEL_DESCRIPTION = ""
    }
}