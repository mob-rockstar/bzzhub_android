package com.blazma.kiosk.util

import android.content.Context;
import android.preference.PreferenceManager;
import java.util.Locale;

object LocaleHelper {
    private val SELECTED_LANGUAGE = "Locale.Helper.Selected.Language"

    fun onAttach(context: Context) {
        val lang = getLanguage(context)
        if (lang == "en") {
            changeLocale(context, lang, "US")
        } else {
            changeLocale(context, lang, "SA")
        }
    }

    fun getLanguage(context: Context): String? {
        return getPersistedData(context, "en")
    }

    fun getPersistedData(context: Context?, defaultLanguage: String?): String? {
        val preferences = PreferenceManager.getDefaultSharedPreferences(context)
        return preferences.getString(SELECTED_LANGUAGE, defaultLanguage)
    }

    private fun persist(context: Context, language: String?) {
        val preferences = PreferenceManager.getDefaultSharedPreferences(context)
        val editor = preferences.edit()
        editor.putString(SELECTED_LANGUAGE, language)
        editor.apply()
    }

    fun changeLocale(context: Context, localeCode: String?, countryCode: String?) {
        persist(context, localeCode)
        val locale = Locale(localeCode, countryCode)
        val res = context.resources
        // Change locale settings in the app.
        val dm = res.displayMetrics
        val conf = res.configuration
        conf.setLocale(locale) // API 17+ only.
        res.updateConfiguration(conf, dm)
    }
}