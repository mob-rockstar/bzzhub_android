package com.blazma.kiosk.model

data class Pill(
    val ID : String,
    val HOSPITAL_ID : String,
    val PRICE: String,
    val NAME_EN : String,
    val NAME_AR : String,
    val HOURS : String,
    val LAB_CATEGORY_ID : Int,
    val ACTIVE_STATUS : Int,
    val TEST_COUNT : Any?,
    val MOBILE_IMAGE_URL_EN : String,
    val MOBILE_IMAGE_URL_AR : String,
    val DESC_EN : String,
    val DESC_AR : String,
    val OLD_PRICE : String,
    val IS_OFFER : Any?,
    val IS_PACKAGE : Any?,
    val SHOW_SUMMARY : Int,
)