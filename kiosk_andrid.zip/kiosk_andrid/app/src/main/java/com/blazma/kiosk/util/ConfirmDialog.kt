package com.blazma.kiosk.util

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.*
import com.blazma.kiosk.R
import com.blazma.kiosk.databinding.DialogConfirmBinding
import java.util.*

class ConfirmDialog(context: Context, theme: Int) : Dialog(context, theme) {

    interface OnClickListener{
        fun onClick(isYes: Boolean)
    }

    companion object {
        fun create(context: Context, onClickListener: OnClickListener): ConfirmDialog {
            val dialog = ConfirmDialog(context, R.style.DialogTheme)

            val binding = DialogConfirmBinding.inflate(LayoutInflater.from(context))
            val view = binding.root
            dialog.setContentView(view)
//
//            binding.tvYes.setOnClickListener{
//                onClickListener.onClick(true)
//            }
//
//            binding.tvNo.setOnClickListener{
//                onClickListener.onClick(false)
//            }

            dialog.setCancelable(false)
            Objects.requireNonNull<Window>(dialog.getWindow()).setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.show()

            return dialog
        }
    }
}