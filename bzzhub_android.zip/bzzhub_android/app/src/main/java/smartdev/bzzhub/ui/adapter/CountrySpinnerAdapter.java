package smartdev.bzzhub.ui.adapter;

import android.widget.ArrayAdapter;

public class CountrySpinnerAdapter  {
}
