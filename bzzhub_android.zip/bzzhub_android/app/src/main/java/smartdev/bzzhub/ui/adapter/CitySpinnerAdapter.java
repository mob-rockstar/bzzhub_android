package smartdev.bzzhub.ui.adapter;

public class CitySpinnerAdapter {
}
