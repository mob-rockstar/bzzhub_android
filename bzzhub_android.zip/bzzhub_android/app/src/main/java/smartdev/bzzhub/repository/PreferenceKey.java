package smartdev.bzzhub.repository;

public interface PreferenceKey {
    String ARG_COMPANY_PROFILE = "company_profile";
    String ARG_USER_PROFILE = "user_profile";
    String ARG_FIREBASE_TOKEN = "fcm_token";
    String ARG_ALREADY_MEMBER = "already_member";
    String ARG_USER_LANGUAGE = "user_language";
}
