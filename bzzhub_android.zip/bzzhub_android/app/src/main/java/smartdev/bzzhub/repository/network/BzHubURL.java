package smartdev.bzzhub.repository.network;

public interface BzHubURL {
    String BASE_URL = "http://bzzhub.com/bzzhub_backend/api/";

 }
