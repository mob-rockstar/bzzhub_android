package smartdev.bzzhub.ui.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import smartdev.bzzhub.R

class GroupDetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_group_detail)
    }
}
