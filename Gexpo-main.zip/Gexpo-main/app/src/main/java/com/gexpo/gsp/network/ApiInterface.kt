package com.gexpo.gsp.network

import com.gexpo.gsp.data.model.Product.ProductListResponse
import com.gexpo.gsp.data.model.base.BaseResponse
import com.gexpo.gsp.data.model.history.OrderHistoryResponse
import com.gexpo.gsp.data.model.notification.NotificationsResponse
import com.gexpo.gsp.data.model.order.OrderResponse
import com.gexpo.gsp.data.model.login.LoginResponse
import com.gexpo.gsp.data.model.order.SellOrderResponse
import com.gexpo.gsp.data.model.refund.RefundResponse
import io.reactivex.Single
import okhttp3.OkHttpClient
import okhttp3.RequestBody
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path

interface ApiInterface {

    @FormUrlEncoded
    @POST("auth/email/login")
    fun getLogin(
        @Field("email") email: String?,
        @Field("password") pass: String?
    ): Single<LoginResponse>

    @GET("products/list")
    fun getProducts(
        @Header("Authorization") authToken : String
    ): Single<ProductListResponse>

    @POST("favorites/add/{id}")
    fun addToFav(
        @Path("id") id: String,
        @Header("Authorization") authToken : String
    ): Single<ProductListResponse>

    @DELETE("favorites/remove/{id}")
    fun removeFromFav(
        @Path("id") id: String,
        @Header("Authorization") authToken : String
    ): Single<ProductListResponse>

    @GET("favorites")
    fun getFavorites(
        @Header("Authorization") authToken : String
    ): Single<ProductListResponse>

    @GET("notifications/list")
    fun getNotifications(
        @Header("Authorization") authToken : String
    ): Single<NotificationsResponse>

    @POST("orders/sell")
    fun sellOrder(
        @Body products: RequestBody?,
        @Header("Authorization") authToken : String
    ): Single<SellOrderResponse>

    @POST("orders/create")
    fun createOrder(
        @Body products: RequestBody?,
        @Header("Authorization") authToken : String
    ): Single<SellOrderResponse>

    @GET("retailers/order-history")
    fun getOrders(
        @Header("Authorization") authToken : String
    ): Single<OrderHistoryResponse>

    @POST("orders/refund")
    fun refundOrder(
        @Body order: RequestBody?,
        @Header("Authorization") authToken : String
    ): Single<RefundResponse>

    @POST("retailer/check")
    fun checkRetailerId(
        @Body order: RequestBody?,
        @Header("Authorization") authToken : String
    ): Single<BaseResponse>

    companion object {
        var BASE_URL = "http://167.71.214.193/api/"

        fun create(accessToken: String): ApiInterface {
            val client = OkHttpClient.Builder()
//                .addInterceptor(ApiClient.OAuthInterceptor("Bearer", accessToken))
                .build()

            val retrofit = Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl(BASE_URL)
                .client(client)
                .build()
            return retrofit.create(ApiInterface::class.java)

        }

    }
}