package com.gexpo.gsp.ui.main

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.gexpo.gsp.R
import com.gexpo.gsp.base.BaseRecyclerViewAdapter
import com.gexpo.gsp.data.local.PreferenceManager
import com.gexpo.gsp.data.model.Product.ProductListResponse
import com.gexpo.gsp.databinding.RecyclerItemProductMainBinding
import com.gexpo.gsp.util.GlideApp
import java.text.DecimalFormat
import java.util.Locale

class ProductAdapter (val context: Context, var list: ArrayList<ProductListResponse.ActiveProducts>,
                      val onProductClick :(product : ProductListResponse.ActiveProducts, isFav : Boolean) -> Unit,
                      val onFavClick :(index : Int, isFav : Boolean) -> Unit): BaseRecyclerViewAdapter<String, RecyclerItemProductMainBinding> (){
    override val layoutId: Int
        get() = R.layout.recycler_item_product_main

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return ProductViewHolder(createBindView(viewGroup))
    }

    @SuppressLint("CheckResult")
    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder: ProductViewHolder = viewHolder as ProductViewHolder

        var isLike = false
        val formattedPrice = formatPrice(list[position].price)

        holder.binding.tvProductName.text =  (if (PreferenceManager.userLanguage == 1) list[position].englishName.toString() else list[position].arabicName.toString())
//        holder.binding.tvProductName.text =  list[position].arabicName.toString()
        holder.binding.tvBarCode.text =  list[position].code.toString()
        holder.binding.tvPrice.text =  String.format(Locale.US, "SAR %.2f", list[position].price ?: 0.0)

        // Product image
        if (list[position].photo != null) {
            Log.d("Product Detail", "Product image : " + list[position].photo)
            GlideApp.with(context).load(list[position].photo).error(R.drawable.ic_product_default).into(holder.binding.ivProduct)
        }

        holder.binding.apply {
            layoutLike.setOnClickListener {
                ivLike.setImageDrawable(
                    ContextCompat.getDrawable(
                        context,
                        if (isLike) R.drawable.ic_heart else R.drawable.ic_heart_fill
                    )
                )
                isLike = !isLike
                onFavClick(list[position].id!!,isLike)
            }

            // Item click listener
            layoutContent.setOnClickListener {
                onProductClick(list[position], isLike)
            }
        }
    }
    fun filterList(filteredList: ArrayList<ProductListResponse.ActiveProducts>) {
        list = filteredList
        notifyDataSetChanged()
    }
    private fun formatPrice(price: Double?): String {
        val decimalFormat = DecimalFormat("0.00")
        return decimalFormat.format(price ?: 0)
    }
    override fun getItemCount(): Int {
        //return super.getItemCount()
//        return 20
        return list.size
    }

    inner class ProductViewHolder (val binding: RecyclerItemProductMainBinding):
            RecyclerView.ViewHolder(binding.root)


}