package com.gexpo.gsp.data.model.order

import com.google.gson.annotations.SerializedName
import com.gexpo.gsp.data.model.base.BaseResponse

class SellOrderResponse : BaseResponse() {
    @field:SerializedName("data")
    var orderData: SellOrderData? = null
}