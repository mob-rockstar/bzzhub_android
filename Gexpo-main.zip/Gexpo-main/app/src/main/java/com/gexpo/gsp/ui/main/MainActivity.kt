package com.gexpo.gsp.ui.main


import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import androidx.recyclerview.widget.GridLayoutManager
import com.gexpo.gsp.R
import com.gexpo.gsp.base.BaseActivity
import com.gexpo.gsp.data.local.PreferenceManager
import com.gexpo.gsp.data.model.Product.ProductListResponse
import com.gexpo.gsp.data.model.base.ErrorResponse
import com.gexpo.gsp.data.viewModel.HomeViewModel.HomeViewModel
import com.gexpo.gsp.data.viewModel.favoritesViewModel.FavoritesViewModel
import com.gexpo.gsp.databinding.ActivityMainBinding
import com.gexpo.gsp.network.ApiInterface
import com.gexpo.gsp.network.HandleResponse
import com.gexpo.gsp.ui.cart.CartActivity
import com.gexpo.gsp.ui.component.dialog.LanguageListDialog
import com.gexpo.gsp.ui.component.dialog.ProductDetailDialog
import com.gexpo.gsp.ui.component.easyImage.DefaultCallback
import com.gexpo.gsp.ui.component.easyImage.EasyImage
import com.gexpo.gsp.ui.component.easyImage.MediaFile
import com.gexpo.gsp.ui.component.easyImage.MediaSource
import com.gexpo.gsp.ui.favorite.FavoriteActivity
import com.gexpo.gsp.ui.notifications.NotificationsActivity
import com.gexpo.gsp.ui.orders.OrderActivity
import com.gexpo.gsp.ui.signin.LoginActivity
import com.gexpo.gsp.util.GlideApp
import com.gexpo.gsp.util.KeyboardUtils
import com.gexpo.gsp.util.PrintHelper
import com.permissionx.guolindev.PermissionX
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import io.nearpay.sdk.data.models.ReconciliationReceipt
import io.nearpay.sdk.utils.enums.ReconcileFailure
import io.nearpay.sdk.utils.enums.SetupFailure
import io.nearpay.sdk.utils.enums.StatusCheckError
import io.nearpay.sdk.utils.listeners.BitmapListener
import io.nearpay.sdk.utils.listeners.ReconcileListener
import io.nearpay.sdk.utils.listeners.SetupListener
import io.nearpay.sdk.utils.toImage
import io.nearpay.sdk.utils.toJson
import java.io.File
import java.util.*
import javax.inject.Inject

class MainActivity : BaseActivity<ActivityMainBinding, HomeViewModel>(), HasAndroidInjector{

    override val layoutId: Int
        get() = R.layout.activity_main


    override val viewModel: HomeViewModel
        get() {
            return getViewModel(HomeViewModel::class.java)
        }

    var favoriteViewModel:FavoritesViewModel = FavoritesViewModel()

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector
    private lateinit var toggle: ActionBarDrawerToggle
    var viewModel1: com.gexpo.gsp.realmDB.MainViewModel? = null
    private var cartCount = 0
    var products: ArrayList<ProductListResponse.ActiveProducts> = ArrayList()

    //    private lateinit var productAdapter
    lateinit var productAdapter: ProductAdapter

    private lateinit var easyImage: EasyImage
    private var file: File? = null
    lateinit var apiInterface: ApiInterface
    private var strSearchKeyword = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel1 = com.gexpo.gsp.realmDB.MainViewModel()
        easyImage = EasyImage.Builder(this@MainActivity)
            .setCopyImagesToPublicGalleryFolder(false)
            .allowMultiple(false).build()




        initUI()
    }

    private fun initUI() {
        cartCount = viewModel1!!.getProductCart()!!.size

        initToggleButton()
        initToolbar()
        initDrawerEvents()
        // Get the product list
        getProducts()
        onSearchKeyword()
        val filter2 = IntentFilter("cartAdded")
        registerReceiver(myBroadcastReceiver, filter2)
    }

    val myBroadcastReceiver: BroadcastReceiver = object : BroadcastReceiver(){
        override fun onReceive(context: Context?, intent: Intent?){
            cartCount = viewModel1!!.getProductCart()!!.size
            setCartCount()
        }
    }

    override fun onResume() {
        cartCount = viewModel1!!.getProductCart()!!.size
        setCartCount()
        super.onResume()
    }

    private fun getProducts() {
        viewDataBinding!!.progressBar.progressBar.visibility = View.VISIBLE
        window.setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
        viewModel.getProducts(object : HandleResponse<ProductListResponse> {
            override fun handleSuccessResponse(response: ProductListResponse) {
                viewDataBinding!!.progressBar.progressBar.visibility = View.GONE
                window.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
                if (response.status == true) {
                    products.addAll(response.data)
                    initRecyclerView()
                } else {
                    Toast.makeText(this@MainActivity, response.message.toString(), Toast.LENGTH_SHORT).show()
                }
                Log.d("TAG", "handleSuccessResponse: "+response.message.toString())
            }

            override fun handleErrorResponse(error: ErrorResponse) {
                viewDataBinding!!.progressBar.progressBar.visibility = View.GONE
                window.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
                Log.d("TAG", "handleErrorResponse: "+error.message.toString())
                Toast.makeText(this@MainActivity, error.message.toString() + "", Toast.LENGTH_SHORT).show()
            }
        })
    }


    private fun addToFavorite(productId: Int, isFav: Boolean) {
        if (isFav){
            favoriteViewModel.addToFavorite(productId.toString(),object : HandleResponse<ProductListResponse> {

                override fun handleSuccessResponse(response: ProductListResponse) {
                    if (response.status == true) {
                        Toast.makeText(this@MainActivity, response.message.toString(), Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@MainActivity, response.message.toString(), Toast.LENGTH_SHORT).show()
                    }
                }

                override fun handleErrorResponse(error: ErrorResponse) {
                    Log.d("TAG", "handleErrorResponse: "+error.message.toString())
                    Toast.makeText(this@MainActivity, error.message.toString() + "", Toast.LENGTH_SHORT).show()
                }
            })
        }
        else{
            favoriteViewModel.removeFromFav(productId.toString(),object : HandleResponse<ProductListResponse> {

                override fun handleSuccessResponse(response: ProductListResponse) {
                    if (response.status == true) {
                        Toast.makeText(this@MainActivity, response.message.toString(), Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@MainActivity, response.message.toString(), Toast.LENGTH_SHORT).show()
                    }
                }

                override fun handleErrorResponse(error: ErrorResponse) {
                    Log.d("TAG", "handleErrorResponse: "+error.message.toString())
                    Toast.makeText(this@MainActivity, error.message.toString() + "", Toast.LENGTH_SHORT).show()
                }
            })
        }
    }

    private fun initToolbar() {
        viewDataBinding?.toolbar?.apply {

            layoutContent.setOnClickListener {
                KeyboardUtils.hideKeyboard(this@MainActivity)
            }

            ivMenu.setOnClickListener {
                KeyboardUtils.hideKeyboard(this@MainActivity)
                openDrawer()
            }

            layoutMenu.setOnClickListener {
                KeyboardUtils.hideKeyboard(this@MainActivity)
                openDrawer()
            }

            layoutCart.setOnClickListener {
                KeyboardUtils.hideKeyboard(this@MainActivity)
                openCartActivity()
            }

            ivCart.setOnClickListener {
                KeyboardUtils.hideKeyboard(this@MainActivity)
                openCartActivity()
            }

            setCartCount()
        }
    }

    private fun initDrawerEvents() {
        viewDataBinding?.drawerHeader?.apply {

            toolbar.apply {
                ivBack.setOnClickListener {
                    closeDrawer()
                }

                tvTitle.text = this@MainActivity.resources.getString(R.string.str_settings)
            }

            ivEdit.setOnClickListener {
                grantCameraPermission()
                //      openEasyImageChooser()
            }

            tvEdit.setOnClickListener {
                grantCameraPermission()
                //   openEasyImageChooser()
            }
            tvUserName.text = PreferenceManager.name
            tvEmail.text = PreferenceManager.email

        }

        viewDataBinding?.drawerBody?.apply {
            layoutProfile.setOnClickListener {
                closeDrawer()
            }

            layoutReconcile.setOnClickListener {
                closeDrawer()
                reconcile()
            }

            layoutProducts.setOnClickListener {
                closeDrawer()
                //  openProductPage()
            }

            layoutOrderHistory.setOnClickListener {
                closeDrawer()
                openOrderActivity()
            }

            layoutFavorite.setOnClickListener {
                closeDrawer()
                openFavoriteActivity()
            }

            layoutNotifications.setOnClickListener {
                closeDrawer()
                openNotificationsActivity()
            }

            layoutTalkToUs.setOnClickListener {
                closeDrawer()
            }

            layoutLanguage.setOnClickListener {
                LanguageListDialog.openDialog(this@MainActivity) {
                    restartApp(this@MainActivity)
                }
            }

            layoutLogout.setOnClickListener {
                PreferenceManager.loggedInMode =
                    PreferenceManager.LoggedInMode.LOGGED_IN_MODE_LOGGED_OUT
                logout()
            }
        }
    }

    // Reconcile
    private fun reconcile(){
        if (nearPay == null)
            initNearPayInstance()

        nearPay!!.setup(object : SetupListener {
            override fun onSetupCompleted() {
                // if you wish to get the receipt in Json format use nearPay.toJson()
                PreferenceManager.isInitiatedNearPay = true
                startReconcile()
            }
            override fun onSetupFailed(setupFailure: SetupFailure) {
                when (setupFailure) {
                    is SetupFailure.AlreadyInstalled -> {
                        // when the payment plugin is already installed.
                        showPaymentErrorMessage("Payment plugin is already installed!")
                        PreferenceManager.isInitiatedNearPay = true
                        startReconcile()
                    }
                    is SetupFailure.NotInstalled -> {
                        // when the installation failed.
                        showPaymentErrorMessage("Plugin installation failed!")
                    }
                    is SetupFailure.AuthenticationFailed -> {
                        // when the authentication failed.
                        // You can use the following method to update your JWT
                        showPaymentErrorMessage("Authentication failed!")
                    }
                    is SetupFailure.InvalidStatus -> {
                        // Please note that you can get the status using setupFailure.status
                        // you can get the status using the following code
                        val status: List<StatusCheckError> = (setupFailure as SetupFailure.InvalidStatus).status
                        var errMsg = ""
                        for (statusCheckError in status) {
                            errMsg = errMsg + statusCheckError.toString() + "\n"
                        }

                        val finalErrMsg = errMsg
                        showPaymentErrorMessage("Invalid status : $finalErrMsg")
                    }
                }
            }
        })
    }

    private fun startReconcile(){
        val enableReceiptUi = true //[optional] true will enable the ui and false will disable.
        val finishTimeOut : Long = 15 //[optional] Add the number of seconds.
        val enableUiDismiss = true // [optional] it will allow you to control dismissing the UI
        val adminPin = "0000"; //[optional] when you add the admin pin here , the UI for admin pin won't be shown.
        val transactionId = UUID.randomUUID(); // [optional] You can add your UUID here which allows you to ask about the transaction again using the same UUID

        nearPay!!.reconcile(null, enableReceiptUi, adminPin, finishTimeOut, enableUiDismiss, object :
            ReconcileListener {
            override fun onReconcileFinished(receipt: ReconciliationReceipt?) {
                // you can use the object to get the reconciliationReceipt data .
                // if you wish to get the receipt in Json format use nearPay.toJson()
                showPaymentErrorMessage("Reconciled successfully!")
                if (receipt != null) {
                    receipt.toImage(this@MainActivity, 300, 24, BitmapListener {
                        PrintHelper.printReceiptBitmap(this@MainActivity, it)
                    })
                }
            }
            override fun onReconcileFailed(reconcileFailure: ReconcileFailure) {
                when (reconcileFailure) {
                    is ReconcileFailure.FailureMessage -> {
                        // when there is FailureMessage
                        showPaymentErrorMessage(reconcileFailure.message)
                    }
                    is ReconcileFailure.AuthenticationFailed -> {
                        // when the Authentication is failed
                        // You can use the following method to update your JWT
                        showPaymentErrorMessage("Authentication is failed")
                    }
                    is ReconcileFailure.InvalidStatus -> {
                        // you can get the status using reconcileFailure.status
                        val status: List<StatusCheckError> = (reconcileFailure as ReconcileFailure.InvalidStatus).status
                        var errorMsg = ""
                        for (statusCheckError in status) {
                            errorMsg = "${errorMsg}${statusCheckError.toString()}}"
                        }
                        showPaymentErrorMessage("Invalid status : $errorMsg")
                    }
                    is ReconcileFailure.GeneralFailure -> {
                        // when there is unexpected error .
                        showPaymentErrorMessage("Unexpected error")
                    }
                }
            }
        })
    }

    private fun openEasyImageChooser() {
        easyImage.openChooser(this@MainActivity)
    }

    private fun initToggleButton() {
        viewDataBinding?.apply {
            toggle = object : ActionBarDrawerToggle(
                this@MainActivity,
                drawerLayout,
                R.string.str_nav_bar_open,
                R.string.str_nav_bar_close
            ) {
                override fun onDrawerOpened(drawerView: View) {
                    super.onDrawerOpened(drawerView)
                }

                override fun onDrawerClosed(drawerView: View) {
                    super.onDrawerClosed(drawerView)
                }

                override fun onDrawerSlide(drawerView: View, slideOffset: Float) {
                    super.onDrawerSlide(drawerView, slideOffset)
                }
            }

            drawerLayout.apply {
                addDrawerListener(toggle)
                setScrimColor(
                    ContextCompat.getColor(
                        this@MainActivity,
                        android.R.color.transparent
                    )
                )
            }
        }
    }

    private fun initRecyclerView() {
        viewDataBinding?.recyclerView?.apply {
            layoutManager = GridLayoutManager(this@MainActivity, 2)
            isNestedScrollingEnabled = false
            setHasFixedSize(true)
//            productAdapter = adapter
            productAdapter =
                ProductAdapter(
                    this@MainActivity,
                    products,
                    onProductClick = {product, isFav-> openProductPage(product, isFav) },
                    onFavClick = { index, isFav -> addToFavorite(index, isFav) })

            adapter = productAdapter
        }
    }

    private fun openDrawer() {
        viewDataBinding?.drawerLayout?.openDrawer(GravityCompat.START, true)
    }

    private fun closeDrawer() {
        viewDataBinding?.drawerLayout?.closeDrawer(GravityCompat.START, true)
    }

    private fun isDrawerOpened(): Boolean {
        return viewDataBinding?.drawerLayout?.isDrawerOpen(GravityCompat.START) ?: false
    }

    override fun onBackPressed() {
        if (isDrawerOpened()) closeDrawer()
    }

    private fun openCartActivity() {
        val intent = Intent(this@MainActivity, CartActivity::class.java)
        startActivity(intent)
    }

    private fun openProfileActivity() {

    }

    private fun openProductPage(product: ProductListResponse.ActiveProducts, isFav: Boolean) {
        ProductDetailDialog.openDialog(this@MainActivity, product, isFav)

    }

    private fun openFavoriteActivity() {
        val intent = Intent(this@MainActivity, FavoriteActivity::class.java)
        startActivity(intent)
    }

    private fun openNotificationsActivity() {
        val intent = Intent(this@MainActivity, NotificationsActivity::class.java)
        startActivity(intent)
    }

    private fun openTalkToUs() {

    }

    private fun openLanguageSettings() {

    }

    private fun openOrderActivity() {
        val intent = Intent(this@MainActivity, OrderActivity::class.java)
        startActivity(intent)
    }

    private fun logout() {
        val intent = Intent(this@MainActivity, LoginActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun setCartCount() {
        viewDataBinding?.toolbar?.tvCartCount?.apply {
            //visibility = if (cartCount == 0) GONE else VISIBLE
            text = cartCount.toString()
        }
    }
    private fun filter(text: String) {
        val filteredList: ArrayList<ProductListResponse.ActiveProducts> = ArrayList()
        for (item in products) {
            if (PreferenceManager.userLanguage == 1){
                if (item.englishName.toLowerCase().contains(text.lowercase(Locale.getDefault()))
                    || item.englishName.toLowerCase().contains(text.lowercase(Locale.getDefault())))
                {
                    filteredList.add(item)
                }
            }else{
                if (item.arabicName.toLowerCase().contains(text.lowercase(Locale.getDefault()))
                    || item.arabicName.toLowerCase().contains(text.lowercase(Locale.getDefault())))
                {
                    filteredList.add(item)
                }
            }

            productAdapter.filterList(filteredList)
        }
    }
    private fun onSearchKeyword() {
        viewDataBinding?.searchBar?.edittextSearch?.apply {
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

                }

                override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                    Log.d("TAG", "onTextChanged: "+p0.toString())
                    filter(p0.toString())
                }

                override fun afterTextChanged(p0: Editable?) {
                }

            })
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        easyImage.handleActivityResult(requestCode, resultCode, data, this@MainActivity,
            object : DefaultCallback() {
                override fun onMediaFilesPicked(imageFiles: Array<MediaFile>, source: MediaSource) {
                    file = imageFiles.first().file
                    if (file?.length()!! / 1024 / 1024 > 4) {

                    } else {
                        GlideApp.with(this@MainActivity)
                            .load(file?.absolutePath)
                            .fitCenter()
                            .placeholder(R.drawable.ic_profile_default)
                            .error(R.drawable.ic_profile_default)
                            .into(viewDataBinding?.drawerHeader?.ivProfile!!)
                    }
                }
            })
    }

    private fun grantCameraPermission() {
        PermissionX.init(this@MainActivity)
            .permissions(
                Manifest.permission.CAMERA,
            )
            .request { allGranted, _, deniedList ->

                //    downloadFile(defaultThemeId, AppConstants.FILE_TYPE_IMAGE)
                if (allGranted) {
                    openEasyImageChooser()
                } else {
                    Toast.makeText(
                        this,
                        "These permissions are denied: $deniedList",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
    }


}