package com.gexpo.gsp.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.util.Log
import com.gexpo.gsp.R
import com.gexpo.gsp.data.local.PreferenceManager
import com.gexpo.gsp.data.model.history.OrderHistoryData
import com.gexpo.gsp.data.model.history.OrderItem
import com.gexpo.gsp.data.model.order.SellOrderData
import com.gexpo.gsp.realmDB.CartDatabase
import java.util.Locale

object PrintHelper {

    private const val error_level = 1 // "纠错级别L (7%)", "纠错级别M (15%)", "纠错级别Q (25%)", "纠错级别H (30%)"

    private const val print_size = 6 // 1 - 12

    private const val regularFont   = "Cairo-Regular.ttf"
    private const val boldFont      = "Cairo-Bold.ttf"

    // Print the receipt bitmap
    fun printNearPayReceipt(context: Context, receiptBmp:Bitmap, orderData : SellOrderData, cartItems: List<CartDatabase>){
        Log.d("PrintHelper", "Printing receipt...")

        // Print the qrcode
        printQrCode(context, orderData, cartItems)

        // Print the receipt invoice
        SunmiPrintHelper.getInstance().feedPaper()
        SunmiPrintHelper.getInstance().setAlign(1)
        SunmiPrintHelper.getInstance().printBitmap(receiptBmp)
        SunmiPrintHelper.getInstance().feedPaper()
    }

    fun printNearPayReceipt(context: Context, receiptBmp:Bitmap, orderData : SellOrderData, items: ArrayList<OrderItem>){
        Log.d("PrintHelper", "Printing receipt...")

        // Print the qrcode
        printInvoice(context,
            orderData.id,
            orderData.retailerId,
            orderData.updatedAt,
            orderData.total,
            orderData.vat,
            orderData.totalWithVat,
            orderData.qrCode,
            items,
            null,
            orderData.discount,
            orderData.discountType)

        // Print the receipt invoice
        SunmiPrintHelper.getInstance().feedPaper()
        SunmiPrintHelper.getInstance().setAlign(1)
        SunmiPrintHelper.getInstance().printBitmap(receiptBmp)
        SunmiPrintHelper.getInstance().feedPaper()
    }

    fun printNearPayReceipt(context: Context, receiptBmp:Bitmap?, orderHistoryData: OrderHistoryData){
        // Print the Transaction info and Qrcode
//        printInvoice(context, orderHistoryData.updatedAt, orderHistoryData.tcn, orderHistoryData.total, orderHistoryData.vat, orderHistoryData.totalWithVat, orderHistoryData.qrCode)

        // Title
        val textData = StringBuilder()
        SunmiPrintHelper.getInstance().setAlign(1)
        textData.append(context.resources.getString(R.string.app_name))
        SunmiPrintHelper.getInstance().printText(
            textData.toString(),
            50F,
            true,
            boldFont
        )
        textData.delete(0, textData.length)
        SunmiPrintHelper.getInstance().feedPaper()

        // Print the receipt
        if (receiptBmp != null) {
            SunmiPrintHelper.getInstance().setAlign(1)
            SunmiPrintHelper.getInstance().printBitmap(receiptBmp)
            SunmiPrintHelper.getInstance().feedPaper()
        }
    }


    fun printReceiptBitmap(context: Context, receiptBmp:Bitmap?){
        // Title
        val textData = StringBuilder()
        SunmiPrintHelper.getInstance().setAlign(1)
        textData.append(context.resources.getString(R.string.app_name))
        SunmiPrintHelper.getInstance().printText(
            textData.toString(),
            50F,
            true,
            boldFont
        )
        textData.delete(0, textData.length)
        SunmiPrintHelper.getInstance().feedPaper()

        // Print the receipt
        if (receiptBmp != null) {
            SunmiPrintHelper.getInstance().setAlign(1)
            SunmiPrintHelper.getInstance().printBitmap(receiptBmp)
            SunmiPrintHelper.getInstance().feedPaper()
        }
    }

    // Print the invoice from order history
    fun printOrderHistoryInvoice(context: Context, order : OrderHistoryData){
        printInvoice(context,
            order.id,
            order.retailerId,
            order.updatedAt,
            order.total,
            order.vat,
            order.totalWithVat,
            order.qrCode,
            order.orderItems,
            null,
            order.discount,
            order.discountType)
    }

    // Print Qrcode
    fun printInvoice(context: Context,
                     id : Int,
                     retailerId: Int,
                     date : String,
                     total : Double,
                     vat : Double,
                     totalAfterVat : Double,
                     qrcode : String,
                     items:ArrayList<OrderItem>? = null,
                     cartItems : List<CartDatabase>? = null,
                     discount : Double? = null,
                     discountType : String? = null){

        val textData = StringBuilder()

        // Get product table
        var productList : ArrayList<TableItem> = arrayListOf()
        if (!items.isNullOrEmpty()){
            for (item in items){
                var table = TableItem()

                var title = ""
                if (item.product != null){
                    title = if (PreferenceManager.userLanguage == 1) item.product!!.englishName ?: "" else item.product!!.arabicName ?: ""
                }

                table.text[0] = title
                table.text[1] = item.quantity.toString()
                table.text[2] = String.format(Locale.US, "%.2f", item.sellingPrice)

                productList.add(table)
            }
        }

        // Get product table from cart list
        var cartProducts : ArrayList<TableItem> = arrayListOf()
        if (!cartItems.isNullOrEmpty()){
            for (item in cartItems){
                var table = TableItem()
                table.text[0] = if (PreferenceManager.userLanguage == 1) item.productName ?: "" else item.arabicName ?: ""
                table.text[1] = (item.quantity ?: 1).toString()
                table.text[2] = String.format(Locale.US, "%.2f", (item.quantity ?: 1).toDouble() * (item.price ?: 0.0))

                productList.add(table)
            }
        }

        SunmiPrintHelper.getInstance().setAlign(1)
        textData.append(context.resources.getString(R.string.app_name))
        SunmiPrintHelper.getInstance().printText(
            textData.toString(),
            50F,
            true,
            boldFont
        )
        textData.delete(0, textData.length)

        textData.append("\n\n${context.resources.getString(R.string.str_invoice_description_en)}")
        textData.append("\n${context.resources.getString(R.string.str_invoice_description_ar)}")
        SunmiPrintHelper.getInstance().printText(
            textData.toString(),
            28F,
            true,
            boldFont
        )
        textData.delete(0, textData.length)
        SunmiPrintHelper.getInstance().feedPaper()

        SunmiPrintHelper.getInstance().setAlign(0)
        textData.append("${context.resources.getString(R.string.str_site_name)}\n")
        textData.append("${context.resources.getString(R.string.str_vat_number)}\n")
        textData.append("${context.resources.getString(R.string.str_invoice_no)} $id\n")
        textData.append("${context.resources.getString(R.string.str_retailer_id)} $retailerId\n")
        textData.append("${context.resources.getString(R.string.str_date)} $date\n")
        textData.append("${context.resources.getString(R.string.str_all_prices_vat)}\n")

        SunmiPrintHelper.getInstance().printText(
            textData.toString(),
            24F,
            false,
            regularFont
        )
        textData.delete(0, textData.length)

        SunmiPrintHelper.getInstance().setAlign(1)
        textData.append("\n------------------------------\n")
        SunmiPrintHelper.getInstance().printText(
            textData.toString(),
            24F,
            true,
            boldFont
        )
        textData.delete(0, textData.length)

        // Check if there are products
        if (!items.isNullOrEmpty() || !cartItems.isNullOrEmpty()){
            // Print the title of table
            val titleTable = TableItem()
            titleTable.text[0] = context.resources.getString(R.string.str_name)
            titleTable.text[1] = context.resources.getString(R.string.str_qty)
            titleTable.text[2] = context.resources.getString(R.string.str_price)
            SunmiPrintHelper.getInstance().printTable(titleTable.text, titleTable.width, titleTable.align)

            textData.append("------------------------------\n")
            SunmiPrintHelper.getInstance().printText(
                textData.toString(),
                24F,
                false,
                regularFont
            )

            // Print the products in Table
            for (tableItem in productList){
                SunmiPrintHelper.getInstance().printTable(tableItem.text, tableItem.width, tableItem.align)
            }

            for (tableItem in cartProducts) {
                SunmiPrintHelper.getInstance().printTable(tableItem.text, tableItem.width, tableItem.align)
            }

            textData.delete(0, textData.length)
            textData.append("------------------------------\n")

            SunmiPrintHelper.getInstance().printText(
                textData.toString(),
                24F,
                false,
                regularFont
            )

            textData.delete(0, textData.length)
        }

        SunmiPrintHelper.getInstance().setAlign(0)
        // Total
        val str_total_amount = String.format(Locale("en"), "%.2f", total)
        textData.append("\n${context.resources.getString(R.string.str_total_amount)}         $str_total_amount\n")

        // Discount
        if (discount != null) {
            val str_discount = String.format(Locale("en"), "%.2f", discount)
            textData.append("${context.resources.getString(R.string.discount)}             $str_discount\n")
        }

        // VAT
        val str_vat = String.format(Locale("en"), "%.2f", vat)
        textData.append("${context.resources.getString(R.string.str_vat_percent)}  $str_vat\n")

        // Total after VAT
        val str_total_with_vat = String.format(Locale("en"), "%.2f", totalAfterVat)
        textData.append("${context.resources.getString(R.string.str_total_after_vat)}      $str_total_with_vat\n")



        // Discount Type
//        if (discountType != null) {
//            textData.append("${context.resources.getString(R.string.discount_type)}        $discountType\n")
//        }
        textData.append(context.resources.getString(R.string.str_all_amount))

        SunmiPrintHelper.getInstance().printText(
            textData.toString(),
            24F,
            false,
            regularFont
        )
        textData.delete(0, textData.length)

        SunmiPrintHelper.getInstance().feedPaper()
        SunmiPrintHelper.getInstance().setAlign(1)
        SunmiPrintHelper.getInstance().printQr(
            qrcode,
            print_size,
            error_level
        )
        SunmiPrintHelper.getInstance().feedPaper()
    }

    // Print the QR code
    fun printQrCode(context: Context, orderData : SellOrderData, cartItems: List<CartDatabase>){
        Log.d("PrintHelper", "Printing qrcode...")

        printInvoice(context,
            orderData.id,
            orderData.retailerId,
            orderData.updatedAt,
            orderData.total,
            orderData.vat,
            orderData.totalWithVat,
            orderData.qrCode,
            null,
            cartItems,
            orderData.discount,
            orderData.discountType)
    }


    /**
     * Scaled image width is an integer multiple of 8 and can be ignored
     */
    private fun scaleImage(bitmap1: Bitmap, scaleX: Float, scaleY: Float): Bitmap? {
        val width = bitmap1.width
        val height = bitmap1.height

        val newWidth = (width / 8 + 1) * 8
        val scaleWidth = newWidth.toFloat() / width
        val matrix = Matrix()
        matrix.postScale(scaleX, scaleY)

        return Bitmap.createBitmap(bitmap1, 0, 0, width, height, matrix, true)
    }
}

private class TableItem {
    var text: Array<String> = arrayOf("", "", "")
    var width: IntArray
    var align: IntArray

    init {
        text = arrayOf("", "", "")
        width = intArrayOf(3, 2, 2)
        align = intArrayOf(0, 1, 2)
    }
}
