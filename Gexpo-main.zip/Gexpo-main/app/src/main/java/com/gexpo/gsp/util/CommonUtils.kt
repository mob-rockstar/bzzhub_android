package com.gexpo.gsp.util

import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.os.LocaleList
import android.widget.EditText
import android.widget.TextView
import com.gexpo.gsp.R
import java.util.Locale

object CommonUtils {
    fun validateInfo(context: Context, username: String, password: String): String {
        return if (username.isNotEmpty() && password.isNotEmpty() && password.length > 4) {
            ""
        } else if (username.isEmpty()) {
            context.resources.getString(R.string.str_enter_username)
        } else if (password.isEmpty()) {
            context.resources.getString(R.string.str_enter_password)
        } else {
            context.resources.getString(R.string.str_invalid_password)
        }
    }

    // Set App Locale
    fun setLocale(mContext: Context, lang: String?) {
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.N) {
            val locale = Locale(lang!!)
            val localeList = LocaleList(locale)
            LocaleList.setDefault(localeList)
            val config = Configuration()
            config.setLocale(locale)
            config.setLocales(localeList)
            config.setLayoutDirection(locale)
            mContext.applicationContext.createConfigurationContext(config)
            mContext.createConfigurationContext(config)
            mContext.resources.updateConfiguration(config, mContext.resources.displayMetrics)
        } else {
            val locale = Locale(lang!!)
            Locale.setDefault(locale)
            val config = mContext.resources.configuration
            config.setLocale(locale)
            config.setLayoutDirection(locale)
            mContext.applicationContext.createConfigurationContext(config)
            mContext.createConfigurationContext(config)
            mContext.resources.updateConfiguration(config, mContext.resources.displayMetrics)
        }
    }

    fun getPlusValue(tvAmount: EditText): String {
        val currentAmount = getAmountFromTextView(tvAmount)
        return (currentAmount + 1).toString()
    }

    fun getMinusValue(tvAmount: EditText): String {
        val currentAmount = getAmountFromTextView(tvAmount)

        return (if (currentAmount == 1) 1 else (currentAmount - 1)).toString()
    }


    fun getAmountFromTextView(tvAmount: EditText) : Int{
        return Integer.parseInt(tvAmount.text.toString())
    }

    fun validatePrice(context: Context, priceString: String): String{
        return if (priceString.isEmpty())
            context.resources.getString(R.string.str_empty_price)
        else if (priceString[priceString.length - 1] == '.' || priceString.toFloatOrNull()  == null)
            context.resources.getString(R.string.str_invalid_price_format)
        else ""
    }
}