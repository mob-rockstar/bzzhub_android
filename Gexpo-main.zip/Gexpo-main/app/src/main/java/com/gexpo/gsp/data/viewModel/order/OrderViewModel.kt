package com.gexpo.gsp.data.viewModel.order

import com.gexpo.gsp.base.BaseViewModel
import com.gexpo.gsp.data.model.Product.ProductListResponse
import com.gexpo.gsp.data.model.base.BaseResponse
import com.gexpo.gsp.data.model.history.OrderHistoryResponse
import com.gexpo.gsp.data.model.notification.NotificationsResponse
import com.gexpo.gsp.data.model.order.OrderResponse
import com.gexpo.gsp.data.model.order.SellOrderResponse
import com.gexpo.gsp.data.model.refund.RefundResponse
import com.gexpo.gsp.network.ApiClient
import com.gexpo.gsp.network.HandleResponse
import com.gexpo.gsp.network.NetworkUtils.getThrowableError
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import okhttp3.RequestBody

class OrderViewModel : BaseViewModel() {

    fun sellOrder(products: RequestBody?,
        handleResponse: HandleResponse<SellOrderResponse>
    ) {
        compositeDisposable.add(ApiClient.sellOrder(products)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        handleResponse.handleSuccessResponse(result)
                    }
                },
                { x ->
                    run {
                        getThrowableError(x)?.let { handleResponse.handleErrorResponse(it) }
                    }
                }
            ))
     }

    fun getOrders(handleResponse: HandleResponse<OrderHistoryResponse>) {
        compositeDisposable.add(ApiClient.getOrders()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        handleResponse.handleSuccessResponse(result)
                    }
                },
                { x ->
                    run {
                        getThrowableError(x)?.let { handleResponse.handleErrorResponse(it) }
                    }
                }
            ))
    }

    fun createOrder(products: RequestBody?,
                  handleResponse: HandleResponse<SellOrderResponse>
    ) {
        compositeDisposable.add(ApiClient.createOrder(products)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        handleResponse.handleSuccessResponse(result)
                    }
                },
                { x ->
                    run {
                        getThrowableError(x)?.let { handleResponse.handleErrorResponse(it) }
                    }
                }
            ))
    }

    fun refundOrder(body : RequestBody?, handleResponse : HandleResponse<RefundResponse>){
        compositeDisposable.add(ApiClient.refundOrder(body)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        handleResponse.handleSuccessResponse(result)
                    }
                },
                { x ->
                    run {
                        getThrowableError(x)?.let { handleResponse.handleErrorResponse(it) }
                    }
                }
            ))
    }

    fun checkRetailerId(body : RequestBody?, handleResponse: HandleResponse<BaseResponse>){
        compositeDisposable.add(ApiClient.checkRetailer(body)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        handleResponse.handleSuccessResponse(result)
                    }
                },
                { x ->
                    run {
                        getThrowableError(x)?.let { handleResponse.handleErrorResponse(it) }
                    }
                }
            ))
    }

}