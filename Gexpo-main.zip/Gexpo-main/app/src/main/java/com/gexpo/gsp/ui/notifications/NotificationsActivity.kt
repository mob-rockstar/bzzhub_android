package com.gexpo.gsp.ui.notifications

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.gexpo.gsp.R
import com.gexpo.gsp.base.BaseActivity
import com.gexpo.gsp.data.model.base.ErrorResponse
import com.gexpo.gsp.data.model.notification.NotificationsResponse
import com.gexpo.gsp.data.viewModel.NotificationViewModel.NotificationViewModel
import com.gexpo.gsp.databinding.ActivityNotificationsBinding
import com.gexpo.gsp.network.HandleResponse
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import javax.inject.Inject

class NotificationsActivity : BaseActivity<ActivityNotificationsBinding, NotificationViewModel>(), HasAndroidInjector {

    override val layoutId: Int
        get() = R.layout.activity_notifications

    override val viewModel: NotificationViewModel
        get() {
            return getViewModel(NotificationViewModel::class.java)
        }

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    var notificationList: ArrayList<NotificationsResponse.Data> = ArrayList()

    private val notificationsAdapter : NotificationsAdapter = NotificationsAdapter(
        this,
        notificationList
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        initUI()
    }

    private fun initUI(){
        initToolbar()
        callapi()
    }

    private fun initToolbar(){
        viewDataBinding?.toolbar?.apply {
            ivBack.setOnClickListener {
                finish()
            }

            tvTitle.text = this@NotificationsActivity.getString(R.string.str_notifications)
        }
    }

    private fun initRecyclerView(){
        viewDataBinding?.recyclerView?.apply {
            layoutManager = LinearLayoutManager(this@NotificationsActivity)
            isNestedScrollingEnabled = false
            setHasFixedSize(true)
//            adapter = notificationsAdapter
            adapter =
                NotificationsAdapter(
                    this@NotificationsActivity,
                    notificationList)
        }
    }

    private fun callapi(){
        viewModel.getNotifications(object :
            HandleResponse<NotificationsResponse> {

            override fun handleSuccessResponse(response: NotificationsResponse) {
                if(response.status == true){
                    notificationList.addAll(response.data)
                    initRecyclerView()

                }
                Log.d("TAG", "getNotificationsSuccessResponse: "+response.message.toString())
            }

            override fun handleErrorResponse(error: ErrorResponse) {
                Log.d("TAG", "getNotificationsErrorResponse: "+error.message.toString())
                Toast.makeText(this@NotificationsActivity, error.message.toString() + "", Toast.LENGTH_SHORT).show()
            }
        })
    }

}