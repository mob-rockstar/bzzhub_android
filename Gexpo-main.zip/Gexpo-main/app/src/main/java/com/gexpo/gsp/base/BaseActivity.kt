package com.gexpo.gsp.base

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.Toast
import androidx.annotation.IdRes
import androidx.annotation.LayoutRes
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.gexpo.gsp.R
import com.gexpo.gsp.BR
import com.gexpo.gsp.base.navigator.Navigator
import com.gexpo.gsp.data.local.PreferenceManager
import com.gexpo.gsp.di.builder.ViewModelProviderFactory
import com.gexpo.gsp.util.AppConstants
import com.gexpo.gsp.util.CommonUtils
import dagger.android.AndroidInjection
import io.nearpay.sdk.Environments
import io.nearpay.sdk.NearPay
import io.nearpay.sdk.utils.PaymentText
import io.nearpay.sdk.utils.enums.AuthenticationData
import io.nearpay.sdk.utils.enums.NetworkConfiguration
import io.nearpay.sdk.utils.enums.UIPosition
import io.reactivex.disposables.Disposable
import java.math.BigDecimal
import java.math.RoundingMode
import javax.inject.Inject


abstract class BaseActivity<T : ViewDataBinding?, V :BaseViewModel>: AppCompatActivity(), BaseFragment.Callback {

    @Inject
    lateinit var viewModelFactory: ViewModelProviderFactory

    var viewDataBinding: T? = null
        private set

    private var mViewModel: V ?= null
    abstract val viewModel: V

    private val bindingVariable : Int = BR._all

    lateinit var progressView : View

    private var disposables: ArrayList<Disposable> = ArrayList()

    @Inject
    lateinit var navigator: Navigator

    @get:LayoutRes
    abstract val layoutId: Int

    var nearPay : NearPay? = null

    protected open fun <T: ViewModel> getViewModel(modelClass: Class<T>): T{
        return ViewModelProvider(this)[modelClass]
    }

    override fun onFragmentAttached() {}
    override fun onFragmentDetached(tag: String?) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        performDependencyInjection()
        setLocale()
        super.onCreate(savedInstanceState)
        setFullScreen()
        performDataBinding()
        viewModel.isLoading.observe(this){
                isLoading -> checkIsLoading(isLoading)
        }
    }

    private fun setFullScreen(){
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        this.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)

    }

    private fun performDependencyInjection(){
        AndroidInjection.inject(this)
    }

    private fun performDataBinding(){
        viewDataBinding = DataBindingUtil.setContentView<T>(this, layoutId)
        mViewModel = if (mViewModel == null) viewModel else mViewModel
        viewDataBinding?.setVariable(bindingVariable, mViewModel)
        viewDataBinding?.executePendingBindings()
    }


    fun checkIsLoading(isLoading: Boolean){
        if (::progressView.isInitialized){
            progressView.visibility = if (isLoading) View.VISIBLE else View.GONE
        }
    }

    fun showErrorDialog(errorMessage: String) {

        val alertDialog: AlertDialog = AlertDialog.Builder(this).create()
        alertDialog.setTitle("")
        alertDialog.setMessage(errorMessage)
        alertDialog.setButton(
            AlertDialog.BUTTON_NEUTRAL, "OK"
        ) { dialog, _ -> dialog.dismiss() }
        alertDialog.show()
    }

    fun showTryAgainDialog(errorMessage: String, onTryAgain :() ->Unit) {

        val alertDialog: AlertDialog = AlertDialog.Builder(this).create()
        alertDialog.setTitle("")
        alertDialog.setCancelable(false)
        alertDialog.setMessage(errorMessage)
        alertDialog.setButton(
            AlertDialog.BUTTON_NEUTRAL, "Try again"
        ) { dialog, _ ->
            onTryAgain()
            dialog.dismiss() }
        alertDialog.show()
    }


    fun addFragment(@IdRes containerId: Int, fragment: Fragment) {
        navigator.addFragmentAndAddToBackStack(this, containerId, fragment)
    }

    fun replaceFragment(@IdRes containerId: Int, fragment: Fragment) {
        navigator.replaceFragmentAndAddToBackStack(this, containerId, fragment)
    }

    fun replaceFragmentDirectly(@IdRes containerId: Int, fragment: Fragment) {
        navigator.replaceFragmentDirectly(this, containerId, fragment)
    }

    fun popFragment() {
        navigator.popFragmentBackStackImmediate(this)
    }

    fun restartApp(activity: Activity){
        navigator.restartApp(activity)
    }

    private fun setLocale() {
        if (PreferenceManager.userLanguage == 1) {
            CommonUtils.setLocale(this, AppConstants.ENGLISH)
        } else {
            CommonUtils.setLocale(this, AppConstants.ARABIC)
        }
    }

    fun getFormattedDecimal(price : Double) : BigDecimal {
        var bd: BigDecimal = BigDecimal.valueOf(price)
        bd = bd.setScale(2, RoundingMode.DOWN)

        return bd
    }

    fun initNearPayInstance(){
        nearPay = NearPay.Builder()
            .context(this)
            .authenticationData(AuthenticationData.Jwt(PreferenceManager.paymentToken))
            .environment(Environments.PRODUCTION)
            .networkConfiguration(NetworkConfiguration.SIM_PREFERRED)
            .paymentText(PaymentText("يرجى تمرير الطاقة", "please tap your card"))
            .loadingUi(true)
            .uiPosition(UIPosition.CENTER_BOTTOM)
            .build()
    }

    fun showPaymentErrorMessage(msg : String){
        runOnUiThread {
            Toast.makeText(
                this,
                msg,
                Toast.LENGTH_LONG
            ).show()
        }
    }
}