package com.gexpo.gsp.realmDB

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import io.realm.Realm
import io.realm.RealmResults
import io.realm.kotlin.deleteFromRealm
import java.util.UUID


class MainViewModel: ViewModel()  {
    private var realm: Realm = Realm.getDefaultInstance()

//    val allNotes: LiveData<List<CartDatabase>>
//        get() = getProductCart()

     fun getProductCart(): RealmResults<CartDatabase>? {
        val list = MutableLiveData<List<CartDatabase>>()
        val notes = realm.where(CartDatabase::class.java).findAll()
//        list.value = notes?.subList(0, notes.size)
        return notes
    }

    fun addtocart(productPrice: String, productquantity: String, productImg: String,productId: String,productName: String,arabicName: String,productSubName: String, retailerId : Int) {
        realm.executeTransaction { r: Realm ->
            val cart = r.createObject(CartDatabase::class.java, UUID.randomUUID().toString())
            cart.quantity       = productquantity.toInt()
            cart.price          = productPrice.toDouble()
            cart.img            = productImg
            cart.productId      = productId
            cart.productName    = productName
            cart.arabicName     = arabicName
            cart.productSubName = productSubName
            cart.retailerId     = retailerId
            realm.insertOrUpdate(cart)
        }
    }

    fun updateProductCart(id : String, quantity: String) {
        val target = realm.where(CartDatabase::class.java)
            .equalTo("id",id )
            .findFirst()

        realm.executeTransaction {

            target?.quantity = quantity.toInt()

            realm.insertOrUpdate(target)
        }
    }

    fun updateProductPrice(id : String,price: String) {
        val target = realm.where(CartDatabase::class.java)
            .equalTo("id",id )
            .findFirst()

        realm.executeTransaction {

            target?.price = price.toDouble()

            realm.insertOrUpdate(target)
        }
    }

    fun deleteNote(id: String) {
        var realm: Realm? = null
        try {
            realm = Realm.getDefaultInstance()
            realm.executeTransaction { realm ->
                val result: CartDatabase? =
                    realm.where(CartDatabase::class.java).equalTo("id", id).findFirst()
                result!!.deleteFromRealm()
            }
        }finally {
            if(realm != null) {
                realm.close()
            }
        }
    }


    fun getFinalCartItems(): List<CartDatabase> {
        val list: MutableList<CartDatabase> = ArrayList<CartDatabase>()

        try {
            realm = Realm.getDefaultInstance()
            val results: RealmResults<CartDatabase> = realm
                .where(CartDatabase::class.java)
                .findAll()
            list.addAll(realm.copyFromRealm(results))
        } finally {
            realm.close()
        }
        return list
    }

    fun deleteAllItemsFromCart() {
        realm.executeTransaction { r: Realm ->
            r.delete(CartDatabase::class.java)
        }
    }
}