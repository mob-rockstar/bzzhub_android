package com.gexpo.gsp.data.viewModel.LoginViewModel

import com.gexpo.gsp.base.BaseViewModel
import com.gexpo.gsp.data.model.login.LoginResponse
import com.gexpo.gsp.network.ApiClient
import com.gexpo.gsp.network.HandleResponse
import com.gexpo.gsp.network.NetworkUtils.getThrowableError
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class LoginViewModel : BaseViewModel() {

    fun loginWithPassword(
        email: String, password: String,
        handleResponse: HandleResponse<LoginResponse>
    ) {
//        setIsLoading(true)
        compositeDisposable.add(ApiClient.loginWithPassword(email, password)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
//                        setIsLoading(false)
                        handleResponse.handleSuccessResponse(result)
                    }
                },
                { x ->
                    run {
//                        setIsLoading(false)
                        getThrowableError(x)?.let { handleResponse.handleErrorResponse(it) }
                    }
                }
            ))
    }

}