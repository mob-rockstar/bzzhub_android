package com.gexpo.gsp.data.viewModel.NotificationViewModel

import com.gexpo.gsp.base.BaseViewModel
import com.gexpo.gsp.data.model.notification.NotificationsResponse
import com.gexpo.gsp.network.ApiClient
import com.gexpo.gsp.network.HandleResponse
import com.gexpo.gsp.network.NetworkUtils.getThrowableError
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class NotificationViewModel : BaseViewModel() {

    fun getNotifications(
        handleResponse: HandleResponse<NotificationsResponse>
    ) {
        compositeDisposable.add(ApiClient.getNotifications()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        handleResponse.handleSuccessResponse(result)
                    }
                },
                { x ->
                    run {
                        getThrowableError(x)?.let { handleResponse.handleErrorResponse(it) }
                    }
                }
            ))
    }

}