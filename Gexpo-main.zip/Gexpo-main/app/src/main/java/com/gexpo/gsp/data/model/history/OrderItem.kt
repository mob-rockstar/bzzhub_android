package com.gexpo.gsp.data.model.history

import com.gexpo.gsp.data.model.login.LoginResponse
import com.google.gson.annotations.SerializedName

class OrderItem {
    @field:SerializedName("id")
    var id: Int = 0

    @field:SerializedName("order_id")
    var orderId: Int = 0

    @field:SerializedName("product_id")
    var productId: Int? = null

    @field:SerializedName("selling_price")
    var sellingPrice : Double = 0.0

    @field:SerializedName("quantity")
    var quantity: Int = 0

    @field:SerializedName("deleted_at")
    var deletedAt: String? = null

    @field:SerializedName("updated_at")
    var updatedAt: String = ""

    @field:SerializedName("created_at")
    var createdAt: String = ""

    @field:SerializedName("product")
    var product: LoginResponse.ActiveProducts? = null
}