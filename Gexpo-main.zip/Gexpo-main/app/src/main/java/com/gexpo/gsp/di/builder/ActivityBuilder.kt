package com.gexpo.gsp.di.builder

import com.gexpo.gsp.ui.cart.CartActivity
import com.gexpo.gsp.ui.favorite.FavoriteActivity
import com.gexpo.gsp.ui.main.MainActivity
import com.gexpo.gsp.ui.notifications.NotificationsActivity
import com.gexpo.gsp.ui.orders.OrderActivity
import com.gexpo.gsp.ui.signin.LoginActivity
import com.gexpo.gsp.ui.splash.SplashActivity
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
interface ActivityBuilder {

    @ContributesAndroidInjector
    fun buildSplashActivity(): SplashActivity

    @ContributesAndroidInjector
    fun buildMainActivity(): MainActivity

    @ContributesAndroidInjector
    fun buildLoginActivity(): LoginActivity
    
    @ContributesAndroidInjector
    fun buildCartActivity() : CartActivity
    
    @ContributesAndroidInjector
    fun buildFavoriteActivity() :FavoriteActivity

    @ContributesAndroidInjector
    fun buildNotificationActivity(): NotificationsActivity

    @ContributesAndroidInjector
    fun buildOrderActivity (): OrderActivity
}