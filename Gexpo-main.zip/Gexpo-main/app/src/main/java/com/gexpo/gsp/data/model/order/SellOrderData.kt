package com.gexpo.gsp.data.model.order

import com.google.gson.annotations.SerializedName

class SellOrderData {
    @field:SerializedName("id")
    var id: Int = 0

    @field:SerializedName("retailer_id")
    var retailerId: Int = 0

    @field:SerializedName("tcn")
    var tcn : String = ""

    @field:SerializedName("total")
    var total : Double = 0.0

    @field:SerializedName("vat")
    var vat: Double = 0.0

    @field:SerializedName("total_afterr_vat")
    var totalWithVat: Double = 0.0

    @field:SerializedName("updated_at")
    var updatedAt: String = ""

    @field:SerializedName("created_at")
    var createdAt: String = ""

    @field:SerializedName("qrcode")
    var qrCode: String = ""

    @field:SerializedName("discount")
    var discount: Double? = null

    @field:SerializedName("discount_type")
    var discountType: String? = null
}