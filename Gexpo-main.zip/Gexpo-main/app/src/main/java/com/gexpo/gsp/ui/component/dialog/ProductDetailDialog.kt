package com.gexpo.gsp.ui.component.dialog

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.util.Log
import android.view.LayoutInflater
import android.view.Window
import android.widget.Toast
import android.widget.Toast.LENGTH_LONG
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import com.gexpo.gsp.R
import com.gexpo.gsp.data.viewModel.favoritesViewModel.FavoritesViewModel
import com.gexpo.gsp.databinding.DialogProductDetailBinding
import com.gexpo.gsp.data.model.Product.ProductListResponse
import com.gexpo.gsp.data.model.base.ErrorResponse
import com.gexpo.gsp.network.HandleResponse
import com.gexpo.gsp.util.CommonUtils
import com.gexpo.gsp.util.CommonUtils.getMinusValue
import com.gexpo.gsp.util.CommonUtils.getPlusValue
import com.gexpo.gsp.util.GlideApp
import com.gexpo.gsp.util.KeyboardUtils
import com.gexpo.gsp.util.PopupUtils

class ProductDetailDialog  {
    lateinit var dialog: Dialog
    var isDialogRunning = false
    var mainViewModel: com.gexpo.gsp.realmDB.MainViewModel? = null
    val viewModel: FavoritesViewModel = FavoritesViewModel()


    @SuppressLint("SetTextI18n", "CheckResult")
    fun openDialog(
        context: Context,
        isFav: Boolean,
        product: ProductListResponse.ActiveProducts
    ) {
        dialog = Dialog(context)

        mainViewModel = com.gexpo.gsp.realmDB.MainViewModel()
        val binding: DialogProductDetailBinding = DataBindingUtil.inflate(
            LayoutInflater.from(context), R.layout.dialog_product_detail, null, false
        )

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(binding.root)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        var isLike = isFav ?: false
        Log.d("TAG", "openDialog===>" + isLike.toString())
        Log.d("TAG", "openDialog===>" + isFav.toString())

        binding.apply {
            // Price
            edittextPrice.setText((product.price ?: 0.00).toString())

            // Quantity
            if (product.quantity!! != 0) {
                tvAmount.setText((product.quantity ?: 1).toString())
            }
            else{
                tvAmount.setText("1")
            }

            // Product image
            if (product.photo != null){
                Log.d("Product Detail", "Product image : " + product.photo)
                GlideApp.with(context).load(product.photo).error(R.drawable.ic_product_default).into(ivProduct)
            }

            ivLike.setImageDrawable(
                ContextCompat.getDrawable(
                    context,
                    if (isLike) R.drawable.ic_heart_fill else R.drawable.ic_heart
                )
            )

            layoutPlus.setOnClickListener {
                KeyboardUtils.hideKeyboard(context)
                tvAmount.setText(getPlusValue(tvAmount))
            }

            layoutMinus.setOnClickListener {
                KeyboardUtils.hideKeyboard(context)
                tvAmount.setText(getMinusValue(tvAmount))
            }

            tvAddToCart.setOnClickListener {
                KeyboardUtils.hideKeyboard(context)
                val errorMessage =
                    CommonUtils.validatePrice(context, edittextPrice.text.toString().trim())
                if (errorMessage.isNotEmpty()) {
                    Toast.makeText(context, errorMessage, LENGTH_LONG).show()
                } else {
                    Toast.makeText(
                        context,
                        "Added to cart",
                        Toast.LENGTH_SHORT
                    ).show()
                    mainViewModel!!.addtocart(
                        edittextPrice.text.toString().trim(),
                        tvAmount.text.toString(),
                        "",
                        product.id.toString(),
                        product.englishName,
                        product.arabicName,
                        product.code ?: "",
                        product.retailerId ?: 0
                    )
                    dismissDialog()
                    val intent2 = Intent("cartAdded")
                    intent2.setPackage(context.packageName)
                    context.sendBroadcast(intent2)
                }
            }

            layoutLike.setOnClickListener {
                KeyboardUtils.hideKeyboard(context)
                ivLike.setImageDrawable(
                    ContextCompat.getDrawable(
                        context,
                        if (isLike) R.drawable.ic_heart else R.drawable.ic_heart_fill
                    )
                )
                isLike = !isLike
                addToFavorite(product.id!!, isLike, context)
            }

            layoutContent.setOnClickListener {
                KeyboardUtils.hideKeyboard(context)
            }

            layoutOutside.setOnClickListener {
                KeyboardUtils.hideKeyboard(context)
                dismissDialog()
            }
        }

        isDialogRunning = true

        PopupUtils.setDefaultDialogProperty(dialog)
        dialog.show()
    }

    private fun addToFavorite(productId: Int, isFav: Boolean, context: Context) {

        if (isFav){
            viewModel.addToFavorite(productId.toString(),object : HandleResponse<ProductListResponse> {
                override fun handleSuccessResponse(response: ProductListResponse) {
                    if (response.status == true) {
                        Toast.makeText(context, response.message.toString(), Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, response.message.toString(), Toast.LENGTH_SHORT).show()
                    }
                }

                override fun handleErrorResponse(error: ErrorResponse) {
                    Log.d("TAG", "handleErrorResponse: "+error.message.toString())
                    Toast.makeText(context, error.message.toString() + "", Toast.LENGTH_SHORT).show()
                }
            })
        }
        else{
            viewModel.removeFromFav(productId.toString(),object :
                HandleResponse<ProductListResponse> {

                override fun handleSuccessResponse(response: ProductListResponse) {
                    if (response.status == true) {
                        Toast.makeText(context, response.message.toString(), Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, response.message.toString(), Toast.LENGTH_SHORT).show()
                    }
                }

                override fun handleErrorResponse(error: ErrorResponse) {
                    Log.d("TAG", "handleErrorResponse: "+error.message.toString())
                    Toast.makeText(context, error.message.toString() + "", Toast.LENGTH_SHORT).show()
                }
            })
        }
    }


    private fun dismissDialog() {
        isDialogRunning = false
        dialog.dismiss()
    }

    companion object {
        private var instance: ProductDetailDialog? = null
        private val Instance: ProductDetailDialog
            get() {
                return instance ?: ProductDetailDialog()
            }

        fun openDialog(
            context: Context,
            product: ProductListResponse.ActiveProducts,
            isFav: Boolean
        ) {
            if (!Instance.isDialogRunning) {
                Instance.openDialog(context, isFav, product)
            }
        }
    }


}