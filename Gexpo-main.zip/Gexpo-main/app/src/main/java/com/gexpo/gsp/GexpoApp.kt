package com.gexpo.gsp

import android.app.Application
import com.gexpo.gsp.data.local.PreferenceManager
import com.gexpo.gsp.di.AppInjector
import com.gexpo.gsp.network.ApiClient
import com.gexpo.gsp.util.SunmiPrintHelper
import dagger.android.AndroidInjector
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import io.realm.Realm
import io.realm.RealmConfiguration
import javax.inject.Inject

class GexpoApp : Application(), HasAndroidInjector {

    @Inject
    lateinit var applicationDispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector(): AndroidInjector<Any> {
        return applicationDispatchingAndroidInjector
    }

    override fun onCreate() {
        super.onCreate()

        initAppComponents()

        initRealm()
    }

    private fun initAppComponents(){
        AppInjector.init(this)
        PreferenceManager.init(this)
        ApiClient.init(this)

        /**
         * Connect print service through interface library
         */
        SunmiPrintHelper.getInstance().initSunmiPrinterService(this)
    }

    private fun initRealm(){
        Realm.init(this)

        val configuration = RealmConfiguration.Builder()
            .name("cart.db")
            .deleteRealmIfMigrationNeeded()
            .schemaVersion(0)
            .allowWritesOnUiThread(true)
            .allowQueriesOnUiThread(true)
            .build()

        Realm.setDefaultConfiguration(configuration)
    }
}