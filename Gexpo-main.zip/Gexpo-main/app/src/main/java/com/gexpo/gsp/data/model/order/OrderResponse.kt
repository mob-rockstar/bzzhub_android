package com.gexpo.gsp.data.model.order

import com.gexpo.gsp.base.BaseViewModel
import com.google.gson.annotations.SerializedName

class OrderResponse : BaseViewModel() {

    @SerializedName("status")
    var status: Boolean? = null
    @SerializedName("message")
    var message: String? = null
    @SerializedName("data")
    var data: ArrayList<MyData> = arrayListOf()


    data class MyData(

        @SerializedName("id") val id: Int,
        @SerializedName("tcn") val tcn: String,
        @SerializedName("total") val total: Double,
        @SerializedName("vat") val vat: Double,
        @SerializedName("total_afterr_vat") val total_afterr_vat: Double,
        @SerializedName("created_at") val created_at: String,
        @SerializedName("updated_at") val updated_at: String,
        @SerializedName("deleted_at") val deleted_at: String,
        @SerializedName("retailer_id") val retailer_id: Int,
        @SerializedName("order_items") val order_items: List<Order_items>

    )

    data class Order_items(

        @SerializedName("id") val id: Int,
        @SerializedName("selling_price") val selling_price: Double,
        @SerializedName("quantity") val quantity: Int,
        @SerializedName("created_at") val created_at: String,
        @SerializedName("updated_at") val updated_at: String,
        @SerializedName("deleted_at") val deleted_at: String,
        @SerializedName("order_id") val order_id: Int,
        @SerializedName("product_id") val product_id: Int,
        @SerializedName("product") val product: Product

    )


    data class Product(

        @SerializedName("id") val id: Int,
        @SerializedName("arabic_name") val arabic_name: String,
        @SerializedName("english_name") val english_name: String,
        @SerializedName("price") val price: Double,
        @SerializedName("created_at") val created_at: String,
        @SerializedName("updated_at") val updated_at: String,
        @SerializedName("deleted_at") val deleted_at: String,
        @SerializedName("category_id") val category_id: Int,
        @SerializedName("retailer_id") val retailer_id: Int,
        @SerializedName("quantity") val quantity: Int,
        @SerializedName("code") val code: String,
        @SerializedName("status") val status: String

    )
}