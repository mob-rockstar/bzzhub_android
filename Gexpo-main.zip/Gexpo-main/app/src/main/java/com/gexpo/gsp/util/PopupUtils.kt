package com.gexpo.gsp.util

import android.app.Dialog
import android.view.WindowManager

object PopupUtils {
    fun setDefaultDialogProperty(dialog: Dialog) {
        val lp = WindowManager.LayoutParams()
        lp.copyFrom(dialog.window?.attributes)
        lp.width = WindowManager.LayoutParams.MATCH_PARENT
        lp.height = WindowManager.LayoutParams.MATCH_PARENT
        dialog.window?.attributes = lp
        dialog.setCanceledOnTouchOutside(true)


        dialog.setCancelable(true)
    }
}