package com.gexpo.gsp.data.model.history

import com.google.gson.annotations.SerializedName

class OrderHistoryData {
    @field:SerializedName("id")
    var id: Int = 0

    @field:SerializedName("retailer_id")
    var retailerId: Int = 0

    @field:SerializedName("tcn")
    var tcn : String = ""

    @field:SerializedName("total")
    var total : Double = 0.0

    @field:SerializedName("vat")
    var vat: Double = 0.0

    @field:SerializedName("total_afterr_vat")
    var totalWithVat: Double = 0.0

    @field:SerializedName("deleted_at")
    var deletedAt: String? = null

    @field:SerializedName("updated_at")
    var updatedAt: String = ""

    @field:SerializedName("created_at")
    var createdAt: String = ""

    @field:SerializedName("qrcode")
    var qrCode: String = ""

    @field:SerializedName("status")
    var status: String = ""

    @field:SerializedName("transaction_uuid")
    var transactionUuid: String? = null

    @field:SerializedName("order_items")
    var orderItems: ArrayList<OrderItem> = arrayListOf()

    @field:SerializedName("payment_type")
    var paymentType : String? = null

    @field:SerializedName("discount")
    var discount: Double? = null

    @field:SerializedName("discount_type")
    var discountType: String? = null

}