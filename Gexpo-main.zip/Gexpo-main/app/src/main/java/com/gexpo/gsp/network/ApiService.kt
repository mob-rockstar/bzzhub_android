package com.gexpo.gsp.network

interface ApiService {

//    @FormUrlEncoded
//    @POST("auth/email/login")
//    fun getLogin(
//        @Field("email") email: String?,
//        @Field("password") pass: String?
//    ): Call<LoginViewModel?>?
}