package com.gexpo.gsp.ui.component.easyImage

import androidx.core.content.FileProvider


class EasyImageFileProvider : FileProvider()