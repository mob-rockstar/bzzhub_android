package com.gexpo.gsp.realmDB
import io.realm.RealmModel
import io.realm.annotations.PrimaryKey
import io.realm.annotations.RealmClass
import io.realm.annotations.Required
import java.util.*

@RealmClass
open class CartDatabase : RealmModel {

    @PrimaryKey
    var id: String = ""
  //  var id: String = UUID.randomUUID().toString()

    @Required
    var price: Double? = 0.0

    @Required
    var quantity: Int? = 0


    @Required
    var img: String? = ""

    @Required
    var productId: String? = ""

    @Required
    var productName: String? = ""

    @Required
    var arabicName: String? = ""

    @Required
    var productSubName: String? = ""

    @Required
    var retailerId: Int? = 0

}