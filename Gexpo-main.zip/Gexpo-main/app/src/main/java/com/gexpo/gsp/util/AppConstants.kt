package com.gexpo.gsp.util

object AppConstants {
    const val PREF_NAME = "app_gexpo_gsp_pref"
//    const val BASE_URL = "http://ec2-13-58-231-131.us-east-2.compute.amazonaws.com:8080/kw-ecm/idox/"
    const val BASE_URL = "http://167.71.214.193/api/"
    const val REQUEST_VALUE_PERMISSION_SETTINGS = 10000

    // Language locale
    const val ENGLISH = "en"
    const val ARABIC = "ar"

    // Login auth token
    const val token = "token"

    // Near Pay token
    const val PAYMENT_TOKEN = "payment_token"

    // Payment Status
    const val PAYMENT_COMPLETED     = "completed"
    const val PAYMENT_REFUND        = "refund"
    const val PAYMENT_CREATED       = "created"

    // Discount Type
    const val DISCOUNT_TYPE_PERCENTAGE = "percentage"
    const val DISCOUNT_TYPE_FIXED      = "fixed"

    // Payment Type
    const val PAYMENT_TYPE_CASH     = "CASH"
    const val PAYMENT_TYPE_POS      = "POS"
}