package com.gexpo.gsp.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.NetworkInfo
import android.os.Handler
import android.os.Looper
import com.gexpo.gsp.data.model.base.ErrorResponse
import com.google.gson.Gson
import com.google.gson.TypeAdapter
import retrofit2.HttpException
import java.net.HttpURLConnection
import java.net.URL
import java.util.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors


object NetworkUtils {
    interface OnConnectedListener {
        fun onConnected()
    }

    private val sListeners = ArrayList<OnConnectedListener>()
    private var isNetworkConnected = true
//    private var snackBar: ImageSnackbar? = null

    fun isNetworkConnected(context: Context): Boolean {
        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        if (android.os.Build.VERSION.SDK_INT > android.os.Build.VERSION_CODES.O) {
            if (connectivityManager.activeNetwork == null) {
                isNetworkConnected = false
            }

            val networkCapabilities = connectivityManager.activeNetwork ?: return false

            if (connectivityManager.getNetworkCapabilities(networkCapabilities) == null) {
                isNetworkConnected = false
            }

            val actNw =
                connectivityManager.getNetworkCapabilities(networkCapabilities) ?: return false

            isNetworkConnected = when {
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> true
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> true
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> true
                else -> false
            }

            return isNetworkConnected
        } else {
            return connectivityManager.activeNetworkInfo != null && connectivityManager.activeNetworkInfo!!.isAvailable &&
                    connectivityManager.activeNetworkInfo!!.isConnectedOrConnecting &&
                    connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI)?.state == NetworkInfo.State.CONNECTED
                    && connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE)?.state == NetworkInfo.State.CONNECTED
        }
    }



    fun getThrowableError(t: Throwable): ErrorResponse? {
        ConnectivityTask().execute()

        if (t is HttpException) {
            val body = t.response()?.errorBody()
            val gson = Gson()
            val adapter: TypeAdapter<ErrorResponse> = gson.getAdapter(ErrorResponse::class.java)

            try {
                return adapter.fromJson(body!!.string())
            } catch (e: Exception) {
                e.printStackTrace()
            }
        } else {
//            AppLogger.d("throwable ${t.message}")
            val errorResponse = ErrorResponse()
            errorResponse.message = t.message ?: ""
            return errorResponse
        }
        return null
    }

    class ConnectivityTask {
        val executor: ExecutorService = Executors.newSingleThreadExecutor()
        val handler = Handler(Looper.getMainLooper())

        fun execute() {
            executor.execute {
                /*
                * its like doInBackground()
                * */
                handler.post {
                    /*
                    * You can perform any operation that
                    * */

                    try {
                        val urlConnection: HttpURLConnection =
                            URL("https://clients3.google.com/generate_204").openConnection() as HttpURLConnection
                        urlConnection.setRequestProperty("User-Agent", "Android")
                        urlConnection.setRequestProperty("Connection", "close")
                        urlConnection.connectTimeout = 6000
                        urlConnection.connect()
                        urlConnection.responseCode == 204 && urlConnection.contentLength == 0
                        isNetworkConnected = true
                    } catch (e: Exception) {
                        e.printStackTrace()
                        isNetworkConnected = false
                    }
                }
            }
        }
    }

}