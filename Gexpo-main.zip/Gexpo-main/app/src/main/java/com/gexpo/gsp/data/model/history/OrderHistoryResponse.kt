package com.gexpo.gsp.data.model.history

import com.google.gson.annotations.SerializedName
import com.gexpo.gsp.data.model.base.BaseResponse

class OrderHistoryResponse : BaseResponse(){
    @field:SerializedName("data")
    var orders: ArrayList<OrderHistoryData> = arrayListOf()
}