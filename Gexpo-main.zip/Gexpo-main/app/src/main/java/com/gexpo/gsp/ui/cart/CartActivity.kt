package com.gexpo.gsp.ui.cart

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import com.gexpo.gsp.R
import com.gexpo.gsp.base.BaseActivity
import com.gexpo.gsp.data.local.PreferenceManager
import com.gexpo.gsp.data.model.Product.ProductListResponse
import com.gexpo.gsp.data.model.base.BaseResponse
import com.gexpo.gsp.data.model.base.ErrorResponse
import com.gexpo.gsp.data.model.order.SellOrderData
import com.gexpo.gsp.data.model.order.SellOrderResponse
import com.gexpo.gsp.data.viewModel.order.OrderViewModel
import com.gexpo.gsp.databinding.ActivityCartBinding
import com.gexpo.gsp.databinding.PaymentBottomSheetDetailBinding
import com.gexpo.gsp.network.HandleResponse
import com.gexpo.gsp.realmDB.CartDatabase
import com.gexpo.gsp.ui.component.dialog.DiscountDialog
import com.gexpo.gsp.ui.component.dialog.PaymentTypeDialog
import com.gexpo.gsp.ui.main.MainActivity
import com.gexpo.gsp.util.AppConstants
import com.gexpo.gsp.util.CommonUtils
import com.gexpo.gsp.util.PopupUtils
import com.gexpo.gsp.util.PrintHelper
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import io.nearpay.sdk.Environments
import io.nearpay.sdk.NearPay
import io.nearpay.sdk.utils.PaymentText
import io.nearpay.sdk.utils.enums.*
import io.nearpay.sdk.utils.listeners.PurchaseListener
import io.nearpay.sdk.utils.listeners.SetupListener
import io.nearpay.sdk.utils.*
import io.nearpay.sdk.utils.listeners.BitmapListener

import io.realm.RealmResults
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody
import okhttp3.internal.notify
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.text.DecimalFormat
import java.util.*
import javax.inject.Inject
import kotlin.math.round


class CartActivity : BaseActivity<ActivityCartBinding, OrderViewModel>(), HasAndroidInjector, PaymentTypeDialog.PaymentTypeDialogListener {

    override val layoutId: Int
        get() = R.layout.activity_cart

    override val viewModel: OrderViewModel
        get() {
            return getViewModel(OrderViewModel::class.java)
        }
    lateinit var realmResults: RealmResults<CartDatabase>

    private val TAG = "CartActivity"
    var totalPrice:Double = 0.0
    var vat:Int =0
//    lateinit var dialog: Dialog

    private var selectPaymentType:String = AppConstants.PAYMENT_TYPE_POS
    private var selectPrintReceipt:String = "YES"

    var viewModel1: com.gexpo.gsp.realmDB.MainViewModel? = null
    var cartProducts: List<CartDatabase> = ArrayList()

    var discountPercentVal : Double? = null
    var discountFixedVal : Double? = null

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    private lateinit var cartAdapter: CartProductAdapterNew

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel1 = com.gexpo.gsp.realmDB.MainViewModel()
//        cartAdapter = ProductsAdapter(viewModel1!!,this@CartActivity,
//            onProductClick = {productId-> deleteProduct(productId) },
//        )
        initUI()
    }

    private fun initUI() {
        initToolbar()
        initRecyclerView()
        viewDataBinding?.apply {
            // Pay
            tvGenerateInvoice.setOnClickListener {
                selectPaymentType = AppConstants.PAYMENT_TYPE_POS
                selectPrintReceipt = "YES"

                if (cartProducts.isNotEmpty()){
                    val retailerId = cartProducts[0].retailerId
                    PaymentTypeDialog.openDialog(this@CartActivity, this@CartActivity, retailerId, true, getTotalPriceAfterVat())
                }
            }

            // Create
            tvCreate.setOnClickListener {
                showDiscountPopup()
            }
        }
    }

    // Show the discount popup for creating order
    private fun showDiscountPopup(){
        DiscountDialog.openDialog(this) { percent, fixed -> createOrder(percent, fixed) }
    }

    private fun createOrder(discountPercent: Double?, discountFixed: Double?){
        viewDataBinding!!.progressBar.visibility = View.VISIBLE
        val productsArray = JSONArray()
        var retailerId = 0
        try {
            cartProducts.forEachIndexed { index, item ->
                println("index = $index, item = $item ")
                retailerId = item.retailerId ?: 0

                val productsJson = JSONObject()
                productsJson.put("product_id", item.productId)
                productsJson.put("selling_price", item.price)
                productsJson.put("quantity", item.quantity)
                productsArray.put(productsJson)
            }
        } catch (e: JSONException) {
            e.printStackTrace()
        }

        val requestJson = JSONObject()
        requestJson.put("payment_type", "cash")
        requestJson.put("products", productsArray)
        requestJson.put("retailer_id", retailerId)

        if (discountPercent != null){
            requestJson.put("discount_type", AppConstants.DISCOUNT_TYPE_PERCENTAGE)
            requestJson.put("discount", discountPercent)
        }
        else if (discountFixed != null){
            requestJson.put("discount_type", AppConstants.DISCOUNT_TYPE_FIXED)
            requestJson.put("discount", discountFixed)
        }

        val body: RequestBody = RequestBody.create(
            "application/json; charset=utf-8".toMediaTypeOrNull(),
            requestJson.toString()
        )

        viewModel.createOrder(body,object :
            HandleResponse<SellOrderResponse> {

            override fun handleSuccessResponse(response: SellOrderResponse) {
                viewDataBinding!!.progressBar.visibility = View.GONE

                if (response.status) {
                    Toast.makeText(this@CartActivity, response.message, Toast.LENGTH_SHORT).show()

                    viewModel1!!.deleteAllItemsFromCart()
                    goToMain()
                }
                else {
                    Toast.makeText(this@CartActivity, response.message, Toast.LENGTH_SHORT).show()
                }

                Log.d(TAG, "Create order: " + response.message)
            }

            override fun handleErrorResponse(error: ErrorResponse) {
                viewDataBinding!!.progressBar.visibility = View.GONE

                Log.d(TAG, "Create order error: "+error.message)
                Toast.makeText(this@CartActivity, error.message + "", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun generateInvoice(retailerId : Int){
        if (selectPaymentType == AppConstants.PAYMENT_TYPE_CASH) {
            sellOrder(null, null, retailerId)
        }
        else{
            if (PreferenceManager.isInitiatedNearPay) {
                // Pay via SDK
                pay(getTotalCost(), retailerId)
            }
            else{
                // Initialize the NearPay SDK
                initNearPay(retailerId)
            }
        }
    }

    private fun getTotalPriceAfterVat() : Double{
        var totalPriceSum = 0.0  // Initialize the sum variable
        for (element in cartProducts) {
            val itemPrice = element.price ?: 0.0
            val itemQuantity = element.quantity ?: 0

            val subtotal = itemPrice * itemQuantity
            totalPriceSum += subtotal
        }
        Log.d("CartActivity", "Total amount to be paid :" + totalPriceSum)

        return  totalPriceSum
    }

    private fun getTotalCost() : Long{
        var totalPriceSum = 0.0  // Initialize the sum variable
        for (element in cartProducts) {
            val itemPrice = element.price ?: 0.0
            val itemQuantity = element.quantity ?: 0

            val subtotal = itemPrice * itemQuantity
            totalPriceSum += subtotal
        }

        if (selectPaymentType != AppConstants.PAYMENT_TYPE_CASH) {
            if (discountPercentVal != null) {
                totalPriceSum = ((totalPriceSum / 1.15) - discountPercentVal!! / 100.0 * (totalPriceSum / 1.15)) * 1.15
            }
            else if (discountFixedVal != null) {
                totalPriceSum = ((totalPriceSum / 1.15) - discountFixedVal!! ) * 1.15
            }
        }

        Log.d("CartActivity", "Total amount with discount :" + totalPriceSum)

        return  (totalPriceSum * 100).toLong()
    }

    private fun initNearPay(retailerId: Int){
        val amount = getTotalCost()
        if (PreferenceManager.paymentToken.isEmpty()){
            // Show the error message
            Toast.makeText(this, getString(R.string.msg_ask_logout), Toast.LENGTH_LONG).show()
            return
        }

        if (nearPay == null) {
            initNearPayInstance()
        }

        nearPay!!.setup(object : SetupListener {
            override fun onSetupCompleted() {
                // if you wish to get the receipt in Json format use nearPay.toJson()
                PreferenceManager.isInitiatedNearPay = true
                pay(amount, retailerId)
            }
            override fun onSetupFailed(setupFailure: SetupFailure) {
                when (setupFailure) {
                    is SetupFailure.AlreadyInstalled -> {
                        // when the payment plugin is already installed.
                        showPaymentErrorMessage("Payment plugin is already installed!")

                        PreferenceManager.isInitiatedNearPay = true
                        pay(amount, retailerId)
                    }
                    is SetupFailure.NotInstalled -> {
                        // when the installation failed.
                        showPaymentErrorMessage("Plugin installation failed!")
                    }
                    is SetupFailure.AuthenticationFailed -> {
                        // when the authentication failed.
                        // You can use the following method to update your JWT
                        showPaymentErrorMessage("Authentication failed!")
//                        nearPay.updateAuthentication(AuthenticationData.Jwt(PreferenceManager.paymentToken))
                    }
                    is SetupFailure.InvalidStatus -> {
                        // Please note that you can get the status using setupFailure.status
                        // you can get the status using the following code
                        val status: List<StatusCheckError> = (setupFailure as SetupFailure.InvalidStatus).status
                        var errMsg = ""
                        for (statusCheckError in status) {
                            errMsg = errMsg + statusCheckError.toString() + "\n"
                        }

                        val finalErrMsg = errMsg
                        showPaymentErrorMessage("Invalid status : $finalErrMsg")
                    }
                }
            }
        })
    }

    private fun pay(amount : Long, retailerId: Int){
        val customerReferenceNumber = "9ace70b7-977d-4094-b7f4-4ecb17de6753" //[optional] any number you want to add as a reference
        val enableReceiptUi = true// [optional] true will enable the ui and false will disable
        val enableReversal = true // it will allow you to enable or disable the reverse button
        val finishTimeOut : Long = 20 // Add the number of seconds
        val transactionId = UUID.randomUUID(); // [optional] You can add your UUID here which allows you to ask about the transaction again using the same UUID
        val enableUiDismiss = true // [optional] it will allow you to control dismissing the UI

        nearPay!!.purchase(amount, customerReferenceNumber, enableReceiptUi, enableReversal, finishTimeOut, transactionId, enableUiDismiss, object :
            PurchaseListener {
            override fun onPurchaseApproved(transactionData: TransactionData) {
                // Check if we need to print the receipt
                if (selectPrintReceipt == "YES") {
                    // Get the order receipt
                    if (transactionData.receipts != null) {
                        val receipt = transactionData.receipts!![0]
                        val receiptJson = receipt.toJson()
                        receipt.toImage(this@CartActivity, 300, 24, BitmapListener {
                            selectPaymentType = AppConstants.PAYMENT_TYPE_POS
                            sellOrder(it, receiptJson, retailerId)
                        })
                    }
                }
                else{
                    selectPaymentType = AppConstants.PAYMENT_TYPE_POS
                    sellOrder(null, null, retailerId)
                }
            }
            override fun onPurchaseFailed(purchaseFailure: PurchaseFailure) {
                when (purchaseFailure) {
                    is PurchaseFailure.PurchaseDeclined -> {
                        // when the payment declined.
                        showPaymentErrorMessage("The payment declined")
                    }
                    is PurchaseFailure.PurchaseRejected -> {
                        // when the payment is rejected .
                        showPaymentErrorMessage("The payment is rejected")
                    }
                    is PurchaseFailure.AuthenticationFailed -> {
                        // when the authentication failed .
                        // You can use the following method to update your JWT
                        showPaymentErrorMessage("The authentication failed")
                    }
                    is PurchaseFailure.InvalidStatus -> {
                        // Please note that you can get the status using purchaseFailure.status
                        TODO("Your Code Here")
                    }
                    is PurchaseFailure.GeneralFailure -> {
                        // when there is General error .
                        showPaymentErrorMessage("General Error")
                    }
                }
            }
        })
    }

    private fun sellOrder(receiptBmp : Bitmap?, receiptJson : String?, retailerId: Int) {
        viewDataBinding!!.progressBar.visibility = View.VISIBLE
        val productsArray = JSONArray()
        try {
            cartProducts.forEachIndexed { index, item ->
                println("index = $index, item = $item ")
                val productsjson = JSONObject()
                productsjson.put("product_id", item.productId)
                productsjson.put("selling_price", item.price)
                productsjson.put("quantity", item.quantity)
                productsArray.put(productsjson)
            }
        } catch (e: JSONException) {
            e.printStackTrace()
        }

        val payType = if (selectPaymentType == AppConstants.PAYMENT_TYPE_CASH) "cash" else "pos"
        val requestJson = JSONObject()
        requestJson.put("payment_type", payType)
        requestJson.put("products", productsArray)
        requestJson.put("retailer_id", retailerId)

        if (discountPercentVal != null){
            requestJson.put("discount_type", AppConstants.DISCOUNT_TYPE_PERCENTAGE)
            requestJson.put("discount", discountPercentVal!!)
        }
        else if (discountFixedVal != null){
            requestJson.put("discount_type", AppConstants.DISCOUNT_TYPE_FIXED)
            requestJson.put("discount", discountFixedVal!!)
        }

        if (selectPaymentType != AppConstants.PAYMENT_TYPE_CASH && receiptJson != null) {
            requestJson.put("payment_object", receiptJson)
        }

        val body: RequestBody = RequestBody.create(
            "application/json; charset=utf-8".toMediaTypeOrNull(),
            requestJson.toString()
        )

        viewModel.sellOrder(body,object :
            HandleResponse<SellOrderResponse> {

            override fun handleSuccessResponse(response: SellOrderResponse) {
                viewDataBinding!!.progressBar.visibility = View.GONE

                if (response.status) {
                    Toast.makeText(this@CartActivity, response.message, Toast.LENGTH_SHORT).show()

                    discountPercentVal = null
                    discountFixedVal = null

                    // Print the receipt/invoice
                    if (selectPaymentType == "CASH") {
                        // Print the qrcode
                        printQrcodeForCashPay(response.orderData!!)
                    }
                    else{
                        // Print the Receipt from NearPay SDK
                        printReceipt(receiptBmp, response.orderData!!)
                    }

                    viewModel1!!.deleteAllItemsFromCart()
                }
                else {
                    Toast.makeText(this@CartActivity, response.message, Toast.LENGTH_SHORT).show()
                }
                Log.d(TAG, "sellOrderSuccessResponse: "+response.message)
            }

            override fun handleErrorResponse(error: ErrorResponse) {
                viewDataBinding!!.progressBar.visibility = View.GONE

                Log.d(TAG, "sellOrderErrorResponse: "+error.message)
                Toast.makeText(this@CartActivity, error.message + "", Toast.LENGTH_SHORT).show()
            }
        })
    }

    // Print the invoice after placed the order
    private fun printReceipt(receiptBitmap : Bitmap?, orderData : SellOrderData){
        if (receiptBitmap != null){
            PrintHelper.printNearPayReceipt(this, receiptBitmap, orderData, cartProducts)
        }

        goToMain()
    }

    // Print the Qrcode for cash payment
    private fun printQrcodeForCashPay(orderData : SellOrderData){
        Log.d("Cart", "Cash Qrcode : "+ orderData.qrCode)
        PrintHelper.printQrCode(this, orderData, cartProducts)
        goToMain()
    }


    private fun initToolbar() {
        viewDataBinding?.toolbar?.apply {
            ivBack.setOnClickListener {
                finish()
            }

            tvTitle.text =
                this@CartActivity.resources.getString(R.string.str_my_cart)
        }
    }

    private fun orderPayment(paymentType:String, printReceipt:String, retailerId : Int){
        Log.d(TAG, "===>paymentType===>"+paymentType+"===>printReceipt==>"+printReceipt)
        selectPaymentType = paymentType
        selectPrintReceipt = printReceipt

        // validate the entered retailer_id
        validateRetailerId(retailerId)
//        generateInvoice(retailerId)
    }

    private fun initRecyclerView() {
        viewDataBinding?.recyclerView?.apply {
            layoutManager = LinearLayoutManager(this@CartActivity)
            isNestedScrollingEnabled = false
            setHasFixedSize(true)

             realmResults = viewModel1!!.getProductCart()!!
            if(realmResults.isEmpty()){
                Toast.makeText(this@CartActivity, "No items in cart.", Toast.LENGTH_SHORT).show()
                viewDataBinding?.bottomLayout!!.visibility = View.GONE
            }
            cartAdapter = CartProductAdapterNew(onProductClick = {tvTotal ,list ,pos -> totalAmountCalculate(list) }, {pos -> deleteItemFromCart(pos)}, viewModel1!!, realmResults)
            adapter = cartAdapter

            cartProducts = realmResults
        }
    }

    // Check if retailer id is valid
    private fun validateRetailerId(retailerId: Int){
        viewDataBinding!!.progressBar.visibility = View.VISIBLE

        val requestJson = JSONObject()
        requestJson.put("retailer_id", retailerId)
        val body: RequestBody = RequestBody.create(
            "application/json; charset=utf-8".toMediaTypeOrNull(),
            requestJson.toString()
        )

        viewModel.checkRetailerId(body,object : HandleResponse<BaseResponse> {

            override fun handleSuccessResponse(response: BaseResponse) {
                viewDataBinding!!.progressBar.visibility = View.GONE
                Log.e(TAG, "Check retailer result : " + response.message)

                if (response.status) {
                    generateInvoice(retailerId)
                }
                else{
                    Toast.makeText(this@CartActivity, response.message, Toast.LENGTH_LONG).show()
                }
            }

            override fun handleErrorResponse(error: ErrorResponse) {
                viewDataBinding!!.progressBar.visibility = View.GONE

                Log.e(TAG, "Check retailer error : " + error.message)
                Toast.makeText(this@CartActivity, error.message + "", Toast.LENGTH_LONG).show()
            }
        })
    }

    // Delete item from cart list
    @SuppressLint("NotifyDataSetChanged")
    private fun deleteItemFromCart(pos : Int){
        // Show the confirm dialog
        val alertDialog = AlertDialog.Builder(this)

        alertDialog.apply {
            // setIcon(R.drawable.ic_hello)
            setTitle("")
            setMessage(getString(R.string.msg_delete))
            setPositiveButton(getString(R.string.yes)) { _: DialogInterface?, _: Int ->
                // Remove item from local storage
                viewModel1!!.deleteNote(realmResults[pos]!!.id)
                cartAdapter.notifyDataSetChanged()

                // Update the all costs
                totalAmountCalculate(realmResults)
            }
            setNegativeButton(getString(R.string.no)) { _, _ ->
                // Nothing to do
            }
            setOnDismissListener {
            }

        }.create().show()
    }

    @SuppressLint("SetTextI18n")
    private fun totalAmountCalculate(list: RealmResults<CartDatabase>?) {

        // Get the cart items
        cartProducts = list!!

        var totalPriceSum = 0.0  // Initialize the sum variable
        for (position in 0 until list.size) {
            val item = list[position]
            val itemPrice = item?.price ?: 0.0
            val itemQuantity = item?.quantity ?: 0

            val subtotal = itemPrice * itemQuantity
            totalPriceSum += subtotal
        }
        Log.d(TAG, "totalAmountCalculate: "+totalPriceSum)

        viewDataBinding?.apply {

            // Total after VAT
            val formattedPrice = formatPrice(totalPriceSum)
            tvTotalVat.text = "SAR ${getFormattedDecimal(totalPriceSum)}"

            // Total
            val sum = totalPriceSum / 1.15
            val formattedSum = formatPrice(sum)
            tvTotalProduct.text = "SAR ${getFormattedDecimal(sum)}"

            // VAT
            val strVat =  (sum * (0.15)).toString()
            val roundedNumber = round(strVat.toDouble())
            val formattedPriceVat = formatPrice(roundedNumber)
            tvVat.text = "SAR ${getFormattedDecimal(totalPriceSum) - getFormattedDecimal(sum)}"

            if(list.isEmpty()){
                Toast.makeText(this@CartActivity, "No items in cart.", Toast.LENGTH_SHORT).show()
                viewDataBinding?.bottomLayout!!.visibility = View.GONE
            }
            Log.d(TAG, "totalAmountCalculate: "+sum)
        }
    }

    private fun formatPrice(price: Double?): String {
        val decimalFormat = DecimalFormat("0.00")
        return decimalFormat.format(price ?: 0)
    }

    private fun goToMain(){
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
    }

    override fun onPay(type: String, isPrintReceipt: String, retailerId: Int, discountPercent : Double?, discountFixed: Double?) {
        discountPercentVal = discountPercent
        discountFixedVal = discountFixed
        orderPayment(type, isPrintReceipt, retailerId)
    }
}