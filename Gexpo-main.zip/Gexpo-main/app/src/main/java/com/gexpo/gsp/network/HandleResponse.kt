package com.gexpo.gsp.network

import com.gexpo.gsp.data.model.base.ErrorResponse

interface HandleResponse<T> {
    fun handleErrorResponse(error: ErrorResponse)
    fun handleSuccessResponse(response: T)
}