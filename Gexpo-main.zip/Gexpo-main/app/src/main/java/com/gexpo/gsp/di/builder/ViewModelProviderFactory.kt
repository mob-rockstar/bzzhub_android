package com.gexpo.gsp.di.builder

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.gexpo.gsp.ui.cart.CartViewModel
import com.gexpo.gsp.data.model.Product.ProductListResponse
import com.gexpo.gsp.data.model.notification.NotificationsResponse
import com.gexpo.gsp.data.model.order.OrderResponse
import com.gexpo.gsp.data.model.login.LoginResponse
import com.gexpo.gsp.ui.splash.SplashViewModel
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ViewModelProviderFactory @Inject constructor(): ViewModelProvider.NewInstanceFactory() {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        @Suppress("UNCHECKED_CAST")
        (return when {
            modelClass.isAssignableFrom(SplashViewModel::class.java) -> {
                SplashViewModel()  as T
            }
            modelClass.isAssignableFrom(ProductListResponse::class.java) -> {
                ProductListResponse()  as T
            }
            modelClass.isAssignableFrom(CartViewModel::class.java) -> {
                CartViewModel()  as T
            }

            modelClass.isAssignableFrom(OrderResponse::class.java) -> {
                OrderResponse()  as T
            }

            modelClass.isAssignableFrom(NotificationsResponse::class.java) -> {
                NotificationsResponse()  as T
            }
            modelClass.isAssignableFrom(OrderResponse::class.java) -> {
                OrderResponse()  as T
            }

            modelClass.isAssignableFrom(LoginResponse::class.java) -> {
                LoginResponse()  as T
            }

            else -> throw IllegalArgumentException("Unknown ViewModel Class")
        })
    }
}