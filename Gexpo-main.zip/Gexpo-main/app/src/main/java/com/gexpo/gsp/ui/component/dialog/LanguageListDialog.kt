package com.gexpo.gsp.ui.component.dialog

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.Window
import androidx.databinding.DataBindingUtil
import com.gexpo.gsp.R
import com.gexpo.gsp.base.navigator.Navigator
import com.gexpo.gsp.data.local.PreferenceManager
import com.gexpo.gsp.databinding.DialogLanguageSelectionBinding
import com.gexpo.gsp.util.PopupUtils

class LanguageListDialog {

    lateinit var dialog: Dialog
    var isDialogRunning = false

    fun openDialog(context: Context, onConfirm: () -> Unit) {
        dialog = Dialog(context)

        val binding: DialogLanguageSelectionBinding = DataBindingUtil.inflate(
            LayoutInflater.from(context), R.layout.dialog_language_selection, null, false
        )

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(binding.root)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        var currentLanguage = PreferenceManager.userLanguage

        binding.apply {
            ivTickEnglish.visibility = if (currentLanguage == 1) VISIBLE else GONE
            ivTickArabic.visibility = if (currentLanguage == 1) GONE else VISIBLE

            layoutEnglish.setOnClickListener {
                ivTickEnglish.visibility = VISIBLE
                ivTickArabic.visibility = GONE
                currentLanguage = 1
            }

            layoutArabic.setOnClickListener {
                ivTickEnglish.visibility = GONE
                ivTickArabic.visibility = VISIBLE
                currentLanguage = 2
            }

            tvConfirm.setOnClickListener {
                PreferenceManager.userLanguage = currentLanguage
                onConfirm()
            }

            toolbar.ivBack.setOnClickListener {
                dismissDialog()
            }

            layoutOutside.setOnClickListener {
                dismissDialog()
            }
        }

        isDialogRunning = true

        PopupUtils.setDefaultDialogProperty(dialog)
        dialog.show()
    }

    fun dismissDialog(){
        isDialogRunning = false
        dialog.dismiss()
    }

    companion object {
        private var instance: LanguageListDialog? = null
        private val Instance: LanguageListDialog
            get() {
                return instance ?: LanguageListDialog()
            }

        fun openDialog(context: Context, onConfirm: () -> Unit) {
            if (!Instance.isDialogRunning){
                Instance.openDialog(context) {
                    onConfirm()
                }
            }
        }
    }
}