package com.gexpo.gsp.util

import android.content.Context
import com.gexpo.gsp.data.local.PreferenceManager
import io.nearpay.sdk.Environments
import io.nearpay.sdk.NearPay
import io.nearpay.sdk.utils.PaymentText
import io.nearpay.sdk.utils.enums.AuthenticationData
import io.nearpay.sdk.utils.enums.NetworkConfiguration
import io.nearpay.sdk.utils.enums.UIPosition

class NearPayHelper {
    companion object {
        val instance = NearPayHelper()
    }
}