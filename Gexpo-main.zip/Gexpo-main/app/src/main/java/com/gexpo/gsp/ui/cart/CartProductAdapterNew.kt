package com.gexpo.gsp.ui.cart


import android.annotation.SuppressLint
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.gexpo.gsp.R
import com.gexpo.gsp.base.BaseRecyclerViewAdapter
import com.gexpo.gsp.data.local.PreferenceManager
import com.gexpo.gsp.databinding.RecyclerItemProductCartBinding
import com.gexpo.gsp.realmDB.CartDatabase
import com.gexpo.gsp.util.CommonUtils.getAmountFromTextView
import com.gexpo.gsp.util.CommonUtils.getMinusValue
import com.gexpo.gsp.util.CommonUtils.getPlusValue
import io.realm.RealmResults
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.*
import kotlin.math.floor


class CartProductAdapterNew(
    val onProductClick :(tvTotal:String, list: RealmResults<CartDatabase>?, pos:Int) -> Unit,
    val onDeleteItem :(pos:Int) -> Unit,
    private val viewModel1: com.gexpo.gsp.realmDB.MainViewModel,
    var list: RealmResults<CartDatabase>?
) : BaseRecyclerViewAdapter<CartDatabase, RecyclerItemProductCartBinding>() {

    override val layoutId: Int
        get() = R.layout.recycler_item_product_cart
    var totalPrice = 0.0
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return CartProductViewHolder(createBindView(viewGroup))
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder: CartProductViewHolder = viewHolder as CartProductViewHolder

        holder.binding.tvProductName.text = (if (PreferenceManager.userLanguage == 1) list?.get(position)?.productName.toString() else list?.get(position)?.arabicName.toString())
        holder.binding.tvPrice.setText(list?.get(position)?.price.toString())
        holder.binding.tvAmount.setText(list?.get(position)?.quantity.toString())

        holder.binding.tvPrice.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if(s!!.isNotEmpty()){
                    viewModel1.updateProductPrice(list!![position]!!.id,s.toString())
                    val currQty = getAmountFromTextView(holder.binding.tvAmount).toDouble()
                    val currPrice = s.toString().toDouble()
                    holder.binding.tvTotal.text = "SAR ${getFormattedDecimal(currPrice * currQty)}"
                    onProductClick(holder.binding.tvTotal.text.toString(),list,position)
                }else{
                    viewModel1.updateProductPrice(list!![position]!!.id,"0")
                    holder.binding.tvPrice.setText("0")
                    holder.binding.tvTotal.text = "SAR ${String.format(Locale.US, "%.2f", (getAmountFromTextView(holder.binding.tvAmount) * 0.0))}"
                    onProductClick(holder.binding.tvTotal.text.toString(),list,position)
                }
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        holder.binding.tvAmount.inputType = InputType.TYPE_CLASS_NUMBER
        holder.binding.tvAmount.addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                        if(s!!.isNotEmpty()){
                            // Total cost
                            val currQty = getAmountFromTextView(holder.binding.tvAmount).toDouble()
                            val currPrice = holder.binding.tvPrice.text.toString().toDouble()
                            holder.binding.tvTotal.text = "SAR ${getFormattedDecimal(currPrice * currQty)}"

//                            "SAR ${
//                                String.format(
//                                    Locale.US,
//                                    "%.2f",
//                                    (getAmountFromTextView(holder.binding.tvAmount) * holder.binding.tvPrice.text.toString().toDouble()))
//                            }".also { holder.binding.tvTotal.text = it }

                            viewModel1.updateProductCart(
                                list!![position]!!.id,
                                holder.binding.tvAmount.text.toString()
                            )

                            onProductClick(holder.binding.tvTotal.text.toString(),list,position)
                        }else{
                            holder.binding.tvAmount.setText("1")
                            // Total cost
                            val currQty = 1.0
                            val currPrice = holder.binding.tvPrice.text.toString().toDouble()
                            holder.binding.tvTotal.text = "SAR ${getFormattedDecimal(currPrice * currQty)}"

//                            // Total cost
//                            "SAR ${
//                                String.format(
//                                    Locale.US,
//                                    "%.2f",
//                                    (getAmountFromTextView(holder.binding.tvAmount) * holder.binding.tvPrice.text.toString().toDouble()))
//                            }".also { holder.binding.tvTotal.text = it }

                            viewModel1.updateProductCart(
                                list!![position]!!.id,
                                holder.binding.tvAmount.text.toString()
                            )

                            onProductClick(holder.binding.tvTotal.text.toString(),list,position)
                        }
                    }
                    override fun afterTextChanged(s: Editable?) {}
                })


        val currQty = getAmountFromTextView(holder.binding.tvAmount).toDouble()
        val currPrice = holder.binding.tvPrice.text.toString().toDouble()
        holder.binding.tvTotal.text = "SAR ${getFormattedDecimal(currPrice * currQty)}"
//        holder.binding.tvTotal.text = "SAR ${String.format(Locale.US, "%.2f", (getAmountFromTextView(holder.binding.tvAmount) * holder.binding.tvPrice.text.toString().toDouble()))}"


        holder.binding.apply {
            // + button event
            layoutPlus.setOnClickListener {
                // Quantity
                tvAmount.setText(getPlusValue(tvAmount))

                // Total cost
                "SAR ${
                    String.format(
                        Locale.US,
                        "%.2f",
                        (getAmountFromTextView(tvAmount) * tvPrice.text.toString().toDouble()))
                }".also { tvTotal.text = it }

                viewModel1.updateProductCart(
                    list!![position]!!.id,
                    tvAmount.text.toString()
                )

                onProductClick(tvTotal.text.toString(),list,position)
            }

            // - button event
            layoutMinus.setOnClickListener {
                tvAmount.setText(getMinusValue(tvAmount))
                "SAR ${
                    String.format(
                        Locale.US,
                        "%.2f",
                        (getAmountFromTextView(tvAmount) * tvPrice.text.toString().toDouble())
                    )
                }".also { tvTotal.text = it }

                if (list!![position]!!.quantity.toString() == "1") {
//                    viewModel1.deleteNote(list!![position]!!.id)
//                    notifyItemRemoved(position)
//                    notifyItemRangeChanged(position, itemCount)
                } else {
                    viewModel1.updateProductCart(
                        list!![position]!!.id,
                        tvAmount.text.toString()
                    )
                }
                onProductClick(tvTotal.text.toString(),list,position)

            }

            // Delete
            ivDelete.setOnClickListener {
                onDeleteItem(position)
            }

            onProductClick(tvTotal.text.toString(),list,position)
        }
    }

    private fun getFormattedDecimal(price : Double) : BigDecimal {
        var bd: BigDecimal = BigDecimal.valueOf(price)
        bd = bd.setScale(2, RoundingMode.DOWN)

        return bd
    }


    internal class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) { // ViewHolder implementation
    }
    override fun getItemCount(): Int {
//        return 5
        return list!!.size
        //return super.getItemCount()
    }


    inner class CartProductViewHolder(val binding: RecyclerItemProductCartBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(note: CartDatabase?) {
            binding.tvPrice.setText(note?.price.toString())
            binding.tvAmount.setText(note?.quantity.toString())
        }

        fun updateTextView(newText: String) {
            // Update the corresponding TextView within the adapter
            binding.tvTotal.text = "Updated Text: $newText"
        }
    }


}