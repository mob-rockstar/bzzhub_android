package com.gexpo.gsp.ui.orders

import android.graphics.Bitmap
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.gexpo.gsp.R
import com.gexpo.gsp.base.BaseActivity
import com.gexpo.gsp.data.local.PreferenceManager
import com.gexpo.gsp.data.model.base.ErrorResponse
import com.gexpo.gsp.data.model.history.OrderHistoryData
import com.gexpo.gsp.data.model.history.OrderHistoryResponse
import com.gexpo.gsp.data.model.history.OrderItem
import com.gexpo.gsp.data.model.order.OrderResponse
import com.gexpo.gsp.data.model.order.SellOrderData
import com.gexpo.gsp.data.model.order.SellOrderResponse
import com.gexpo.gsp.data.model.refund.RefundResponse
import com.gexpo.gsp.data.viewModel.order.OrderViewModel
import com.gexpo.gsp.databinding.ActivityOrderBinding
import com.gexpo.gsp.network.HandleResponse
import com.gexpo.gsp.ui.component.dialog.PaymentTypeDialog
import com.gexpo.gsp.util.AppConstants
import com.gexpo.gsp.util.PrintHelper
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import io.nearpay.sdk.Environments
import io.nearpay.sdk.NearPay
import io.nearpay.sdk.utils.PaymentText
import io.nearpay.sdk.utils.enums.AuthenticationData
import io.nearpay.sdk.utils.enums.GetDataFailure
import io.nearpay.sdk.utils.enums.NetworkConfiguration
import io.nearpay.sdk.utils.enums.PurchaseFailure
import io.nearpay.sdk.utils.enums.RefundFailure
import io.nearpay.sdk.utils.enums.SetupFailure
import io.nearpay.sdk.utils.enums.StatusCheckError
import io.nearpay.sdk.utils.enums.TransactionData
import io.nearpay.sdk.utils.enums.UIPosition
import io.nearpay.sdk.utils.listeners.BitmapListener
import io.nearpay.sdk.utils.listeners.GetTransactionListener
import io.nearpay.sdk.utils.listeners.PurchaseListener
import io.nearpay.sdk.utils.listeners.RefundListener
import io.nearpay.sdk.utils.listeners.SetupListener
import io.nearpay.sdk.utils.toImage
import io.nearpay.sdk.utils.toJson
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.util.UUID
import javax.inject.Inject

class OrderActivity : BaseActivity<ActivityOrderBinding, OrderViewModel>(), PaymentTypeDialog.PaymentTypeDialogListener,
    HasAndroidInjector {

    private val TAG = "CartActivity"

    override val layoutId: Int
        get() = R.layout.activity_order

    override val viewModel: OrderViewModel
        get() {
            return getViewModel(OrderViewModel::class.java)
        }

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    lateinit var ordersAdapter: OrdersAdapter

    var updatedOrderItems : ArrayList<OrderItem> = arrayListOf()

    private var selectPaymentType:String = AppConstants.PAYMENT_TYPE_POS
    private var selectPrintReceipt:String = "YES"

    private var selectedOrder : OrderHistoryData? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        initUI()
    }

    private fun initUI(){
        initToolbar()
        initRecyclerView()

        getOrderHistory()
    }

    private fun getOrderHistory() {
        viewDataBinding!!.progressBar.visibility = View.VISIBLE
        viewModel.getOrders(object :
            HandleResponse<OrderHistoryResponse> {

            override fun handleSuccessResponse(response: OrderHistoryResponse) {
                viewDataBinding!!.progressBar.visibility = View.GONE
                if (response.status) {
                    setOrderHistory(response.orders)
                } else {
                    Toast.makeText(
                        this@OrderActivity,
                        response.message.toString(),
                        Toast.LENGTH_SHORT
                    ).show()
                }

                selectedOrder = null
                Log.d("TAG", "getOrdersSuccessResponse: "+response.message.toString())
            }

            override fun handleErrorResponse(error: ErrorResponse) {
                viewDataBinding!!.progressBar.visibility = View.GONE
                Log.d("TAG", "getOrdersErrorResponse: "+error.message.toString())
                Toast.makeText(this@OrderActivity, error.message.toString() + "", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun initToolbar(){
        viewDataBinding?.toolbar?.apply {
            ivBack.setOnClickListener {
                finish()
            }

            tvTitle.text = this@OrderActivity.resources.getString(R.string.str_order_history)
        }
    }

    private fun initRecyclerView(){
        viewDataBinding?.recyclerView?.apply {
            layoutManager = LinearLayoutManager(this@OrderActivity)
            isNestedScrollingEnabled = false
            setHasFixedSize(true)
//            adapter = ordersAdapter
        }
    }

    // Set the order items
    private fun setOrderHistory(orders : ArrayList<OrderHistoryData>){
        ordersAdapter = OrdersAdapter(this,
                                            orders,
                                            {order -> printReceipt(order)},
                                            {order -> printInvoice(order)},
                                            {order -> payOrder(order)},
                                            {order -> refundOrder(order)})
        viewDataBinding?.recyclerView?.adapter = ordersAdapter
    }

    // Pay for pending order
    private fun payOrder(order : OrderHistoryData){
        selectedOrder = order
        PaymentTypeDialog.openDialog(this, this, order.retailerId, false, order.totalWithVat)
    }

    // Refund order
    private fun refundOrder(order : OrderHistoryData){
        val customerReferenceNumber = "9ace70b7-977d-4094-b7f4-4ecb17de6751"; // [optional] any number you want to add as a reference
        val enableReceiptUi = true // [optional] true will enable the ui and false will disable
        val enableReversal = true // it will allow you to enable or disable the reverse button
        val enableEditableRefundAmountUi = true // [optional] true will enable the ui and false will disable
        val finishTimeOut : Long = 10 // Add the number of seconds
        val transactionId = UUID.randomUUID(); // [optional] You can add your UUID here which allows you to ask about the transaction again using the same UUID
        val enableUiDismiss = true // [optional] it will allow you to control dismissing the UI
        val adminPin = "0000"; //[optional] when you add the admin pin here , the UI for admin pin won't be shown.

        if (nearPay == null)
            initNearPayInstance()

        nearPay!!.refund((order.totalWithVat * 100f).toLong(), order.transactionUuid, customerReferenceNumber, enableReceiptUi, enableReversal, enableEditableRefundAmountUi, finishTimeOut, transactionId, adminPin, enableUiDismiss, object :
            RefundListener {
            override fun onRefundApproved(transactionData: TransactionData) {
                // Print the Refund receipt
                if (transactionData.receipts != null) {
                    val receipt = transactionData.receipts!![0]
                    receipt.toImage(this@OrderActivity, 300, 24, BitmapListener {
                        PrintHelper.printReceiptBitmap(this@OrderActivity, it)
                    })
                }

                // Call the Refund Order api
                sendRefundOrder(order.id)
            }
            override fun onRefundFailed(refundFailure: RefundFailure) {
                when (refundFailure) {
                    is RefundFailure.RefundDeclined -> {
                        // when the refund is declined
                        showPaymentErrorMessage("Refund is declined")
                    }
                    is RefundFailure.RefundRejected -> {
                        // when the refund is rejected
                        showPaymentErrorMessage("Refund is rejected")
                    }
                    is RefundFailure.AuthenticationFailed -> {
                        // when the Authentication is failed
                        // You can use the following method to update your JWT
                        showPaymentErrorMessage("Authentication is failed")
                    }
                    is RefundFailure.InvalidStatus -> {
                        // you can get the status using refundFailure.status
                        showPaymentErrorMessage("Invalid status")
                    }
                    is RefundFailure.GeneralFailure -> {
                        // when there is general error.
                        showPaymentErrorMessage("General error")
                    }
                }
            }
        })
    }

    private fun sendRefundOrder(orderId : Int){
        viewDataBinding!!.progressBar.visibility = View.VISIBLE

        val requestJson = JSONObject()
        requestJson.put("order_id", orderId)

        val body: RequestBody = RequestBody.create(
            "application/json; charset=utf-8".toMediaTypeOrNull(),
            requestJson.toString()
        )

        viewModel.refundOrder(body, object : HandleResponse<RefundResponse> {
            override fun handleErrorResponse(error: ErrorResponse) {
                viewDataBinding!!.progressBar.visibility = View.GONE

                Toast.makeText(this@OrderActivity, error.message + "", Toast.LENGTH_SHORT).show()
            }

            override fun handleSuccessResponse(response: RefundResponse) {
                viewDataBinding!!.progressBar.visibility = View.GONE

                if (response.status) {
                    // Refresh the order history
                    getOrderHistory()
                }
                else{
                    Toast.makeText(this@OrderActivity, response.message, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    // Print the invoice
    private fun printInvoice(order : OrderHistoryData){
        PrintHelper.printOrderHistoryInvoice(this, order)
    }

    private fun printReceipt(receiptBitmap : Bitmap?, orderData : SellOrderData){
        if (receiptBitmap != null){
            PrintHelper.printNearPayReceipt(this, receiptBitmap, orderData, selectedOrder!!.orderItems)

            selectedOrder = null
        }
    }

    // Print the receipt
    private fun printReceipt(order : OrderHistoryData){
        // Create the singleton of NearPay to use wherever we need
        if (nearPay == null)
            initNearPayInstance()

        if (PreferenceManager.isInitiatedNearPay) {
            getTransaction(order)
        }
        else{
            initNearPay(order)
        }
    }

    // Init NearPay SDK
    private fun initNearPay(order : OrderHistoryData, isGetTransaction : Boolean = true, retailerId: Int? = null){
        nearPay!!.setup(object : SetupListener {
            override fun onSetupCompleted() {
                // if you wish to get the receipt in Json format use nearPay.toJson()
                PreferenceManager.isInitiatedNearPay = true
                if (isGetTransaction) {
                    getTransaction(order)
                }
                else if (selectedOrder != null && retailerId != null){
                    pay((selectedOrder!!.totalWithVat * 100f).toLong(), retailerId)
                }
            }
            override fun onSetupFailed(setupFailure: SetupFailure) {
                when (setupFailure) {
                    is SetupFailure.AlreadyInstalled -> {
                        // when the payment plugin is already installed.
                        PreferenceManager.isInitiatedNearPay = true

                        if (isGetTransaction) {
                            getTransaction(order)
                        }
                        else if (selectedOrder != null && retailerId != null){
                            pay((selectedOrder!!.totalWithVat * 100f).toLong(), retailerId)
                        }
                    }
                    is SetupFailure.NotInstalled -> {
                        // when the installation failed.
                        showPaymentErrorMessage("Plugin installation failed!")
                    }
                    is SetupFailure.AuthenticationFailed -> {
                        // when the authentication failed.
                        // You can use the following method to update your JWT
                        showPaymentErrorMessage("Authentication failed!")
                    }
                    is SetupFailure.InvalidStatus -> {
                        // Please note that you can get the status using setupFailure.status
                        // you can get the status using the following code
                        val status: List<StatusCheckError> = (setupFailure as SetupFailure.InvalidStatus).status
                        var errMsg = ""
                        for (statusCheckError in status) {
                            errMsg = errMsg + statusCheckError.toString() + "\n"
                        }

                        val finalErrMsg = errMsg
                        showPaymentErrorMessage("Invalid status : $finalErrMsg")
                    }
                }
            }
        })
    }

    // Get the transaction data from NearPay SDK
    private fun getTransaction(order : OrderHistoryData){
//        val uid = "5cca70b7-347d-4456-b7f4-4ecb17de6753";

        nearPay!!.getTransactionByUuid(order.transactionUuid ?: "", object : GetTransactionListener {
            override fun onSuccess(transactionData: TransactionData) {
                if (transactionData.receipts != null) {
                    val receipt = transactionData.receipts!![0]
                    receipt.toImage(this@OrderActivity, 300, 24, BitmapListener {
                        PrintHelper.printNearPayReceipt(this@OrderActivity, it, order)
                    })
                }
                else{
                    runOnUiThread {
                        Toast.makeText(
                            this@OrderActivity,
                            "Sorry, failed to get transaction data.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
            override fun onFailure(getDataFailure: GetDataFailure) {
                when (getDataFailure) {
                    is GetDataFailure.AuthenticationFailed -> {
                        // when the Authentication is failed
                    }
                    is GetDataFailure.FailureMessage -> {
                        // when there is FailureMessage
                    }
                    is GetDataFailure.GeneralFailure -> {
                        // when there is general error
                    }
                    is GetDataFailure.InvalidStatus -> {
                        // you can get the status using reconcileFailure.status
                    }
                }
            }
        })
    }

    // Init the order items including section hearer
    private fun initUpdateOrderItems(orderList : ArrayList<OrderHistoryData>){
        updatedOrderItems = ArrayList()
        for (order in orderList){
            val orderItem = OrderItem()
            orderItem.orderId = order.id

            if (updatedOrderItems.isNotEmpty() && updatedOrderItems.last().productId == null) {
                updatedOrderItems.removeAt(updatedOrderItems.size - 1)
            }

            updatedOrderItems.add(orderItem)

            for (item in order.orderItems) {
                updatedOrderItems.add(item)
            }
        }
    }

    private fun printQrcodeForCashPay(order : SellOrderData){
        Log.d(TAG, "Cash Qrcode : "+ order.qrCode)
        PrintHelper.printInvoice(
            this,
            order.id,
            order.retailerId,
            order.updatedAt,
            order.total,
            order.vat,
            order.totalWithVat,
            order.qrCode,
            selectedOrder!!.orderItems
        )

        selectedOrder = null
    }

    private fun sellOrder(receiptBmp : Bitmap?, receiptJson : String?, retailerId: Int) {
        viewDataBinding!!.progressBar.visibility = View.VISIBLE
        val productsArray = JSONArray()
        try {
            selectedOrder!!.orderItems.forEachIndexed { index, item ->
                println("index = $index, item = $item ")
                val productsJson = JSONObject()
                productsJson.put("product_id", item.productId ?: 0)
                productsJson.put("selling_price", item.sellingPrice)
                productsJson.put("quantity", item.quantity)
                productsArray.put(productsJson)
            }
        } catch (e: JSONException) {
            e.printStackTrace()
        }

        val payType = if (selectPaymentType == AppConstants.PAYMENT_TYPE_CASH) "cash" else "pos"
        val requestJson = JSONObject()
        requestJson.put("payment_type", payType)
        requestJson.put("products", productsArray)
        requestJson.put("retailer_id", retailerId)

        if (selectedOrder != null) {
            requestJson.put("order_id", selectedOrder!!.id)
        }

        if (selectPaymentType != AppConstants.PAYMENT_TYPE_CASH && receiptJson != null) {
            requestJson.put("payment_object", receiptJson)
        }

        val body: RequestBody = RequestBody.create(
            "application/json; charset=utf-8".toMediaTypeOrNull(),
            requestJson.toString()
        )

        viewModel.sellOrder(body,object :
            HandleResponse<SellOrderResponse> {

            override fun handleSuccessResponse(response: SellOrderResponse) {
                viewDataBinding!!.progressBar.visibility = View.GONE

                if (response.status) {
                    Toast.makeText(this@OrderActivity, response.message, Toast.LENGTH_SHORT).show()

                    // Print the receipt/invoice
                    if (selectPaymentType == AppConstants.PAYMENT_TYPE_CASH) {
                        // Print the qrcode
                        printQrcodeForCashPay(response.orderData!!)
                    }
                    else{
                        // Print the Receipt from NearPay SDK
                        printReceipt(receiptBmp, response.orderData!!)
                    }

                    selectedOrder = null

                    // Refresh the order history
                    getOrderHistory()
                }
                else {
                    Toast.makeText(this@OrderActivity, response.message, Toast.LENGTH_SHORT).show()
                }
                Log.d(TAG, "sellOrderSuccessResponse: "+response.message)
            }

            override fun handleErrorResponse(error: ErrorResponse) {
                viewDataBinding!!.progressBar.visibility = View.GONE

                Log.d(TAG, "sellOrderErrorResponse: "+error.message)
                Toast.makeText(this@OrderActivity, error.message + "", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun pay(amount : Long, retailerId: Int){
        val customerReferenceNumber = "9ace70b7-977d-4094-b7f4-4ecb17de6753" //[optional] any number you want to add as a reference
        val enableReceiptUi = true// [optional] true will enable the ui and false will disable
        val enableReversal = true // it will allow you to enable or disable the reverse button
        val finishTimeOut : Long = 20 // Add the number of seconds
        val transactionId = UUID.randomUUID(); // [optional] You can add your UUID here which allows you to ask about the transaction again using the same UUID
        val enableUiDismiss = true // [optional] it will allow you to control dismissing the UI

        nearPay!!.purchase(amount, customerReferenceNumber, enableReceiptUi, enableReversal, finishTimeOut, transactionId, enableUiDismiss, object :
            PurchaseListener {
            override fun onPurchaseApproved(transactionData: TransactionData) {
                // Check if we need to print the receipt
                if (selectPrintReceipt == "YES") {
                    // Get the order receipt
                    if (transactionData.receipts != null) {
                        val receipt = transactionData.receipts!![0]
                        val receiptJson = receipt.toJson()
                        receipt.toImage(this@OrderActivity, 300, 24, BitmapListener {
                            selectPaymentType = AppConstants.PAYMENT_TYPE_POS
                            sellOrder(it, receiptJson, retailerId)
                        })
                    }
                }
                else{
                    selectPaymentType = AppConstants.PAYMENT_TYPE_POS
                    sellOrder(null, null, retailerId)
                }
            }
            override fun onPurchaseFailed(purchaseFailure: PurchaseFailure) {
                when (purchaseFailure) {
                    is PurchaseFailure.PurchaseDeclined -> {
                        // when the payment declined.
                        showPaymentErrorMessage("The payment declined")
                    }
                    is PurchaseFailure.PurchaseRejected -> {
                        // when the payment is rejected .
                        showPaymentErrorMessage("The payment is rejected")
                    }
                    is PurchaseFailure.AuthenticationFailed -> {
                        // when the authentication failed .
                        // You can use the following method to update your JWT
                        showPaymentErrorMessage("The authentication failed")
                    }
                    is PurchaseFailure.InvalidStatus -> {
                        // Please note that you can get the status using purchaseFailure.status
                        TODO("Your Code Here")
                    }
                    is PurchaseFailure.GeneralFailure -> {
                        // when there is General error .
                        showPaymentErrorMessage("General Error")
                    }
                }
            }
        })
    }

    /**
     * PaymentTypeDialog Listener
     */
    override fun onPay(type: String, isPrintReceipt: String, retailerId: Int, discountPercent : Double?, discountFixed : Double?) {
        // TODO("Not yet implemented")
        selectPaymentType = type
        selectPrintReceipt = isPrintReceipt

        if (selectPaymentType == AppConstants.PAYMENT_TYPE_CASH) {
            sellOrder(null, null, retailerId)
        }
        else{
            if (PreferenceManager.isInitiatedNearPay) {
                // Pay via SDK
                pay((selectedOrder!!.totalWithVat * 100f).toLong(), retailerId)
            }
            else{
                // Initialize the NearPay SDK
                if (nearPay == null)
                    initNearPayInstance()

                if (selectedOrder != null)
                    initNearPay(selectedOrder!!, false, retailerId)
            }
        }
    }
}