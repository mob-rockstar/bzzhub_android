package com.gexpo.gsp.data.model.refund

import com.google.gson.annotations.SerializedName

class RefundData {
    @field:SerializedName("id")
    var id: Int = 0

    @field:SerializedName("retailer_id")
    var retailerId: Int = 0

    @field:SerializedName("tcn")
    var tcn : String = ""

    @field:SerializedName("total")
    var total : Double = 0.0

    @field:SerializedName("vat")
    var vat: Double = 0.0

    @field:SerializedName("total_afterr_vat")
    var totalWithVat: Double = 0.0

    @field:SerializedName("updated_at")
    var updatedAt: String? = null

    @field:SerializedName("created_at")
    var createdAt: String? = null

    @field:SerializedName("status")
    var status: String = ""

    @field:SerializedName("payment_type")
    var paymentType: String = ""

    @field:SerializedName("discount_type")
    var discountType: String = ""

    @field:SerializedName("discount")
    var discount: String = ""
}