package com.gexpo.gsp.ui.component.easyImage

enum class ChooserType {
    CAMERA_AND_GALLERY, CAMERA_AND_DOCUMENTS
}