package com.gexpo.gsp.ui.splash

import com.gexpo.gsp.base.BaseViewModel

class SplashViewModel : BaseViewModel() {
}