package com.gexpo.gsp.data.model.base

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import jo.basket.data.model.api.response.base.ErrorsMessages


open class ErrorResponse : BaseResponse {

    @SerializedName("data")
    @Expose
    var errorsMessages: ErrorsMessages? = null

    constructor()
}