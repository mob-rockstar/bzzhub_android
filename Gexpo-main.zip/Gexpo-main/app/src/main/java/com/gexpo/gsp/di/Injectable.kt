package com.gexpo.gsp.di

interface Injectable