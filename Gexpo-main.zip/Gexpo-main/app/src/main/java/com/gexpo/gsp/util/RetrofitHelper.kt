package com.marriagebiodata.makerwq.ApiCall

import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class RetrofitHelper {

    var retrofit: Retrofit? = null

    public fun getClient(): Retrofit? {
        val interceptor: Interceptor = HttpLoggingInterceptor()
        (interceptor as HttpLoggingInterceptor).setLevel(HttpLoggingInterceptor.Level.BODY)
        val client = OkHttpClient.Builder().addInterceptor(interceptor).build()
        retrofit = Retrofit.Builder()
            .baseUrl("http://167.71.214.193/api/")
            .addConverterFactory(GsonConverterFactory.create())
            .client(client)
            .build()
        return retrofit
    }
}