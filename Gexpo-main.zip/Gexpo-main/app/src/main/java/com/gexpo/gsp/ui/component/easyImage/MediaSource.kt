package com.gexpo.gsp.ui.component.easyImage

enum class MediaSource {
    GALLERY, DOCUMENTS, CAMERA_IMAGE, CAMERA_VIDEO, CHOOSER
}