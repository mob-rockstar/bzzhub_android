package com.gexpo.gsp.data.model.login

import com.google.gson.annotations.SerializedName

class LoginResponse {


    @SerializedName("status"  ) var status  : Boolean? = null
    @SerializedName("message" ) var message : String?  = null
    @SerializedName("data"    ) var data    : Data?    = Data()


    data class ActiveProducts (

        @SerializedName("id"           ) var id          : Int?    = null,
        @SerializedName("arabic_name"  ) var arabicName  : String? = null,
        @SerializedName("english_name" ) var englishName : String? = null,
        @SerializedName("price"        ) var price       : Double?    = null,
        @SerializedName("created_at"   ) var createdAt   : String? = null,
        @SerializedName("updated_at"   ) var updatedAt   : String? = null,
        @SerializedName("deleted_at"   ) var deletedAt   : String? = null,
        @SerializedName("category_id"  ) var categoryId  : Int?    = null,
        @SerializedName("retailer_id"  ) var retailerId  : Int?    = null,
        @SerializedName("quantity"     ) var quantity    : Int?    = null,
        @SerializedName("code"         ) var code        : String? = null,
        @SerializedName("status"       ) var status      : String? = null,
        @SerializedName("photo")         var photo       : String? = null

    )
    data class Data (

        @SerializedName("id"              ) var id             : Int?                      = null,
        @SerializedName("name"            ) var name           : String?                   = null,
        @SerializedName("cr_number"       ) var crNumber       : String?                   = null,
        @SerializedName("nationality"     ) var nationality    : String?                   = null,
        @SerializedName("email"           ) var email          : String?                   = null,
        @SerializedName("mobile"          ) var mobile         : String?                   = null,
        @SerializedName("created_at"      ) var createdAt      : String?                   = null,
        @SerializedName("updated_at"      ) var updatedAt      : String?                   = null,
        @SerializedName("deleted_at"      ) var deletedAt      : String?                   = null,
        @SerializedName("token"           ) var token          : String                    = "",
        @SerializedName("active_products" ) var activeProducts : ArrayList<ActiveProducts> = arrayListOf(),
        @SerializedName("payment_token")    var paymentToken   : String?                   = null,
        @SerializedName("can_refund")       var canRefund      : Int                       = 0

    )
}