package com.gexpo.gsp.data.model.Product

import com.gexpo.gsp.base.BaseViewModel
import com.google.gson.annotations.SerializedName

class ProductListResponse : BaseViewModel() {

    @SerializedName("status"  ) var status  : Boolean?        = null
    @SerializedName("message" ) var message : String?         = null
    @SerializedName("data"    ) var data    : ArrayList<ActiveProducts> = arrayListOf()

    data class ActiveProducts (

        @SerializedName("id"           ) var id          : Int?    = null,
        @SerializedName("arabic_name"  ) var arabicName  : String  = "",
        @SerializedName("english_name" ) var englishName : String  = "",
        @SerializedName("price"        ) var price       : Double? = null,
        @SerializedName("created_at"   ) var createdAt   : String? = null,
        @SerializedName("updated_at"   ) var updatedAt   : String? = null,
        @SerializedName("deleted_at"   ) var deletedAt   : String? = null,
        @SerializedName("category_id"  ) var categoryId  : Int?    = null,
        @SerializedName("retailer_id"  ) var retailerId  : Int?    = null,
        @SerializedName("quantity"     ) var quantity    : Int?    = null,
        @SerializedName("code"         ) var code        : String? = null,
        @SerializedName("status"       ) var status      : String? = null,
        @SerializedName("photo")         var photo       : String? = null

    )

}