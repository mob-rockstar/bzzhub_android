package com.gexpo.gsp.ui.splash

import android.Manifest.permission.CAMERA
import android.Manifest.permission.READ_EXTERNAL_STORAGE
import android.Manifest.permission.WRITE_EXTERNAL_STORAGE
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Build.VERSION.SDK_INT
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.provider.Settings
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.gexpo.gsp.R
import com.gexpo.gsp.base.BaseActivity
import com.gexpo.gsp.data.local.PreferenceManager
import com.gexpo.gsp.databinding.ActivitySplashBinding
import com.gexpo.gsp.ui.main.MainActivity
import com.gexpo.gsp.ui.signin.LoginActivity
import com.gexpo.gsp.util.AppConstants.REQUEST_VALUE_PERMISSION_SETTINGS
import com.permissionx.guolindev.PermissionX
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import io.realm.Realm
import io.realm.RealmConfiguration
import javax.inject.Inject


class SplashActivity : BaseActivity<ActivitySplashBinding, SplashViewModel>(), HasAndroidInjector {

    override val layoutId: Int
        get() = R.layout.activity_splash

    override val viewModel: SplashViewModel
        get() {
            return getViewModel(SplashViewModel::class.java)
        }

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    var handler: Handler = Handler()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        initView()
//        initRealm()

        checkPermission()
    }

    private fun initView() {
        viewDataBinding!!.tvVersion.text =
            resources.getString(
                R.string.str_version_with_number,
                packageManager.getPackageInfo(packageName, 0).versionName
            )
    }

    private fun initRealm(){
        Realm.init(this)

        val configuration = RealmConfiguration.Builder()
            .name("cart.db")
            .deleteRealmIfMigrationNeeded()
            .schemaVersion(0)
            .allowWritesOnUiThread(true)
            .allowQueriesOnUiThread(true)
            .build()

        Realm.setDefaultConfiguration(configuration)
    }

    private fun gotoNextActivity(){
        handler.postDelayed({
            if (PreferenceManager.loggedInMode == PreferenceManager.LoggedInMode.LOGGED_IN_MODE_LOGGED_OUT)
            openLoginActivity() else openMainActivity()
            finish()
        }, 1500)
    }

    private fun openLoginActivity(){
        val intent = Intent(this@SplashActivity, LoginActivity::class.java)
        startActivity(intent)
    }

    private fun openMainActivity(){
        val intent = Intent(this@SplashActivity, MainActivity::class.java)
        startActivity(intent)
    }

    private fun checkPermission(){
        if (SDK_INT >= 30){
            requestPermission()
        }else{
            // Download the theme icons
            PermissionX.init(this@SplashActivity)
                .permissions(
                    READ_EXTERNAL_STORAGE,
                    WRITE_EXTERNAL_STORAGE,
                    CAMERA,
                )
                .request { allGranted, _, deniedList ->

                    //    downloadFile(defaultThemeId, AppConstants.FILE_TYPE_IMAGE)
                    if (allGranted) {
                        gotoNextActivity()
                    } else {
                        Toast.makeText(
                            this,
                            "These permissions are denied: $deniedList",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
        }
    }

    private fun requestPermission() {
        if (SDK_INT >= Build.VERSION_CODES.R) {
            if(!Environment.isExternalStorageManager()){
                try {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                    intent.addCategory("android.intent.category.DEFAULT")
                    intent.data = Uri.parse(String.format("package:%s", applicationContext.packageName))
                    startActivityForResult(intent, REQUEST_VALUE_PERMISSION_SETTINGS)
                } catch (e: Exception) {
                    val intent = Intent()
                    intent.action = Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION
                    startActivityForResult(intent, REQUEST_VALUE_PERMISSION_SETTINGS)
                }
            }else{
                gotoNextActivity()
            }
        } else {
            //below android 11
            ActivityCompat.requestPermissions(
                this@SplashActivity,
                arrayOf(WRITE_EXTERNAL_STORAGE, READ_EXTERNAL_STORAGE, CAMERA),
                REQUEST_VALUE_PERMISSION_SETTINGS
            )
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int,  data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_VALUE_PERMISSION_SETTINGS) {
            if (SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    gotoNextActivity()
                } else {
                   requestPermission()
                }
            }
        }
    }


}