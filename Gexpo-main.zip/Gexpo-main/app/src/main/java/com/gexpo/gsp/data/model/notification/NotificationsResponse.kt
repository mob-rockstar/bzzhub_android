package com.gexpo.gsp.data.model.notification

import com.gexpo.gsp.base.BaseViewModel
import com.google.gson.annotations.SerializedName

class NotificationsResponse : BaseViewModel() {

    @SerializedName("status"  ) var status  : Boolean?        = null
    @SerializedName("message" ) var message : String?         = null
    @SerializedName("data"    ) var data    : ArrayList<Data> = arrayListOf()

    data class Data (

        @SerializedName("id"                 ) var id                : Double?    = null,
        @SerializedName("type"               ) var type              : String? = null,
        @SerializedName("notifiable_type"    ) var notifiableType    : String? = null,
        @SerializedName("notifiable_id"      ) var notifiableId      : Int?    = null,
        @SerializedName("data"               ) var data              : String? = null,
        @SerializedName("read_at"            ) var readAt            : String? = null,
        @SerializedName("created_at"         ) var createdAt         : String? = null,
        @SerializedName("updated_at"         ) var updatedAt         : String? = null,
        @SerializedName("agoArabic"          ) var agoArabic         : String? = null,
        @SerializedName("arabic_title"       ) var arabicTitle       : String? = null,
        @SerializedName("title"              ) var title             : String? = null,
        @SerializedName("arabic_description" ) var arabicDescription : String? = null,
        @SerializedName("description"        ) var description       : String? = null,
        @SerializedName("ago"                ) var ago               : String? = null

    )
}