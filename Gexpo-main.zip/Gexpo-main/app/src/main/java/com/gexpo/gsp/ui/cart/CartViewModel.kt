package com.gexpo.gsp.ui.cart

import com.gexpo.gsp.base.BaseViewModel

class CartViewModel : BaseViewModel() {
}