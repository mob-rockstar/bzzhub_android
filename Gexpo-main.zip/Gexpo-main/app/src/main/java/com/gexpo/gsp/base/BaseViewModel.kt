package com.gexpo.gsp.base

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.gexpo.gsp.network.ApiClient
import com.gexpo.gsp.network.Repository
import io.reactivex.disposables.CompositeDisposable


abstract class BaseViewModel : ViewModel() {
//    var repository : Repository = Repository(ApiClient.apiService!!)

    private var _isLoading = MutableLiveData<Boolean>()
    val isLoading : LiveData<Boolean> get() = _isLoading

    var compositeDisposable = CompositeDisposable()

    fun setLoading(mLoading: Boolean){
        _isLoading.postValue(mLoading)
    }

    override fun onCleared() {
        compositeDisposable.dispose()
        super.onCleared()
    }


}