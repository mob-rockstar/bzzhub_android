package com.gexpo.gsp.ui.orders

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.gexpo.gsp.R
import com.gexpo.gsp.base.BaseRecyclerViewAdapter
import com.gexpo.gsp.data.local.PreferenceManager
import com.gexpo.gsp.data.model.history.OrderHistoryData
import com.gexpo.gsp.data.model.history.OrderItem
import com.gexpo.gsp.databinding.RecyclerItemDividerOlderOrdersBinding
import com.gexpo.gsp.databinding.RecyclerItemOrdersBinding
import com.gexpo.gsp.util.AppConstants
import java.text.DecimalFormat

class OrdersAdapter (val context: Context,
                     var orderList: ArrayList<OrderHistoryData>,
                     val onPrintOrderReceipt : (order: OrderHistoryData) -> Unit,
                     val onPrintOrderInvoice : (order : OrderHistoryData) -> Unit,
                     val onPay: (order : OrderHistoryData) -> Unit,
                     val onRefund : (order : OrderHistoryData) -> Unit
) : BaseRecyclerViewAdapter<String, RecyclerItemOrdersBinding>() {

    override val layoutId: Int
        get() = R.layout.recycler_item_orders

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            VIEW_TYPE_NORMAL_ITEM -> {
                val binding = createBindView(viewGroup)
                return OrderItemViewHolder(binding)
            }

            else -> {
                OlderOrderDividerViewHolder(
                    DataBindingUtil.inflate(
                        LayoutInflater.from(viewGroup.context),
                        R.layout.recycler_item_divider_older_orders,
                        viewGroup,
                        false
                    )
                )
            }
        }
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (getItemViewType(position)){
            VIEW_TYPE_NORMAL_ITEM -> {
                val orderHolder = holder as OrderItemViewHolder
                // Get order and order items
                val order = orderList[position]

                orderHolder.binding.apply {
                    tvOrderNo.text = "${context.resources.getString(R.string.str_order_number)} ${order.id}"
                    tvTcn.text = order.tcn
                    tvDate.text = order.updatedAt
                    tvPrice.text = "SAR ${formatPrice(order.totalWithVat)}"

                    tvPrintReceipt.visibility = if (order.transactionUuid == null) GONE else VISIBLE

                    // Print receipt
                    tvPrintReceipt.setOnClickListener {
                        onPrintOrderReceipt(order)
                    }

                    // Print invoice
                    tvPrintInvoice.setOnClickListener {
                        onPrintOrderInvoice(order)
                    }

                    // Pay
                    tvPay.setOnClickListener{
                        onPay(order)
                    }

                    // Refund
                    tvRefund.setOnClickListener {
                        onRefund(order)
                    }

                    //Payment Type
                    if (order.paymentType != null) {
                        tvPaymentType.visibility = VISIBLE
                        if (order.paymentType == "pos") {
                            tvPaymentType.text = context.resources.getString(R.string.pos)
                        }
                        else{
                            tvPaymentType.text = context.resources.getString(R.string.cash)
                        }
                    }else {
                        tvPaymentType.visibility = GONE
                    }


                    when (order.status) {
                        AppConstants.PAYMENT_CREATED -> {
                            layoutPrint.visibility = GONE
                            tvPay.visibility = VISIBLE
                            tvRefund.visibility = GONE
                        }
                        AppConstants.PAYMENT_COMPLETED -> {
                            layoutPrint.visibility = VISIBLE
                            if (order.paymentType != null) {
                                if (order.paymentType == "cash") {
                                    tvPrintReceipt.visibility = GONE
                                    tvRefund.visibility = GONE
                                }
                                else{
                                    tvPrintReceipt.visibility = VISIBLE
                                    if (PreferenceManager.canRefund == 1) {
                                        tvRefund.visibility = VISIBLE
                                    }
                                    else{
                                        tvRefund.visibility = GONE
                                    }
                                }
                            }
                            else{
                                tvRefund.visibility = GONE
                            }

                            tvPay.visibility = GONE
                        }
                        else -> {
                            layoutPrint.visibility = GONE
                            tvPay.visibility = GONE
                            tvRefund.visibility = GONE
                        }
                    }
                }
            }
        }
    }

    override fun getItemCount(): Int {
        return orderList.size
    }

    override fun getItemViewType(position: Int): Int {
        return VIEW_TYPE_NORMAL_ITEM

//        return when (position) {
//            1 -> VIEW_TYPE_ORDER_SECTION
//            else -> VIEW_TYPE_NORMAL_ITEM
//        }
    }

    inner class OrderItemViewHolder(val binding: RecyclerItemOrdersBinding) :
        RecyclerView.ViewHolder(binding.root)

    inner class OlderOrderDividerViewHolder(val binding: RecyclerItemDividerOlderOrdersBinding) :
        RecyclerView.ViewHolder(binding.root)

    companion object {
        const val VIEW_TYPE_NORMAL_ITEM = 0
        const val VIEW_TYPE_ORDER_SECTION = 1
    }

    private fun formatPrice(price: Double?): String {
        val decimalFormat = DecimalFormat("0.00")
        return decimalFormat.format(price ?: 0)
    }
}