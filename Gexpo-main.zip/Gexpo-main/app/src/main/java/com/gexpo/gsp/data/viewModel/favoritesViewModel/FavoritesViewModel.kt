package com.gexpo.gsp.data.viewModel.favoritesViewModel
import com.gexpo.gsp.base.BaseViewModel
import com.gexpo.gsp.network.ApiClient
import com.gexpo.gsp.network.HandleResponse
import com.gexpo.gsp.network.NetworkUtils.getThrowableError
import com.gexpo.gsp.data.model.Product.ProductListResponse
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class FavoritesViewModel : BaseViewModel() {

    fun addToFavorite(id: String,handleResponse: HandleResponse<ProductListResponse>) {
        compositeDisposable.add(ApiClient.addToFav(id)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
//                        setIsLoading(false)
                        handleResponse.handleSuccessResponse(result)
                    }
                },
                { x ->
                    run {
//                        setIsLoading(false)
                        getThrowableError(x)?.let { handleResponse.handleErrorResponse(it) }
                    }
                }
            ))
    }

    fun removeFromFav(id: String,handleResponse: HandleResponse<ProductListResponse>) {
        compositeDisposable.add(ApiClient.removeFromFav(id)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
//                        setIsLoading(false)
                        handleResponse.handleSuccessResponse(result)
                    }
                },
                { x ->
                    run {
//                        setIsLoading(false)
                        getThrowableError(x)?.let { handleResponse.handleErrorResponse(it) }
                    }
                }
            ))
    }

    fun getFavorites(handleResponse: HandleResponse<ProductListResponse>) {
        compositeDisposable.add(ApiClient.getFavorites()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
//                        setIsLoading(false)
                        handleResponse.handleSuccessResponse(result)
                    }
                },
                { x ->
                    run {
//                        setIsLoading(false)
                        getThrowableError(x)?.let { handleResponse.handleErrorResponse(it) }
                    }
                }
            ))
    }

}