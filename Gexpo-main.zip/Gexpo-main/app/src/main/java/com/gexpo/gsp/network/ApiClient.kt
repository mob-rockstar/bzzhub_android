package com.gexpo.gsp.network

import android.content.Context
import com.gexpo.gsp.data.local.PreferenceManager
import com.gexpo.gsp.data.model.login.LoginResponse
import com.gexpo.gsp.data.model.Product.ProductListResponse
import com.gexpo.gsp.data.model.base.BaseResponse
import com.gexpo.gsp.data.model.history.OrderHistoryResponse
import com.gexpo.gsp.data.model.notification.NotificationsResponse
import com.gexpo.gsp.data.model.order.OrderResponse
import com.gexpo.gsp.data.model.order.SellOrderResponse
import com.gexpo.gsp.data.model.refund.RefundResponse
import com.gexpo.gsp.util.AppConstants
import com.google.gson.GsonBuilder
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import io.reactivex.Single
import okhttp3.Cache
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.RequestBody
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.converter.moshi.MoshiConverterFactory
import java.io.File
import java.util.concurrent.TimeUnit

object ApiClient {

    const val CACHE_FILE_NAME = "iDOX_CACHE_FILE"
    private lateinit var apiInterface: ApiInterface

    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

    fun init(context: Context){
        val cacheFile = File(context.cacheDir, CACHE_FILE_NAME)
        cacheFile.mkdir()
        val cache = Cache(cacheFile, 60 * 1000 * 1000)

        // OKHttp Builder
        val interceptor = HttpLoggingInterceptor()
        interceptor.level = HttpLoggingInterceptor.Level.BODY
        val okHttpBuilder = OkHttpClient.Builder()
            .connectTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
//            .addInterceptor(OAuthInterceptor("Bearer", PreferenceManager.accessToken))
            .cache(cache)
        okHttpBuilder.interceptors().add(interceptor)

        // OKHttp
        val okHttpClient = okHttpBuilder.build()

        val retrofit = Retrofit.Builder()
            .baseUrl(AppConstants.BASE_URL)
            .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
            .addConverterFactory(GsonConverterFactory.create(GsonBuilder().setLenient().create()))
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .client(okHttpClient)
            .build()
        apiInterface = retrofit.create(ApiInterface::class.java)
    }

    fun loginWithPassword(email: String, password: String): Single<LoginResponse> {
        return apiInterface.getLogin(email, password)
    }

    fun getProducts(): Single<ProductListResponse> {
        return apiInterface.getProducts(getBearerToken())
    }
    fun addToFav(id: String): Single<ProductListResponse> {
        return apiInterface.addToFav(id, getBearerToken())
    }
    fun removeFromFav(id: String): Single<ProductListResponse> {
        return apiInterface.removeFromFav(id, getBearerToken())
    }
    fun getFavorites(): Single<ProductListResponse> {
        return apiInterface.getFavorites(getBearerToken())
    }
    fun getNotifications(): Single<NotificationsResponse> {
        return apiInterface.getNotifications(getBearerToken())
    }
    fun sellOrder(products: RequestBody?): Single<SellOrderResponse> {
        return apiInterface.sellOrder(products, getBearerToken())
    }
    fun getOrders(): Single<OrderHistoryResponse> {
        return apiInterface.getOrders(getBearerToken())
    }

    fun createOrder(body: RequestBody?): Single<SellOrderResponse> {
        return apiInterface.createOrder(body, getBearerToken())
    }

    fun refundOrder(body: RequestBody?) : Single<RefundResponse> {
        return apiInterface.refundOrder(body, getBearerToken())
    }

    fun checkRetailer(body: RequestBody?) : Single<BaseResponse>{
        return apiInterface.checkRetailerId(body, getBearerToken())
    }

//    class OAuthInterceptor(private val tokenType: String, private val accessToken: String) :
//        Interceptor {
//        override fun intercept(chain: Interceptor.Chain): okhttp3.Response {
//            var request = chain.request()
//            request =
//                request.newBuilder().header("Authorization", "$tokenType $accessToken").build()
//            return chain.proceed(request)
//        }
//    }

    private fun getBearerToken() : String{
        return "Bearer " + PreferenceManager.accessToken
    }
}