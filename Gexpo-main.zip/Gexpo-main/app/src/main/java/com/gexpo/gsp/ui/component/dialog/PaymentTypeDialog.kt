package com.gexpo.gsp.ui.component.dialog

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import com.gexpo.gsp.R
import com.gexpo.gsp.data.model.Product.ProductListResponse
import com.gexpo.gsp.databinding.PaymentBottomSheetDetailBinding
import com.gexpo.gsp.util.AppConstants
import com.gexpo.gsp.util.PopupUtils

class PaymentTypeDialog {

    lateinit var dialog: Dialog
    var isDialogRunning = false

    private var selectPaymentType:String  = AppConstants.PAYMENT_TYPE_POS
    private var selectPrintReceipt:String = "YES"

    fun openDialog(context: Context, listener: PaymentTypeDialogListener, retailerId: Int? = null, isFromCart : Boolean = true, totalPrice : Double) {
        dialog = Dialog(context)
        val binding: PaymentBottomSheetDetailBinding = DataBindingUtil.inflate(
            LayoutInflater.from(context), R.layout.payment_bottom_sheet_detail, null, false
        )

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(binding.root)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        if (retailerId != null)
            binding.etRetailerId.setText(retailerId.toString())

        if (isFromCart){
            binding.etRetailerId.visibility = View.VISIBLE
            binding.layoutDiscount.visibility = View.VISIBLE
        }
        else{
            binding.etRetailerId.visibility = View.GONE
            binding.layoutDiscount.visibility = View.GONE
        }

        binding.cashClick.setOnClickListener {
            selectPrintReceipt = "YES"
            selectPaymentType = AppConstants.PAYMENT_TYPE_CASH
            binding.cashClick.setTextColor(context.resources.getColor(R.color.white))
            binding.posClick.setTextColor(context.resources.getColor(R.color.color_green_500))
            binding.cashClick.setBackgroundResource(R.drawable.ic_round_green_500_8dp)
            binding.posClick.setBackgroundResource(R.drawable.ic_round_green_border_500_8dp)
            binding.printLayout.visibility = View.GONE
        }

        binding.posClick.setOnClickListener {
            selectPrintReceipt = "YES"
            selectPaymentType = AppConstants.PAYMENT_TYPE_POS
            binding.cashClick.setBackgroundResource(R.drawable.ic_round_green_border_500_8dp)
            binding.posClick.setBackgroundResource(R.drawable.ic_round_green_500_8dp)
            binding.posClick.setTextColor(context.resources.getColor(R.color.white))
            binding.cashClick.setTextColor(context.resources.getColor(R.color.color_green_500))
            binding.printLayout.visibility = View.VISIBLE
        }

        binding.yesClick.setOnClickListener {
            binding.noClick.setBackgroundResource(R.drawable.ic_round_green_border_500_8dp)
            binding.yesClick.setBackgroundResource(R.drawable.ic_round_green_500_8dp)
            binding.yesClick.setTextColor(context.resources.getColor(R.color.white))
            binding.noClick.setTextColor(context.resources.getColor(R.color.color_green_500))

            selectPrintReceipt = "YES"
        }

        binding.noClick.setOnClickListener {
            binding.yesClick.setBackgroundResource(R.drawable.ic_round_green_border_500_8dp)
            binding.noClick.setBackgroundResource(R.drawable.ic_round_green_500_8dp)
            binding.noClick.setTextColor(context.resources.getColor(R.color.white))
            binding.yesClick.setTextColor(context.resources.getColor(R.color.color_green_500))

            selectPrintReceipt = "NO"
        }

        binding.submit.setOnClickListener {
            val retailerId = binding.etRetailerId.text.toString()
            if (retailerId.isNullOrEmpty()) {
                Toast.makeText(context, context.resources.getString(R.string.msg_enter_retailer_id), Toast.LENGTH_SHORT).show()
            }
            else{
                Log.d("Cart", "Retailer Id : $retailerId")
                val discountPercentStr = binding.etPercent.text.toString().trim()
                val discountFixedStr = binding.etFixed.text.toString().trim()

                val discountPercent : Double? = if (discountPercentStr.isNullOrEmpty()) null else discountPercentStr.toDouble()
                val discountFixed : Double? = if (discountFixedStr.isNullOrEmpty()) null else discountFixedStr.toDouble()
                if (discountPercent != null && discountPercent >= 100) {
                    Toast.makeText(context, context.resources.getString(R.string.msg_invalid_percent), Toast.LENGTH_LONG).show()
                    binding.etPercent.setText("")
                    return@setOnClickListener
                }
                else if(discountFixed != null && discountFixed >= totalPrice){
                    Toast.makeText(context, context.resources.getString(R.string.msg_invalid_fixed), Toast.LENGTH_LONG).show()
                    binding.etFixed.setText("")
                    return@setOnClickListener
                }
                else {
                    if (isFromCart) {
                        listener.onPay(selectPaymentType, selectPrintReceipt, retailerId.toIntOrNull() ?: 0, discountPercent, discountFixed)
                    }
                    else{
                        listener.onPay(selectPaymentType, selectPrintReceipt, retailerId.toIntOrNull() ?: 0)
                    }

                    dialog.dismiss()
                }
            }
        }

        PopupUtils.setDefaultDialogProperty(dialog)
        dialog.show()
    }

    companion object {
        private var instance: PaymentTypeDialog? = null
        private val Instance: PaymentTypeDialog
            get() {
                return instance ?: PaymentTypeDialog()
            }

        fun openDialog(
            context: Context,
            listener: PaymentTypeDialogListener,
            retailerId: Int? = null,
            isFromCart: Boolean = true,
            totalPrice: Double
        ) {
            if (!Instance.isDialogRunning) {
                Instance.openDialog(context, listener, retailerId, isFromCart, totalPrice)
            }
        }
    }

    interface PaymentTypeDialogListener {
        fun onPay(type : String, isPrintReceipt : String, retailerId : Int, discountPercent : Double? = null, discountFixed : Double? = null)
    }
}