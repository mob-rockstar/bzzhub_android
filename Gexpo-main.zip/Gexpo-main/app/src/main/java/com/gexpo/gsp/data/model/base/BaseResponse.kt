package com.gexpo.gsp.data.model.base

import com.google.gson.annotations.SerializedName


open class BaseResponse {

    @field:SerializedName("httpCode")
    var code: Int? = 0

    @field:SerializedName("locale")
    var locale: String? = null

    @field:SerializedName("message")
    var message: String = ""

    @field:SerializedName("status")
    var status: Boolean = true

    override fun toString(): String {
        return "BaseResponse(code=$code, locale=$locale, message=$message)"
    }


}
