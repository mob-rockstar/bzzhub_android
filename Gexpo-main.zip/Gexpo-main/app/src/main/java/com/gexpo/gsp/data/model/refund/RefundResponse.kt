package com.gexpo.gsp.data.model.refund

import com.google.gson.annotations.SerializedName
import com.gexpo.gsp.data.model.base.BaseResponse

class RefundResponse : BaseResponse() {
    @SerializedName("data")
    var data : RefundData? = null
}