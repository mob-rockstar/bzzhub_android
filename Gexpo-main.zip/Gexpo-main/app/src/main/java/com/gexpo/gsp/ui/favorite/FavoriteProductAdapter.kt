package com.gexpo.gsp.ui.favorite

import android.content.Context
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.gexpo.gsp.R
import com.gexpo.gsp.base.BaseRecyclerViewAdapter
import com.gexpo.gsp.data.local.PreferenceManager
import com.gexpo.gsp.databinding.RecyclerItemProductMainBinding
import com.gexpo.gsp.data.model.Product.ProductListResponse
import java.text.DecimalFormat

class FavoriteProductAdapter(
    val context: Context,
    var list: ArrayList<ProductListResponse.ActiveProducts>,
    val onProductClick: (product : ProductListResponse.ActiveProducts, isFav : Boolean) -> Unit,
    val onFavClick: (index: Int, isFav: Boolean) -> Unit
) : BaseRecyclerViewAdapter<String, RecyclerItemProductMainBinding>() {
    override val layoutId: Int
        get() = R.layout.recycler_item_product_main

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return ProductViewHolder(createBindView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder: ProductViewHolder = viewHolder as ProductViewHolder

        var isLike = false
        val formattedPrice = formatPrice(list[position].price)


        holder.binding.tvProductName.text =  (if (PreferenceManager.userLanguage == 1) list[position].englishName.toString() else list[position].arabicName.toString())
        holder.binding.tvBarCode.text =  list[position].code.toString()
        holder.binding.tvPrice.text =  "SAR "+ formattedPrice.toString()

        holder.binding.apply {
            ivLike.apply {
                setImageDrawable(
                    ContextCompat.getDrawable(
                        context,
                        R.drawable.ic_heart_fill
                    )
                )
                layoutLike.setOnClickListener {
                    onFavClick(list[position].id!!, isLike)
                    list.removeAt(position)
                    notifyDataSetChanged()
                }
            }

            layoutContent.setOnClickListener {
                onProductClick(list[position], isLike)
            }
        }
    }
    fun formatPrice(price: Double?): String {
        val decimalFormat = DecimalFormat("0.00")
        return "$${decimalFormat.format(price)}"
    }

    override fun getItemCount(): Int {
        return list.size
    }

    inner class ProductViewHolder(val binding: RecyclerItemProductMainBinding) :
        RecyclerView.ViewHolder(binding.root)
}