package com.gexpo.gsp.ui.signin

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.gexpo.gsp.R
import com.gexpo.gsp.base.BaseActivity
import com.gexpo.gsp.data.viewModel.LoginViewModel.LoginViewModel
import com.gexpo.gsp.data.local.PreferenceManager
import com.gexpo.gsp.data.model.base.ErrorResponse
import com.gexpo.gsp.data.model.login.LoginResponse
import com.gexpo.gsp.databinding.ActivityLoginBinding
import com.gexpo.gsp.network.HandleResponse
import com.gexpo.gsp.ui.component.dialog.LanguageListDialog
import com.gexpo.gsp.ui.main.MainActivity
import com.gexpo.gsp.util.AppConstants
import com.gexpo.gsp.util.CommonUtils
import com.gexpo.gsp.util.KeyboardUtils
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import javax.inject.Inject

class LoginActivity : BaseActivity<ActivityLoginBinding, LoginViewModel>(), HasAndroidInjector {

    override val layoutId: Int
        get() = R.layout.activity_login


    override val viewModel: LoginViewModel
        get() {
            return getViewModel(LoginViewModel::class.java)
        }

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    private var strEmail =""
    private var strPassword =""
    private var showPassword = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        initUI()
    }

    private fun initUI(){
        setEyeIcons()
        initLanguageView()
        viewDataBinding?.apply {
            tvSignIn.setOnClickListener {
                initInfoValues()
                KeyboardUtils.hideKeyboard(this@LoginActivity)
                val errorMessage = CommonUtils.validateInfo(this@LoginActivity,strEmail,strPassword)

                if (errorMessage.isEmpty()) login(strEmail,strPassword)
                else showErrorDialog(errorMessage)
            }

            layoutContent.setOnClickListener {
                KeyboardUtils.hideKeyboard(this@LoginActivity)
            }
        }
    }

    private fun initInfoValues(){
        with(viewDataBinding!!){
            strEmail = edittextUserName.text.toString().trim()
            strPassword = edittextPassword.text.toString().trim()
        }
    }

    private fun initLanguageView(){
        viewDataBinding?.apply {
            tvLanguage.text =   this@LoginActivity.resources.getString(if (PreferenceManager.userLanguage == 1) R.string.str_english else R.string.str_arabic)
            layoutLanguage.setOnClickListener {
                LanguageListDialog.openDialog(this@LoginActivity){
                    restartApp(this@LoginActivity)
                }
            }
        }
    }

    private fun login(strEmail: String, strPassword: String) {
//        startMainActivity()
        window.setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)

        getLogin(this, strEmail, strPassword)
    }

    private fun getLogin(loginActivity: LoginActivity, strEmail: String, strPassword: String) {
        viewDataBinding!!.progressBar.visibility = View.VISIBLE
        viewModel.loginWithPassword(strEmail, strPassword, object :
            HandleResponse<LoginResponse> {

            override fun handleSuccessResponse(response: LoginResponse) {
                window.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
                viewDataBinding!!.progressBar.visibility = View.GONE

                if(response.status == true){
                    PreferenceManager.loggedInMode = PreferenceManager.LoggedInMode.LOGGED_IN_MODE_LOGGED_IN

                    // Save the access token
                    PreferenceManager.accessToken = response.data!!.token

                    // Save the payment token
                    PreferenceManager.paymentToken = response.data!!.paymentToken ?: ""
                    PreferenceManager.email = response.data!!.email ?: ""
                    PreferenceManager.name = response.data!!.name ?: ""
                    PreferenceManager.canRefund = response.data!!.canRefund

                    // Go to main page
                    startMainActivity()
                }
                else{
                    Toast.makeText(loginActivity, response.message.toString(), Toast.LENGTH_SHORT).show()
                }
            }

            override fun handleErrorResponse(error: ErrorResponse) {
                viewDataBinding!!.progressBar.visibility = View.GONE

                window.clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
                Log.d("TAG", "handleErrorResponse: "+error.message.toString())
            }
        })
    }

    private fun startMainActivity(){
        startActivity(Intent(this@LoginActivity, MainActivity::class.java))
    }

    private fun setEyeIcons(){
        viewDataBinding?.apply {
            ivEye.setOnClickListener {
                edittextPassword.inputType = if (showPassword){
                    InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                } else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_NORMAL
                ivEye.setImageDrawable(ContextCompat.getDrawable(this@LoginActivity,
                    if (showPassword) R.drawable.ic_eye_on else R.drawable.ic_eye_off))
                showPassword = !showPassword
            }
        }
    }


}