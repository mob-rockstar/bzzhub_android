package com.gexpo.gsp.ui.component.dialog

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import com.gexpo.gsp.R
import com.gexpo.gsp.databinding.DialogDiscountBinding
import com.gexpo.gsp.databinding.PaymentBottomSheetDetailBinding
import com.gexpo.gsp.util.PopupUtils

class DiscountDialog {
    lateinit var dialog: Dialog
    var isDialogRunning = false

    fun openDialog(context: Context, onSubmit: (percent: Double?, fixed: Double?) -> Unit) {
        dialog = Dialog(context)
        val binding: DialogDiscountBinding = DataBindingUtil.inflate(
            LayoutInflater.from(context), R.layout.dialog_discount, null, false
        )

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(binding.root)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        binding.submit.setOnClickListener {
            val discountPercentStr = binding.etPercent.text.toString().trim()
            val discountFixedStr = binding.etFixed.text.toString().trim()

            val discountPercent : Double? = if (discountPercentStr.isNullOrEmpty()) null else discountPercentStr.toDouble()
            val discountFixed : Double? = if (discountFixedStr.isNullOrEmpty()) null else discountFixedStr.toDouble()

            onSubmit(discountPercent, discountFixed)
            dialog.dismiss()
        }

        PopupUtils.setDefaultDialogProperty(dialog)
        dialog.show()
    }

    companion object {
        private var instance: DiscountDialog? = null
        private val Instance: DiscountDialog
            get() {
                return instance ?: DiscountDialog()
            }

        fun openDialog(
            context: Context,
            onSubmit : (percent : Double?, fixed : Double?)-> Unit
        ) {
            if (!Instance.isDialogRunning) {
                Instance.openDialog(context, onSubmit)
            }
        }
    }
}