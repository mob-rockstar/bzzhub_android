package com.gexpo.gsp.data.local

import android.content.Context
import android.content.SharedPreferences
import com.gexpo.gsp.util.AppConstants

object PreferenceManager {

    //Constants
    private const val PREF_KEY_CART_COUNT       = "PREF_KEY_CART_COUNT"
    private const val PREF_KEY_USER_LANGUAGE    = "PREF_KEY_USER_LANGUAGE"
    private const val PREF_KEY_LOGGED_IN_MODE   = "PREF_KEY_LOGGED_IN_MODE"
    private const val PREF_KEY_PAYMENT_TOKEN    = "PREF_KEY_PAYMENT_TOKEN"
    private const val PREF_KEY_INIT_NEARPAY     = "PREF_KEY_INIT_NEARPAY"
    private const val PREF_KEY_ACCESS_TOKEN     = "PREF_KEY_ACCESS_TOKEN"
    private const val PREF_KEY_EMAIL            = "PREF_KEY_EMAIL"
    private const val PREF_KEY_NAME             = "PREF_KEY_NAME"
    private const val PREF_KEY_CAN_REFUND       = "PREF_KEY_CAN_REFUND"

    private lateinit var mPref: SharedPreferences

    fun init(context: Context) {
        mPref = context.getSharedPreferences(AppConstants.PREF_NAME, Context.MODE_PRIVATE)
    }

    var cartCount: Int
        get() = mPref.getInt(PREF_KEY_CART_COUNT, 0)
        set(value) {
            mPref.edit().putInt(PREF_KEY_CART_COUNT, value).apply()
        }

    var canRefund : Int
        get() = mPref.getInt(PREF_KEY_CAN_REFUND, 0)
        set(value) {
            mPref.edit().putInt(PREF_KEY_CAN_REFUND, value).apply()
        }

    var userLanguage: Int  // if 1 : English if 2 :Arabic
        get() = mPref.getInt(PREF_KEY_USER_LANGUAGE, 1)
        set(value) {
            mPref.edit().putInt(PREF_KEY_USER_LANGUAGE, value).apply()
        }

    var loggedInMode: LoggedInMode // 0: Logged out 1: Logged in
        get() =
            LoggedInMode.fromInt(mPref.getInt(PREF_KEY_LOGGED_IN_MODE, 0))
        set(value) {
            mPref.edit().putInt(PREF_KEY_LOGGED_IN_MODE, value.type).apply()
        }

    var paymentToken : String
        get() = mPref.getString(PREF_KEY_PAYMENT_TOKEN, "")!!
        set(value) {
            mPref.edit().putString(PREF_KEY_PAYMENT_TOKEN, value).apply()
        }

    var accessToken : String
        get() = mPref.getString(PREF_KEY_ACCESS_TOKEN, "")!!
        set(value) {
            mPref.edit().putString(PREF_KEY_ACCESS_TOKEN, value).apply()
        }

    var isInitiatedNearPay : Boolean
        get() = mPref.getBoolean(PREF_KEY_INIT_NEARPAY, false)
        set(value) {
            mPref.edit().putBoolean(PREF_KEY_INIT_NEARPAY, value)
        }
    var email : String
        get() = mPref.getString(PREF_KEY_EMAIL, "")!!
        set(value) {
            mPref.edit().putString(PREF_KEY_EMAIL, value).apply()
        }

    var name : String
        get() = mPref.getString(PREF_KEY_NAME, "")!!
        set(value) {
            mPref.edit().putString(PREF_KEY_NAME, value).apply()
        }

    enum class LoggedInMode(val type: Int) {
        LOGGED_IN_MODE_LOGGED_OUT(0), LOGGED_IN_MODE_LOGGED_IN(1);

        companion object {
            fun fromInt(value: Int) = LoggedInMode.values().first { it.ordinal == value }
        }
    }

    fun setStringPreferences(key: String, value: String) {
        mPref.edit()!!.putString(key, value).apply()
     }
    //get String Preference
    fun getStringPreferences(key: String): String? {
        return mPref.getString(key, null)
    }


    //set Boolean Preference
    fun setBooleanPreferences(key: String, value: Boolean) {
        mPref.edit()!!.putBoolean(key, value).apply()
     }
    //get Boolean Preference
    fun getBooleanPreferences(key: String): Boolean {
        return mPref.getBoolean(key, false)
    }



    //set int prfrence


    fun setIntPreferences(key: String, value: Int) {
        mPref.edit()!!.putInt(key, value).apply()
     }
    //get String Preference
    fun getIntPreferences(key: String): Int {
        return mPref.getInt(key, 0)
    }

    //remove all preference
    fun removeAllPreferences() {
        mPref.edit()!!.clear().apply()
    }
}