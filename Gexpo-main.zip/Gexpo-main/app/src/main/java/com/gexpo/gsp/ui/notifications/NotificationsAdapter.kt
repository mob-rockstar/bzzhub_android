package com.gexpo.gsp.ui.notifications

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.gexpo.gsp.R
import com.gexpo.gsp.base.BaseRecyclerViewAdapter
import com.gexpo.gsp.data.local.PreferenceManager
import com.gexpo.gsp.data.model.notification.NotificationsResponse
import com.gexpo.gsp.databinding.RecyclerItemNotificationsBinding

class NotificationsAdapter(
    var notificationsActivity: NotificationsActivity,
    var notificationList: ArrayList<NotificationsResponse.Data>
) : BaseRecyclerViewAdapter<String, RecyclerItemNotificationsBinding>() {

    override val layoutId: Int
        get() = R.layout.recycler_item_notifications

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return NotificationViewHolder(createBindView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder: NotificationViewHolder = viewHolder as NotificationViewHolder


        holder.binding.tvTitle.text = (if (PreferenceManager.userLanguage == 1) notificationList[position].title.toString()else notificationList[position].arabicTitle.toString())
        holder.binding.tvDescription.text = (if (PreferenceManager.userLanguage == 1) notificationList[position].description.toString()else notificationList[position].arabicDescription.toString())
        holder.binding.tvDate.text = (if (PreferenceManager.userLanguage == 1) notificationList[position].ago.toString()else notificationList[position].agoArabic.toString())


    }

    override fun getItemCount(): Int {
        return notificationList.size
        //return super.getItemCount()
    }

    inner class NotificationViewHolder(val binding: RecyclerItemNotificationsBinding) :
        RecyclerView.ViewHolder(binding.root)
}