package com.gexpo.gsp.ui.favorite

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import com.gexpo.gsp.R
import com.gexpo.gsp.base.BaseActivity
import com.gexpo.gsp.data.viewModel.favoritesViewModel.FavoritesViewModel
import com.gexpo.gsp.databinding.ActivityFavoriteBinding
import com.gexpo.gsp.ui.component.dialog.ProductDetailDialog
import com.gexpo.gsp.data.model.Product.ProductListResponse
import com.gexpo.gsp.data.model.base.ErrorResponse
import com.gexpo.gsp.network.HandleResponse
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import javax.inject.Inject

class FavoriteActivity : BaseActivity<ActivityFavoriteBinding, FavoritesViewModel>(), HasAndroidInjector {

    override val layoutId: Int
        get() = R.layout.activity_favorite
    var products: ArrayList<ProductListResponse.ActiveProducts> = ArrayList()

    override val viewModel: FavoritesViewModel
        get() {
            return getViewModel(FavoritesViewModel::class.java)
        }

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initToolbar()

        // Get the favorite product list
        getFavoriteProducts()
    }
    private fun getFavoriteProducts() {
        viewDataBinding!!.progressBar.visibility = View.VISIBLE
        viewModel.getFavorites(object : HandleResponse<ProductListResponse> {
            override fun handleSuccessResponse(response: ProductListResponse) {
                viewDataBinding!!.progressBar.visibility = View.GONE
                if (response.status == true) {
                    products.addAll(response.data)
                    initRecyclerView()
                } else {
                    Toast.makeText(this@FavoriteActivity, response.message.toString(), Toast.LENGTH_SHORT).show()
                }
            }

            override fun handleErrorResponse(error: ErrorResponse) {
                viewDataBinding!!.progressBar.visibility = View.GONE
                Log.d("TAG", "handleErrorResponse: "+error.message.toString())
                Toast.makeText(this@FavoriteActivity, error.message.toString() + "", Toast.LENGTH_SHORT).show()
            }
        })
    }

    // Add the product to favorite list
    private fun addToFavorite(productId: Int, isFav: Boolean) {
        if (isFav){
            viewModel.addToFavorite(productId.toString(),object : HandleResponse<ProductListResponse> {

                override fun handleSuccessResponse(response: ProductListResponse) {
                    if (response.status == true) {
                        Toast.makeText(this@FavoriteActivity, response.message.toString(), Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@FavoriteActivity, response.message.toString(), Toast.LENGTH_SHORT).show()
                    }
                }

                override fun handleErrorResponse(error: ErrorResponse) {
                    Log.d("TAG", "handleErrorResponse: "+error.message.toString())
                    Toast.makeText(this@FavoriteActivity, error.message.toString() + "", Toast.LENGTH_SHORT).show()
                }
            })
        }
        else{
            viewModel.removeFromFav(productId.toString(),object :
                HandleResponse<ProductListResponse> {

                override fun handleSuccessResponse(response: ProductListResponse) {
                    if (response.status == true) {
                        Toast.makeText(this@FavoriteActivity, response.message.toString(), Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@FavoriteActivity, response.message.toString(), Toast.LENGTH_SHORT).show()
                    }
                }

                override fun handleErrorResponse(error: ErrorResponse) {
                    Log.d("TAG", "handleErrorResponse: "+error.message.toString())
                    Toast.makeText(this@FavoriteActivity, error.message.toString() + "", Toast.LENGTH_SHORT).show()
                }
            })
        }
    }

    private fun initToolbar(){
        viewDataBinding?.toolbar?.apply {
            ivBack.setOnClickListener {
                finish()
            }

            tvTitle.text = this@FavoriteActivity.resources.getString(R.string.str_favorite)
        }
    }

    private fun initRecyclerView(){
        viewDataBinding?.recyclerView?.apply {
            layoutManager = GridLayoutManager(this@FavoriteActivity, 2)
            isNestedScrollingEnabled = false
            setHasFixedSize(true)
            adapter = FavoriteProductAdapter(this@FavoriteActivity,products, onProductClick = {item, isFav -> openProductPage(item, isFav) },
                onFavClick = { index, isFav -> addToFavorite(index, isFav) })
        }
    }

    private fun openProductPage(product: ProductListResponse.ActiveProducts, isFav: Boolean){
        ProductDetailDialog.openDialog(this@FavoriteActivity, product, true)
    }
}