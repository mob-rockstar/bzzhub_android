package com.lab.alarab.ui.search.notification

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.lab.alarab.R
import com.lab.alarab.base.BaseRecyclerViewAdapter
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.data.model.api.response.notificationresponse.Notification
import com.lab.alarab.databinding.RecyclerItemNotificatoinBinding

class NotificationAdapter(private val onSelect: (deepLink: String)->Unit)  : BaseRecyclerViewAdapter<Notification, RecyclerItemNotificatoinBinding>()  {
    override val layoutId: Int
        get() = R.layout.recycler_item_notificatoin

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return NotificationViewHolder(createBindedView(viewGroup))

    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as NotificationViewHolder

        val context =holder.binding.root.context

        holder.binding.tvTitle.text =
            if (PreferenceManager.language == "en") items[position].tITLEEN
            else items[position].tITLEAR

        holder.itemView.setOnClickListener { onSelect(items[position].dEEPLINK) }
    }

    inner class NotificationViewHolder(val binding: RecyclerItemNotificatoinBinding) :
        RecyclerView.ViewHolder(binding.root)
}