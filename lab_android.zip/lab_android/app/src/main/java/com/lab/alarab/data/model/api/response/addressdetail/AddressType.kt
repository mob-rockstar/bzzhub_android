package com.lab.alarab.data.model.api.response.addressdetail


import com.google.gson.annotations.SerializedName

data class AddressType(
    @SerializedName("ID")
    var iD: Int,
    @SerializedName("NAME_AR")
    var nAMEAR: String,
    @SerializedName("NAME_EN")
    var nAMEEN: String
)