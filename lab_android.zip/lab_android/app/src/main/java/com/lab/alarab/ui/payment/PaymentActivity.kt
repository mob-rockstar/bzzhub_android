package com.lab.alarab.ui.payment

import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import androidx.recyclerview.widget.LinearLayoutManager
import com.lab.alarab.R
import com.lab.alarab.base.BaseActivity
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.data.model.api.TokenResponse
import com.lab.alarab.data.model.api.response.ErrorResponse
import com.lab.alarab.data.model.api.response.addorder.AddOrderResponse
import com.lab.alarab.data.model.api.response.cart.CartResponse
import com.lab.alarab.data.model.api.response.orderdetail.OrderDetailResponse
import com.lab.alarab.data.model.api.response.removewithcalculation.RemoveWithCalculationResponse
import com.lab.alarab.databinding.ActivityPaymentBinding
import com.lab.alarab.ui.checkout.CheckoutActivity
import com.lab.alarab.ui.order.CartListAdapter
import com.lab.alarab.ui.orderscheduled.OrderScheduledActivity
import com.lab.alarab.ui.patient.AddPatientActivity
import com.lab.alarab.utils.AppConstants
import com.lab.alarab.utils.AppConstants.FORT_REQUEST_CODE
import com.lab.alarab.utils.AppConstants.PAYFORT_MODE_AUTHORIZATION
import com.lab.alarab.utils.FormatterUtils
import com.lab.alarab.utils.NetworkUtils
import com.payfort.fort.android.sdk.base.FortSdk
import com.payfort.fort.android.sdk.base.callbacks.FortCallBackManager
import com.payfort.sdk.android.dependancies.base.FortInterfaces
import com.payfort.sdk.android.dependancies.models.FortRequest
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import timber.log.Timber
import java.util.*
import javax.inject.Inject


class PaymentActivity : BaseActivity<ActivityPaymentBinding?, PaymentViewModel>(),
    HasAndroidInjector {


    override val layoutId: Int
        get() = R.layout.activity_payment

    override val viewModel: PaymentViewModel
        get() {
            return getViewModel(PaymentViewModel::class.java)
        }

    private var payfortDeviceId: String? = null
    private var fortCallback: FortCallBackManager? = null
    private var payfortEnvironmentMode = FortSdk.ENVIRONMENT.TEST
    private var paymentMode = 1
    private var netAmount = 0.0f

    private var cartListAdapter: CartListAdapter = CartListAdapter {
            packageID, position ->removeItemFromCart(packageID!!, position)
    }

    // prevent double tapping variables
    private var lastClickTime: Long = 0

    private var packageId = 0


    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        payfortDeviceId = FortSdk.getDeviceId(this)
        fortCallback = FortCallBackManager.Factory.create()

        viewDataBinding?.ivBack?.setOnClickListener { finish() }

        viewDataBinding?.tvContinue?.setOnClickListener {
            payfortDeviceId = FortSdk.getDeviceId(this)
/*            val intent = Intent(applicationContext, OrderScheduledActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            startActivity(intent)
            finish()*/
            if (SystemClock.elapsedRealtime() - lastClickTime > 2500) {
                lastClickTime = SystemClock.elapsedRealtime()
                if (paymentMode == 1){
                    addOrder()
                }else{
                    getPayFortToken()
                }
            }
        }

        viewDataBinding?.layoutAdd?.setOnClickListener {
            AppConstants.packageId = packageId
            startActivity(Intent(this@PaymentActivity, AddPatientActivity::class.java))
        }

        initRadioListeners()

        initRecyclerView()
        getCartList()
    }

    fun initRecyclerView(){
        viewDataBinding?.recyclerView?.layoutManager = LinearLayoutManager(this@PaymentActivity)
        viewDataBinding?.recyclerView?.setHasFixedSize(true)
        viewDataBinding?.recyclerView?.adapter = cartListAdapter
    }

    fun getPayFortToken() {
        viewModel.getPayFortToken(PreferenceManager.currentUserId!!, payfortDeviceId!!, object :
            HandleResponse<TokenResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                this@PaymentActivity.onError(
                    error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                )
            }

            override fun handleSuccessRespons(tokenResponse: TokenResponse) {
                // Open Add Credit Card Page
                if (tokenResponse.sdkToken != null) {
                    createAddCardRequest(createMap(tokenResponse.sdkToken)!!)
                } else {
                    Timber.tag("asstokenRes").d(tokenResponse.toString())
                }
            }
        })
    }

    // Create Request (Map request)
    private fun createMap(token: String): Map<String, Any>? {
        val requestMap: MutableMap<String, Any> =
            HashMap()
        requestMap["amount"] = (netAmount * 100).toInt()
        requestMap["currency"] = "SAR"
        requestMap["customer_email"] = "${PreferenceManager.currentUserId}@alarablabs.com"
        requestMap["language"] = AppConstants.PAYFORT_LANGUAGE
        requestMap["merchant_reference"] = Date().time.toString()
        requestMap["command"] = PAYFORT_MODE_AUTHORIZATION
        requestMap["sdk_token"] = token
        return requestMap
    }

    private fun removeItemFromCart(packageId: Int, position: Int){
        viewModel.removeCart(packageId,
            object : HandleResponse <RemoveWithCalculationResponse>{
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (NetworkUtils.isNetworkConnected(this@PaymentActivity)) {
                        this@PaymentActivity.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        this@PaymentActivity.onError(
                            error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }

                override fun handleSuccessRespons(successResponse: RemoveWithCalculationResponse) {
                    if (successResponse.success && successResponse.httpStatus == 200){
                        cartListAdapter.removeItem(position)
                        PreferenceManager.userCartCount = cartListAdapter.itemCount
                    }else{
                        this@PaymentActivity.onError(
                            AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    }
                }
            })
    }

    // Open Add Credit Card page
    private fun createAddCardRequest(requestMap: Map<String, Any>) {
        val fortRequest = FortRequest()
        fortRequest.requestMap = requestMap

        FortSdk.getInstance().registerCallback(this,
            fortRequest,
            payfortEnvironmentMode,
            FORT_REQUEST_CODE,
            fortCallback,
            true,
            object : FortInterfaces.OnTnxProcessed {
                override fun onCancel(
                    map: MutableMap<String, Any>, map1: MutableMap<String, Any>
                ) {
                    //       this@PaymentActivity.onError(DEFAULT_ERROR_MESSAGE)
                }

                override fun onSuccess(
                    map: MutableMap<String, Any>, fortData: MutableMap<String, Any>
                ) {// Add Credit Card to server
                    //addOrder()
                    AppConstants.paymentMode = paymentMode
                }

                override fun onFailure(
                    map: MutableMap<String, Any>,
                    fortResponse: MutableMap<String, Any>
                ) {
                    if (fortResponse != null && fortResponse["response_message"] != null) {
                        this@PaymentActivity.onError(
                            fortResponse["response_message"].toString()
                        )
                    }
                }
            })
    }


    private fun initRadioListeners() {
        viewDataBinding?.radioApplePay?.setOnClickListener {
            viewDataBinding?.radioApplePay?.setImageDrawable(resources.getDrawable(R.drawable.ic_circle_selected))
            viewDataBinding?.radioCashOnDelivery?.setImageDrawable(resources.getDrawable(R.drawable.ic_circle_deselected))
            viewDataBinding?.radioCreditCard?.setImageDrawable(resources.getDrawable(R.drawable.ic_circle_deselected))
        }

        viewDataBinding?.radioCashOnDelivery?.setOnClickListener {
            paymentMode = 1
            viewDataBinding?.radioCashOnDelivery?.setImageDrawable(resources.getDrawable(R.drawable.ic_circle_selected))
            viewDataBinding?.radioApplePay?.setImageDrawable(resources.getDrawable(R.drawable.ic_circle_deselected))
            viewDataBinding?.radioCreditCard?.setImageDrawable(resources.getDrawable(R.drawable.ic_circle_deselected))
        }

        viewDataBinding?.radioCreditCard?.setOnClickListener {
            paymentMode = 2
            viewDataBinding?.radioCreditCard?.setImageDrawable(resources.getDrawable(R.drawable.ic_circle_selected))
            viewDataBinding?.radioCashOnDelivery?.setImageDrawable(resources.getDrawable(R.drawable.ic_circle_deselected))
            viewDataBinding?.radioApplePay?.setImageDrawable(resources.getDrawable(R.drawable.ic_circle_deselected))
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        // Enable 'Add Credit Card' button after Payfort Page disappeared
        fortCallback!!.onActivityResult(requestCode, resultCode, data)
    }

    private fun getOrderDetail() {
        viewModel.getOrderDetail(AppConstants.orderId,
            object : HandleResponse<OrderDetailResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (NetworkUtils.isNetworkConnected(this@PaymentActivity)) {
                        this@PaymentActivity.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        this@PaymentActivity.onError(
                            error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }

                override fun handleSuccessRespons(successResponse: OrderDetailResponse) {
                    if (successResponse.success && successResponse.httpStatus == 200) {
                        viewDataBinding?.tvBaseTotal?.text = "SAR" + successResponse.response.bASEAMOUNT
                        viewDataBinding?.tvTax?.text = "SAR" + successResponse.response.tAXAMOUNT
                        viewDataBinding?.tvDiscount?.text = "SAR" + successResponse.response.dISCOUNTAMOUNT
                        viewDataBinding?.tvTotal?.text = "SAR" + successResponse.response.tOTALAMOUNT
                    } else {
                        this@PaymentActivity.onError(
                            successResponse.errorMessage ?: AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }
            })
    }

    private fun getCartList(){
        viewModel.getCartList(object : HandleResponse<CartResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(this@PaymentActivity)) {
                    this@PaymentActivity.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    this@PaymentActivity.onError(
                        error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                    )
                }
            }

            override fun handleSuccessRespons(successResponse: CartResponse) {
                if (successResponse.success && successResponse.httpStatus == 200){
                    viewDataBinding?.tvBaseTotal?.text = "SAR" + successResponse.response.packagesAmount
                    viewDataBinding?.tvTax?.text = "SAR" + successResponse.response.taxAmount
                    viewDataBinding?.tvDiscount?.text = "SAR" + successResponse.response.discountAmount
                    viewDataBinding?.tvTotal?.text = "SAR" + successResponse.response.netTotal
                    netAmount = successResponse.response.netTotal!!


                    cartListAdapter.setItems(successResponse.response.packages)
                    if (successResponse.response.packages.isNotEmpty()){
                        packageId = successResponse.response.packages[0].iD
                    }
                }else{
                    this@PaymentActivity.onError(
                        AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                }
            }
        })
    }

    private fun addOrder(){
        AppConstants.paymentMode = paymentMode
        startActivity(Intent(this@PaymentActivity, CheckoutActivity::class.java))
    }


/*
    private fun addOrder(){
        viewModel.addOrder(AppConstants.cityName, paymentMode, AppConstants.selectedTimeId,
            AppConstants.strDateForAPI, AppConstants.lat, AppConstants.lng,
            object : HandleResponse<AddOrderResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (NetworkUtils.isNetworkConnected(this@PaymentActivity)) {
                        this@PaymentActivity.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        this@PaymentActivity.onError(
                            error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }

                override fun handleSuccessRespons(successResponse: AddOrderResponse) {
                    if (successResponse.success  && successResponse.httpStatus == 200){

                        val intent = Intent(applicationContext, OrderScheduledActivity::class.java)
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                        startActivity(intent)
                        finish()
                    }else{
                        this@PaymentActivity.onError(
                            AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }
            })
    }
*/

    override fun onResume() {
        super.onResume()
        getCartList()
    }
}