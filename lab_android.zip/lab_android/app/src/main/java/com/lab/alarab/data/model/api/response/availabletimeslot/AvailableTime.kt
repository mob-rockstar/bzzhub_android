package com.lab.alarab.data.model.api.response.availabletimeslot

data class AvailableTime(
    val ACTIVE_FLAG: Int,
    val CREATE_DATE: String,
    val DAY_OF_WEEK_ID: Int,
    val FROM_TIME: String,
    val HOSPITAL_ID: Int,
    val ID: Int,
    val TO_TIME: String,
    val UPDATE_DATE: String
)