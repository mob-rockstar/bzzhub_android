package com.lab.alarab.data.model.api.response


import com.google.gson.annotations.SerializedName

data class CancelOrderResponse(
    var errorMessage: String,
    var httpStatus: Int,
    var response: Any,
    var success: Boolean,
    var timestamp: Int
)