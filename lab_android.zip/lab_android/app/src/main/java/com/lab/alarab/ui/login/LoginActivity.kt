package com.lab.alarab.ui.login

import android.os.Bundle
import com.lab.alarab.R
import com.lab.alarab.base.BaseActivity
import com.lab.alarab.databinding.ActivitySplashBinding
import com.lab.alarab.ui.login.inputmobile.InputMobileFragment
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import javax.inject.Inject

class LoginActivity : BaseActivity<ActivitySplashBinding?, LoginViewModel>(),
    HasAndroidInjector {

    override val layoutId: Int
        get() = R.layout.activity_login

    override val viewModel: LoginViewModel
        get() {
            return getViewModel(LoginViewModel::class.java)
        }

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        replaceFragmentDirectly(R.id.frameLayout,InputMobileFragment())
    }
}