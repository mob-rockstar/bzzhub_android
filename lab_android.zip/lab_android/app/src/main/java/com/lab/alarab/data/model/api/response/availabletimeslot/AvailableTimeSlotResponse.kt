package com.lab.alarab.data.model.api.response.availabletimeslot

data class AvailableTimeSlotResponse(
    val errorMessage: Any,
    val httpStatus: Int,
    val response: Response,
    val success: Boolean,
    val timestamp: Int
)