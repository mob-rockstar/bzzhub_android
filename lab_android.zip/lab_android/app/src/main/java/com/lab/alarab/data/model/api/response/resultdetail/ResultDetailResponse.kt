package com.lab.alarab.data.model.api.response.resultdetail


import com.google.gson.annotations.SerializedName

data class ResultDetailResponse(
    var errorMessage: Any,
    var httpStatus: Int,
    var response: List<Response>,
    var success: Boolean,
    var timestamp: Int
)