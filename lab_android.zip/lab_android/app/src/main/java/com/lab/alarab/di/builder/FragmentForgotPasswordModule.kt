package com.lab.alarab.di.builder

import com.lab.alarab.ui.forgotpassword.enterotp.ForgotPasswordEnterOTPFragment
import com.lab.alarab.ui.forgotpassword.inputmobile.ForgotPasswordInputMobileFragment
import com.lab.alarab.ui.login.enterotp.EnterOTPFragment
import com.lab.alarab.ui.login.inputinfo.InputInfoFragment
import com.lab.alarab.ui.login.inputmobile.InputMobileFragment
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class FragmentForgotPasswordModule {
    @ContributesAndroidInjector
    abstract fun contributeForgotPasswordInputMobileFragment(): ForgotPasswordInputMobileFragment

    @ContributesAndroidInjector
    abstract fun contributeForgotPasswordEnterOTPFragment(): ForgotPasswordEnterOTPFragment
}