package com.lab.alarab.data.model.api.response.availabletimeslot

data class CITYSTATE (
    val ENG_NAME : String,
    val ARABIC_NAME: String
        )