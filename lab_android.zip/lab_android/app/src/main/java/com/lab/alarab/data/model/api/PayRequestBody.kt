package com.lab.alarab.data.model.api

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import com.lab.alarab.utils.AppConstants
import com.lab.alarab.utils.AppConstants.PAYFORT_ESCI
import com.lab.alarab.utils.AppConstants.PAYFORT_SDK_TOKEN


class PayRequestBody  {
    @SerializedName("command")
    @Expose
    var command: String = PAYFORT_SDK_TOKEN

    @SerializedName("access_code")
    @Expose
    var accessCode: String =
       AppConstants.PAYFORT_ACCESS_CODE_PRODUCTION


    @SerializedName("merchant_identifier")
    @Expose
    var merchantIdentifier: String = AppConstants.PAYFORT_MERCHANT_ID_PRODUCTION

    @SerializedName("merchant_reference")
    @Expose
    var merchantReference: String? = null

    @SerializedName("amount")
    @Expose
    var amount = 0

    @SerializedName("currency")
    @Expose
    var currency: String = "SAR"

    @SerializedName("language")
    @Expose
    var language: String = AppConstants.PAYFORT_LANGUAGE

    @SerializedName("customer_email")
    @Expose
    var customerEmail: String? = null

    @SerializedName("eci")
    @Expose
    var eci: String = PAYFORT_ESCI

    @SerializedName("token_name")
    @Expose
    var tokenName: String? = null

    @SerializedName("signature")
    @Expose
    var signature: String? = null
}