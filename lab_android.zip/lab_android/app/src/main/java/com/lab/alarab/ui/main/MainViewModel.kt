package com.lab.alarab.ui.main

import com.google.gson.JsonObject
import com.lab.alarab.base.BaseViewModel
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.model.api.response.FlagListResponse
import com.lab.alarab.data.model.api.response.city.CityResponse
import com.lab.alarab.data.model.api.response.getresult.GetResultResponse
import com.lab.alarab.data.model.api.response.landing.LandingPageResponse
import com.lab.alarab.data.model.api.response.notificationresponse.NotificationResponse
import com.lab.alarab.data.model.api.response.orderhistory.OrderHistoryResponse
import com.lab.alarab.data.model.api.response.removewithcalculation.RemoveWithCalculationResponse
import com.lab.alarab.data.model.api.response.updateitemwithcalculation.UpdateWithCalculationResponse
import com.lab.alarab.data.remote.APIManager
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class MainViewModel : BaseViewModel() {
    // API to get Flag List
    fun getLandingPageInfo(
        handleResponse: HandleResponse<LandingPageResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.addAll(
            APIManager.getLandingPageInformation()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

    // API to add item to cart
    fun addToCart(
        packageId: Int,
        handleResponse: HandleResponse<UpdateWithCalculationResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.addAll(
            APIManager.addToCartWithCalculations(packageId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

    fun removeItemFromCart(
        packageId: Int,
        handleResponse: HandleResponse<RemoveWithCalculationResponse>
    ){
        setIsLoading(true)
        compositeDisposable.addAll(
            APIManager.removeCartWithCalculations(packageId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

    fun getOrderHistory(
        handleResponse: HandleResponse<OrderHistoryResponse>
    ){
        setIsLoading(true)
        compositeDisposable.addAll(
            APIManager.getOrderHistory()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

    fun getResults(
        handleResponse: HandleResponse<GetResultResponse>
    ){
        setIsLoading(true)
        compositeDisposable.addAll(
            APIManager.getResults()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

    fun getGoogleAddress(
        latitude: Double,
        longitude: Double,
        handleResponse: HandleResponse<JsonObject>
    ) {
        compositeDisposable.add(
            APIManager.getGoogleAddress(latitude, longitude)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

    fun getNotification(
        handleResponse: HandleResponse<NotificationResponse>
    ){
        compositeDisposable.add(
            APIManager.getNotifications()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

    fun getCityList(   handleResponse: HandleResponse<CityResponse>){
        compositeDisposable.add(
            APIManager.getCityList()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }
}