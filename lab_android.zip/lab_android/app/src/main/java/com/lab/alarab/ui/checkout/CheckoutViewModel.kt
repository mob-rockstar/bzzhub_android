package com.lab.alarab.ui.checkout

import com.lab.alarab.base.BaseViewModel
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.model.api.response.VerifyMobileResponse
import com.lab.alarab.data.model.api.response.addorder.AddOrderResponse
import com.lab.alarab.data.model.api.response.cart.CartResponse
import com.lab.alarab.data.model.api.response.timeslot.TimeSlotResponse
import com.lab.alarab.data.remote.APIManager
import com.lab.alarab.utils.AppConstants
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class CheckoutViewModel : BaseViewModel() {
    // API to get available time slot
    fun getAvailableTimeList(
        date: String,
        handleResponse: HandleResponse<TimeSlotResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.getAvailableTimeSlots(date)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

    fun addOrder(
        city: String,
        paymentMethodID : Int,
        availableTimeId: Int,
        availableDate: String,
        lat : Double,
        lng : Double,
        handleResponse: HandleResponse<AddOrderResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.addOrder(city,paymentMethodID,availableTimeId,availableDate,lng, lat, AppConstants.hospitalId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }


    fun getCartList(
        handleResponse: HandleResponse<CartResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.addAll(
            APIManager.viewCart()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }
}