package com.lab.alarab.ui.editaddress

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.lab.alarab.R
import com.lab.alarab.base.BaseRecyclerViewAdapter
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.data.model.api.response.addressmeta.AddressType
import com.lab.alarab.databinding.RecyclerItemAddressTypeBinding

class AddressTypeAdapter(private var onSelect: (addressType : AddressType)-> Unit) : BaseRecyclerViewAdapter<AddressType, RecyclerItemAddressTypeBinding>()  {

    override val layoutId: Int
        get() = R.layout.recycler_item_address_type

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return AddressViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as AddressViewHolder
        val context = holder.itemView.context

        if (PreferenceManager.language == "en"){
            holder.binding.tvType.text = items[position].nAMEEN
        }else  holder.binding.tvType.text = items[position].nAMEAR

        holder.itemView.setOnClickListener {
            onSelect(items[position])
        }
    }

    inner class AddressViewHolder(val binding: RecyclerItemAddressTypeBinding) :
        RecyclerView.ViewHolder(binding.root)
}