package com.lab.alarab.data.model.api.response.notificationresponse


import com.google.gson.annotations.SerializedName

data class NotificationResponse(
    var errorMessage: Any,
    var httpStatus: Int,
    var response: Response,
    var success: Boolean,
    var timestamp: Int
)