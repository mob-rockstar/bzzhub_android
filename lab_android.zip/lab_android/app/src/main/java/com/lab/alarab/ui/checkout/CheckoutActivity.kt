package com.lab.alarab.ui.checkout

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.DatePicker
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.lab.alarab.R
import com.lab.alarab.base.BaseActivity
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.model.api.response.ErrorResponse
import com.lab.alarab.data.model.api.response.addorder.AddOrderResponse
import com.lab.alarab.data.model.api.response.timeslot.TimeSlotResponse
import com.lab.alarab.databinding.ActivityCheckoutBinding
import com.lab.alarab.ui.choosedelivery.ChooseDeliveryActivity
import com.lab.alarab.ui.orderscheduled.OrderScheduledActivity
import com.lab.alarab.ui.payment.PaymentActivity
import com.lab.alarab.utils.AppConstants
import com.lab.alarab.utils.DateUtils
import com.lab.alarab.utils.NetworkUtils
import timber.log.Timber
import java.text.SimpleDateFormat
import java.util.*

class CheckoutActivity : BaseActivity<ActivityCheckoutBinding?, CheckoutViewModel>() {

    override val layoutId: Int
        get() = R.layout.activity_checkout

    override val viewModel: CheckoutViewModel
        get() {
            return getViewModel(CheckoutViewModel::class.java)
        }

    private var mDatePickerDialog: DatePickerDialog? = null
    private lateinit var userMap: GoogleMap
    private var strDate = ""
    private var strDateForAPI = ""

    private var morningAdapter: TimeAdapter = TimeAdapter() { timeID ->
        enableMorningSelection(timeID)
    }
    private var afternoonAdapter: TimeAdapter = TimeAdapter() { timeID ->
        enableAfternoonSelectIon(timeID)
    }
    private var nightAdapter: TimeAdapter = TimeAdapter() { timeID ->
        enableEveningSelection(timeID)
    }
    val apiDateFormat = SimpleDateFormat("yyyy-MM-dd")

    private val LOCATION_PICK_REQUEST = 1002
    private var selectedTimeId = 0
    private var cityName = ""
    private var lat = 0.0
    private var lng = 0.0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        strDateForAPI = apiDateFormat.format(Date())


        initDate()
        initRecyclerView()

        strDate = SimpleDateFormat("EEE, dd, MMM").format(Date())
        initListener()
        initMap()
        setDateTimeField()
        viewDataBinding?.tvDate?.text = strDate
    //    getAvailableTimeSlot(strDateForAPI)
    }

    private fun initRecyclerView() {
        viewDataBinding?.recyclerViewMorning?.layoutManager =
            GridLayoutManager(this@CheckoutActivity, 2)
        viewDataBinding?.recyclerViewMorning?.adapter = morningAdapter

        morningAdapter.setSelection(-1)
        afternoonAdapter.setSelection(-1)
        nightAdapter.setSelection(-1)

        viewDataBinding?.recyclerViewAfternoon?.layoutManager =
            GridLayoutManager(this@CheckoutActivity, 2)
        viewDataBinding?.recyclerViewAfternoon?.adapter = afternoonAdapter

        viewDataBinding?.recyclerViewNight?.layoutManager =
            GridLayoutManager(this@CheckoutActivity, 2)
        viewDataBinding?.recyclerViewNight?.adapter = nightAdapter
    }

    private fun initListener() {
        viewDataBinding?.ivNext?.setOnClickListener {
            viewDataBinding?.tvDate?.text =
                DateUtils.getNextDateAsString(viewDataBinding?.tvDate?.text.toString())
            strDate = viewDataBinding?.tvDate?.text.toString()
            strDateForAPI = DateUtils.getNextDateAsStringForAPI(strDateForAPI)
            getAvailableTimeSlot(strDateForAPI)
        }

        viewDataBinding?.ivBefore?.setOnClickListener {
            viewDataBinding?.tvDate?.text =
                DateUtils.getPreviewsDayFromString(viewDataBinding?.tvDate?.text.toString())
            strDate = viewDataBinding?.tvDate?.text.toString()
            strDateForAPI = DateUtils.getPreviewsDayFromString(strDateForAPI)
            getAvailableTimeSlot(strDateForAPI)
        }

        viewDataBinding?.tvDate?.setOnClickListener {
            mDatePickerDialog?.show()
        }

        viewDataBinding?.layoutLocation?.setOnClickListener {
            val intent = Intent(this@CheckoutActivity, ChooseDeliveryActivity::class.java)
            startActivityForResult(intent, LOCATION_PICK_REQUEST)
            //  startActivity(Intent(this@CheckoutActivity, ChooseDeliveryActivity::class.java))
        }

        viewDataBinding?.layoutBook?.setOnClickListener {
            val intent = Intent(this@CheckoutActivity, ChooseDeliveryActivity::class.java)
            startActivityForResult(intent, LOCATION_PICK_REQUEST)
          //  startActivity(Intent(this@CheckoutActivity, ChooseDeliveryActivity::class.java))
        }

        viewDataBinding?.tvContinue?.setOnClickListener {
            if (cityName.isNotEmpty() &&  strDateForAPI.isNotEmpty() && lat != 0.0) {
                addOrder()
          //      startActivity(Intent(this@CheckoutActivity, PaymentActivity::class.java))
            } else {
                var strErrorMessage = ""
                when {
                    cityName.isEmpty() -> {
                        strErrorMessage = "Please select your delivery location "
                    }
                    lat == 0.0 -> {
                        strErrorMessage = "Please select your delivery location"
                    }
                    selectedTimeId == 0 -> {
                        strErrorMessage = "Please select Time"
                    }
                }
                Toast.makeText(this@CheckoutActivity, strErrorMessage, Toast.LENGTH_LONG).show()
            }
            //    startActivity(Intent(this@CheckoutActivity, PaymentActivity::class.java))
        }
    }

    private fun addOrder() {
        AppConstants.cityName = cityName
        AppConstants.strDateForAPI = strDateForAPI
        AppConstants.lat = lat
        AppConstants.lng = lng

        viewModel.addOrder(AppConstants.cityName, AppConstants.paymentMode, AppConstants.selectedTimeId,
            AppConstants.strDateForAPI, AppConstants.lat, AppConstants.lng,
            object : HandleResponse<AddOrderResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (NetworkUtils.isNetworkConnected(this@CheckoutActivity)) {
                        this@CheckoutActivity.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        this@CheckoutActivity.onError(
                            error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }

                override fun handleSuccessRespons(successResponse: AddOrderResponse) {
                    if (successResponse.success  && successResponse.httpStatus == 200){

                        val intent = Intent(applicationContext, OrderScheduledActivity::class.java)
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                        startActivity(intent)
                        finish()
                    }else{
                        this@CheckoutActivity.onError(
                            AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }
            })

        /*   viewModel.addOrder(cityName, 1, selectedTimeId, strDateForAPI, lat, lng,
               object : HandleResponse<AddOrderResponse> {
                   override fun handleErrorResponse(error: ErrorResponse?) {
                       if (NetworkUtils.isNetworkConnected(this@CheckoutActivity)) {
                           this@CheckoutActivity.onError(
                               error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                           )
                       } else {
                           this@CheckoutActivity.onError(
                               error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                           )
                       }
                   }

                   override fun handleSuccessRespons(successResponse: AddOrderResponse) {
                       if (successResponse.success  && successResponse.httpStatus == 200){
                    *//*       val intent = Intent(applicationContext, OrderScheduledActivity::class.java)
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                        startActivity(intent)
                        finish()*//*
                         AppConstants.orderId = successResponse.response.packages?.get(0).pivot.eNDUSERLABORDERID
                        startActivity(Intent(this@CheckoutActivity, PaymentActivity::class.java))
                    }else{
                        this@CheckoutActivity.onError(
                            AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }
            })*/
    }

    private fun initDate() {
        viewDataBinding?.tvDate?.text = DateUtils.getCurrentDateAsString()
    }

    private fun initMap() {
        // user address
        val mapFragment =
            supportFragmentManager.findFragmentById(R.id.fragment_map) as SupportMapFragment
        mapFragment.view?.isClickable = false
        mapFragment.getMapAsync { map ->
            map.uiSettings.isMapToolbarEnabled = false
            val userLatLng = LatLng(32.0, 36.0)
            map.moveCamera(CameraUpdateFactory.newLatLng(userLatLng))

            userMap = map
        }

        viewDataBinding?.ivBack?.setOnClickListener { finish() }
    }

    private fun setDateTimeField() {
        val newCalendar = Calendar.getInstance()
        mDatePickerDialog = DatePickerDialog(
            this@CheckoutActivity,
            R.style.styleDatePickerDialog,
            DatePickerDialog.OnDateSetListener { view: DatePicker?, year: Int, monthOfYear: Int, dayOfMonth: Int ->
                val newDate = Calendar.getInstance()
                newDate[year, monthOfYear] = dayOfMonth
                val formatDate =
                    SimpleDateFormat("EEE, dd, MMM")
                val startDate = newDate.time
                val fdate = formatDate.format(startDate)
                strDate = formatDate.format(startDate)
                strDateForAPI = apiDateFormat.format(startDate)
                getAvailableTimeSlot(strDateForAPI)
                viewDataBinding?.tvDate?.text = fdate
                //      enableNextButton()
            },
            newCalendar[Calendar.YEAR],
            newCalendar[Calendar.MONTH],
            newCalendar[Calendar.DAY_OF_MONTH]
        )
        val c = Calendar.getInstance()
        mDatePickerDialog!!.datePicker.minDate = c.timeInMillis
        mDatePickerDialog!!.setTitle("")
    }

    private fun getAvailableTimeSlot(date: String) {
        viewModel.getAvailableTimeList(date,
            object : HandleResponse<TimeSlotResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (NetworkUtils.isNetworkConnected(this@CheckoutActivity)) {
                        this@CheckoutActivity.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        this@CheckoutActivity.onError(
                            error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }

                override fun handleSuccessRespons(successResponse: TimeSlotResponse) {
                    if (successResponse.success && successResponse.httpStatus == 200) {
                        morningAdapter.setItems(successResponse.response.morning)
                        afternoonAdapter.setItems(successResponse.response.afternoon)
                        nightAdapter.setItems(successResponse.response.evening)


                    } else {
                        this@CheckoutActivity.onError(
                            AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }
            })
    }

    private fun enableMorningSelection(timeID: Int) {
        afternoonAdapter.setSelection(-1)
        nightAdapter.setSelection(-1)
        selectedTimeId = timeID
    }

    private fun enableAfternoonSelectIon(timeID: Int) {
        morningAdapter.setSelection(-1)
        nightAdapter.setSelection(-1)
        selectedTimeId = timeID
    }

    private fun enableEveningSelection(timeID: Int) {
        morningAdapter.setSelection(-1)
        afternoonAdapter.setSelection(-1)
        selectedTimeId = timeID
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode === this.LOCATION_PICK_REQUEST && resultCode === RESULT_OK) {
            cityName = data?.extras?.getString("city")!!
            lat = data?.extras?.getDouble("lat")!!
            lng = data?.extras?.getDouble("lng")!!

            viewDataBinding?.tvCity?.text = cityName
        }
    }


}