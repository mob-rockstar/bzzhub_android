package com.lab.alarab.di

/**
 * Marks an activity / fragment injectable.
 */
interface Injectable
