package com.lab.alarab.ui.time

import com.lab.alarab.base.BaseViewModel
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.model.api.response.availabletimeslot.AvailableTimeSlotResponse
import com.lab.alarab.data.model.api.response.removewithcalculation.RemoveWithCalculationResponse
import com.lab.alarab.data.model.api.response.timeslot.TimeSlotResponse
import com.lab.alarab.data.model.api.response.updateitemwithcalculation.UpdateWithCalculationResponse
import com.lab.alarab.data.remote.APIManager
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class AvailableTimeViewModel : BaseViewModel() {
    // API to get available time slot
    fun getAvailableTimeList(
        packageId : Int, cityId : Int, longitude : Double, latitude : Double, testType : Int, date: String,
        handleResponse: HandleResponse<AvailableTimeSlotResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.getAvailableTimeSlotForProduct(date, packageId, testType, longitude, latitude, cityId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

    // API to add item to cart
    fun addToCart(
        packageId: Int,
        handleResponse: HandleResponse<UpdateWithCalculationResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.addAll(
            APIManager.addToCartWithCalculations(packageId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

    fun removeItemFromCart(
        packageId: Int,
        handleResponse: HandleResponse<RemoveWithCalculationResponse>
    ){
        setIsLoading(true)
        compositeDisposable.addAll(
            APIManager.removeCartWithCalculations(packageId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

}