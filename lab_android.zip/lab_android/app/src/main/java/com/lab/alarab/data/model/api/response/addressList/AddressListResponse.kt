package com.lab.alarab.data.model.api.response.addressList


import com.google.gson.annotations.SerializedName

data class AddressListResponse(
    var errorMessage: String?,
    var httpStatus: Int,
    var response: Response,
    var success: Boolean,
    var timestamp: Int
)