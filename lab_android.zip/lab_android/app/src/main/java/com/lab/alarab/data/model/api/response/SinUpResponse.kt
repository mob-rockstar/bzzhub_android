package com.lab.alarab.data.model.api.response

import com.lab.alarab.data.model.api.User

data class SinUpResponse(
    var httpStatus: Int,
    var success: Boolean,
    var timestamp: Int,
    var response: User
)