package com.lab.alarab.data.model.api.response.defaultaddress


import com.google.gson.annotations.SerializedName

data class DefaultAddressResponse(
    var errorMessage: String?,
    var httpStatus: Int,
    var response: Response,
    var success: Boolean,
    var timestamp: Int
)