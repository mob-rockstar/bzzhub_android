package com.lab.alarab.data.model.api.response.addressmeta


import com.google.gson.annotations.SerializedName

data class Response(
    var addressTitles: List<AddressTitle>,
    var addressTypes: List<AddressType>
)