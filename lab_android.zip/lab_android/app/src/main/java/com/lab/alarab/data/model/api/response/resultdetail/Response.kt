package com.lab.alarab.data.model.api.response.resultdetail


import com.google.gson.annotations.SerializedName

data class Response(
    @SerializedName("ANALYZE_TIME")
    var aNALYZETIME: Any,
    @SerializedName("BIRTH_DATE")
    var bIRTHDATE: String,
    @SerializedName("COLLECTION_TIME")
    var cOLLECTIONTIME: Any,
    @SerializedName("DATE_OF_BIRTH")
    var dATEOFBIRTH: Any,
    @SerializedName("DECIMAL_RESULT")
    var dECIMALRESULT: Any,
    @SerializedName("END_USER_LAB_ORDER_ID")
    var eNDUSERLABORDERID: Int,
    @SerializedName("FOLLOWER_RELATION_ID")
    var fOLLOWERRELATIONID: Any,
    @SerializedName("GENDER_ID")
    var gENDERID: Any,
    @SerializedName("HAS_COUGH")
    var hASCOUGH: Any,
    @SerializedName("HAS_DIFFICULTIES_BREATHING")
    var hASDIFFICULTIESBREATHING: Any,
    @SerializedName("HAS_SYMTOMPS")
    var hASSYMTOMPS: Any,
    @SerializedName("HAS_THROAT_PAIN")
    var hASTHROATPAIN: Any,
    @SerializedName("HASـCOVID_CONTACT")
    var hASـCOVIDCONTACT: Any,
    @SerializedName("ID")
    var iD: Int,
    @SerializedName("IDENTIFICATION")
    var iDENTIFICATION: Any,
    @SerializedName("IDENTIFICATION_TYPE")
    var iDENTIFICATIONTYPE: Any,
    var lABCATEGORYPACKAGE: LABCATEGORYPACKAGE,
    @SerializedName("LAB_CATEGORY_PACKAGE_ID")
    var lABCATEGORYPACKAGEID: Int,
    @SerializedName("LAB_ORDER_STATUS_ID")
    var lABORDERSTATUSID: Int,
    @SerializedName("MOBILE_NUMBER")
    var mOBILENUMBER: Any,
    @SerializedName("NAME")
    var nAME: String,
    @SerializedName("NATIONALITY")
    var nATIONALITY: Any,
    @SerializedName("NATIONALITY_ID")
    var nATIONALITYID: Any,
    @SerializedName("PRICE")
    var pRICE: Int,
    @SerializedName("RESULT")
    var rESULT: Any,
    @SerializedName("RESULT_TIME")
    var rESULTTIME: Any,
    @SerializedName("RESULT_URL")
    var rESULTURL: String,
    @SerializedName("TEMPRETURE")
    var tEMPRETURE: Any
)