package com.lab.alarab

import android.app.Application
import android.content.Intent
import android.util.Log
import com.cometchat.pro.core.AppSettings
import com.cometchat.pro.core.CometChat
import com.cometchat.pro.exceptions.CometChatException
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.data.remote.APIManager
import com.lab.alarab.di.AppInjector
import com.lab.alarab.utils.AppConstants
import com.lab.alarab.utils.AppLogger
import dagger.android.AndroidInjector
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import io.github.inflationx.calligraphy3.CalligraphyConfig

import io.realm.Realm
import io.realm.RealmConfiguration
import javax.inject.Inject
import com.cometchat.pro.core.AppSettings.AppSettingsBuilder


class ArabLabApp: Application(), HasAndroidInjector{

    val TAG = "ARABLAB_APPLICATION"

    @Inject
    lateinit var activityDispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector(): AndroidInjector<Any> {
        return activityDispatchingAndroidInjector
    }

    private var intent: Intent? = null

    @Inject
    lateinit var mCalligraphyConfig: CalligraphyConfig

    override fun onCreate() {
        super.onCreate()
        // Set Realm Configuration
        setRealmConfiguration()
        AppInjector.init(this)
    /*    ViewPump.init(
            ViewPump.builder()
                .addInterceptor(CalligraphyInterceptor(mCalligraphyConfig))
                .build()
        )*/

        AppLogger.init()
        APIManager.init(this)
        val appSettings = AppSettingsBuilder().subscribePresenceForAllUsers().setRegion(AppConstants.CHAT_REGION).build()

        CometChat.init(this,AppConstants.CHAT_APP_ID,appSettings, object : CometChat.CallbackListener<String>() {
            override fun onSuccess(p0: String?) {
                Log.d(TAG, "Initialization completed successfully")
            }

            override fun onError(p0: CometChatException?) {
                Log.d(TAG, "Initialization failed with exception: " + p0?.message)
            }

        })
    }

    private fun setRealmConfiguration() {
        Realm.init(this)
        PreferenceManager.init(this)
        val configuration = RealmConfiguration.Builder()
            .schemaVersion(Companion.REALM_SCHEMA_VERSION)
            .deleteRealmIfMigrationNeeded()
            .name(AppConstants.DB_NAME)
            .build()
        Realm.setDefaultConfiguration(configuration)
    }


    fun setIntent(mIntent: Intent) {
        intent = mIntent
    }

    companion object {
        private val REALM_SCHEMA_VERSION: Long = 2

        private var instance: ArabLabApp? = null
        private val Instance: ArabLabApp
            get() {
                if (instance == null) {
                    instance = ArabLabApp()
                }
                return instance!!
            }

        fun setIntent(intent: Intent) {
            Instance.setIntent(intent)
        }
    }
}