package com.lab.alarab.ui.orderdetail

import android.content.Intent
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.lab.alarab.R
import com.lab.alarab.base.BaseActivity
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.model.api.response.CancelOrderResponse
import com.lab.alarab.data.model.api.response.ErrorResponse
import com.lab.alarab.data.model.api.response.orderdetail.OrderDetailResponse
import com.lab.alarab.data.model.api.response.orderdetail.Response
import com.lab.alarab.databinding.ActivityOrderDetailBinding
import com.lab.alarab.ui.checkout.CheckoutActivity
import com.lab.alarab.ui.choosedelivery.ChooseDeliveryActivity
import com.lab.alarab.ui.choosepayment.ChoosePaymentActivity
import com.lab.alarab.utils.*
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import org.greenrobot.eventbus.EventBus
import javax.inject.Inject

class OrderDetailActivity : BaseActivity<ActivityOrderDetailBinding?, OrderDetailViewModel>() ,
    HasAndroidInjector {


    override val layoutId: Int
        get() = R.layout.activity_order_detail

    override val viewModel: OrderDetailViewModel
        get() {
            return getViewModel(OrderDetailViewModel::class.java)
        }

    private var orderId : Int =0
    private var  orderDetail: Response? = null
    private var orderDetailAdapter: OrderDetailAdapter = OrderDetailAdapter()

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        orderId = intent.getIntExtra("order_id", 0)
        initListeners()

        initRecyclerView()
        getOrderDetail()
    }

    private fun initRecyclerView(){
        viewDataBinding?.recyclerView?.layoutManager = LinearLayoutManager(this@OrderDetailActivity)
        viewDataBinding?.recyclerView?.adapter = orderDetailAdapter
    }

    private fun initListeners(){
        viewDataBinding?.ivBack?.setOnClickListener{
            finish()
        }

        viewDataBinding?.layoutHelp?.setOnClickListener {
            val i = Intent(Intent.ACTION_SEND)
            i.putExtra(Intent.EXTRA_EMAIL, arrayOf<String>("support@lab.com"))
            i.putExtra(Intent.EXTRA_SUBJECT, "Hello")
            i.putExtra(Intent.EXTRA_TEXT,"" )
            startActivity(Intent.createChooser(i, "Send email"))
        }

        viewDataBinding?.layoutPaymentDetail?.tvChangeAddress?.setOnClickListener {
            startActivity(Intent(this@OrderDetailActivity, ChooseDeliveryActivity::class.java))
        }

        viewDataBinding?.layoutPaymentDetail?.tvChangePayment?.setOnClickListener {
       //     startActivity(Intent(this@OrderDetailActivity, ChoosePaymentActivity::class.java))
        }

        viewDataBinding?.layoutPaymentDetail?.layoutDetail?.setOnClickListener {
            PopupUtils.showOrderDetails(this@OrderDetailActivity, orderDetail!!)
        }
    }

    private fun getOrderDetail(){
        viewModel.getOrderDetail(orderId,
            object : HandleResponse<OrderDetailResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (NetworkUtils.isNetworkConnected(this@OrderDetailActivity)) {
                        this@OrderDetailActivity.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        this@OrderDetailActivity.onError(
                            error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }

                override fun handleSuccessRespons(successResponse: OrderDetailResponse) {
                    if (successResponse.success && successResponse.httpStatus == 200){
                        orderDetail = successResponse.response
                        orderDetailAdapter.setItems(orderDetail?.packages!!)

                        initUI()
                    }else{
                        this@OrderDetailActivity.onError(
                            successResponse?.errorMessage ?: AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }
            })
    }

    private fun initUI(){
        viewDataBinding?.tvOrderNumber?.text =
            resources.getString(R.string.str_order_number, orderDetail?.iD.toString())

        viewDataBinding?.tvDate?.text=
            resources.getString(R.string.str_order_date, DateUtils.getOrderDate(orderDetail?.sCHEDULEDATE!!))
        viewDataBinding?.tvTime?.text =
            """${DateUtils.getOrderTime(orderDetail?.lABAVAILABLETIME?.fROMTIME!!)} - ${
                DateUtils.getOrderTime(orderDetail?.lABAVAILABLETIME?.tOTIME!!)
            }"""

        viewDataBinding?.layoutPaymentDetail?.tvAddress?.text = orderDetail?.dELIVERYADDRESS
        viewDataBinding?.layoutPaymentDetail?.tvAmount?.text = """SAR ${orderDetail?.bASEAMOUNT}"""

        viewDataBinding?.tvCancelOrder?.setOnClickListener {
            PopupUtils.showConfirmDialog(this@OrderDetailActivity,
                "Confirm",
                "Are you sure you want cancel this order?"){
                cancelOrder()
            }
        }
    }

    private fun cancelOrder(){
        viewModel.cancelOrder(orderId,
            object : HandleResponse<CancelOrderResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (NetworkUtils.isNetworkConnected(this@OrderDetailActivity)) {
                        this@OrderDetailActivity.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        this@OrderDetailActivity.onError(
                            error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }

                override fun handleSuccessRespons(successResponse: CancelOrderResponse) {
                    if (successResponse.success && successResponse.httpStatus == 200){
                        EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_CART_CHANGED))

                    }else{
                        this@OrderDetailActivity.onError(
                            successResponse?.errorMessage ?: AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }
            })
    }
}