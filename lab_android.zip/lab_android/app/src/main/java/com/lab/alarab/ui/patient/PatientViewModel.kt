package com.lab.alarab.ui.patient

import com.lab.alarab.base.BaseViewModel
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.model.api.response.updateitemwithcalculation.UpdateWithCalculationResponse
import com.lab.alarab.data.remote.APIManager
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class PatientViewModel : BaseViewModel() {
    fun addPatient(
        packageId: Int,
        type: Int,
        name: String,
        gender: Int,
        mobileNumber: String,
        nationality: Int,
        birthday: Int,
        birthMonth: Int,
        birthYear: Int,
        handleResponse: HandleResponse<UpdateWithCalculationResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.addToCartWithFollowers(
                packageId,
                type,
                name,
                gender,
                mobileNumber,
                nationality,
                birthday,
                birthMonth,
                birthYear,
            ).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }
}