package com.lab.alarab.ui.nationality

import android.content.Intent
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.lab.alarab.R
import com.lab.alarab.base.BaseActivity
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.model.api.Flag
import com.lab.alarab.data.model.api.response.ErrorResponse
import com.lab.alarab.data.model.api.response.FlagListResponse
import com.lab.alarab.data.model.api.response.flag.FlagObject
import com.lab.alarab.databinding.ActivityNationalityBinding
import com.lab.alarab.utils.AppConstants
import com.lab.alarab.utils.NetworkUtils
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import java.io.Serializable
import javax.inject.Inject


class NationalityActivity : BaseActivity<ActivityNationalityBinding?, NationalityViewModel>(),
    FlagAdapter.SelectedListener,
    HasAndroidInjector {

    override val layoutId: Int
        get() = R.layout.activity_nationality

    override val viewModel: NationalityViewModel
        get() {
            return getViewModel(NationalityViewModel::class.java)
        }

    var flagAdapter = FlagAdapter()

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        initToolbar()
        initRecyclerView()
        getFlagList()
    }

    fun initToolbar(){
        viewDataBinding?.toolbar?.ivBack?.setOnClickListener {
            finish()
        }

        viewDataBinding?.toolbar?.tvTitle?.text = resources.getString(R.string.str_choose_nationality)
    }


    fun initRecyclerView(){
        viewDataBinding?.recyclerView?.layoutManager = LinearLayoutManager(this@NationalityActivity)
        viewDataBinding?.recyclerView?.adapter = flagAdapter
        flagAdapter.selectedListener = this@NationalityActivity
    }

    fun getFlagList(){
        viewModel.getFlagList(object : HandleResponse<FlagListResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(this@NationalityActivity)) {
                    this@NationalityActivity.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    this@NationalityActivity.onError(
                        error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                    )
                }
            }

            override fun handleSuccessRespons(successResponse: FlagListResponse) {
                if (successResponse.httpStatus == 200 && successResponse.success) {
                   flagAdapter.setItems(successResponse.response)
                }
            }
        })
    }

    override fun onSelected(flag: FlagObject) {
        val returnIntent = Intent()

        val bundle = Bundle()
        bundle.putSerializable("selected_flag", flag as Serializable)
        returnIntent.putExtras(bundle)
        setResult(RESULT_OK, returnIntent)
        finish()
    }
}