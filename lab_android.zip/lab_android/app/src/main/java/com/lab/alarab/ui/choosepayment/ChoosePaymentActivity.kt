package com.lab.alarab.ui.choosepayment

import android.os.Bundle
import com.lab.alarab.R
import com.lab.alarab.base.BaseActivity
import com.lab.alarab.databinding.ActivityChoosePaymentBinding

class ChoosePaymentActivity : BaseActivity<ActivityChoosePaymentBinding?, ChoosePaymentViewModel>() {

    override val layoutId: Int
        get() = R.layout.activity_choose_payment

    override val viewModel: ChoosePaymentViewModel
        get() = ChoosePaymentViewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewDataBinding?.layoutToolbar?.ivBack?.setOnClickListener {
            finish()
        }

        viewDataBinding?.layoutToolbar?.tvTitle?.text = resources.getString(R.string.str_choose_payment_method)
    }


}