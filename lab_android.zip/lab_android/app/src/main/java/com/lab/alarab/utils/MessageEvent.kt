package com.lab.alarab.utils

data class MessageEvent(
    val message: Int,
    val data: Any?
) {
    constructor(message: Int) : this(message, null)
}