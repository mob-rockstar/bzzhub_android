package com.lab.alarab.data.model.api.response.updateitemwithcalculation


import com.google.gson.annotations.SerializedName

data class UpdateWithCalculationResponse(
    var errorMessage: String?,
    var httpStatus: Int,
    var response: Response,
    var success: Boolean,
    var timestamp: Int
)