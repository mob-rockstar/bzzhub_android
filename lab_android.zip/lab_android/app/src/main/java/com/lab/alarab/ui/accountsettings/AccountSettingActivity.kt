package com.lab.alarab.ui.accountsettings

import android.content.Intent
import android.os.Bundle
import com.cometchat.pro.constants.CometChatConstants
import com.cometchat.pro.models.User
import com.lab.alarab.R
import com.lab.alarab.base.BaseActivity
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.databinding.ActivityAccountSettingBinding
import com.lab.alarab.ui.main.MainActivity
import com.lab.alarab.ui.orderscheduled.OrderScheduledActivity
import com.lab.alarab.ui.profile.ProfileActivity
import com.lab.alarab.ui.splash.SplashActivity
import com.lab.alarab.utils.AppConstants.CHAT_SUPPORT_ID
import com.lab.alarab.utils.AppConstants.CHAT_SUPPORT_NAME
import com.lab.alarab.utils.PopupUtils
import constant.StringContract
import dagger.android.AndroidInjector
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import screen.messagelist.CometChatMessageListActivity
import javax.inject.Inject


class AccountSettingActivity : BaseActivity<ActivityAccountSettingBinding?, AccountSettingViewModel>(),
    HasAndroidInjector {

    override val layoutId: Int
        get() = R.layout.activity_account_setting

    override val viewModel: AccountSettingViewModel
        get() = AccountSettingViewModel()

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewDataBinding?.ivBack?.setOnClickListener {
            finish()
        }

        viewDataBinding?.tvEditProfile?.setOnClickListener {
            startActivity(Intent(this@AccountSettingActivity, ProfileActivity::class.java))
        }

        viewDataBinding?.tvUserName?.setOnClickListener {
            startActivity(Intent(this@AccountSettingActivity, ProfileActivity::class.java))
        }

        viewDataBinding?.tvUserName?.setOnClickListener {
            startActivity(Intent(this@AccountSettingActivity, ProfileActivity::class.java))
        }

        viewDataBinding?.layoutContactUs?.setOnClickListener {

            val intent = Intent(this@AccountSettingActivity, CometChatMessageListActivity::class.java)
            intent.putExtra(StringContract.IntentStrings.TYPE, CometChatConstants.RECEIVER_TYPE_USER)
            intent.putExtra(StringContract.IntentStrings.NAME, CHAT_SUPPORT_NAME)
            intent.putExtra(StringContract.IntentStrings.UID, CHAT_SUPPORT_ID)
            startActivity(intent)
        }

        viewDataBinding?.layoutSendFeedback?.setOnClickListener {
            val i = Intent(Intent.ACTION_SEND)
            i.putExtra(Intent.EXTRA_EMAIL, arrayOf<String>("support@lab.com"))
            i.putExtra(Intent.EXTRA_SUBJECT, "Hello")
            i.putExtra(Intent.EXTRA_TEXT,"" )
            startActivity(Intent.createChooser(i, "Send email"))

        }

        viewDataBinding?.layoutLogout?.setOnClickListener {
            PopupUtils.showConfirmDialog(
                this,
                "",
                getString(R.string.str_are_you_sure_logout)
            ) {
                logout()
            }
        }

        viewDataBinding?.layoutLanguage?.setOnClickListener {
            showDialogFragment(LanguageFragment())
        }

        viewDataBinding?.tvUserName?.text = PreferenceManager.currentUserFirstName
    }

    private fun logout(){
        PreferenceManager.currentUserLoggedInMode = PreferenceManager.LoggedInMode.LOGGED_IN_MODE_LOGGED_OUT

        val intent = Intent(applicationContext, SplashActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        startActivity(intent)
        finish()
    }


}