package com.lab.alarab.ui.login.inputinfo

import android.app.Activity.RESULT_OK
import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.DatePicker
import android.widget.Toast
import android.widget.Toast.LENGTH_LONG
import androidx.core.content.ContextCompat
import com.lab.alarab.R
import com.lab.alarab.base.BaseInputFragment
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.data.model.api.response.ErrorResponse
import com.lab.alarab.data.model.api.response.SinUpResponse
import com.lab.alarab.data.model.api.response.flag.FlagObject
import com.lab.alarab.databinding.FragmentInputInfoBinding
import com.lab.alarab.di.Injectable
import com.lab.alarab.ui.login.LoginViewModel
import com.lab.alarab.ui.main.MainActivity
import com.lab.alarab.ui.nationality.NationalityActivity
import com.lab.alarab.utils.AppConstants
import com.lab.alarab.utils.NetworkUtils
import java.text.SimpleDateFormat
import java.util.Calendar.*


class InputInfoFragment  :
    BaseInputFragment<FragmentInputInfoBinding?, LoginViewModel>(), Injectable {

    override val layoutId: Int
        get() = R.layout.fragment_input_info

    override val viewModel: LoginViewModel
        get() {
            return getViewModel(baseActivity, LoginViewModel::class.java)
        }

    private val FLAG_SELECTION_REQUEST = 1001

    private var gender = 1
    private var dialCode = ""
    private var countryID = 0
    private var firstName = ""
    private var lastName = ""

    private var strCountryName = ""
    private var strYear = ""
    private var strMonth = ""
    private var strday = ""

    private var mDatePickerDialog: DatePickerDialog? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initToolbar()
        initUI()
        initDatePickerDialog()
        progressView = viewDataBinding?.layoutProgress
    }

    private fun initToolbar(){
        viewDataBinding?.toolbar?.ivBack?.setOnClickListener { popBackStack() }
    }

    private fun initUI(){
        viewDataBinding?.tvMale?.setOnClickListener {
            viewDataBinding?.tvMale?.background = ContextCompat.getDrawable(
                baseActivity,
                R.drawable.ic_rounded_white_background_8
            )
            gender = 1
            viewDataBinding?.tvFemale?.background = null
        }

        viewDataBinding?.tvFemale?.setOnClickListener {
            viewDataBinding?.tvMale?.background = null
            gender = 2
            viewDataBinding?.tvFemale?.background = ContextCompat.getDrawable(
                baseActivity,
                R.drawable.ic_rounded_white_background_8
            )
        }

        viewDataBinding?.toolbar?.tvHelp?.setOnClickListener {
            val i = Intent(Intent.ACTION_SEND)
            i.putExtra(Intent.EXTRA_EMAIL, arrayOf<String>("support@lab.com"))
            i.putExtra(Intent.EXTRA_SUBJECT, "Hello")
            i.putExtra(Intent.EXTRA_TEXT, "")
            startActivity(Intent.createChooser(i, "Send email"))
        }

        initRegisterButton()
        initListeners()
    }

    private fun initListeners(){
        viewDataBinding?.edittextNation?.setOnClickListener {
            val intent = Intent(baseActivity, NationalityActivity::class.java)
            startActivityForResult(intent, FLAG_SELECTION_REQUEST)
        }

        viewDataBinding?.edittextDob?.setOnClickListener{mDatePickerDialog?.show()}
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode === this.FLAG_SELECTION_REQUEST && resultCode === RESULT_OK) {
            val flag: FlagObject = data?.extras?.getSerializable("selected_flag") as FlagObject
            viewDataBinding?.edittextNation?.setText(flag.name)

            strCountryName = flag.name!!
            countryID = flag.id!!
            dialCode = flag.dialCode!!
        }
    }

    private fun initRegisterButton(){
        viewDataBinding?.tvContinue?.setOnClickListener {
            firstName = viewDataBinding?.edittextFirstName?.text.toString()
            lastName = viewDataBinding?.edittextLastName?.text.toString()

           val errorMessage = when {
               firstName.isEmpty() -> {
                   baseActivity.resources.getString(R.string.str_please_enter_first_name)
               }
               lastName.isEmpty() -> {
                   baseActivity.resources.getString(R.string.str_please_enter_second_name)
               }
               strYear.isEmpty() -> {
                   baseActivity.resources.getString(R.string.str_please_enter_birthday)
               }
               strCountryName.isEmpty() -> {
                   baseActivity.resources.getString(R.string.str_please_choose_country)
               }
               else -> {
                   ""
               }
           }

            if (errorMessage.isEmpty()){
                signUpUser()
            }else{
                Toast.makeText(baseActivity, errorMessage, LENGTH_LONG).show()
            }
        }
    }

    private fun signUpUser(){
        viewModel.signUp(viewModel.strCountryCode,
            viewModel.strMobile,
            countryID.toString(),
            gender,
            strYear,
            strMonth,
            strday,
            firstName,
            lastName,
            object : HandleResponse<SinUpResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (NetworkUtils.isNetworkConnected(baseActivity)) {
                        this@InputInfoFragment.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        this@InputInfoFragment.onError(
                            error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }

                override fun handleSuccessRespons(successResponse: SinUpResponse) {
                    PreferenceManager.userData = successResponse.response
                    startActivity(Intent(activity, MainActivity::class.java))
                    finishActivity()
                }
            })
    }

    private fun initDatePickerDialog() {
        val newCalendar = getInstance()
        mDatePickerDialog = DatePickerDialog(
            baseActivity,
            R.style.styleDatePickerDialog,
            { _: DatePicker?, year: Int, monthOfYear: Int, dayOfMonth: Int ->
                val newDate = getInstance()
                newDate[year, monthOfYear] = dayOfMonth
                val sd = SimpleDateFormat("dd/MM/yyyy")
                
                val formatDate =
                    SimpleDateFormat("yyyy")

                val formatMonth =
                    SimpleDateFormat("MM")

                val formatDay =
                    SimpleDateFormat("dd")

                val startDate = newDate.time
                val fdate = sd.format(startDate)
                strYear = formatDate.format(startDate)
                strMonth = formatMonth.format(startDate)
                strday = formatDay.format(startDate)
                viewDataBinding?.edittextDob?.setText(fdate)
            },
            newCalendar[YEAR],
            newCalendar[MONTH],
            newCalendar[DAY_OF_MONTH]
        )
        val c = getInstance()
        c.add(YEAR, -6) // subtract 2 years from now
        mDatePickerDialog!!.datePicker.maxDate = c.timeInMillis
        mDatePickerDialog!!.setTitle("")
    }
}