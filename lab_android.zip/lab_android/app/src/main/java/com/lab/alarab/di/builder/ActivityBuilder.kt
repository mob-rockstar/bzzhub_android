package com.lab.alarab.di.builder

import com.lab.alarab.ui.accountsettings.AccountSettingActivity
import com.lab.alarab.ui.checkout.CheckoutActivity
import com.lab.alarab.ui.choosedelivery.ChooseDeliveryActivity
import com.lab.alarab.ui.choosepayment.ChoosePaymentActivity
import com.lab.alarab.ui.editaddress.EditAddressActivity
import com.lab.alarab.ui.forgotpassword.ForgotPasswordActivity
import com.lab.alarab.ui.login.LoginActivity
import com.lab.alarab.ui.main.MainActivity
import com.lab.alarab.ui.nationality.NationalityActivity
import com.lab.alarab.ui.order.OrderActivity
import com.lab.alarab.ui.orderdetail.OrderDetailActivity
import com.lab.alarab.ui.orderscheduled.OrderScheduledActivity
import com.lab.alarab.ui.patient.AddPatientActivity
import com.lab.alarab.ui.payment.PaymentActivity
import com.lab.alarab.ui.pickup.PickUpAddressActivity
import com.lab.alarab.ui.profile.ProfileActivity
import com.lab.alarab.ui.resultexplanation.ResultExplanationActivity
import com.lab.alarab.ui.search.SearchProductActivity
import com.lab.alarab.ui.splash.SplashActivity
import com.lab.alarab.ui.time.AvailableTimeActivity
import com.lab.alarab.ui.videovisit.VideoVisitActivity
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class ActivityBuilder {
    @ContributesAndroidInjector
    abstract fun bindSplashActivity(): SplashActivity

    @ContributesAndroidInjector(modules = [FragmentLoginModule::class])
    abstract fun bindLoginActivity(): LoginActivity

    @ContributesAndroidInjector(modules = [FragmentMainModule::class])
    abstract fun bindMainActivity(): MainActivity

    @ContributesAndroidInjector
    abstract fun bindOrderActivity(): OrderActivity

    @ContributesAndroidInjector
    abstract fun bindCheckoutActivity(): CheckoutActivity

    @ContributesAndroidInjector
    abstract fun bindChooseDeliveryActivity(): ChooseDeliveryActivity

    @ContributesAndroidInjector
    abstract fun bindPaymentActivity(): PaymentActivity

    @ContributesAndroidInjector
    abstract fun bindOrderScheduledActivity(): OrderScheduledActivity

    @ContributesAndroidInjector
    abstract fun bindOrderResultExplanationActivity(): ResultExplanationActivity

    @ContributesAndroidInjector
    abstract fun bindVideoVisitActivity(): VideoVisitActivity

    @ContributesAndroidInjector
    abstract fun bindOrderDetailActivity(): OrderDetailActivity

    @ContributesAndroidInjector
    abstract fun bindChoosePaymentActivity(): ChoosePaymentActivity

    @ContributesAndroidInjector
    abstract fun bindPickUpAddressActivity(): PickUpAddressActivity

    @ContributesAndroidInjector
    abstract fun bindEditAddressActivity(): EditAddressActivity

    @ContributesAndroidInjector(modules = [FragmentAccountSettingModule::class])
    abstract fun bindAccountSettingActivity(): AccountSettingActivity

    @ContributesAndroidInjector
    abstract fun bindAccountProfileActivity(): ProfileActivity

    @ContributesAndroidInjector
    abstract fun bindNationalityActivity(): NationalityActivity

    @ContributesAndroidInjector(modules = [FragmentSearchModule::class])
    abstract fun bindSearchProductActivity(): SearchProductActivity

    @ContributesAndroidInjector(modules = [FragmentForgotPasswordModule::class])
    abstract fun bindForgotPasswordActivity(): ForgotPasswordActivity

    @ContributesAndroidInjector
    abstract fun bindAddPatientActivity(): AddPatientActivity

    @ContributesAndroidInjector
    abstract fun bindAvailableTimeActivity(): AvailableTimeActivity
}