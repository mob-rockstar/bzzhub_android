package com.lab.alarab.di.factory

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.lab.alarab.ui.accountsettings.AccountSettingViewModel
import com.lab.alarab.ui.checkout.CheckoutViewModel
import com.lab.alarab.ui.choosedelivery.ChooseDeliveryViewModel
import com.lab.alarab.ui.choosepayment.ChoosePaymentViewModel
import com.lab.alarab.ui.editaddress.EditAddressViewModel
import com.lab.alarab.ui.forgotpassword.ForgotPasswordViewModel
import com.lab.alarab.ui.login.LoginViewModel
import com.lab.alarab.ui.main.MainViewModel
import com.lab.alarab.ui.nationality.NationalityViewModel
import com.lab.alarab.ui.order.OrderViewModel
import com.lab.alarab.ui.orderdetail.OrderDetailViewModel
import com.lab.alarab.ui.orderscheduled.OrderScheduleViewModel
import com.lab.alarab.ui.patient.PatientViewModel
import com.lab.alarab.ui.payment.PaymentViewModel
import com.lab.alarab.ui.pickup.PickUpViewModel
import com.lab.alarab.ui.profile.ProfileViewModel
import com.lab.alarab.ui.resultexplanation.ResultExplanationViewModel
import com.lab.alarab.ui.search.SearchViewModel
import com.lab.alarab.ui.splash.SplashViewModel
import com.lab.alarab.ui.time.AvailableTimeViewModel
import com.lab.alarab.ui.videovisit.VideoVisitViewModel
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ViewModelProviderFactory @Inject constructor() : ViewModelProvider.NewInstanceFactory() {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(SplashViewModel::class.java) -> {
                SplashViewModel() as T
            }
            modelClass.isAssignableFrom(LoginViewModel::class.java) -> {
                LoginViewModel() as T
            }
            modelClass.isAssignableFrom(MainViewModel::class.java) -> {
                MainViewModel() as T
            }

            modelClass.isAssignableFrom(NationalityViewModel::class.java) -> {
                NationalityViewModel() as T
            }

            modelClass.isAssignableFrom(OrderViewModel::class.java) -> {
                OrderViewModel() as T
            }
            modelClass.isAssignableFrom(OrderDetailViewModel::class.java) -> {
                OrderDetailViewModel() as T
            }
            modelClass.isAssignableFrom(OrderScheduleViewModel::class.java) -> {
                OrderScheduleViewModel() as T
            }
            modelClass.isAssignableFrom(PaymentViewModel::class.java) -> {
                PaymentViewModel() as T
            }
            modelClass.isAssignableFrom(ProfileViewModel::class.java) -> {
                ProfileViewModel() as T
            }
            modelClass.isAssignableFrom(ResultExplanationViewModel::class.java) -> {
                ResultExplanationViewModel() as T
            }
            modelClass.isAssignableFrom(VideoVisitViewModel::class.java) -> {
                VideoVisitViewModel() as T
            }
            modelClass.isAssignableFrom(AccountSettingViewModel::class.java) -> {
                AccountSettingViewModel() as T
            }

            modelClass.isAssignableFrom(CheckoutViewModel::class.java) -> {
                CheckoutViewModel() as T
            }

            modelClass.isAssignableFrom(ChooseDeliveryViewModel::class.java) -> {
                ChooseDeliveryViewModel() as T
            }
            modelClass.isAssignableFrom(EditAddressViewModel::class.java) -> {
                EditAddressViewModel() as T
            }
            modelClass.isAssignableFrom(SearchViewModel::class.java) -> {
                SearchViewModel() as T
            }
            modelClass.isAssignableFrom(ForgotPasswordViewModel::class.java) -> {
                ForgotPasswordViewModel() as T
            }

            modelClass.isAssignableFrom(PatientViewModel::class.java) -> {
                PatientViewModel() as T
            }

            modelClass.isAssignableFrom(AvailableTimeViewModel::class.java) -> {
                AvailableTimeViewModel() as T
            }
            else -> throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
        }
    }
}