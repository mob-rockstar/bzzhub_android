package com.lab.alarab.data.model.api.response.timeslot


data class Response(
    var afternoon: List<Time>,
    var evening: List<Time>,
    var morning: List<Time>
)