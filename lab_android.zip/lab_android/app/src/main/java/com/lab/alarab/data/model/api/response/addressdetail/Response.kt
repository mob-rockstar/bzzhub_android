package com.lab.alarab.data.model.api.response.addressdetail


import com.google.gson.annotations.SerializedName

data class Response(
    var address: Address
)