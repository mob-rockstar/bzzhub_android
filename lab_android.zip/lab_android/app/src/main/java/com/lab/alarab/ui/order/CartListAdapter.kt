package com.lab.alarab.ui.order

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.lab.alarab.R
import com.lab.alarab.base.BaseRecyclerViewAdapter
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.data.model.api.response.cart.Package
import com.lab.alarab.databinding.RecyclerItemOrderBinding

class CartListAdapter (private val onRemoveItem: (packageID: Int?, position: Int) -> Unit)  : BaseRecyclerViewAdapter<Package, RecyclerItemOrderBinding>()  {
    override val layoutId: Int
        get() = R.layout.recycler_item_order

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return CartViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as CartViewHolder

        if (PreferenceManager.language.equals("en")) {
            holder.binding.tvContent.text = items[position].nAMEEN
        }else{
            holder.binding.tvContent.text = items[position].nAMEAR
        }

        holder.binding.tvPrice.text = items[position].pRICE.toString() + "\nSAR"

        holder.binding.ivRemove.setOnClickListener {
                onRemoveItem(items[position].cARTPACKAGEID, position)
        }
    }

    fun removeItem(position: Int){
        items.removeAt(position)
        notifyDataSetChanged()
    }

    inner class CartViewHolder(val binding: RecyclerItemOrderBinding) :
        RecyclerView.ViewHolder(binding.root)
}