package com.lab.alarab.ui.search.notification

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.lab.alarab.R
import com.lab.alarab.base.BaseDialogFragment
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.model.api.response.ErrorResponse
import com.lab.alarab.data.model.api.response.notificationresponse.NotificationResponse
import com.lab.alarab.databinding.FragmentNotificationBinding
import com.lab.alarab.di.Injectable
import com.lab.alarab.ui.main.MainActivity
import com.lab.alarab.ui.search.SearchViewModel
import com.lab.alarab.utils.AppConstants
import com.lab.alarab.utils.MessageEvent
import com.lab.alarab.utils.NetworkUtils
import org.greenrobot.eventbus.EventBus


class NotificationFragment :
    BaseDialogFragment<FragmentNotificationBinding?, SearchViewModel>(), Injectable {


    override val layoutId: Int
        get() = R.layout.fragment_notification

    override val viewModel: SearchViewModel
        get() {
            return getViewModel(baseActivity, SearchViewModel::class.java)
        }

    override fun getTheme(): Int {
        return R.style.FullScreenDialogFragmentTheme
    }

    var notificationsAdapter: NotificationAdapter = NotificationAdapter(){
        deepLink ->  setMessage(deepLink)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initRecyclerView()
        getNotifications()

        viewDataBinding?.toolbar?.ivBack?.setOnClickListener {
            dismiss()
        }

        viewDataBinding?.toolbar?.tvTitle?.text = baseActivity.resources.getString(R.string.str_notifications)
    }

    private fun setMessage(deepLink: String){
        var currentTab = 1
        if (deepLink.toLowerCase().contains("results")){
            currentTab = 3
        //    EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_GO_RESULT))
        }else if (deepLink.toLowerCase().contains("orders")){
            currentTab = 2
       //     EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_GO_ORDER))
        }
        val intent = Intent(baseActivity, MainActivity::class.java)
        intent.putExtra("current_tab", currentTab)
        startActivity(intent)
        dismiss()
        finishActivity()
    }

    private fun initRecyclerView(){
        viewDataBinding?.recyclerView?.layoutManager = LinearLayoutManager(baseActivity)
        viewDataBinding?.recyclerView?.adapter = notificationsAdapter
    }

    private fun getNotifications(){
        viewModel.getNotification(
            object : HandleResponse<NotificationResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (NetworkUtils.isNetworkConnected(baseActivity)) {
                        this@NotificationFragment.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        this@NotificationFragment.onError(
                            error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }

                override fun handleSuccessRespons(successResponse: NotificationResponse) {
                    if (successResponse.success && successResponse.httpStatus == 200){
                        notificationsAdapter.setItems(successResponse.response.notifications    )
                    }else{
                        this@NotificationFragment.onError(
                            AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    }
                }
            }
        )
    }

}