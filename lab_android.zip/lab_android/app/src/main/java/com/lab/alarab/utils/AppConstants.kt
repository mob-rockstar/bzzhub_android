package com.lab.alarab.utils

import com.lab.alarab.data.model.api.response.city.Response
import com.lab.alarab.data.model.api.response.landing.CategoryType

object AppConstants {
    const val APP_NAME = "LabAPp"
    const val DEFAULT_ERROR_MESSAGE = "There was an error, please try again lager"
    const val NETWORK_ERROR_MESSAGE = "Please check your internet connection"

    const val CURRENCY_CODE = "SAR"

    const val PREF_NAME = "arabLab_pref"
    const val NULL_INDEX = -1L
    const val DB_NAME = "arablab.db"

    const val MESSAGE_GET_CART_COUNT = 1010
    const val MESSAGE_CART_CHANGED = 1015
    const val MESSAGE_ADDRESS_CHANGED = 1020
    const val RELOAD_ORDER = 1025
    const val MESSAGE_UPDATE_PROFILE = 1030
    const val MESSAGE_GO_RESULT = 1035
    const val MESSAGE_GO_ORDER = 1040

    const val GOOGLE_MAP_API_KEY = "AIzaSyD5yLaJroPHBf5sdn9PV63NmzM71OX6guw"

    var categoryType:List<CategoryType>?= null

    var categoryID: Int =0

    const val ENGLISH = "en"
    const val ARABIC = "ar"

    const val CHAT_APP_ID = "2661430bcd06ee7"
    const val CHAT_AUTH_KEY = "5550b1b7527513d810faf61f75c37ded364bc3e3"
    const val CHAT_REGION = "eu"

    const val CHAT_SUPPORT_NAME = "Cometchat-Lab"
    const val CHAT_SUPPORT_ID = "1"

    const val PAYFORT_URL_SANDBOX = "https://sbpaymentservices.payfort.com/FortAPI/paymentApi"
    const val PAYFORT_URL_LIVE = "https://sbpaymentservices.payfort.com/FortAPI/paymentApi"

    var PAYFORT_ACCESS_CODE_PRODUCTION = "Y9ia6yGEdwp5W5xbBn9D"
    var PAYFORT_LANGUAGE = "en"
    var PAYFORT_MERCHANT_ID_PRODUCTION = "be4dfb83"
    var PAYFORT_SDK_TOKEN = "SDK_TOKEN"
    var PAYFORT_MODE_AUTHORIZATION = "AUTHORIZATION"
    const val PAYFORT_MODE_PURCHASE = "PURCHASE"
    var PAYFORT_KEY = "/bq92NHCToZ5dYaffD7L"

    const val PAYFORT_CUSTOMER_EMAIL = "m.rabea@alarablabs.com"
    var PAYFORT_AUTH_PATH = "/bq92NHCToZ5dYaffD7L"
    const val PAYFORT_CURRENCY = "JOD"
    const val PAYFORT_ESCI = "ECOMMERCE"

    // Constant for Payfort
    const val FORT_REQUEST_CODE: Int = 5
    var orderId: Int = 0
    var cityName = ""
    var selectedTimeId = 0
    var strDateForAPI = ""
    var lat = 0.0
    var lng = 0.0

    var packageId = 0
    var cityList: List<Response> = ArrayList()

    var paymentMode = 0
    var hospitalId = 0
}