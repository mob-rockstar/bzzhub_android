package com.lab.alarab.data.model.api.response.landing


import com.google.gson.annotations.SerializedName

data class Response(
    var categoryTypes: List<CategoryType>,
    var defaultAddress: List<DefaultAddres>,
    var defaultCategories: ArrayList<DefaultCategory>,
    var defaultProducts: ArrayList<DefaultProduct>,
    var defaultSlider: ArrayList<DefaultSlider>
)