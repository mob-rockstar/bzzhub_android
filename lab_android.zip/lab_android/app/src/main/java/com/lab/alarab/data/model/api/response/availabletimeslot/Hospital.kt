package com.lab.alarab.data.model.api.response.availabletimeslot

data class Hospital(
    val AvailableTimes: List<AvailableTime>,
    val CITYSTATE: CITYSTATE?,
    val DISTANCE: Double,
    val GPS_LATITUDE: String,
    val GPS_LONGITUDE: String,
    val ID: Int,
    val IMAGE_URL: String,
    val NAME_AR: String,
    val NAME_EN: String,
    val TITLE_AR: String,
    val TITLE_EN: String
)