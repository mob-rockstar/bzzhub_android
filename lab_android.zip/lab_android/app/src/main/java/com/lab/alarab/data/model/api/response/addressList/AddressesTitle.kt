package com.lab.alarab.data.model.api.response.addressList


import com.google.gson.annotations.SerializedName

data class AddressesTitle(
    var addresses: List<Addresse>,
    @SerializedName("ID")
    var iD: Int,
    @SerializedName("NAME_AR")
    var nAMEAR: String,
    @SerializedName("NAME_EN")
    var nAMEEN: String
)