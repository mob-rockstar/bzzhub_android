package com.lab.alarab.data.model.api.response.availabletimeslot

data class Package(
    val ACTIVE_STATUS: Int,
    val CITY_ID: Any,
    val DESC_AR: Any,
    val DESC_EN: Any,
    val FASTING_REQUIRED: Int,
    val HOSPITAL_ID: Any,
    val ID: Int,
    val IMAGE_URL: Any,
    val LAB_CATEGORY_ID: Int,
    val NAME_AR: String,
    val NAME_EN: String,
    val PRICE: Int,
    val TEST_COUNT: Any,
    val TEST_TYPE: Any
)