package com.lab.alarab.ui.patient

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.DatePicker
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.lab.alarab.R
import com.lab.alarab.base.BaseActivity
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.model.api.response.ErrorResponse
import com.lab.alarab.data.model.api.response.flag.FlagObject
import com.lab.alarab.data.model.api.response.updateitemwithcalculation.UpdateWithCalculationResponse
import com.lab.alarab.databinding.ActivityAddPatientBinding
import com.lab.alarab.ui.nationality.NationalityActivity
import com.lab.alarab.utils.AppConstants
import com.lab.alarab.utils.DateUtils
import com.lab.alarab.utils.NetworkUtils
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

class AddPatientActivity: BaseActivity<ActivityAddPatientBinding?, PatientViewModel>() ,
    HasAndroidInjector {

    override val layoutId: Int
        get() = R.layout.activity_add_patient

    override val viewModel: PatientViewModel
        get() {
            return getViewModel(PatientViewModel::class.java)
        }

    private var strCountryName = ""
    private var strYear = ""
    private var strMonth = ""
    private var strday = ""
    private var gender = 1

    private var strEmail = ""

    private var dialCode = ""
    private var countryID = 0
    private var firstName = ""
    private var lastName = ""
    private val FLAG_SELECTION_REQUEST = 1001
    private var mDatePickerDialog: DatePickerDialog? = null

    private var packageId : Int = 0

    private var strMobile = ""
    private var strCountryCode = ""

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        initDatePickerDialog()
        initUI()

        initContinueButton()
    }

    private fun initUI(){
        viewDataBinding?.edittextNation?.setOnClickListener {
            val intent = Intent(this@AddPatientActivity, NationalityActivity::class.java)
            startActivityForResult(intent, FLAG_SELECTION_REQUEST)
        }

        viewDataBinding?.layoutCancel?.setOnClickListener {
            finish()
        }

        viewDataBinding?.edittextDob?.setOnClickListener{
            mDatePickerDialog?.show()
        }

        viewDataBinding?.tvMale?.setOnClickListener {
            viewDataBinding?.tvMale?.background = ContextCompat.getDrawable(
                this@AddPatientActivity,
                R.drawable.ic_rounded_white_background_8
            )
            gender = 1
            viewDataBinding?.tvFemale?.background = null
        }

        viewDataBinding?.tvFemale?.setOnClickListener {
            viewDataBinding?.tvMale?.background = null
            gender = 2
            viewDataBinding?.tvFemale?.background = ContextCompat.getDrawable(
                this@AddPatientActivity,
                R.drawable.ic_rounded_white_background_8
            )
        }
    }

    private fun initDatePickerDialog() {
        val newCalendar = Calendar.getInstance()
        mDatePickerDialog = DatePickerDialog(
            this@AddPatientActivity,
            R.style.styleDatePickerDialog,
            { _: DatePicker?, year: Int, monthOfYear: Int, dayOfMonth: Int ->
                val newDate = Calendar.getInstance()
                newDate[year, monthOfYear] = dayOfMonth
                val sd = SimpleDateFormat("yyyy-mm-dd")

                val formatDate =
                    SimpleDateFormat("yyyy")

                val formatMonth =
                    SimpleDateFormat("MM")

                val formatDay =
                    SimpleDateFormat("dd")

                val startDate = newDate.time
                val fdate = sd.format(startDate)
                strYear = formatDate.format(startDate)
                strMonth = formatMonth.format(startDate)
                strday = formatDay.format(startDate)
                viewDataBinding?.edittextDob?.setText(fdate)
            },
            newCalendar[Calendar.YEAR],
            newCalendar[Calendar.MONTH],
            newCalendar[Calendar.DAY_OF_MONTH]
        )
        val c = Calendar.getInstance()
        c.add(Calendar.YEAR, -6) // subtract 2 years from now
        mDatePickerDialog!!.datePicker.maxDate = c.timeInMillis
        mDatePickerDialog!!.setTitle("")
    }

    private fun initContinueButton(){

        viewDataBinding?.tvContinue?.setOnClickListener {
            initValues()
            val validationMessage = verifyInfo()
            if (verifyInfo().isEmpty()){
                editInfo()
            }else{
                Toast.makeText(this@AddPatientActivity, validationMessage, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun editInfo(){
        viewModel.addPatient(AppConstants.packageId,
            2,
            "$firstName $lastName",
            gender,
            strCountryCode + strMobile,
            countryID,
            strday.toInt(),
            strMonth.toInt(),
            strYear.toInt(),
            object : HandleResponse<UpdateWithCalculationResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (NetworkUtils.isNetworkConnected(this@AddPatientActivity)) {
                        this@AddPatientActivity.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        this@AddPatientActivity.onError(
                            error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }

                override fun handleSuccessRespons(successResponse: UpdateWithCalculationResponse) {
                    if (successResponse.success && successResponse.httpStatus == 200){
                        finish()
                    }

                }
            }
        )
    }

    private fun initValues(){
        firstName = viewDataBinding?.edittextFirstName?.text.toString()
        lastName = viewDataBinding?.edittextLastName?.text.toString()
        strEmail = viewDataBinding?.edittextEmail?.text.toString()
        if (viewDataBinding?.edittextDob?.text.toString().isNotEmpty()){
            strYear =  DateUtils.getYear(viewDataBinding?.edittextDob?.text.toString())
            strMonth = DateUtils.getMonth(viewDataBinding?.edittextDob?.text.toString())
            strday = DateUtils.getDay(viewDataBinding?.edittextDob?.text.toString())
        }
        strCountryName = viewDataBinding?.edittextNation?.text.toString()

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode === this.FLAG_SELECTION_REQUEST && resultCode === RESULT_OK) {
            val flag: FlagObject = data?.extras?.getSerializable("selected_flag") as FlagObject
            viewDataBinding?.edittextNation?.setText(flag.name)

            strCountryName = flag.name!!
            countryID = flag.id!!
            dialCode = flag.dialCode!!
        }
    }

    private fun verifyInfo(): String{
        return if (!isValidFirstName()){
            resources.getString(R.string.str_please_enter_first_name)
        }else if (!isValidLastName()){
            resources.getString(R.string.str_please_enter_second_name)
        }else if(!isEmailValid()){
            resources.getString(R.string.str_please_enter_valid_email)
        }else if (!isBirthdayValid()){
            resources.getString(R.string.str_please_enter_birthday)
        }else if (!isValidMobile()){
            resources.getString(R.string.str_enter_valid_mobile)
        }else if (!isValidNationality()){
            resources.getString(R.string.str_choose_nationality)
        } else{
            ""
        }
    }


    private fun isValidMobile(): Boolean{
        strMobile = viewDataBinding?.edittextMobile?.text.toString().trim()
        strCountryCode = viewDataBinding?.countryPicker?.selectedCountryCodeWithPlus!!
        return strMobile.length > 7
    }

    private fun isValidFirstName(): Boolean{
        return firstName.isNotEmpty()
    }

    private fun isValidLastName(): Boolean{
        return lastName.isNotEmpty()
    }

    fun isEmailValid(): Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(strEmail).matches()
    }

    fun isBirthdayValid(): Boolean{
        return strYear.isNotEmpty()
    }

    fun isValidNationality(): Boolean{
        return strCountryName.isNotEmpty()
    }
}