package com.lab.alarab.di.builder

import com.lab.alarab.ui.accountsettings.LanguageFragment
import com.lab.alarab.ui.login.inputmobile.InputMobileFragment
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class FragmentAccountSettingModule {
    @ContributesAndroidInjector
    abstract fun contributeLanguageFragment(): LanguageFragment
}