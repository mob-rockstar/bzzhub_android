package com.lab.alarab.ui.search

import com.lab.alarab.base.BaseViewModel
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.model.api.response.notificationresponse.NotificationResponse
import com.lab.alarab.data.model.api.response.searchresult.SearchResultResponse
import com.lab.alarab.data.model.api.response.updateitemwithcalculation.UpdateWithCalculationResponse
import com.lab.alarab.data.remote.APIManager
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class SearchViewModel : BaseViewModel() {

    fun getProductSearchResults(
        categoryID: Int,
        query: String,
        categoryType: Int,
        handleResponse: HandleResponse<SearchResultResponse>
    ){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.getSearchResults(categoryType, query , categoryID)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

    // API to add item to cart
    fun addToCart(
        packageId: Int,
        handleResponse: HandleResponse<UpdateWithCalculationResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.addAll(
            APIManager.addToCartWithCalculations(packageId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }


    fun getNotification(
        handleResponse: HandleResponse<NotificationResponse>
    ){
        compositeDisposable.add(
            APIManager.getNotifications()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }
}