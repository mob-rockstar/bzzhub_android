package com.lab.alarab.ui.accountsettings

import com.lab.alarab.base.BaseViewModel

class AccountSettingViewModel :BaseViewModel(){

}