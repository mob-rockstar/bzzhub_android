package com.lab.alarab.ui.payment

import com.lab.alarab.base.BaseViewModel
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.data.model.api.TokenResponse
import com.lab.alarab.data.model.api.response.addorder.AddOrderResponse
import com.lab.alarab.data.model.api.response.cart.CartResponse
import com.lab.alarab.data.model.api.response.orderdetail.OrderDetailResponse
import com.lab.alarab.data.model.api.response.removewithcalculation.RemoveWithCalculationResponse
import com.lab.alarab.data.remote.APIManager
import com.lab.alarab.utils.AppConstants
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class PaymentViewModel  : BaseViewModel() {

    // Get Payfort Token
    fun getPayFortToken(userId: Long, deviceID: String, handleResponse: HandleResponse<TokenResponse>) {
        setIsLoading(true)
        compositeDisposable.add(APIManager.getPayFortToken(userId, deviceID)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { result ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleSuccessRespons(result)
                    }
                },
                { x ->
                    run {
                        setIsLoading(false)
                        handleResponse.handleErrorResponse(getThrowableError(x))
                    }
                }
            ))
    }

    fun getOrderDetail(
        orderID: Int,
        handleResponse: HandleResponse<OrderDetailResponse>
    ){
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.getOrderDetail(orderID)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

    fun getCartList(
        handleResponse: HandleResponse<CartResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.addAll(
            APIManager.viewCart()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

    fun addOrder(
        city: String,
        paymentMethodID : Int,
        availableTimeId: Int,
        availableDate: String,
        lat : Double,
        lng : Double,
        handleResponse: HandleResponse<AddOrderResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.addOrder(city,paymentMethodID,availableTimeId,availableDate,lng, lat, AppConstants.hospitalId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

    fun removeCart(
        packageId: Int,
        handleResponse: HandleResponse<RemoveWithCalculationResponse>){
        setIsLoading(true)
        compositeDisposable.addAll(
            APIManager.removeCartWithCalculations(packageId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

}