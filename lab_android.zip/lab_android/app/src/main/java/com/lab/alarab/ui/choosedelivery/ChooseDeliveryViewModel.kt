package com.lab.alarab.ui.choosedelivery

import com.google.gson.JsonObject
import com.lab.alarab.base.BaseViewModel
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.model.api.response.DeleteAddressResponse
import com.lab.alarab.data.model.api.response.addressList.AddressListResponse
import com.lab.alarab.data.remote.APIManager
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class ChooseDeliveryViewModel : BaseViewModel() {
    fun getGoogleAddress(
        latitude: Double,
        longitude: Double,
        handleResponse: HandleResponse<JsonObject>
    ) {
        compositeDisposable.add(
            APIManager.getGoogleAddress(latitude, longitude)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

    fun getAddressList(handleResponse: HandleResponse<AddressListResponse>){
        compositeDisposable.add(
            APIManager.getAddressList()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

    fun removeAddress(addressId: Int, handleResponse: HandleResponse<DeleteAddressResponse>){
        compositeDisposable.add(
            APIManager.deleteAddress(addressId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

    fun getAddressMetaData(){

    }
}