package com.lab.alarab.data.model.api

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import com.lab.alarab.utils.AppConstants
import com.lab.alarab.utils.AppConstants.PAYFORT_LANGUAGE
import com.lab.alarab.utils.AppConstants.PAYFORT_MERCHANT_ID_PRODUCTION
import com.lab.alarab.utils.AppConstants.PAYFORT_SDK_TOKEN

class TokenRequestBody {
    @SerializedName("service_command")
    @Expose
    var serviceCommand: String = PAYFORT_SDK_TOKEN

    @SerializedName("access_code")
    @Expose
    var accessCode: String = AppConstants.PAYFORT_ACCESS_CODE_PRODUCTION

    @SerializedName("merchant_identifier")
    @Expose
    var merchantIdentifier: String = PAYFORT_MERCHANT_ID_PRODUCTION

    @SerializedName("language")
    @Expose
    var language: String = PAYFORT_LANGUAGE

    @SerializedName("device_id")
    @Expose
    var deviceId: String? = null

    @SerializedName("signature")
    @Expose
    var signature: String? = null

}