package com.lab.alarab.ui.forgotpassword

import android.os.Bundle
import com.lab.alarab.R
import com.lab.alarab.base.BaseActivity
import com.lab.alarab.databinding.ActivityForgotPasswordBinding
import com.lab.alarab.ui.forgotpassword.inputmobile.ForgotPasswordInputMobileFragment
import com.lab.alarab.ui.login.inputmobile.InputMobileFragment
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import javax.inject.Inject

class ForgotPasswordActivity : BaseActivity<ActivityForgotPasswordBinding?, ForgotPasswordViewModel>(),
    HasAndroidInjector {

    override val layoutId: Int
        get() = R.layout.activity_forgot_password

    override val viewModel: ForgotPasswordViewModel
        get() {
            return getViewModel(ForgotPasswordViewModel::class.java)
        }

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        replaceFragmentDirectly(R.id.frameLayout, ForgotPasswordInputMobileFragment())
    }
}