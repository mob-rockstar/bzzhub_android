package com.lab.alarab.ui.orderscheduled

import android.content.Intent
import android.net.sip.SipErrorCode.TIME_OUT
import android.os.Bundle
import android.os.Handler
import com.lab.alarab.R
import com.lab.alarab.base.BaseActivity
import com.lab.alarab.databinding.ActivityOrderScheduledBinding
import com.lab.alarab.ui.main.MainActivity
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import javax.inject.Inject


class OrderScheduledActivity : BaseActivity<ActivityOrderScheduledBinding?, OrderScheduleViewModel>() ,
    HasAndroidInjector {

    override val layoutId: Int
        get() = R.layout.activity_order_scheduled

    override val viewModel: OrderScheduleViewModel
        get() {
            return getViewModel(OrderScheduleViewModel::class.java)
        }

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        Handler().postDelayed(Runnable {
            startActivity(Intent(this@OrderScheduledActivity, MainActivity::class.java))
            finish()
        }, 1000)
    }
}