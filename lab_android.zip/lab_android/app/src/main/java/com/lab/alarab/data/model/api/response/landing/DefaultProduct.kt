package com.lab.alarab.data.model.api.response.landing


import com.google.gson.annotations.SerializedName
import com.lab.alarab.data.model.api.response.LabPackageItems

data class DefaultProduct(
    @SerializedName("ACTIVE_STATUS")
    var aCTIVESTATUS: Int,
    @SerializedName("CART_ID")
    var cARTID: Long?,
    @SerializedName("CITY_ID")
    var cITYID: Int?,
    @SerializedName("DESC_AR")
    var dESCAR: String?,
    @SerializedName("DESC_EN")
    var dESCEN: String?,
    @SerializedName("FASTING_REQUIRED")
    var fASTINGREQUIRED: Int,
    @SerializedName("HOSPITAL_ID")
    var hOSPITALID: Any,
    @SerializedName("ID")
    var iD: Int,
    @SerializedName("LAB_CATEGORY_ID")
    var lABCATEGORYID: Int,
    @SerializedName("NAME_AR")
    var nAMEAR: String,
    @SerializedName("NAME_EN")
    var nAMEEN: String,
    @SerializedName("IMAGE_URL")
    var ImageUrl: String ?= null,
    @SerializedName("PRICE")
    var pRICE: Int,
    @SerializedName("TEST_TYPE")
    var tESTTYPE: Any,
    @SerializedName("lABPACKAGEITEMS")
    var lABPACKAGEITEMS: List<LabPackageItems>? = null


)