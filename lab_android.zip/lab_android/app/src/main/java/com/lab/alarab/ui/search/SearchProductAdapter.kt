package com.lab.alarab.ui.search

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.lab.alarab.R
import com.lab.alarab.base.BaseRecyclerViewAdapter
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.data.model.api.response.landing.DefaultProduct
import com.lab.alarab.databinding.RecyclerItemSearchProductBinding
import com.lab.alarab.utils.PopupUtils

class SearchProductAdapter(private val onAddToCart: (packageID: DefaultProduct?) -> Unit) : BaseRecyclerViewAdapter<DefaultProduct, RecyclerItemSearchProductBinding>()  {

    override val layoutId: Int
        get() = R.layout.recycler_item_search_product

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return SearchProductViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as SearchProductViewHolder
        val context =holder.binding.root.context
        if (PreferenceManager.language == "en"){
            holder.binding.tvProductName.text = items[position].nAMEEN
        }else{
            holder.binding.tvProductName.text = items[position].nAMEAR
        }

        holder.itemView?.setOnClickListener {
            PopupUtils.showAddToCart(context, position.toLong(), items[position], onAddToCart)
        }
    }

    inner class SearchProductViewHolder(val binding: RecyclerItemSearchProductBinding) :
        RecyclerView.ViewHolder(binding.root)
}