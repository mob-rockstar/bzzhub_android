package com.lab.alarab.data.model.api

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class TokenResponse {
    @SerializedName("response_code")
    @Expose
    val responseCode: String? = null

    @SerializedName("response_message")
    @Expose
    val responseMessage: String? = null

    @SerializedName("service_command")
    @Expose
    val serviceCommand: String? = null

    @SerializedName("device_id")
    @Expose
    val deviceId: String? = null

    @SerializedName("sdk_token")
    @Expose
    val sdkToken: String? = null

    @SerializedName("signature")
    @Expose
    val signature: String? = null

    @SerializedName("merchant_identifier")
    @Expose
    val merchantIdentifier: String? = null

    @SerializedName("access_code")
    @Expose
    val accessCode: String? = null

    @SerializedName("language")
    @Expose
    val language: String? = null

    @SerializedName("status")
    @Expose
    val status: String? = null
}
