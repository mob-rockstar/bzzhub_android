package com.lab.alarab.data.model.api.response.editadderss


import com.google.gson.annotations.SerializedName

data class EditAddressResponse(
    var errorMessage: String?,
    var httpStatus: Int,
    var response: Response,
    var success: Boolean,
    var timestamp: Int
)