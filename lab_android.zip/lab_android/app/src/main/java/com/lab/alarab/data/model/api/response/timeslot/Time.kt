package com.lab.alarab.data.model.api.response.timeslot


import com.google.gson.annotations.SerializedName

data class Time(
    @SerializedName("ACTIVE_FLAG")
    var aCTIVEFLAG: Int,
    @SerializedName("CREATE_DATE")
    var cREATEDATE: String,
    @SerializedName("DAY_OF_WEEK_ID")
    var dAYOFWEEKID: Int,
    @SerializedName("FROM_TIME")
    var fROMTIME: String,
    @SerializedName("HOSPITAL_ID")
    var hOSPITALID: Any,
    @SerializedName("ID")
    var iD: Int,
    @SerializedName("TO_TIME")
    var tOTIME: String,
    @SerializedName("UPDATE_DATE")
    var uPDATEDATE: String
)