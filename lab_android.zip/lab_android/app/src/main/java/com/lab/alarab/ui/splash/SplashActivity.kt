package com.lab.alarab.ui.splash

import android.Manifest
import android.content.Intent
import android.os.Bundle
import com.lab.alarab.R
import com.lab.alarab.base.BaseActivity
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.databinding.ActivitySplashBinding
import com.lab.alarab.ui.login.LoginActivity
import com.lab.alarab.ui.main.MainActivity
import com.lab.alarab.utils.GPSTrackService
import com.tbruyelle.rxpermissions2.RxPermissions
import io.reactivex.android.schedulers.AndroidSchedulers

class SplashActivity : BaseActivity<ActivitySplashBinding?, SplashViewModel>() {

    override val layoutId: Int
        get() = R.layout.activity_splash

    override val viewModel: SplashViewModel
        get() {
            return getViewModel(SplashViewModel::class.java)
        }
    private var gpsTracker: GPSTrackService? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        initUI()
    }

    private fun initUI(){
        viewDataBinding?.btnContinue?.setOnClickListener {

            RxPermissions(this@SplashActivity).request(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe { granted ->
                    if (granted) {
                        gpsTracker = GPSTrackService(this@SplashActivity)
                        if (!gpsTracker!!.canGetLocation()) {
                            // Can't get location, ask user to enable GPS/Network in settings
                            gpsTracker!!.showSettingsAlert()
                        } else {
                            //       startActivity(Intent(this@SplashActivity,LoginActivity::class.java))
                            if (PreferenceManager.userData == null
                                || PreferenceManager.currentUserLoggedInMode == PreferenceManager.LoggedInMode.LOGGED_IN_MODE_LOGGED_OUT){
                                startActivity(Intent(this@SplashActivity, LoginActivity::class.java))
                            }else{
                                startActivity(Intent(this@SplashActivity, MainActivity::class.java))
                            }
                        }
                    }
                }
        }

        viewDataBinding?.tvHelp?.setOnClickListener {
            val i = Intent(Intent.ACTION_SEND)
            i.putExtra(Intent.EXTRA_EMAIL, arrayOf<String>("support@lab.com"))
            i.putExtra(Intent.EXTRA_SUBJECT, "Hello")
            i.putExtra(Intent.EXTRA_TEXT,"" )
            startActivity(Intent.createChooser(i, "Send email"))
        }
    }
}