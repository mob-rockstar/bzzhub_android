package com.lab.alarab.ui.main.home

import android.content.Intent
import android.view.View.GONE
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.lab.alarab.R
import com.lab.alarab.base.BaseRecyclerViewAdapter
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.data.model.api.response.landing.DefaultProduct
import com.lab.alarab.databinding.RecyclerItemHomeDefaultProductNewBinding
import com.lab.alarab.ui.time.AvailableTimeActivity
import com.lab.alarab.utils.PopupUtils

class DefaultProductAdapter(private val onAddToCart: (packageID: DefaultProduct?, position: Long?) -> Unit)  : BaseRecyclerViewAdapter<DefaultProduct, RecyclerItemHomeDefaultProductNewBinding>()  {
    override val layoutId: Int
        get() = R.layout.recycler_item_home_default_product_new

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return ProductViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as ProductViewHolder
        val context =holder.binding.root.context
        holder.binding.tvPrice.text = """${items[position].pRICE} SAR"""
        if (PreferenceManager.language.equals("en")){
            holder.binding.tvName.text = items[position].nAMEEN
            if (items[position].dESCEN == null || items[position].dESCEN!!.isEmpty()){
                holder.binding.tvDescription.visibility = GONE
            }
            holder.binding.tvDescription.text = items[position].dESCEN
        }else{
            holder.binding.tvName.text = items[position].nAMEAR
            holder.binding.tvDescription.text = items[position].dESCAR
            if (items[position].dESCAR == null || items[position].dESCAR!!.isEmpty()){
                holder.binding.tvDescription.visibility = GONE
            }
        }

        var itemName = "items"
        var itemCount = 0
        if (items[position].lABPACKAGEITEMS != null && items[position].lABPACKAGEITEMS!!.isNotEmpty()){
            itemCount = items[position].lABPACKAGEITEMS?.size!!
            itemName = if (PreferenceManager.language != "ar"){
                items[position].lABPACKAGEITEMS!![0].NAME_EN ?: ""
            }else{
                items[position].lABPACKAGEITEMS!![0].NAME_AR ?: ""
            }
        }

        holder.binding.tvPackageCount.text = "$itemCount $itemName"

        Glide.with(context!!).asBitmap().load(items[position].ImageUrl ?: "")
            .into(viewHolder.binding.ivBanner)


        holder.itemView.setOnClickListener {
            var intent = Intent(context, AvailableTimeActivity::class.java)
            intent.putExtra("package_id", items[position].iD)
            intent.putExtra("city_id", items[position].cITYID ?: 41)
            context.startActivity(intent)
        //    PopupUtils.showAddToCart(context, position.toLong(), items[position], onAddToCart)
        }

/*        holder.binding.ivAdd?.setOnClickListener {
            onAddToCart(items[position], position.toLong())
        }*/
    }

    override fun setItems(itemList: List<DefaultProduct>) {
        super.setItems(itemList)
    }

    fun setItemPosition(position: Int, cartId: Long?){
           items[position].cARTID = cartId
           notifyItemChanged(position)
    }

    inner class ProductViewHolder(val binding: RecyclerItemHomeDefaultProductNewBinding) :
        RecyclerView.ViewHolder(binding.root)
}