package com.lab.alarab.data.model.api


import com.google.gson.annotations.SerializedName

data class UserObject(
    var user: User? = null,
    var userSignType: Int
)