package com.lab.alarab.data.model.api.response.addorder


import com.google.gson.annotations.SerializedName

data class Response(
    @SerializedName("ACCESS_CODE")
    var aCCESSCODE: Any,
    @SerializedName("AMOUNT")
    var aMOUNT: Any,
    @SerializedName("AUTHORIZATION_CODE")
    var aUTHORIZATIONCODE: Any,
    @SerializedName("BASE_AMOUNT")
    var bASEAMOUNT: Float,
    @SerializedName("BUILDING_NO")
    var bUILDINGNO: Any,
    @SerializedName("CARD_HOLDER_NAME")
    var cARDHOLDERNAME: Any,
    @SerializedName("CARD_NAME")
    var cARDNAME: Any,
    @SerializedName("CASH_AMOUNT")
    var cASHAMOUNT: Any,
    @SerializedName("COLLECTED_BY")
    var cOLLECTEDBY: Any,
    @SerializedName("COMMAND")
    var cOMMAND: Any,
    @SerializedName("COUPON_CODE")
    var cOUPONCODE: String,
    @SerializedName("CREATE_DATE")
    var cREATEDATE: String,
    @SerializedName("CURRENCY")
    var cURRENCY: Any,
    @SerializedName("CUSTOMER_EMAIL")
    var cUSTOMEREMAIL: Any,
    @SerializedName("CUSTOMER_IP")
    var cUSTOMERIP: Any,
    @SerializedName("CUSTOMER_NAME")
    var cUSTOMERNAME: Any,
    @SerializedName("DELIVERY_ADDRESS")
    var dELIVERYADDRESS: String,
    @SerializedName("DELIVERY_AMOUNT")
    var dELIVERYAMOUNT: Int,
    @SerializedName("DELIVERY_LATITIUDE")
    var dELIVERYLATITIUDE: String,
    @SerializedName("DELIVERY_LONGTITUDE")
    var dELIVERYLONGTITUDE: String,
    @SerializedName("DISCOUNT_AMOUNT")
    var dISCOUNTAMOUNT: Double,
    @SerializedName("DISCOUNT_PERCENTAGE")
    var dISCOUNTPERCENTAGE: String,
    @SerializedName("ECI")
    var eCI: Any,
    @SerializedName("END_USER_ID")
    var eNDUSERID: Int,
    @SerializedName("EXPIRY_DATE")
    var eXPIRYDATE: Any,
    @SerializedName("FEES")
    var fEES: Int,
    @SerializedName("FLOOR_NO")
    var fLOORNO: Any,
    @SerializedName("FORT_ID")
    var fORTID: Any,
    @SerializedName("HOSPITAL_ID")
    var hOSPITALID: Any,
    @SerializedName("ID")
    var iD: Int,
    var lABAVAILABLETIME: LABAVAILABLETIME,
    @SerializedName("LAB_AVAILABLE_TIME_ID")
    var lABAVAILABLETIMEID: Int,
    @SerializedName("LAB_ORDER_STATUS_ID")
    var lABORDERSTATUSID: Any,
    @SerializedName("LANGUAGE")
    var lANGUAGE: Any,
    @SerializedName("MERCHAT_EXTRA")
    var mERCHATEXTRA: Any,
    @SerializedName("MERCHAT_EXTRA2")
    var mERCHATEXTRA2: Any,
    @SerializedName("MERCHAT_EXTRA3")
    var mERCHATEXTRA3: Any,
    @SerializedName("MERCHAT_EXTRA4")
    var mERCHATEXTRA4: Any,
    @SerializedName("MERCHAT_IDENTIFIER")
    var mERCHATIDENTIFIER: Any,
    @SerializedName("MERCHAT_REFERENCE")
    var mERCHATREFERENCE: Any,
    @SerializedName("NEAREST")
    var nEAREST: Any,
    @SerializedName("NOTES")
    var nOTES: Any,
    @SerializedName("ORDER_DESCRIPTION")
    var oRDERDESCRIPTION: Any,
    @SerializedName("ORDER_STATUS_ID")
    var oRDERSTATUSID: Int,
    @SerializedName("PAYMENT_METHOD_ID")
    var pAYMENTMETHODID: Int,
    @SerializedName("PAYMENT_OPTION")
    var pAYMENTOPTION: Any,
    @SerializedName("PHONE_NUMBER")
    var pHONENUMBER: Any,
    @SerializedName("Packages")
    var packages: List<Package>,
    @SerializedName("REMEMBER_ME")
    var rEMEMBERME: Any,
    @SerializedName("RESPONSE_CODE")
    var rESPONSECODE: Any,
    @SerializedName("RESPONSE_MESSAGE")
    var rESPONSEMESSAGE: Any,
    @SerializedName("SCHEDULE_DATE")
    var sCHEDULEDATE: String,
    @SerializedName("SETTLEMENT_REFERENCE")
    var sETTLEMENTREFERENCE: Any,
    @SerializedName("SIGNATURE")
    var sIGNATURE: Any,
    @SerializedName("STATUS")
    var sTATUS: Any,
    @SerializedName("TAX_AMOUNT")
    var tAXAMOUNT: Int,
    @SerializedName("TOKEN_NAME")
    var tOKENNAME: Any,
    @SerializedName("TOTAL_AMOUNT")
    var tOTALAMOUNT: Double,
    @SerializedName("UPDATE_DATE")
    var uPDATEDATE: String,
    @SerializedName("VISA_AMOUNT")
    var vISAAMOUNT: Any,
    @SerializedName("WALLET_AMOUNT")
    var wALLETAMOUNT: String
)