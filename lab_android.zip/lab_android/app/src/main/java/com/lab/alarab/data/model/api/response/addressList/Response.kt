package com.lab.alarab.data.model.api.response.addressList


import com.google.gson.annotations.SerializedName

data class Response(
    var addressesTitles: List<AddressesTitle>
)