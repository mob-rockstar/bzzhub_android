package com.lab.alarab.ui.profile

import android.Manifest
import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.DatePicker
import android.widget.Toast
import android.widget.Toast.LENGTH_LONG
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.lab.alarab.R
import com.lab.alarab.base.BaseActivity
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.data.model.api.response.ErrorResponse
import com.lab.alarab.data.model.api.response.SinUpResponse
import com.lab.alarab.data.model.api.response.flag.FlagObject
import com.lab.alarab.databinding.ActivityProfileBinding
import com.lab.alarab.ui.forgotpassword.ForgotPasswordActivity
import com.lab.alarab.ui.main.MainActivity
import com.lab.alarab.ui.nationality.NationalityActivity
import com.lab.alarab.utils.AppConstants
import com.lab.alarab.utils.DateUtils
import com.lab.alarab.utils.MessageEvent
import com.lab.alarab.utils.NetworkUtils
import com.tbruyelle.rxpermissions2.RxPermissions
import io.reactivex.android.schedulers.AndroidSchedulers
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import pl.aprilapps.easyphotopicker.DefaultCallback
import pl.aprilapps.easyphotopicker.EasyImage
import pl.aprilapps.easyphotopicker.MediaFile
import pl.aprilapps.easyphotopicker.MediaSource
import timber.log.Timber
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class ProfileActivity : BaseActivity<ActivityProfileBinding?, ProfileViewModel>() {

    override val layoutId: Int
        get() = R.layout.activity_profile

    override val viewModel: ProfileViewModel
        get() = ProfileViewModel()

    private lateinit var easyImage: EasyImage
    private var file: File? = null

    private var strCountryName = ""
    private var strYear = ""
    private var strMonth = ""
    private var strday = ""
    private var gender = 1
    private val FLAG_SELECTION_REQUEST = 1001
    private var strEmail = ""

    private var dialCode = ""
    private var countryID = 0
    private var firstName = ""
    private var lastName = ""

    private var mDatePickerDialog: DatePickerDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        EventBus.getDefault().register(this)
        progressView = viewDataBinding?.layoutProgress
        // Define Easy Image
        easyImage =
            EasyImage.Builder(this@ProfileActivity).setCopyImagesToPublicGalleryFolder(false)
                .allowMultiple(false)
                .build()

        initListeners()

        initDatePickerDialog()
        initUI()
    }

    private fun initUI(){

        Glide.with(this@ProfileActivity).load("http://207.154.193.128" + PreferenceManager.currentUserImageUrl).fitCenter()
            .placeholder(R.drawable.ic_profile_green)
            .error(R.drawable.ic_profile_green).into(viewDataBinding!!.ivProfile)

        viewDataBinding?.edittextMobile?.setOnClickListener {
            startActivity(Intent(this@ProfileActivity, ForgotPasswordActivity::class.java))
        }

        viewDataBinding?.edittextFirstName?.setText(PreferenceManager.currentUserFirstName)
        viewDataBinding?.edittextLastName?.setText(PreferenceManager.currentUserLastName)

        viewDataBinding?.edittextMobile?.setText(PreferenceManager.currentUserMobile)

        viewDataBinding?.edittextNation?.setText(PreferenceManager.nationality ?: "")
        viewDataBinding?.edittextEmail?.setText(PreferenceManager.currentUserEmail ?: "")
      //  viewDataBinding?.edittextMobile?.setText(PreferenceManager.currentUserMobile)
        viewDataBinding?.edittextDob?.setText(PreferenceManager.dob)
        strYear = DateUtils.getYear(PreferenceManager.dob!!)
        strMonth = DateUtils.getMonth(PreferenceManager.dob!!)
        strday = DateUtils.getDay(PreferenceManager.dob!!)

        if (PreferenceManager.genderId == 1){
            viewDataBinding?.tvFemale?.background = null
            viewDataBinding?.tvMale?.background = ContextCompat.getDrawable(
                this@ProfileActivity,
                R.drawable.ic_rounded_white_background_8
            )
        }else if (PreferenceManager.genderId == 2){
            viewDataBinding?.tvMale?.background = null

            viewDataBinding?.tvFemale?.background = ContextCompat.getDrawable(
                this@ProfileActivity,
                R.drawable.ic_rounded_white_background_8
            )
        }

        viewDataBinding?.tvMale?.setOnClickListener {
            viewDataBinding?.tvMale?.background = ContextCompat.getDrawable(
                this@ProfileActivity,
                R.drawable.ic_rounded_white_background_8
            )
            gender = 1
            viewDataBinding?.tvFemale?.background = null
        }

        viewDataBinding?.tvFemale?.setOnClickListener {
            viewDataBinding?.tvMale?.background = null
            gender = 2
            viewDataBinding?.tvFemale?.background = ContextCompat.getDrawable(
                this@ProfileActivity,
                R.drawable.ic_rounded_white_background_8
            )
        }

        viewDataBinding?.edittextDob?.setOnClickListener{
            mDatePickerDialog?.show()
        }

        initContinueButton()
    }

    private fun initValues(){
        firstName = viewDataBinding?.edittextFirstName?.text.toString()
        lastName = viewDataBinding?.edittextLastName?.text.toString()
        strEmail = viewDataBinding?.edittextEmail?.text.toString()
        strYear =  DateUtils.getYear(viewDataBinding?.edittextDob?.text.toString())
        strMonth = DateUtils.getMonth(viewDataBinding?.edittextDob?.text.toString())
        strday = DateUtils.getDay(viewDataBinding?.edittextDob?.text.toString())
        strCountryName = viewDataBinding?.edittextNation?.text.toString()

    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }

    private fun initListeners(){
        viewDataBinding?.ivCamera!!.setOnClickListener {
            openImagePicker()
        }
        viewDataBinding?.ivProfile!!.setOnClickListener {
            openImagePicker()
        }
        viewDataBinding?.ivBack?.setOnClickListener {
            finish()
        }

        viewDataBinding?.edittextNation?.setOnClickListener {
            val intent = Intent(this@ProfileActivity, NationalityActivity::class.java)
            startActivityForResult(intent, FLAG_SELECTION_REQUEST)
        }
    }

    private fun openImagePicker() {
        RxPermissions(this@ProfileActivity).request(
            Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        )
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe { granted ->
                if (granted) {
                    easyImage.openChooser(this)
                }
            }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Profile Image Changed
        easyImage.handleActivityResult(requestCode, resultCode, data, this@ProfileActivity, object :
            DefaultCallback() {
            override fun onMediaFilesPicked(imageFiles: Array<MediaFile>, source: MediaSource) {
                file = imageFiles.first().file
                Glide.with(this@ProfileActivity).load(file?.absolutePath).fitCenter()
                    .placeholder(R.drawable.ic_profile_green)
                    .error(R.drawable.ic_profile_green).into(viewDataBinding!!.ivProfile)
            }
        })

        if (requestCode === this.FLAG_SELECTION_REQUEST && resultCode === RESULT_OK) {
            val flag: FlagObject = data?.extras?.getSerializable("selected_flag") as FlagObject
            viewDataBinding?.edittextNation?.setText(flag.name)

            strCountryName = flag.name!!
            countryID = flag.id!!
            dialCode = flag.dialCode!!
        }
    }

    private fun initDatePickerDialog() {
        val newCalendar = Calendar.getInstance()
        mDatePickerDialog = DatePickerDialog(
            this@ProfileActivity,
            R.style.styleDatePickerDialog,
            { _: DatePicker?, year: Int, monthOfYear: Int, dayOfMonth: Int ->
                val newDate = Calendar.getInstance()
                newDate[year, monthOfYear] = dayOfMonth
                val sd = SimpleDateFormat("yyyy-mm-dd")

                val formatDate =
                    SimpleDateFormat("yyyy")

                val formatMonth =
                    SimpleDateFormat("MM")

                val formatDay =
                    SimpleDateFormat("dd")

                val startDate = newDate.time
                val fdate = sd.format(startDate)
                strYear = formatDate.format(startDate)
                strMonth = formatMonth.format(startDate)
                strday = formatDay.format(startDate)
                viewDataBinding?.edittextDob?.setText(fdate)
            },
            newCalendar[Calendar.YEAR],
            newCalendar[Calendar.MONTH],
            newCalendar[Calendar.DAY_OF_MONTH]
        )
        val c = Calendar.getInstance()
        c.add(Calendar.YEAR, -6) // subtract 2 years from now
        mDatePickerDialog!!.datePicker.maxDate = c.timeInMillis
        mDatePickerDialog!!.setTitle("")
    }

    private fun initContinueButton(){

        viewDataBinding?.tvContinue?.setOnClickListener {
            initValues()
            val validationMessage = verifyInfo()
            if (verifyInfo().isEmpty()){
                editInfo()
            }else{
                Toast.makeText(this@ProfileActivity, validationMessage, LENGTH_LONG).show()
            }
        }
    }

    private fun verifyInfo(): String{
        return if (!isValidFirstName()){
            resources.getString(R.string.str_please_enter_first_name)
        }else if (!isValidLastName()){
            resources.getString(R.string.str_please_enter_second_name)
        }else if(!isEmailValid()){
            resources.getString(R.string.str_please_enter_valid_email)
        }else if (!isBirthdayValid()){
            resources.getString(R.string.str_please_enter_birthday)
        }else{
            ""
        }
    }

    private fun editInfo(){
        viewModel.updateProfile(PreferenceManager.dialCode!!,
            PreferenceManager.currentUserMobile!!,
            countryID.toString(),
            gender,
            strYear,
            strMonth,
            strday,
            firstName,
            lastName,
            strEmail,
            file,
            object : HandleResponse<SinUpResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (NetworkUtils.isNetworkConnected(this@ProfileActivity)) {
                        this@ProfileActivity.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        this@ProfileActivity.onError(
                            error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }

                override fun handleSuccessRespons(successResponse: SinUpResponse) {
                    if (successResponse.success && successResponse.httpStatus == 200){
                        PreferenceManager.userData = successResponse.response
                        Toast.makeText(this@ProfileActivity, resources.getString(R.string.str_success), LENGTH_LONG).show()
                    }else{
                        Toast.makeText(this@ProfileActivity, resources.getString(R.string.str_failed), LENGTH_LONG).show()
                    }
                }
            })
    }

    private fun isValidFirstName(): Boolean{
        return firstName.isNotEmpty()
    }

    private fun isValidLastName(): Boolean{
        return lastName.isNotEmpty()
    }

    fun isEmailValid(): Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(strEmail).matches()
    }

    fun isBirthdayValid(): Boolean{
        return strYear.isNotEmpty()
    }

    fun isValidNationality(): Boolean{
        return strCountryName.isNotEmpty()
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        when (event.message) {
            AppConstants.MESSAGE_UPDATE_PROFILE -> {
                // If received broadcast message 'profile_changed', reload user information
                viewDataBinding?.edittextMobile?.setText(PreferenceManager.currentUserMobile)
            }
        }
    }
}
