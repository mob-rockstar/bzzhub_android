package com.lab.alarab.data.model.api.response.city

data class Response(
    val ARABIC_NAME: String,
    val CITY_ID: Int,
    val ENG_NAME: String,
    val LATITUDE: String,
    val LONGITUDE: String,
    val NAME: Int
)