package com.lab.alarab.ui.order

import android.content.Intent
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.lab.alarab.R
import com.lab.alarab.base.BaseActivity
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.data.model.api.response.ErrorResponse
import com.lab.alarab.data.model.api.response.cart.CartResponse
import com.lab.alarab.data.model.api.response.removewithcalculation.RemoveWithCalculationResponse
import com.lab.alarab.databinding.ActivityOrderBinding
import com.lab.alarab.ui.checkout.CheckoutActivity
import com.lab.alarab.ui.patient.AddPatientActivity
import com.lab.alarab.utils.AppConstants
import com.lab.alarab.utils.AppConstants.CURRENCY_CODE
import com.lab.alarab.utils.FormatterUtils
import com.lab.alarab.utils.NetworkUtils
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import javax.inject.Inject

class OrderActivity: BaseActivity<ActivityOrderBinding?, OrderViewModel>() ,
    HasAndroidInjector {

    override val layoutId: Int
        get() = R.layout.activity_order

    override val viewModel: OrderViewModel
        get() {
            return getViewModel(OrderViewModel::class.java)
        }

    private var cartListAdapter: CartListAdapter = CartListAdapter {
        packageID, position ->removeItemFromCart(packageID!!, position)
    }

    private var packageId = 0

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewDataBinding?.layoutAdd?.setOnClickListener {
            AppConstants.packageId = packageId
            startActivity(Intent(this@OrderActivity, AddPatientActivity::class.java))
        }

        viewDataBinding?.layoutCancel?.setOnClickListener {
            finish()
        }

        viewDataBinding?.layoutOrder?.setOnClickListener {
            finish()
        }

        viewDataBinding?.layoutPay?.setOnClickListener {
            startActivity(Intent(this@OrderActivity, CheckoutActivity::class.java))
        }

        initRecyclerView()

        getCartList()
    }

    private fun initRecyclerView(){
        viewDataBinding?.recyclerView?.layoutManager = LinearLayoutManager(this@OrderActivity)
        viewDataBinding?.recyclerView?.setHasFixedSize(true)
        viewDataBinding?.recyclerView?.adapter = cartListAdapter
    }

    private fun getCartList(){
        viewModel.getCartList(object : HandleResponse<CartResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(this@OrderActivity)) {
                    this@OrderActivity.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    this@OrderActivity.onError(
                        error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                    )
                }
            }

            override fun handleSuccessRespons(successResponse: CartResponse) {
                if (successResponse.success && successResponse.httpStatus == 200){
                    cartListAdapter.setItems(successResponse.response.packages)
                    if (successResponse.response.packages.isNotEmpty()){
                        packageId = successResponse.response.packages[0].iD
                    }

                    viewDataBinding?.tvNetTotal?.text =
                        """$CURRENCY_CODE ${successResponse.response.netTotal}"""

                    viewDataBinding?.tvCount?.text = successResponse.response.packagesCount.toString()
                    viewDataBinding?.tvDiscountFee?.text = resources.getString(R.string.str_free_fee_discount,
                        AppConstants.CURRENCY_CODE, FormatterUtils.formatDouble(successResponse.response.discountAmount!!))
                }else{
                    this@OrderActivity.onError(
                        AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                }
            }
        })
    }

    private fun removeItemFromCart(packageId: Int, position: Int){
        viewModel.removeCart(packageId,
            object : HandleResponse <RemoveWithCalculationResponse>{
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (NetworkUtils.isNetworkConnected(this@OrderActivity)) {
                        this@OrderActivity.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        this@OrderActivity.onError(
                            error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }

                override fun handleSuccessRespons(successResponse: RemoveWithCalculationResponse) {
                    if (successResponse.success && successResponse.httpStatus == 200){
                        cartListAdapter.removeItem(position)
                        PreferenceManager.userCartCount = cartListAdapter.itemCount
                    }else{
                        this@OrderActivity.onError(
                            AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    }
                }
            })
    }

    override fun onResume() {
        super.onResume()
        getCartList()
    }
}