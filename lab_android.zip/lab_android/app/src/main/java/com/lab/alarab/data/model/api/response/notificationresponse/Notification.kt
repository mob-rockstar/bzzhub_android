package com.lab.alarab.data.model.api.response.notificationresponse


import com.google.gson.annotations.SerializedName

data class Notification(
    @SerializedName("CREATE_DATE")
    var cREATEDATE: Any,
    @SerializedName("DEEPLINK")
    var dEEPLINK: String,
    @SerializedName("DESCRIPTION_AR")
    var dESCRIPTIONAR: String,
    @SerializedName("DESCRIPTION_EN")
    var dESCRIPTIONEN: String,
    @SerializedName("END_USER_ID")
    var eNDUSERID: Int,
    @SerializedName("ID")
    var iD: Int,
    @SerializedName("IS_READ")
    var iSREAD: Int,
    @SerializedName("TITLE_AR")
    var tITLEAR: String,
    @SerializedName("TITLE_EN")
    var tITLEEN: String
)