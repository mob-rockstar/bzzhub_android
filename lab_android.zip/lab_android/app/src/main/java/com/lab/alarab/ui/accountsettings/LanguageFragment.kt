package com.lab.alarab.ui.accountsettings

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import com.lab.alarab.R
import com.lab.alarab.base.BaseInputDialogFragment
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.databinding.LayoutLanguageBinding
import com.lab.alarab.di.Injectable
import com.lab.alarab.ui.main.MainActivity
import com.lab.alarab.utils.PopupUtils

class LanguageFragment :
    BaseInputDialogFragment<LayoutLanguageBinding?, AccountSettingViewModel>(),
    Injectable {

    override val layoutId: Int
        get() = R.layout.layout_language

    override val viewModel: AccountSettingViewModel
        get() {
            return getViewModel(baseActivity, AccountSettingViewModel::class.java)
        }


    override fun getTheme(): Int {
        return R.style.FullScreenDialogFragmentTheme
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewDataBinding?.ivBack?.setOnClickListener {
            dismiss()
        }

        initUI()

        viewDataBinding?.layoutArabic?.setOnClickListener {
            if (PreferenceManager.language != "ar"){
                    PopupUtils.showConfirmDialog(
                        baseActivity,
                        getString(R.string.str_title_confirm_language_change),
                        getString(R.string.str_content_language_change)
                    ) {
                        updateLanguageSettings("ar")
                    }
            }

            viewDataBinding?.ivEnglish?.visibility = GONE
            viewDataBinding?.ivArabic?.visibility = VISIBLE
        }

        viewDataBinding?.layoutEnglish?.setOnClickListener {
            viewDataBinding?.ivEnglish?.visibility = VISIBLE
            viewDataBinding?.ivArabic?.visibility = GONE
            if (PreferenceManager.language != "en"){
                PopupUtils.showConfirmDialog(
                    baseActivity,
                    getString(R.string.str_title_confirm_language_change),
                    getString(R.string.str_content_language_change)
                ) {
                    updateLanguageSettings("en")
                }
            }

        }
    }

    private fun initUI(){
        if (PreferenceManager.language == "en"){
            viewDataBinding?.ivEnglish?.visibility = VISIBLE
            viewDataBinding?.ivArabic?.visibility = GONE
        }else{
            viewDataBinding?.ivEnglish?.visibility = GONE
            viewDataBinding?.ivArabic?.visibility = VISIBLE
        }
    }

    private fun updateLanguageSettings(language: String){
        PreferenceManager.language = language
        restartApp()
    }

    // Restart Application
    fun restartApp() {
        try {
            val homeIntent = Intent(baseActivity.applicationContext, MainActivity::class.java)
            homeIntent.addCategory(Intent.CATEGORY_HOME)
            homeIntent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(homeIntent)
            finishActivity()
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        }
    }
}