package com.lab.alarab.utils

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.lab.alarab.R
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.data.model.api.response.addressList.Addresse
import com.lab.alarab.data.model.api.response.addressmeta.AddressType
import com.lab.alarab.data.model.api.response.landing.DefaultProduct
import com.lab.alarab.ui.checkout.CheckoutActivity
import com.lab.alarab.ui.editaddress.AddressTypeAdapter
import com.lab.alarab.ui.editaddress.EditAddressActivity
import com.lab.alarab.ui.pickup.PickUpAddressActivity
import org.greenrobot.eventbus.Logger
import java.text.FieldPosition

object PopupUtils {
    var isPopupShowing = false

    interface PopupConfirmListener {
        fun OnConfirm()
        fun OnCancel()
    }

    private val lp = WindowManager.LayoutParams()

    // Show Alert Dialog with one button Only - 'Okay'
    fun showAlertDialog(context: Context, title: String, message: String) {
        val alertDialogBuilder = AlertDialog.Builder(context, R.style.DefaultAlertButtonStyle)
        alertDialogBuilder
            .setTitle(title)
            .setMessage(message)
            .setCancelable(true)
            .setPositiveButton(context.resources.getString(R.string.str_ok)) { dialog, _ ->
                dialog.dismiss()
            }

        val alertDialog = alertDialogBuilder.show()
        val tvBody = alertDialog.findViewById<TextView>(android.R.id.message)
        tvBody?.textSize = (14.0f)
        tvBody?.gravity = Gravity.CENTER

        alertDialog.show()
    }

    // Show Alert Dialog with 'Okay' and 'Cancel' Button
    fun showConfirmDialog(context: Context, title: String, message: String, onConfirm: () -> Unit) {
        AlertDialog.Builder(context, R.style.DefaultAlertButtonStyle)
            .setTitle(title)
            .setMessage(message)
            .setCancelable(true)
            .setPositiveButton(context.resources.getString(R.string.str_ok)) { dialog, _ ->
                onConfirm()
                dialog.dismiss()
            }.setNegativeButton(context.resources.getString(R.string.str_cancel)) { dialog, _ ->
                dialog.cancel()
            }.show()
    }

    fun showAddToCart(context: Context,position: Long?, product: DefaultProduct, onAddToCart: (packageID: DefaultProduct?) -> Unit){
        val dialog = Dialog(context)

        val view = LayoutInflater.from(context).inflate(R.layout.dialog_product_detail, null)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(view)

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val layoutCancel = view.findViewById<LinearLayout>(R.id.layout_cancel)
        layoutCancel.setOnClickListener {
            dialog.dismiss()
        }

        val layoutAddToCart = view.findViewById<RelativeLayout>(R.id.layout_add_to_cart)
        layoutAddToCart.setOnClickListener {
            onAddToCart(product)
            dialog.dismiss()
        }

        val tvProductName = view.findViewById<TextView>(R.id.tv_product_name)
        val tvFastingRequired = view.findViewById<TextView>(R.id.tv_fasting_required)
        val tvAmount = view.findViewById<TextView>(R.id.tv_amount)
        val tvTitleDescription = view.findViewById<TextView>(R.id.tv_short_description)
        val tvDescription = view.findViewById<TextView>(R.id.tv_description)

        if (PreferenceManager.language == "en"){
            tvProductName.text = product.nAMEEN
            if (product.dESCEN == null){
                tvTitleDescription.visibility = GONE
                tvDescription.visibility = GONE
            }else{
                tvDescription.text = product.dESCEN
            }
        }else{
            tvProductName.text = product.nAMEAR
            if (product.dESCAR == null){
                tvTitleDescription.visibility = GONE
                tvDescription.visibility = GONE
            }else{
                tvDescription.text = product.dESCAR
            }
        }

        if (product.fASTINGREQUIRED == 1){
            tvFastingRequired.visibility = VISIBLE
        }else tvFastingRequired.visibility = GONE

        tvAmount.text = """SAR ${product.pRICE}"""


        setDefaultDialogProperty(dialog)
        dialog.show()
    }


    fun showAddToCart(context: Context,position: Long?, product: DefaultProduct, onAddToCart: (packageID: DefaultProduct?,position:Long?) -> Unit){
        val dialog = Dialog(context)

        val view = LayoutInflater.from(context).inflate(R.layout.dialog_product_detail, null)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(view)

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val layoutCancel = view.findViewById<LinearLayout>(R.id.layout_cancel)
        layoutCancel.setOnClickListener {
            dialog.dismiss()
        }

        val layoutAddToCart = view.findViewById<RelativeLayout>(R.id.layout_add_to_cart)
        layoutAddToCart.setOnClickListener {
            onAddToCart(product,position)
            dialog.dismiss()
        }

        val tvProductName = view.findViewById<TextView>(R.id.tv_product_name)
        val tvFastingRequired = view.findViewById<TextView>(R.id.tv_fasting_required)
        val tvAmount = view.findViewById<TextView>(R.id.tv_amount)
        val tvTitleDescription = view.findViewById<TextView>(R.id.tv_short_description)
        val tvDescription = view.findViewById<TextView>(R.id.tv_description)

        if (PreferenceManager.language == "en"){
            tvProductName.text = product.nAMEEN
            if (product.dESCEN == null){
                tvTitleDescription.visibility = GONE
                tvDescription.visibility = GONE
            }else{
                tvDescription.text = product.dESCEN
            }
        }else{
            tvProductName.text = product.nAMEAR
            if (product.dESCAR == null){
                tvTitleDescription.visibility = GONE
                tvDescription.visibility = GONE
            }else{
                tvDescription.text = product.dESCAR
            }
        }

        if (product.fASTINGREQUIRED == 1){
            tvFastingRequired.visibility = VISIBLE
        }else tvFastingRequired.visibility = GONE

        tvAmount.text = """SAR ${product.pRICE}"""


        setDefaultDialogProperty(dialog)
        dialog.show()
    }

    fun showOrderDetails(context: Context, orderDetail: com.lab.alarab.data.model.api.response.orderdetail.Response){
        val dialog = Dialog(context)

        val view = LayoutInflater.from(context).inflate(R.layout.dialog_order_details, null)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(view)

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val layoutOutside = view.findViewById<LinearLayout>(R.id.layout_outside)
        layoutOutside.setOnClickListener {
            dialog.dismiss()
        }

        val tvBaseAmount = view.findViewById<TextView>(R.id.tv_base)
        val tvDiscount = view.findViewById<TextView>(R.id.tv_discount_fee)
        val tvTotal = view.findViewById<TextView>(R.id.tv_total)
        val tvDeliveryFee = view.findViewById<TextView>(R.id.tv_delivery_fee)

        tvBaseAmount.text = """SAR ${FormatterUtils.formatDouble(orderDetail.bASEAMOUNT)}"""
        tvDiscount.text = """SAR ${FormatterUtils.formatDouble(orderDetail.dISCOUNTAMOUNT)}"""
        tvTotal.text =  """SAR ${FormatterUtils.formatDouble(orderDetail.tOTALAMOUNT)}"""
        tvDeliveryFee.text = """SAR ${FormatterUtils.formatDouble(orderDetail.dELIVERYAMOUNT.toFloat())}"""

        setDefaultDialogProperty(dialog)
        dialog.show()
    }

    fun showEditLocationDialog(context: Context,addressTitleId  : Int, addresstype : String ,  address: Addresse, onEdit: () -> Unit, onRemove: (address: Addresse)-> Unit){
        val dialog = Dialog(context)

        val view = LayoutInflater.from(context).inflate(R.layout.dialog_edit_location, null)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(view)

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val tvAddressType = view.findViewById<TextView>(R.id.tv_address_type)
        tvAddressType.text = addresstype

        val tvAddress = view.findViewById<TextView>(R.id.tv_address)
        tvAddress.text = address.sTREETADDRESS

        val layoutModify = view.findViewById<RelativeLayout>(R.id.layout_modify)
        layoutModify.setOnClickListener {
            val intent = Intent(context, EditAddressActivity::class.java)
            intent.putExtra("address", address)
            intent.putExtra("address_title", addressTitleId)
            context.startActivity(intent)
        }

        val layoutDelete = view.findViewById<RelativeLayout>(R.id.layout_delete)
        layoutDelete.setOnClickListener {
            onRemove(address)
            dialog.dismiss()
        }

        val layoutCancel = view.findViewById<RelativeLayout>(R.id.layout_cancel)
        layoutCancel.setOnClickListener {
            dialog.dismiss()
        }

        setDefaultDialogProperty(dialog)
        dialog.show()
    }

    fun showAddressTypeDialog(context: Context, addressList: List<AddressType> , onSelect :(addressType : AddressType) -> Unit){
        val dialog = Dialog(context)

        val view = LayoutInflater.from(context).inflate(R.layout.dialog_property_type, null)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(view)

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val recyclerViewType = view.findViewById<RecyclerView>(R.id.recyclerView)
        recyclerViewType.layoutManager = LinearLayoutManager(context)
        val addressTypeAdapter = AddressTypeAdapter(){
            addressType -> onSelect(addressType)
            dialog.dismiss()
        }
        addressTypeAdapter.setItems(addressList)
        recyclerViewType.adapter = addressTypeAdapter

        val layoutCancel = view.findViewById<RelativeLayout>(R.id.layout_cancel)
        layoutCancel.setOnClickListener {
            dialog.dismiss()
        }

        setDefaultDialogProperty(dialog)
        dialog.show()
    }

    // Show 'Resend OTP' Dialog
    fun showResendOTPDialog(
        context: Context,
        mobile: String,
        onConfirm: () -> Unit
    ) {
        val dialog = Dialog(context)
        val layoutInflater = LayoutInflater.from(context)
        val view = layoutInflater.inflate(R.layout.dialog_resend_otp, null)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(view)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val layoutOutside = view.findViewById(R.id.layout_outside) as LinearLayout

        layoutOutside.setOnClickListener { }

        val btnSendOtp = view.findViewById(R.id.btn_send_verify_code) as Button
        btnSendOtp.setOnClickListener {
            onConfirm()
            dialog.dismiss()
        }

        val btnCancel = view.findViewById(R.id.btn_cancel) as Button
        btnCancel.setOnClickListener {
            dialog.dismiss()
        }

        setDefaultDialogProperty(dialog)
        dialog.show()
    }

    fun dialogSetPropertyType(context: Context){
        val dialog = Dialog(context)

        val view = LayoutInflater.from(context).inflate(R.layout.dialog_property_type, null)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(view)

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val layoutMain = view.findViewById<LinearLayout>(R.id.layout_main)
        layoutMain.setOnClickListener {
            dialog.dismiss()
        }

        val layoutCancel = view.findViewById<RelativeLayout>(R.id.layout_cancel)
        layoutCancel.setOnClickListener {
            dialog.dismiss()
        }

        setDefaultDialogProperty(dialog)
        dialog.show()
    }


    fun setDefaultDialogProperty(dialog: Dialog) {
        val lp = WindowManager.LayoutParams()
        lp.copyFrom(dialog.window?.attributes)
        lp.width = WindowManager.LayoutParams.MATCH_PARENT
        lp.height = WindowManager.LayoutParams.MATCH_PARENT
        dialog.window?.attributes = lp
        dialog.setCanceledOnTouchOutside(true)


        dialog.setCancelable(true)
    }
}