package com.lab.alarab.ui.resultexplanation

import com.lab.alarab.base.BaseViewModel

class ResultExplanationViewModel : BaseViewModel() {

}