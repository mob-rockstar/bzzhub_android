package com.lab.alarab.data.model.api.response


import com.google.gson.annotations.SerializedName
import com.lab.alarab.data.model.api.UserObject

data class SignInResponse(
    var httpStatus: Int,
    var success: Boolean,
    var timestamp: Int,
    var response: UserObject
)