package com.lab.alarab.ui.videovisit

import com.lab.alarab.base.BaseViewModel
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.model.api.response.resultdetail.ResultDetailResponse
import com.lab.alarab.data.model.api.response.timeslot.TimeSlotResponse
import com.lab.alarab.data.remote.APIManager
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class VideoVisitViewModel :BaseViewModel(){
    fun getResultDetail(
        orderId: Int,
        handleResponse: HandleResponse<ResultDetailResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.addAll(
            APIManager.getResultDetail(orderId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    // API to get available time slot
    fun getAvailableTimeList(
        date: String,
        handleResponse: HandleResponse<TimeSlotResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.getAvailableTimeSlots(date)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }
}