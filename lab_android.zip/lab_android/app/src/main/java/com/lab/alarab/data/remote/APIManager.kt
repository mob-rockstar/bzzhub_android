package com.lab.alarab.data.remote

import android.content.Context
import com.google.common.hash.Hashing
import com.google.gson.GsonBuilder
import com.google.gson.JsonObject
import com.jakewharton.retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import com.lab.alarab.BuildConfig
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.data.model.api.response.*
import com.lab.alarab.data.model.api.response.addaddress.AddAddressResponse
import com.lab.alarab.data.model.api.response.addorder.AddOrderResponse
import com.lab.alarab.data.model.api.response.addressList.AddressListResponse
import com.lab.alarab.data.model.api.response.addressdetail.AddressDetailResponse
import com.lab.alarab.data.model.api.response.addressmeta.AddressMetadataResponse
import com.lab.alarab.data.model.api.response.cart.CartResponse
import com.lab.alarab.data.model.api.response.category.CategoryResponse
import com.lab.alarab.data.model.api.response.coupon.CouponResponse
import com.lab.alarab.data.model.api.response.defaultaddress.DefaultAddressResponse
import com.lab.alarab.data.model.api.response.editadderss.EditAddressResponse
import com.lab.alarab.data.model.api.response.getresult.GetResultResponse
import com.lab.alarab.data.model.api.response.landing.LandingPageResponse
import com.lab.alarab.data.model.api.response.notificationresponse.NotificationResponse
import com.lab.alarab.data.model.api.response.orderdetail.OrderDetailResponse
import com.lab.alarab.data.model.api.response.orderhistory.OrderHistoryResponse
import com.lab.alarab.data.model.api.response.removewithcalculation.RemoveWithCalculationResponse
import com.lab.alarab.data.model.api.response.resultdetail.ResultDetailResponse
import com.lab.alarab.data.model.api.response.searchresult.SearchResultResponse
import com.lab.alarab.data.model.api.response.timeslot.TimeSlotResponse
import com.lab.alarab.data.model.api.response.updateitemwithcalculation.UpdateWithCalculationResponse
import com.lab.alarab.data.model.api.response.updateitemwithoutcalculation.UpdateWithoutCalculationResponse
import com.lab.alarab.utils.AppConstants
import io.reactivex.Single
import okhttp3.Cache
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import timber.log.Timber
import java.io.File
import java.util.concurrent.TimeUnit
import com.lab.alarab.data.model.api.PayRequestBody
import com.lab.alarab.data.model.api.PayResponseBody
import com.lab.alarab.data.model.api.TokenRequestBody
import com.lab.alarab.data.model.api.TokenResponse
import com.lab.alarab.data.model.api.response.availabletimeslot.AvailableTimeSlotResponse
import com.lab.alarab.data.model.api.response.city.CityResponse
import com.lab.alarab.utils.AppConstants.PAYFORT_ACCESS_CODE_PRODUCTION
import com.lab.alarab.utils.AppConstants.PAYFORT_AUTH_PATH
import com.lab.alarab.utils.AppConstants.PAYFORT_ESCI
import com.lab.alarab.utils.AppConstants.PAYFORT_LANGUAGE
import com.lab.alarab.utils.AppConstants.PAYFORT_MERCHANT_ID_PRODUCTION
import com.lab.alarab.utils.AppConstants.PAYFORT_MODE_PURCHASE
import java.nio.charset.StandardCharsets
import java.util.*
import kotlin.collections.ArrayList

object APIManager {

    private const val CACHE_FILE_NAME = "ARABLAB_http_cache"

    private lateinit var apiInterface: ApiInterface
    private var ConnectionType = "close"

    fun init(context: Context) {
        // cache
        val cacheFile = File(context.cacheDir, CACHE_FILE_NAME)
        cacheFile.mkdir()
        val cache = Cache(cacheFile, 10 * 1000 * 1000)

        // OKHttp
        val okHttpClient = OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .readTimeout(50, TimeUnit.SECONDS)
            .addInterceptor(LoggingInterceptor())
            .cache(cache)
            .build()

        // Retrofit
        val retrofit = Retrofit.Builder()
            .baseUrl(BuildConfig.BASE_URL)
            .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
            .addConverterFactory(
                GsonConverterFactory.create(
                    GsonBuilder()
                        .setLenient()
                        .create()
                )
            )
            .client(okHttpClient).build()

        apiInterface = retrofit.create(ApiInterface::class.java)
    }

    // API to check version number is allowed
    fun verifyMobileNo(
        countryCode: String,
        mobile: String
    ): Single<VerifyMobileResponse> {
        return apiInterface.verifyMobile(countryCode, mobile)
    }

    // API to check version number is allowed
    fun signInUpdateMobileNo(
        countryCode: String,
        mobile: String
    ): Single<VerifyMobileResponse> {
        return apiInterface.signInUpdateMobileNo(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!,
            countryCode, mobile
        )
    }

    // API to check version number is allowed
    fun signInWithOTP(
        countryCode: String,
        mobile: String,
        otp: String
    ): Single<SignInResponse> {
        return apiInterface.signInWithOTP(countryCode, mobile, otp)
    }

    // API to check version number is allowed
    fun verifyUpdateMobileNo(
        countryCode: String,
        mobile: String,
        otp: String
    ): Single<SignInResponse> {
        return apiInterface.verifyUpdateMobileNo(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!,
            countryCode, mobile, otp
        )
    }

    fun getFlagList(): Single<FlagListResponse> {
        return apiInterface.getFlags()
    }

    // API to register user
    fun signUpUser(
        countryCode: String,
        mobile: String,
        nationality: String,
        genderId: Int,
        birthYear: String,
        birthMonth: String,
        birthDay: String,
        firstName: String,
        lastName: String
    ): Single<SinUpResponse> {
        return apiInterface.signUpUser(
            countryCode,
            mobile,
            nationality,
            genderId,
            birthYear,
            birthMonth,
            birthDay,
            firstName,
            lastName
        )
    }

    // API to edit User
    fun editUser(
        countryCode: String,
        mobile: String,
        nationality: String,
        genderId: Int,
        birthYear: String,
        birthMonth: String,
        birthDay: String,
        firstName: String,
        lastName: String,
        email: String,
        profileImage: File?
    ): Single<SinUpResponse> {
        var image: MultipartBody.Part? = null
        image = if (profileImage != null) {
            val requestFile: RequestBody =
                profileImage.asRequestBody("image/png".toMediaTypeOrNull())
            MultipartBody.Part.createFormData("profile_image", profileImage.name, requestFile)

        } else {
            val attachmentEmpty = "".toRequestBody("image/png".toMediaTypeOrNull())
            MultipartBody.Part.createFormData("profile_image", "", attachmentEmpty)
        }

        return apiInterface.editUser(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!,
            countryCode.toRequestBody("text/plain".toMediaTypeOrNull()),
            mobile.toRequestBody("text/plain".toMediaTypeOrNull()),
            nationality.toRequestBody("text/plain".toMediaTypeOrNull()),
            genderId.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            birthYear.toRequestBody("text/plain".toMediaTypeOrNull()),
            birthMonth.toRequestBody("text/plain".toMediaTypeOrNull()),
            birthDay.toRequestBody("text/plain".toMediaTypeOrNull()),
            firstName.toRequestBody("text/plain".toMediaTypeOrNull()),
            lastName.toRequestBody("text/plain".toMediaTypeOrNull()),
            email.toRequestBody("text/plain".toMediaTypeOrNull()),
            image
        )
    }

    fun getLandingPageInformation(): Single<LandingPageResponse> {
        return apiInterface.getLandingPageInfo(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!,
            ConnectionType
        )
    }

    fun getResults(): Single<GetResultResponse> {
        return apiInterface.getResults(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!
        )
    }

    fun getAvailableTimeSlots(date: String): Single<TimeSlotResponse> {
        return apiInterface.getAvailableTimeSlots(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!,
            date
        )
    }

    fun getAvailableTimeSlotForProduct(
        date: String,
        packageId: Int,
        testType: Int,
        lng: Double,
        lat: Double,
        cityId: Int
    ): Single<AvailableTimeSlotResponse> {
        return apiInterface.getAvailableTimeSlotsForProduct(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!,
            date,
            packageId,
            testType,
            lng,
            lat,
            cityId
        )
    }


    fun addToCartWithCalculations(packageId: Int): Single<UpdateWithCalculationResponse> {
        return apiInterface.addToCartWithCalculations(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!,
            packageId
        )
    }

    fun addToCartWithFollowers(
        packageId: Int,
        type: Int,
        name: String,
        gender: Int,
        mobileNumber: String,
        nationality: Int,
        birthday: Int,
        birthMonth: Int,
        birthYear: Int
    ): Single<UpdateWithCalculationResponse> {
        return apiInterface.addToCartWithFollowers(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!,
            packageId,
            type,
            name,
            gender,
            mobileNumber,
            nationality,
            birthday,
            birthMonth,
            birthYear
        )
    }

    fun addToCartWithoutCalculations(packageId: Int): Single<UpdateWithoutCalculationResponse> {
        return apiInterface.addToCartWithoutCalculations(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!,
            packageId
        )
    }

    fun removeCartWithoutCalculations(packageId: Int): Single<UpdateWithoutCalculationResponse> {
        return apiInterface.removeCartWithoutCalculations(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!,
            packageId
        )
    }

    fun removeCartWithCalculations(packageId: Int): Single<RemoveWithCalculationResponse> {
        return apiInterface.removeWithCalculationResponse(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!,
            packageId
        )
    }

    fun viewCart(): Single<CartResponse> {
        return apiInterface.viewCart(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!,
            ConnectionType
        )
    }

    fun addCoupon(couponCode: String): Single<CouponResponse> {
        return apiInterface.addCoupon(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!,
            couponCode
        )
    }

    fun getSearchResults(
        categoryType: Int,
        query: String,
        categoryId: Int
    ): Single<SearchResultResponse> {
        return apiInterface.getSearchResults(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!,
            categoryId,
            categoryType,
            query
        )
    }

    fun getCategories(categoryType: Int): Single<CategoryResponse> {
        return apiInterface.getCategories(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!,
            categoryType
        )
    }

    fun getOrderHistory(): Single<OrderHistoryResponse> {
        return apiInterface.getOrderHistory(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!
        )
    }

    fun getOrderDetail(orderId: Int): Single<OrderDetailResponse> {
        return apiInterface.getOrderDetail(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!,
            orderId
        )
    }

    fun checkOrderPaid(orderId: Int): Single<SimpleResponse> {
        return apiInterface.checkOrderPaid(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!,
            orderId
        )
    }

    fun addOrder(
        address: String,
        paymentMethodId: Int,
        availableTimeId: Int,
        availableDate: String,
        longitude: Double,
        latitude: Double,
        hospitalId: Int
    ): Single<AddOrderResponse> {
        return apiInterface.addOrder(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!,
            address,
            paymentMethodId,
            availableTimeId,
            availableDate,
            longitude,
            latitude,
            hospitalId
        )
    }

    fun getAddressMetaData(): Single<AddressMetadataResponse> {
        return apiInterface.getAddressMetaData(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!
        )
    }

    fun getAddressDetail(addressId: Int): Single<AddressDetailResponse> {
        return apiInterface.getAddressDetail(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!,
            addressId
        )
    }

    fun getAddressList(): Single<AddressListResponse> {
        return apiInterface.getAddressList(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!,
        )
    }

    fun setDefaultAddress(addressId: Int): Single<DefaultAddressResponse> {
        return apiInterface.setDefaultAddressResponse(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!,
            addressId
        )
    }

    fun addAddress(
        addressTypeId: Int,
        addressTitleId: Int,
        streetAddress: String,
        landMark: String,
        city: String,
        lat: Double,
        long: Double,
        addressInfo: String
    ): Single<AddAddressResponse> {
        return apiInterface.addAddress(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!,
            addressTypeId,
            addressTitleId,
            streetAddress,
            landMark,
            city,
            lat,
            long,
            addressInfo
        )
    }

    fun editAddress(
        addressTypeId: Int,
        addressTitleId: Int,
        streetAddress: String,
        landMark: String,
        city: String,
        lat: Double,
        long: Double,
        addressInfo: String,
        addressId: Int
    ): Single<EditAddressResponse> {
        return apiInterface.editAddress(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!,
            addressId,
            addressTypeId,
            addressTitleId,
            streetAddress,
            landMark,
            city,
            lat,
            long,
            addressInfo,
        )
    }

    fun deleteAddress(
        addressId: Int
    ): Single<DeleteAddressResponse> {
        return apiInterface.deleteAddress(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!,
            addressId
        )
    }


    // Google-API to do reverse Geo0coding
    fun getGoogleAddress(latitude: Double, longitude: Double): Single<JsonObject> {
        return apiInterface.callGoogleAPI(
            "https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=${AppConstants.GOOGLE_MAP_API_KEY}"
        )
    }

    fun cancelOrder(addressId: Int): Single<CancelOrderResponse> {
        return apiInterface.cancelOrder(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!,
            addressId
        )
    }

    fun getResultDetail(orderId: Int): Single<ResultDetailResponse> {
        return apiInterface.getResultByOrder(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!,
            orderId
        )
    }

    fun getNotifications(): Single<NotificationResponse> {
        return apiInterface.getNotifications(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!
        )
    }

    fun getCityList() : Single<CityResponse>{
        return apiInterface.getCityList(
            PreferenceManager.currentUserId?.toString()!!,
            PreferenceManager.accessToken!!
        )
    }


    // Get payfort token
    fun getPayFortToken(userId: Long, deviceId: String): Single<TokenResponse> {
        val tokenRequestBody = TokenRequestBody()
        tokenRequestBody.deviceId = deviceId
        var url = ""
        url = AppConstants.PAYFORT_URL_LIVE
        tokenRequestBody.signature = getPayFortSignatureToken(userId, tokenRequestBody)

        return apiInterface.getPayFortToken(url, tokenRequestBody)
    }

    // Get Payfort Signature Token
    fun getPayFortSignatureToken(userId: Long, tokenRequestBody: TokenRequestBody): String {
        val data: MutableList<String> =
            ArrayList()
        data.add("service_command=${tokenRequestBody.serviceCommand}")
        data.add("access_code=${tokenRequestBody.accessCode}")
        data.add("merchant_identifier=${tokenRequestBody.merchantIdentifier}")
        data.add("language=${tokenRequestBody.language}")
        data.add("device_id=${tokenRequestBody.deviceId}")
        data.sort()
        val builder = java.lang.StringBuilder()
        builder.append(PAYFORT_AUTH_PATH)
        for (d in data) builder.append(d)
        builder.append(PAYFORT_AUTH_PATH)

        return getSHA256(builder.toString())
    }

    fun performPayWithPayFort(
        userId: Long,
        amount: Int,
        tokenName: String,
        merchantReference: String
    ): Single<PayResponseBody> {
        val payRequestBody = PayRequestBody()
        payRequestBody.merchantReference = merchantReference
        payRequestBody.amount = amount
        payRequestBody.customerEmail = "$userId@alarablabs.com"
        payRequestBody.tokenName = tokenName

        var url = ""

        url = AppConstants.PAYFORT_URL_LIVE
        payRequestBody.accessCode = PAYFORT_ACCESS_CODE_PRODUCTION
        payRequestBody.merchantIdentifier = PAYFORT_MERCHANT_ID_PRODUCTION


        payRequestBody.signature =
            getPayFortSignaturePayment(userId, amount, tokenName, merchantReference)

        return apiInterface.performPayWithPayFort(url, payRequestBody)
    }

    // Get Payfort Signature from information
    fun getPayFortSignaturePayment(
        userId: Long,
        amount: Int,
        tokenName: String,
        merchantReference: String,
    ): String {

        val data: MutableList<String> =
            ArrayList()
        data.add("command=$PAYFORT_MODE_PURCHASE")
        data.add("access_code=$PAYFORT_ACCESS_CODE_PRODUCTION")
        data.add("merchant_identifier=$PAYFORT_MERCHANT_ID_PRODUCTION")
        data.add("merchant_reference=$merchantReference")
        data.add("amount=$amount")
        data.add("currency=$AppConstants.PAYFORT_CURRENCY")
        data.add("language=$PAYFORT_LANGUAGE")
        data.add(
            "customer_email=" + userId
                .toString() + "@alarablabs.com"
        )
        data.add("eci=$PAYFORT_ESCI")
        data.add("token_name=$tokenName")

        data.sort()
        val builder = StringBuilder()
        builder.append(PAYFORT_AUTH_PATH)
        for (d in data) builder.append(d)
        builder.append(PAYFORT_AUTH_PATH)

        return getSHA256(builder.toString())
    }



    private fun getSHA256(data: String): String {
        return Hashing.sha256()
            .hashString(data, StandardCharsets.UTF_8)
            .toString().toUpperCase(Locale.ROOT)
    }
}