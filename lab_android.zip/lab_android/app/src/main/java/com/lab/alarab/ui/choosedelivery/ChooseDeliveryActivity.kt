package com.lab.alarab.ui.choosedelivery

import android.content.Context
import android.content.Intent
import android.location.Geocoder
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.gms.maps.model.LatLng
import com.google.gson.JsonObject
import com.lab.alarab.R
import com.lab.alarab.base.BaseActivity
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.model.api.response.DeleteAddressResponse
import com.lab.alarab.data.model.api.response.ErrorResponse
import com.lab.alarab.data.model.api.response.addressList.AddressListResponse
import com.lab.alarab.data.model.api.response.addressList.Addresse
import com.lab.alarab.databinding.ActivityChooseDeliveryBinding
import com.lab.alarab.ui.editaddress.EditAddressActivity
import com.lab.alarab.utils.AppConstants
import com.lab.alarab.utils.GPSTrackService
import com.lab.alarab.utils.MessageEvent
import com.lab.alarab.utils.NetworkUtils
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import timber.log.Timber
import java.io.IOException
import java.util.*

class ChooseDeliveryActivity : BaseActivity<ActivityChooseDeliveryBinding?, ChooseDeliveryViewModel>() {

    override val layoutId: Int
        get() = R.layout.activity_choose_delivery

    override val viewModel: ChooseDeliveryViewModel
        get() {
            return getViewModel(ChooseDeliveryViewModel::class.java)
        }
    var addressString :String ? = ""
    var gpsTracker :GPSTrackService? = null
    var adapter: AddressAdapter = AddressAdapter({onEdit()},{address-> removeAddress(address.iD)}){
        address->setAddressData(address)
    }

    private var selectedAddressId = 0
    private var lat = 0.0
    private var lng = 0.0
    private var cityName = ""
    private var currentCityName = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        EventBus.getDefault().register(this)

        viewDataBinding?.ivClose?.setOnClickListener {
            val returnIntent = Intent()
            val bundle = Bundle()
            bundle.putString("city", cityName)
            bundle.putDouble("lat",lat)
            bundle.putDouble("lng", lng)
            returnIntent.putExtras(bundle)
            setResult(RESULT_OK, returnIntent)
            finish()
        }

        viewDataBinding?.layoutCurrentLocation?.layoutBackground?.setOnClickListener {
            adapter.setSelection(-1)
            cityName = currentCityName
            lat = gpsTracker!!.latitude
            lng = gpsTracker!!.longitude
            viewDataBinding?.layoutCurrentLocation?.layoutBackground?.background =
                resources.getDrawable(R.drawable.ic_rounded_background_category_selected_12)
        }

        initRecyclerView()
        getAddressList()

  /*      viewDataBinding?.layoutBackgroundAnotherAddress?.setOnClickListener {
            startActivity(Intent(this@ChooseDeliveryActivity, EditAddressActivity::class.java))
        }

*/
        gpsTracker = GPSTrackService(this@ChooseDeliveryActivity)
        setAddress(LatLng(gpsTracker!!.latitude, gpsTracker!!.longitude))
    }

    private fun setAddress(latLng: LatLng) {
        try {
            addressString = getAddressName(this@ChooseDeliveryActivity, latLng.latitude, latLng.longitude)
            viewDataBinding?.layoutCurrentLocation?.tvLocation?.text = addressString
        } catch (e: java.lang.Exception) {
            getGoogleAddress(latLng.latitude, latLng.longitude)
            e.printStackTrace()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }

    private fun getAddressName(context: Context, latitude: Double, longitude: Double): String? {
        val geocoder = Geocoder(context, Locale.ENGLISH)
        var addresses: List<android.location.Address>? = null
        var addressName: String? = ""
        try {
            addresses = geocoder.getFromLocation(latitude, longitude, 1)
            addressName = addresses.first().getAddressLine(0)
            currentCityName = addresses.first().locality
        } catch (ignored: IOException) {
            Timber.tag("LocationMap -> parse").e(ignored)
            getGoogleAddress(latitude, longitude)
        }
        return addressName
    }

    private fun getAddressList(){
        viewModel.getAddressList(object : HandleResponse<AddressListResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(this@ChooseDeliveryActivity)) {
                    this@ChooseDeliveryActivity.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    this@ChooseDeliveryActivity.onError(
                        error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                    )
                }
            }

            override fun handleSuccessRespons(successResponse: AddressListResponse) {
                if (successResponse.success && successResponse.httpStatus == 200){
                    adapter.setItems(successResponse.response.addressesTitles)
                }else{
                    this@ChooseDeliveryActivity.onError(successResponse.errorMessage ?: AppConstants.DEFAULT_ERROR_MESSAGE)
                }
            }
        })
    }

    private fun setAddressData(address: Addresse){
        viewDataBinding?.layoutCurrentLocation?.layoutBackground?.background =
            resources.getDrawable(R.drawable.ic_rounded_white_background_12)

        cityName = address.cITY
        if (address?.lATITUDE != null && address?.lATITUDE!!.isNotEmpty()) lat = address?.lATITUDE?.toDouble()!!
        if (address?.lONGITUDE != null && address?.lONGITUDE!!.isNotEmpty()) lng  = address?.lONGITUDE?.toDouble()!!
        selectedAddressId = address.iD
    }

    private fun removeAddress(addressId: Int){
        if (selectedAddressId == addressId){
            selectedAddressId = 0
            cityName = ""
            lat = 0.0
            lng = 0.0
        }
        viewModel.removeAddress(addressId,
            object : HandleResponse<DeleteAddressResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (NetworkUtils.isNetworkConnected(this@ChooseDeliveryActivity)) {
                        this@ChooseDeliveryActivity.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        this@ChooseDeliveryActivity.onError(
                            error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }

                override fun handleSuccessRespons(successResponse: DeleteAddressResponse) {
                    if (successResponse.success && successResponse.httpStatus == 200){
                        getAddressList()
                    }else{
                        this@ChooseDeliveryActivity.onError(successResponse.errorMessage ?: AppConstants.DEFAULT_ERROR_MESSAGE)
                    }
                }
            })
    }

    private fun getGoogleAddress(latitude: Double, longitude: Double) {
        viewModel.getGoogleAddress(latitude, longitude, object : HandleResponse<JsonObject> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(this@ChooseDeliveryActivity)) {
                    this@ChooseDeliveryActivity.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    this@ChooseDeliveryActivity.onError(
                        error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                    )
                }
            }

            override fun handleSuccessRespons(successResponse: JsonObject) {
                addressString = try {
                    successResponse.getAsJsonArray("results")[1].asJsonObject["formatted_address"].toString()
                        .replace("\"", "")
                } catch (e: java.lang.Exception) {
                    ""
                }
                viewDataBinding?.layoutCurrentLocation?.tvLocation?.text = addressString
            }
        })
    }

    private fun onEdit(){

    }

    private fun initRecyclerView(){
        viewDataBinding?.recyclerView?.layoutManager = LinearLayoutManager(this@ChooseDeliveryActivity)
        viewDataBinding?.recyclerView?.adapter = adapter
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        when (event.message) {
            AppConstants.MESSAGE_ADDRESS_CHANGED -> {
                // If received broadcast message 'profile_changed', reload user information
                getAddressList()
            }
        }
    }
}