package com.lab.alarab.data.remote

import com.google.gson.JsonObject
import com.lab.alarab.data.model.api.response.*
import com.lab.alarab.data.model.api.response.addaddress.AddAddressResponse
import com.lab.alarab.data.model.api.response.addorder.AddOrderResponse
import com.lab.alarab.data.model.api.response.addressList.AddressListResponse
import com.lab.alarab.data.model.api.response.addressdetail.AddressDetailResponse
import com.lab.alarab.data.model.api.response.addressmeta.AddressMetadataResponse
import com.lab.alarab.data.model.api.response.cart.CartResponse
import com.lab.alarab.data.model.api.response.category.CategoryResponse
import com.lab.alarab.data.model.api.response.coupon.CouponResponse
import com.lab.alarab.data.model.api.response.defaultaddress.DefaultAddressResponse
import com.lab.alarab.data.model.api.response.editadderss.EditAddressResponse
import com.lab.alarab.data.model.api.response.getresult.GetResultResponse
import com.lab.alarab.data.model.api.response.landing.LandingPageResponse
import com.lab.alarab.data.model.api.response.notificationresponse.NotificationResponse
import com.lab.alarab.data.model.api.response.orderdetail.OrderDetailResponse
import com.lab.alarab.data.model.api.response.orderhistory.OrderHistoryResponse
import com.lab.alarab.data.model.api.response.removewithcalculation.RemoveWithCalculationResponse
import com.lab.alarab.data.model.api.response.resultdetail.ResultDetailResponse
import com.lab.alarab.data.model.api.response.searchresult.SearchResultResponse
import com.lab.alarab.data.model.api.response.timeslot.TimeSlotResponse
import com.lab.alarab.data.model.api.response.updateitemwithcalculation.UpdateWithCalculationResponse
import com.lab.alarab.data.model.api.response.updateitemwithoutcalculation.UpdateWithoutCalculationResponse
import io.reactivex.Single
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.http.*
import com.lab.alarab.data.model.api.PayRequestBody
import com.lab.alarab.data.model.api.PayResponseBody
import com.lab.alarab.data.model.api.TokenRequestBody
import com.lab.alarab.data.model.api.TokenResponse
import com.lab.alarab.data.model.api.response.availabletimeslot.AvailableTimeSlotResponse
import com.lab.alarab.data.model.api.response.city.CityResponse

interface ApiInterface {

    @FormUrlEncoded
    @POST("v1/user/sign_using_mobile_no")
    fun verifyMobile(
        @Field("country_code") countryCode: String?,
        @Field("mobile_no") mobileNo: String?,
    ): Single<VerifyMobileResponse>

    @FormUrlEncoded
    @POST("v1/user/update_mobile_no")
    fun signInUpdateMobileNo(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String,
        @Field("country_code") countryCode: String?,
        @Field("mobile_no") mobileNo: String?,
    ): Single<VerifyMobileResponse>

    @FormUrlEncoded
    @POST("v1/user/verify_mobile_no")
    fun signInWithOTP(
        @Field("country_code") countryCode: String?,
        @Field("mobile_no") mobileNo: String?,
        @Field("verification_code") otp: String?
    ): Single<SignInResponse>

    @FormUrlEncoded
    @POST("v1/user/verify_update_mobile_no")
    fun verifyUpdateMobileNo(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String,
        @Field("country_code") countryCode: String?,
        @Field("mobile_no") mobileNo: String?,
        @Field("verification_code") otp: String?
    ): Single<SignInResponse>

    @GET("v1/lab/nationalities")
    fun getFlags(): Single<FlagListResponse>

    @FormUrlEncoded
    @POST("v1/user/sign_up")
    fun signUpUser(
        @Field("country_code") countryCode: String?,
        @Field("mobile_no") mobileNo: String?,
        @Field("nationality") nationality: String?,
        @Field("gender_id") genderId: Int?,
        @Field("birth_year") birthYear: String,
        @Field("birth_month") birthMonth: String,
        @Field("birth_day") birthDay: String,
        @Field("first_name") firstName: String,
        @Field("last_name") lastName: String
    ): Single<SinUpResponse>

    @Multipart
    @POST("v1/user/edit")
    fun editUser(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String,
        @Part("country_code") countryCode: RequestBody?,
        @Part("mobile_no") mobileNo: RequestBody?,
        @Part("nationality") nationality: RequestBody?,
        @Part("gender_id") genderId: RequestBody?,
        @Part("birth_year") birthYear: RequestBody?,
        @Part("birth_month") birthMonth: RequestBody?,
        @Part("birth_day") birthDay: RequestBody?,
        @Part("first_name") firstName: RequestBody?,
        @Part("last_name") lastName: RequestBody?,
        @Part("email") email: RequestBody?,
        @Part profileImage: MultipartBody.Part?
    ): Single<SinUpResponse>

    @GET("v1/lab/landing")
    fun getLandingPageInfo(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String,
        @Header("Connection") connection: String
    ): Single<LandingPageResponse>

    @GET("v1/lab/cities")
    fun getCityList(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String
    ): Single<CityResponse>

    @GET("v1/lab/results")
    fun getResults(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String
    ): Single<GetResultResponse>

    @GET("v1/lab/available_times/{date}")
    fun getAvailableTimeSlots(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String,
        @Path("date") date: String
    ): Single<TimeSlotResponse>

    @GET("v1/lab/available_times/{date}")
    fun getAvailableTimeSlotsForProduct(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String,
        @Path("date") date: String,
        @Query("package-id") packageId: Int,
        @Query("test-type") testType: Int,
        @Query("long") longitude: Double,
        @Query("lat") latitude: Double,
        @Query("city-id") cityId: Int
    ): Single<AvailableTimeSlotResponse>

    @FormUrlEncoded
    @POST("v1/lab/update_cart_with_calculations")
    fun addToCartWithCalculations(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String,
        @Field("lab_category_package_id") packageId: Int
    ): Single<UpdateWithCalculationResponse>

    @FormUrlEncoded
    @POST("v1/lab/update_cart_with_calculations")
    fun addToCartWithFollowers(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String,
        @Field("lab_category_package_id") packageId: Int,
        @Field("type") type: Int,
        @Field("name") name: String,
        @Field("gender") gender: Int,
        @Field("mobile_number") mobileNumber: String,
        @Field("nationality") nationality: Int,
        @Field("birth_day") birthday: Int,
        @Field("birth_month") birthMonth: Int,
        @Field("birth_year") birthYear: Int
    ): Single<UpdateWithCalculationResponse>

    @FormUrlEncoded
    @POST("v1/lab/update_cart_without_calculations")
    fun addToCartWithoutCalculations(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String,
        @Field("lab_category_package_id") packageId: Int
    ): Single<UpdateWithoutCalculationResponse>

    @FormUrlEncoded
    @POST("v1/lab/update_cart_without_calculations")
    fun removeCartWithoutCalculations(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String,
        @Field("lab_category_package_id") packageId: Int
    ): Single<UpdateWithoutCalculationResponse>

    @FormUrlEncoded
    @POST("v1/lab/remove_cart_package_with_calculations")
    fun removeWithCalculationResponse(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String,
        @Field("cart_id") packageId: Int
    ): Single<RemoveWithCalculationResponse>

    @POST("v1/lab/view_cart")
    fun viewCart(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String,
        @Header("Connection") connection: String
    ): Single<CartResponse>

    @FormUrlEncoded
    @POST("v1/lab/view_cart")
    fun addCoupon(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String,
        @Field("coupon_code") couponCode: String
    ): Single<CouponResponse>

    @GET("v1/lab/category/{categoryId}/packages")
    fun getSearchResults(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String,
        @Path("categoryId") categoryId: Int,
        @Query("category-type") categoryType: Int,
        @Query("q") query: String
    ):Single<SearchResultResponse>

    @GET("v1/lab/categories")
    fun getCategories(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String,
        @Query("category-type") categoryType: Int
    ): Single<CategoryResponse>

    @GET("v1/lab/orders")
    fun getOrderHistory(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String
    ): Single<OrderHistoryResponse>

    @GET("v1/lab/order/{order_id}")
    fun getOrderDetail(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String,
        @Path("order_id") orderId: Int
    ): Single<OrderDetailResponse>

    @GET("v1/lab/order/{order_id}/check_order_paid")
    fun checkOrderPaid(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String,
        @Path("order_id") orderId: Int
    ): Single<SimpleResponse>

    @FormUrlEncoded
    @POST("v1/lab/order")
    fun addOrder(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String,
        @Field("address") address: String,
        @Field("payment_method_id") paymentMethodId: Int,
        @Field("available_time_id") availableTimeId: Int,
        @Field("available_date") availableDate: String,
        @Field("long") longitude: Double,
        @Field("lat") latitude: Double,
        @Field("hospital_id") hospitalId: Int
    ): Single<AddOrderResponse>

    @GET("v1/user/meta/addresses")
    fun getAddressMetaData(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String
    ): Single<AddressMetadataResponse>

    @GET("v1/user/addresses/{address_id}")
    fun getAddressDetail(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String,
        @Path("address_id") addressId: Int
    ): Single<AddressDetailResponse>

    @GET("v1/user/addresses")
    fun getAddressList(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String
    ): Single<AddressListResponse>

    @FormUrlEncoded
    @POST("v1/user/addresses/{address_id}/default")
    fun setDefaultAddressResponse(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String,
        @Path("address_id") addressId: Int
    ):Single<DefaultAddressResponse>

    @FormUrlEncoded
    @POST("v1/user/addresses")
    fun addAddress(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String,
        @Field("address_type_id") addressTypeId: Int,
        @Field("address_title_id") addressTitleId: Int,
        @Field("street_address") streetAddress: String,
        @Field("land_mark") landMark: String,
        @Field("city") city: String,
        @Field("lat") lat: Double,
        @Field("long") long: Double,
        @Field("address_info") addressInfo: String
    ):Single<AddAddressResponse>

    @FormUrlEncoded
    @POST("v1/user/addresses/{address_id}")
    fun editAddress(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String,
        @Path("address_id") addressId: Int,
        @Field("address_type_id") addressTypeId: Int,
        @Field("address_title_id") addressTitleId: Int,
        @Field("street_address") streetAddress: String,
        @Field("land_mark") landMark: String,
        @Field("city") city: String,
        @Field("lat") lat: Double,
        @Field("long") long: Double,
        @Field("address_info") addressInfo: String
    ):Single<EditAddressResponse>

    @GET
    fun callGoogleAPI(@Url url: String): Single<JsonObject>

    @DELETE("v1/user/addresses/{address_id}")
    fun deleteAddress(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String,
        @Path("address_id") addressId: Int
    ):Single<DeleteAddressResponse>

    @DELETE("v1/lab/order/{order_id}")
    fun cancelOrder(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String,
        @Path("order_id") addressId: Int
    ):Single<CancelOrderResponse>

    @GET("v1/lab/results")
    fun getResultByOrder(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String,
        @Query("order-id") orderId: Int
    ): Single<ResultDetailResponse>

    @GET("v1/user/notifications")
    fun getNotifications(
        @Header("end-user-id") userID: String,
        @Header("access-token") token: String
    ): Single<NotificationResponse>

    @POST
    fun getPayFortToken(
        @Url PayFortURL : String,
        @Body tokenBody: TokenRequestBody
    ): Single<TokenResponse>

    @POST
    fun performPayWithPayFort(
        @Url PayFortURL : String,
        @Body payRequestBody: PayRequestBody
    ): Single<PayResponseBody>


}