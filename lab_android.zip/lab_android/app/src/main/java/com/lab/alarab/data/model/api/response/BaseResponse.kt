package com.lab.alarab.data.model.api.response

import com.google.gson.annotations.SerializedName

open class BaseResponse {

    @field:SerializedName("httpCode")
    var code: Int? = 0

    @field:SerializedName("locale")
    var locale: String? = null

    @field:SerializedName("Message")
    var message: String? = null

    override fun toString(): String {
        return "BaseResponse(code=$code, locale=$locale, message=$message)"
    }


}
