package com.lab.alarab.ui.profile

import com.lab.alarab.base.BaseViewModel
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.model.api.response.SinUpResponse
import com.lab.alarab.data.model.api.response.VerifyMobileResponse
import com.lab.alarab.data.remote.APIManager
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import java.io.File

class ProfileViewModel :BaseViewModel(){
    // API to verify Mobile
    fun updateProfile(
        countryCode: String,
        mobile: String,
        nationality: String,
        genderId: Int,
        birthYear: String,
        birthMonth: String,
        birthDay: String,
        firstName: String,
        lastName: String,
        email: String,
        profileImage: File?,
        handleResponse: HandleResponse<SinUpResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.editUser(countryCode, mobile, nationality, genderId, birthYear, birthMonth, birthDay,firstName, lastName, email,
            profileImage)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }
}