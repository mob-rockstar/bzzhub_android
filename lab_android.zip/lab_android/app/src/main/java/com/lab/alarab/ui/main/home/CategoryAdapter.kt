package com.lab.alarab.ui.main.home

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.lab.alarab.R
import com.lab.alarab.base.BaseRecyclerViewAdapter
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.data.model.api.response.landing.DefaultCategory
import com.lab.alarab.databinding.RecyclerItemCategorySelectedBinding
import com.lab.alarab.utils.AppConstants

class CategoryAdapter : BaseRecyclerViewAdapter<DefaultCategory, RecyclerItemCategorySelectedBinding>()  {

    override val layoutId: Int
        get() = R.layout.recycler_item_category_selected

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return CategoryViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as CategoryViewHolder

        if (PreferenceManager.language.equals("en")) {
            holder.binding.tvContent.text = items[position].nAMEEN
        }else{
            holder.binding.tvContent.text = items[position].nAMEAR
        }

        val context = holder.itemView.context
        if (position == selected){
            holder.binding.tvContent.setTextColor(context.resources.getColor(R.color.colorAccent))
            holder.binding.tvContent.background = context.resources.getDrawable(R.drawable.ic_rounded_background_category_selected_30)
        }else{
            holder.binding.tvContent.setTextColor(context.resources.getColor(R.color.color_black_800))
            holder.binding.tvContent.background = context.resources.getDrawable(R.drawable.ic_rounded_white_background_30)
        }

        holder.itemView.setOnClickListener {
            AppConstants.categoryID = items[position].iD
            setSelection(position)
        }
    }

    override fun setItems(itemList: List<DefaultCategory>) {
        super.setItems(itemList)
        setSelection(0)
    }

        interface OnItemSelectedListener {
            fun onItemSelected(position: Int)
        }

    inner class CategoryViewHolder(val binding: RecyclerItemCategorySelectedBinding) :
        RecyclerView.ViewHolder(binding.root)
}