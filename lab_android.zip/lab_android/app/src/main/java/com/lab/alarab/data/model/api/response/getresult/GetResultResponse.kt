package com.lab.alarab.data.model.api.response.getresult


import com.google.gson.annotations.SerializedName

data class GetResultResponse(
    var errorMessage: String?,
    var httpStatus: Int,
    var response: List<Response>,
    var success: Boolean,
    var timestamp: Int
)