package com.lab.alarab.ui.forgotpassword.inputmobile

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import android.widget.Toast.LENGTH_LONG
import com.lab.alarab.R
import com.lab.alarab.base.BaseInputFragment
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.model.api.response.ErrorResponse
import com.lab.alarab.data.model.api.response.VerifyMobileResponse
import com.lab.alarab.databinding.FragmentForgotPasswordInputMobileBinding
import com.lab.alarab.databinding.FragmentInputMobileBinding
import com.lab.alarab.di.Injectable
import com.lab.alarab.ui.forgotpassword.ForgotPasswordViewModel
import com.lab.alarab.ui.forgotpassword.enterotp.ForgotPasswordEnterOTPFragment
import com.lab.alarab.utils.AppConstants
import com.lab.alarab.utils.NetworkUtils

class ForgotPasswordInputMobileFragment :
BaseInputFragment<FragmentForgotPasswordInputMobileBinding?, ForgotPasswordViewModel>(), Injectable {

    override val layoutId: Int
    get() = R.layout.fragment_forgot_password_input_mobile

    override val viewModel: ForgotPasswordViewModel
    get() {
        return getViewModel(baseActivity, ForgotPasswordViewModel::class.java)
    }

    private var strMobile = ""
    private var strCountryCode = ""

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        progressView = viewDataBinding?.progressView
        initUI()
    }

    private fun initUI(){
        viewDataBinding?.layoutSms?.setOnClickListener {
            if (isValidMobile()){
                verifyMobile()
            }else{
                Toast.makeText(baseActivity, baseActivity.resources.getString(R.string.str_enter_valid_mobile),
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        viewDataBinding?.layoutWhatsapp?.setOnClickListener {
            //       addFragment(R.id.frameLayout, EnterOTPFragment())
        }

        viewDataBinding?.toolbar?.ivBack?.setOnClickListener {
            finishActivity()
        }
        viewDataBinding?.toolbar?.tvHelp?.setOnClickListener {
            val i = Intent(Intent.ACTION_SEND)
            i.putExtra(Intent.EXTRA_EMAIL, arrayOf<String>("support@lab.com"))
            i.putExtra(Intent.EXTRA_SUBJECT, "Hello")
            i.putExtra(Intent.EXTRA_TEXT,"" )
            startActivity(Intent.createChooser(i, "Send email"))

        }
    }

    private fun isValidMobile(): Boolean{
        strMobile = viewDataBinding?.edittextMobile?.text.toString().trim()
        strCountryCode = viewDataBinding?.countryPicker?.selectedCountryCodeWithPlus!!
        return strMobile.length > 7
    }

    private fun verifyMobile(){
        viewModel.strMobile = strMobile
        viewModel.strCountryCode = strCountryCode

        viewModel.verifyMobileNumber(object : HandleResponse<VerifyMobileResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(baseActivity)) {
                    this@ForgotPasswordInputMobileFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    this@ForgotPasswordInputMobileFragment.onError(
                        error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                    )
                }
            }

            override fun handleSuccessRespons(successResponse: VerifyMobileResponse) {
                if (successResponse.httpStatus == 200 && successResponse.success){
                    addFragment(R.id.frameLayout, ForgotPasswordEnterOTPFragment())
                }else{
                    this@ForgotPasswordInputMobileFragment.onError(AppConstants.DEFAULT_ERROR_MESSAGE)
                }
            }
        })
    }
}