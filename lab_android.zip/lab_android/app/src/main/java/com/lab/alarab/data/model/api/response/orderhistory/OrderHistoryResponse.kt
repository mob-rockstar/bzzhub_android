package com.lab.alarab.data.model.api.response.orderhistory


import com.google.gson.annotations.SerializedName

data class OrderHistoryResponse(
    var errorMessage: String?,
    var httpStatus: Int,
    var response: List<Response>,
    var success: Boolean,
    var timestamp: Int
)