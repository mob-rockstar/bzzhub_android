package com.lab.alarab.ui.search

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.lab.alarab.R
import com.lab.alarab.base.BaseActivity
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.data.model.api.response.ErrorResponse
import com.lab.alarab.data.model.api.response.landing.CategoryType
import com.lab.alarab.data.model.api.response.searchresult.SearchResultResponse
import com.lab.alarab.data.model.api.response.updateitemwithcalculation.UpdateWithCalculationResponse
import com.lab.alarab.databinding.ActivitySearchProductBinding
import com.lab.alarab.ui.order.OrderActivity
import com.lab.alarab.ui.search.notification.NotificationFragment
import com.lab.alarab.utils.AppConstants
import com.lab.alarab.utils.MessageEvent
import com.lab.alarab.utils.NetworkUtils
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import javax.inject.Inject

class SearchProductActivity : BaseActivity<ActivitySearchProductBinding?, SearchViewModel>(),
    HasAndroidInjector {

    override val layoutId: Int
        get() = R.layout.activity_search_product

    private var categoryId = 0
    private var categoryTypeId = 0
    private var searchKey = ""
    private var categoryType: List<CategoryType>? = null

    override val viewModel: SearchViewModel
        get() = SearchViewModel()

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector


    private var searchProductAdapter: SearchProductAdapter = SearchProductAdapter(){
        product->addToCartWithCalculations(product?.iD!!)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        EventBus.getDefault().register(this)

        viewDataBinding?.layoutNotification?.setOnClickListener {
            showDialogFragment(NotificationFragment())
        }

        categoryType = AppConstants.categoryType
        categoryId = AppConstants.categoryID
        if (categoryType != null &&  categoryType!!.isNotEmpty()){
            categoryTypeId = categoryType!![0].iD
        }

        initEdittext()
        initRecyclerView()
        searchProduct()
        initCartCount()

        initListener()
        if (categoryType != null &&  categoryType!!.isNotEmpty()){
            initCategoryType()
        }
        viewDataBinding?.ivBack?.setOnClickListener {
            finish()
        }

        viewDataBinding?.layoutCart?.setOnClickListener {
            startActivity(Intent(this@SearchProductActivity, OrderActivity::class.java))
        }
    }

    private fun addToCartWithCalculations(packageId: Int){
        viewModel.addToCart(packageId, object : HandleResponse <UpdateWithCalculationResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(this@SearchProductActivity)) {
                    this@SearchProductActivity.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    this@SearchProductActivity.onError(
                        error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                    )
                }
            }

            override fun handleSuccessRespons(successResponse: UpdateWithCalculationResponse) {
                if (successResponse.success && successResponse.httpStatus == 200){
                    PreferenceManager.userCartCount = PreferenceManager.userCartCount+1
                }else{
                    this@SearchProductActivity.onError(
                        successResponse.errorMessage ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                }
            }
        })
    }


    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }

    private fun initCategoryType(){
        if (PreferenceManager.language == "en"){
            viewDataBinding?.tvIndividualTest?.text = categoryType!![0].nAMEEN
            viewDataBinding?.tvPackage?.text = categoryType!![1].nAMEEN
        }else{
            viewDataBinding?.tvIndividualTest?.text = categoryType!![0].nAMEAR
            viewDataBinding?.tvPackage?.text = categoryType!![1].nAMEAR
        }
    }

    private fun initRecyclerView(){
        viewDataBinding?.recyclerView?.layoutManager = LinearLayoutManager(this@SearchProductActivity)
        viewDataBinding?.recyclerView?.adapter = searchProductAdapter
    }

    private fun initListener(){
        viewDataBinding?.tvIndividualTest?.setOnClickListener {
            viewDataBinding?.tvPackage?.setTextColor(ContextCompat.getColor(
                this@SearchProductActivity,R.color.color_black_800))
            viewDataBinding?.tvIndividualTest?.setTextColor(ContextCompat.getColor(
                this@SearchProductActivity,R.color.color_white_1000))
            viewDataBinding?.tvIndividualTest?.background = ContextCompat.getDrawable(
                this@SearchProductActivity,R.drawable.ic_rounded_accent_background_30)
            viewDataBinding?.tvPackage?.background = null
            categoryTypeId = categoryType!![0].iD
            searchProduct()
        }

        viewDataBinding?.tvPackage?.setOnClickListener {
            viewDataBinding?.tvPackage?.setTextColor(ContextCompat.getColor(
                this@SearchProductActivity,R.color.color_white_1000))
            viewDataBinding?.tvIndividualTest?.background = null
            viewDataBinding?.tvPackage?.background = ContextCompat.getDrawable(
                this@SearchProductActivity,R.drawable.ic_rounded_accent_background_30)
            viewDataBinding?.tvIndividualTest?.setTextColor(ContextCompat.getColor(
                this@SearchProductActivity,R.color.color_black_800))
            categoryTypeId = categoryType!![1].iD
            searchProduct()
        }
    }

    private fun initEdittext(){
        viewDataBinding?.edittextSearch?.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                searchKey = s.toString().trim()
                searchProduct()
            }
        })
    }

    private fun searchProduct(){
        viewModel.getProductSearchResults(categoryId, searchKey, categoryTypeId,
            object : HandleResponse<SearchResultResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (NetworkUtils.isNetworkConnected(this@SearchProductActivity)) {
                        this@SearchProductActivity.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        this@SearchProductActivity.onError(
                            error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }

                override fun handleSuccessRespons(successResponse: SearchResultResponse) {
                    if (successResponse.success && successResponse.httpStatus == 200){
                        searchProductAdapter.setItems(successResponse.response)
                    }else{
                        this@SearchProductActivity.onError(
                            successResponse.errorMessage ?: AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }
            })
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        when (event.message) {
            AppConstants.MESSAGE_CART_CHANGED -> {
                // If received broadcast message 'profile_changed', reload user information
                initCartCount()
            }
        }
    }

    private fun initCartCount(){
        viewDataBinding?.layoutCartCount?.visibility =
            if (PreferenceManager.userCartCount == 0) View.GONE
            else View.VISIBLE

        viewDataBinding?.tvCartCount?.text = PreferenceManager.userCartCount.toString()
    }
}