package com.lab.alarab.ui.main.tracking

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.lab.alarab.R
import com.lab.alarab.base.BaseRecyclerViewAdapter
import com.lab.alarab.data.model.api.response.landing.DefaultProduct
import com.lab.alarab.data.model.api.response.orderhistory.Response
import com.lab.alarab.databinding.RecyclerItemHomeDefaultProductBinding
import com.lab.alarab.databinding.RecyclerItemTrackingBinding
import com.lab.alarab.ui.main.home.DefaultProductAdapter
import com.lab.alarab.utils.DateUtils

class TrackingAdapter(private val onSelected: (orderId: Int)->Unit) : BaseRecyclerViewAdapter<Response, RecyclerItemTrackingBinding>()  {

    override val layoutId: Int
        get() = R.layout.recycler_item_tracking

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return TrackingViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as TrackingViewHolder

        val context =holder.binding.root.context
        holder.binding.tvOrderNumber.text = context.resources.getString(R.string.str_order_number, items[position].iD.toString())

        holder.binding.tvDate.text = context.resources.getString(R.string.str_order_date, DateUtils.getOrderDate(items[position].sCHEDULEDATE))

        holder.binding.tvTime.text =
            """${DateUtils.getOrderTime(items[position].lABAVAILABLETIME.fROMTIME)} - ${
                DateUtils.getOrderTime(items[position].lABAVAILABLETIME.tOTIME)
            }"""

        holder.itemView?.setOnClickListener {
            onSelected(items[position].iD)
        }
    }

    inner class TrackingViewHolder(val binding: RecyclerItemTrackingBinding) :
        RecyclerView.ViewHolder(binding.root)
}