package com.lab.alarab.di.builder

import com.lab.alarab.ui.login.enterotp.EnterOTPFragment
import com.lab.alarab.ui.login.inputinfo.InputInfoFragment
import com.lab.alarab.ui.login.inputmobile.InputMobileFragment
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class FragmentLoginModule {
    @ContributesAndroidInjector
    abstract fun contributeLoginTypeFragment(): InputMobileFragment

    @ContributesAndroidInjector
    abstract fun contributeInputInfoFragmentFragment(): InputInfoFragment

    @ContributesAndroidInjector
    abstract fun contributeEnterOTPFragmentFragmentFragment(): EnterOTPFragment
}