package com.lab.alarab.ui.editaddress

import android.content.Intent
import android.os.Bundle
import android.view.View.GONE
import android.widget.Toast
import android.widget.Toast.LENGTH_LONG
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.lab.alarab.R
import com.lab.alarab.base.BaseActivity
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.model.api.response.ErrorResponse
import com.lab.alarab.data.model.api.response.addaddress.AddAddressResponse
import com.lab.alarab.data.model.api.response.addressList.Addresse
import com.lab.alarab.data.model.api.response.addressmeta.AddressMetadataResponse
import com.lab.alarab.data.model.api.response.addressmeta.AddressType
import com.lab.alarab.data.model.api.response.editadderss.EditAddressResponse
import com.lab.alarab.data.model.api.response.flag.FlagObject
import com.lab.alarab.databinding.ActivityEditAddressBinding
import com.lab.alarab.ui.pickup.PickUpAddressActivity
import com.lab.alarab.utils.*
import org.greenrobot.eventbus.EventBus
import timber.log.Timber
import java.io.Serializable


class EditAddressActivity : BaseActivity<ActivityEditAddressBinding?, EditAddressViewModel>() {

    override val layoutId: Int
        get() = R.layout.activity_edit_address

    override val viewModel: EditAddressViewModel
        get() = EditAddressViewModel()

    private lateinit var userMap: GoogleMap

    var address: Addresse? = null
    var addressTypeList : List<AddressType> = ArrayList()
    var selectedAddressType : AddressType? = null
    var addressTypeId = 0
    var addressTitleId = 0
    var streetAddress =""
    var landMark =""
    var cityName = ""
    var lat : Double = 0.0
    var lng : Double = 0.0
    var addressInfo = ""
    var addressId: Int = 0
    var gpsTracker: GPSTrackService ? = null
    private val LOCATION_PICK_REQUEST = 1002
    var marker: MarkerOptions? =null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewDataBinding?.toolbar?.tvTitle?.text = resources.getString(R.string.str_delivery_adderss)

        gpsTracker = GPSTrackService(this)

        address = intent.getSerializableExtra("address") as Addresse?
        addressTitleId = intent.getIntExtra("address_title", 0)
        getAddressMetaData()

        if (address == null){
            viewDataBinding?.toolbar?.ivRemove?.visibility = GONE
        }else{
            initUI()
        }

        initMap()
        initListeners()
    }

    private fun initUI(){
        viewDataBinding?.tvAddressName?.text = address?.sTREETADDRESS

        cityName = address?.cITY!!
        streetAddress = address?.sTREETADDRESS!!
        if (address?.lATITUDE != null && address?.lATITUDE!!.isNotEmpty()) lat = address?.lATITUDE?.toDouble()!!
        if (address?.lONGITUDE != null && address?.lONGITUDE!!.isNotEmpty()) lng  = address?.lONGITUDE?.toDouble()!!
        landMark = address?.lANDMARK!!
        addressTypeId = address!!.aDDRESSTYPEID
        addressId = address!!.iD
        addressInfo = address!!.aDDRESSINFO

        viewDataBinding?.edittextLandmark?.setText(landMark)
        viewDataBinding?.edittextAddress?.setText(addressInfo)
    }

    private fun initMap(){
        // user address
        val mapFragment =
            supportFragmentManager.findFragmentById(R.id.fragment_map) as SupportMapFragment
        mapFragment.view?.isClickable = false
        mapFragment.getMapAsync { map ->
            map.uiSettings.isMapToolbarEnabled = false
            val userLatLng = LatLng(
                if (address != null && lat != 0.0) lat else gpsTracker!!.latitude,
                if (address != null && lng != 0.0) lat else gpsTracker!!.longitude
            )
            map.moveCamera(CameraUpdateFactory.newLatLng(userLatLng))
    /*        marker = MarkerOptions().position(LatLng( if (address != null && lat != 0.0) lat else gpsTracker!!.latitude,
                    if (address != null && lng != 0.0) lat else gpsTracker!!.longitude))
                .title("")
            map.addMarker(marker)*/
            userMap = map
        }
    }

    private fun initListeners(){

     //   viewDataBinding?.tvSaveAddress?.setOnClickListener { finish() }

        viewDataBinding?.toolbar?.ivBack?.setOnClickListener { finish() }

        viewDataBinding?.layoutEditType?.setOnClickListener {
            PopupUtils.showAddressTypeDialog(this@EditAddressActivity, addressTypeList){
                    addressType ->
                    selectedAddressType  = addressType
                    addressTypeId = selectedAddressType?.iD!!
             }
        }

        viewDataBinding?.tvModify?.setOnClickListener {
            val intent = Intent(this@EditAddressActivity, PickUpAddressActivity::class.java)
            if (address != null){
                intent.putExtra("address", address)
            }
            startActivityForResult(intent, LOCATION_PICK_REQUEST)
        }

        viewDataBinding?.tvSaveAddress?.setOnClickListener {
            addressInfo = viewDataBinding?.edittextAddress?.text.toString().trim()
            landMark = viewDataBinding?.edittextLandmark?.text.toString().trim()
            if (address == null){
                addAddress()
            }else{
                updateAddress()
            }
        }
    }

    private fun addAddress(){
        if (addressTypeId != 0
            && streetAddress.isNotEmpty() &&
            cityName.isNotEmpty() &&
            lat != 0.0 &&
            addressInfo.isNotEmpty()){
            viewModel.addAddress(addressTitleId,
                addressTypeId,
                streetAddress,
                landMark,
                cityName,
                lat,
                lng,
                addressInfo,
                object : HandleResponse<AddAddressResponse> {
                    override fun handleErrorResponse(error: ErrorResponse?) {
                        if (NetworkUtils.isNetworkConnected(this@EditAddressActivity)) {
                            this@EditAddressActivity.onError(
                                error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                            )
                        } else {
                            this@EditAddressActivity.onError(
                                error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                            )
                        }
                    }

                    override fun handleSuccessRespons(successResponse: AddAddressResponse) {
                        if (successResponse.success && successResponse.httpStatus == 200) {
                            EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_ADDRESS_CHANGED))
                            finish()
                        } else {
                            this@EditAddressActivity.onError(
                                successResponse?.errorMessage ?: AppConstants.NETWORK_ERROR_MESSAGE
                            )
                        }
                    }
                })
        }else{
            var strErrorMessage = ""
            when {
                addressTypeId == 0 -> {
                    strErrorMessage = "Please select Address Type"
                }
                streetAddress.isEmpty() -> {
                    Timber.tag("aaaaaa").d("111111")
                    strErrorMessage = "Please select your delivery location"
                }
                cityName.isEmpty() -> {
                    Timber.tag("aaaaaa").d("2222222")
                    strErrorMessage = "Please select your delivery location "
                }
                lat == 0.0 -> {
                    Timber.tag("aaaaaa").d("3333333")
                    strErrorMessage = "Please select your delivery location"
                }
                addressInfo.isEmpty() -> {
                    strErrorMessage = "Please add address Info"
                }
            }
            Toast.makeText(this@EditAddressActivity, strErrorMessage, LENGTH_LONG).show()
        }
    }

    private fun updateAddress(){
        if (addressTypeId != 0
            && streetAddress.isNotEmpty() &&
            cityName.isNotEmpty() &&
            lat != 0.0 &&
            addressInfo.isNotEmpty()){
            viewModel.updateAddress(addressTitleId,
                addressTypeId,
                streetAddress,
                landMark,
                cityName,
                lat,
                lng,
                addressInfo,
                addressId,
                object : HandleResponse<EditAddressResponse> {
                    override fun handleErrorResponse(error: ErrorResponse?) {
                        if (NetworkUtils.isNetworkConnected(this@EditAddressActivity)) {
                            this@EditAddressActivity.onError(
                                error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                            )
                        } else {
                            this@EditAddressActivity.onError(
                                error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                            )
                        }
                    }

                    override fun handleSuccessRespons(successResponse: EditAddressResponse) {
                        if (successResponse.success && successResponse.httpStatus == 200) {
                            EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_ADDRESS_CHANGED))
                            finish()
                        } else {
                            this@EditAddressActivity.onError(
                                successResponse?.errorMessage ?: AppConstants.NETWORK_ERROR_MESSAGE
                            )
                        }
                    }
                })
        }else{
            var strErrorMessage = ""
            when {
                addressTypeId == 0 -> {
                    strErrorMessage = "Please select Address Type"
                }
                streetAddress.isEmpty() -> {
                    Timber.tag("aaaaaa").d("111111")
                    strErrorMessage = "Please select your delivery location"
                }
                cityName.isEmpty() -> {
                    Timber.tag("aaaaaa").d("2222222")
                    strErrorMessage = "Please select your delivery location "
                }
                lat == 0.0 -> {
                    Timber.tag("aaaaaa").d("3333333")
                    strErrorMessage = "Please select your delivery location"
                }
                addressInfo.isEmpty() -> {
                    strErrorMessage = "Please add address Info"
                }
            }
            Toast.makeText(this@EditAddressActivity, strErrorMessage, LENGTH_LONG).show()
        }
    }

    private fun getAddressMetaData(){
        viewModel.getAddressMetaData(object : HandleResponse<AddressMetadataResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(this@EditAddressActivity)) {
                    this@EditAddressActivity.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    this@EditAddressActivity.onError(
                        error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                    )
                }
            }

            override fun handleSuccessRespons(successResponse: AddressMetadataResponse) {
                if (successResponse.success && successResponse.httpStatus == 200) {
                    addressTypeList = successResponse.response.addressTypes
                } else {
                    this@EditAddressActivity.onError(
                        successResponse?.errorMessage ?: AppConstants.NETWORK_ERROR_MESSAGE
                    )
                }
            }
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode === this.LOCATION_PICK_REQUEST && resultCode === RESULT_OK) {
            Timber.tag("aaaa").d("aaaaaa")
            cityName = data?.extras?.getString("city")!!
            streetAddress = data?.extras?.getString("street")!!
            lat = data?.extras?.getDouble("lat")!!
            lng = data?.extras?.getDouble("lng")!!

            viewDataBinding?.tvAddressName?.text = streetAddress
        }
    }



/*    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.startActivityForResult(intent, requestCode)
        if (requestCode === this.LOCATION_PICK_REQUEST && resultCode === androidx.appcompat.app.AppCompatActivity.RESULT_OK) {

        }
    }*/
}