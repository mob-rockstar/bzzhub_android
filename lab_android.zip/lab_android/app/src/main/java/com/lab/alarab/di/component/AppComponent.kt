package com.lab.alarab.di.component

import com.lab.alarab.ArabLabApp
import com.lab.alarab.di.builder.ActivityBuilder
import com.lab.alarab.di.module.AppModule
import dagger.BindsInstance
import dagger.Component
import dagger.android.AndroidInjectionModule
import javax.inject.Singleton


@Singleton
@Component(modules = [AndroidInjectionModule::class, AppModule::class, ActivityBuilder::class])
interface AppComponent {

    @Component.Builder
    interface Builder {
        @BindsInstance
        fun application(application: ArabLabApp): Builder
        fun build(): AppComponent
    }

    fun inject(app: ArabLabApp)

}