package com.lab.alarab.ui.main.result

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.lab.alarab.R
import com.lab.alarab.base.BaseRecyclerViewAdapter
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.databinding.RecyclerItemResultBinding

class ResultAdapter(private  val onSelect: (item: com.lab.alarab.data.model.api.response.getresult.Response)->Unit, private val onCall:()->Unit)  : BaseRecyclerViewAdapter<com.lab.alarab.data.model.api.response.getresult.Response, RecyclerItemResultBinding>()  {

    override val layoutId: Int
        get() = R.layout.recycler_item_result

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return ResultViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as ResultViewHolder

        val context =holder.binding.root.context
        holder.binding.tvName.text = items[position].nAME
        holder.binding.tvDate.text = items[position].bIRTHDATE
        if (PreferenceManager.language == "en"){
            holder.binding.tvDescription?.text = items[position].lABCATEGORYPACKAGE.nAMEEN
        }else{
            holder.binding.tvDescription?.text = items[position].lABCATEGORYPACKAGE.nAMEAR
        }

        holder.itemView.setOnClickListener {
            onSelect(items[position])
        }

        holder.binding.tvCall?.setOnClickListener { onCall() }

    }

    inner class ResultViewHolder(val binding: RecyclerItemResultBinding) :
        RecyclerView.ViewHolder(binding.root)
}