package com.lab.alarab.ui.time

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.DatePicker
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.lab.alarab.R
import com.lab.alarab.base.BaseActivity
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.data.model.api.response.ErrorResponse
import com.lab.alarab.data.model.api.response.availabletimeslot.AvailableTimeSlotResponse
import com.lab.alarab.data.model.api.response.availabletimeslot.Response
import com.lab.alarab.data.model.api.response.removewithcalculation.RemoveWithCalculationResponse
import com.lab.alarab.data.model.api.response.updateitemwithcalculation.UpdateWithCalculationResponse
import com.lab.alarab.databinding.ActivityAvailableTimeBinding
import com.lab.alarab.ui.payment.PaymentActivity
import com.lab.alarab.utils.*
import timber.log.Timber
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class AvailableTimeActivity : BaseActivity<ActivityAvailableTimeBinding?, AvailableTimeViewModel>() {

    override val layoutId: Int
        get() = R.layout.activity_available_time

    override val viewModel: AvailableTimeViewModel
        get() = AvailableTimeViewModel()

    private var mDatePickerDialog: DatePickerDialog? = null
    private var strDate = ""
    private var strDateForAPI = ""
    private val apiDateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)

    private var selectedTimeId = 0
    private var cityName = ""

    // Package Id
    private var packageId : Int = 0

    // City Id
    private var cityId : Int = 0

    lateinit var linearLayoutManager: LinearLayoutManager

    var gpsTracker: GPSTrackService? = null
    private var latitude : Double = 0.0
    private var longitude : Double = 0.0
    private var availableTimeData: Response?= null
    private var hospitalAdapter: HospitalAdapter = HospitalAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize the GPS tracker
        gpsTracker = GPSTrackService(this)

        // Check if it can get the current location
        if (gpsTracker!!.canGetLocation){
            latitude = gpsTracker!!.getLatitude()
            longitude = gpsTracker!!.getLongitude()
        }

        initDate()

        strDateForAPI = apiDateFormat.format(Date())
        AppConstants.strDateForAPI = strDateForAPI

        strDate = SimpleDateFormat("EEE, dd, MMM", Locale.ENGLISH).format(Date())
        viewDataBinding?.tvDate?.text = strDate
        setDateTimeField()
        viewDataBinding?.tvDate?.setOnClickListener {
            mDatePickerDialog?.show()
        }

        initTimeSlotsRecyclerView()

        // Previous Date
        viewDataBinding?.ivNext?.setOnClickListener {
            Timber.tag("DateStringIs").d(viewDataBinding?.tvDate?.text.toString() + "aaaaa")
            viewDataBinding?.tvDate?.text =
                DateUtils.getNextDateAsString(viewDataBinding?.tvDate?.text.toString())
            strDate = viewDataBinding?.tvDate?.text.toString()
            strDateForAPI = DateUtils.getNextDateAsStringForAPI(strDateForAPI)
            AppConstants.strDateForAPI = strDateForAPI
            // Get the time slots
            getAvailableTimeSlot(packageId, cityId, strDateForAPI)
        }

        // Next Date
        viewDataBinding?.ivBefore?.setOnClickListener {
            viewDataBinding?.tvDate?.text =
                DateUtils.getPreviewsDayFromString(viewDataBinding?.tvDate?.text.toString())
            strDate = viewDataBinding?.tvDate?.text.toString()
            strDateForAPI = DateUtils.getPreviewsDayFromString(strDateForAPI)
            AppConstants.strDateForAPI = strDateForAPI
            // Get the time slots
            getAvailableTimeSlot(packageId, cityId, strDateForAPI)
        }

        if (intent.extras != null) {
            packageId     = intent.extras!!.getInt("package_id")
            cityId        = intent.extras!!.getInt("city_id")

            // Get the time slots
            getAvailableTimeSlot(packageId, cityId, strDateForAPI)
        }

        initToolbar()
    }

    private fun initToolbar(){
        viewDataBinding?.ivBack?.setOnClickListener { finish() }
        viewDataBinding?.tvCity?.text = CommonUtils.getCityNameWithID(cityId)

        viewDataBinding?.layoutThumb?.setOnClickListener {
            viewDataBinding?.layoutThumb?.background = ContextCompat.getDrawable(this, R.drawable.ic_circle_background_accent)
            viewDataBinding?.layoutPeople?.background = null
            hospitalAdapter.setWalkAvailable(false)
        }

        viewDataBinding?.layoutPeople?.setOnClickListener {
            viewDataBinding?.layoutThumb?.background = null
            viewDataBinding?.layoutPeople?.background = ContextCompat.getDrawable(this, R.drawable.ic_circle_background_accent)
            hospitalAdapter.setWalkAvailable(true)
        }
    }

    private fun initTimeSlotsRecyclerView(){
        linearLayoutManager = LinearLayoutManager(this)

        viewDataBinding!!.recyclerView.layoutManager = linearLayoutManager
        viewDataBinding!!.recyclerView.setHasFixedSize(true)
        viewDataBinding!!.recyclerView.adapter = hospitalAdapter
    }


    private fun initDate() {
        viewDataBinding?.tvDate?.text = DateUtils.getCurrentDateAsString()
    }

    private fun setDateTimeField() {
        val newCalendar = Calendar.getInstance()
        mDatePickerDialog = DatePickerDialog(
            this@AvailableTimeActivity,
            R.style.styleDatePickerDialog,
             { _: DatePicker?, year: Int, monthOfYear: Int, dayOfMonth: Int ->
                val newDate = Calendar.getInstance()
                newDate[year, monthOfYear] = dayOfMonth
                val formatDate =
                    SimpleDateFormat("EEE, dd, MMM", Locale.ENGLISH)
                val startDate = newDate.time
                val fdate = formatDate.format(startDate)
                strDate = formatDate.format(startDate)
                strDateForAPI = apiDateFormat.format(startDate)
                 AppConstants.strDateForAPI = strDateForAPI
                // Get the time slots
                getAvailableTimeSlot(packageId, cityId, strDateForAPI)

                viewDataBinding?.tvDate?.text = fdate
                //      enableNextButton()
            },
            newCalendar[Calendar.YEAR],
            newCalendar[Calendar.MONTH],
            newCalendar[Calendar.DAY_OF_MONTH]
        )
        val c = Calendar.getInstance()
        mDatePickerDialog!!.datePicker.minDate = c.timeInMillis
        mDatePickerDialog!!.setTitle("")
    }

    private fun getAvailableTimeSlot(packageId : Int, cityId : Int, date: String) {
        viewModel.getAvailableTimeList(packageId, cityId, longitude, latitude, 1, date,
            object : HandleResponse<AvailableTimeSlotResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (NetworkUtils.isNetworkConnected(this@AvailableTimeActivity)) {
                        this@AvailableTimeActivity.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        this@AvailableTimeActivity.onError(
                            error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }

                override fun handleSuccessRespons(successResponse: AvailableTimeSlotResponse) {
                    if (successResponse.success && successResponse.httpStatus == 200) {
                        // Refresh the TimeSlots RecyclerView
                        availableTimeData = successResponse.response
                        initUI()
                    } else {
                        this@AvailableTimeActivity.onError(
                            AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }
            })
    }

    private fun initUI(){
        viewDataBinding?.tvName?.text =
            if (PreferenceManager.language == "en"){
            availableTimeData?.`package`?.NAME_EN
        }else availableTimeData?.`package`?.NAME_AR

        hospitalAdapter.setItems(availableTimeData?.hospitals ?: ArrayList())
    }


    fun addToCartWithCalculations(){
        viewModel.addToCart(packageId, object : HandleResponse <UpdateWithCalculationResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(this@AvailableTimeActivity)) {
                    this@AvailableTimeActivity.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    this@AvailableTimeActivity.onError(
                        error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                    )
                }
            }

            override fun handleSuccessRespons(successResponse: UpdateWithCalculationResponse) {
                if (successResponse.success && successResponse.httpStatus == 200){
                    PreferenceManager.userCartCount = PreferenceManager.userCartCount+1
                    startActivity(Intent(this@AvailableTimeActivity, PaymentActivity::class.java))
                  //  getLandingPageInfo()
                }else{
                    this@AvailableTimeActivity.onError(
                        successResponse.errorMessage ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                }
            }
        })
    }

    private fun removeItemFromCart(){
        viewModel.removeItemFromCart(packageId, object : HandleResponse <RemoveWithCalculationResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {

            }

            override fun handleSuccessRespons(successResponse: RemoveWithCalculationResponse) {
                if (successResponse.success && successResponse.httpStatus == 200){

                }
            }
        })
    }

    override fun onDestroy() {
        super.onDestroy()
        removeItemFromCart()
    }
}