package com.lab.alarab.ui.resultexplanation

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.URLUtil
import android.webkit.WebView
import android.webkit.WebViewClient
import com.lab.alarab.R
import com.lab.alarab.base.BaseActivity
import com.lab.alarab.databinding.ActivityResultExplanationBinding
import com.lab.alarab.ui.videovisit.VideoVisitActivity
import com.lab.alarab.utils.AppConstants
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import timber.log.Timber
import javax.inject.Inject


class ResultExplanationActivity : BaseActivity<ActivityResultExplanationBinding?, ResultExplanationViewModel>() ,
    HasAndroidInjector {


    override val layoutId: Int
        get() = R.layout.activity_result_explanation

    override val viewModel: ResultExplanationViewModel
        get() {
            return getViewModel(ResultExplanationViewModel::class.java)
        }

    private var url = "https://testcorona.co/samples/306/pdf"
    private var orderId = 0

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewDataBinding?.layoutToolbar?.tvTitle?.text = resources.getString(R.string.str_result_explanation)

        viewDataBinding?.layoutToolbar?.ivBack?.setOnClickListener { finish() }

        url = intent.getStringExtra("document_url") ?: ""
        orderId = intent.getIntExtra("order_id", 0)

        viewDataBinding?.layoutVideoCall?.setOnClickListener {
            startActivity(Intent(this@ResultExplanationActivity, VideoVisitActivity::class.java))
        }

        viewDataBinding?.layoutDownload?.setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }

        viewDataBinding?.webView?.settings?.javaScriptEnabled = true
        viewDataBinding?.webView?.settings?.loadWithOverviewMode = true
        viewDataBinding?.webView?.settings?.useWideViewPort = true
        viewDataBinding?.webView?.settings?.userAgentString =
            "${viewDataBinding?.webView?.settings?.userAgentString} ${AppConstants.APP_NAME}"

        viewDataBinding?.webView?.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                return if (URLUtil.isNetworkUrl(url)){
                    view?.loadUrl(url!!)
                    false
                }else{
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    startActivity(intent)
                    true
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                Timber.tag("contentURL").d(url)

            }
        }

        viewDataBinding?.webView?.loadUrl("https://drive.google.com/viewerng/viewer?embedded=true&url=$url");
    }
    
    
}