package com.lab.alarab.data.model.api.response.availabletimeslot

data class Response(
    val hospitals: List<Hospital>,
    val `package`: Package
)