package com.lab.alarab.ui.choosedelivery

import android.content.Intent
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.lab.alarab.R
import com.lab.alarab.base.BaseRecyclerViewAdapter
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.data.model.api.response.addressList.Addresse
import com.lab.alarab.data.model.api.response.addressList.AddressesTitle
import com.lab.alarab.databinding.RecyclerItemLocationBinding
import com.lab.alarab.ui.editaddress.EditAddressActivity
import com.lab.alarab.ui.pickup.PickUpAddressActivity
import com.lab.alarab.utils.PopupUtils

class AddressAdapter(private val onEdit:()-> Unit
                     ,private val onRemove:(address: Addresse) -> Unit
                     ,private val onSelect: (address: Addresse)->Unit)
    : BaseRecyclerViewAdapter<AddressesTitle, RecyclerItemLocationBinding>()  {

    override val layoutId: Int
        get() = R.layout.recycler_item_location

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return AddressViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as AddressViewHolder
        val context = holder.itemView.context

        holder.binding.tvAddressType?.text = if (PreferenceManager.language == "en")
            items[position].nAMEEN else items[position].nAMEAR

        if (items[position].addresses.isEmpty()){
            holder.binding.tvLocation.text = context.resources.getString(R.string.str_add_adderss)
            holder.binding.ivRefresh.setImageDrawable(context.resources.getDrawable(R.drawable.ic_plus_outline))
        }else{
            holder.binding.ivRefresh.setImageDrawable(context.resources.getDrawable(R.drawable.ic_page_indicator))
            holder.binding.tvLocation.text =
                items[position].addresses[0].sTREETADDRESS
        }
        holder.binding.ivRefresh.setOnClickListener {
            if (items[position].addresses.isEmpty()){
                val intent = Intent(context, EditAddressActivity::class.java)
                intent.putExtra("address_title",items[position].iD)
                context.startActivity(intent)
            }else{
                PopupUtils.showEditLocationDialog(context,
                    items[position].iD ,
                    if (PreferenceManager.language == "en")  items[position].nAMEEN else items[position].nAMEAR,
                    items[position].addresses[0],{onEdit()},{onRemove(items[position].addresses[0])})
            }
        }

        if (selected == position){
            holder.binding.layoutBackground.background = context.resources.getDrawable(R.drawable.ic_rounded_background_category_selected_12)
        }else{
            holder.binding.layoutBackground.background = context.resources.getDrawable(R.drawable.ic_rounded_white_background_12)
        }

        holder.itemView.setOnClickListener {
            if (items[position].addresses.isNotEmpty()){
                setSelection(position)
                onSelect(items[position].addresses[0])
            }
        }
/*        holder.binding.tvAddressType.text = items[position].sTREETADDRESS*/
    }

    inner class AddressViewHolder(val binding: RecyclerItemLocationBinding) :
        RecyclerView.ViewHolder(binding.root)
}