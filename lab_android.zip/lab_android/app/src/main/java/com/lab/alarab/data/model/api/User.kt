package com.lab.alarab.data.model.api


import com.google.gson.annotations.SerializedName
import io.realm.RealmObject
import io.realm.annotations.PrimaryKey

open class User : RealmObject() {
    @SerializedName("ACCESS_TOKEN")
    var aCCESSTOKEN: String? = null

    @SerializedName("ADDRESS")
    var aDDRESS: String? = null

    @SerializedName("BUILDING_NO")
    var bUILDINGNO: String? = null

    @SerializedName("DATE_OF_BIRTH")
    var dATEOFBIRTH: String? = null

    @SerializedName("DIAL_CODE")
    var dIALCODE: String? = null

    @SerializedName("DIAL_CODE_ID")
    var dIALCODEID: String? = null

    @SerializedName("ELECTRONIC_ID")
    var eLECTRONICID: String? = null

    @SerializedName("EMAIL")
    var eMAIL: String? = null

    @SerializedName("END_USER_PHOTO_URI")
    var eNDUSERPHOTOURI: String? = null

    @SerializedName("FIRST_NAME")
    var fIRSTNAME: String? = null

    @SerializedName("FLOOR_NO")
    var fLOORNO: String? = null

    @SerializedName("FULL_NAME")
    var fULLNAME: String? = null

    @SerializedName("GCM_ID")
    var gCMID: String? = null

    @SerializedName("GENDER_ID")
    var gENDERID: Int = 0

    @PrimaryKey
    @SerializedName("ID")
    var iD: Long = 0

    @SerializedName("IDENTIFICATION")
    var iDENTIFICATION: String? = null

    @SerializedName("IDENTIFICATION_TYPE")
    var iDENTIFICATIONTYPE: String? = null

    @SerializedName("INSURANCE_COMPANY_ID")
    var iNSURANCECOMPANYID: String? = null

    @SerializedName("INSURANCE_POLICY_NUMBER")
    var iNSURANCEPOLICYNUMBER: String? = null

    @SerializedName("LANGUAGE")
    var lANGUAGE: String? = null

    @SerializedName("LAST_NAME")
    var lASTNAME: String? = null

    @SerializedName("LATITUDE")
    var lATITUDE: String? = null

    @SerializedName("LONGITUDE")
    var lONGITUDE: String? = null

    @SerializedName("MOBILE_NUMBER")
    var mOBILENUMBER: String? = null

    @SerializedName("NATIONALITY")
    var nATIONALITY: String? = null

    @SerializedName("NATIONALITY_ID")
    var nATIONALITYID: Int = 0

    @SerializedName("NEAREST")
    var nEAREST: String? = null

    @SerializedName("RESET_PASSWORD_FLAG")
    var rESETPASSWORDFLAG: String? = null

    @SerializedName("SIGN_UP_DATE")
    var sIGNUPDATE: String? = null

    @SerializedName("STATUS_ID")
    var sTATUSID: Int = 0

    @SerializedName("SYSTEM_MODULE_ID")
    var sYSTEMMODULEID: String? = null

    @SerializedName("TOKEN")
    var tOKEN: String? = null
}