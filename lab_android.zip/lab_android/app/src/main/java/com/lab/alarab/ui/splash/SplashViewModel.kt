package com.lab.alarab.ui.splash

import com.lab.alarab.base.BaseViewModel

class SplashViewModel : BaseViewModel() {

}