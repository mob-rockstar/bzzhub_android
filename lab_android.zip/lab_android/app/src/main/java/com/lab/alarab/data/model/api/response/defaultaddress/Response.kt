package com.lab.alarab.data.model.api.response.defaultaddress


import com.google.gson.annotations.SerializedName

data class Response(
    var address: Address
)