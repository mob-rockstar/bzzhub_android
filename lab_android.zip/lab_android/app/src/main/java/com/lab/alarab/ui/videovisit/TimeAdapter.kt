package com.lab.alarab.ui.videovisit

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.lab.alarab.R
import com.lab.alarab.base.BaseRecyclerViewAdapter
import com.lab.alarab.data.model.api.response.timeslot.Time
import com.lab.alarab.databinding.RecyclerItemDeliveryTimeBinding

class TimeAdapter : BaseRecyclerViewAdapter<Time, RecyclerItemDeliveryTimeBinding>() {

    override val layoutId: Int
        get() = R.layout.recycler_item_delivery_time

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return TimeViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as TimeViewHolder
        val context =holder.binding.root.context

        holder.binding.tvTime.text =
            "${com.lab.alarab.utils.DateUtils.getOrderTime(items[position].fROMTIME)}"

    }

    inner class TimeViewHolder(val binding: RecyclerItemDeliveryTimeBinding) :
        RecyclerView.ViewHolder(binding.root)
}