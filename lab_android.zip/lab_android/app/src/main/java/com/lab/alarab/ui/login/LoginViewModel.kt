package com.lab.alarab.ui.login

import com.lab.alarab.base.BaseViewModel
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.model.api.response.FlagListResponse
import com.lab.alarab.data.model.api.response.SignInResponse
import com.lab.alarab.data.model.api.response.SinUpResponse
import com.lab.alarab.data.model.api.response.VerifyMobileResponse
import com.lab.alarab.data.remote.APIManager
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class LoginViewModel : BaseViewModel() {

    var strMobile = ""
    var strCountryCode = ""

    // API to verify Mobile
    fun verifyMobileNumber(
        handleResponse: HandleResponse<VerifyMobileResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.verifyMobileNo(strCountryCode, strMobile)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

    // API to signin with OTP
    fun signInWithOTP(otp: String, handleResponse: HandleResponse<SignInResponse>) {
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.signInWithOTP(strCountryCode, strMobile, otp)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

    fun signUp(
        countryCode: String,
        mobile: String,
        nationality: String,
        genderId: Int,
        birthYear: String,
        birthMonth: String,
        birthDay: String,
        firstName: String,
        lastName: String,
        handleResponse: HandleResponse<SinUpResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.addAll(
            APIManager.signUpUser(countryCode,mobile,nationality,genderId,birthYear,birthMonth,birthDay,firstName,lastName)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                )
        )
    }

    // API to get Flag List
    fun getFlagList(
        handleResponse: HandleResponse<FlagListResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.addAll(
            APIManager.getFlagList()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }
}