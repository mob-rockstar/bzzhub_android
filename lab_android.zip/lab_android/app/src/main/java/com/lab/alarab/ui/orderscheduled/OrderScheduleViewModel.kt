package com.lab.alarab.ui.orderscheduled

import com.lab.alarab.base.BaseViewModel

class OrderScheduleViewModel  : BaseViewModel() {

}