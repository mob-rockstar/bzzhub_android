package com.lab.alarab.ui.pickup

import com.google.gson.JsonObject
import com.lab.alarab.base.BaseViewModel
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.remote.APIManager
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class PickUpViewModel : BaseViewModel(){
    fun getGoogleAddress(
        latitude: Double,
        longitude: Double,
        handleResponse: HandleResponse<JsonObject>
    ) {
        compositeDisposable.add(
            APIManager.getGoogleAddress(latitude, longitude)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

}