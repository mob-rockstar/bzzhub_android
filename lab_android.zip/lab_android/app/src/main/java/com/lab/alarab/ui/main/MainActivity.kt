package com.lab.alarab.ui.main

import android.os.Bundle
import android.util.Log
import android.view.View.GONE
import android.view.View.VISIBLE
import com.cometchat.pro.core.CometChat
import com.cometchat.pro.exceptions.CometChatException
import com.cometchat.pro.models.User
import com.lab.alarab.R
import com.lab.alarab.base.BaseActivity
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.databinding.ActivityMainBinding
import com.lab.alarab.ui.main.home.MainFragment
import com.lab.alarab.ui.main.result.HomeResultFragment
import com.lab.alarab.ui.main.tracking.HomeTrackingFragment
import com.lab.alarab.utils.AppConstants
import com.lab.alarab.utils.AppConstants.CHAT_AUTH_KEY
import com.lab.alarab.utils.MessageEvent
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import timber.log.Timber
import javax.inject.Inject

class MainActivity : BaseActivity<ActivityMainBinding?, MainViewModel>() ,
    HasAndroidInjector {

    override val layoutId: Int
        get() = R.layout.activity_main

    override val viewModel: MainViewModel
        get() {
            return getViewModel(MainViewModel::class.java)
        }

    var currentTab = 1

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        EventBus.getDefault().register(this)

        extractArguments()

        if (PreferenceManager.userData != null && PreferenceManager.currentUserId != null){
            val authKey = CHAT_AUTH_KEY // Replace with your App Auth Key
            val user = User()
            user.uid = PreferenceManager.currentUserId.toString() // Replace with the UID for the user to be created
            user.name = PreferenceManager.currentUserFirstName // Replace with the name of the user

            CometChat.createUser(user, authKey, object : CometChat.CallbackListener<User>() {
                override fun onSuccess(user: User) {
                    val UID:String="user1" // Replace with the UID of the user to login
                    val authKey:String="AUTH_KEY" // Replace with your App Auth Key

                    if (CometChat.getLoggedInUser() == null) {
                        CometChat.login(UID,authKey, object : CometChat.CallbackListener<User>() {
                            override fun onSuccess(p0: User?) {
                                Log.d("CREATE_USER", "Login Successful : " + p0?.toString()!!)
                            }

                            override fun onError(p0: CometChatException?) {
                                Log.d("CREATE_USER", "Login failed with exception: " +  p0?.message!!)
                            }

                        })
                    }else{
                        // User already logged in
                    }                }

                override fun onError(e: CometChatException) {
                    val UID:String=PreferenceManager.currentUserId.toString()// Replace with the UID of the user to login
                    val authKey:String=CHAT_AUTH_KEY // Replace with your App Auth Key

                    if (CometChat.getLoggedInUser() == null) {
                        CometChat.login(UID,authKey, object : CometChat.CallbackListener<User>() {
                            override fun onSuccess(p0: User?) {
                                Log.d("CREATE_USER", "Login Successful : " + p0?.toString())
                            }

                            override fun onError(p0: CometChatException?) {
                                Log.d("CREATE_USER", "Login failed with exception: " +  p0?.message)
                            }

                        })
                    }else{
                        // User already logged in
                    }                }
            })

        }

        when (currentTab) {
            1 -> {
                replaceFragmentDirectly(R.id.frameLayout,MainFragment())
                viewDataBinding?.ivBackgroundHome?.visibility = VISIBLE
                viewDataBinding?.ivBackgroundResult?.visibility = GONE
                viewDataBinding?.ivBackgroundTracking?.visibility = GONE            }
            2 -> {
                replaceFragmentDirectly(R.id.frameLayout,HomeTrackingFragment())
                viewDataBinding?.ivBackgroundHome?.visibility = GONE
                viewDataBinding?.ivBackgroundResult?.visibility = GONE
                viewDataBinding?.ivBackgroundTracking?.visibility = VISIBLE            }
            3 -> {
                replaceFragmentDirectly(R.id.frameLayout,HomeResultFragment())
                viewDataBinding?.ivBackgroundHome?.visibility = GONE
                viewDataBinding?.ivBackgroundResult?.visibility = VISIBLE
                viewDataBinding?.ivBackgroundTracking?.visibility = GONE
            }
        }


        PreferenceManager.currentUserLoggedInMode = PreferenceManager.LoggedInMode.LOGGED_IN_MODE_SERVER

        initClickListeners()
    }

    private fun extractArguments(){
         currentTab = intent.getIntExtra("current_tab",1)
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)

    }

    private fun initClickListeners(){
        viewDataBinding?.layoutHome?.setOnClickListener {
            if (currentTab != 1){
                replaceFragmentDirectly(R.id.frameLayout,MainFragment())
                viewDataBinding?.ivBackgroundHome?.visibility = VISIBLE
                viewDataBinding?.ivBackgroundResult?.visibility = GONE
                viewDataBinding?.ivBackgroundTracking?.visibility = GONE
            }

            currentTab = 1
        }

        viewDataBinding?.layoutTracking?.setOnClickListener {
            if (currentTab != 2){
                replaceFragmentDirectly(R.id.frameLayout,HomeTrackingFragment())
                viewDataBinding?.ivBackgroundHome?.visibility = GONE
                viewDataBinding?.ivBackgroundResult?.visibility = GONE
                viewDataBinding?.ivBackgroundTracking?.visibility = VISIBLE
            }
            currentTab = 2
        }

        viewDataBinding?.layoutResult?.setOnClickListener {
            if (currentTab != 3){
                replaceFragmentDirectly(R.id.frameLayout,HomeResultFragment())
                viewDataBinding?.ivBackgroundHome?.visibility = GONE
                viewDataBinding?.ivBackgroundResult?.visibility = VISIBLE
                viewDataBinding?.ivBackgroundTracking?.visibility = GONE
            }

            currentTab = 3
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        when (event.message) {
            AppConstants.MESSAGE_GO_ORDER -> {
                viewDataBinding?.layoutTracking?.performClick()
                // If received broadcast message 'profile_changed', reload user information
            }
            AppConstants.MESSAGE_GO_RESULT -> {
                viewDataBinding?.layoutResult?.performClick()
                // If received broadcast message 'profile_changed', reload user information
            }
        }
    }
}