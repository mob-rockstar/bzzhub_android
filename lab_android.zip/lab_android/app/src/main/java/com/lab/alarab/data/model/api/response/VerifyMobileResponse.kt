package com.lab.alarab.data.model.api.response


import com.google.gson.annotations.SerializedName

data class VerifyMobileResponse(
    var httpStatus: Int,
    var success: Boolean,
    var timestamp: Long
)