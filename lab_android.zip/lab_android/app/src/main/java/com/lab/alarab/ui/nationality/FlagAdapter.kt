package com.lab.alarab.ui.nationality

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.lab.alarab.R
import com.lab.alarab.base.BaseRecyclerViewAdapter
import com.lab.alarab.data.model.api.Flag
import com.lab.alarab.data.model.api.response.flag.FlagObject
import com.lab.alarab.databinding.ItemCountryBinding

class FlagAdapter : BaseRecyclerViewAdapter<FlagObject, ItemCountryBinding>() {

    override val layoutId: Int
        get() = R.layout.item_country

    var selectedListener: SelectedListener ?= null

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return FlagViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as FlagViewHolder

        holder.binding.tvCountry.text = items[position].name

        holder.itemView.setOnClickListener {
            selectedListener?.onSelected(items[position])
        }
    }

    interface SelectedListener {
        fun onSelected(flag: FlagObject)
    }

    inner class FlagViewHolder(val binding: ItemCountryBinding) :
        RecyclerView.ViewHolder(binding.root)
}