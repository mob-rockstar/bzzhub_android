package com.lab.alarab.ui.choosepayment

import com.lab.alarab.base.BaseViewModel

class ChoosePaymentViewModel : BaseViewModel() {

}