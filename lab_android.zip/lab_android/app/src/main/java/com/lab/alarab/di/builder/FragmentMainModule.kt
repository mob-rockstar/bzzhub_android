package com.lab.alarab.di.builder

import com.lab.alarab.ui.main.home.MainFragment
import com.lab.alarab.ui.main.notification.NotificationFragment
import com.lab.alarab.ui.main.result.HomeResultFragment
import com.lab.alarab.ui.main.tracking.HomeTrackingFragment
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class FragmentMainModule {
    @ContributesAndroidInjector
    abstract fun contributeMainFragment(): MainFragment

    @ContributesAndroidInjector
    abstract fun contributeHomeTrackingFragment(): HomeTrackingFragment

    @ContributesAndroidInjector
    abstract fun contributeHomeResultFragment(): HomeResultFragment

    @ContributesAndroidInjector
    abstract fun contributeNotificationFragment(): NotificationFragment
}