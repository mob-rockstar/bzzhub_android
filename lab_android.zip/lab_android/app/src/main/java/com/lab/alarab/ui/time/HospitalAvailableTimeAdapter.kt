package com.lab.alarab.ui.time

import android.content.Intent
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.lab.alarab.R
import com.lab.alarab.base.BaseRecyclerViewAdapter
import com.lab.alarab.data.model.api.response.availabletimeslot.AvailableTime
import com.lab.alarab.data.model.api.response.availabletimeslot.Hospital
import com.lab.alarab.databinding.RecyclerItemAvailableTimeListBinding
import com.lab.alarab.ui.payment.PaymentActivity
import com.lab.alarab.utils.AppConstants

class HospitalAvailableTimeAdapter :
    BaseRecyclerViewAdapter<AvailableTime, RecyclerItemAvailableTimeListBinding>() {

    override val layoutId: Int
        get() = R.layout.recycler_item_available_time_list

    var parentHospital: Hospital ?= null

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return HospitalViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as HospitalViewHolder
        val context =holder.binding.root.context


        holder.binding.tvTime.text = items[position].FROM_TIME ?: ""

        holder.binding.tvTime.setOnClickListener {
            AppConstants.hospitalId = items[position].HOSPITAL_ID
            AppConstants.selectedTimeId = items[position].ID
            (context as AvailableTimeActivity).addToCartWithCalculations()
        }
    }

    inner class HospitalViewHolder(val binding: RecyclerItemAvailableTimeListBinding) :
        RecyclerView.ViewHolder(binding.root)
}