package com.lab.alarab.data.model.api.response.orderdetail


import com.google.gson.annotations.SerializedName

data class OrderDetailResponse(
    var errorMessage: String?,
    var httpStatus: Int,
    var response: Response,
    var success: Boolean,
    var timestamp: Int
)