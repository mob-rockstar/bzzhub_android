package com.lab.alarab.ui.pickup

import android.content.Context
import android.content.Intent
import android.location.Geocoder
import android.os.Bundle
import android.view.View.GONE
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.gson.JsonObject
import com.lab.alarab.R
import com.lab.alarab.base.BaseActivity
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.model.api.response.ErrorResponse
import com.lab.alarab.data.model.api.response.addressList.Addresse
import com.lab.alarab.databinding.ActivityPickUpAddressBinding
import com.lab.alarab.utils.AppConstants
import com.lab.alarab.utils.GPSTrackService
import com.lab.alarab.utils.NetworkUtils
import timber.log.Timber
import java.io.IOException
import java.util.*

class PickUpAddressActivity : BaseActivity<ActivityPickUpAddressBinding?, PickUpViewModel>() {

    override val layoutId: Int
        get() = R.layout.activity_pick_up_address

    override val viewModel: PickUpViewModel
        get() = PickUpViewModel()

    private lateinit var userMap: GoogleMap

    var address: Addresse? = null
    var lat : Double = 0.0
    var lng : Double = 0.0
    var gpsTracker: GPSTrackService? = null
    var addressString : String? =  ""
    var latLng = LatLng(0.0, 0.0)
    var marker: MarkerOptions? =null
    var cityName = "Riyad"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        gpsTracker = GPSTrackService(this)
        viewDataBinding?.toolbar?.tvTitle?.text =  resources.getString(R.string.str_delivery_adderss)

        address = intent.getSerializableExtra("address") as Addresse?

        if (address != null){
            if (address?.lATITUDE != null && address?.lATITUDE!!.isNotEmpty()) lat = address?.lATITUDE?.toDouble()!!
            if (address?.lONGITUDE != null && address?.lONGITUDE!!.isNotEmpty()) lng  = address?.lONGITUDE?.toDouble()!!
        }

        if (lat == 0.0) lat = gpsTracker!!.latitude
        if (lng == 0.0) lng = gpsTracker!!.longitude

        setAddress(LatLng(lat, lng))

        viewDataBinding?.toolbar?.ivRemove?.visibility = GONE

        initMap()
        initListeners()
    }

    private fun initMap(){
        // user address
        val mapFragment =
            supportFragmentManager.findFragmentById(R.id.fragment_map) as SupportMapFragment
        mapFragment.view?.isClickable = false
        mapFragment.getMapAsync { map ->
            map.uiSettings.isMapToolbarEnabled = false
            val userLatLng = LatLng(
                if (address != null && lat != 0.0) lat else gpsTracker!!.latitude,
                if (address != null && lng != 0.0) lat else gpsTracker!!.longitude)
            map.moveCamera(CameraUpdateFactory.newLatLng(userLatLng))

            /*marker = MarkerOptions().position(LatLng( if (address != null && lat != 0.0) lat else gpsTracker!!.latitude,
                if (address != null && lng != 0.0) lat else gpsTracker!!.longitude))
                .title("")
            map.addMarker(marker)*/

            map?.setOnCameraMoveListener {
                val ll = map!!.cameraPosition.target
                this.latLng = ll
            }

            map?.setOnCameraIdleListener {
                val ll = map.cameraPosition.target
                latLng = ll
                lat = latLng.latitude
                lng = latLng.longitude
                this.setAddress(ll)
            }
            userMap = map
        }
    }

    private fun setAddress(latLng: LatLng) {
        try {
            addressString = getAddressName(this@PickUpAddressActivity, latLng.latitude, latLng.longitude)
            viewDataBinding?.tvStreetAddress?.text = addressString
            viewDataBinding?.tvAddress?.text = cityName
        } catch (e: java.lang.Exception) {
            getGoogleAddress(latLng.latitude, latLng.longitude)
            e.printStackTrace()
        }
    }

    private fun getAddressName(context: Context, latitude: Double, longitude: Double): String? {
        val geocoder = Geocoder(context, Locale.ENGLISH)
        var addresses: List<android.location.Address>? = null
        var addressName: String? = "Riyadh"
        try {
            addresses = geocoder.getFromLocation(latitude, longitude, 1)
            addressName = addresses.first().getAddressLine(0)
            cityName = addresses.first().locality
            viewDataBinding?.tvAddress?.text = cityName
        } catch (ignored: IOException) {
            Timber.tag("LocationMap -> parse").e(ignored)
            getGoogleAddress(latitude, longitude)
        }
        return addressName
    }


    private fun getGoogleAddress(latitude: Double, longitude: Double) {
        viewModel.getGoogleAddress(latitude, longitude, object : HandleResponse<JsonObject> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(this@PickUpAddressActivity)) {
                    this@PickUpAddressActivity.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    this@PickUpAddressActivity.onError(
                        error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                    )
                }
            }

            override fun handleSuccessRespons(successResponse: JsonObject) {
                addressString = try {
                    successResponse.getAsJsonArray("results")[1].asJsonObject["formatted_address"].toString()
                        .replace("\"", "")
                } catch (e: java.lang.Exception) {
                    "Riyadh"
                }
                viewDataBinding?.tvStreetAddress?.text = addressString
            }
        })
    }


    private fun initListeners(){
        viewDataBinding?.tvSaveAddress?.setOnClickListener {
            val returnIntent = Intent()
            val bundle = Bundle()
            bundle.putString("city", cityName)
            bundle.putString("street",addressString)
            bundle.putDouble("lat",lat)
            bundle.putDouble("lng", lng)
            returnIntent.putExtras(bundle)
            setResult(RESULT_OK, returnIntent)
            finish()
        }

        viewDataBinding?.toolbar?.ivBack?.setOnClickListener { finish() }
    }
}