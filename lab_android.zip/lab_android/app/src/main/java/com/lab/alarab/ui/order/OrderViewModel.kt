package com.lab.alarab.ui.order

import com.lab.alarab.base.BaseViewModel
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.model.api.response.cart.CartResponse
import com.lab.alarab.data.model.api.response.landing.LandingPageResponse
import com.lab.alarab.data.model.api.response.removewithcalculation.RemoveWithCalculationResponse
import com.lab.alarab.data.remote.APIManager
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class OrderViewModel  : BaseViewModel() {

    fun getCartList(
        handleResponse: HandleResponse<CartResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.addAll(
            APIManager.viewCart()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

    fun removeCart(
        packageId: Int,
        handleResponse: HandleResponse<RemoveWithCalculationResponse>){
        setIsLoading(true)
        compositeDisposable.addAll(
            APIManager.removeCartWithCalculations(packageId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }
}