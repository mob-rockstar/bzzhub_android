package com.lab.alarab.utils

import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

object DateUtils {

    fun getCurrentDateAsString() : String{
        val currentTime: Date = Calendar.getInstance().time

        val format = SimpleDateFormat("EEE, dd, MMM")
        return format.format(currentTime)
    }

    fun getNextDateAsString( strDate: String) : String {
        var date : Date? = null
        val format =
            SimpleDateFormat("EEE, dd, MMM")
        try {
             date = format.parse(strDate)
        } catch (e: ParseException) {
            e.printStackTrace()
        }

        val cal = Calendar.getInstance()
        cal.time = date
        cal.add(Calendar.DAY_OF_MONTH, 1) //Adds a day
        return format.format(cal.time)
    }

    fun getNextDateAsStringForAPI( strDate: String) : String {
        var date : Date? = null
        val format =
            SimpleDateFormat("yyyy-MM-dd")
        try {
            date = format.parse(strDate)
        } catch (e: ParseException) {
            e.printStackTrace()
        }

        val cal = Calendar.getInstance()
        cal.time = date
        cal.add(Calendar.DAY_OF_MONTH, 1) //Adds a day
        return format.format(cal.time)
    }

    fun getPreviewsDayFromString( strDate: String) : String {
        var date : Date? = null
        val format =
            SimpleDateFormat("EEE, dd, MMM")
        try {
            date = format.parse(strDate)
        } catch (e: ParseException) {
            e.printStackTrace()
        }

        val cal = Calendar.getInstance()
        cal.time = date
        cal.add(Calendar.DAY_OF_MONTH, -1) //Adds a day
        return format.format(cal.time)
    }

    fun getPreviewsDayFromStringForAPI( strDate: String) : String {
        var date : Date? = null
        val format =
            SimpleDateFormat("yyyy-MM-dd")
        try {
            date = format.parse(strDate)
        } catch (e: ParseException) {
            e.printStackTrace()
        }

        val cal = Calendar.getInstance()
        cal.time = date
        cal.add(Calendar.DAY_OF_MONTH, -1) //Adds a day
        return format.format(cal.time)
    }

    // Change date format as MMMM dd yyyy
    fun getYear(inputDateStr: String): String {
        val inputFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val outputFormat = SimpleDateFormat("yyyy", Locale.US)
        var date: Date? = null
        try {
            date = inputFormat.parse(inputDateStr)
        } catch (e: ParseException) {
            e.printStackTrace()
        }

        return outputFormat.format(date)
    }

    // Change date format as MMMM dd yyyy
    fun getMonth(inputDateStr: String): String {
        val inputFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val outputFormat = SimpleDateFormat("MM", Locale.US)
        var date: Date? = null
        try {
            date = inputFormat.parse(inputDateStr)
        } catch (e: ParseException) {
            e.printStackTrace()
        }

        return outputFormat.format(date)
    }

    // Change date format as MMMM dd yyyy
    fun getDay(inputDateStr: String): String {
        val inputFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val outputFormat = SimpleDateFormat("d", Locale.US)
        var date: Date? = null
        try {
            date = inputFormat.parse(inputDateStr)
        } catch (e: ParseException) {
            e.printStackTrace()
        }

        return outputFormat.format(date!!)
    }

    // Change date format as MMMM dd yyyy
    fun getOrderDate(inputDateStr: String): String {
        val inputFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val outputFormat = SimpleDateFormat("MMM dd", Locale.US)
        var date: Date? = null
        try {
            date = inputFormat.parse(inputDateStr)
        } catch (e: ParseException) {
            e.printStackTrace()
        }

        return outputFormat.format(date!!)
    }

    // Change date format as MMMM dd yyyy
    fun getOrderTime(inputDateStr: String): String {
        val inputFormat = SimpleDateFormat("HH:mm:ss", Locale.US)
        val outputFormat = SimpleDateFormat("HH:mm a", Locale.US)
        var date: Date? = null
        try {
            date = inputFormat.parse(inputDateStr)
        } catch (e: ParseException) {
            e.printStackTrace()
        }

        return outputFormat.format(date!!)
    }

    fun convertDate(inputDateStr: String) : String{
        val inputFormat = SimpleDateFormat("EEE, dd, MMM", Locale.US)
        val outputFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        var date: Date? = null
        try {
            date = inputFormat.parse(inputDateStr)
        } catch (e: ParseException) {
            e.printStackTrace()
        }

        return outputFormat.format(date)
    }
}