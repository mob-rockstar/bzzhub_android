package com.lab.alarab.base

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.IdRes
import androidx.annotation.LayoutRes
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProviders
import com.lab.alarab.R
import com.lab.alarab.base.navigator.Navigator
import com.lab.alarab.di.Injectable
import com.lab.alarab.di.factory.ViewModelProviderFactory
import com.lab.alarab.utils.PopupUtils
import dagger.android.support.AndroidSupportInjection
import javax.inject.Inject


abstract class BaseDialogFragment<T : ViewDataBinding?, V : BaseViewModel?> : DialogFragment(),
    Injectable {

    @Inject
    lateinit var viewModelFactory: ViewModelProviderFactory

    @Inject
    lateinit var navigator: Navigator

    lateinit var baseActivity: BaseActivity<*, *>
        private set

    private var mRootView: View? = null
    var viewDataBinding: T? = null
        private set
    private var mViewModel: V? = null

    /**
     * Override for set binding variable
     *
     * @return variable id
     */
    private val bindingVariable: Int = 0

    /**
     * @return layout resource id
     */
    @get:LayoutRes
    abstract val layoutId: Int

    /**
     * Override for set view model
     *
     * @return view model instance
     */
    abstract val viewModel: V

    var progressView: View? = null


    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is BaseActivity<*, *>) {
            val activity = context
            baseActivity = activity
            activity.onFragmentAttached()
        }
    }

    protected open fun <T : ViewModel?> getViewModel(cls: java.lang.Class<T>): T {
        return ViewModelProviders.of(this, viewModelFactory).get(cls)
    }

    protected open fun <T : ViewModel?> getViewModel(
        fregmentActivity: FragmentActivity,
        cls: java.lang.Class<T>
    ): T {
        return ViewModelProviders.of(fregmentActivity, viewModelFactory).get(cls)
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        performDependencyInjection()
        super.onCreate(savedInstanceState)
        mViewModel = viewModel
        setHasOptionsMenu(false)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        viewDataBinding = DataBindingUtil.inflate<T>(inflater, layoutId, container, false)
        mRootView = viewDataBinding!!.root
        return mRootView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewDataBinding!!.setVariable(bindingVariable, mViewModel)
        viewDataBinding!!.lifecycleOwner = this
        viewDataBinding!!.executePendingBindings()
        mViewModel?.isLoading!!.observe(baseActivity, Observer { consumeResponse(it) })
    }

    open fun consumeResponse(o: Boolean) {
        if (o) {
            showLoading()
        } else {
            hideLoading()
        }
    }

    fun showLoading() {
        if (progressView != null) {
            progressView!!.visibility = View.VISIBLE
        }
    }

    fun hideLoading() {
        if (progressView != null) {
            progressView!!.visibility = View.GONE
        }
    }

    val isNetworkConnected: Boolean
        get() = baseActivity.isNetworkConnected


    private fun performDependencyInjection() {
        AndroidSupportInjection.inject(this)
    }

    interface Callback {
        fun onFragmentAttached()
        fun onFragmentDetached(tag: String?)
    }


    private fun showSuccessCaseFor(successView: View, errorView: View) {
        successView.visibility = View.VISIBLE
        errorView.visibility = View.GONE
    }

    private fun showErrorCaseFor(successView: View, errorView: View) {
        successView.visibility = View.GONE
        errorView.visibility = View.VISIBLE
    }

    fun onError(message: String) {
        PopupUtils.showAlertDialog(baseActivity, getString(R.string.str_error), message)
    }

    fun startActivity(activityClass: Class<out Activity>) {
        navigator.startActivity(baseActivity, activityClass)
    }

    fun finishActivity() {
        navigator.finishActivity(baseActivity)
    }

    fun finishActivityWithResult(resultCode: Int, resultIntentFun: (Intent.() -> Unit)? = null) {
        navigator.finishActivityWithResult(baseActivity, resultCode, resultIntentFun)
    }

    fun addFragment(@IdRes containerId: Int, fragment: Fragment) {
        navigator.addFragmentAndAddToBackStack(baseActivity, containerId, fragment)
    }

    fun replaceFragment(@IdRes containerId: Int, fragment: Fragment) {
        navigator.replaceFragmentAndAddToBackStack(baseActivity, containerId, fragment)
    }

    fun replaceFragmentDirectly(@IdRes containerId: Int, fragment: Fragment) {
        navigator.replaceFragment(baseActivity, containerId, fragment)
    }

    fun popBackStack() {
        navigator.popFragmentBackStackImmediate(baseActivity)
    }
}