package com.lab.alarab.ui.main.result

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.cometchat.pro.constants.CometChatConstants
import com.cometchat.pro.core.Call
import com.cometchat.pro.core.CometChat
import com.cometchat.pro.exceptions.CometChatException
import com.cometchat.pro.models.User
import com.google.android.material.snackbar.Snackbar
import com.lab.alarab.R
import com.lab.alarab.base.BaseInputFragment
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.data.model.api.response.ErrorResponse
import com.lab.alarab.data.model.api.response.getresult.GetResultResponse
import com.lab.alarab.databinding.FragmentHomeResultBinding
import com.lab.alarab.di.Injectable
import com.lab.alarab.ui.main.MainViewModel
import com.lab.alarab.ui.order.OrderActivity
import com.lab.alarab.ui.resultexplanation.ResultExplanationActivity
import com.lab.alarab.utils.AppConstants
import com.lab.alarab.utils.AppConstants.CHAT_SUPPORT_ID
import com.lab.alarab.utils.MessageEvent
import com.lab.alarab.utils.NetworkUtils
import constant.StringContract
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import org.json.JSONObject
import screen.CometChatCallActivity
import utils.Utils

class HomeResultFragment :
    BaseInputFragment<FragmentHomeResultBinding?, MainViewModel>(), Injectable {

    override val layoutId: Int
        get() = R.layout.fragment_home_result

    override val viewModel: MainViewModel
        get() {
            return getViewModel(baseActivity, MainViewModel::class.java)
        }

    var resultAdapter: ResultAdapter = ResultAdapter(  {response->
        openResultScreen(response)}){
            onCall()
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        EventBus.getDefault().register(this)

        viewDataBinding?.layoutCart?.setOnClickListener {
            startActivity(Intent(activity, OrderActivity::class.java))
        }

        initRecyclerView()

        getResults()
        initCartCount()
        viewDataBinding?.layoutHelp?.setOnClickListener {
            val i = Intent(Intent.ACTION_SEND)
            i.putExtra(Intent.EXTRA_EMAIL, arrayOf<String>("support@lab.com"))
            i.putExtra(Intent.EXTRA_SUBJECT, "Hello")
            i.putExtra(Intent.EXTRA_TEXT,"" )
            startActivity(Intent.createChooser(i, "Send email"))
        }
    }

    private fun onCall(){
        val call = Call(AppConstants.CHAT_SUPPORT_ID!!, CometChatConstants.RECEIVER_TYPE_USER, CometChatConstants.CALL_TYPE_VIDEO)
        val jsonObject = JSONObject()
        try {
            jsonObject.put("bookingId", 6)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        call.metadata = jsonObject
        CometChat.initiateCall(call, object : CometChat.CallbackListener<Call>() {
            override fun onSuccess(call: Call) {
                Utils.startCallIntent(context!!, call.callReceiver as User, call.type, true, call.sessionId)
            }

            override fun onError(e: CometChatException) {
                Snackbar.make((context as Activity).window.decorView.rootView, context!!.getResources().getString(
                    com.cometchat.pro.uikit.R.string.call_initiate_error) + ":" + e.message, Snackbar.LENGTH_LONG).show()
            }
        })
    }

    private fun initRecyclerView(){
        viewDataBinding?.recyclerView?.layoutManager = LinearLayoutManager(baseActivity)
        viewDataBinding?.recyclerView?.adapter = resultAdapter
    }

    private fun openResultScreen(item:  com.lab.alarab.data.model.api.response.getresult.Response){
        val intent = Intent(baseActivity, ResultExplanationActivity::class.java)
        intent.putExtra("document_url",item.rESULTURL)
        intent.putExtra("order_id", item.eNDUSERLABORDERID)
        startActivity(intent)
    }

    private fun getResults(){
        viewModel.getResults(object : HandleResponse<GetResultResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(baseActivity)) {
                    this@HomeResultFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    this@HomeResultFragment.onError(
                        error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                    )
                }
            }

            override fun handleSuccessRespons(successResponse: GetResultResponse) {
                if (successResponse.success && successResponse.httpStatus == 200){
                    resultAdapter.setItems(successResponse.response)
                }else{
                    this@HomeResultFragment.onError(
                        AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                }
            }
        })
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        when (event.message) {
            AppConstants.MESSAGE_CART_CHANGED -> {
                // If received broadcast message 'profile_changed', reload user information
                initCartCount()
            }
        }
    }

    private fun initCartCount(){
        viewDataBinding?.layoutCartCount?.visibility =
            if (PreferenceManager.userCartCount == 0) View.GONE
            else View.VISIBLE

        viewDataBinding?.tvCartCount?.text = PreferenceManager.userCartCount.toString()
    }
}