package com.lab.alarab.data.model.api.response.landing


import com.google.gson.annotations.SerializedName

data class DefaultSlider(
    @SerializedName("ID")
    var iD: Int,
    @SerializedName("IMAGE_PATH")
    var iMAGEPATH: String
)