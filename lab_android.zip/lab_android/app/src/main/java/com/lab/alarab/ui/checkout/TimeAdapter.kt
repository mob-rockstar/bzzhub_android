package com.lab.alarab.ui.checkout

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.lab.alarab.R
import com.lab.alarab.base.BaseRecyclerViewAdapter
import com.lab.alarab.data.model.api.response.timeslot.Time
import com.lab.alarab.databinding.RecyclerItemDeliveryTimeBinding

class TimeAdapter(private val onTimeSelect: (timeID: Int) -> Unit) : BaseRecyclerViewAdapter<Time, RecyclerItemDeliveryTimeBinding>() {

    override val layoutId: Int
        get() = R.layout.recycler_item_delivery_time

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return TimeViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as TimeViewHolder
        val context =holder.binding.root.context

        holder.binding.tvTime.text =
            """${com.lab.alarab.utils.DateUtils.getOrderTime(items[position].fROMTIME)} - ${
                com.lab.alarab.utils.DateUtils.getOrderTime(items[position].tOTIME)
            }"""

        if (selected == position){
            holder.binding.tvTime.setTextColor(context.resources.getColor(R.color.colorAccent))
            holder.binding.tvTime.background = context.resources.getDrawable(R.drawable.ic_rounded_background_category_selected_4)
        }else{
            holder.binding.tvTime.setTextColor(context.resources.getColor(R.color.color_black_800))
            holder.binding.tvTime.background = null
        }

        holder.itemView.setOnClickListener {
            setSelection(position)
            onTimeSelect(items[position].iD)
        }

    }

    inner class TimeViewHolder(val binding: RecyclerItemDeliveryTimeBinding) :
        RecyclerView.ViewHolder(binding.root)
}