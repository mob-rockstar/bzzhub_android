package com.lab.alarab.utils

import android.content.Context
import android.net.ConnectivityManager
import android.os.AsyncTask
import androidx.appcompat.app.AlertDialog
import com.google.gson.Gson
import com.google.gson.TypeAdapter
import com.jakewharton.retrofit2.adapter.rxjava2.HttpException
import com.lab.alarab.data.model.api.response.ErrorResponse
import java.net.HttpURLConnection
import java.net.URL
import java.util.ArrayList


object NetworkUtils {
    interface OnConnectedListener {
        fun onConnected()
    }

    private val sListeners = ArrayList<OnConnectedListener>()
    private var isNetworkConnected = true
    private var noInternetDialog: AlertDialog? = null

    fun isNetworkConnected(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetwork = cm.activeNetworkInfo
        val connectivity = activeNetwork != null && activeNetwork.isConnectedOrConnecting
        if (connectivity) {
            return isNetworkConnected
        }
        return false
    }


    fun getThrowableError(t: Throwable): ErrorResponse? {
        ConnectivityTask().execute()

        if (t is HttpException) {
            val body = t.response().errorBody()
            val gson = Gson()
            val adapter: TypeAdapter<ErrorResponse> = gson.getAdapter(ErrorResponse::class.java)

            try {
                return adapter.fromJson(body!!.string())
            } catch (e: Exception) {
                e.printStackTrace()
            }
        } else {
            AppLogger.d("throwable ${t.message}")
            val errorResponse = ErrorResponse()
            errorResponse.message = t.message
            return errorResponse
        }
        return null
    }

    class ConnectivityTask : AsyncTask<Void, Void, Void>() {
        override fun doInBackground(vararg params: Void): Void? {
            try {
                val urlConnection: HttpURLConnection =
                    URL("https://clients3.google.com/generate_204").openConnection() as HttpURLConnection
                urlConnection.setRequestProperty("User-Agent", "Android")
                urlConnection.setRequestProperty("Connection", "close")
                urlConnection.connectTimeout = 1500
                urlConnection.connect()
                urlConnection.responseCode == 204 && urlConnection.contentLength == 0
                isNetworkConnected = true
            } catch (e: Exception) {
                e.printStackTrace()
                isNetworkConnected = false
            }
            return null
        }
    }

}