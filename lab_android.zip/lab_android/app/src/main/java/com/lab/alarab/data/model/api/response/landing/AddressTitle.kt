package com.lab.alarab.data.model.api.response.landing


import com.google.gson.annotations.SerializedName

data class AddressTitle(
    @SerializedName("ID")
    var iD: Int,
    @SerializedName("NAME_AR")
    var nAMEAR: String,
    @SerializedName("NAME_EN")
    var nAMEEN: String
)