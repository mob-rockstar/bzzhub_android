package com.lab.alarab.data.model.api.response


import com.google.gson.annotations.SerializedName

data class SimpleResponse(
    var errorMessage: String?,
    var httpStatus: Int,
    var response: String,
    var success: Boolean,
    var timestamp: Int
)