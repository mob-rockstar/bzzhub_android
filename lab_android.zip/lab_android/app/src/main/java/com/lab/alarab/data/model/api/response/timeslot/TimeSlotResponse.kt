package com.lab.alarab.data.model.api.response.timeslot


import com.google.gson.annotations.SerializedName

data class TimeSlotResponse(
    var errorMessage: String?,
    var httpStatus: Int,
    var response: Response,
    var success: Boolean,
    var timestamp: Int
)