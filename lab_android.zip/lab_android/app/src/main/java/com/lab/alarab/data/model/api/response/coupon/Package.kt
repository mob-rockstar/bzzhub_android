package com.lab.alarab.data.model.api.response.coupon


import com.google.gson.annotations.SerializedName

data class Package(
    @SerializedName("ACTIVE_STATUS")
    var aCTIVESTATUS: Int,
    @SerializedName("AGE")
    var aGE: Int,
    @SerializedName("BIRTH_DATE")
    var bIRTHDATE: String,
    @SerializedName("CART_PACKAGE_ID")
    var cARTPACKAGEID: Int,
    @SerializedName("CITY_ID")
    var cITYID: Any,
    @SerializedName("DESC_AR")
    var dESCAR: Any,
    @SerializedName("DESC_EN")
    var dESCEN: Any,
    @SerializedName("FASTING_REQUIRED")
    var fASTINGREQUIRED: Int,
    @SerializedName("FOLLOWER_RELATION_ID")
    var fOLLOWERRELATIONID: Any,
    @SerializedName("HOSPITAL_ID")
    var hOSPITALID: Any,
    @SerializedName("ID")
    var iD: Int,
    @SerializedName("LAB_CATEGORY_ID")
    var lABCATEGORYID: Int,
    @SerializedName("NAME")
    var nAME: String,
    @SerializedName("NAME_AR")
    var nAMEAR: String,
    @SerializedName("NAME_EN")
    var nAMEEN: String,
    @SerializedName("PRICE")
    var pRICE: Int,
    @SerializedName("RELATION_NAME_AR")
    var rELATIONNAMEAR: Any,
    @SerializedName("RELATION_NAME_EN")
    var rELATIONNAMEEN: Any,
    @SerializedName("TEST_TYPE")
    var tESTTYPE: Any
)