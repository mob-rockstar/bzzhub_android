package com.lab.alarab.ui.videovisit

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.DatePicker
import androidx.recyclerview.widget.GridLayoutManager
import com.google.android.gms.maps.GoogleMap
import com.lab.alarab.R
import com.lab.alarab.base.BaseActivity
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.data.model.api.response.ErrorResponse
import com.lab.alarab.data.model.api.response.resultdetail.ResultDetailResponse
import com.lab.alarab.data.model.api.response.timeslot.TimeSlotResponse
import com.lab.alarab.databinding.ActivityVideoVisitBinding
import com.lab.alarab.utils.AppConstants
import com.lab.alarab.utils.DateUtils
import com.lab.alarab.utils.NetworkUtils
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

class VideoVisitActivity : BaseActivity<ActivityVideoVisitBinding?, VideoVisitViewModel>() ,
    HasAndroidInjector {


    override val layoutId: Int
        get() = R.layout.activity_video_visit

    override val viewModel: VideoVisitViewModel
        get() {
            return getViewModel(VideoVisitViewModel::class.java)
        }

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    override fun androidInjector() = dispatchingAndroidInjector

    private var mDatePickerDialog: DatePickerDialog? = null
    private var strDate = ""
    private var orderId = 0
    private var strDateForAPI = ""

    private var morningAdapter: TimeAdapter = TimeAdapter()
    private var afternoonAdapter: TimeAdapter = TimeAdapter()
    private var nightAdapter: TimeAdapter = TimeAdapter()
    val apiDateFormat = SimpleDateFormat("yyyy-MM-dd")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        viewDataBinding?.toolbar?.tvTitle?.text = resources.getString(R.string.str_result_explanation)
        orderId = intent.getIntExtra("order_id", 0)
        strDate = SimpleDateFormat("EEE, dd, MMM").format(Date())
        strDateForAPI = apiDateFormat.format(Date())

        initDate()
        initListener()
        setDateTimeField()

        initRecyclerView()
        getResultDetails()
        getAvailableTimeSlot(strDateForAPI)
    }

    private fun initRecyclerView(){
        viewDataBinding?.recyclerViewMorning?.layoutManager = GridLayoutManager(this@VideoVisitActivity,3)
        viewDataBinding?.recyclerViewMorning?.adapter = morningAdapter

        morningAdapter.setSelection(-1)
        afternoonAdapter.setSelection(-1)
        nightAdapter.setSelection(-1)

        viewDataBinding?.recyclerViewAfternoon?.layoutManager = GridLayoutManager(this@VideoVisitActivity,3)
        viewDataBinding?.recyclerViewAfternoon?.adapter = afternoonAdapter

        viewDataBinding?.recyclerViewNight?.layoutManager = GridLayoutManager(this@VideoVisitActivity,3)
        viewDataBinding?.recyclerViewNight?.adapter = nightAdapter
    }


    private fun initListener(){
        viewDataBinding?.toolbar?.ivBack?.setOnClickListener {
            finish()
        }

        viewDataBinding?.ivNext?.setOnClickListener {
            viewDataBinding?.tvDate?.text = DateUtils.getNextDateAsString(viewDataBinding?.tvDate?.text.toString())
            strDate = viewDataBinding?.tvDate?.text.toString()
            strDateForAPI = DateUtils.getNextDateAsStringForAPI(strDateForAPI)
            getAvailableTimeSlot(strDateForAPI)
        }

        viewDataBinding?.ivBefore?.setOnClickListener {
            viewDataBinding?.tvDate?.text = DateUtils.getPreviewsDayFromString(viewDataBinding?.tvDate?.text.toString())
            strDate = viewDataBinding?.tvDate?.text.toString()
            strDateForAPI = DateUtils.getPreviewsDayFromString(strDateForAPI)
            getAvailableTimeSlot(strDateForAPI)
        }



        viewDataBinding?.tvDate?.setOnClickListener {
            mDatePickerDialog?.show()
        }
    }

    private fun initDate(){
        viewDataBinding?.tvDate?.text = DateUtils.getCurrentDateAsString()
    }

    private fun setDateTimeField() {
        val newCalendar = Calendar.getInstance()
        mDatePickerDialog = DatePickerDialog(
            this@VideoVisitActivity,
            R.style.styleDatePickerDialog,
            DatePickerDialog.OnDateSetListener { view: DatePicker?, year: Int, monthOfYear: Int, dayOfMonth: Int ->
                val newDate = Calendar.getInstance()
                newDate[year, monthOfYear] = dayOfMonth
                val formatDate =
                    SimpleDateFormat("EEE, dd, MMM")
                val startDate = newDate.time
                val fdate = formatDate.format(startDate)
                strDate = formatDate.format(startDate)
                strDateForAPI = apiDateFormat.format(startDate)
                getAvailableTimeSlot(strDateForAPI)
                viewDataBinding?.tvDate?.text = fdate
                //      enableNextButton()
            },
            newCalendar[Calendar.YEAR],
            newCalendar[Calendar.MONTH],
            newCalendar[Calendar.DAY_OF_MONTH]
        )
        val c = Calendar.getInstance()
        mDatePickerDialog!!.datePicker.minDate = c.timeInMillis
        mDatePickerDialog!!.setTitle("")
    }


    private fun getAvailableTimeSlot(date: String){
        viewModel.getAvailableTimeList(date,
            object : HandleResponse<TimeSlotResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (NetworkUtils.isNetworkConnected(this@VideoVisitActivity)) {
                        this@VideoVisitActivity.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        this@VideoVisitActivity.onError(
                            error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }

                override fun handleSuccessRespons(successResponse: TimeSlotResponse) {
                    if (successResponse.success  && successResponse.httpStatus == 200){
                        morningAdapter.setItems(successResponse.response.morning)
                        afternoonAdapter.setItems(successResponse.response.afternoon)
                        nightAdapter.setItems(successResponse.response.evening)


                    }else{
                        this@VideoVisitActivity.onError(
                            AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }
            })
    }


    private fun getResultDetails(){
        viewModel.getResultDetail(orderId,
            object : HandleResponse<ResultDetailResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (NetworkUtils.isNetworkConnected(this@VideoVisitActivity)) {
                        this@VideoVisitActivity.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        this@VideoVisitActivity.onError(
                            error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }

                override fun handleSuccessRespons(successResponse: ResultDetailResponse) {
                    if (successResponse.success && successResponse.httpStatus == 200){
                        viewDataBinding?.tvProductName?.text =
                            if (PreferenceManager.language == "en") successResponse.response[0].lABCATEGORYPACKAGE.nAMEEN
                        else successResponse.response[0].lABCATEGORYPACKAGE.nAMEAR
                    }else{
                        this@VideoVisitActivity.onError(
                            successResponse?.errorMessage.toString() ?: AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }
            })
    }
}