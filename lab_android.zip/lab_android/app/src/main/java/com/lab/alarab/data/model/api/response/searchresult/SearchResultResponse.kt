package com.lab.alarab.data.model.api.response.searchresult


import com.google.gson.annotations.SerializedName
import com.lab.alarab.data.model.api.response.landing.DefaultProduct

data class SearchResultResponse(
    var errorMessage: String?,
    var httpStatus: Int,
    var response: List<DefaultProduct>,
    var success: Boolean,
    var timestamp: Int
)