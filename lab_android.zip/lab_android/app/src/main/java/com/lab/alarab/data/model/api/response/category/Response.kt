package com.lab.alarab.data.model.api.response.category


import com.google.gson.annotations.SerializedName
import com.lab.alarab.data.model.api.response.landing.DefaultCategory
import com.lab.alarab.data.model.api.response.landing.DefaultProduct

data class Response(
    var categories: List<DefaultCategory>,
    var defaultProducts: List<DefaultProduct>
)