package com.lab.alarab.data.model.api.response

data class LabPackageItems(
    val ID: Int,
    val LAB_CATEGORY_PACKAGE_ID: Int,
    val NAME_AR: String,
    val NAME_EN: String
)