package com.lab.alarab.ui.orderdetail

import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.lab.alarab.R
import com.lab.alarab.base.BaseRecyclerViewAdapter
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.data.model.api.response.orderdetail.Package
import com.lab.alarab.databinding.RecyclerItemHomeDefaultProductNewBinding

class OrderDetailAdapter : BaseRecyclerViewAdapter<Package, RecyclerItemHomeDefaultProductNewBinding>()  {

    override val layoutId: Int
        get() = R.layout.recycler_item_home_default_product_new

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return OrderDetailViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as OrderDetailViewHolder
        val context =holder.binding.root.context

        holder.binding.tvPrice.text = """${items[position].pRICE} SAR"""
        if (PreferenceManager.language.equals("en")){
            holder.binding.tvName.text = items[position].nAMEEN
            if (items[position].dESCEN == null || items[position].dESCEN!!.isEmpty()){
                holder.binding.tvDescription.visibility = View.GONE
            }
            holder.binding.tvDescription.text = items[position].dESCEN
        }else{
            holder.binding.tvName.text = items[position].nAMEAR
            holder.binding.tvDescription.text = items[position].dESCAR
            if (items[position].dESCAR == null || items[position].dESCAR!!.isEmpty()){
                holder.binding.tvDescription.visibility = View.GONE
            }
        }
        var itemName = "items"
        var itemCount = 0
        if (items[position].lABPACKAGEITEMS != null && items[position].lABPACKAGEITEMS!!.isNotEmpty()){
            itemCount = items[position].lABPACKAGEITEMS?.size!!
            itemName = if (PreferenceManager.language != "ar"){
                items[position].lABPACKAGEITEMS!![0].NAME_EN ?: ""
            }else{
                items[position].lABPACKAGEITEMS!![0].NAME_AR ?: ""
            }
        }
        holder.binding.tvPackageCount.text = "$itemCount $itemName"
        Glide.with(context!!).asBitmap().load(items[position].ImageUrl ?: "")
            .into(viewHolder.binding.ivBanner)
    }

    inner class OrderDetailViewHolder(val binding: RecyclerItemHomeDefaultProductNewBinding) :
        RecyclerView.ViewHolder(binding.root)
}