package com.lab.alarab.data.model.api.response.landing



data class LandingPageResponse(
    var httpStatus: Int,
    var response: Response,
    var success: Boolean,
    var timestamp: Int,
    var errorMessage: String?
)