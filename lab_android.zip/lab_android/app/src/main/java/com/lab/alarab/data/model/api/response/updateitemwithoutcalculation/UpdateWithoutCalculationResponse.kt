package com.lab.alarab.data.model.api.response.updateitemwithoutcalculation


import com.google.gson.annotations.SerializedName

data class UpdateWithoutCalculationResponse(
    var errorMessage: String?,
    var httpStatus: Int,
    var response: List<Any>,
    var success: Boolean,
    var timestamp: Int
)