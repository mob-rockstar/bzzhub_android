package com.lab.alarab.data.model.api.response.notificationresponse


import com.google.gson.annotations.SerializedName

data class Response(
    var notifications: List<Notification>
)