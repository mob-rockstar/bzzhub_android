package com.lab.alarab.ui.main.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.bumptech.glide.Glide
import com.lab.alarab.R
import com.lab.alarab.data.model.api.response.landing.DefaultSlider
import com.lab.alarab.databinding.SliderItemLandingPageBinding
import com.smarteist.autoimageslider.SliderViewAdapter
import timber.log.Timber

class LandingSliderAdapter  : SliderViewAdapter<LandingSliderAdapter.StoreReceiptImageViewHolder>() {

    var receiptData: List<DefaultSlider> = ArrayList()

    override fun onCreateViewHolder(viewGroup: ViewGroup?): StoreReceiptImageViewHolder {
        val binding =  DataBindingUtil.inflate<SliderItemLandingPageBinding>(
            LayoutInflater.from(viewGroup!!.context),
            R.layout.slider_item_landing_page,
            viewGroup,
            false
        )

        return StoreReceiptImageViewHolder(binding)
    }

    override fun onBindViewHolder(viewHolder: StoreReceiptImageViewHolder?, position: Int) {
        val holder = viewHolder as LandingSliderAdapter.StoreReceiptImageViewHolder
        Glide.with(viewHolder.itemView)
            .load("http://" + receiptData[position].iMAGEPATH).placeholder(R.drawable.bg_round_accent_20).error(R.drawable.bg_round_accent_20)
            .centerCrop()
            .into(holder.binding.ivImage)
/*
        holder.itemView.setOnClickListener {
            imageClickListener?.onImageClick(receiptData[position].iMAGEPATH)
        }*/

    }

    fun renewItems(receiptList: ArrayList<DefaultSlider>){
        receiptData = receiptList
        notifyDataSetChanged()
    }

    override fun getCount(): Int {
        return receiptData.size
    }

    inner class StoreReceiptImageViewHolder(val binding: SliderItemLandingPageBinding) :
        SliderViewAdapter.ViewHolder(binding.root)
}