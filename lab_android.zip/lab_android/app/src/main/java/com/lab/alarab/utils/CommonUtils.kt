package com.lab.alarab.utils

import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.os.LocaleList
import com.lab.alarab.data.local.prefs.PreferenceManager
import java.util.*

object CommonUtils {
    // Set App Locale
    fun setLocale(mContext: Context, lang: String?) {
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.N) {
            val locale = Locale(lang)
            val localeList = LocaleList(locale)
            LocaleList.setDefault(localeList)
            val config = Configuration()
            config.setLocale(locale)
            config.setLocales(localeList)
            config.setLayoutDirection(locale)
            mContext.applicationContext.createConfigurationContext(config)
            mContext.createConfigurationContext(config)
            mContext.resources.updateConfiguration(config, mContext.resources.displayMetrics)
        } else {
            val locale = Locale(lang)
            Locale.setDefault(locale)
            val config = mContext.resources.configuration
            config.setLocale(locale)
            config.setLayoutDirection(locale)
            mContext.applicationContext.createConfigurationContext(config)
            mContext.createConfigurationContext(config)
            mContext.resources.updateConfiguration(config, mContext.resources.displayMetrics)
        }
    }


    fun getCityNameWithID(cityID: Int) : String{
        var cityName = "Riyadh"
        val cityList = AppConstants.cityList
        for (city in cityList){
            if (city.CITY_ID == cityID){
                cityName = if (PreferenceManager.language == "en"){
                    city.ENG_NAME
                }else{
                    city.ARABIC_NAME
                }
            }
        }

        return cityName
    }

}