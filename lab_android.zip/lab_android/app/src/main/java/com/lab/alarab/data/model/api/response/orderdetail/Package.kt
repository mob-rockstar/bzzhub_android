package com.lab.alarab.data.model.api.response.orderdetail


import com.google.gson.annotations.SerializedName
import com.lab.alarab.data.model.api.response.LabPackageItems

data class Package(
    @SerializedName("ACTIVE_STATUS")
    var aCTIVESTATUS: Int,
    @SerializedName("CITY_ID")
    var cITYID: Any,
    @SerializedName("DESC_AR")
    var dESCAR: String,
    @SerializedName("DESC_EN")
    var dESCEN: String,
    @SerializedName("FASTING_REQUIRED")
    var fASTINGREQUIRED: Int,
    @SerializedName("HOSPITAL_ID")
    var hOSPITALID: Any,
    @SerializedName("ID")
    var iD: Int,
    @SerializedName("LAB_CATEGORY_ID")
    var lABCATEGORYID: Int,
    @SerializedName("NAME_AR")
    var nAMEAR: String,
    @SerializedName("NAME_EN")
    var nAMEEN: String,
    @SerializedName("PRICE")
    var pRICE: Int,
    var pivot: Pivot,
    @SerializedName("TEST_TYPE")
    var tESTTYPE: Any,
    @SerializedName("lABPACKAGEITEMS")
    var lABPACKAGEITEMS: List<LabPackageItems>? = null,
    @SerializedName("IMAGE_URL")
    var ImageUrl: String ?= null,
)