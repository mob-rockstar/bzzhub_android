package com.lab.alarab.ui.editaddress

import com.lab.alarab.base.BaseViewModel
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.model.api.response.DeleteAddressResponse
import com.lab.alarab.data.model.api.response.addaddress.AddAddressResponse
import com.lab.alarab.data.model.api.response.addressdetail.AddressDetailResponse
import com.lab.alarab.data.model.api.response.addressmeta.AddressMetadataResponse
import com.lab.alarab.data.model.api.response.editadderss.EditAddressResponse
import com.lab.alarab.data.remote.APIManager
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class EditAddressViewModel : BaseViewModel() {
    fun getAddressDetail(addressId: Int, handleResponse: HandleResponse<AddressDetailResponse>){
        compositeDisposable.add(
            APIManager.getAddressDetail(addressId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

    fun getAddressMetaData(handleResponse: HandleResponse<AddressMetadataResponse>){
        compositeDisposable.add(
            APIManager.getAddressMetaData()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

    fun addAddress(
        addressId : Int,
        addressTypeId : Int,
        streetAddresS: String,
        landMark: String,
        city: String,
        lat: Double,
        lng: Double,
        addressInfo: String,
        handleResponse: HandleResponse<AddAddressResponse>){
        compositeDisposable.add(
            APIManager.addAddress(
                addressTypeId,
                addressId,
                streetAddresS,
                landMark,city,lat,lng,addressInfo
            )
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

    fun updateAddress(
        addressTitleId : Int,
        addressTypeId : Int,
        streetAddresS: String,
        landMark: String,
        city: String,
        lat: Double,
        lng: Double,
        addressInfo: String,
        addressID: Int,
        handleResponse: HandleResponse<EditAddressResponse>
    ){
        compositeDisposable.add(
            APIManager.editAddress(
                addressTypeId,
                addressTitleId,
                streetAddresS,
                landMark,city,lat,lng,addressInfo, addressID
            )
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }
}