package com.lab.alarab.data.model.api.response.searchresult


import com.google.gson.annotations.SerializedName

data class Response(
    @SerializedName("ACTIVE_STATUS")
    var aCTIVESTATUS: Int,
    @SerializedName("CART_ID")
    var cARTID: Any,
    @SerializedName("CITY_ID")
    var cITYID: Any,
    @SerializedName("DESC_AR")
    var dESCAR: Any,
    @SerializedName("DESC_EN")
    var dESCEN: Any,
    @SerializedName("FASTING_REQUIRED")
    var fASTINGREQUIRED: Int,
    @SerializedName("HOSPITAL_ID")
    var hOSPITALID: Any,
    @SerializedName("ID")
    var iD: Int,
    @SerializedName("LAB_CATEGORY_ID")
    var lABCATEGORYID: Int,
    var lABPACKAGEITEMS: List<Any>,
    @SerializedName("NAME_AR")
    var nAMEAR: String,
    @SerializedName("NAME_EN")
    var nAMEEN: String,
    @SerializedName("PRICE")
    var pRICE: Int,
    @SerializedName("TEST_TYPE")
    var tESTTYPE: Any
)