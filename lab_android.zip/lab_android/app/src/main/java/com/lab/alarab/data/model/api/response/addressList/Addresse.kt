package com.lab.alarab.data.model.api.response.addressList


import com.google.gson.annotations.SerializedName
import java.io.Serializable

open class Addresse : Serializable{
    @SerializedName("ADDRESS_INFO")
    var aDDRESSINFO: String = ""
    @SerializedName("ADDRESS_TITLE_ID")
    var aDDRESSTITLEID: Int = 0
    @SerializedName("ADDRESS_TYPE_ID")
    var aDDRESSTYPEID: Int = 0
    @SerializedName("CITY")
    var cITY: String = ""
    @SerializedName("END_USER_ID")
    var eNDUSERID: Int = 0
    @SerializedName("ID")
    var iD: Int= 0
    @SerializedName("IS_DEFAULT")
    var iSDEFAULT: Int = 0
    @SerializedName("LAND_MARK")
    var lANDMARK: String = ""
    @SerializedName("LATITUDE")
    var lATITUDE: String = ""
    @SerializedName("LONGITUDE")
    var lONGITUDE: String = ""
    @SerializedName("STREET_ADDRESS")
    var sTREETADDRESS: String = ""
}