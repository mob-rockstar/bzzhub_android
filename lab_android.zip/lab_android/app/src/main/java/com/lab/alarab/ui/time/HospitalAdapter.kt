package com.lab.alarab.ui.time

import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.lab.alarab.R
import com.lab.alarab.base.BaseRecyclerViewAdapter
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.data.model.api.response.availabletimeslot.Hospital
import com.lab.alarab.databinding.RecyclerItemAvailableTimeBinding

class HospitalAdapter : BaseRecyclerViewAdapter<Hospital, RecyclerItemAvailableTimeBinding>() {

    override val layoutId: Int
        get() = R.layout.recycler_item_available_time

    private var isWalkAvailable = true

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return HospitalViewHolder(createBindedView(viewGroup))
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val holder = viewHolder as HospitalViewHolder
        val context =holder.binding.root.context

        Glide.with(context!!).asBitmap().load(items[position].IMAGE_URL ?: "")
            .into(viewHolder.binding.ivImage)

        holder.binding.tvName.text =  if (PreferenceManager.language == "en") items[position].NAME_EN else items[position].NAME_AR
        holder.binding.tvAddress.text =  if (PreferenceManager.language == "en") items[position].TITLE_EN else items[position].TITLE_AR

        holder.binding.tvDistance.text = items[position].DISTANCE.toString() + "km"
        holder.binding.tvState.text = if (PreferenceManager.language == "en") items[position].CITYSTATE?.ENG_NAME
        else items[position].CITYSTATE?.ARABIC_NAME

        holder.binding.tvState.visibility = if (holder.binding.tvState.text == null || holder.binding.tvState.text.isEmpty()){
            GONE
        }else{
            VISIBLE
        }

        val linearLayoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL,false)
        val hospitalAdapter = HospitalAvailableTimeAdapter()
        holder.binding.recyclerviewTime.layoutManager = linearLayoutManager
        holder.binding.recyclerviewTime.adapter = hospitalAdapter
        hospitalAdapter.setItems(items[position].AvailableTimes)
        hospitalAdapter.parentHospital = items[position]

        if (isWalkAvailable){
            holder.binding.layoutWalk.visibility = VISIBLE
            holder.binding.tvState.visibility = VISIBLE
        }else{
            holder.binding.layoutWalk.visibility = GONE
            holder.binding.tvState.visibility = GONE
        }
    }

    fun setWalkAvailable(walkAvailable: Boolean){
        isWalkAvailable = walkAvailable
        notifyDataSetChanged()
    }

    inner class HospitalViewHolder(val binding: RecyclerItemAvailableTimeBinding) :
        RecyclerView.ViewHolder(binding.root)
}