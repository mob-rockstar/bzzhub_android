package com.lab.alarab.data.model.api.response.orderdetail


import com.google.gson.annotations.SerializedName

data class Pivot(
    @SerializedName("BIRTH_DATE")
    var bIRTHDATE: String,
    @SerializedName("DATE_OF_BIRTH")
    var dATEOFBIRTH: Any,
    @SerializedName("END_USER_LAB_ORDER_ID")
    var eNDUSERLABORDERID: Int,
    @SerializedName("FOLLOWER_RELATION_ID")
    var fOLLOWERRELATIONID: Any,
    @SerializedName("GENDER_ID")
    var gENDERID: Any,
    @SerializedName("ID")
    var iD: Int,
    @SerializedName("IDENTIFICATION")
    var iDENTIFICATION: Any,
    @SerializedName("IDENTIFICATION_TYPE")
    var iDENTIFICATIONTYPE: Any,
    @SerializedName("LAB_CATEGORY_PACKAGE_ID")
    var lABCATEGORYPACKAGEID: Int,
    @SerializedName("LAB_ORDER_STATUS_ID")
    var lABORDERSTATUSID: Int,
    @SerializedName("MOBILE_NUMBER")
    var mOBILENUMBER: Any,
    @SerializedName("NAME")
    var nAME: String,
    @SerializedName("NATIONALITY")
    var nATIONALITY: Any,
    @SerializedName("NATIONALITY_ID")
    var nATIONALITYID: Any,
    @SerializedName("PRICE")
    var pRICE: Int
)