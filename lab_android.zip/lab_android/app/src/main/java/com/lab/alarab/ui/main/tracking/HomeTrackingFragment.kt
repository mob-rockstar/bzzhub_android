package com.lab.alarab.ui.main.tracking


import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.lab.alarab.R
import com.lab.alarab.base.BaseInputFragment
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.data.model.api.response.ErrorResponse
import com.lab.alarab.data.model.api.response.orderhistory.OrderHistoryResponse
import com.lab.alarab.databinding.FragmentHomeTrackingBinding
import com.lab.alarab.di.Injectable
import com.lab.alarab.ui.choosepayment.ChoosePaymentActivity
import com.lab.alarab.ui.main.MainActivity
import com.lab.alarab.ui.main.MainViewModel
import com.lab.alarab.ui.order.OrderActivity
import com.lab.alarab.ui.orderdetail.OrderDetailActivity
import com.lab.alarab.ui.resultexplanation.ResultExplanationActivity
import com.lab.alarab.utils.AppConstants
import com.lab.alarab.utils.MessageEvent
import com.lab.alarab.utils.NetworkUtils
import kotlinx.android.synthetic.main.activity_order.*
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode


class HomeTrackingFragment :
    BaseInputFragment<FragmentHomeTrackingBinding?, MainViewModel>(), Injectable {

    override val layoutId: Int
        get() = R.layout.fragment_home_tracking

    override val viewModel: MainViewModel
        get() {
            return getViewModel(baseActivity, MainViewModel::class.java)
        }

    var trackingAdapter: TrackingAdapter = TrackingAdapter(){
        orderId ->gotoOrderDetailActivity(orderId)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

   //     viewDataBinding?.itemProgress?.layoutRipple?.startRippleAnimation()
        EventBus.getDefault().register(this)
        viewDataBinding?.layoutCart?.setOnClickListener {
            startActivity(Intent(activity, OrderActivity::class.java))
        }

        initCartCount()
        getOrders()
        initRecyclerView()

/*        viewDataBinding?.itemProgress?.ivNext?.setOnClickListener {
            startActivity(Intent(activity, OrderDetailActivity::class.java))
        }

        viewDataBinding?.itemProgress?.tvResult?.setOnClickListener {
            startActivity(Intent(activity, ResultExplanationActivity::class.java))
        }*/

        viewDataBinding?.layoutHelp?.setOnClickListener {
            val i = Intent(Intent.ACTION_SEND)
            i.putExtra(Intent.EXTRA_EMAIL, arrayOf<String>("support@lab.com"))
            i.putExtra(Intent.EXTRA_SUBJECT, "Hello")
            i.putExtra(Intent.EXTRA_TEXT,"" )
            startActivity(Intent.createChooser(i, "Send email"))
        }
    }

    private fun gotoOrderDetailActivity(orderId: Int){
        val intent = Intent(baseActivity, OrderDetailActivity::class.java)
        intent.putExtra("order_id", orderId)
        startActivity(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }

    private fun initRecyclerView(){
        viewDataBinding?.recyclerView?.layoutManager = LinearLayoutManager(baseActivity)
        viewDataBinding?.recyclerView?.adapter = trackingAdapter
    }

    private fun getOrders(){
        viewModel.getOrderHistory(
            object : HandleResponse<OrderHistoryResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (NetworkUtils.isNetworkConnected(baseActivity)) {
                        this@HomeTrackingFragment.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        this@HomeTrackingFragment.onError(
                            error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }

                override fun handleSuccessRespons(successResponse: OrderHistoryResponse) {
                    if (successResponse.success && successResponse.httpStatus == 200){
                        trackingAdapter.setItems(successResponse.response)
                    }else{
                        this@HomeTrackingFragment.onError(
                           AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    }
                }
            }
        )
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        when (event.message) {
            AppConstants.RELOAD_ORDER -> {
                // If received broadcast message 'profile_changed', reload user information
                getOrders()
            }
            AppConstants.MESSAGE_CART_CHANGED -> {
                // If received broadcast message 'profile_changed', reload user information
                initCartCount()
            }
        }
    }

    private fun initCartCount(){
        viewDataBinding?.layoutCartCount?.visibility =
            if (PreferenceManager.userCartCount == 0) View.GONE
            else View.VISIBLE

        viewDataBinding?.tvCartCount?.text = PreferenceManager.userCartCount.toString()
    }
}