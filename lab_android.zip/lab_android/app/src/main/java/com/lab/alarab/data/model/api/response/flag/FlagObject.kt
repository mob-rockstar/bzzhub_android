package com.lab.alarab.data.model.api.response.flag


import com.google.gson.annotations.SerializedName
import java.io.Serializable

open class FlagObject: Serializable {
    @SerializedName("ar_name")
    var arName: String? =null
    var code: String? = null
    @SerializedName("dial_code")
    var dialCode: String? = null
    var icon: String? = null
    var id: Int?= null
    var name: String ? = null
}
