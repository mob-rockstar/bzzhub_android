package com.lab.alarab.ui.forgotpassword.enterotp

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import com.lab.alarab.R
import com.lab.alarab.base.BaseInputFragment
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.data.model.api.response.ErrorResponse
import com.lab.alarab.data.model.api.response.SignInResponse
import com.lab.alarab.data.model.api.response.VerifyMobileResponse
import com.lab.alarab.databinding.FragmentEnterOTPBinding
import com.lab.alarab.databinding.FragmentForgotPasswordEnterOTPBinding
import com.lab.alarab.di.Injectable
import com.lab.alarab.ui.forgotpassword.ForgotPasswordViewModel
import com.lab.alarab.utils.*
import org.greenrobot.eventbus.EventBus


class ForgotPasswordEnterOTPFragment  :
    BaseInputFragment<FragmentForgotPasswordEnterOTPBinding?, ForgotPasswordViewModel>(), Injectable {

    override val layoutId: Int
        get() = R.layout.fragment_forgot_password_enter_o_t_p

    override val viewModel: ForgotPasswordViewModel
        get() {
            return getViewModel(baseActivity, ForgotPasswordViewModel::class.java)
        }

    var digitCode = ""
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initUI()

        Handler().postDelayed({
            viewDataBinding?.edittextOtp?.requestFocus()
            KeyboardUtils.showKeyboard(baseActivity, viewDataBinding?.edittextOtp!!)
        }, 200)
    }

    private fun initUI(){
        viewDataBinding?.tvNotReceiveCode?.setOnClickListener {
            PopupUtils.showResendOTPDialog(baseActivity, viewModel.strMobile) { verifyMobile() }
        }

        viewDataBinding?.toolbar?.ivBack?.setOnClickListener {
            popBackStack()
        }

        viewDataBinding?.tvEdit?.setOnClickListener {
            popBackStack()
        }

        viewDataBinding?.tvContinue?.setOnClickListener {
            if (digitCode.length ==4 ){
                verifyOTPCode()
            }else{
                Toast.makeText(baseActivity, baseActivity.resources.getString(R.string.str_enter_valid_otp),
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        viewDataBinding?.toolbar?.tvHelp?.setOnClickListener {
            val i = Intent(Intent.ACTION_SEND)
            i.putExtra(Intent.EXTRA_EMAIL, arrayOf<String>("support@lab.com"))
            i.putExtra(Intent.EXTRA_SUBJECT, "Hello")
            i.putExtra(Intent.EXTRA_TEXT,"" )
            startActivity(Intent.createChooser(i, "Send email"))

        }

        initOTPField()
    }


    private fun initOTPField(){
        viewDataBinding?.edittextOtp?.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                digitCode = viewDataBinding?.edittextOtp?.text.toString().trim()
                // If OTP length reaches 4, then automatically call 'Verify OTP' method
                if (digitCode.length == 4) {
                    enableNextButton()
                    verifyOTPCode()
                } else
                    disableNextButton()
            }
        })
    }

    private fun enableNextButton(){
        viewDataBinding?.tvContinue?.isClickable = true
        viewDataBinding?.tvContinue?.isFocusable = true
        viewDataBinding?.tvContinue?.background = baseActivity?.resources?.getDrawable(R.drawable.ic_round_background_gradient_12)
    }

    private fun disableNextButton(){
        viewDataBinding?.tvContinue?.isClickable = true
        viewDataBinding?.tvContinue?.isFocusable = true
        viewDataBinding?.tvContinue?.background = baseActivity?.resources?.getDrawable(R.drawable.ic_round_background_grey_600_12)
    }

    private fun verifyOTPCode(){
        viewModel.verifyUpdateMobileNo(digitCode, object : HandleResponse<SignInResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(baseActivity)) {
                    this@ForgotPasswordEnterOTPFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    this@ForgotPasswordEnterOTPFragment.onError(
                        error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                    )
                }
            }

            override fun handleSuccessRespons(successResponse: SignInResponse) {
                if (successResponse.httpStatus == 200 && successResponse.success){
                    PreferenceManager.currentUserMobile = viewModel.strMobile
                    PreferenceManager.dialCode = viewModel.strCountryCode
                    EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_UPDATE_PROFILE))
                    finishActivity()
                }else{
                    this@ForgotPasswordEnterOTPFragment.onError(AppConstants.DEFAULT_ERROR_MESSAGE)
                }
            }
        })
    }

    private fun verifyMobile(){

        viewModel.verifyMobileNumber(object : HandleResponse<VerifyMobileResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(baseActivity)) {
                    this@ForgotPasswordEnterOTPFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    this@ForgotPasswordEnterOTPFragment.onError(
                        error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                    )
                }
            }

            override fun handleSuccessRespons(successResponse: VerifyMobileResponse) {
                if (successResponse.httpStatus == 200 && successResponse.success){
                }else{
                    this@ForgotPasswordEnterOTPFragment.onError(AppConstants.DEFAULT_ERROR_MESSAGE)
                }
            }
        })
    }


}