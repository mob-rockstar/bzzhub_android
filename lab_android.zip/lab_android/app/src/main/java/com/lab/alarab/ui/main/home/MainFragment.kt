package com.lab.alarab.ui.main.home

import android.content.Context
import android.content.Intent
import android.location.Geocoder
import android.os.Bundle
import android.util.EventLog
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.gms.maps.model.LatLng
import com.google.gson.JsonObject
import com.lab.alarab.R
import com.lab.alarab.base.BaseInputFragment
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.local.prefs.PreferenceManager
import com.lab.alarab.data.model.api.response.ErrorResponse
import com.lab.alarab.data.model.api.response.city.CityResponse
import com.lab.alarab.data.model.api.response.landing.CategoryType
import com.lab.alarab.data.model.api.response.landing.DefaultCategory
import com.lab.alarab.data.model.api.response.landing.DefaultProduct
import com.lab.alarab.data.model.api.response.landing.LandingPageResponse
import com.lab.alarab.data.model.api.response.removewithcalculation.RemoveWithCalculationResponse
import com.lab.alarab.data.model.api.response.updateitemwithcalculation.UpdateWithCalculationResponse
import com.lab.alarab.databinding.FragmentMainBinding
import com.lab.alarab.di.Injectable
import com.lab.alarab.ui.accountsettings.AccountSettingActivity
import com.lab.alarab.ui.choosedelivery.ChooseDeliveryActivity
import com.lab.alarab.ui.main.MainViewModel
import com.lab.alarab.ui.main.notification.NotificationFragment
import com.lab.alarab.ui.order.OrderActivity
import com.lab.alarab.ui.search.SearchProductActivity
import com.lab.alarab.utils.AppConstants
import com.lab.alarab.utils.GPSTrackService
import com.lab.alarab.utils.MessageEvent
import com.lab.alarab.utils.NetworkUtils
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import timber.log.Timber
import java.io.IOException
import java.util.*
import kotlin.collections.ArrayList


class MainFragment   :
    BaseInputFragment<FragmentMainBinding?, MainViewModel>(), Injectable {

    override val layoutId: Int
        get() = R.layout.fragment_main

    override val viewModel: MainViewModel
        get() {
            return getViewModel(baseActivity, MainViewModel::class.java)
        }

    var categoryAdapter: CategoryAdapter = CategoryAdapter()
    var landingSliderAdapter: LandingSliderAdapter = LandingSliderAdapter()
    var categoryType:List<CategoryType>?= null
    var productList: ArrayList<DefaultProduct> ?= null
    var defaultCategory = ArrayList<DefaultCategory>()
    var productAdapter: DefaultProductAdapter = DefaultProductAdapter(){
        product,position ->
        if (product?.cARTID == null){
            addToCartWithCalculations(product?.iD!!, position!!)
        }else{
            removeItemFromCart(product.iD)
        }

    }
    var gpsTracker: GPSTrackService? = null
    var addressString :String ? = ""

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        EventBus.getDefault().register(this)

        gpsTracker = GPSTrackService(baseActivity)

        if (gpsTracker?.canGetLocation!!){
            setAddress(LatLng(gpsTracker?.latitude!!, gpsTracker?.longitude!!))
        }
        viewDataBinding?.toolbar?.ivProfile?.setOnClickListener {
            startActivity(Intent(activity, AccountSettingActivity::class.java))
        }

        viewDataBinding?.toolbar?.layoutCart?.setOnClickListener {
            startActivity(Intent(activity, OrderActivity::class.java))
        }

        viewDataBinding?.toolbar?.tvName?.text = PreferenceManager.currentUserFirstName
   //     viewDataBinding?.toolbar?.tvAddress?.text = PreferenceManager.address

        initCartCount()

        viewDataBinding?.toolbar?.layoutAddress?.setOnClickListener {
            startActivity(Intent(activity, ChooseDeliveryActivity::class.java))
        }

        viewDataBinding?.layoutSearch?.setOnClickListener {
            startActivity(Intent(activity, SearchProductActivity::class.java))
        }

        viewDataBinding?.toolbar?.layoutNotification?.setOnClickListener {
            showDialogFragment(NotificationFragment())
        }

        getCityList()
        initListener()
    }

    private fun setAddress(latLng: LatLng) {
        try {
            addressString = getAddressName(baseActivity, latLng.latitude, latLng.longitude)
            viewDataBinding?.toolbar?.tvAddress?.text = addressString
        } catch (e: java.lang.Exception) {
            getGoogleAddress(latLng.latitude, latLng.longitude)
            e.printStackTrace()
        }
    }

    private fun getAddressName(context: Context, latitude: Double, longitude: Double): String? {
        val geocoder = Geocoder(context, Locale.ENGLISH)
        var addresses: List<android.location.Address>? = null
        var addressName: String? = ""
        try {
            addresses = geocoder.getFromLocation(latitude, longitude, 1)
            addressName = addresses.first().countryName
            addressString = addresses.first().countryName
        } catch (ignored: IOException) {
            Timber.tag("LocationMap -> parse").e(ignored)
            getGoogleAddress(latitude, longitude)
        }
        return addressName
    }

    private fun getGoogleAddress(latitude: Double, longitude: Double) {
        viewModel.getGoogleAddress(latitude, longitude, object : HandleResponse<JsonObject> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(baseActivity)) {
                    this@MainFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    this@MainFragment.onError(
                        error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                    )
                }
            }

            override fun handleSuccessRespons(successResponse: JsonObject) {
                addressString = try {
                    successResponse.getAsJsonArray("results")[1].asJsonObject["formatted_address"].toString()
                        .replace("\"", "")
                } catch (e: java.lang.Exception) {
                    ""
                }
                viewDataBinding?.toolbar?.tvAddress?.text = addressString
            }
        })
    }


    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }

    override fun onResume() {
        super.onResume()
        getLandingPageInfo()
    }

    private fun initCartCount(){
     /*   viewDataBinding?.toolbar?.layoutCartCount?.visibility =
            if (PreferenceManager.userCartCount == 0) GONE
            else VISIBLE*/
        viewDataBinding?.toolbar?.layoutCart?.visibility = GONE
        viewDataBinding?.toolbar?.layoutCartCount?.visibility = GONE

        viewDataBinding?.toolbar?.tvCartCount?.text = PreferenceManager.userCartCount.toString()
    }

    private fun initListener(){
        viewDataBinding?.tvIndividualTest?.setOnClickListener {
            viewDataBinding?.tvPackage?.setTextColor(ContextCompat.getColor(baseActivity,R.color.color_black_800))
            viewDataBinding?.tvIndividualTest?.setTextColor(ContextCompat.getColor(baseActivity,R.color.color_white_1000))
            viewDataBinding?.tvIndividualTest?.background = ContextCompat.getDrawable(baseActivity,R.drawable.ic_rounded_accent_background_30)
            viewDataBinding?.tvPackage?.background = null
        }

        viewDataBinding?.tvPackage?.setOnClickListener {
            viewDataBinding?.tvPackage?.setTextColor(ContextCompat.getColor(baseActivity,R.color.color_white_1000))
            viewDataBinding?.tvIndividualTest?.background = null
            viewDataBinding?.tvPackage?.background = ContextCompat.getDrawable(baseActivity,R.drawable.ic_rounded_accent_background_30)
            viewDataBinding?.tvIndividualTest?.setTextColor(ContextCompat.getColor(baseActivity,R.color.color_black_800))
        }
    }

    private fun getLandingPageInfo(){
        viewModel.getLandingPageInfo(object : HandleResponse<LandingPageResponse> {
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(baseActivity)) {
                    this@MainFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    this@MainFragment.onError(
                        error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                    )
                }
            }

            override fun handleSuccessRespons(successResponse: LandingPageResponse) {
                if (successResponse.success && successResponse.httpStatus == 200){
                    landingSliderAdapter.renewItems(successResponse.response.defaultSlider)
                    viewDataBinding?.imageSlider?.setSliderAdapter(landingSliderAdapter)

                    categoryType = successResponse.response.categoryTypes
                    AppConstants.categoryType = categoryType
                    initCategoryType()
                    defaultCategory = successResponse.response.defaultCategories
                    initDefaultCategory()
                    productList = successResponse.response.defaultProducts
                    getCartCount()
                    initProductView()
                }else{
                    this@MainFragment.onError(
                      successResponse.errorMessage ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                }
            }
        })
    }

    private fun getCartCount(){
        var cartCount= 0
        for (product in productList!!){
            if (product.cARTID != null && product.cARTID!! != 0L){
                cartCount ++
            }
        }

        PreferenceManager.userCartCount = cartCount
    }

    private fun initCategoryType(){
        if (PreferenceManager.language == "en"){
            viewDataBinding?.tvIndividualTest?.text = categoryType!![0].nAMEEN
            viewDataBinding?.tvPackage?.text = categoryType!![1].nAMEEN
        }else{
            viewDataBinding?.tvIndividualTest?.text = categoryType!![0].nAMEAR
            viewDataBinding?.tvPackage?.text = categoryType!![1].nAMEAR
        }
    }

    private fun initDefaultCategory() {
        viewDataBinding?.recyclerViewCategory?.layoutManager = LinearLayoutManager(baseActivity,LinearLayoutManager.HORIZONTAL,false)
        viewDataBinding?.recyclerViewCategory?.adapter = categoryAdapter
        categoryAdapter.setItems(defaultCategory)

        AppConstants.categoryID = defaultCategory[0].iD
    }

    private fun initProductView(){
        viewDataBinding?.recyclerviewProduct?.layoutManager =
            LinearLayoutManager(baseActivity,LinearLayoutManager.VERTICAL,false)
        viewDataBinding?.recyclerviewProduct?.adapter = productAdapter
        productAdapter.setItems(productList!!)
    }

    private fun addToCartWithCalculations(packageId: Int, position:Long){
        viewModel.addToCart(packageId, object : HandleResponse <UpdateWithCalculationResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(baseActivity)) {
                    this@MainFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    this@MainFragment.onError(
                        error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                    )
                }
            }

            override fun handleSuccessRespons(successResponse: UpdateWithCalculationResponse) {
                if (successResponse.success && successResponse.httpStatus == 200){
                    PreferenceManager.userCartCount = PreferenceManager.userCartCount+1
                    getLandingPageInfo()
                }else{
                    this@MainFragment.onError(
                        successResponse.errorMessage ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                }
            }
        })
    }

    private fun removeItemFromCart(packageId: Int){
        viewModel.removeItemFromCart(packageId, object : HandleResponse <RemoveWithCalculationResponse>{
            override fun handleErrorResponse(error: ErrorResponse?) {
                if (NetworkUtils.isNetworkConnected(baseActivity)) {
                    this@MainFragment.onError(
                        error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                } else {
                    this@MainFragment.onError(
                        error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                    )
                }
            }

            override fun handleSuccessRespons(successResponse: RemoveWithCalculationResponse) {
                if (successResponse.success && successResponse.httpStatus == 200){
                    PreferenceManager.userCartCount = PreferenceManager.userCartCount+1
                    getLandingPageInfo()
                }else{
                    this@MainFragment.onError(
                         AppConstants.DEFAULT_ERROR_MESSAGE
                    )
                }
            }
        })
    }

    private fun getCityList(){
        viewModel.getCityList(
            object : HandleResponse<CityResponse> {
                override fun handleErrorResponse(error: ErrorResponse?) {
                    if (NetworkUtils.isNetworkConnected(baseActivity)) {
                        this@MainFragment.onError(
                            error?.message ?: AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    } else {
                        this@MainFragment.onError(
                            error?.message ?: AppConstants.NETWORK_ERROR_MESSAGE
                        )
                    }
                }

                override fun handleSuccessRespons(successResponse: CityResponse) {
                    if (successResponse.success && successResponse.httpStatus == 200){
                        AppConstants.cityList = successResponse.response ?: ArrayList()
                    }else{
                        this@MainFragment.onError(
                            AppConstants.DEFAULT_ERROR_MESSAGE
                        )
                    }
                }
            }
        )
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        when (event.message) {
            AppConstants.MESSAGE_CART_CHANGED -> {
                // If received broadcast message 'profile_changed', reload user information
                initCartCount()
            }
        }
    }

}