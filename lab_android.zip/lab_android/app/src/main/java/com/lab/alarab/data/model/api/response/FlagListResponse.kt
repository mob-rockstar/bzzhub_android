package com.lab.alarab.data.model.api.response


import com.lab.alarab.data.model.api.response.flag.FlagObject

data class FlagListResponse(
    var httpStatus: Int,
    var response: List<FlagObject>,
    var success: Boolean,
    var timestamp: Int
)