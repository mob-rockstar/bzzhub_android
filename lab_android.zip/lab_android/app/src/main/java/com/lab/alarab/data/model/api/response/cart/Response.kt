package com.lab.alarab.data.model.api.response.cart


import com.google.gson.annotations.SerializedName

data class Response(
    var coupon: String,
    @SerializedName("discount_amount")
    var discountAmount: Float,
    @SerializedName("discount_percetnage")
    var discountPercetnage: String,
    @SerializedName("fees_amount")
    var feesAmount: Int,
    @SerializedName("net_total")
    var netTotal: Float,
    var packages: List<Package>,
    @SerializedName("packages_amount")
    var packagesAmount: Float,
    @SerializedName("packages_count")
    var packagesCount: Int,
    @SerializedName("tax_amount")
    var taxAmount: Float,
    @SerializedName("wallet_amount")
    var walletAmount: Float
)