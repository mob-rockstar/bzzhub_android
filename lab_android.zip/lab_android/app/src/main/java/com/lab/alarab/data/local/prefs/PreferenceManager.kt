package com.lab.alarab.data.local.prefs

import android.content.Context
import android.content.SharedPreferences
import com.lab.alarab.data.model.api.User
import com.lab.alarab.utils.AppConstants
import com.lab.alarab.utils.MessageEvent
import org.greenrobot.eventbus.EventBus
import kotlin.math.sign

object PreferenceManager {

    // Constants
    private const val PREF_KEY_ACCESS_TOKEN                 = "PREF_KEY_ACCESS_TOKEN"
    private const val PREF_KEY_CURRENT_USER_MOBILE          = "PREF_KEY_CURRENT_USER_MOBILE"
    private const val PREF_KEY_CURRENT_USER_EMAIL           = "PREF_KEY_CURRENT_USER_EMAIL"
    private const val PREF_KEY_CURRENT_USER_ID              = "PREF_KEY_CURRENT_USER_ID"
    private const val PREF_KEY_CURRENT_USER_FIRST_NAME      = "PREF_KEY_CURRENT_USER_FIRST_NAME"
    private const val PREF_KEY_CURRENT_USER_LAST_NAME       = "PREF_KEY_CURRENT_USER_LAST_NAME"
    private const val PREF_KEY_CURRENT_USER_IMAGE_URL       = "PREF_KEY_CURRENT_USER_IMAGE_URL"
    private const val PREF_KEY_CURRENT_USER_ADDRESS       = "PREF_KEY_CURRENT_USER_ADDRESS"
    private const val PREF_KEY_CURRENT_USER_BUILDING       = "PREF_KEY_CURRENT_USER_BUILDING"
    private const val PREF_KEY_DATE_OF_BIRTH       = "PREF_KEY_DATE_OF_BIRTH"
    private const val PREF_KEY_DIAL_CODE       = "PREF_KEY_DIAL_CODE"
    private const val PREF_KEY_DIAL_CODE_ID       = "PREF_KEY_DIAL_CODE_ID"
    private const val PREF_KEY_ELECTRONIC_ID      = "PREF_KEY_ELECTRONIC_ID"
    private const val PREF_KEY_GCM_ID = "PREF_KEY_GCM_ID"
    private const val PREF_KEY_GENDER_ID = "PREF_KEY_GENDER_ID"
    private const val PREF_KEY_IDENTIFICATION = "PREF_KEY_IDENTIFICATION"
    private const val PREF_KEY_IDENTIFICATION_TYPE = "PREF_KEY_IDENTIFICATION_TYPE"
    private const val PREF_KEY_INSURANCE_COMPANY_ID = "PREF_KEY_INSURANCE_COMPANY_ID"
    private const val PREF_KEY_INSURANCE_POLICY_NUMBER = "PREF_KEY_INSURANCE_POLICY_NUMBER"
    private const val PREF_KEY_LANGUAGE = "PREF_KEY_LANGUAGE"
    private const val PREF_KEY_LATITUDE = "PREF_KEY_LATITUDE"
    private const val PREF_KEY_LONGITUDE = "PREF_KEY_LONGITUDE"
    private const val PREF_KEY_NATIONALITY = "PREF_KEY_NATIONALITY"
    private const val PREF_KEY_NATIONALITY_ID = "PREF_KEY_NATIONALITY_ID"
    private const val PREF_KEY_NEAREST = "PREF_KEY_NEAREST"
    private const val PREF_KEY_RESET_PASSWORD_FLAG = "PREF_KEY_RESET_PASSWORD_FLAG"
    private const val PREF_KEY_SIGN_UP_DATE = "PREF_KEY_SIGN_UP_DATE"
    private const val PREF_KEY_STATUS_ID = "PREF_KEY_STATUS_ID"
    private const val PREF_KEY_SYSTEM_MODULE_ID = "PREF_KEY_SYSTEM_MODULE_ID"
    private const val PREF_KEY_TOKEN = "PREF_KEY_TOKEN"
    private const val PREF_KEY_FLOOR_NO = "PREF_KEY_FLOOR_NO"
    private const val PREF_KEY_USER_CART_COUNT              = "PREF_KEY_USER_CART_COUNT"
    private const val PREF_KEY_USER_LOGGED_IN_MODE          = "PREF_KEY_USER_LOGGED_IN_MODE"

    private lateinit var mPrefs: SharedPreferences

    fun init(context: Context) {
        mPrefs = context.getSharedPreferences(AppConstants.PREF_NAME, Context.MODE_PRIVATE)
    }

    // User Data
    private var _userData: User? = null
    var userData: User?
        get() {
            if (_userData == null) {
                if (currentUserId != null && currentUserId!! > 0) {
                    _userData = User()
                    _userData!!.iD = currentUserId!!
                    _userData!!.aCCESSTOKEN =
                        accessToken
                    _userData!!.mOBILENUMBER =
                        currentUserMobile
                    _userData!!.fIRSTNAME =
                        currentUserFirstName
                    _userData!!.lASTNAME =
                        currentUserLastName
                    _userData!!.eMAIL =
                        currentUserEmail
                    _userData!!.eNDUSERPHOTOURI =
                        currentUserImageUrl
                    _userData!!.tOKEN =
                        token
                    _userData!!.aDDRESS =
                        address
                    _userData!!.bUILDINGNO =
                        building
                    _userData!!.dATEOFBIRTH =
                        dob
                    _userData!!.dIALCODE =
                        dialCode
                    _userData!!.dIALCODEID =
                        dialCodeId
                    _userData!!.eLECTRONICID =
                        electronicID
                    _userData!!.fLOORNO =
                        floorNo
                    _userData!!.gCMID =
                        gcmID
                    _userData!!.gENDERID =
                        genderId
                    _userData!!.iDENTIFICATION =
                        identification
                    _userData!!.iDENTIFICATIONTYPE =
                        idType
                    _userData!!.iNSURANCECOMPANYID =
                        insuranceCompanyId
                    _userData!!.iNSURANCEPOLICYNUMBER =
                        insurancePolicyNumber
                    _userData!!.lANGUAGE =
                        language
                    _userData!!.lATITUDE =
                        latitude
                    _userData!!.lONGITUDE =
                        longitude
                    _userData!!.nATIONALITY =
                        nationality
                    _userData!!.nATIONALITYID =
                        nationalityID
                    _userData!!.nEAREST =
                        nearest
                    _userData!!.rESETPASSWORDFLAG =
                        resetPasswordFlag
                    _userData!!.sIGNUPDATE =
                        signUpDate
                    _userData!!.sTATUSID =
                        statusID
                    _userData!!.sYSTEMMODULEID =
                        systemModuleId
                }
            }
            return _userData
        }
        set(user) {
            _userData = user

            currentUserId = user?.iD
            accessToken = user?.aCCESSTOKEN
            currentUserMobile = user?.mOBILENUMBER
            currentUserFirstName = user?.fIRSTNAME
            currentUserLastName = user?.lASTNAME
            currentUserEmail = user?.eMAIL
            currentUserImageUrl = user?.eNDUSERPHOTOURI
            token = user?.tOKEN
            address = user?.aDDRESS
            building = user?.bUILDINGNO
            dob = user?.dATEOFBIRTH
            dialCode = user?.dIALCODE
            dialCodeId = user?.dIALCODEID
            electronicID = user?.eLECTRONICID
            floorNo = user?.fLOORNO
            gcmID = user?.gCMID
            genderId = user?.gENDERID!!
            identification = user.iDENTIFICATION
            idType = user.iDENTIFICATIONTYPE
            insuranceCompanyId = user.iNSURANCECOMPANYID
            insurancePolicyNumber = user.iNSURANCEPOLICYNUMBER
            language = user.lANGUAGE
            latitude = user.lATITUDE
            longitude = user.lONGITUDE
            nationality = user.nATIONALITY
            nationalityID = user.nATIONALITYID
            nearest = user.nEAREST
            resetPasswordFlag = user.rESETPASSWORDFLAG
            signUpDate = user.sIGNUPDATE
            statusID = user.sTATUSID
            systemModuleId = user.sYSTEMMODULEID
        }

    // Token from Server
    var accessToken: String?
        get() = mPrefs.getString(
            PREF_KEY_ACCESS_TOKEN, null
        )
        set(accessToken) {
            mPrefs.edit().putString(
                PREF_KEY_ACCESS_TOKEN, accessToken
            ).apply()
        }

    // User Mobile number
    var currentUserMobile: String?
        get() = mPrefs.getString(
            PREF_KEY_CURRENT_USER_MOBILE, null
        )
        set(mobile) {
            mPrefs.edit().putString(
                PREF_KEY_CURRENT_USER_MOBILE, mobile
            ).apply()
        }

    // User Email Address
    var currentUserEmail: String?
        get() = mPrefs.getString(
            PREF_KEY_CURRENT_USER_EMAIL, null
        )
        set(email) {
            mPrefs.edit().putString(
                PREF_KEY_CURRENT_USER_EMAIL, email
            ).apply()
        }

    // Current User Login Mode - Loggedin, Loggedout, Social
    var currentUserLoggedInMode: LoggedInMode
        get() = LoggedInMode.fromInt(
            mPrefs.getInt(
                PREF_KEY_USER_LOGGED_IN_MODE,
                0
            )
        )
        set(mode) {
            mPrefs.edit().putInt(
                PREF_KEY_USER_LOGGED_IN_MODE, mode.type
            ).apply()
        }


    // User ID
    var currentUserId: Long?
        get() {
            val userId = mPrefs.getLong(
                PREF_KEY_CURRENT_USER_ID, AppConstants.NULL_INDEX
            )
            return if (userId == AppConstants.NULL_INDEX) null else userId
        }
        set(userId) {
            val id = userId ?: AppConstants.NULL_INDEX
            mPrefs.edit().putLong(
                PREF_KEY_CURRENT_USER_ID, id
            ).apply()
        }

    // User First Name
    var currentUserFirstName: String?
        get() = mPrefs.getString(
            PREF_KEY_CURRENT_USER_FIRST_NAME, null
        )
        set(firstName) {
            mPrefs.edit().putString(
                PREF_KEY_CURRENT_USER_FIRST_NAME, firstName
            ).apply()
        }

    // User Last Name
    var currentUserLastName: String?
        get() = mPrefs.getString(
            PREF_KEY_CURRENT_USER_LAST_NAME, null
        )
        set(lastName) {
            mPrefs.edit().putString(
                PREF_KEY_CURRENT_USER_LAST_NAME, lastName
            ).apply()
        }

    // User Image URL
    var currentUserImageUrl: String?
        get() = mPrefs.getString(
            PREF_KEY_CURRENT_USER_IMAGE_URL, null
        )
        set(profilePicUrl) {
            mPrefs.edit().putString(
                PREF_KEY_CURRENT_USER_IMAGE_URL, profilePicUrl
            ).apply()
        }

    // User token
    var token: String?
        get() = mPrefs.getString(
            PREF_KEY_TOKEN, null
        )
        set(strToken) {
            mPrefs.edit().putString(
                PREF_KEY_TOKEN, strToken
            ).apply()
        }

    // User address
    var address: String?
        get() = mPrefs.getString(
            PREF_KEY_CURRENT_USER_ADDRESS, null
        )
        set(address) {
            mPrefs.edit().putString(
                PREF_KEY_CURRENT_USER_ADDRESS, address
            ).apply()
        }

    // User building
    var building: String?
        get() = mPrefs.getString(
            PREF_KEY_CURRENT_USER_BUILDING, null
        )
        set(building) {
            mPrefs.edit().putString(
                PREF_KEY_CURRENT_USER_BUILDING, building
            ).apply()
        }

    // User token
    var dob: String?
        get() = mPrefs.getString(
            PREF_KEY_DATE_OF_BIRTH, null
        )
        set(dob) {
            mPrefs.edit().putString(
                PREF_KEY_DATE_OF_BIRTH, dob
            ).apply()
        }

    // User token
    var dialCode: String?
        get() = mPrefs.getString(
            PREF_KEY_DIAL_CODE, null
        )
        set(dialCode) {
            mPrefs.edit().putString(
                PREF_KEY_DIAL_CODE, dialCode
            ).apply()
        }

    // User token
    var dialCodeId: String?
        get() = mPrefs.getString(
            PREF_KEY_DIAL_CODE_ID, null
        )
        set(dialCodeId) {
            mPrefs.edit().putString(
                PREF_KEY_DIAL_CODE_ID, dialCodeId
            ).apply()
        }

    // User token
    var electronicID: String?
        get() = mPrefs.getString(
            PREF_KEY_ELECTRONIC_ID, null
        )
        set(dialCode) {
            mPrefs.edit().putString(
                PREF_KEY_ELECTRONIC_ID, dialCode
            ).apply()
        }

    // User token
    var gcmID: String?
        get() = mPrefs.getString(
            PREF_KEY_GCM_ID, null
        )
        set(gcmID) {
            mPrefs.edit().putString(
                PREF_KEY_GCM_ID, gcmID
            ).apply()
        }

    // User token
    var genderId: Int
        get() = mPrefs.getInt(
            PREF_KEY_GENDER_ID, 0
        )
        set(genderId) {
            mPrefs.edit().putInt(
                PREF_KEY_GENDER_ID, genderId
            ).apply()
        }

    // User token
    var identification: String?
        get() = mPrefs.getString(
            PREF_KEY_IDENTIFICATION, null
        )
        set(identification) {
            mPrefs.edit().putString(
                PREF_KEY_IDENTIFICATION, identification
            ).apply()
        }


    // User token
    var idType: String?
        get() = mPrefs.getString(
            PREF_KEY_IDENTIFICATION_TYPE, null
        )
        set(idType) {
            mPrefs.edit().putString(
                PREF_KEY_IDENTIFICATION_TYPE, idType
            ).apply()
        }

    // User token
    var insuranceCompanyId: String?
        get() = mPrefs.getString(
            PREF_KEY_INSURANCE_COMPANY_ID, null
        )
        set(insuranceCompanyId) {
            mPrefs.edit().putString(
                PREF_KEY_INSURANCE_COMPANY_ID, insuranceCompanyId
            ).apply()
        }

    // User token
    var insurancePolicyNumber: String?
        get() = mPrefs.getString(
            PREF_KEY_INSURANCE_POLICY_NUMBER, null
        )
        set(insurancePolicyNumber) {
            mPrefs.edit().putString(
                PREF_KEY_INSURANCE_POLICY_NUMBER, insurancePolicyNumber
            ).apply()
        }

    // User token
    var language: String?
        get() = mPrefs.getString(
            PREF_KEY_LANGUAGE, "en"
        )
        set(language) {
            mPrefs.edit().putString(
                PREF_KEY_LANGUAGE, language
            ).apply()
        }

    // User token
    var latitude: String?
        get() = mPrefs.getString(
            PREF_KEY_LATITUDE, null
        )
        set(latitude) {
            mPrefs.edit().putString(
                PREF_KEY_LATITUDE, latitude
            ).apply()
        }

    // User token
    var longitude: String?
        get() = mPrefs.getString(
            PREF_KEY_LONGITUDE, null
        )
        set(longitude) {
            mPrefs.edit().putString(
                PREF_KEY_LONGITUDE, longitude
            ).apply()
        }

    // User token
    var nationality: String?
        get() = mPrefs.getString(
            PREF_KEY_NATIONALITY, null
        )
        set(nationality) {
            mPrefs.edit().putString(
                PREF_KEY_NATIONALITY, nationality
            ).apply()
        }

    // User token
    var nationalityID: Int
        get() = mPrefs.getInt(
            PREF_KEY_NATIONALITY_ID, 0
        )
        set(nationality) {
            mPrefs.edit().putInt(
                PREF_KEY_NATIONALITY_ID, nationality
            ).apply()
        }

    // User token
    var nearest: String?
        get() = mPrefs.getString(
            PREF_KEY_NEAREST, null
        )
        set(nationality) {
            mPrefs.edit().putString(
                PREF_KEY_NEAREST, nationality
            ).apply()
        }

    // User token
    var resetPasswordFlag: String?
        get() = mPrefs.getString(
            PREF_KEY_RESET_PASSWORD_FLAG, null
        )
        set(nationality) {
            mPrefs.edit().putString(
                PREF_KEY_RESET_PASSWORD_FLAG, nationality
            ).apply()
        }

    // User token
    var signUpDate: String?
        get() = mPrefs.getString(
            PREF_KEY_SIGN_UP_DATE, null
        )
        set(nationality) {
            mPrefs.edit().putString(
                PREF_KEY_SIGN_UP_DATE, nationality
            ).apply()
        }

    // User token
    var statusID: Int
        get() = mPrefs.getInt(
            PREF_KEY_STATUS_ID, 0
        )
        set(nationality) {
            mPrefs.edit().putInt(
                PREF_KEY_STATUS_ID, nationality
            ).apply()
        }

    // User token
    var systemModuleId: String?
        get() = mPrefs.getString(
            PREF_KEY_SYSTEM_MODULE_ID, null
        )
        set(nationality) {
            mPrefs.edit().putString(
                PREF_KEY_SYSTEM_MODULE_ID, nationality
            ).apply()
        }

    // User Cart Count
    var userCartCount: Int
        get() = mPrefs.getInt(
            PREF_KEY_USER_CART_COUNT, 0
        )
        set(count) {
            mPrefs.edit().putInt(
                PREF_KEY_USER_CART_COUNT, count
            ).apply()
            EventBus.getDefault().post(MessageEvent(AppConstants.MESSAGE_CART_CHANGED))
        }


    // User token
    var floorNo: String?
        get() = mPrefs.getString(
            PREF_KEY_FLOOR_NO, null
        )
        set(nationality) {
            mPrefs.edit().putString(
                PREF_KEY_FLOOR_NO, nationality
            ).apply()
        }

    enum class LoggedInMode(val type: Int) {
        LOGGED_IN_MODE_LOGGED_OUT(0), LOGGED_IN_MODE_GOOGLE(1), LOGGED_IN_MODE_FB(2), LOGGED_IN_MODE_SERVER(
            3
        );

        companion object {
            fun fromInt(value: Int) = LoggedInMode.values().first { it.ordinal == value }
        }
    }

}