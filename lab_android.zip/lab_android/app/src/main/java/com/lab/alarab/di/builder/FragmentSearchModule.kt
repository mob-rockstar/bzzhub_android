package com.lab.alarab.di.builder

import com.lab.alarab.ui.search.notification.NotificationFragment
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class FragmentSearchModule {
    @ContributesAndroidInjector
    abstract fun contributeNotificationFragment(): NotificationFragment
}