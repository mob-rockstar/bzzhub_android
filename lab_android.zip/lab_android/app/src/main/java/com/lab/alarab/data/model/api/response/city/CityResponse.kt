package com.lab.alarab.data.model.api.response.city

data class CityResponse(
    val errorMessage: Any,
    val httpStatus: Int,
    val response: List<Response>,
    val success: Boolean,
    val timestamp: Int
)