package com.lab.alarab.base

import com.lab.alarab.data.model.api.response.ErrorResponse

interface HandleResponse<T> {

    fun handleErrorResponse(error: ErrorResponse?)
    fun handleSuccessRespons(successResponse: T)

}