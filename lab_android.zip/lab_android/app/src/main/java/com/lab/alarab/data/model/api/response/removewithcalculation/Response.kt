package com.lab.alarab.data.model.api.response.removewithcalculation


import com.google.gson.annotations.SerializedName

data class Response(
    var coupon: String,
    @SerializedName("discount_amount")
    var discountAmount: Int,
    @SerializedName("discount_percetnage")
    var discountPercetnage: String,
    @SerializedName("fees_amount")
    var feesAmount: Int,
    @SerializedName("net_total")
    var netTotal: Int,
    var packages: List<Any>,
    @SerializedName("packages_amount")
    var packagesAmount: Int,
    @SerializedName("packages_count")
    var packagesCount: Int,
    @SerializedName("tax_amount")
    var taxAmount: Int,
    @SerializedName("wallet_amount")
    var walletAmount: Int
)