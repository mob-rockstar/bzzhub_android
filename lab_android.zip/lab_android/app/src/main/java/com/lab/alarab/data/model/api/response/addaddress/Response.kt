package com.lab.alarab.data.model.api.response.addaddress


import com.google.gson.annotations.SerializedName

data class Response(
    @SerializedName("ADDRESS_INFO")
    var aDDRESSINFO: String,
    @SerializedName("ADDRESS_TITLE_ID")
    var aDDRESSTITLEID: Int,
    @SerializedName("ADDRESS_TYPE_ID")
    var aDDRESSTYPEID: Int,
    @SerializedName("CITY")
    var cITY: String,
    @SerializedName("END_USER_ID")
    var eNDUSERID: Int,
    @SerializedName("ID")
    var iD: Int,
    @SerializedName("IS_DEFAULT")
    var iSDEFAULT: Int,
    @SerializedName("LAND_MARK")
    var lANDMARK: String,
    @SerializedName("LATITUDE")
    var lATITUDE: String,
    @SerializedName("LONGITUDE")
    var lONGITUDE: String,
    @SerializedName("STREET_ADDRESS")
    var sTREETADDRESS: String
)