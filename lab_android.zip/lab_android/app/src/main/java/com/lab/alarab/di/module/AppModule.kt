package com.lab.alarab.di.module

import android.content.Context
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.lab.alarab.ArabLabApp
import com.lab.alarab.R
import com.lab.alarab.base.navigator.ActivityNavigator
import com.lab.alarab.base.navigator.ChildFragmentNavigator
import com.lab.alarab.base.navigator.FragmentNavigator
import com.lab.alarab.base.navigator.Navigator
import com.lab.alarab.utils.rx.AppSchedulerProvider
import com.lab.alarab.utils.rx.SchedulerProvider
import dagger.Module
import dagger.Provides
import io.github.inflationx.calligraphy3.CalligraphyConfig
import io.reactivex.disposables.CompositeDisposable
import javax.inject.Singleton

@Module
class AppModule {


    @Provides
    @Singleton
    fun provideCalligraphyDefaultConfig(): CalligraphyConfig {
        return CalligraphyConfig.Builder()
//            .setDefaultFontPath("fonts/OpenSans-Regular.ttf")
            .setFontAttrId(R.attr.fontPath)
            .build()
    }

    @Provides
    @Singleton
    fun provideContext(application: ArabLabApp): Context {
        return application
    }

    @Provides
    @Singleton
    fun provideCompositeDisposable(): CompositeDisposable {
        return CompositeDisposable()
    }


    @Provides
    @Singleton
    fun provideGson(): Gson? {
        return GsonBuilder().excludeFieldsWithoutExposeAnnotation().create()
    }

    @Provides
    fun provideSchedulerProvider(): SchedulerProvider {
        return AppSchedulerProvider()
    }

    @Provides
    @Singleton
    fun provideNavigator(activityNavigator: ActivityNavigator): Navigator {
        return activityNavigator
    }

    @Provides
    @Singleton
    fun provideFragmentNavigator(childFragmentNavigator: ChildFragmentNavigator): FragmentNavigator {
        return childFragmentNavigator
    }
}