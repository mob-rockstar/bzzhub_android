package com.lab.alarab.utils

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.*

object FormatterUtils {
    // Format Double Price
    fun formatDouble(value: Float?): String {
        val otherSymbols = DecimalFormatSymbols(Locale.US)
        otherSymbols.decimalSeparator = '.'
        val mFormat = DecimalFormat("#.##", otherSymbols)
        return mFormat.format(value)
    }

}