package com.lab.alarab.ui.forgotpassword

import com.lab.alarab.base.BaseViewModel
import com.lab.alarab.base.HandleResponse
import com.lab.alarab.data.model.api.response.SignInResponse
import com.lab.alarab.data.model.api.response.VerifyMobileResponse
import com.lab.alarab.data.remote.APIManager
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class ForgotPasswordViewModel : BaseViewModel(){
    var strMobile = ""
    var strCountryCode = ""


    // API to verify Mobile
    fun verifyMobileNumber(
        handleResponse: HandleResponse<VerifyMobileResponse>
    ) {
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.signInUpdateMobileNo(strCountryCode, strMobile)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }

    // API to signin with OTP
    fun verifyUpdateMobileNo(otp: String, handleResponse: HandleResponse<SignInResponse>) {
        setIsLoading(true)
        compositeDisposable.add(
            APIManager.verifyUpdateMobileNo(strCountryCode, strMobile, otp)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { result ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleSuccessRespons(result)
                        }
                    },
                    { x ->
                        run {
                            setIsLoading(false)
                            handleResponse.handleErrorResponse(getThrowableError(x))
                        }
                    }
                ))
    }
}
