package utils

public interface KeyboardVisibilityListener {
    fun onKeyboardVisibilityChanged(keyboardVisible: Boolean)
}