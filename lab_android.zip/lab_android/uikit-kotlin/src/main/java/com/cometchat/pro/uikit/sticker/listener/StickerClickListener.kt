package com.cometchat.pro.uikit.sticker.listener

import com.cometchat.pro.uikit.sticker.model.Sticker

interface StickerClickListener {
    fun onClickListener(sticker: Sticker?)
}