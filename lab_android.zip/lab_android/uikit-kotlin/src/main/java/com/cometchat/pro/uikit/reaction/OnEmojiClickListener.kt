package com.cometchat.pro.uikit.reaction

import com.cometchat.pro.uikit.reaction.model.Reaction

interface OnEmojiClickListener {
    fun onEmojiClicked(emojicon: Reaction)
}