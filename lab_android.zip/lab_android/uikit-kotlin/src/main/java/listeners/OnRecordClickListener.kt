package listeners

import android.view.View

interface OnRecordClickListener {
    fun onClick(v: View?)
}