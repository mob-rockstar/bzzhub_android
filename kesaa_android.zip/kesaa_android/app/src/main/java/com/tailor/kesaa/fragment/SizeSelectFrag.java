package com.tailor.kesaa.fragment;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import de.hdodenhof.circleimageview.CircleImageView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.tailor.kesaa.customs.CustomFontButton;
import com.tailor.kesaa.customs.CustomFontTextView;
import com.tailor.kesaa.MainActivity;
import com.tailor.kesaa.R;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link SizeSelectFrag.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link SizeSelectFrag#newInstance} factory method to
 * create an instance of this fragment.
 */
public class SizeSelectFrag extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    public MainActivity masterActivity;
    private OnFragmentInteractionListener mListener;
    public int selected_size = -1;

    public View frag_view;

    @BindView(R.id.left_size_btn)
    public CustomFontButton small_btn;

    @BindView(R.id.mid_size_btn)
    public CustomFontButton med_btn;

    @BindView(R.id.right_size_btn)
    public CustomFontButton lrg_btn;

    @BindView(R.id.btn_confirm_size)
    CustomFontButton confirmButton;

    public Drawable selectedBack;
    public Drawable deselectedBack;

    @BindView(R.id.size_description_text)
    CustomFontTextView sizeDescriptionView;

    @BindView(R.id.size_layout)
    LinearLayout sizeInfoView;

    private RequestOptions requestOptions;

    public SizeSelectFrag() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment SizeSelectFrag.
     */
    // TODO: Rename and change types and number of parameters
    public static SizeSelectFrag newInstance(String param1, String param2) {
        SizeSelectFrag fragment = new SizeSelectFrag();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        masterActivity = (MainActivity) getActivity();
        if (masterActivity != null){
            masterActivity.showActionBar();
            masterActivity.currentSession.session_has_moved_past_init = true;
        }

        if (masterActivity != null) {
            masterActivity.setFragTitle(getString(R.string.meas_cust_title));

            // Firebase analytics event
            Bundle bundle = new Bundle();
            bundle.putString(FirebaseAnalytics.Param.SCREEN_NAME, "Confirm Size");
            bundle.putString(FirebaseAnalytics.Param.SCREEN_CLASS, getClass().getSimpleName());
            masterActivity.mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SCREEN_VIEW, bundle);
        }

        // Inflate the layout for this fragment
        frag_view =  inflater.inflate(R.layout.fragment_size_select, container, false);
        ButterKnife.bind(this, frag_view);

        // Hide info view
        sizeInfoView.setVisibility(View.INVISIBLE);


        CircleImageView style_image = frag_view.findViewById(R.id.size_sel_style_image);
        TextView style_text = frag_view.findViewById(R.id.size_sel_style_text);
        TextView style_descr = frag_view.findViewById(R.id.size_sel_style_descr);


        requestOptions = new RequestOptions();
        requestOptions.placeholder(R.drawable.ic_saudi_style);
        requestOptions.error(R.drawable.ic_saudi_style);

        // Display the selected thobe details
        if (masterActivity != null) {
            if (masterActivity.currentOrderItem.selectedThobe != null){
                Glide.with(masterActivity).load(masterActivity.currentOrderItem.selectedThobe.getImage()).apply(requestOptions).into(style_image);

                // Show error message
                if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                    style_text.setText(masterActivity.currentOrderItem.selectedThobe.getEnglishName());
                    style_descr.setText(masterActivity.currentOrderItem.selectedThobe.getEnglishDescription());
                }
                else{
                    style_text.setText(masterActivity.currentOrderItem.selectedThobe.getArabicName());
                    style_descr.setText(masterActivity.currentOrderItem.selectedThobe.getArabicDescription());
                }

            }

        }


        selectedBack = getResources().getDrawable(R.drawable.br_btn_round,null);
        deselectedBack =  getResources().getDrawable(R.drawable.white_btn_round,null);

//
        // Set button style
        setButtonAppearance();

        if (masterActivity.currentOrderItem.order_size >= 0){
            sizeInfoView.setVisibility(View.VISIBLE);
        }
        else{
            sizeInfoView.setVisibility(View.INVISIBLE);
        }

        scaleButtonToDevice();

        return frag_view;
    }

    @OnClick(R.id.btn_confirm_size) void confirmSize(){
        if (masterActivity.currentOrderItem.order_size >= 0){
            Navigation.findNavController(confirmButton).navigate(R.id.action_sizeSelectFrag_to_customizeStyleFragment);
        }
    }

    public void scaleButtonToDevice(){

        int width;
        int height;

        float button_scaler = 1.0f;

        if (masterActivity != null) {

            width = masterActivity.master_screen_width;
            height = masterActivity.master_screen_height;


            if (width >= 1079) {
                button_scaler = 1.0f ;
            } else {
                button_scaler = 0.80f;
            }


            ViewGroup.LayoutParams lParams = small_btn.getLayoutParams();
            lParams.width = Math.round(lParams.width*button_scaler);
            lParams.height = Math.round(lParams.height*button_scaler);
            small_btn.setLayoutParams(lParams);

            lParams = med_btn.getLayoutParams();
            lParams.width = Math.round(lParams.width*button_scaler);
            lParams.height = Math.round(lParams.height*button_scaler);
            med_btn.setLayoutParams(lParams);

            lParams = lrg_btn.getLayoutParams();
            lParams.width = Math.round(lParams.width*button_scaler);
            lParams.height = Math.round(lParams.height*button_scaler);
            lrg_btn.setLayoutParams(lParams);

        }

    }


    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    // Size S
    @OnClick(R.id.left_size_btn) void selectedSizeS(){

        sizeInfoView.setVisibility(View.VISIBLE);

        masterActivity.currentOrderItem.order_size = 0;

        // update size description
        if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH) {
            sizeDescriptionView.setText(masterActivity.currentOrderItem.selectedThobe.enSmallSize);
        }
        else{
            sizeDescriptionView.setText(masterActivity.currentOrderItem.selectedThobe.arSmallSize);
        }


        setButtonAppearance();
    }

    // Size M
    @OnClick(R.id.mid_size_btn) void selectedSizeM(){
        sizeInfoView.setVisibility(View.VISIBLE);

        masterActivity.currentOrderItem.order_size = 1;

        // update size description
//        sizeDescriptionView.setText(getString(R.string.size_m_description));
        if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH) {
            sizeDescriptionView.setText(masterActivity.currentOrderItem.selectedThobe.enMediumSize);
        }
        else{
            sizeDescriptionView.setText(masterActivity.currentOrderItem.selectedThobe.arMediumSize);
        }

        setButtonAppearance();
    }

    // Size L
    @OnClick(R.id.right_size_btn) void selectedSizeL(){
        sizeInfoView.setVisibility(View.VISIBLE);

        masterActivity.currentOrderItem.order_size = 2;

        // update size description
//        sizeDescriptionView.setText(getString(R.string.size_l_description));
        if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH) {
            sizeDescriptionView.setText(masterActivity.currentOrderItem.selectedThobe.enLargeSize);
        }
        else{
            sizeDescriptionView.setText(masterActivity.currentOrderItem.selectedThobe.arLargeSize);
        }

        setButtonAppearance();
    }


    public void setButtonAppearance() {

        //Button states should already be set and checkSessionOrder true before calling this

        switch (masterActivity.currentOrderItem.order_size) {

            case 0:
                setSmallSizeAppearance();
                break;
            case 1:
                setMedSizeAppearance();
                break;
            case 2:
                setLargeSizeAppearance();
                break;
            default:
                setNoSizeAppearance();
                break;
        }

    }

    public void setNoSizeAppearance() {
        small_btn.setBackgroundResource(R.drawable.white_btn_round);
        med_btn.setBackgroundResource(R.drawable.white_btn_round);
        lrg_btn.setBackgroundResource(R.drawable.white_btn_round);

        small_btn.setTextColor(Color.parseColor("#000000"));
        med_btn.setTextColor(Color.parseColor("#000000"));
        lrg_btn.setTextColor(Color.parseColor("#000000"));

        sizeDescriptionView.setVisibility(View.GONE);

    }

    public void setSmallSizeAppearance() {
        small_btn.setBackground(selectedBack);
        med_btn.setBackground(deselectedBack);
        lrg_btn.setBackground(deselectedBack);


        small_btn.setTextColor(Color.parseColor("#FFFFFF"));
        med_btn.setTextColor(Color.parseColor("#000000"));
        lrg_btn.setTextColor(Color.parseColor("#000000"));

        sizeDescriptionView.setVisibility(View.VISIBLE);
//        sizeDescriptionView.setText(getString(R.string.size_s_description));
        if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH) {
            sizeDescriptionView.setText(masterActivity.currentOrderItem.selectedThobe.enSmallSize);
        }
        else{
            sizeDescriptionView.setText(masterActivity.currentOrderItem.selectedThobe.arSmallSize);
        }
    }

    public void setMedSizeAppearance() {
        small_btn.setBackground(deselectedBack);
        med_btn.setBackground(selectedBack);
        lrg_btn.setBackground(deselectedBack);


        small_btn.setTextColor(Color.parseColor("#000000"));
        med_btn.setTextColor(Color.parseColor("#FFFFFF"));
        lrg_btn.setTextColor(Color.parseColor("#000000"));

        sizeDescriptionView.setVisibility(View.VISIBLE);
//        sizeDescriptionView.setText(getString(R.string.size_m_description));
        if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH) {
            sizeDescriptionView.setText(masterActivity.currentOrderItem.selectedThobe.enMediumSize);
        }
        else{
            sizeDescriptionView.setText(masterActivity.currentOrderItem.selectedThobe.arMediumSize);
        }
    }


    public void setLargeSizeAppearance() {
        small_btn.setBackground(deselectedBack);
        med_btn.setBackground(deselectedBack);
        lrg_btn.setBackground(selectedBack);

        small_btn.setTextColor(Color.parseColor("#000000"));
        med_btn.setTextColor(Color.parseColor("#000000"));
        lrg_btn.setTextColor(Color.parseColor("#FFFFFF"));

        sizeDescriptionView.setVisibility(View.VISIBLE);
//        sizeDescriptionView.setText(getString(R.string.size_l_description));
        if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH) {
            sizeDescriptionView.setText(masterActivity.currentOrderItem.selectedThobe.enLargeSize);
        }
        else{
            sizeDescriptionView.setText(masterActivity.currentOrderItem.selectedThobe.arLargeSize);
        }
    }

    public boolean checkSessionOrder(){
        boolean all_set_ok = false;

        if ( masterActivity.currentSession != null) {
            masterActivity.currentSession.lastMainLineScreen ="sizeSelect";
            if (masterActivity.currentOrderItem != null) {
                all_set_ok = true;

            } else {
                Toast err_toast = Toast.makeText(getContext(),R.string.error_order_init,Toast.LENGTH_LONG);
                err_toast.show();
            }
        } else {
            Toast err_toast = Toast.makeText(getContext(),R.string.error_session_init,Toast.LENGTH_LONG);
            err_toast.show();
        }

        return all_set_ok;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void setFragTitle(String newTitle);
        void onFragmentInteraction(Uri uri);
    }
}
