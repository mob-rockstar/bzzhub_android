package com.tailor.kesaa.model;

public class Section {

    private final String name;

    public boolean isExpanded;
    public boolean isFilled;


    public Section(String name) {
        this.name = name;
        isExpanded = true;
        isFilled= false;


    }

    public String getName() {
        return name;
    }
}
