package com.tailor.kesaa.model;

public class TimelineDataElements {
    public float alphaLevel;
    public int checkType;
    public int lineType;
    public int timeLineIcon;
    public String timeLineText;

    public TimelineDataElements(int checkType, int lineType, int timeLineIcon, String timeLineText, float alphaLevel) {

        this.alphaLevel = alphaLevel;
        this.checkType = checkType;
        this.lineType = lineType;
        this.timeLineIcon = timeLineIcon;
        this.timeLineText = timeLineText;
    }


}
