package com.tailor.kesaa.model;

import com.tailor.kesaa.model.thobe.ThobeStyleData;

import java.util.Map;

public class OrderReviewDetails {

    public float order_item_price;
    public float order_shipping_price;
    public float order_total_price;

    // Thobe
    public int order_thobe_style;
    public ThobeStyleData selectedThobe;

    public String order_tailor_name;

    public int order_tailor_id;
    public int order_qty;

//    public int order_fabric_type;
//    public int order_collar_type;
//    public int order_cuffs_type;
//    public int order_placket_type;
//    public int order_pocket_type;
//    public int order_sidepocket_type;

    public String order_fabric_str;
    public String order_collar_str;
    public String order_cuffs_str;
    public String order_placket_str;
    public String order_pocket_str;
    public String order_sidepocket_str;


    public String order_address_line;
    public String order_measure_sched_time;

    // time slot id
    public int order_time_id;

    // Delivery instructions
    public String deliveryInstructions = "";

    // Options
//    public CustomizeOptionElement fabricOption;
//    public CustomizeOptionElement cuffOption;
//    public CustomizeOptionElement collarOption;
//    public CustomizeOptionElement pocketOption;
//    public CustomizeOptionElement placketOption;
//    public CustomizeOptionElement sidePocketOption;
    public Map<Integer, CustomizeOptionElement> selectedOptionsMap;

}
