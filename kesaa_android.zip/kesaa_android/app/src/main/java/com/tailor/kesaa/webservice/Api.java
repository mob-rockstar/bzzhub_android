package com.tailor.kesaa.webservice;

import com.google.gson.JsonObject;
import com.tailor.kesaa.model.AddressListData;
import com.tailor.kesaa.model.NewAddressDataResponse;
import com.tailor.kesaa.model.faq.FaqListResponse;
import com.tailor.kesaa.model.notification.NotificationListReponse;
import com.tailor.kesaa.model.order.OrderListResponse;
import com.tailor.kesaa.model.style.OptionListResponse;
import com.tailor.kesaa.model.tailor.CommentListResponse;
import com.tailor.kesaa.model.tailor.TailorListResponse;
import com.tailor.kesaa.model.thobe.ThobeStyleListResponse;
import com.tailor.kesaa.model.user.UserResponseData;

import java.util.HashMap;

import io.reactivex.Observable;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface Api {

    // URLs
//    String BASE_URL = "http://harrierlabs.com/kessa/admin/"; //
    String BASE_URL = "http://portal.kesaathobes.com:3000/";


    // Get user details with firebase ID
    @POST("api/user/new")
    Observable<UserResponseData> getUserDetails(@Body RequestBody body);

    // Create new address
    @POST("api/address/new")
    Observable<NewAddressDataResponse> createNewAddress(@Body RequestBody body);

    // Update Address
    @POST("api/address/update")
    Observable<NewAddressDataResponse> updateAddress(@Body RequestBody body);

    // Get address list
    @POST("api/address/list/user/{userId}")
    Observable<AddressListData> getAddressList(@Path("userId") String userId);

    // Delete address
    @POST("api/address/delete/{addressId}")
    Observable<JsonObject> deleteAddress(@Path("addressId") String addressId);

    // Update user address
    @GET("validated/customer_control_master.php")
    Observable<JsonObject> updateAddressList(@Query("func") int funcValue, @Query("addressJSON") String addressJson, @Query("user_id") String userId, @Query("user_uid") String userFirebaseId);

    // Update user details
    @POST("api/user/update")
    Observable<JsonObject> updateUserDetails(@Body RequestBody body);

    // Get user details
    @POST("api/user/profile/{userId}")
    Observable<UserResponseData> getUserCredentialsWithId(@Path("userId") String userId);

    // Get thobe styles
    @POST("api/style/list/enabled")
    Observable<ThobeStyleListResponse> getThobeStyles();

    // Get options
    @GET("api/option/listall/{styleId}")
    Observable<OptionListResponse> getCustomOptions(@Path("styleId") String styleId);

    // Get timeslots
    @GET("api/timeslot/{dateString}")
    Observable<JsonObject> getTimeSlots(@Path("dateString") String dateStr);

    // Get tailors
    @POST("api/tailor/details")
//    Observable<TailorListResponse> getTailors(@Body RequestBody body);
    Observable<TailorListResponse> getTailors(@Body HashMap<String, Object> body);

    // Get comments of tailor
    @GET("api/review/tailor/{tailorId}")
    Observable<CommentListResponse> getComments(@Path("tailorId") String tailorId);

    // Get Faq list
    @GET("api/faq/list/enabled")
    Observable<FaqListResponse> getFaqList();

    // Create new order
    @POST("api/order/new")
    Observable<JsonObject> createNewOrder(@Body HashMap<String, Object> body);

    // Get order history
    @POST("api/order/list/user")
    Observable<OrderListResponse> getOrderHistory(@Body RequestBody body);

    // Get order details
    @GET("api/order/details/{orderId}")
    Observable<JsonObject> getOrderDetails(@Path("orderId") String orderId);

    // Get notifications
    @POST("api/notification/list")
    Observable<NotificationListReponse> getNotifications(@Body RequestBody body);

    // Rate tailor
    @POST("api/review/new")
    Observable<JsonObject> rateTailor(@Body RequestBody body);

    // Get Checkout ID
    @POST("api/order/checkout")
    Observable<JsonObject> requestCheckoutID(@Body HashMap<String, Object> body);

    // Get payment status
    @POST("api/order/status")
    Observable<JsonObject> getPaymentStatus(@Body HashMap<String, Object> body);

    // Check coupon
    @POST("api/coupon/check")
    Observable<JsonObject> checkCoupon(@Body HashMap<String, Object> body);

}
