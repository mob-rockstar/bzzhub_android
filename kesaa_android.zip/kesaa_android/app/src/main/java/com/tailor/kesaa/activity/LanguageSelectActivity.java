package com.tailor.kesaa.activity;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;

import com.tailor.kesaa.R;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;

import butterknife.ButterKnife;
import butterknife.OnClick;

public class LanguageSelectActivity extends KessaActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.fragment_lang_select);

        ButterKnife.bind(this);

        // Set the default locale
        changeLocale("en","US");

//        if (MyPreferenceManager.getInstance(this).getBoolean(SettingsKeys.KEY_IS_LOGGED)) {
//            if (MyPreferenceManager.getInstance(this).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
//                changeLocale("en","US");
//            }
//            else{
//                changeLocale("ar","SA");
//            }
//        }
    }

    // English
    @OnClick(R.id.btn_lang_eng) void selectedEnglish(){
        MyPreferenceManager.getInstance(this).put(SettingsKeys.KEY_CURRENT_LANGUAGE, SettingsKeys.KEY_ENGLISH);
        changeLocale("en","US");
        gotoLoginPage();
    }

    // Arabic
    @OnClick(R.id.btn_lang_arabic) void selectedArabic(){
        MyPreferenceManager.getInstance(this).put(SettingsKeys.KEY_CURRENT_LANGUAGE, SettingsKeys.KEY_ARABIC);
        changeLocale("ar","SA");
        gotoLoginPage();
    }

    // go to login page
    private void gotoLoginPage(){
        Intent intent = new Intent(LanguageSelectActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }


}
