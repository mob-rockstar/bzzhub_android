package com.tailor.kesaa.model;

public class WeekDayDetails {

    public String dayName;
    public int dayDate;
    public boolean isSelected;

}
