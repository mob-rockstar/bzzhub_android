package com.tailor.kesaa.model;

import com.google.android.gms.maps.model.LatLng;

public class LocationTemplate {
    public int addrType =0; //0 = home, 1 = work, 2 = other
    public String unitNum = "";
    public String addrLine1= "";
    public String addrLine2= "";
    public String addr_phone= "";
    public String city= "";
    public String zipCode= "";
    public String region= "";
    public LatLng latLng;
    public boolean addrValid = false;
    public boolean defaultSet = false;
}
