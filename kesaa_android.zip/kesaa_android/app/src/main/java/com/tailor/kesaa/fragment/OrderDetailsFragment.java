package com.tailor.kesaa.fragment;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Point;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import company.tap.gosellapi.open.buttons.PayButtonView;
import company.tap.gosellapi.open.controllers.SDKSession;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import okhttp3.RequestBody;

import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.tailor.kesaa.KesaaApplication;
import com.tailor.kesaa.adapter.OrderedOptionsGridAdapter;
import com.tailor.kesaa.customs.CustomFontButton;
import com.tailor.kesaa.customs.CustomFontEditText;
import com.tailor.kesaa.customs.CustomFontTextView;
import com.tailor.kesaa.global.AllHelpers;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;
import com.tailor.kesaa.model.CustomizeOptionElement;
import com.tailor.kesaa.MainActivity;
import com.tailor.kesaa.model.order.OrderHistoryDetails;
import com.tailor.kesaa.R;
import com.tailor.kesaa.global.SettingsManager;
import com.tailor.kesaa.adapter.TimelineDataAdapter;
import com.tailor.kesaa.model.TimelineDataElements;
import com.tailor.kesaa.widgets.ExpandableHeightGridView;
import com.iarcuschin.simpleratingbar.SimpleRatingBar;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link OrderDetailsFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link OrderDetailsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class OrderDetailsFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    public String TAG = "ORDET";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public MainActivity masterActivity;
    public View frag_view;

    private RecyclerView timelineView;
    private RecyclerView.Adapter timelineAdapter;
    private RecyclerView.LayoutManager timelineLayoutManager;

    private OnFragmentInteractionListener mListener;

    public ArrayList<TimelineDataElements>  currentOrderTimeline;
    public ArrayList<OrderHistoryDetails> orderReviewArray;

    private TextView styleName;
    private TextView tailorName;
    private TextView orderQty;
    private TextView orderTotalPrice;
    private TextView orderSnHPrice;
    private TextView transOrderID;
    private TextView nextOrderDate;

    public PayButtonView payButtonView;

    private CustomFontButton rateButton;

    private final int SDK_REQUEST_CODE = 1001;
    private SDKSession sdkSession;
    private SettingsManager settingsManager;

    private ImageView styleOptionPic;


    private List<CustomizeOptionElement> orderedOptions = new ArrayList<>();

    // Delivery days
    int deliveryDays = 0;

    @BindView(R.id.progressBar)
    ProgressBar progressBar;

    @BindView(R.id.options_grid)
    ExpandableHeightGridView optionsGrid;

    OrderedOptionsGridAdapter gridAdapter;

    // Delivery Time
    String deliveryTimeString = "";

    public OrderDetailsFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment OrderDetailsFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static OrderDetailsFragment newInstance(String param1, String param2) {
        OrderDetailsFragment fragment = new OrderDetailsFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        Display display =  getActivity().getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int width = size.x;
        int height = size.y;

        settingsManager = SettingsManager.getInstance();
        settingsManager.setPref(getContext());


        masterActivity = (MainActivity) getActivity();

        frag_view = inflater.inflate(R.layout.fragment_order_details, container, false);
        ButterKnife.bind(this, frag_view);

        styleName            = frag_view.findViewById(R.id.order_detail_style_name_text);
        nextOrderDate        = frag_view.findViewById(R.id.order_detail_next_date);

        // rate
        rateButton        =  frag_view.findViewById(R.id.btn_rate_tailor);
        if (masterActivity.currentSession.currentOrderOfInterest.order_status >= 5) {
            rateButton.setVisibility(View.VISIBLE);
        }
        else{
            rateButton.setVisibility(View.GONE);
        }

        transOrderID = frag_view.findViewById(R.id.order_detail_order_id);
        tailorName = frag_view.findViewById(R.id.order_detail_tailor_name);
        orderTotalPrice = frag_view.findViewById(R.id.order_detail_item_price_value_text);
        styleOptionPic = frag_view.findViewById(R.id.order_detail_style_pic);

        if (masterActivity != null) {
            if (masterActivity.master_screen_width <= 760) {
                styleName.setTextSize(16.0f);
                transOrderID.setTextSize(10.0f);
                tailorName.setTextSize(10.0f);
                nextOrderDate.setTextSize(10.0f);
            }
        }

        if (masterActivity != null) {

//            getStoredOptions();

            timelineView = (RecyclerView) frag_view.findViewById(R.id.order_detail_timeline);
            timelineView.setHasFixedSize(true);
            timelineStatusSetter(3);
            timelineLayoutManager = new LinearLayoutManager(getContext(),
                    LinearLayoutManager.HORIZONTAL, false);
            timelineView.setLayoutManager(timelineLayoutManager);

            timelineAdapter = new TimelineDataAdapter(getContext(),currentOrderTimeline ,width, height, masterActivity.currentSession.currentOrderOfInterest.order_status );
            timelineView.setAdapter(timelineAdapter);
            timelineAdapter.notifyDataSetChanged();

            if (masterActivity.currentSession.currentOrderOfInterest != null) {

                String orderStyle = Integer.toString(masterActivity.currentSession.currentOrderOfInterest.order_thobe_style);

                double finalCost = (masterActivity.currentSession.currentOrderOfInterest.order_total_price + 30) * 1.05;
                String orderPrice= Float.toString(masterActivity.currentSession.currentOrderOfInterest.order_total_price);
//                Toast.makeText(getContext(), "Type : " + orderStyle + " @ " + orderPrice + " SAR",Toast.LENGTH_LONG).show();
            }


            // Set the title
            if (mListener != null) {
                String orderNoString = "#" + masterActivity.currentSession.currentOrderOfInterest.order_id;
                mListener.setFragTitle(getString(R.string.order_format, orderNoString));
            }

            // Get order details from server
            loadOrderDetails();
        }

        return frag_view;
    }

    @OnClick(R.id.btn_rate_tailor)
    public void showRatePopup(){
        try {
            Dialog dialog = new Dialog(masterActivity);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView(R.layout.dialog_rate_tailor);
            dialog.getWindow().setBackgroundDrawableResource(R.drawable.empty);
            dialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);

            // Tailor Name
            CustomFontTextView nameText = dialog.findViewById(R.id.tailor_name_text);
            nameText.setText(tailorName.getText().toString().trim());

            // Comment
            CustomFontEditText commentText = dialog.findViewById(R.id.comment_edit);

            // Rating Bar
            SimpleRatingBar ratingBar = dialog.findViewById(R.id.ratingBar);


            // Save
            CustomFontButton saveButton = dialog.findViewById(R.id.save_button);
            saveButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    dialog.dismiss();
                    rateTailor(masterActivity.currentSession.currentOrderOfInterest.order_tailor_id, commentText.getText().toString().trim(), ratingBar.getRating());
                }
            });

            // Cancel
            CustomFontButton cancelButton = dialog.findViewById(R.id.cancel_button);
            cancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    dialog.dismiss();

                }
            });

            dialog.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Rate tailor
    private void rateTailor(int tailorId, String comment, float rate){
        int uId = masterActivity.currentSession.currentUser.id;
        JSONObject requestParam = new JSONObject();
        try {
            requestParam.put("userId", uId);
            requestParam.put("tailorId", tailorId);
            requestParam.put("comment", comment);
            requestParam.put("orderId", masterActivity.currentSession.currentOrderOfInterest.order_id);
            requestParam.put("rating", rate);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // Create the request body
        RequestBody body = RequestBody.create(okhttp3.MediaType.parse("application/json; charset=utf-8"),
                requestParam.toString());

        // Show the loading progress
        progressBar.setVisibility(View.VISIBLE);

        KesaaApplication.getKesaaAPI().rateTailor(body)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<JsonObject>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(JsonObject response) {
                        progressBar.setVisibility(View.GONE);
                        if (response.get("code").getAsInt() == 200){

                        }
                        else{
                            // Show error message
                            if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                                Toast.makeText(masterActivity, response.get("message").getAsString(), Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(masterActivity, response.get("arabicMessage").getAsString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(masterActivity, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onOrderDetailsFragmentInteraction("");
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    // Load order details
    private void loadOrderDetails(){
        progressBar.setVisibility(View.VISIBLE);

        KesaaApplication.getKesaaAPI().getOrderDetails(masterActivity.currentSession.currentOrderOfInterest.order_id)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<JsonObject>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(JsonObject jsonObject) {
                        progressBar.setVisibility(View.GONE);
                        if (jsonObject.get("code").getAsInt() == 200){
                            if (jsonObject.get("data") != null){
                                JsonObject optionJson = jsonObject.get("data").getAsJsonObject();

                                // Tailor name
                                if (optionJson.get("tailorName") != null){
                                    tailorName.setText(optionJson.get("tailorName").getAsString());
                                }

                                // Delivery days
                                if (optionJson.get("deliveryDays") != null){
                                    deliveryDays = optionJson.get("deliveryDays").getAsInt();
                                }

                                // Delivery Time
                                if (optionJson.get("deliveryDate") != null){
                                    deliveryTimeString = optionJson.get("deliveryDate").getAsString();
                                }

                                // Options
                                if (optionJson.get("options") != null){
                                    JsonArray optionArrayJson = optionJson.get("options").getAsJsonArray();
                                    Gson gson = new Gson();
                                    Type listType = new TypeToken<List<CustomizeOptionElement>>(){}.getType();
                                    orderedOptions = gson.fromJson(optionArrayJson.toString(), listType);
                                }
                            }
                        }
                        else{
                            // Show error message
                            if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                                Toast.makeText(masterActivity, jsonObject.get("message").getAsString(), Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(masterActivity, jsonObject.get("arabicMessage").getAsString(), Toast.LENGTH_SHORT).show();
                            }
                        }

                        // Display the order details
                        fillAllOrderDetails();
                    }

                    @Override
                    public void onError(Throwable e) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(masterActivity, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();

                        // Display the order details
                        fillAllOrderDetails();
                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }


    public void fillAllOrderDetails(){

        // Delivery time
//        String createdOrderString = masterActivity.currentSession.currentOrderOfInterest.order_placement_date;
//        Date orderDate = AllHelpers.strToDate(createdOrderString);
//
//        long dateMillis = deliveryDays * 26 * 3600 * 1000;
//        Date deliveryDate = new Date(orderDate.getTime() + dateMillis);

        if (deliveryTimeString.isEmpty()){
            nextOrderDate.setText(getString(R.string.est_delivery, ""));
        }
        else{
            Date deliveryDate = AllHelpers.strToDate(deliveryTimeString, "yyyy-MM-dd HH:mm:ss");
            nextOrderDate.setText(getString(R.string.est_delivery, AllHelpers.dateToStr(deliveryDate, "d MMMM yyyy")));
        }

//        nextOrderDate.setText(getString(R.string.est_delivery, AllHelpers.dateToStr(deliveryDate)));


        int style_id = masterActivity.currentSession.currentOrderOfInterest.order_thobe_style;

        String transaction_order_str = "#" + masterActivity.currentSession.currentOrderOfInterest.order_id;

        if ((style_id>=0) ) {

            // Style name
            if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH) {
                styleName.setText(masterActivity.currentSession.currentOrderOfInterest.styleEnglishName);
            }
            else{
                styleName.setText(masterActivity.currentSession.currentOrderOfInterest.styleArabicName);
            }

            // Style image
            Glide.with(masterActivity).load(masterActivity.currentSession.currentOrderOfInterest.styleImagePath).into(styleOptionPic);

            // Order id
            transOrderID.setText(getString(R.string.order_no, transaction_order_str));//     ("Order No : #" + transaction_order_str);

            // Tailor name
//            tailorName.setText(masterActivity.currentSession.currentOrderOfInterest.order_tailor_name);

            // Total price
            double finalCost = (masterActivity.currentSession.currentOrderOfInterest.order_total_price + 30) * 1.05;
            orderTotalPrice.setText(getString(R.string.sar, String.format(new Locale("en"), "%.2f", masterActivity.currentSession.currentOrderOfInterest.order_total_price)));

            // display options
            gridAdapter = new OrderedOptionsGridAdapter(masterActivity, orderedOptions);
            optionsGrid.setAdapter(gridAdapter);
            optionsGrid.setExpanded(true);

        }

    }


    public void timelineStatusSetter(int currentStatus){

        currentOrderTimeline = new ArrayList<>();

        TimelineDataElements ordRcvElem;
        TimelineDataElements measureElem;
        TimelineDataElements tailAcceptElem;
        TimelineDataElements sewingElem;
        TimelineDataElements pickupElem;
        TimelineDataElements delivElem;

        //ordRcvd
        if (currentStatus >=0) {
            ordRcvElem = new TimelineDataElements(1,0,0,getString(R.string.new_order),1.0f);
        } else {
            ordRcvElem = new TimelineDataElements(0,1,0,getString(R.string.new_order),0.3f);
        }

        //measure completed
        if (currentStatus >=1) {
            measureElem = new TimelineDataElements(1, 0, 0, getString(R.string.measurement_complete), 1.0f);
        } else {
            measureElem = new TimelineDataElements(0,1,0,getString(R.string.measurement_complete),0.3f);
        }

        //accepted by tailor
        if (currentStatus >=2) {
            tailAcceptElem = new TimelineDataElements(1,0,0,getString(R.string.tailor_accepted),1.0f);
        } else {
            tailAcceptElem = new TimelineDataElements(0,1,0,getString(R.string.tailor_accepted),0.3f);
        }
        //sewing
        if (currentStatus >=3) {
            sewingElem = new TimelineDataElements(1,0,0,getString(R.string.sewing),1.0f);
        } else {
            sewingElem = new TimelineDataElements(0,1,0,getString(R.string.sewing),0.3f);
        }
        //picked up
        if (currentStatus >=4) {
            pickupElem = new TimelineDataElements(1,0,0,getString(R.string.pickup),1.0f);
        } else {
            pickupElem = new TimelineDataElements(0,1,0,getString(R.string.pickup),0.3f);
        }

        //delivered
        if (currentStatus >=5) {
            delivElem = new TimelineDataElements(1,0,0,getString(R.string.delivered),1.0f);
        } else {
            delivElem = new TimelineDataElements(0,1,0,getString(R.string.delivered),0.3f);
        }



        currentOrderTimeline.add(ordRcvElem);
        currentOrderTimeline.add(measureElem);
        currentOrderTimeline.add(tailAcceptElem);
        currentOrderTimeline.add(sewingElem);
        currentOrderTimeline.add(pickupElem);
        currentOrderTimeline.add(delivElem);


    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {

        void setFragTitle(String newTitle);
        void onOrderDetailsFragmentInteraction(String data);
    }
}
