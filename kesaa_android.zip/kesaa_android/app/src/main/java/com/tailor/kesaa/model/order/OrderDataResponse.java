package com.tailor.kesaa.model.order;

import java.util.ArrayList;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class OrderDataResponse {
    @SerializedName("rows")
    @Expose
    private ArrayList<OrderHistoryDetails> orders = new ArrayList<>();

    @SerializedName("page")
    @Expose
    private Integer page;

    @SerializedName("pageSize")
    @Expose
    private Integer pageSize;

    public ArrayList<OrderHistoryDetails> getOrders() {
        return orders;
    }

    public void setOrders(ArrayList<OrderHistoryDetails> orders) {
        this.orders = orders;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
}
