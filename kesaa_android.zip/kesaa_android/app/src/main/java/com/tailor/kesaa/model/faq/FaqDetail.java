package com.tailor.kesaa.model.faq;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class FaqDetail {
    @SerializedName("id")
    @Expose
    private int id;

    @SerializedName("englishQuestion")
    @Expose
    private String englishQuestion;

    @SerializedName("arabicQuestion")
    @Expose
    private String arabicQuestion;

    @SerializedName("englishAnswer")
    @Expose
    private String englishAnswer;

    @SerializedName("arabicAnswer")
    @Expose
    private String arabicAnswer;

    @SerializedName("createdDate")
    @Expose
    private String createdDate;

    @SerializedName("status")
    @Expose
    private int status;

    @SerializedName("updatedDate")
    @Expose
    private String updatedDate;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEnglishQuestion() {
        return englishQuestion;
    }

    public void setEnglishQuestion(String englishQuestion) {
        this.englishQuestion = englishQuestion;
    }

    public String getArabicQuestion() {
        return arabicQuestion;
    }

    public void setArabicQuestion(String arabicQuestion) {
        this.arabicQuestion = arabicQuestion;
    }

    public String getEnglishAnswer() {
        return englishAnswer;
    }

    public void setEnglishAnswer(String englishAnswer) {
        this.englishAnswer = englishAnswer;
    }

    public String getArabicAnswer() {
        return arabicAnswer;
    }

    public void setArabicAnswer(String arabicAnswer) {
        this.arabicAnswer = arabicAnswer;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(String updatedDate) {
        this.updatedDate = updatedDate;
    }
}
