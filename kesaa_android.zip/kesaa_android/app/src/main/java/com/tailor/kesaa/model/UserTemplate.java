package com.tailor.kesaa.model;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class UserTemplate {

    // User Id
    public int id;

    // Firebase User Id
    public String uid;

    // First name
    public String firstName = "";

    // Last name
    public String lastName = "";

    // Phone number
    public String mobileNum = "";

    // Full name
    public String fullName = "";

    // Email address
    public String email = "";

    // Profile image
    public String profileImageUrl = null;

    public String companyName;
    public int selectedAddress = -1;

    // Default address index
    public int defaultUserAddressIndex = -1;

    public String addressJSONstr ="";

    public ArrayList<LocationTemplate> userLocations;
    public boolean userAddressesUpdatedOnServer = true;
    public boolean userLoaded = false;


    // Address list
    public List<AddressData> addressList = new ArrayList<>();

    // Current order address
    public AddressData currOrderAddress = null;


    public UserTemplate(String uid) {
        this.uid = uid;
        userLocations = new ArrayList<>();
    }


    // Get Address JsonArray String
    public String convertAddressesToJSON(){
        this.addressJSONstr = "";

        String jsonAddrArrayStr = "";
        JSONArray jsonAddressArray = new JSONArray();

        if (addressList == null) {
            addressList = new ArrayList<>();
        }

        for (int i = 0 ; i < addressList.size() ; i++) {
            JSONObject currAddressJSON = new JSONObject();
            try {
                AddressData addressInfo = addressList.get(i);
                currAddressJSON.put("unitNum", addressInfo.getUnitNum());
                currAddressJSON.put("addrLine1", addressInfo.getAddrLine1());
                currAddressJSON.put("addrLine2", addressInfo.getAddrLine2());
                currAddressJSON.put("addr_phone", "");
                currAddressJSON.put("city", addressInfo.getCity());
                currAddressJSON.put("zipCode", addressInfo.getZipcode());
                currAddressJSON.put("region", addressInfo.getRegion());
                currAddressJSON.put("lat", addressInfo.getLatitude());
                currAddressJSON.put("long", addressInfo.getLongitude());
                currAddressJSON.put("addrType", addressInfo.getAddrType());
                if (addressInfo.getIsDefault() == 1)
                {
                    currAddressJSON.put("isDefault", "1");
                }
                else {
                    currAddressJSON.put("isDefault", "0");
                }

                jsonAddressArray.put(currAddressJSON);
            } catch (Exception e) {
                Log.d("USERTEMPL", "Error in JSON conversion of addr array");
            }
        }

        jsonAddrArrayStr = jsonAddressArray.toString();
        this.addressJSONstr = jsonAddrArrayStr;

        return jsonAddrArrayStr;
    }

}
