package com.tailor.kesaa.model.tailor;

import java.io.Serializable;
import java.util.ArrayList;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TailorDataResponse implements Serializable {
    @SerializedName("rows")
    @Expose
    private ArrayList<TailorDetails> tailors = new ArrayList<>();

    @SerializedName("page")
    @Expose
    private Integer page;

    @SerializedName("pageSize")
    @Expose
    private Integer pageSize;

    public ArrayList<TailorDetails> getTailors() {
        return tailors;
    }

    public void setTailors(ArrayList<TailorDetails> tailors) {
        this.tailors = tailors;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
}
