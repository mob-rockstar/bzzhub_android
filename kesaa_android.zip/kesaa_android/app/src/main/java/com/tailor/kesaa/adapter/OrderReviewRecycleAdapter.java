package com.tailor.kesaa.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import net.cachapa.expandablelayout.ExpandableLayout;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;
import com.tailor.kesaa.model.CustomizeOptionElement;
import com.tailor.kesaa.model.OrderReviewDetails;
import com.tailor.kesaa.R;
import com.tailor.kesaa.fragment.OrderReviewFragment;
import com.tailor.kesaa.widgets.ExpandableHeightGridView;

public class OrderReviewRecycleAdapter   extends RecyclerView.Adapter<OrderReviewRecycleAdapter.OrderReviewCardHolder> {

    public RecyclerView recyclerView;
    private ArrayList<OrderReviewDetails> orderDataset;
    private OrderReviewFragment masterOfrag;
    public int width;
    public int height;
    Context mContext;

    private static boolean isHiddenAddressView = false;

    public OrderReviewRecycleAdapter(RecyclerView rView, ArrayList<OrderReviewDetails> orderDataSet, OrderReviewFragment masterOfrag, int width, int height, Context mContext) {
        this.recyclerView = rView;
        this.orderDataset = orderDataSet;
        this.masterOfrag = masterOfrag;
        this.width = width;
        this.height = height;
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public OrderReviewCardHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.order_review_cards, parent, false);

        return new OrderReviewRecycleAdapter.OrderReviewCardHolder(itemView, this.width, this.height);
    }



    @Override
    public void onBindViewHolder(@NonNull OrderReviewCardHolder holder, int position) {
        holder.bind();
    }



    @Override
    public int getItemCount() {
        return orderDataset.size();
    }

    public class OrderReviewCardHolder extends RecyclerView.ViewHolder implements View.OnClickListener, ExpandableLayout.OnExpansionUpdateListener {

        LinearLayout clickableBlock;
        ExpandableLayout expanderBlock;

        ImageButton incrButton;
        ImageButton decrButton;

        TextView styleName;
        TextView tailorName;
        TextView orderQty;
        TextView orderTotalPrice;
        TextView orderSnHPrice;

        ImageView styleOptionPic;

        TextView addressString;
        TextView measSchedString;

        LinearLayout shippingLayout;

        ImageView trashImage;

        TextView deliveryInstructionsText;


        // Options Grid
        ExpandableHeightGridView optionsGrid;


        public OrderReviewCardHolder (View itemView, int screen_width, int screen_height) {
            super(itemView);

            clickableBlock       = itemView.findViewById(R.id.ord_review_top_block);
            clickableBlock.setOnClickListener(this);

            incrButton           = itemView.findViewById(R.id.order_card_incr_qty);
            decrButton           = itemView.findViewById(R.id.order_card_decr_qty);

            expanderBlock        = itemView.findViewById(R.id.order_card_expander);

            styleName            = itemView.findViewById(R.id.ord_review_style_text);
            tailorName           = itemView.findViewById(R.id.ord_review_tailor_name) ;
            orderQty             = itemView.findViewById(R.id.ord_review_item_qty);
            orderTotalPrice      = itemView.findViewById(R.id.ord_review_top_item_price);

            // Shipping price
            orderSnHPrice        = itemView.findViewById(R.id.ord_review_shipping_price);

            // Shipping layout
            shippingLayout       = itemView.findViewById(R.id.shipping_layout);
//
            styleOptionPic       = itemView.findViewById(R.id.ord_review_style_image);
            addressString        = itemView.findViewById(R.id.ord_review_addr_text);
            measSchedString      = itemView.findViewById(R.id.ord_review_date_text);

            trashImage          = itemView.findViewById(R.id.trash_image);
            deliveryInstructionsText = itemView.findViewById(R.id.delivery_instructions_text);

            // options grid
            optionsGrid = itemView.findViewById(R.id.options_grid);
        }


        @Override
        public void onClick(View view) {

            int position = getAdapterPosition();
            String tag = (String) view.getTag();
            OrderReviewRecycleAdapter.OrderReviewCardHolder holder = (OrderReviewRecycleAdapter.OrderReviewCardHolder) recyclerView.findViewHolderForAdapterPosition(position);
              if (holder != null ) {
                      if (tag != null) {
                          if (tag.contentEquals("click")) {
                              holder.expanderBlock.toggle();
                          } else {
                              OrderReviewDetails orderReviewDetails = orderDataset.get(position);

                              if (tag.contentEquals("incr") ) // Increase the thobe amount
                              {
                                  int currentQty = orderReviewDetails.order_qty + 1;

                                  orderDataset.get(position).order_qty = currentQty;
                                  holder.orderQty.setText(String.valueOf(currentQty));

                                  // Calculate the total price without VAT
                                  orderDataset.get(position).order_total_price = currentQty * orderReviewDetails.order_item_price;
                                  float totalOptionPrice = currentQty * getOptionPrice(orderDataset.get(position));
                                  holder.orderTotalPrice.setText(mContext.getString(R.string.sar, String.valueOf(orderDataset.get(position).order_total_price + totalOptionPrice)));

                                  masterOfrag.adjustQuantity(position,0);
                              }
                              else if (tag.contentEquals("decr") ) { // Decrease the thobe amount
                                  int currentQty = orderReviewDetails.order_qty;
                                  if (currentQty > 1){
                                      currentQty = currentQty - 1;

                                      orderDataset.get(position).order_qty = currentQty;
                                      holder.orderQty.setText(String.valueOf(currentQty));

                                      // Calculate the total price without VAT
                                      orderDataset.get(position).order_total_price = currentQty * orderReviewDetails.order_item_price;
                                      float totalOptionPrice = currentQty * getOptionPrice(orderDataset.get(position));
                                      holder.orderTotalPrice.setText(mContext.getString(R.string.sar, String.valueOf(orderDataset.get(position).order_total_price + totalOptionPrice)));

                                      masterOfrag.adjustQuantity(position,1);
                                  }
                              }
                              else if (tag.contentEquals("trash")) { // Delete order
                                  masterOfrag.deleteOrder(position);
                              }
                          }

                      }

              }


        }

        private float getOptionPrice(OrderReviewDetails orderData){
            float price = 0f;

            Iterator myIterator = orderData.selectedOptionsMap.keySet().iterator();
            while(myIterator.hasNext()) {
                Integer key = (Integer) myIterator.next();
                CustomizeOptionElement value = (CustomizeOptionElement) orderData.selectedOptionsMap.get(key);

                if (value != null){
                    price += Float.parseFloat(value.price);
                }
            }

            return price;
        }


        public void bind() {

            int position = getAdapterPosition();

            clickableBlock.setTag("click");
            incrButton.setTag("incr");
            decrButton.setTag("decr");
            trashImage.setTag("trash");

            incrButton.setOnClickListener(this);
            decrButton.setOnClickListener(this);
            trashImage.setOnClickListener(this);

            tailorName.setText(orderDataset.get(position).order_tailor_name);
            orderQty.setText(String.valueOf(orderDataset.get(position).order_qty));
            orderTotalPrice.setText(mContext.getString(R.string.sar, String.valueOf(orderDataset.get(position).order_item_price + getOptionPrice(orderDataset.get(position)))));//    Float.toString(orderDataset.get(position).order_total_price));
            orderSnHPrice.setText(mContext.getString(R.string.shipping_amount, "+ " + orderDataset.get(position).order_shipping_price));

            // Option names
            if (MyPreferenceManager.getInstance(mContext).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH) {
                styleName.setText(orderDataset.get(position).selectedThobe.getEnglishName());
            }
            else {
                styleName.setText(orderDataset.get(position).selectedThobe.getArabicName());
            }

            Glide.with(mContext).load(orderDataset.get(position).selectedThobe.getImage()).into(styleOptionPic);

            addressString.setText(masterOfrag.addressString);
            measSchedString.setText(orderDataset.get(position).order_measure_sched_time);

            // Hide all options except main order info
            if (getItemCount() > 1) {
                expanderBlock.collapse(false);

                if (position == 0){
                    shippingLayout.setVisibility(View.VISIBLE);
                    isHiddenAddressView = true;
                }
                else{
                    shippingLayout.setVisibility(View.GONE);
                }
            }
            else {
                expanderBlock.expand(false);
            }

            // delivery instructions
            deliveryInstructionsText.setText(orderDataset.get(position).deliveryInstructions);

            // display options
            List<CustomizeOptionElement> optionArray = new ArrayList<>();
            Map<Integer, CustomizeOptionElement> optionsDict = new TreeMap<Integer, CustomizeOptionElement>(orderDataset.get(position).selectedOptionsMap);
            Iterator myIterator = optionsDict.keySet().iterator();
            while(myIterator.hasNext()) {
                Integer key = (Integer) myIterator.next();
                CustomizeOptionElement value = (CustomizeOptionElement) optionsDict.get(key);

                if (value != null){
                    optionArray.add(value);
                }
            }
            OrderedOptionsGridAdapter gridAdapter = new OrderedOptionsGridAdapter(mContext, optionArray);
            optionsGrid.setAdapter(gridAdapter);
            optionsGrid.setExpanded(true);

        }

        @Override
        public void onExpansionUpdate(float expansionFraction, int state) {
            if (state == ExpandableLayout.State.EXPANDING) {
                recyclerView.smoothScrollToPosition(getAdapterPosition());
            }
        }

    }

}
