package com.tailor.kesaa.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class AddressData implements Serializable {
    @SerializedName("id")
    @Expose
    private int id;

    @SerializedName("userid")
    @Expose
    private int userId;

//    @SerializedName("firebaseUID")
//    @Expose
//    private String firebaseUID;

    @SerializedName("addr_type")
    @Expose
    private int addrType = 0;

    @SerializedName("isDefault")
    @Expose
    private int isDefault = 0;

    @SerializedName("unitNum")
    @Expose
    private String unitNum;

    @SerializedName("addrLine1")
    @Expose
    private String addrLine1 = "";

    @SerializedName("addrLine2")
    @Expose
    private String addrLine2 = "";

    @SerializedName("region")
    @Expose
    private String region = "";

    @SerializedName("city")
    @Expose
    private String city = "";

    @SerializedName("apartment")
    @Expose
    private String apartment = "";

    @SerializedName("floor")
    @Expose
    private String floor = "";

    @SerializedName("zipcode")
    @Expose
    private String zipcode = "";

    @SerializedName("latitude")
    @Expose
    private String latitude = "0.0";

    @SerializedName("longitude")
    @Expose
    private String longitude = "0.0";

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getApartment() {
        return apartment;
    }

    public void setApartment(String apartment) {
        this.apartment = apartment;
    }

    public String getFloor() {
        return floor;
    }

    public void setFloor(String floor) {
        this.floor = floor;
    }

    public int getUserid() {
        return userId;
    }

    public void setUserid(int userid) {
        this.userId = userid;
    }

//    public String getFirebaseUID() {
//        return firebaseUID;
//    }
//
//    public void setFirebaseUID(String firebaseUID) {
//        this.firebaseUID = firebaseUID;
//    }

    public int getAddrType() {
        return addrType;
    }

    public void setAddrType(int addrType) {
        this.addrType = addrType;
    }

    public int getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(int isDefault) {
        this.isDefault = isDefault;
    }

    public String getUnitNum() {
        return unitNum;
    }

    public void setUnitNum(String unitNum) {
        this.unitNum = unitNum;
    }

    public String getAddrLine1() {
        return addrLine1;
    }

    public void setAddrLine1(String addrLine1) {
        this.addrLine1 = addrLine1;
    }

    public String getAddrLine2() {
        return addrLine2;
    }

    public void setAddrLine2(String addrLine2) {
        this.addrLine2 = addrLine2;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }
}
