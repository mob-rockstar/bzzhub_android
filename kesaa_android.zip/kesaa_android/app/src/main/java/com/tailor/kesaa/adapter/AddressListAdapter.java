package com.tailor.kesaa.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.tailor.kesaa.customs.CustomFontTextView;
import com.tailor.kesaa.fragment.settings.AddressesFragment;
import com.tailor.kesaa.R;
import com.tailor.kesaa.model.AddressData;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class AddressListAdapter extends BaseAdapter implements View.OnClickListener {
    private static final String TAG = "AddressListAdapter";

//    private ArrayList<LocationTemplate> locationDataSet;
    private AddressesFragment addressListFragment;
    Context mContext;
    private LayoutInflater inflater;

    private List<AddressData> addressList;

    static class AddressDetailCardHolder {
//        TextView addressType;
//        TextView addressLine1;
//        TextView addrRegionCity;
//        TextView addressLine2;
//        TextView cityName;
//        TextView region;
//        TextView addrMobile;
//
//        ImageView profilePic;
//        TextView defaultCheck;
//
//        LinearLayout dataBlock;

        @BindView(R.id.address_mark_image)
        ImageView markImageView;

        @BindView(R.id.address_type_text)
        CustomFontTextView addressTypeText;

        @BindView(R.id.address_text)
        CustomFontTextView addressLineText;

        @BindView(R.id.phone_text)
        CustomFontTextView phoneText;

        @BindView(R.id.default_tag_text)
        CustomFontTextView defaultMarkText;

        @BindView(R.id.delete_image)
        ImageView deleteImage;

        public AddressDetailCardHolder(View view){
            ButterKnife.bind(this, view);
        }

    }

    public AddressListAdapter(List<AddressData> data, Context context, AddressesFragment addrListFrag ) {
//        super(context, R.layout.address_card, data);
//        this.locationDataSet = data;
        this.mContext = context;
        this.addressListFragment = addrListFrag;
        this.inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.addressList = data;
    }

    @Override
    public int getCount() {
        return addressList.size();
    }

    @Override
    public Object getItem(int position) {
        return addressList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public void onClick(View v) {

        if (v.getTag() != null){
            if (v.getId() == R.id.delete_image){ // Delete Address
                int position = (int) v.getTag();
                addressListFragment.deleteAddress(position);
            }
        }

//        LocationTemplate currAddress = null;
//
//        if ( v.getTag() != null) {
//            int position = (Integer) v.getTag();
//            Object object = getItem(position);
//            currAddress = (LocationTemplate) object;
//
//
//            Log.d(TAG, "Addr Adapter view " + v.getId());
//
//            switch (v.getId()) {
//                case R.id.AddressCardPic:
//                    //use this option as an edit control
//                    addressListFragment.addrCardOptionClicked("pic_" +v.getTag().toString());
//                    //masterTfrag.picSelectedForReview(currTailorDetail.getName());
//                    break;
//
//
//                case R.id.address_card_mid_vert_data_block:
//                    //use this to set the default
//                    addressListFragment.addrCardOptionClicked("data_" +v.getTag().toString());
//                    //masterTfrag.picSelectedForReview(currTailorDetail.getName());
//                    break;
//
//
//                default:
//                    addressListFragment.addrCardOptionClicked("Something else " + currAddress.addrLine1);
//                    break;
//
//            }
//        }

    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        AddressDetailCardHolder holder;

        if (convertView == null){
            convertView = inflater.inflate(R.layout.item_address_list, parent, false);
            holder = new AddressDetailCardHolder(convertView);
            convertView.setTag(holder);
        }
        else{
            holder = (AddressDetailCardHolder) convertView.getTag();
        }


        AddressData addressInfo = addressList.get(position);
        // Check if it is default
        if (addressInfo.getIsDefault() == 1){
            holder.defaultMarkText.setVisibility(View.VISIBLE);
        }
        else{
            holder.defaultMarkText.setVisibility(View.INVISIBLE);
        }

        // Address title
        if (addressInfo.getAddrType() >= 0){
            int addressType= addressInfo.getAddrType();
            switch (addressType){
                case 0:
                    holder.addressTypeText.setText(mContext.getString(R.string.home_address));
                    break;
                case 1:
                    holder.addressTypeText.setText(mContext.getString(R.string.work_address));
                    break;
                case 2:
                    holder.addressTypeText.setText(mContext.getString(R.string.other_address));
                    break;
                default:
                    holder.addressTypeText.setText(mContext.getString(R.string.home_address));
                    break;
            }
        }


        // Address line
        String addressLine = "";
        if (addressInfo.getZipcode() != null && !addressInfo.getZipcode().isEmpty()) {
            addressLine = addressInfo.getZipcode() + ",";
        }

        if (addressInfo.getAddrLine1() != null &&!addressInfo.getAddrLine1().isEmpty()){
            addressLine = addressLine + addressInfo.getAddrLine1() + ",";
        }

        if (addressInfo.getAddrLine2() != null &&!addressInfo.getAddrLine2().isEmpty()){
            addressLine = addressLine + addressInfo.getAddrLine2() + ",";
        }

        if (addressInfo.getCity() != null &&!addressInfo.getCity().isEmpty()){
            addressLine = addressLine + addressInfo.getCity() + ",";
        }

        if (addressInfo.getRegion() != null &&!addressInfo.getRegion().isEmpty()){
            addressLine = addressLine + addressInfo.getRegion();
        }

        holder.addressLineText.setText(addressLine);

        // Phone


        // Get the data item for this position
//        LocationTemplate dataModel = getItem(position);
//        // Check if an existing view is being reused, otherwise inflate the view
//        AddressListAdapter.AddressDetailCardHolder viewHolder; // view lookup cache stored in tag
//
//        final View result;
//
//        if (convertView == null) {
//
//            viewHolder = new AddressListAdapter.AddressDetailCardHolder();
//            LayoutInflater inflater = LayoutInflater.from(getContext());
//            convertView = inflater.inflate(R.layout.address_card, parent, false);
//            viewHolder.addressLine1 = (TextView) convertView.findViewById(R.id.AddressLine1);
//            //viewHolder.addressLine2 = (TextView) convertView.findViewById(R.id.TailorCardAddress);
//            viewHolder.addressType = (TextView) convertView.findViewById(R.id.AddressCardType);
//            viewHolder.addrRegionCity = (TextView) convertView.findViewById(R.id.AddressCardAddress);
//            //viewHolder.addrMobile = convertView.findViewById(R.id.AddressCardMobile);
//
//            viewHolder.profilePic = convertView.findViewById(R.id.AddressCardPic);
//
//            viewHolder.defaultCheck =convertView.findViewById(R.id.default_addr_tag);
//
//            viewHolder.dataBlock = convertView.findViewById(R.id.address_card_mid_vert_data_block);
//
//            result = convertView;
//
//            convertView.setTag(viewHolder);
//        } else {
//            viewHolder = (AddressListAdapter.AddressDetailCardHolder) convertView.getTag();
//            result=convertView;
//        }
//
//        /*
//        Animation animation = AnimationUtils.loadAnimation(mContext, (position > lastPosition) ? R.anim.up_from_bottom : R.anim.down_from_top);
//        result.startAnimation(animation);
//        */
//
//        lastPosition = position;
//
//        String addressTypeString = "Address Type : ";
//        if ((dataModel.addrType) == 0 )
//            addressTypeString += "Home";
//        else if ((dataModel.addrType) == 1 )
//            addressTypeString += "Work";
//        else if ((dataModel.addrType) == 2 )
//            addressTypeString += "Other";
//        else
//            addressTypeString += "";
//
//
//        if (dataModel.defaultSet) {
//            viewHolder.defaultCheck.setAlpha(Float.parseFloat("0.4"));
//        } else {
//            viewHolder.defaultCheck.setAlpha(Float.parseFloat("0.0"));
//        }
//
//
//        viewHolder.addressLine1.setText(dataModel.addrLine1);
//        viewHolder.addressType.setText(addressTypeString);
//        //viewHolder.addrRegionCity.setText(dataModel.city + ", " +dataModel.region );
//        //viewHolder.addrMobile.setText(dataModel.addr_phone);
//
//        viewHolder.profilePic.setTag(position);
//        viewHolder.dataBlock.setTag(position);
//
//        viewHolder.profilePic.setOnClickListener(this);
//        viewHolder.dataBlock.setOnClickListener(this);

        holder.deleteImage.setTag(position);
        holder.deleteImage.setOnClickListener(this);


        // Return the completed view to render on screen
        return convertView;
    }


}
