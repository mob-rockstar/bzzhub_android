package com.tailor.kesaa.fragment;


import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.tailor.kesaa.KesaaApplication;
import com.tailor.kesaa.customs.CustomFontButton;
import com.tailor.kesaa.customs.CustomFontEditText;
import com.tailor.kesaa.customs.CustomFontTextView;
import com.tailor.kesaa.global.EventBusMessage;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;
import com.tailor.kesaa.global.Utils;
import com.tailor.kesaa.model.ActiveSession;
import com.tailor.kesaa.model.AddressData;
import com.tailor.kesaa.MainActivity;
import com.tailor.kesaa.R;
import com.tailor.kesaa.model.NewAddressDataResponse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONException;
import org.json.JSONObject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import okhttp3.RequestBody;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link LocationMapperFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link LocationMapperFragment    #newInstance} factory method to
 * create an instance of this fragment.
 */
public class LocationMapperFragment extends Fragment implements OnMapReadyCallback {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public GoogleMap thisGoogleMap;

    @BindView(R.id.myLocationMap)
    public MapView mapView;

    public View mView;


//    public LocationTemplate currentUserLocation;
//
//    public ArrayAdapter<CharSequence> regionSpinnerAdapter;

    // Current Address
    public AddressData currentHighlightedAddress;

    // flag to check if it is from address list page
    boolean isFromAddress = false;

    // AddressData to be updated
    AddressData updateAddressData = null;

//    public EditText unitNumEditText;
//    public EditText addr1EditText;
//    public EditText addr2EditText;
//    public EditText addr3EditText;
//    public EditText cityEditText;
//    public EditText zipEditText;
//    public Spinner regionSpinner;
    public int selectedRegion;

    public Double selectedLat = -1.0;
    public Double selectedLong = -1.0;

    public String TAG = "LOCMAPFRAG";

    public MainActivity masterActivity;
    public View locationMapperMainView;

    public boolean addrDefaultSwitchValue = false;

    private OnFragmentInteractionListener mListener;

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;

    @BindView(R.id.full_address_text)
    CustomFontTextView fullAddressText;

    @BindView(R.id.address_edt)
    CustomFontEditText addressLineText;

    @BindView(R.id.floor_no_edt)
    CustomFontEditText floorNoText;

    @BindView(R.id.apartment_no_edt)
    CustomFontEditText apartmentNoText;

    @BindView(R.id.zip_edt)
    CustomFontEditText zipText;

    @BindView(R.id.region_edt)
    CustomFontEditText regionText;

    @BindView(R.id.city_edt)
    CustomFontEditText cityText;

    @BindView(R.id.unit_no_edt)
    CustomFontEditText unitNoText;

//    String fullAddress = "";

    @BindView(R.id.progressBar)
    ProgressBar progressBar;

    public LocationMapperFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment LocationMapperFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static LocationMapperFragment newInstance(String param1, String param2) {
        LocationMapperFragment fragment = new LocationMapperFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        masterActivity = (MainActivity) getActivity();
        if (masterActivity != null) {
            masterActivity.setFragTitle(getString(R.string.new_addr_title));
        }

        mView = inflater.inflate(R.layout.fragment_location_mapper, container, false);
        ButterKnife.bind(this, mView);

        locationMapperMainView = mView;
        masterActivity = (MainActivity) getActivity();

//        unitNumEditText = mView.findViewById(R.id.unitnum);
//        addr1EditText = mView.findViewById(R.id.addrLine1);
//        addr2EditText = mView.findViewById(R.id.addrLine2);
//        cityEditText = mView.findViewById(R.id.addrCity);
//        zipEditText = mView.findViewById(R.id.addrZip);

        selectedRegion = 1;

//        Button saveBtn = mView.findViewById(R.id.locationSaveBtn);
//        saveBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                addressTypeDialog();
//
//
//            }
//        });


        return mView;
    }


    // Save address
    @OnClick(R.id.locationSaveBtn) void saveAddress(){
        makeFullAddress();
        if (!addressLineText.getText().toString().isEmpty() && !zipText.getText().toString().isEmpty()
                && !regionText.getText().toString().isEmpty() && !cityText.getText().toString().isEmpty() && !unitNoText.getText().toString().isEmpty()){
            addressTypeDialog();
        }
        else{
            Toast.makeText(getContext(), getString(R.string.error_address_info_msg), Toast.LENGTH_SHORT).show();
        }
    }


//    public void saveAddrClicked() {
//        saveCurrAddressDetails();
//        addressTypeDialog();
//    }

    // Show the save dialog
    public void addressTypeDialog() {


        final AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this.getContext());
        LayoutInflater inflater = this.getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.addr_save_dlg, null);
        dialogBuilder.setView(dialogView);

        final CustomFontTextView addressString = dialogView.findViewById(R.id.addr_dlg_received_address);
        final Spinner addrTypeOptions = dialogView.findViewById(R.id.addr_dlg_type_spinner);
        final Switch addDlgDefSwitch = dialogView.findViewById(R.id.addr_save_default_toggle_switch);
        final CustomFontButton saveCurrAddrBtn = dialogView.findViewById(R.id.addr_dlg_save_btn);


        if (ActiveSession.getInstance().currentUser.defaultUserAddressIndex >= 0){
            addrDefaultSwitchValue = false;
            addDlgDefSwitch.setChecked(false);
//            addDlgDefSwitch.setEnabled(false);
        }
        else{
            addDlgDefSwitch.setChecked(true);
//            addDlgDefSwitch.setEnabled(true);
        }

        // Check if updated address is default
        if (updateAddressData != null){
            addDlgDefSwitch.setEnabled(true);
            if (updateAddressData.getIsDefault() == 1){
                addrDefaultSwitchValue = true;
                addDlgDefSwitch.setChecked(true);
            }
            else{
                addrDefaultSwitchValue = false;
                addDlgDefSwitch.setChecked(false);
            }
        }

        addDlgDefSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    addrDefaultSwitchValue = true;

                } else {
                    addrDefaultSwitchValue = false;
                }
                masterActivity.clearPreviousDefaultAddress();
                currentHighlightedAddress.setIsDefault(addrDefaultSwitchValue ? 1 : 0);
            }
        });

        currentHighlightedAddress = new AddressData();
        currentHighlightedAddress.setUnitNum(unitNoText.getText().toString());
        currentHighlightedAddress.setAddrLine1(addressLineText.getText().toString());

        if (updateAddressData != null){

            currentHighlightedAddress.setAddrLine2(updateAddressData.getAddrLine2());
            currentHighlightedAddress.setRegion(updateAddressData.getRegion());
        }
        else{
            currentHighlightedAddress.setAddrLine2("");
            currentHighlightedAddress.setRegion("Eastern Province");
        }

        currentHighlightedAddress.setCity(cityText.getText().toString());
        currentHighlightedAddress.setZipcode(zipText.getText().toString());

        currentHighlightedAddress.setLongitude(String.valueOf(selectedLong));
        currentHighlightedAddress.setLatitude(String.valueOf(selectedLat));
        currentHighlightedAddress.setIsDefault(addrDefaultSwitchValue ? 1 : 0);
        currentHighlightedAddress.setFloor(floorNoText.getText().toString());
        currentHighlightedAddress.setApartment(apartmentNoText.getText().toString());

        // show the full address in dialog
        addressString.setText(makeFullAddress());

        // Address type spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(),
                R.array.addr_types, android.R.layout.simple_spinner_item);

        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        addrTypeOptions.setAdapter(adapter);

        // Apply the adapter to the spinner
        if (updateAddressData != null){
            addrTypeOptions.setSelection(updateAddressData.getAddrType());
        }

        final AlertDialog verifyDlg = dialogBuilder.create();
        Window window = verifyDlg.getWindow();
        window.setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        window.setGravity(Gravity.CENTER);

        saveCurrAddrBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //get the currentAddress stash it into UserLocations with the correct type flags set

                if (addrTypeOptions.getSelectedItem().toString().contentEquals(getString(R.string.home_address))) {
                    currentHighlightedAddress.setAddrType(0);
                }
                else if (addrTypeOptions.getSelectedItem().toString().contentEquals(getString(R.string.work_address))) {
                    currentHighlightedAddress.setAddrType(1);
                }
                else {
                    currentHighlightedAddress.setAddrType(2);
                }

                // Dismiss the dialog
                verifyDlg.dismiss();


                // save address into server
                saveCurrentAddressIntoServer(addDlgDefSwitch.isChecked());
            }
        });


        verifyDlg.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        DisplayMetrics displayMetrics = new DisplayMetrics();
        masterActivity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        // The absolute width of the available display size in pixels.
        int displayWidth = displayMetrics.widthPixels;
        // The absolute height of the available display size in pixels.
        int displayHeight = displayMetrics.heightPixels;

        // Initialize a new window manager layout parameters
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();

        // Copy the alert dialog window attributes to new layout parameter instance
        layoutParams.copyFrom(verifyDlg.getWindow().getAttributes());

        // Set alert dialog width equal to screen width 70%
        int dialogWindowWidth = (int) (displayWidth * 0.75f);

        // Set the width and height for the layout parameters
        // This will bet the width and height of alert dialog
        layoutParams.width = dialogWindowWidth;
        layoutParams.dimAmount=0.4f;
        // Apply the newly created layout parameters to the alert dialog window

        verifyDlg.show();
        verifyDlg.getWindow().setAttributes(layoutParams);
        verifyDlg.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        verifyDlg.getWindow().setDimAmount(0.7f);
    }

    // Save current address into server DB
    private void saveCurrentAddressIntoServer(boolean isDefault){

        if (masterActivity != null && !Utils.isNetworkConnected(masterActivity)){
            Toast.makeText(masterActivity, getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);

        JSONObject requestParam = new JSONObject();
        try {
            requestParam.put("userId", ActiveSession.getInstance().currentUser.id);
            requestParam.put("addr_type", currentHighlightedAddress.getAddrType());
            requestParam.put("isDefault", isDefault ? 1 : 0);
            requestParam.put("unitNum", currentHighlightedAddress.getUnitNum());
            requestParam.put("apartment", currentHighlightedAddress.getApartment());
            requestParam.put("floor", currentHighlightedAddress.getFloor());
            requestParam.put("addrLine1", currentHighlightedAddress.getAddrLine1());
            requestParam.put("addrLine2", currentHighlightedAddress.getAddrLine2());
            requestParam.put("region", currentHighlightedAddress.getRegion());
            requestParam.put("city", currentHighlightedAddress.getCity());
            requestParam.put("zipcode", currentHighlightedAddress.getZipcode());
            requestParam.put("latitude", currentHighlightedAddress.getLatitude());
            requestParam.put("longitude", currentHighlightedAddress.getLongitude());

            if (updateAddressData != null){
                requestParam.put("addressId", updateAddressData.getId());
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // Create the request body
        RequestBody body = RequestBody.create(okhttp3.MediaType.parse("application/json; charset=utf-8"),
                requestParam.toString());

        if (updateAddressData == null){ // Create new address
            // Call apis
            KesaaApplication.getKesaaAPI().createNewAddress(body)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Observer<NewAddressDataResponse>() {
                        @Override
                        public void onSubscribe(Disposable d) {

                        }

                        @Override
                        public void onNext(NewAddressDataResponse response) {
                            progressBar.setVisibility(View.GONE);
                            Log.d(TAG, "Update Address Response: " + response.toString());

                            if (response.getCode() == 200){
                                if (isFromAddress){
                                    // Init the user address array
                                    if (masterActivity.currentSession.currentUser.addressList == null) {
                                        masterActivity.currentSession.currentUser.addressList = new ArrayList<AddressData>();
                                    }

                                    masterActivity.currentSession.currentUser.addressList.add(response.getAddress());

                                    if (isDefault){
                                        int defaultAddrIndex = masterActivity.currentSession.currentUser.addressList.indexOf(response.getAddress());
                                        if (defaultAddrIndex >= 0){
                                            masterActivity.currentSession.currentUser.defaultUserAddressIndex = defaultAddrIndex;
                                        }
                                    }

                                    // Go to AddressList page
                                    EventBus.getDefault().post(new EventBusMessage(EventBusMessage.MessageType.NEW_ADDRESS_CREATED));
                                }

                                // pop back stack
                                masterActivity.getSupportFragmentManager().popBackStack();
                            }
                            else{
                                // Show error message
                                if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                                    Toast.makeText(masterActivity, response.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                                else{
                                    Toast.makeText(masterActivity, response.getArabicMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        }

                        @Override
                        public void onError(Throwable e) {
                            progressBar.setVisibility(View.GONE);
                            Toast.makeText(getContext(), e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                            Log.d(TAG, "Update Address Error: " + e.getLocalizedMessage());
                        }

                        @Override
                        public void onComplete() {

                        }
                    });
        }
        else{ // Update address

            KesaaApplication.getKesaaAPI().updateAddress(body)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Observer<NewAddressDataResponse>() {
                        @Override
                        public void onSubscribe(Disposable d) {

                        }

                        @Override
                        public void onNext(NewAddressDataResponse response) {
                            progressBar.setVisibility(View.GONE);
                            Log.d(TAG, "Update Address Response: " + response.toString());

                            if (response.getCode() == 200){
                                if (isFromAddress){
                                    // Init the user address array
                                    if (masterActivity.currentSession.currentUser.addressList == null) {
                                        masterActivity.currentSession.currentUser.addressList = new ArrayList<AddressData>();
                                    }

                                    masterActivity.currentSession.currentUser.addressList.add(response.getAddress());

                                    if (isDefault){
                                        int defaultAddrIndex = masterActivity.currentSession.currentUser.addressList.indexOf(response.getAddress());
                                        if (defaultAddrIndex >= 0){
                                            masterActivity.currentSession.currentUser.defaultUserAddressIndex = defaultAddrIndex;
                                        }
                                    }

                                    // Go to AddressList page
                                    EventBus.getDefault().post(new EventBusMessage(EventBusMessage.MessageType.NEW_ADDRESS_CREATED));
                                }

                                // pop back stack
                                masterActivity.getSupportFragmentManager().popBackStack();
                            }
                            else{
                                // Show error message
                                if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                                    Toast.makeText(masterActivity, response.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                                else{
                                    Toast.makeText(masterActivity, response.getArabicMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        }

                        @Override
                        public void onError(Throwable e) {
                            progressBar.setVisibility(View.GONE);
                            Toast.makeText(getContext(), e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                            Log.d(TAG, "Update Address Error: " + e.getLocalizedMessage());
                        }

                        @Override
                        public void onComplete() {

                        }
                    });
        }


    }

    // make the full address
    private String makeFullAddress(){
        String floorNo = floorNoText.getText().toString();
        String apartmentNo = apartmentNoText.getText().toString();
        String zipCode = zipText.getText().toString();
        String city = cityText.getText().toString();
        String addressLine = addressLineText.getText().toString();
        String unitNo = unitNoText.getText().toString();

        String addressText = "";
        if (!apartmentNo.isEmpty()) {
            addressText = "Apt No." + apartmentNo + ", ";
        }

        if (!floorNo.isEmpty()){
            addressText = addressText + "Floor " + floorNo + ", ";
        }

        if (!unitNo.isEmpty()){
            addressText = addressText + "Building " + unitNo + ", ";
        }

        if (!addressLine.isEmpty()){
            addressText = addressText + addressLine + ", ";
        }

        if (!city.isEmpty()){
            addressText = addressText + city + ", ";
        }

        addressText = addressText + "Eastern Province" + ", ";

        if (!zipCode.isEmpty()){
            addressText = addressText + zipCode;
        }

        fullAddressText.setText(addressText);
        return addressText;
    }


    @Override
    public void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        mapView.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

//        mapView = mView.findViewById(R.id.myLocationMap);

        if (mapView != null) {
            mapView.onCreate(savedInstanceState);
//            mapView.onResume();
            mapView.getMapAsync(this);
        }

        if (getArguments() != null) {
            isFromAddress = getArguments().getBoolean("isFromAddressList", false);

            if (getArguments().getSerializable("selected_address") != null) {
                updateAddressData = (AddressData) getArguments().getSerializable("selected_address");
            }
        }

    }

    public void updateLocationDetails(boolean validAddress, String unitNum, String addrLine1, String addrLine2, String cityName, String zipCode )
    {
        if (validAddress) {

            // Unit No
            if (unitNum != null && !unitNum.isEmpty()){
                unitNoText.setText(unitNum);
            }

            // Full Address
            if (addrLine1 != null && !addrLine1.isEmpty()){
                addressLineText.setText(addrLine1);
            }
            else if (addrLine2 != null && !addrLine2.isEmpty()){
                addressLineText.setText(addrLine2);
            }

            // City
            if (cityName != null && !cityName.isEmpty()){
                cityText.setText(cityName);
            }


            // Zip Code
            if (zipCode != null && !zipCode.isEmpty()){
                zipText.setText(zipCode);
            }
        } else {
            unitNoText.setText("");
            cityText.setText("");
            zipText.setText("");
            addressLineText.setText("");
            floorNoText.setText("");
            apartmentNoText.setText("");
        }

        makeFullAddress();
    }


    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onLocationMapFragmentInteraction(null);
        }
    }

    private void enableMyLocationIfPermitted() {
        if (ContextCompat.checkSelfPermission(this.getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(masterActivity,
                    android.Manifest.permission.ACCESS_FINE_LOCATION)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
            } else {
                // No explanation needed, we can request the permission.
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
            }

        } else if (thisGoogleMap != null) {
            thisGoogleMap.setMyLocationEnabled(true);
            thisGoogleMap.setOnMyLocationButtonClickListener(onMyLocationButtonClickListener);
            thisGoogleMap.setOnMyLocationClickListener(onMyLocationClickListener);
        }
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

        MapsInitializer.initialize(this.getContext());
        thisGoogleMap = googleMap;
        thisGoogleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);

        if (ContextCompat.checkSelfPermission(this.getContext(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            thisGoogleMap.setMyLocationEnabled(true);
            thisGoogleMap.setOnMyLocationButtonClickListener(onMyLocationButtonClickListener);
            thisGoogleMap.setOnMyLocationClickListener(onMyLocationClickListener);
        }

        CameraPosition hobbyDistrict;
        if (updateAddressData != null){
            hobbyDistrict = CameraPosition.builder().target(new LatLng(Double.parseDouble(updateAddressData.getLatitude()), Double.parseDouble(updateAddressData.getLongitude()))).zoom(10).bearing(0).tilt(0).build();
        }
        else{
            hobbyDistrict = CameraPosition.builder().target(new LatLng(26.443704, 49.922592)).zoom(10).bearing(0).tilt(0).build();
        }

        thisGoogleMap.setMinZoomPreference(12.0f);
        thisGoogleMap.setMaxZoomPreference(18.0f);

        thisGoogleMap.moveCamera(CameraUpdateFactory.newCameraPosition(hobbyDistrict));
        thisGoogleMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {

            @Override
            public void onMapClick(LatLng latLng) {

                // Show the marker
                displayMarker(latLng.latitude, latLng.longitude);
            }
        });


        enableMyLocationIfPermitted();

        thisGoogleMap.getUiSettings().setZoomControlsEnabled(true);
        thisGoogleMap.setMinZoomPreference(5);

        // display the marker if address is not null
        if (updateAddressData != null){
            displayMarker(Double.parseDouble(updateAddressData.getLatitude()), Double.parseDouble(updateAddressData.getLongitude()));
            currentHighlightedAddress = updateAddressData;
        }

//        getLatLongFromAddress("");

        /*
        //26.2971212,50.197955
        thisGoogleMap.addMarker(new MarkerOptions().position(new LatLng(26.2971212,50.197955)).title("Mystery Location").snippet("Meth Warehouse"));

        CameraPosition hobbyDistrict  = CameraPosition.builder().target(new LatLng(26.2971212,50.197955)).zoom(16).bearing(0).tilt(45).build();

        thisGoogleMap.moveCamera(CameraUpdateFactory.newCameraPosition(hobbyDistrict));
        */

    }

    private void displayMarker(double latitude, double longitude){
        // Creating a marker
        MarkerOptions markerOptions = new MarkerOptions();

        // save the selected location
        selectedLat = latitude;
        selectedLong = longitude;

        LatLng selectedLatLng = new LatLng(latitude, longitude);

        // Setting the position for the marker
        markerOptions.position(selectedLatLng);
        getAddressFromLatLng(selectedLatLng );

        // Setting the title for the marker.
        // This will be displayed on taping the marker
        markerOptions.title(latitude + " : " + latitude);

        // Clears the previously touched position
        thisGoogleMap.clear();
        // Animating to the touched position
        thisGoogleMap.animateCamera(CameraUpdateFactory.newLatLng(selectedLatLng));
        // Placing a marker on the touched position
        thisGoogleMap.addMarker(markerOptions);
    }


    private void getLatLongFromAddress(String user_address)
    {
        String fullAddrStr = "";

        Geocoder gc =  new Geocoder(this.getContext(),Locale.getDefault());
        try {
            List<Address> addresses = gc.getFromLocationName(fullAddrStr,1,-90,-180,90,180);
            if (addresses != null && addresses.size() > 0){
                String lat = Double.toString(addresses.get(0).getLatitude());
                String lng = Double.toString(addresses.get(0).getLongitude());

                Log.d("GETLOC",lat + ", " + lng);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private void getAddressFromLatLng(LatLng userLatLng)
    {

        String fullAddr = "";
        boolean problemAddress = false;
        boolean nonSaudiAddr = true;

        String unitNum = "";
        String addrLine1 = "" ;
        String addrLine2= "" ;
        String cityLocale= "" ;
        String fullZip= "" ;


        Geocoder gc =  new Geocoder(this.getContext(),Locale.getDefault());
        try {
            List<Address> addresses = gc.getFromLocation(userLatLng.latitude,userLatLng.longitude,2);

            if (addresses.get(0).getAddressLine(0) != null) {
                //addr1EditText.setText(addresses.get(0).getAddressLine(0));
                fullAddr += addresses.get(0).getAddressLine(0);
                if (addresses.get(0).getAddressLine(1) != null) {
                    //addr2EditText.setText(addresses.get(0).getAddressLine(1));
                    fullAddr += addresses.get(0).getAddressLine(1);
                    if (addresses.get(0).getAddressLine(1) != null) {
                        //addr3EditText.setText(addresses.get(0).getAddressLine(2));

                        fullAddr += addresses.get(0).getAddressLine(2);
                    }
                }
            }
            if (addresses.get(0).getLocality() != null) {
                //cityEditText.setText(addresses.get(0).getLocality());
                fullAddr += addresses.get(0).getLocality();
            }

            selectedLat = userLatLng.latitude;
            selectedLong = userLatLng.longitude;

            String countryName = addresses.get(0).getCountryName();
            String localityName = addresses.get(0).getLocality();
            String postalCode = addresses.get(0).getPostalCode();
            String extraPostCodeDigits = "";

            String addressLine = addresses.get(0).getAddressLine(0);

            if (countryName.contains("Saudi")) {
                //process this address
                nonSaudiAddr = false;

                if (countryName == null) countryName = "";
                if (localityName == null) localityName = "";
                if (postalCode == null) postalCode = "";
                if (addressLine == null) addressLine = "";

                if ( ( postalCode.length() > 1 )  && ( addressLine.length() > 1  ) ) {


                    int zipPos = addressLine.indexOf(postalCode);

                    if (zipPos >= 0) {
                        extraPostCodeDigits = addressLine.substring(zipPos+postalCode.length()+1, zipPos+postalCode.length()+5 );
                        Log.d(TAG,"ExtraDigs = "+ extraPostCodeDigits);
                    }

                }


                Log.d(TAG, "Ctry : " + countryName + ", Local: " + localityName + ", post: " + postalCode + ", addr: " + addressLine );

                String [] fullAddrArray =fullAddr.split(",");
                String tempStr = "";

                unitNum = "";
                addrLine1 = "";
                addrLine2 = "";
                cityLocale = localityName;
                if (org.apache.commons.lang3.StringUtils.isNumeric(extraPostCodeDigits))
                    fullZip = postalCode + " " + extraPostCodeDigits;


                if (fullAddrArray.length == 0) {
                    //warn them that you don't have enough detail. Save the lat and long anyway


                } else if (fullAddrArray.length == 1) {
                    //put this in line 1 (cos that's all you got)

                } else  if (fullAddrArray.length > 2) {

                    // this should have 4 parts - if not treat is as an error
                    Log.d(TAG,"address has " + Integer.toString(fullAddrArray.length) + " parts" );
                    if (fullAddrArray.length < 3 ){
                        problemAddress = true;

                    } else {

                        addrLine1 = fullAddrArray[0];
                        String [] addr1split = addrLine1.split(" ");
                        Log.d(TAG,"First split line ("+ addrLine1 +") has " + Integer.toString(addr1split.length) + " parts" );
                        addrLine1 = "";


                        if (addr1split.length > 0) {

                            if (org.apache.commons.lang3.StringUtils.isNumeric(addr1split[0]) ) {
                                unitNum = addr1split[0];
                            }

                            for (int i = 0 ; i < addr1split.length ; i++ ) {

                                if ( (i==0) && (unitNum.length()<2)) {
                                    addrLine1 += addr1split[i];
                                }
                                if (i>0) {
                                    addrLine1 += addr1split[i] + " " ;
                                }

                            }

                        }


                        addrLine2 = fullAddrArray[1];
                        String [] addr2split = addrLine2.split(" ");
                        Log.d(TAG,"Second split line ("+ addrLine2 +") has " + Integer.toString(addr2split.length) + " parts" );
                        addrLine2 = "";


                        if (addr2split.length > 0) {

                            for (int i = 0 ; i < addr2split.length ; i++ ) {

                                Log.d(TAG,"Checking " + addr2split[i]);
                                if (!org.apache.commons.lang3.StringUtils.isNumeric(addr2split[i])) {
                                    Log.d(TAG,"Adding " + addr2split[i] + " to  address 2" );

                                    addrLine2 += addr2split[i] + " " ;
                                }


                            }

                        }


                        if (addrLine1.length() < 4) {
                            Log.d(TAG, "Addr line 1 length = " + Integer.toString(addrLine1.length()));
                            //problemAddress = true;
                        }

                        if (addrLine2.length() < 4) {
                            Log.d(TAG, "Addr line 2 length = " + Integer.toString(addrLine1.length()));
                            //problemAddress =true;
                        }


                    }



                }


            } else {
                //if not just give them a heads up that they have to fill the address
                nonSaudiAddr = true;
            }


            if (nonSaudiAddr) {
                Log.d(TAG, "Non Saudi Address - just save GPS");
            } else {
                Log.d(TAG, "Saudi Address - try to extract all fields");

                if (problemAddress) {
                    Log.d(TAG,"There was a problem with the address");
                } else {
                    Log.d(TAG,unitNum +" - " + addrLine1 + " - " + addrLine2 + " - " + cityLocale +  " - " + fullZip );
                }

            }


            updateLocationDetails((true), unitNum, addrLine1, addrLine2, cityLocale, fullZip );





        } catch (IOException e) {
            e.printStackTrace();
        }

    }



    protected void onHandleIntent(Intent intent) {
        Geocoder geocoder = new Geocoder(this.getContext(), Locale.getDefault());

    }

    private void showDefaultLocation() {
        Log.d(TAG, "Location permission not granted");

        if (thisGoogleMap != null){
            thisGoogleMap.addMarker(new MarkerOptions().position(new LatLng(26.2971212,50.197955)).title("").snippet(""));
            CameraPosition hobbyDistrict  = CameraPosition.builder().target(new LatLng(26.2971212,50.197955)).zoom(16).bearing(0).tilt(45).build();
            thisGoogleMap.moveCamera(CameraUpdateFactory.newCameraPosition(hobbyDistrict));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        switch (requestCode) {
            case LOCATION_PERMISSION_REQUEST_CODE: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    enableMyLocationIfPermitted();
                }
                else {
                    showDefaultLocation();
                }

                return;
            }

        }
    }

    private GoogleMap.OnMyLocationButtonClickListener onMyLocationButtonClickListener =
            new GoogleMap.OnMyLocationButtonClickListener() {
                @Override
                public boolean onMyLocationButtonClick() {

                    if (thisGoogleMap != null) {
                        thisGoogleMap.setMinZoomPreference(5);
                        Location currentLocation = thisGoogleMap.getMyLocation();
                        if (currentLocation != null){
                            getAddressFromLatLng(new LatLng(currentLocation.getLatitude(),currentLocation.getLongitude()));
                        }
                        else{
                            Log.d(TAG, "Can't determine current location");
                        }
                    }

                    return false;
                }
            };

    private GoogleMap.OnMyLocationClickListener onMyLocationClickListener =
            new GoogleMap.OnMyLocationClickListener() {
                @Override
                public void onMyLocationClick(@NonNull Location location) {

                    thisGoogleMap.setMinZoomPreference(5);

                    CircleOptions circleOptions = new CircleOptions();
                    circleOptions.center(new LatLng(location.getLatitude(),
                            location.getLongitude()));

                    circleOptions.radius(200);
                    circleOptions.fillColor(Color.RED);
                    circleOptions.strokeWidth(6);

                    thisGoogleMap.addCircle(circleOptions);
                }
            };

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onLocationMapFragmentInteraction(String data);
    }
}
