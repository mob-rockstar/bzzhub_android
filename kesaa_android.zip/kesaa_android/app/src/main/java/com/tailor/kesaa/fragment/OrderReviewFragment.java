package com.tailor.kesaa.fragment;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import company.tap.gosellapi.GoSellSDK;
import company.tap.gosellapi.internal.api.callbacks.GoSellError;
import company.tap.gosellapi.internal.api.models.Authorize;
import company.tap.gosellapi.internal.api.models.Charge;
import company.tap.gosellapi.internal.api.models.PhoneNumber;
import company.tap.gosellapi.internal.api.models.Token;
import company.tap.gosellapi.open.buttons.PayButtonView;
import company.tap.gosellapi.open.controllers.SDKSession;
import company.tap.gosellapi.open.controllers.ThemeObject;
import company.tap.gosellapi.open.delegate.SessionDelegate;
import company.tap.gosellapi.open.enums.AppearanceMode;
import company.tap.gosellapi.open.enums.TransactionMode;
import company.tap.gosellapi.open.models.CardsList;
import company.tap.gosellapi.open.models.Customer;
import company.tap.gosellapi.open.models.Receipt;
import company.tap.gosellapi.open.models.TapCurrency;
import company.tap.gosellapi.open.viewmodel.CustomerViewModel;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.database.DatabaseReference;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.oppwa.mobile.connect.checkout.dialog.CheckoutActivity;
import com.oppwa.mobile.connect.checkout.meta.CheckoutSettings;
import com.oppwa.mobile.connect.exception.PaymentError;
import com.oppwa.mobile.connect.provider.Connect;
import com.oppwa.mobile.connect.provider.Transaction;
import com.oppwa.mobile.connect.provider.TransactionType;
import com.tailor.kesaa.KesaaApplication;
import com.tailor.kesaa.customs.CustomFontButton;
import com.tailor.kesaa.customs.CustomFontTextView;
import com.tailor.kesaa.global.AllHelpers;
import com.tailor.kesaa.global.EventBusMessage;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.Utils;
import com.tailor.kesaa.model.ActiveSession;
import com.tailor.kesaa.model.AddressData;
import com.tailor.kesaa.model.CustomizeOptionElement;
import com.tailor.kesaa.MainActivity;
import com.tailor.kesaa.model.OrderItemTemplate;
import com.tailor.kesaa.model.OrderReviewDetails;
import com.tailor.kesaa.adapter.OrderReviewRecycleAdapter;
import com.tailor.kesaa.R;
import com.tailor.kesaa.global.SettingsKeys;
import com.tailor.kesaa.global.SettingsManager;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link OrderReviewFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link OrderReviewFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class OrderReviewFragment extends Fragment{
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private MainActivity masterActivity;
    private String TAG = "OrderReview";

    public int master_screen_width = -1;
    public int master_screen_height = -1;
    public String addressString = "No default address";

    public ArrayList<OrderReviewDetails> orderReviewArray;

    private View frag_view;

    private View masterView;
    private SettingsManager settingsManager;

    public float total_cart_price = 0;

    public RecyclerView orderReviewRecycler;
    public OrderReviewRecycleAdapter orderReviewRecycleAdapter;
    private RecyclerView.LayoutManager orderReviewRecycleLayoutManager;
    private OnFragmentInteractionListener mListener;

    public LinearLayout paymentOptionsLayoutBlock;
    public LinearLayout baseOptionsLayoutBlock;

    @BindView(R.id.order_review_price_value_text)
    CustomFontTextView orderTotalCostText;

    @BindView(R.id.progressBar)
    ProgressBar progressBar;

    public OrderReviewFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment OrderReviewFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static OrderReviewFragment newInstance(String param1, String param2) {
        OrderReviewFragment fragment = new OrderReviewFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        masterActivity = (MainActivity) getActivity();

        if (masterActivity != null){
            masterActivity.showActionBar();
            masterActivity.setFragTitle(getString(R.string.ord_review_title));

            // Firebase analytics event
            Bundle bundle = new Bundle();
            bundle.putString(FirebaseAnalytics.Param.SCREEN_NAME, "Order Review");
            bundle.putString(FirebaseAnalytics.Param.SCREEN_CLASS, getClass().getSimpleName());
            masterActivity.mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SCREEN_VIEW, bundle);
        }

        settingsManager = SettingsManager.getInstance();
        settingsManager.setPref(getContext());


        if (ActiveSession.getInstance().currentUser.currOrderAddress != null){
            addressString = getFullAddress(ActiveSession.getInstance().currentUser.currOrderAddress);
        }
        else if (masterActivity.currentSession.currentUser.defaultUserAddressIndex >= 0) {
//            int addrType = masterActivity.currentSession.currentUser.addressList.get(masterActivity.currentSession.currentUser.defaultUserAddressIndex).getAddrType();

            AddressData userAddress = masterActivity.currentSession.currentUser.addressList.get(masterActivity.currentSession.currentUser.defaultUserAddressIndex);
            ActiveSession.getInstance().currentUser.currOrderAddress = userAddress;
            if (userAddress != null){
                addressString = getFullAddress(userAddress);
            }
        }

        frag_view =  inflater.inflate(R.layout.fragment_order_review, container, false);
        ButterKnife.bind(this, frag_view);

        masterView = frag_view;

        paymentOptionsLayoutBlock = frag_view.findViewById(R.id.ord_review_payment_opts_block);
        baseOptionsLayoutBlock = frag_view.findViewById(R.id.ord_review_buttons_block);

        orderReviewRecycler = frag_view.findViewById(R.id.ord_review_recyclerview);
        orderReviewRecycleLayoutManager = new LinearLayoutManager(getContext(),
                RecyclerView.VERTICAL, false);
        orderReviewRecycler.setLayoutManager(orderReviewRecycleLayoutManager);


        if (masterActivity.currentOrderItem != null) {
            masterActivity.currentOrderItem.order_quantity = 1;

            if (masterActivity.currentOrderItem.item_price > 0){
                addCurrentOrderToCart();
            } else {
                masterActivity.currentOrderItem.item_price  = 0;
                masterActivity.currentOrderItem.item_total_price = 0;
                addCurrentOrderToCart();
            }
        }

        fillAdapterFromOrders(true);

        return frag_view;
    }


    // Checkout
    @OnClick(R.id.btn_checkout) void goToPayment(){
        Bundle bundle = new Bundle();
        bundle.putFloat("total_amount", total_cart_price);
        Navigation.findNavController(masterView).navigate(R.id.action_orderReviewFragment_to_paymentFragment, bundle);
    }

    // Get user address
    private String getFullAddress(AddressData userAddress){
        int addrType = userAddress.getAddrType();

        String floorNo          = "";
        String apartmentNo      = "";
        String zipCode          = userAddress.getZipcode();
        String city             = userAddress.getCity();
        String addressLine      = userAddress.getAddrLine1();
        String state            = userAddress.getRegion();
        String unitNo           = userAddress.getUnitNum();

        String addressText = "";
        if (!apartmentNo.isEmpty()) {
            addressText = "Apt No." + apartmentNo + ", ";
        }

        if (!floorNo.isEmpty()){
            addressText = addressText + "Floor " + floorNo + ", ";
        }

        if (!unitNo.isEmpty()){
            addressText = addressText + "Building " + unitNo + ", ";
        }

        if (!addressLine.isEmpty()){
            addressText = addressText + addressLine + ", ";
        }

        if (!city.isEmpty()){
            addressText = addressText + city + ", ";
        }

        if (!state.isEmpty()){
            addressText = addressText + state + ", ";
        }

        if (!zipCode.isEmpty()){
            addressText = addressText + zipCode;
        }



        switch (addrType) {
            case 0:
                addressText  = addressText + " " + getString(R.string.order_address_home);
                break;
            case 1:
                addressText  = addressText + " " + getString(R.string.order_address_work);
                break;
            case 2:
                addressText  = addressText + " " + getString(R.string.order_address_other);
                break;
            default:
                addressText  = addressText + " " + getString(R.string.order_address_home);
                break;

        }

        return addressText;
    }

    public void addCurrentOrderToCart(){
        if (!masterActivity.currentOrderItem.order_placed_in_cart) {
            Date currentDate = Calendar.getInstance().getTime();

            // Get price and total price
            float item_total_price = masterActivity.currentOrderItem.item_total_price; // With VAT
            float totalPrice = item_total_price * masterActivity.currentOrderItem.order_quantity;

            OrderItemTemplate thisOrder = new OrderItemTemplate(0,0,0, currentDate,
                    0,0, masterActivity.currentOrderItem.order_size,masterActivity.currentOrderItem.order_quantity,
                    masterActivity.currentOrderItem.item_price, item_total_price,"", masterActivity.currentOrderItem.selectedThobe != null ? masterActivity.currentOrderItem.selectedThobe.getId() : 1,
                    masterActivity.currentOrderItem.order_thobe_fabric,masterActivity.currentOrderItem.order_thobe_cuff,masterActivity.currentOrderItem.order_thobe_collar,masterActivity.currentOrderItem.order_thobe_byoke,masterActivity.currentOrderItem.order_thobe_fyoke,
                    masterActivity.currentOrderItem.order_thobe_placket,masterActivity.currentOrderItem.order_thobe_numpocket,masterActivity.currentOrderItem.order_thobe_pocketstyle,masterActivity.currentOrderItem.order_thobe_placketstyle,
                    masterActivity.currentOrderItem.order_thobe_pleat,masterActivity.currentOrderItem.order_thobe_sidepocket,masterActivity.currentOrderItem.order_thobe_slit,masterActivity.currentOrderItem.order_thobe_elbow,
                    currentDate, currentDate, "",0,masterActivity.currentOrderItem.user_id, masterActivity.currentOrderItem.orderDeliveryInstructions, masterActivity.currentOrderItem.optSelectedMap);

            thisOrder.tailor_name = masterActivity.currentOrderItem.tailor_name;
            thisOrder.tailor_id = masterActivity.currentOrderItem.tailor_id;

            // Thobe
            thisOrder.selectedThobe             = masterActivity.currentOrderItem.selectedThobe;

            // Set options
            thisOrder.selectedFabricOption      = masterActivity.currentOrderItem.selectedFabricOption;
            thisOrder.selectedCollarOption      = masterActivity.currentOrderItem.selectedCollarOption;
            thisOrder.selectedCuffOption        = masterActivity.currentOrderItem.selectedCuffOption;
            thisOrder.selectedPlacketOption     = masterActivity.currentOrderItem.selectedPlacketOption;
            thisOrder.selectedPocketOption      = masterActivity.currentOrderItem.selectedPocketOption;
            thisOrder.selectedSidePocketOption  = masterActivity.currentOrderItem.selectedSidePocketOption;
//            thisOrder.optSelectedMap            = masterActivity.currentOrderItem.optSelectedMap;
            thisOrder.deliveryCost              = masterActivity.currentOrderItem.deliveryCost;

            // Add order item to cart
            masterActivity.currentOrderItem = thisOrder;
            masterActivity.currentSession.addItemToCart(thisOrder);
            masterActivity.currentOrderItem.order_placed_in_cart = true;
        }
    }

    // Update the quantity of thobe
    public void adjustQuantity(int ord_position_num, int operation ) {
        //operation - 0 = incr, 1= decr
        int curr_quantity = masterActivity.currentSession.current_session_cart.get(ord_position_num).order_quantity;

        if (operation == 1){
            if (curr_quantity > 1) {
                masterActivity.currentSession.current_session_cart.get(ord_position_num).order_quantity = curr_quantity - 1 ;
            }
        } else if (operation == 0){
            masterActivity.currentSession.current_session_cart.get(ord_position_num).order_quantity = curr_quantity + 1 ;
        }

        fillAdapterFromOrders(false);
    }

    // Update the total checkout price
    public void updateTotalOrderCost(){
        orderTotalCostText.setText(getString(R.string.sar, String.format(new Locale("en"), "%.2f", total_cart_price)));
    }

    // Delete order
    public void deleteOrder(int ord_position_num){
        masterActivity.currentSession.current_session_cart.remove(ord_position_num);

        fillAdapterFromOrders(true);

        // Go to style selection page
        if (orderReviewArray.size() == 0){
            Navigation.findNavController(frag_view).navigate(R.id.action_orderReviewFragment_to_styleSelectFragment);
        }
    }

    public void fillAdapterFromOrders(boolean reloadList){
        //all orders (including the active one) are in the cart - so just work through the cart in the active session
        total_cart_price = 0;

        if (masterActivity != null) {

            //Reset the Array
            if (orderReviewArray == null) {
                orderReviewArray = new ArrayList<>();
            } else {
                orderReviewArray.clear();
            }


            for (int i =0 ; i< masterActivity.currentSession.current_session_cart.size() ; i++) {

                if (masterActivity != null) {

                    OrderReviewDetails curr_order_detail = new OrderReviewDetails();

                    float itemPrice = masterActivity.currentSession.current_session_cart.get(i).item_price;
                    curr_order_detail.order_item_price =  itemPrice;

                    curr_order_detail.order_shipping_price = masterActivity.currentSession.current_session_cart.get(i).deliveryCost;

//                    float itemTotalPrice = itemPrice * masterActivity.currentSession.current_session_cart.get(i).order_quantity;
                    curr_order_detail.order_total_price = itemPrice * masterActivity.currentSession.current_session_cart.get(i).order_quantity;

                    curr_order_detail.order_thobe_style = masterActivity.currentSession.current_session_cart.get(i).order_thobe_style;
                    curr_order_detail.selectedThobe = masterActivity.currentSession.current_session_cart.get(i).selectedThobe;

                    curr_order_detail.order_tailor_name = masterActivity.currentSession.current_session_cart.get(i).tailor_name;
                    curr_order_detail.order_qty = masterActivity.currentSession.current_session_cart.get(i).order_quantity;

                    curr_order_detail.selectedOptionsMap = masterActivity.currentSession.current_session_cart.get(i).optSelectedMap;
                    ////////////////////////////////////////////

                    curr_order_detail.deliveryInstructions = masterActivity.currentSession.current_session_cart.get(i).orderDeliveryInstructions;

                    if (masterActivity.currentSession.currentUser.defaultUserAddressIndex >= 0) {
                        curr_order_detail.order_address_line = getFullAddress(masterActivity.currentSession.currentUser.addressList.get(masterActivity.currentSession.currentUser.defaultUserAddressIndex));
                    }

                    String order_date_string = curr_order_detail.order_measure_sched_time = AllHelpers.dateToStr(masterActivity.currentSession.measure_date);
                    curr_order_detail.order_measure_sched_time = order_date_string  + " - " + masterActivity.currentSession.measure_time_interval + ":00";

                    // timeslot id
                    curr_order_detail.order_time_id = masterActivity.currentSession.timeSlotId;

                    orderReviewArray.add(curr_order_detail);
                }

            }

            if (reloadList)
                refreshOrderAdapter();

            // Get the total price
            total_cart_price = masterActivity.currentSession.getTotalCartPrice();
            masterActivity.currentSession.updateAllCartItemsPrice();

            // Update the total cost
            updateTotalOrderCost();
        }
    }

    // Refresh the order info
    public void refreshOrderAdapter(){
        orderReviewRecycleAdapter = new OrderReviewRecycleAdapter(orderReviewRecycler, orderReviewArray,this, masterActivity.master_screen_width, master_screen_height, getContext());
        orderReviewRecycler.setAdapter(orderReviewRecycleAdapter);
        orderReviewRecycleAdapter.notifyDataSetChanged();
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onOrderReviewFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void setFragTitle(String newTitle);
        void onOrderReviewFragmentInteraction(Uri uri);
    }
}
