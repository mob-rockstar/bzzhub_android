package com.tailor.kesaa.model.thobe;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
public class ThobeStyleData {
    @SerializedName("id")
    @Expose
    private Integer id;

    @SerializedName("arabicName")
    @Expose
    private String arabicName;

    @SerializedName("englishName")
    @Expose
    private String englishName;

    @SerializedName("image")
    @Expose
    private String image;

    @SerializedName("arabicDescription")
    @Expose
    private String arabicDescription;

    @SerializedName("englishDescription")
    @Expose
    private String englishDescription;

    @SerializedName("createdDate")
    @Expose
    private String createdDate;

    @SerializedName("status")
    @Expose
    private Integer status;

    @SerializedName("updatedDate")
    @Expose
    private String updatedDate;

    // English Descriptions for size
    @SerializedName("smallEnglishDescription")
    @Expose
    public String enSmallSize;

    @SerializedName("mediumEnglishDescription")
    @Expose
    public String enMediumSize;

    @SerializedName("largeEnglishDescription")
    @Expose
    public String enLargeSize;

    // Arabic Descriptions for size
    @SerializedName("smallArabicDescription")
    @Expose
    public String arSmallSize;

    @SerializedName("mediumArabicDescription")
    @Expose
    public String arMediumSize;

    @SerializedName("largeArabicDescription")
    @Expose
    public String arLargeSize;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getArabicName() {
        return arabicName;
    }

    public void setArabicName(String arabicName) {
        this.arabicName = arabicName;
    }

    public String getEnglishName() {
        return englishName;
    }

    public void setEnglishName(String englishName) {
        this.englishName = englishName;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getArabicDescription() {
        return arabicDescription;
    }

    public void setArabicDescription(String arabicDescription) {
        this.arabicDescription = arabicDescription;
    }

    public String getEnglishDescription() {
        return englishDescription;
    }

    public void setEnglishDescription(String englishDescription) {
        this.englishDescription = englishDescription;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(String updatedDate) {
        this.updatedDate = updatedDate;
    }
}
