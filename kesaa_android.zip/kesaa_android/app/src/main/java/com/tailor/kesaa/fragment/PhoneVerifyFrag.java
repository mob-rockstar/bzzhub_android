package com.tailor.kesaa.fragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.tailor.kesaa.MainActivity;
import com.tailor.kesaa.R;
import com.tailor.kesaa.customs.CustomFontTextView;
import com.tailor.kesaa.model.UserTemplate;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link PhoneVerifyFrag.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link PhoneVerifyFrag#newInstance} factory method to
 * create an instance of this fragment.
 */
public class PhoneVerifyFrag extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    public String TAG = "PHNVERIF";

    public EditText otpEditText;
    public MainActivity masterActivity;
    private OnFragmentInteractionListener mListener;
    private String mVerificationId;
    public PhoneAuthProvider.ForceResendingToken mResendToken;
    public PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;

    @BindView(R.id.resend_code_text)
    CustomFontTextView resendCodeText;

    @BindView(R.id.remaining_time_Text)
    CustomFontTextView remainingTimeText;

    public PhoneVerifyFrag() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment PhoneVerifyFrag.
     */
    // TODO: Rename and change types and number of parameters
    public static PhoneVerifyFrag newInstance(String param1, String param2) {
        PhoneVerifyFrag fragment = new PhoneVerifyFrag();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_phone_verify, container, false);
        ButterKnife.bind(this, view);

        otpEditText = view.findViewById(R.id.phone_verify_sms_code_edit_text);

        Button otp_btn = view.findViewById(R.id.btn_otp_verify);
        otp_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                verifyOTP();
            }
        });
        return view;
    }

    // Resend code
    @OnClick(R.id.resend_code_text) void resendOtpCode(){

    }

    // [START sign_in_with_phone]
    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        masterActivity.currentSession.firebaseAuth.signInWithCredential(credential)
                .addOnCompleteListener(getActivity(), new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update session  with the signed-in user's information
                            Log.d(TAG, "signInWithPhoneCredential:success");
                            FirebaseUser user = task.getResult().getUser();
                            getMySQLuserDetailsFromUid(user.getUid(),false);
                        } else {
                            // Sign in failed, display a message and update the UI
                            Log.d(TAG, "signInWithCredential:failure", task.getException());
                            if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                                // The verification code entered was invalid
                            }
                        }
                    }
                });
    }

    public void getMySQLuserDetailsFromUid(final String uid, final boolean cameFromNotification) {

        String url = "http://harrierlabs.com/kessa/admin/production/customer_control_master.php?func=2&user_uid="+ uid;
        Log.d(TAG,"calling getMySQLuserDetails with" + url);

        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(getContext());
        StringRequest sr = new StringRequest(Request.Method.GET, url,
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d(TAG, "success! response: " + response.toString());
                        Toast.makeText(getContext(), "login_php : " + response + " " , Toast.LENGTH_LONG).show();
                        processServerUserDetails(uid,response.toString(), cameFromNotification);
                    }
                },
                new com.android.volley.Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Toast.makeText(getContext(), "login_err_php : " + error.toString() + " " , Toast.LENGTH_LONG).show();
                        Log.d(TAG, "error: " + error.toString());
                    }
                })
        {

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String,String> params = new HashMap<String, String>();
                params.put("Content-Type","application/x-www-form-urlencoded");
                return params;
            }
        };
        queue.add(sr);

    }

    public void processServerUserDetails(String uid, String incomingStr, boolean cameFromNotification) {

        try {

            JSONArray jArray = new JSONArray(incomingStr);
            Log.d(TAG, Integer.toString(jArray.length()));
            for (int arr_elem = 0 ; arr_elem < jArray.length() ; arr_elem++)
            {
                JSONObject explrObject = jArray.getJSONObject(arr_elem);
                Log.d(TAG, explrObject.toString());
                Log.d(TAG, Integer.toString(arr_elem));

                if (masterActivity.currentSession != null) {
                    if (masterActivity.currentSession.currentUser == null) {
                        masterActivity.currentSession.currentUser = new UserTemplate(uid);
                    }
                    masterActivity.currentSession.currentUser.id = explrObject.getInt("user_id");


                    if (masterActivity.currentSession.currentUser.id > 0) {
                        Log.d(TAG, "USER is : "+ Integer.toString(masterActivity.currentSession.currentUser.id));
                        masterActivity.navController.navigate(R.id.action_phoneVerifyFrag_to_styleSelectFragment);
                    }

                } else {
                    Toast.makeText(getContext(), "login : session is null  " , Toast.LENGTH_LONG).show();
                }




            }

        } catch (Throwable t) {
            Log.e(TAG, "Could not parse malformed userdet JSONArray: \"" + t.getMessage() + "\"");
        }


    }

    public void verifyOTP(){
        String enteredCode = otpEditText.getText().toString();
        verifyPhoneNumberWithCode(masterActivity.currentSession.mVerificationId,enteredCode);
    }

    private void verifyPhoneNumberWithCode(String verificationId, String code) {
        // [START verify_with_code]
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationId, code);
        // [END verify_with_code]
        signInWithPhoneAuthCredential(credential);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
