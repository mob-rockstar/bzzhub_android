package com.tailor.kesaa.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.tailor.kesaa.global.AllHelpers;
import com.tailor.kesaa.model.CustomizeOptionElement;
import com.tailor.kesaa.fragment.CustomizeStyleFragment;
import com.tailor.kesaa.R;

import java.util.ArrayList;

public class CustomizerDataBaseAdapter extends BaseAdapter  implements  View.OnClickListener {

    public CustomizeStyleFragment customizeParentFrag;
    public ArrayList<CustomizeOptionElement> customizeOptionElementDataSet;
    public Context mContext;

    public CustomizerDataBaseAdapter(Context mainContext, ArrayList<CustomizeOptionElement> customizeOptionElementDataSet, CustomizeStyleFragment customizeParentFrag ) {
        this.mContext = mainContext;
        this.customizeParentFrag = customizeParentFrag;
        this.customizeOptionElementDataSet = customizeOptionElementDataSet;
    }


    public void refreshDataSet(ArrayList<CustomizeOptionElement> newDataSet) {
        this.customizeOptionElementDataSet = newDataSet;
    }
    @Override
    public int getCount() {
        return customizeOptionElementDataSet.size();
    }

    @Override
    public Object getItem(int i) {
        return customizeOptionElementDataSet.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        // Get the data item for this position
        CustomizeOptionElement dataModel = (CustomizeOptionElement) getItem(position);

        CustomizerOptionCardHolder viewHolder;

        if (convertView == null || convertView.getTag() == null ) {
            viewHolder = new CustomizerDataBaseAdapter.CustomizerOptionCardHolder();
            convertView = LayoutInflater.from(mContext).
                    inflate(R.layout.customize_item, parent, false);
            viewHolder.customizeOptionName = convertView.findViewById(R.id.customize_text_item);
            viewHolder.customizeOptionPic =  convertView.findViewById(R.id.customize_image_item);
            viewHolder.customizeCheckSelect =  convertView.findViewById(R.id.customize_check_item);
            convertView.setTag(viewHolder);
        } else {

            viewHolder = (CustomizerDataBaseAdapter.CustomizerOptionCardHolder) convertView.getTag();

        }

/*
        Animation animation = AnimationUtils.loadAnimation(mContext,  R.anim.shake);
        result.startAnimation(animation);
*/

        viewHolder.customizeOptionName.setText(dataModel.optionName);
        viewHolder.customizeOptionPic.setImageResource(AllHelpers.optImageSetter(dataModel.optionName));


        if (dataModel.optionSelected) {
            viewHolder.customizeCheckSelect.setVisibility(View.VISIBLE);
        } else {
            viewHolder.customizeCheckSelect.setVisibility(View.INVISIBLE);
        }



        viewHolder.customizeOptionName.setTag(position);
        viewHolder.customizeOptionPic.setTag(position);


        viewHolder.customizeOptionPic.setOnClickListener(this);
        viewHolder.customizeOptionName.setOnClickListener(this);
        // Return the completed view to render on screen
        return convertView;

    }

    @Override
    public void onClick(View view) {

        int position=(Integer) view.getTag();
        Object object= getItem(position);
        CustomizeOptionElement currBaseOption = (CustomizeOptionElement)object;

        String tester = "none";
        if (currBaseOption.optionSelected) {
            tester = "true " ;
        } else {
            tester = "false ";
        }

        Toast err_toast = Toast.makeText(view.getContext()," base clicked on " + ((CustomizeOptionElement) object).optionName + tester,Toast.LENGTH_LONG);
        //err_toast.show();
        //customizeParentFrag.optionToggled(currBaseOption.optionDBname, currBaseOption.op);

    }

    private  static class CustomizerOptionCardHolder {
        TextView customizeOptionName;
        ImageView customizeOptionPic;
        ImageView customizeCheckSelect;


    }
}
