package com.tailor.kesaa.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import com.bumptech.glide.Glide;
import com.tailor.kesaa.customs.CustomFontTextView;
import com.tailor.kesaa.global.AllHelpers;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;
import com.tailor.kesaa.model.order.OrderHistoryDetails;
import com.tailor.kesaa.R;
import com.tailor.kesaa.fragment.OrderHistoryFragment;

public class OrderHistoryAdapter extends ArrayAdapter<OrderHistoryDetails> implements View.OnClickListener {

    private ArrayList<OrderHistoryDetails> orderHistoryDataset;
    private OrderHistoryFragment masterOfrag;
    Context mContext;

//    public  int screen_width = -1;
//    public  int screen_height = -1;
//    public int scaled_margin = -1;


    private static class OrderHistoryDetailCardHolder {

        TextView styleName;
        TextView transOrderID;
        TextView orderDate;
        TextView orderTotalPrice;

        ImageView styleOptionPic;
        TextView statusTag;

        CustomFontTextView shippingPriceText;

        RelativeLayout full_wrapper;
        LinearLayout pic_block;
        LinearLayout mid_block;
        LinearLayout price_block;
    }

    public OrderHistoryAdapter(ArrayList<OrderHistoryDetails> data, Context context, OrderHistoryFragment oFrag, int width, int height) {
        super(context, R.layout.order_history_card, data);
        this.orderHistoryDataset = data;
        this.mContext=context;
        this.masterOfrag = oFrag;
//        this.screen_width = width;
//        this.screen_height = height;

//        float scaler_value = 0.0f;
//        if (this.screen_width <= 721) {
//            scaler_value = 50.0f;
//        } else {
//            scaler_value = 25.0f;
//        }
//
//        int scaled_margin = Math.round(this.screen_width/scaler_value);

    }

    @Override
    public void onClick(View v) {

        int position=(Integer) v.getTag();

        masterOfrag.orderClicked(position);
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {


        OrderHistoryDetails dataModel = getItem(position);
        OrderHistoryAdapter.OrderHistoryDetailCardHolder viewHolder; // view lookup cache stored in tag


        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.order_history_card, parent, false);

            viewHolder = new OrderHistoryAdapter.OrderHistoryDetailCardHolder();


            viewHolder.full_wrapper         = convertView.findViewById(R.id.order_history_card_view_internal_master_wrapper);
            viewHolder.styleName            = convertView.findViewById(R.id.order_history_style_name);
            viewHolder.orderTotalPrice      = convertView.findViewById(R.id.order_history_price);
            viewHolder.orderDate            = convertView.findViewById(R.id.order_history_order_date);
            viewHolder.statusTag            = convertView.findViewById(R.id.order_history_status_tag);
            viewHolder.styleOptionPic      = convertView.findViewById(R.id.order_history_style_image);
            viewHolder.transOrderID         = convertView.findViewById(R.id.order_history_trans_order_id);
            viewHolder.shippingPriceText    = convertView.findViewById(R.id.ord_review_shipping_price);

            convertView.setTag(viewHolder);
            Log.d("OrderHistory", "Setting tag - " + convertView.getTag().toString());
        }
        else {
            viewHolder = (OrderHistoryAdapter.OrderHistoryDetailCardHolder) convertView.getTag();
        }

//        String style_name  = "";
//        switch (dataModel.order_thobe_style) {
//            case AllHelpers.SAUDI:
//                viewHolder.styleOptionPic.setImageResource(R.drawable.ic_saudi_style);
//                style_name = mContext.getString(R.string.saudi);
//                break;
//            case AllHelpers.EMIRATI:
//                viewHolder.styleOptionPic.setImageResource(R.drawable.ic_uae_style);
//                style_name = mContext.getString(R.string.emirati);
//                break;
//            case AllHelpers.BAHRAINI:
//                viewHolder.styleOptionPic.setImageResource(R.drawable.ic_bahrain_style);
//                style_name = mContext.getString(R.string.bahraini);
//                break;
//            case AllHelpers.KUWAITI:
//                viewHolder.styleOptionPic.setImageResource(R.drawable.ic_kuwait_style);
//                style_name = mContext.getString(R.string.kuwaiti);
//                break;
//            default:
//                style_name = "Unknown Style";
//                break;
//        }

        // Style name
        if (MyPreferenceManager.getInstance(mContext).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH) {
            viewHolder.styleName.setText(dataModel.styleEnglishName);
        }
        else{
            viewHolder.styleName.setText(dataModel.styleArabicName);
        }

        // Style image
        Glide.with(mContext).load(dataModel.styleImagePath).into(viewHolder.styleOptionPic);

        // Order id
        String orderNoString = "#" + dataModel.order_id;
        viewHolder.transOrderID.setText(mContext.getString(R.string.order_format, orderNoString));

        viewHolder.full_wrapper.setTag(position);
        viewHolder.full_wrapper.setOnClickListener(this);

        // Order cost
        double finalCost = (dataModel.order_total_price + 30) * 1.05;
        viewHolder.orderTotalPrice.setText(mContext.getString(R.string.sar, String.format(new Locale("en"), "%.2f", dataModel.order_total_price)));//     Float.toString(dataModel.order_total_price));

        // Order created date
        Date orderCreatedDate = AllHelpers.strToDate(dataModel.order_placement_date);
        viewHolder.orderDate.setText(AllHelpers.dateToStr(orderCreatedDate));

//        viewHolder.shippingPriceText.setText(mContext.getString(R.string.shipping_amount, "+30"));

        String status_tag_str = "unknown";
        int status_tag_colour = -1;

//        if (dataModel.order_cancel_status  == 0) {

            switch (dataModel.order_status) {
                case  0:
                    status_tag_str = mContext.getString(R.string.new_order); // Order created
                    status_tag_colour = R.color.kessaStatusOrange;
                    break;
                case  1:
                    status_tag_str = mContext.getString(R.string.measurement_complete); // Measurement
                    status_tag_colour = R.color.kessaStatusOrange;
                    break;
                case  2:
                    status_tag_str = mContext.getString(R.string.tailor_accepted); // Tailor Accepted
                    status_tag_colour = R.color.kessaStatusOrange;
                    break;
                case  3:
                    status_tag_str = mContext.getString(R.string.sewing); //"Sewing";
                    status_tag_colour = R.color.kessaStatusOrange;
                    break;
                case  4:
                    status_tag_str = mContext.getString(R.string.pickup); //"Pickup";
                    status_tag_colour = R.color.kessaStatusGreen;
                    break;
                case  5:
                    status_tag_str = mContext.getString(R.string.delivered); //"Delivered";
                    status_tag_colour = R.color.kessaStatusGreen;
                    break;
                default:
                    status_tag_str = mContext.getString(R.string.unknown); //"Unknown";
                    status_tag_colour = R.color.kessaStatusRed;
                    break;
            }

//        } else {
//            status_tag_str = mContext.getString(R.string.canceled);
//            status_tag_colour = R.color.kessaStatusRed;
//        }

        viewHolder.statusTag.setBackgroundColor( viewHolder.statusTag.getContext().getResources().getColor(status_tag_colour));
        viewHolder.statusTag.setText(status_tag_str);

        return convertView;
    }

}


