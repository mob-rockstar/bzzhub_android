package com.tailor.kesaa.customs;

import android.util.Log;
import android.view.View;

import androidx.viewpager.widget.ViewPager;

public class FadePageTransformer implements ViewPager.PageTransformer {
    private static final float MIN_SCALE = 0.6f;
    private static final float MIN_ALPHA = 0.3f;

    public void transformPage(View view, float position) {
        int pageWidth = view.getWidth();
        int pageHeight = view.getHeight();

        float scaleFactor = Math.max(MIN_SCALE, 1 - Math.abs(position));

        Log.d("TRX",  Float.toString(position));

        if (position < -1) { // [-Infinity,-1)
            // This page is way off-screen to the left.
            view.setAlpha(0);
            view.setScaleX(MIN_SCALE);
            view.setScaleY(MIN_SCALE);

        } else if (position <= 0) { // [-1,0]
            // Use the default slide transition when moving to the left page
            view.setAlpha(1.0f-0.7f*Math.abs(position));
            view.setTranslationY(-1.0f*Math.abs(position)*350);

            view.setScaleX(scaleFactor);
            view.setScaleY(scaleFactor);

        } else if (position <= 1) { // (0,1]
            // Fade the page out.
            view.setAlpha(1.0f-0.7f*Math.abs(position));
            view.setTranslationY(-1.0f*Math.abs(position)*250);

            view.setScaleX(scaleFactor);
            view.setScaleY(scaleFactor);


        } else { // (1,+Infinity]
            // This page is way off-screen to the right.
            view.setAlpha(0);

            view.setScaleX(MIN_SCALE);
            view.setScaleY(MIN_SCALE);
        }

    }
}