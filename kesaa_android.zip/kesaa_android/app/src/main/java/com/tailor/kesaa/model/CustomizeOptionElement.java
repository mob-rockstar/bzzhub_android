package com.tailor.kesaa.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CustomizeOptionElement {

    @SerializedName("id")
    @Expose
    public int id_num;

    @SerializedName("englishName")
    @Expose
    public String optionName;

    @SerializedName("arabicName")
    @Expose
    public String optionNameAr;

    @SerializedName("image")
    @Expose
    public String imagePath;

    @SerializedName("price")
    @Expose
    public String price;

    // flag to check if it needs to show the popup,
    // for fabric, type = 1
    @SerializedName("type")
    @Expose
    public int type;

    @SerializedName("createdDate")
    @Expose
    public String createdDate;

    @SerializedName("status")
    @Expose
    public int status;

    @SerializedName("updatedDate")
    @Expose
    public String updatedDate;

    // DB Name
    @SerializedName("key")
    @Expose
    public String optionDBname;

    // english description
    @SerializedName("englishDescription")
    @Expose
    public String enDescription;

    // arabic description
    @SerializedName("arabicDescription")
    @Expose
    public String arDescription;

    // arabic category name
    @SerializedName("categoryArabicName")
    @Expose
    public String categoryNameAr;

    // english category name
    @SerializedName("categoryEnglishName")
    @Expose
    public String categoryNameEn;

    // category ID
    @SerializedName("categoryId")
    @Expose
    public int categoryId;

    // Flag check if current option is selected or not
    public boolean optionSelected;

    public CustomizeOptionElement(int id_num, String optionName, String optionDBname, boolean optionSelected, String optionNameAr) {
        this.id_num = id_num;
        this.optionName = optionName;
        this.optionDBname = optionDBname;
        this.optionSelected = optionSelected;
        this.optionNameAr = optionNameAr;
    }
}
