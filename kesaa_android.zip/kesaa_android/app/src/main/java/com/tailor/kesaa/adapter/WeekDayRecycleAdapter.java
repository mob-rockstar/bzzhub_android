package com.tailor.kesaa.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;


import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.tailor.kesaa.R;
import com.tailor.kesaa.model.WeekDayDetails;
import com.tailor.kesaa.fragment.MeasureScheduleFragment;

public class WeekDayRecycleAdapter extends RecyclerView.Adapter<WeekDayRecycleAdapter.WeekDayCardHolder> {

    public RecyclerView recyclerView;
    private ArrayList<WeekDayDetails> weekDayDataSet;
    private MeasureScheduleFragment masterSchedfrag;
    public int width;
    public int height;
    Context mContext;

    public WeekDayRecycleAdapter(RecyclerView rView, ArrayList<WeekDayDetails> orderDataset, MeasureScheduleFragment masterOfrag, int width, int height, Context mContext) {
        this.recyclerView = rView;
        this.weekDayDataSet = orderDataset;
        this.masterSchedfrag = masterOfrag;
        this.width = width;
        this.height = height;
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public WeekDayRecycleAdapter.WeekDayCardHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.week_layout_card, parent, false);


        /*
        LinearLayout card_wrapper = (LinearLayout) itemView.findViewById(R.id.weekday_card_main_linear_wrapper);
        ViewGroup.LayoutParams imViewParams = card_wrapper.getLayoutParams();
        imViewParams.width = Math.round((this.width-60)/7);
        card_wrapper.setLayoutParams(imViewParams );
        */

        Button datebtn = (Button) itemView.findViewById(R.id.measure_date_card_date_btn);
        ViewGroup.LayoutParams datebtnViewParams = datebtn.getLayoutParams();

        int scaler = 70;

        if (width >= 1079) {
            scaler= 70;
        } else {
            scaler =40;
        }


        datebtnViewParams.width     = scaler;
        datebtnViewParams.height    = scaler;
        datebtn.setLayoutParams(datebtnViewParams);





        return new WeekDayRecycleAdapter.WeekDayCardHolder(itemView, this.width, this.height);
    }

    @Override
    public void onBindViewHolder(@NonNull WeekDayRecycleAdapter.WeekDayCardHolder holder, int position) {
        holder.bind();

    }

    @Override
    public int getItemCount() {
        return weekDayDataSet.size();
    }


    public class WeekDayCardHolder extends RecyclerView.ViewHolder implements View.OnClickListener {


        TextView dayName;
        Button dateNum;


        public WeekDayCardHolder(View itemView, int screen_width, int screen_height) {
            super(itemView);

            dayName = itemView.findViewById(R.id.measure_date_card_day);
            dateNum = itemView.findViewById(R.id.measure_date_card_date_btn);

        }


        @Override
        public void onClick(View view) {

            int position = getAdapterPosition();
            String tag = (String) view.getTag();
            WeekDayRecycleAdapter.WeekDayCardHolder holder = (WeekDayRecycleAdapter.WeekDayCardHolder) recyclerView.findViewHolderForAdapterPosition(position);

            if (holder != null) {
                if (tag != null) {


                }


            }
        }


            public void bind() {

                int activeposition = getAdapterPosition();

                dayName.setTag("click");
                dateNum.setTag("btnclick");
                dateNum.setOnClickListener(this);

                int currDate = weekDayDataSet.get(activeposition).dayDate;
                String currDay = weekDayDataSet.get(activeposition).dayName;


                if (activeposition == 3) {
                    dateNum.setBackground(ContextCompat.getDrawable(dateNum.getContext(), R.drawable.green_btn_round));
                    dateNum.setTextColor( dateNum.getContext().getResources().getColor(R.color.kessaWhite));
                } else {
                    dateNum.setBackground(ContextCompat.getDrawable(dateNum.getContext(), R.drawable.ligt_gray_btn_round));
                    dateNum.setTextColor( dateNum.getContext().getResources().getColor(R.color.kessaBlack));
                }
                dayName.setText(currDay);
                dateNum.setText(Integer.toString(currDate));

            }


        }
    }

