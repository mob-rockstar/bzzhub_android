package com.tailor.kesaa.webservice;

import android.content.Context;

import com.google.gson.JsonObject;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;
import com.tailor.kesaa.model.AddressListData;
import com.tailor.kesaa.model.NewAddressDataResponse;
import com.tailor.kesaa.model.faq.FaqListResponse;
import com.tailor.kesaa.model.notification.NotificationListReponse;
import com.tailor.kesaa.model.order.OrderListResponse;
import com.tailor.kesaa.model.style.OptionListResponse;
import com.tailor.kesaa.model.tailor.CommentListResponse;
import com.tailor.kesaa.model.tailor.TailorListResponse;
import com.tailor.kesaa.model.thobe.ThobeStyleListResponse;
import com.tailor.kesaa.model.user.UserResponseData;

import java.util.HashMap;

import io.reactivex.Observable;
import okhttp3.RequestBody;


public class KesaaServiceManager {

    private Api api;
    private Context mContext;
    private MyPreferenceManager preferenceManager;

    // Constructor
    public KesaaServiceManager(Context context){
        this.mContext = context;
        this.api = HttpUtils.getRetrofit(Api.BASE_URL).create(Api.class);
        this.preferenceManager = MyPreferenceManager.getInstance(mContext);
    }

    // Get user id
    private int getUserId(){
        return preferenceManager.getInt(SettingsKeys.KEY_USER_ID, 0);
    }

    // Get device token
    private String getDeviceToken(){
        return preferenceManager.getString(SettingsKeys.KEY_DEVICE_TOKEN, "");
    }
    // Get access token
    private String getAccessToken(){
        return preferenceManager.getString(SettingsKeys.KEY_ACCESS_TOKEN, "");
    }

    private String getHeader(){
        return "Bearer " + getAccessToken();
    }

    // User Details with Firebase ID
    public Observable<UserResponseData> getUserDetails(RequestBody body){
        return api.getUserDetails(body);
    }

    // Create new address
    public Observable<NewAddressDataResponse> createNewAddress(RequestBody body){
        return api.createNewAddress(body);
    }

    // Update address
    public Observable<NewAddressDataResponse> updateAddress(RequestBody body){
        return api.updateAddress(body);
    }

    // Address list
    public Observable<AddressListData> getAddressList(String userId) {
        return api.getAddressList(userId);
    }

    // Updated address list
    public Observable<JsonObject> updateAddresses(String uID, String addressJson, String uUID){
        return api.updateAddressList(10, addressJson, uID, uUID);
    }

    public Observable<JsonObject> deleteAddress(int addressId){
        return api.deleteAddress(String.valueOf(addressId));
    }

    // Update user details
    public Observable<JsonObject> updateUserCredentials(RequestBody body){
        return  api.updateUserDetails(body);
    }

    // Get user info
    public Observable<UserResponseData> getUserInfo(int uID){
        return api.getUserCredentialsWithId(String.valueOf(uID));
    }

    // Get thobe list
    public Observable<ThobeStyleListResponse> getThobes(){
        return api.getThobeStyles();
    }

    // Get option list
    public Observable<OptionListResponse> getCustomOptions(int styleId){
        return api.getCustomOptions(String.valueOf(styleId));
    }

    // Get timeslots
    public Observable<JsonObject> getTimeSlots(String dateString){
        return api.getTimeSlots(dateString);
    }

    // Get tailors
    public Observable<TailorListResponse> getTailors(HashMap<String, Object> body/*RequestBody body*/){
        return api.getTailors(body);
    }

    // Get comments
    public Observable<CommentListResponse> getComments(int tailorId){
        return api.getComments(String.valueOf(tailorId));
    }

    // Get faq
    public Observable<FaqListResponse> getFaqList(){
        return api.getFaqList();
    }

    // Create new order
    public Observable<JsonObject> createNewOrder(HashMap<String, Object> body){
        return api.createNewOrder(body);
    }

    // Get order list
    public Observable<OrderListResponse> getOrders(RequestBody body){
        return api.getOrderHistory(body);
    }

    // Get order details
    public Observable<JsonObject> getOrderDetails(int orderId){
        return api.getOrderDetails(String.valueOf(orderId));
    }

    // Get notifications
    public Observable<NotificationListReponse> getNotifications(RequestBody body){
        return api.getNotifications(body);
    }

    // Rate tailor
    public Observable<JsonObject> rateTailor(RequestBody body){
        return api.rateTailor(body);
    }

    // Get Checkout ID
    public Observable<JsonObject> getCheckoutID(HashMap<String, Object> body) {
        return api.requestCheckoutID(body);
    }

    // Get Payment Status
    public Observable<JsonObject> getPaymentStatus(HashMap<String, Object> body) {
        return api.getPaymentStatus(body);
    }

    // Check coupon
    public Observable<JsonObject> checkCoupon(HashMap<String, Object> body) {
        return api.checkCoupon(body);
    }
}
