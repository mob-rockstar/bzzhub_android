package com.tailor.kesaa.model.tailor;

import java.io.Serializable;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TailorDetails implements Serializable {

    @SerializedName("tailorId")
    @Expose
    public Integer id;

//    @SerializedName("tailorId")
//    @Expose
//    public int TailorID;

    @SerializedName("name")
    @Expose
    public String TailorName;

    public String TailorAddress;

    @SerializedName("rating")
    @Expose
    public float TailorStarRating;

    @SerializedName("reviews")
    @Expose
    public int TailorNumReviews;

    public double distToMe = -1.0;

    // Delivery cost
    @SerializedName("delivery")
    @Expose
    public float deliveryCost = 0;

    // Total Cost
    @SerializedName("totalCost")
    @Expose
    public float totalCost = 0;

    // Total cost witt VAT
    @SerializedName("totalCostAfterVAT")
    @Expose
    public float TailorApproxPrice = 0;

    // Total cost with VAT

    @SerializedName("image")
    @Expose
    public String TailorImagePath;

    @SerializedName("deliveryDays")
    @Expose
    public int deliveryDays;

    public TailorDetails(int tailorID, String name, String address, float starRating, int numReviews, int appoxPrice) {
        this.id = tailorID;
        this.TailorName=name;
        this.TailorAddress=address;
        this.TailorStarRating=starRating;
        this.TailorNumReviews=numReviews;
        this.TailorApproxPrice=appoxPrice;

    }

    public String getName() {
        return TailorName;
    }

    public String getAddress() {
        return TailorAddress;
    }

    public float getRating() {
        return TailorStarRating;
    }

    public int getReviews() {
        return TailorNumReviews;
    }


}
