package com.tailor.kesaa.global;

import android.content.Context;
import android.graphics.Typeface;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;

import androidx.core.content.ContextCompat;

import com.tailor.kesaa.R;
import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.DayViewDecorator;
import com.prolificinteractive.materialcalendarview.DayViewFacade;

import java.util.Calendar;

public class MyDayDecorator implements DayViewDecorator {

    private Context mContext;
    public MyDayDecorator(Context context){
        mContext = context;
    }

    @Override
    public boolean shouldDecorate(CalendarDay calendarDay) {
        return calendarDay.isAfter(CalendarDay.today());
    }

    @Override
    public void decorate(DayViewFacade dayViewFacade) {

        // Set bold font
        dayViewFacade.addSpan(new StyleSpan(Typeface.BOLD));
        dayViewFacade.addSpan(new ForegroundColorSpan(ContextCompat.getColor(mContext, R.color.colorStyleTitle)));
    }
}
