package com.tailor.kesaa.fragment;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.JsonObject;
import com.oppwa.mobile.connect.checkout.dialog.CheckoutActivity;
import com.oppwa.mobile.connect.checkout.meta.CheckoutSettings;
import com.oppwa.mobile.connect.exception.PaymentError;
import com.oppwa.mobile.connect.provider.Connect;
import com.oppwa.mobile.connect.provider.Transaction;
import com.oppwa.mobile.connect.provider.TransactionType;
import com.tailor.kesaa.KesaaApplication;
import com.tailor.kesaa.MainActivity;
import com.tailor.kesaa.R;
import com.tailor.kesaa.customs.CustomFontButton;
import com.tailor.kesaa.customs.CustomFontEditText;
import com.tailor.kesaa.customs.CustomFontTextView;
import com.tailor.kesaa.global.AllHelpers;
import com.tailor.kesaa.global.EventBusMessage;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;
import com.tailor.kesaa.global.Utils;
import com.tailor.kesaa.model.ActiveSession;
import com.tailor.kesaa.model.CustomizeOptionElement;
import com.tailor.kesaa.model.OrderItemTemplate;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;


public class PaymentFragment extends Fragment {
    private static final String PAY_BRAND_VISA      = "VISA";
    private static final String PAY_BRAND_MASTER    = "MASTER";
    private static final String PAY_BRAND_MADA      = "MADA";

    private static final String TAG = "Payment";

    private MainActivity masterActivity;

    // Payment Reference for HyperPay
    private String paymentReference = "";
    private String checkoutID = "";
    private String selectedBrand = "";

    private View masterView;

    // Total cart price
    private float total_cart_price = 0;

    // Final total price
    private float final_price = 0;

    // Discount price
    private float discount_price = 0;

    // flag to check if promo code is applied
    private boolean isAppliedPromo = false;

    // promo code
    private String promoCode = "";

    @BindView(R.id.progressBar)
    ProgressBar progressBar;

    // Total amount
    @BindView(R.id.txt_total_amount)
    CustomFontTextView totalAmountText;

    // Discount amount
    @BindView(R.id.txt_discount_amount)
    CustomFontTextView discountAmountText;

    // Final amount
    @BindView(R.id.txt_final_total)
    CustomFontTextView finalAmountText;

    // Promo code
    @BindView(R.id.edt_promo_code)
    CustomFontEditText promoCodeEditText;

    @BindView(R.id.btn_apply)
    CustomFontButton applyButton;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View frag_view =  inflater.inflate(R.layout.fragment_payment, container, false);
        ButterKnife.bind(this, frag_view);

        masterView = frag_view;

        masterActivity = (MainActivity) getActivity();
        if (masterActivity != null){
            masterActivity.showActionBar();
            masterActivity.setFragTitle(getString(R.string.payment));

            // Firebase analytics event
            Bundle bundle = new Bundle();
            bundle.putString(FirebaseAnalytics.Param.SCREEN_NAME, "Payment");
            bundle.putString(FirebaseAnalytics.Param.SCREEN_CLASS, getClass().getSimpleName());
            masterActivity.mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SCREEN_VIEW, bundle);
        }

        // Get total cart price
        if (getArguments() != null){
            total_cart_price = getArguments().getFloat("total_amount", 0f);
            String formattedPrice = String.format(Locale.ENGLISH, "%.2f", total_cart_price);
            totalAmountText.setText(String.format(Locale.ENGLISH, getString(R.string.sar), formattedPrice));

            updateTotalAmount(discount_price);
        }

        // Register EventBus
        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this);



        return  frag_view;
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(EventBusMessage event) {
        /* Do something */
        if (event.getMessageType() == EventBusMessage.MessageType.HYPERPAY_ASYNC_CALLBACK) {
            String checkoutId = (String) event.getMessage();
            Log.d("Payment", "Checkout ID : " + checkoutId);

            // request payment status
            checkPaymentStatus();
        }
    }

    // Visa
    @OnClick(R.id.pay_option_visa_btn) void payWithVisa(){
        requestCheckoutId(PAY_BRAND_VISA);
    }

    // MasterCard
    @OnClick(R.id.pay_option_master_btn) void payWithMasterCard(){
        requestCheckoutId(PAY_BRAND_MASTER);
    }

    // Mada
    @OnClick(R.id.pay_option_mada_btn) void payWithMada(){
        requestCheckoutId(PAY_BRAND_MADA);
    }

    // Apply promo
    @OnClick(R.id.btn_apply) void applyPromoCode(){
        if (isAppliedPromo && !promoCode.isEmpty()) {
            isAppliedPromo = false;
            promoCode = "";
            promoCodeEditText.setText("");

            // Update the total amount
            updateTotalAmount(0);

            // Update button title into "Apply"
            applyButton.setText(getString(R.string.apply));
        }
        else{
            if (promoCodeEditText.getText() != null && !promoCodeEditText.getText().toString().trim().isEmpty()){
                String code = promoCodeEditText.getText().toString().trim();
                checkCoupon(code);
            }
            else{
                Log.d(TAG, "Empty promo code");
                Toast.makeText(masterActivity, getString(R.string.enter_promo_code), Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Testing pay
    @OnClick(R.id.btn_test_pay) void testPay(){
        updateAllOrderPaymentRefsSuccess(AllHelpers.PAY_TYPE_CASH, "");
    }

    // Check if coupon is valid
    private void checkCoupon(String code){
        // Dismiss the keyboard
        if (masterActivity != null){
            Utils.hideKeyboard(masterActivity);
        }

        HashMap<String, Object> params = new HashMap<>();
        params.put("code", code);
        params.put("amount", total_cart_price);

        // Show the loading progress
        progressBar.setVisibility(View.VISIBLE);

        // Call api to create the order
        KesaaApplication.getKesaaAPI().checkCoupon(params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<JsonObject>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(JsonObject jsonObject) {
                        progressBar.setVisibility(View.GONE);

                        if (jsonObject.get("code").getAsInt() == 200){
                            if (jsonObject.get("data") != null){
                                float discount = jsonObject.get("data").getAsFloat();

                                isAppliedPromo = true;
                                promoCode = code;

                                // Update the button title into Remove promo
                                applyButton.setText(getString(R.string.remove_promo));

                                // Update the total amount
                                updateTotalAmount(discount);
                            }
                            else{
                                if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                                    Toast.makeText(masterActivity, jsonObject.get("message").getAsString(), Toast.LENGTH_SHORT).show();
                                }
                                else{
                                    Toast.makeText(masterActivity, jsonObject.get("arabicMessage").getAsString(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        }
                        else{
                            // Show error message
                            if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                                Toast.makeText(masterActivity, jsonObject.get("message").getAsString(), Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(masterActivity, jsonObject.get("arabicMessage").getAsString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(masterActivity, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }

    // Update the total amount
    private void updateTotalAmount(float discount){
        // Display the discount amount
        String formattedPrice = String.format(Locale.ENGLISH, "%.2f", discount);
        discountAmountText.setText(String.format(Locale.ENGLISH, getString(R.string.sar), formattedPrice));

        // Set the discount amount
        discount_price = discount;

        // Calculate the final total amount
        final_price = total_cart_price - discount_price;
        formattedPrice = String.format(Locale.ENGLISH, "%.2f", final_price);
        finalAmountText.setText(String.format(Locale.ENGLISH, getString(R.string.sar), formattedPrice));
    }

    // Create the order
    public void createOrderOnServer(int paymentType){
        if (masterActivity != null && !Utils.isNetworkConnected(masterActivity)){
            Toast.makeText(masterActivity, getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
            return;
        }

        if (masterActivity== null || masterActivity.currentSession.current_session_cart.size() == 0){
            return;
        }

        updateAllOrderUserIDs();

        // Get order item
        OrderItemTemplate currentOrderItem = masterActivity.currentSession.current_session_cart.get(0);

        HashMap<String, Object> params = new HashMap<>();
        params.put("userId", currentOrderItem.user_id);
        params.put("styleId", currentOrderItem.selectedThobe.getId());
        params.put("hour", masterActivity.currentSession.measure_time_interval);
        params.put("requestDate", AllHelpers.dateToStr(masterActivity.currentSession.measure_date, "yyyy-MM-dd"));
        params.put("addressId", masterActivity.currentSession.currentUser.currOrderAddress.getId());
        params.put("tailorId", currentOrderItem.tailor_id);
        params.put("shippingType", 1);

        // Payment type
        params.put("cashOnMeasurement", paymentType);
        if (paymentType == AllHelpers.PAY_TYPE_HYPERPAY){ // HyperPay
            params.put("paymentId", paymentReference);
        }

        params.put("orderDeliveryInstructions", currentOrderItem.orderDeliveryInstructions);
        params.put("orderQuantity", currentOrderItem.order_quantity);

        // Get selected size
        String sizeStr = "small";
        if (currentOrderItem.order_size == 0){
            sizeStr = "small";
        }
        else if (currentOrderItem.order_size == 1){
            sizeStr = "medium";
        }
        else if (currentOrderItem.order_size == 2){
            sizeStr = "large";
        }

        params.put("size", sizeStr);

        if (paymentType == AllHelpers.PAY_TYPE_HYPERPAY){ // Hyper Pay
            params.put("cost", final_price);
        }
        else{ // Cash On Delivery
            params.put("cost", final_price);
        }

        // Get option array
        List<Integer> options = new ArrayList<>();
        Iterator myIterator = masterActivity.currentOrderItem.optSelectedMap.keySet().iterator();
        while(myIterator.hasNext()) {
            Integer key = (Integer) myIterator.next();
            CustomizeOptionElement value = (CustomizeOptionElement) masterActivity.currentOrderItem.optSelectedMap.get(key);

            if (value != null){
                options.add(value.id_num);
            }
        }

        // options
        params.put("options", options);

        // total cost
        params.put("timeslotId", masterActivity.currentSession.timeSlotId);

        if (isAppliedPromo && discount_price > 0) {
            params.put("coupon", promoCode);
        }

        // Show the loading progress
        progressBar.setVisibility(View.VISIBLE);

        // Call api to create the order
        KesaaApplication.getKesaaAPI().createNewOrder(params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<JsonObject>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(JsonObject jsonObject) {
                        progressBar.setVisibility(View.GONE);
                        if (jsonObject.get("code").getAsInt() == 200){
                            if (jsonObject.get("data") != null){
                                JsonObject orderJson = jsonObject.get("data").getAsJsonObject();

                                // Get order id
                                masterActivity.currentSession.last_active_transaction_number = orderJson.get("id").getAsInt();

                                // clear cart
                                clearCart();

                                // Go to order complete page
                                Navigation.findNavController(masterView).navigate(R.id.action_paymentFragment_to_checkOutFragment);
                            }
                        }
                        else{
                            // Show error message
                            if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                                Toast.makeText(masterActivity, jsonObject.get("message").getAsString(), Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(masterActivity, jsonObject.get("arabicMessage").getAsString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(masterActivity, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onComplete() {

                    }
                });

    }

    public void updateAllOrderUserIDs(){
        for(int i=0; i < masterActivity.currentSession.current_session_cart.size(); i++) {
            OrderItemTemplate curr_order_item = masterActivity.currentSession.current_session_cart.get(i);
            curr_order_item.user_id = masterActivity.currentSession.currentUser.id;
            masterActivity.currentSession.current_session_cart.set(i,curr_order_item);
        }
    }

    // Clear cart
    private void clearCart(){
        // init time
        masterActivity.currentSession.user_has_selected_time = false;
        masterActivity.currentSession.user_has_selected_date = false;
        masterActivity.currentSession.measure_time_interval = -1;

        masterActivity.currentOrderItem = null;
        masterActivity.createNewOrderItem();

        // clear cart items
        if (masterActivity.currentSession != null)
            masterActivity.currentSession.current_session_cart.clear();
    }

    // hide progress dialog
    private void hideProgressDialog(){

    }

    // show the alert dialog
    protected void showAlertDialog(String message) {
        new AlertDialog.Builder(getActivity())
                .setMessage(message)
                .setPositiveButton(R.string.ok, null)
                .setCancelable(false)
                .show();
    }

    // Create order in server after payment succeeded
    public void updateAllOrderPaymentRefsSuccess(int payType, String tap_transcation_ref){
        for(int i=0; i < masterActivity.currentSession.current_session_cart.size(); i++) {
            OrderItemTemplate curr_order_item = masterActivity.currentSession.current_session_cart.get(i);
            curr_order_item.order_payment_type = payType;

//            if (payType == AllHelpers.PAY_TYPE_TAP) {
//                curr_order_item.order_payment_status = AllHelpers.PAY_STATUS_PASSED;
//            } else if (payType == AllHelpers.PAY_TYPE_COD) {
//                curr_order_item.order_payment_status = AllHelpers.PAY_STATUS_COD_PEND;
////                curr_order_item.item_total_price = (int)(finalCost + 15f);
//            } else {
//                curr_order_item.order_payment_status = AllHelpers.PAY_STATUS_UNKNOWN;
//            }

            curr_order_item.tap_transaction_reference = tap_transcation_ref;
            masterActivity.currentSession.current_session_cart.set(i,curr_order_item);
        }

        createOrderOnServer(payType);
    }

    /**
     * HyperPay Settings
     */
    // Get Checkout ID for HyperPay
    private void requestCheckoutId(String paymentBrand){
        final_price = total_cart_price - discount_price;

        HashMap<String, Object> params = new HashMap<>();
        params.put("amount", final_price);
        params.put("paymentType", paymentBrand.equals(PAY_BRAND_MADA) ? "mada" : "visa");

        progressBar.setVisibility(View.VISIBLE);
        masterActivity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);

        KesaaApplication.getKesaaAPI().getCheckoutID(params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<JsonObject>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(JsonObject jsonObject) {
                        progressBar.setVisibility(View.GONE);
                        masterActivity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);

                        if (jsonObject.get("code").getAsInt() == 200){
                            if (jsonObject.get("data") != null){
                                JsonObject dataJson = jsonObject.get("data").getAsJsonObject();

                                // get checkout id
                                checkoutID = dataJson.get("id").getAsString();
                                paymentReference = dataJson.get("uuid").getAsString();

                                // open HyperPay Checkout page
                                openCheckoutUI(checkoutID, paymentBrand);
                            }
                        }
                        else{
                            // Show error message
                            if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                                Toast.makeText(masterActivity, jsonObject.get("message").getAsString(), Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(masterActivity, jsonObject.get("arabicMessage").getAsString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        progressBar.setVisibility(View.GONE);
                        masterActivity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);

                        Toast.makeText(masterActivity, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onComplete() {
                    }
                });
    }

    // Show the Checkout page
    private void openCheckoutUI(String checkoutId, String brand) {
        selectedBrand = brand.equals(PAY_BRAND_MADA) ? "mada" : "visa";

        Set<String> paymentBrands = new LinkedHashSet<String>();

        paymentBrands.add(PAY_BRAND_VISA);
        paymentBrands.add(PAY_BRAND_MASTER);
        paymentBrands.add(PAY_BRAND_MADA);

        CheckoutSettings checkoutSettings = new CheckoutSettings(checkoutId, paymentBrands, Connect.ProviderMode.LIVE);

        // Set shopper result URL
        checkoutSettings.setShopperResultUrl( "kesaa://result");

        // Present the Checkout Page
        Intent intent = checkoutSettings.createCheckoutActivityIntent(masterActivity);
        startActivityForResult(intent, CheckoutActivity.REQUEST_CODE_CHECKOUT);
    }

    // Check payment status
    private void checkPaymentStatus(){
        HashMap<String, Object> params = new HashMap<>();
        params.put("id", checkoutID);
        params.put("paymentType", selectedBrand);

        progressBar.setVisibility(View.VISIBLE);

        KesaaApplication.getKesaaAPI().getPaymentStatus(params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<JsonObject>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(JsonObject jsonObject) {
                        progressBar.setVisibility(View.GONE);
                        if (jsonObject.get("code").getAsInt() == 200){
                            if (jsonObject.get("data") != null){
                                JsonObject dataJson = jsonObject.get("data").getAsJsonObject();

                                JsonObject resultJson = dataJson.get("result").getAsJsonObject();
                                String resultCode = resultJson.get("code").getAsString();
                                String resultMessage = resultJson.get("description").getAsString();
                                if (isSucceededTransaction(resultCode)){
                                    Log.d(TAG, "Transaction is processed");

                                    // create order
                                    updateAllOrderPaymentRefsSuccess(AllHelpers.PAY_TYPE_HYPERPAY, "");
                                }
                                else{
                                    Log.d(TAG, "Transaction is still in pending");

                                    // show the error message
                                    Toast.makeText(masterActivity, resultMessage, Toast.LENGTH_SHORT).show();
                                }
                            }
                        }
                        else{
                            // Show error message
                            if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                                Toast.makeText(masterActivity, jsonObject.get("message").getAsString(), Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(masterActivity, jsonObject.get("arabicMessage").getAsString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(masterActivity, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onComplete() {
                    }
                });
    }

    // Check transaction status using regex
    public boolean isSucceededTransaction(String code) {
        try {
            Pattern pattern1 = Pattern.compile("^(000\\.000\\.|000\\.100\\.1|000\\.[36])");
            Pattern pattern2 = Pattern.compile("^(000\\.400\\.0[^3]|000\\.400\\.100)");
            return (pattern1.matcher(code).find() || pattern2.matcher(code).find());
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * OnActivityResult
     */
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        /* Override onActivityResult to get notified when the checkout process is done. */
        if (requestCode == CheckoutActivity.REQUEST_CODE_CHECKOUT) {
            switch (resultCode) {
                case CheckoutActivity.RESULT_OK:
                    /* Transaction completed. */
                    Transaction transaction = data.getParcelableExtra(CheckoutActivity.CHECKOUT_RESULT_TRANSACTION);

                    /* Check the transaction type. */
                    if (transaction.getTransactionType() == TransactionType.SYNC) {
                        /* Check the status of synchronous transaction. */
                        checkPaymentStatus();
                    }
                    else {
                        /* Asynchronous transaction is processed in the onNewIntent(). */
                        hideProgressDialog();
                    }

                    break;
                case CheckoutActivity.RESULT_CANCELED:
                    hideProgressDialog();

                    break;
                case CheckoutActivity.RESULT_ERROR:
                    hideProgressDialog();

                    PaymentError error = data.getParcelableExtra(
                            CheckoutActivity.CHECKOUT_RESULT_ERROR);

                    showAlertDialog(getActivity().getString(R.string.error_message));
            }
        }
    }

    @Override
    public void onDestroy() {
        // Unregister EventBus
        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }

        super.onDestroy();
    }
}
