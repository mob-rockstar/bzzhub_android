package com.tailor.kesaa.fragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.tailor.kesaa.KesaaApplication;
import com.tailor.kesaa.adapter.NotificationListAdapter;
import com.tailor.kesaa.MainActivity;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;
import com.tailor.kesaa.model.NotificationDetails;
import com.tailor.kesaa.R;
import com.tailor.kesaa.adapter.NotificationDataAdapter;
import com.tailor.kesaa.model.notification.NotificationDetail;
import com.tailor.kesaa.model.notification.NotificationListReponse;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import butterknife.ButterKnife;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import okhttp3.RequestBody;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link NotificationFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link NotificationFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class NotificationFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    public String TAG = "NOTIFRAG";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public View mainView;
    public ProgressBar progressBar;
    public TextView notifHeader;
    ArrayList<NotificationDetails> notificationDetailsArray;
    private static NotificationDataAdapter adapter;
    public ListView notificationListView;

    public boolean firstPass;

    public MainActivity masterActivity;
    private OnFragmentInteractionListener mListener;

    // Notification List Adapter
    NotificationListAdapter listAdapter;

    // Notification list
    List<NotificationDetail> notifications = new ArrayList<>();

    private int offset = 0;

    public NotificationFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment NotificationFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static NotificationFragment newInstance(String param1, String param2) {
        NotificationFragment fragment = new NotificationFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mainView = inflater.inflate(R.layout.fragment_notification, container, false);
        ButterKnife.bind(this, mainView);

        progressBar = mainView.findViewById(R.id.notif_spinner);
        notificationListView = mainView.findViewById(R.id.notification_list);

        masterActivity = (MainActivity) getActivity();

        if (mListener != null) {
            masterActivity.showActionBar();
            mListener.setFragTitle(getString(R.string.notifications));
        }

        if (masterActivity != null) {
            // Initialize the notification list
            listAdapter = new NotificationListAdapter(masterActivity, notifications);
            notificationListView.setAdapter(listAdapter);
        }

        loadNotifications();

        return mainView;
    }

    private void loadNotifications(){
        progressBar.setVisibility(View.VISIBLE);

        JSONObject requestParam = new JSONObject();
        try {
            requestParam.put("userId", masterActivity.currentSession.currentUser.id);
            requestParam.put("pageNumber", offset);
            requestParam.put("pageSize", 20);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // Create the request body
        RequestBody body = RequestBody.create(okhttp3.MediaType.parse("application/json; charset=utf-8"),
                requestParam.toString());

        KesaaApplication.getKesaaAPI().getNotifications(body)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<NotificationListReponse>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(NotificationListReponse notificationListReponse) {
                        progressBar.setVisibility(View.GONE);
                        if (notificationListReponse.getCode() == 200){
                            notifications = notificationListReponse.getNotifications();

                            listAdapter = new NotificationListAdapter(masterActivity, notifications);
                            notificationListView.setAdapter(listAdapter);
                        }
                        else{
                            // Show error message
                            if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                                Toast.makeText(masterActivity, notificationListReponse.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(masterActivity, notificationListReponse.getArabicMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }

                    }

                    @Override
                    public void onError(Throwable e) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(masterActivity, e.getLocalizedMessage(), Toast.LENGTH_SHORT);
                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }


    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onNotificationFragmentInteraction("",0);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        void setFragTitle(String newTitle);
        void onNotificationFragmentInteraction(String mode, int order_id);
    }
}
