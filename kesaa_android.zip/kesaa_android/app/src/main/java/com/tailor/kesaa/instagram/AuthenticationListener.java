package com.tailor.kesaa.instagram;

public interface AuthenticationListener {
    void onTokenReceived(String auth_token);
}
