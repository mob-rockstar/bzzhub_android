package com.tailor.kesaa.model.order;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class OrderHistoryDetails {
    /*
            {
                "id": 1,
                "tailorId": 1,
                "userId": 1,
                "styleId": 1,
                "addressId": 1,
                "timeslotId": 1,
                "requestDate": "2019-09-03T00:00:00.000Z",
                "hour": 8,
                "shippingType": 1,
                "cost": 200,
                "size": "small",
                "cuff": "simple_cuff",
                "collar": "band_collar",
                "fabric": "show_white_fabric",
                "placket": "simple_classic_placket",
                "pocket": "inclined_pocket",
                "spocket": "simple_zipper_spocket",
                "orderQuantity": 2,
                "orderDeliveryInstructions": "i need your help",
                "cashOnMeasurement": 0,
                "createdDate": "2019-08-05T00:00:00.000Z",
                "status": 1,
                "updatedDate": null,
                "arabicName": "سعودي",
                "englishName": "Saudi Style",
                "image": "http://165.22.254.242/kessa/ic_saudi_style.png",
                "arabicDescription": "لبَّا قلبك، خلِّك رزَّه بالثوب السعودي الكشخة، واختار المواصفات على كيف كيفك",
                "englishDescription": "You can never go wrong with the Saudi Thobe"
            }
     */
    public int order_cancel_status;

    // Thobe style id
    @SerializedName("styleId")
    @Expose
    public int order_thobe_style;

    // Transaction id
    public int transaction_id;

    // Order id
    @SerializedName("id")
    @Expose
    public int order_id;

    // Order total cost
    @SerializedName("cost")
    @Expose
    public float order_total_price;

    // Order status
    @SerializedName("status")
    @Expose
    public int order_status;

    // Thobe size
    @SerializedName("size")
    @Expose
    public String order_size;

    // User id
    @SerializedName("userId")
    @Expose
    public int user_id;

    // Tailor name
    public String order_tailor_name;

    // Tailor id
    @SerializedName("tailorId")
    @Expose
    public int order_tailor_id;

    // Order quantity
    @SerializedName("orderQuantity")
    @Expose
    public int order_qty;


    public int order_fabric_type;
    public int order_collar_type;
    public int order_cuffs_type;
    public int order_placket_type;
    public int order_pocket_type;
    public int order_sidepocket_type;

    @SerializedName("createdDate")
    @Expose
    public String order_placement_date;

    // Style name in Arabic
    @SerializedName("arabicName")
    @Expose
    public String styleArabicName;

    // Style name in English
    @SerializedName("englishName")
    @Expose
    public String styleEnglishName;

    // Style image path
    @SerializedName("image")
    @Expose
    public String styleImagePath;

    // Cuff
    @SerializedName("cuff")
    @Expose
    public String cuff;

    // Collar
    @SerializedName("collar")
    @Expose
    public String collar;

    // Fabric
    @SerializedName("fabric")
    @Expose
    public String fabric;

    // Placket
    @SerializedName("placket")
    @Expose
    public String placket;

    // Pocket
    @SerializedName("pocket")
    @Expose
    public String pocket;

    // Side Pocket
    @SerializedName("spocket")
    @Expose
    public String spocket;

}
