package com.tailor.kesaa.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.tailor.kesaa.R;
import com.tailor.kesaa.customs.CustomFontTextView;
import com.tailor.kesaa.fragment.CustomizeStyleFragment;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;
import com.tailor.kesaa.model.CustomizeOptionElement;

import net.cachapa.expandablelayout.ExpandableLayout;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;

public class CustomOptionListAdapter extends BaseAdapter {

    private CustomizeStyleFragment customizeParentFrag;
    Context mContext;
    private LayoutInflater inflater;

    // Options
    private Map<Integer, List<CustomizeOptionElement>> optionsMap;

    public CustomOptionListAdapter(Context context, Map<Integer, List<CustomizeOptionElement>> optionsDictionary, CustomizeStyleFragment parent){
        this.mContext               = context;
        this.customizeParentFrag    = parent;
        this.inflater               = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.optionsMap             = optionsDictionary;
    }

    @Override
    public int getCount() {
        return optionsMap.size();
    }

    @Override
    public List<CustomizeOptionElement> getItem(int position) {
        if (this.optionsMap.keySet().toArray() != null){
            Object keyValue = this.optionsMap.keySet().toArray()[position];
            return (List<CustomizeOptionElement>)this.optionsMap.get(keyValue);
        }
        else{
            List<CustomizeOptionElement> emptyOptions = new ArrayList<>();
            return emptyOptions ;
        }

    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        OptionViewHolder holder;

        if (convertView == null){
            convertView = inflater.inflate(R.layout.item_option_list, parent, false);
            holder = new OptionViewHolder(convertView);
            convertView.setTag(holder);
        }
        else{
            holder = (OptionViewHolder) convertView.getTag();
        }

        // Get options
        List<CustomizeOptionElement> options = getItem(position);
        if (options.size() > 0){
            // get category id
            Integer categoryId = options.get(0).categoryId;

            if (MyPreferenceManager.getInstance(mContext).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH) {
                // category title
                holder.categoryTitleTextView.setText(options.get(0).categoryNameEn);
                holder.optionScroller.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            }
            else{
                // category title
                holder.categoryTitleTextView.setText(options.get(0).categoryNameAr);
                holder.optionScroller.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            }

            // Marker
            if (customizeParentFrag.masterActivity.currentOrderItem.optSelectedMap != null){
                if (customizeParentFrag.masterActivity.currentOrderItem.optSelectedMap.get(categoryId) != null){
                    holder.markerView.setVisibility(View.VISIBLE);
                }
                else{
                    holder.markerView.setVisibility(View.GONE);
                }
            }
            else{
                holder.markerView.setVisibility(View.GONE);
            }

            // Check if current section is selected or not
            if (customizeParentFrag.selectedHeader == position) {
                holder.collapsArrowImageView.setImageResource(R.drawable.ic_keyboard_arrow_down_black_24dp);
                holder.expandableLayout.expand();
            }
            else{
                holder.collapsArrowImageView.setImageResource(R.drawable.ic_keyboard_arrow_right_black_24dp);
                holder.expandableLayout.collapse();
            }

            // Display Options
            CustomizerDataAdapter optionAdapter = new CustomizerDataAdapter(mContext, new ArrayList<CustomizeOptionElement>(options), customizeParentFrag);
            optionAdapter.notifyDataSetChanged();
            if (holder.horizontalOptionsContainer.getChildCount() > 0){
                holder.horizontalOptionsContainer.removeAllViews();
            }

            for (int i = 0; i < options.size(); i++) {
                View currOption = optionAdapter.getView(i, customizeParentFrag.masterServiceView, customizeParentFrag.masterServiceContainer);
                currOption.setTag(i);
                holder.horizontalOptionsContainer.addView(currOption);
            }

            // Click header listener
            holder.headerLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    customizeParentFrag.selectedHeader = position;
//                    customizeParentFrag.updateExpandableStatus();
                    if (position == customizeParentFrag.selectedHeader) {
//                        holder.expandableLayout.toggle();
                    }
                    else{
                        customizeParentFrag.selectedHeader = position;
                        customizeParentFrag.updateExpandableStatus();
                    }
                }
            });

        }

        return convertView;
    }

    // View Holder
    static class OptionViewHolder {

        // Header layout
        @BindView(R.id.option_header_layout)
        RelativeLayout headerLayout;

        // Category title
        @BindView(R.id.category_title_text)
        CustomFontTextView categoryTitleTextView;

        // Marker
        @BindView(R.id.mark_view)
        View markerView;

        // Collaps Arrow
        @BindView(R.id.collapse_arrow_image)
        ImageView collapsArrowImageView;

        // Expandable layout
        @BindView(R.id.expander)
        ExpandableLayout expandableLayout;

        // Horizontal ScrollView
        @BindView(R.id.option_scroller)
        HorizontalScrollView optionScroller;

        // Container
        @BindView(R.id.horizontal_options_layout)
        LinearLayout horizontalOptionsContainer;


        public OptionViewHolder(View view){
            ButterKnife.bind(this, view);
        }
    }

}
