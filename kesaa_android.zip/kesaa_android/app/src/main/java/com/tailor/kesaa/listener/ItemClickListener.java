package com.tailor.kesaa.listener;

import com.tailor.kesaa.model.Item;
import com.tailor.kesaa.model.Section;

public interface ItemClickListener {
    void itemClicked(Item item);
    void itemClicked(Section section);
}
