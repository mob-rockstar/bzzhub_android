package com.tailor.kesaa.fcm;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.tailor.kesaa.R;
import com.tailor.kesaa.activity.SplashActivity;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;
import com.tailor.kesaa.global.Utils;

public class MyFirebaseMessagingService extends FirebaseMessagingService {
    private static final String TAG = "FCMService";

    private static final String CHANNEL_NAME = "Kesaa Notification Channel";
    private static final String CHANNEL_DESCRIPTION = "This is used for managing FCM";

    /**
     * Called if InstanceID token is updated. This may occur if the security of
     * the previous token had been compromised. Note that this is called when the InstanceID token
     * is initially generated so this is where you would retrieve the token.
     */
    @Override
    public void onNewToken(String token) {
        Log.d(TAG, "Refreshed token: " + token);

        // If you want to send messages to this application instance or
        // manage this apps subscriptions on the server side, send the
        // Instance ID token to your app server.
        sendRegistrationToServer(token);
    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        // TODO(developer): Handle FCM messages here.
        // Not getting messages here? See why this may be: https://goo.gl/39bRNJ
        Log.d(TAG, "From: " + remoteMessage.getFrom());

        String title = "Kesaa";
        String bodyMessage = "Welcome to Kesaa!";

        // Check if message contains a data payload.
        if (remoteMessage.getData().size() > 0) {
            Log.d(TAG, "Push Message data payload: " + remoteMessage.getData());

            if (/* Check if data needs to be processed by long running job */ true) {
                // For long-running tasks (10 seconds or more) use Firebase Job Dispatcher.
            }
            else {
                // Handle message within 10 seconds
            }

            if (MyPreferenceManager.getInstance(this).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                title = remoteMessage.getData().get("title");
                bodyMessage = remoteMessage.getData().get("body");
            }
            else{
                title = remoteMessage.getData().get("arabicTitle");
                bodyMessage = remoteMessage.getData().get("arabicBody");
            }

        }

        // Check if message contains a notification payload.
        if (remoteMessage.getNotification() != null) {
            Log.d(TAG, "Message Notification Title: " + remoteMessage.getNotification().getTitle());
            Log.d(TAG, "Message Notification Body: " + remoteMessage.getNotification().getBody());

            title = remoteMessage.getNotification().getTitle();
            bodyMessage = remoteMessage.getNotification().getBody();
        }

//            JSONObject notificationJson = null;
//            try {
//                notificationJson = new JSONObject(customNotiJson.getString("custom_notification"));
//                title = notificationJson.getString("title");
//                bodyMessage = notificationJson.getString("body");
//            } catch (JSONException e) {
//                e.printStackTrace();
//            }

        // Create an explicit intent for an Activity in your app
        Intent intent = new Intent(this, SplashActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);

        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = CHANNEL_NAME;
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(getString(R.string.default_notification_channel_id), name, importance);
            channel.setDescription(CHANNEL_DESCRIPTION);
            channel.setShowBadge(true);

            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }

        // Get the all badge count
        int badgeCount = MyPreferenceManager.getInstance(getApplicationContext()).getInt(SettingsKeys.KEY_BADGE_COUNT, 0);
        badgeCount ++;
        MyPreferenceManager.getInstance(getApplicationContext()).put(SettingsKeys.KEY_BADGE_COUNT, badgeCount);

        // show the notification
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this, getString(R.string.default_notification_channel_id))
                .setContentTitle(title)
                .setContentText(bodyMessage)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setNumber(1)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
//                mBuilder.setSmallIcon(R.mipmap.ic_notification);
            mBuilder.setSmallIcon(R.drawable.ic_navigation);
            mBuilder.setColor(Utils.getColor(this, R.color.colorPrimary));
        }
        else{
            mBuilder.setSmallIcon(R.mipmap.ic_launcher);
        }
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);

        // Get the notification id
        int notifyId = SettingsKeys.NOTIFICATION_ID;
//            try {
//                notifyId = Integer.parseInt(notificationJson.getString("id"));
//            } catch (JSONException e) {
//                e.printStackTrace();
//            } catch (NullPointerException e){
//                e.printStackTrace();
//            }

        // notificationId is a unique int for each notification that you must define
        notificationManager.notify(notifyId, mBuilder.build());

    }

    private void sendRegistrationToServer(String token) {
        // Save device token into local
        MyPreferenceManager.getInstance(getApplicationContext()).put(SettingsKeys.KEY_DEVICE_TOKEN, token);

    }
}
