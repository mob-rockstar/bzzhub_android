package com.tailor.kesaa.model.notification;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class NotificationListReponse {
    @SerializedName("code")
    @Expose
    private int code;

    @SerializedName("message")
    @Expose
    private String message;

    @SerializedName("arabicMessage")
    @Expose
    private String arabicMessage;

    @SerializedName("data")
    @Expose
    private List<NotificationDetail> notifications = new ArrayList<>();

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getArabicMessage() {
        return arabicMessage;
    }

    public void setArabicMessage(String arabicMessage) {
        this.arabicMessage = arabicMessage;
    }

    public List<NotificationDetail> getNotifications() {
        return notifications;
    }

    public void setNotifications(List<NotificationDetail> notifications) {
        this.notifications = notifications;
    }
}
