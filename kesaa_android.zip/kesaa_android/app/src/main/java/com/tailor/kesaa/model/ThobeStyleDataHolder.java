package com.tailor.kesaa.model;

public class ThobeStyleDataHolder {

    private int styleDescriptionStringID;
    private int styleImageID;

    public ThobeStyleDataHolder(int descrStrID, int sytleImgID) {
        styleDescriptionStringID= descrStrID;
        styleImageID = sytleImgID;
    }

    public int getDescrID() {
        return styleDescriptionStringID;
    }

    public int getImageID() {
        return styleImageID;
    }

}
