package com.tailor.kesaa.global;

import android.content.Context;
import android.text.style.ForegroundColorSpan;

import androidx.core.content.ContextCompat;

import com.tailor.kesaa.R;
import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.DayViewDecorator;
import com.prolificinteractive.materialcalendarview.DayViewFacade;

public class MyDayBgDecorator implements DayViewDecorator {

    private Context mContext;
    private CalendarDay selectedDay;
    private boolean shouldClear = false;

    public MyDayBgDecorator(Context context, CalendarDay currentDay, boolean shouldClear){
        mContext = context;
        this.selectedDay = currentDay;
        this.shouldClear = shouldClear;
    }

    @Override
    public boolean shouldDecorate(CalendarDay calendarDay) {
        return calendarDay.equals(selectedDay);
    }

    @Override
    public void decorate(DayViewFacade dayViewFacade) {

        // Set background of date
        try {
            if (shouldClear){
                dayViewFacade.setBackgroundDrawable(mContext.getDrawable(R.drawable.calendar_day_background));
            }
            else{
                dayViewFacade.setBackgroundDrawable(mContext.getDrawable(R.drawable.calendar_day_sel_background));
            }

            dayViewFacade.addSpan(new ForegroundColorSpan(ContextCompat.getColor(mContext, R.color.colorStyleTitle)));
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
}
