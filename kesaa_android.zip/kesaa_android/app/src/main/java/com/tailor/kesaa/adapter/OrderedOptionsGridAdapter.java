package com.tailor.kesaa.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.tailor.kesaa.R;
import com.tailor.kesaa.customs.CustomFontTextView;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;
import com.tailor.kesaa.model.CustomizeOptionElement;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class OrderedOptionsGridAdapter extends BaseAdapter {

    private LayoutInflater inflater = null;
    Context mContext;
    private List<CustomizeOptionElement> options;

    public OrderedOptionsGridAdapter(Context mContext, List<CustomizeOptionElement> optionArray) {
        this.mContext = mContext;
        this.inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.options = optionArray;
    }

    @Override
    public int getCount() {
        return options.size();
    }

    @Override
    public Object getItem(int position) {
        return options.get(position);
    }

    @Override
    public long getItemId(int position) {
        return options.get(position).id_num;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        OrderedOptionViewHolder holder;

        if (convertView == null){
            convertView = inflater.inflate(R.layout.item_ordered_options_list, parent, false);
            holder = new OrderedOptionViewHolder(convertView);
            convertView.setTag(holder);
        }
        else{
            holder = (OrderedOptionViewHolder) convertView.getTag();
        }

        CustomizeOptionElement optionElement = options.get(position);

        // Category title & option name
        if (MyPreferenceManager.getInstance(mContext).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
            holder.categoryTextView.setText(optionElement.categoryNameEn);
            holder.optionNameTextView.setText(optionElement.optionName);
        }
        else{
            holder.categoryTextView.setText(optionElement.categoryNameAr);
            holder.optionNameTextView.setText(optionElement.optionNameAr);
        }

        // Option Image
        Glide.with(mContext).load(optionElement.imagePath).into(holder.optionImageView);

        return convertView;
    }

    static class OrderedOptionViewHolder {

        // category title
        @BindView(R.id.category_title_text)
        CustomFontTextView categoryTextView;

        // option image
        @BindView(R.id.option_image)
        ImageView optionImageView;

        // option name
        @BindView(R.id.option_name_text)
        CustomFontTextView optionNameTextView;


        public OrderedOptionViewHolder(View view){
            ButterKnife.bind(this, view);
        }
    }
}
