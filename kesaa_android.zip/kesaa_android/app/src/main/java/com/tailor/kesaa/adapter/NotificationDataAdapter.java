package com.tailor.kesaa.adapter;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.tailor.kesaa.global.AllHelpers;
import com.tailor.kesaa.model.NotificationDetails;
import com.tailor.kesaa.fragment.NotificationFragment;
import com.tailor.kesaa.R;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class NotificationDataAdapter extends ArrayAdapter<NotificationDetails> implements View.OnClickListener, View.OnLongClickListener{

    private String thobeTypeList[] = {"Saudi" , "Emarati", "Bahraini", "Kuwaiti", "Omani", "Qatari"};
    public String[] timeIntervals  = {"06:00 AM - 08:00 AM","08:00 AM - 10:00 AM","10:00 AM - 12:00 PM","12:00 PM - 14:00 PM","14:00 PM - 16:00 PM","16:00 PM - 18:00 PM","18:00 PM - 20:00 PM","20:00 PM - 22:00 PM","22:00 PM - 00:00 AM"};
    public String[] status_string  = {"Awaiting Confirmation", "Measurement Visit Underway", "Awaiting Payment", "Tailor Preparation", "Tailoring Underway", "Tailoring Complete", "Delivery Initiated", "Delivery Underway", "Delivery Complete" };


    public String TAG = "NOTIFADAPT";
    private ArrayList<NotificationDetails> notificationDataSet;
    private NotificationFragment parentNotificationFrag;
    private Context parentContex;

    public NotificationDataAdapter(ArrayList<NotificationDetails> data, Context context, NotificationFragment nFrag) {
        super(context, R.layout.notification_card_element, data);
        this.notificationDataSet = data;
        this.parentContex=context;
        this.parentNotificationFrag = nFrag;
    }

    private static class NotificationDetailCardHolder {
        TextView orderDetails;
        TextView tailorName;
        TextView bookingDate;
        TextView bookingTime;
        TextView bookingStatus;
        LinearLayout edgeColourLayout;
        LinearLayout mainWrapper;
    }

    public String dateToStr(Date inpDate) {
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        return dateFormat.format(inpDate);
    }



    @Override
    public void onClick(View v) {

            Log.d(TAG, "Notification Adapter view " + v.getId());
//            parentNotificationFrag.notificationCardClicked((Integer)(v.getTag()));
        }

    @Override
    public boolean onLongClick(View v) {

        Log.d(TAG, "Long click on Notification card view " + v.getId());
        //parentNotificationFrag.notificationCardLongPress((Integer)(v.getTag()));
        //parentNotificationFrag.notificationCardClicked((Integer)(v.getTag()));
        return  true;
    }



    @Override
    public View getView(int position, View convertView, ViewGroup parent) {


        // Get the data item for this position
        NotificationDetails dataModel = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view
        NotificationDetailCardHolder viewHolder; // view lookup cache stored in tag

        final View result;

        if (convertView == null) {

            viewHolder = new NotificationDetailCardHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.notification_card_element, parent, false);
            viewHolder.orderDetails = (TextView) convertView.findViewById(R.id.notification_order_details);
            viewHolder.tailorName = (TextView) convertView.findViewById(R.id.notification_tailor_name);
            viewHolder.bookingDate = (TextView) convertView.findViewById(R.id.notification_date);
            viewHolder.bookingTime = (TextView) convertView.findViewById(R.id.notification_time);
            viewHolder.bookingStatus = (TextView) convertView.findViewById(R.id.notification_status);
            viewHolder.edgeColourLayout = convertView.findViewById(R.id.status_indicator_layout);
            viewHolder.mainWrapper = convertView.findViewById(R.id.data_holder);

            result=convertView;
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (NotificationDetailCardHolder) convertView.getTag();
            result=convertView;
        }

        viewHolder.orderDetails.setText("Order: #"+ Integer.toString(dataModel.order_id  )  + " (" +thobeTypeList[dataModel.orderThobeType] +  " Style)");
        viewHolder.tailorName.setText(dataModel.tailorName );
        viewHolder.mainWrapper.setOnClickListener(this);
        viewHolder.mainWrapper.setLongClickable(true);
        viewHolder.mainWrapper.setOnLongClickListener(this);
        viewHolder.mainWrapper.setTag(position);

//     public static String[] master_db_status_readable = {"New Order","Measurement in Process","Awaiting Payment","Payment Done","Tailoring Underway","Tailoring Complete","Tailoring on Hold","Pickup in Progress","Delivery in Progress","Delivery Complete"};
////                                                           0                1                       2                3               4                   5                          6                7                     8                  9

        switch (dataModel.orderBookingStatus) {

            case 0:
                viewHolder.edgeColourLayout.setBackgroundColor(Color.parseColor("#f0b400"));
                viewHolder.bookingStatus.setTextColor(Color.parseColor("#f0b400"));
                viewHolder.bookingStatus.setText("Status : " + AllHelpers.master_db_status_readable[dataModel.orderBookingStatus] );
                viewHolder.bookingDate.setText("Booking Date : " + dateToStr(dataModel.orderBookingDate));
                viewHolder.bookingTime.setText("Booking Time : " + timeIntervals[dataModel.orderBookingTimeInterval] );

                break;
            case 1:
                viewHolder.edgeColourLayout.setBackgroundColor(Color.parseColor("#00ff00"));
                viewHolder.bookingStatus.setTextColor(Color.parseColor("#00ff00"));
                viewHolder.bookingStatus.setText("Status : " + AllHelpers.master_db_status_readable[dataModel.orderBookingStatus] );
                viewHolder.bookingDate.setText("Booking Date : " + dateToStr(dataModel.orderBookingDate));
                viewHolder.bookingTime.setText("Booking Time : " + timeIntervals[dataModel.orderBookingTimeInterval] );

                break;
            case 2:
                viewHolder.edgeColourLayout.setBackgroundColor(Color.parseColor("#f0b400"));
                viewHolder.bookingStatus.setTextColor(Color.parseColor("#f0b400"));
                viewHolder.bookingStatus.setText("Status : " + AllHelpers.master_db_status_readable[dataModel.orderBookingStatus] );
                viewHolder.bookingDate.setText("Measurement Done");
                viewHolder.bookingTime.setText("" );

                break;

            case 3:
                viewHolder.edgeColourLayout.setBackgroundColor(Color.parseColor("#00ff00"));
                viewHolder.bookingStatus.setTextColor(Color.parseColor("#00ff00"));
                viewHolder.bookingStatus.setText("Status : " + AllHelpers.master_db_status_readable[dataModel.orderBookingStatus] );
                viewHolder.bookingDate.setText("Awaiting Tailor Confirmation");
                viewHolder.bookingTime.setText("" );

                break;

            case 4:
                viewHolder.edgeColourLayout.setBackgroundColor(Color.parseColor("#00ff0000"));
                viewHolder.bookingStatus.setTextColor(Color.parseColor("#ff0000"));
                viewHolder.bookingStatus.setText("Status : " + AllHelpers.master_db_status_readable[dataModel.orderBookingStatus] );
                viewHolder.bookingDate.setText("Tailoring to Complete by : " + AllHelpers.dateToStr(dataModel.orderCompletionDate ));
                viewHolder.bookingTime.setText("" );

                break;

            case 5:
                viewHolder.edgeColourLayout.setBackgroundColor(Color.parseColor("#00ff0000"));
                viewHolder.bookingStatus.setTextColor(Color.parseColor("#00ff00"));
                viewHolder.bookingStatus.setText("Status : " + AllHelpers.master_db_status_readable[dataModel.orderBookingStatus] );
                viewHolder.bookingDate.setText("Tailoring Complete");
                viewHolder.bookingTime.setText("" );

                break;
            case 6:
                viewHolder.edgeColourLayout.setBackgroundColor(Color.parseColor("#00ff0000"));
                viewHolder.bookingStatus.setTextColor(Color.parseColor("#00ff00"));
                viewHolder.bookingStatus.setText("Status : " + AllHelpers.master_db_status_readable[dataModel.orderBookingStatus] );
                viewHolder.bookingDate.setText("");
                viewHolder.bookingTime.setText("" );
                break;
            case 7:
                viewHolder.edgeColourLayout.setBackgroundColor(Color.parseColor("#00ff0000"));
                viewHolder.bookingStatus.setTextColor(Color.parseColor("#00ff00"));
                viewHolder.bookingStatus.setText("Status : " + AllHelpers.master_db_status_readable[dataModel.orderBookingStatus] );
                viewHolder.bookingDate.setText("");
                viewHolder.bookingTime.setText("" );
                break;
            case 8:
                viewHolder.edgeColourLayout.setBackgroundColor(Color.parseColor("#00ff0000"));
                viewHolder.bookingStatus.setTextColor(Color.parseColor("#00ff00"));
                viewHolder.bookingStatus.setText("Status : " + AllHelpers.master_db_status_readable[dataModel.orderBookingStatus] );
                viewHolder.bookingDate.setText("");
                viewHolder.bookingTime.setText("" );
                break;
            case 9:
                viewHolder.edgeColourLayout.setBackgroundColor(Color.parseColor("#0000ff00"));
                viewHolder.bookingStatus.setTextColor(Color.parseColor("#00ff00"));
                viewHolder.bookingStatus.setText("Status : " + AllHelpers.master_db_status_readable[dataModel.orderBookingStatus] );
                viewHolder.bookingDate.setText("");
                viewHolder.bookingTime.setText("" );
                break;


            default:
                viewHolder.edgeColourLayout.setBackgroundColor(Color.parseColor("#0000ff"));
                viewHolder.bookingStatus.setTextColor(Color.parseColor("#0000ff"));
                viewHolder.bookingStatus.setText("Status : Undefined" );
                viewHolder.bookingDate.setText("");
                viewHolder.bookingTime.setText("" );
                break;

        }



        return convertView;


    }


}
