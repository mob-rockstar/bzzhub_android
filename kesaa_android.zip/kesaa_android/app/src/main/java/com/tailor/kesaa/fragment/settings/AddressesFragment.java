package com.tailor.kesaa.fragment.settings;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.google.gson.JsonObject;
import com.tailor.kesaa.KesaaApplication;
import com.tailor.kesaa.MainActivity;
import com.tailor.kesaa.R;
import com.tailor.kesaa.adapter.AddressListAdapter;
import com.tailor.kesaa.global.EventBusMessage;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;
import com.tailor.kesaa.global.Utils;
import com.tailor.kesaa.model.ActiveSession;
import com.tailor.kesaa.model.AddressData;
import com.tailor.kesaa.model.AddressListData;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class AddressesFragment extends Fragment {
    private static final String TAG = "AddressesFragment";

    @BindView(R.id.address_list)
    ListView addressListView;

    @BindView(R.id.progressBar)
    ProgressBar progressBar;

    public MainActivity masterActivity;

    List<AddressData> addressList = new ArrayList<>();
    AddressListAdapter addressListAdapter;

    boolean isLoadingAddress = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_addresses, container, false);
        ButterKnife.bind(this, view);

        // Register EventBus
        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this);

        masterActivity = (MainActivity) getActivity();
        if (masterActivity != null){
            masterActivity.setFragTitle(getString(R.string.your_addr_title));
            masterActivity.showActionBar();
        }

        loadAddressList();

        return view;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        // TODO Add your menu entries here
        inflater.inflate(R.menu.address_add_menu,menu);
//        super.onCreateOptionsMenu(menu, inflater);
    }


    // handle button activities
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.add_address_btn) {
            if (masterActivity != null) {
                Bundle bundle = new Bundle();
                bundle.putBoolean("isFromAddressList", true);

                Navigation.findNavController(addressListView).navigate(R.id.action_addressListFragment_to_locationMapperFragment, bundle);
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        //MenuItem item = menu.findItem(R.id.action_settings);
        //item.setVisible(true);
        super.onPrepareOptionsMenu(menu);
    }

    @Override
    public void onDestroy() {
        // Unregister EventBus
        if (EventBus.getDefault().isRegistered(this)){
            EventBus.getDefault().unregister(this);
        }

        super.onDestroy();
    }

    @Override
    public void onResume() {
        super.onResume();

        if (masterActivity != null){
            masterActivity.setFragTitle(getString(R.string.your_addr_title));
            masterActivity.showActionBar();
        }
    }



    @Subscribe(threadMode = ThreadMode.MAIN)
    public void OnEventMessage(EventBusMessage messageEvent){
        if (messageEvent != null){
            int messageType = messageEvent.getMessageType();
            if (messageType == EventBusMessage.MessageType.NEW_ADDRESS_CREATED){ // Added new address
                loadAddressList();
            }
        }
    }

    private void initAddressList(){
        addressListAdapter = new AddressListAdapter(addressList, masterActivity, this);
        addressListView.setAdapter(addressListAdapter);

        addressListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                AddressData selectedAddress = addressList.get(position);
                updateAddress(selectedAddress);
            }
        });

        checkDefaultAddress();
    }

    // Go to Address update
    private void updateAddress(AddressData addressData){
        if (masterActivity != null) {
            Bundle bundle = new Bundle();
            bundle.putBoolean("isFromAddressList", true);
            bundle.putSerializable("selected_address", addressData);

            Navigation.findNavController(addressListView).navigate(R.id.action_addressListFragment_to_locationMapperFragment, bundle);
        }
    }

    private void checkDefaultAddress(){
        int addressCount = addressList.size();
        for (int i = 0; i < addressCount; i++){
            AddressData addressData = addressList.get(i);
            if (addressData.getIsDefault() == 1){
                ActiveSession.getInstance().currentUser.defaultUserAddressIndex = i;
                break;
            }
        }
    }

    // Delete address
    public void deleteAddress(int position){
        AddressData selectedAddress = addressList.get(position);

        if (masterActivity != null && !Utils.isNetworkConnected(masterActivity)){
            Toast.makeText(masterActivity, getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);

        KesaaApplication.getKesaaAPI().deleteAddress(selectedAddress.getId())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<JsonObject>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(JsonObject jsonObject) {
                        progressBar.setVisibility(View.GONE);
                        if (jsonObject.get("code") != null && jsonObject.get("code").getAsInt() == 200){
                            updateAddressList(selectedAddress);
                        }
                        else{
                            // Show error message
                            if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                                Toast.makeText(getActivity(), jsonObject.get("message").getAsString(), Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(getActivity(), jsonObject.get("arabicMessage").getAsString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(masterActivity, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }

    // Update address list
    private void updateAddressList(AddressData address){
        // remove this address in list
        int idx = addressList.indexOf(address);
        if (idx >= 0){
            addressList.remove(idx);
        }

        masterActivity.currentSession.currentUser.addressList = addressList;

        // refresh listview
        addressListAdapter.notifyDataSetChanged();
    }


    // Load address list by using user id
    private void loadAddressList(){

        // Check if network is connected
        if (masterActivity != null && !Utils.isNetworkConnected(masterActivity)){
            Toast.makeText(masterActivity, getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
            return;
        }

        if (isLoadingAddress){
            return;
        }

        progressBar.setVisibility(View.VISIBLE);
        isLoadingAddress = true;

        // Call apis
        KesaaApplication.getKesaaAPI().getAddressList(String.valueOf(ActiveSession.getInstance().currentUser.id))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<AddressListData>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(AddressListData response) {
                        progressBar.setVisibility(View.GONE);
                        isLoadingAddress = false;
                        Log.d(TAG, "Address List Response: " + response.toString());

                        if (response.getCode() == 200){
                            List<AddressData> addressArray = response.getData().getAddresses();
                            if (addressArray != null){
                                addressList.clear();
                                addressList.addAll(addressArray);
                                ActiveSession.getInstance().currentUser.addressList = addressList;

                                initAddressList();
                            }
                        }
                        else{
                            // Show error message
                            if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                                Toast.makeText(getActivity(), response.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(getActivity(), response.getArabicMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        progressBar.setVisibility(View.GONE);
                        isLoadingAddress = false;

                        Toast.makeText(getContext(), e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                        Log.d(TAG, "Address List Error: " + e.getLocalizedMessage());
                    }

                    @Override
                    public void onComplete() {

                    }
                });

    }
}
