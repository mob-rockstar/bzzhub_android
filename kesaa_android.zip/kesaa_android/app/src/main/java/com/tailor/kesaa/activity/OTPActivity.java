package com.tailor.kesaa.activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.tailor.kesaa.KesaaApplication;
import com.tailor.kesaa.MainActivity;
import com.tailor.kesaa.R;
import com.tailor.kesaa.customs.CustomFontEditText;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;
import com.tailor.kesaa.global.Utils;
import com.tailor.kesaa.model.ActiveSession;
import com.tailor.kesaa.model.UserTemplate;
import com.tailor.kesaa.model.user.UserData;
import com.tailor.kesaa.model.user.UserResponseData;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import okhttp3.RequestBody;

public class OTPActivity extends AppCompatActivity {
    private static final String TAG = "OTP";

    String verificationId = null;
    String firstName = "";
    String lastName = "";
    String phoneNumber = "";

    PhoneAuthProvider.ForceResendingToken forceResendingToken;

    @BindView(R.id.phone_verify_sms_code_edit_text)
    CustomFontEditText otpCodeText;

    @BindView(R.id.progressBar)
    ProgressBar progressBar;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.fragment_phone_verify);

        ButterKnife.bind(this);

        // Get verification Id
        verificationId = getIntent().getStringExtra("otp_id");

        if (getIntent().getStringExtra(SettingsKeys.KEY_FIRST_NAME) != null){
            firstName = getIntent().getStringExtra(SettingsKeys.KEY_FIRST_NAME);
        }

        if (getIntent().getStringExtra(SettingsKeys.KEY_LAST_NAME) != null){
            lastName = getIntent().getStringExtra(SettingsKeys.KEY_LAST_NAME);
        }

        if (getIntent().getStringExtra(SettingsKeys.KEY_PHONE) != null){
            phoneNumber = getIntent().getStringExtra(SettingsKeys.KEY_PHONE);
        }
    }

    // Verify phone number
    @OnClick(R.id.btn_otp_verify) void verifyPhoneNumber(){
        String enteredCode = otpCodeText.getText().toString();
        if (enteredCode.equals("")){
            Toast.makeText(OTPActivity.this, getString(R.string.enter_verification_code), Toast.LENGTH_SHORT).show();
            return;
        }

        // [START verify_with_code]
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationId, enteredCode);
        // [END verify_with_code]
        signInWithPhoneAuthCredential(credential);
    }

    // Resend Otp code
    @OnClick(R.id.resend_code_text) void resend(){
        // Check if network is connected
        if (!Utils.isNetworkConnected(this)){
            Toast.makeText(this, getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);

        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phoneNumber, 60 /*timeout*/, TimeUnit.SECONDS,
                this,
                new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

                    @Override
                    public void onCodeSent(String verificationId,
                                           PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                        Log.d(TAG,"Code sent");
                        progressBar.setVisibility(View.GONE);

                        otpCodeText.setText("");
                    }

                    @Override
                    public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {
                        // Sign in with the credential
                        Log.d(TAG,"Phone Verification Succeeded");
                        progressBar.setVisibility(View.GONE);

//                        signInWithPhoneAuthCredential(phoneAuthCredential);
                    }

                    @Override
                    public void onVerificationFailed(FirebaseException e) {
                        Log.d(TAG,R.string.ph_verify_failed_text + e.toString());
                        progressBar.setVisibility(View.GONE);
                    }

                }, SettingsKeys.resendingToken);
    }

    // [START sign_in_with_phone]
    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        // Check if network is connected
        if (!Utils.isNetworkConnected(this)){
            Toast.makeText(this, getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);
        ActiveSession.getInstance().firebaseAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        progressBar.setVisibility(View.GONE);

                        if (task.isSuccessful()) {
                            // Sign in success, update session  with the signed-in user's information
                            Log.d(TAG, "signInWithPhoneCredential:success");
                            FirebaseUser user = task.getResult().getUser();

                            getMySQLUserDetailsFromUid(user, user.getUid(),false);
                        } else {
                            // Sign in failed, display a message and update the UI
                            Log.d(TAG, "signInWithCredential:failure", task.getException());
                            if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                                // The verification code entered was invalid
                                Toast.makeText(OTPActivity.this, getString(R.string.entered_invalid_code), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                });
    }

    // Get User ID from server
    public void getMySQLUserDetailsFromUid(FirebaseUser fUser, final String uid, final boolean cameFromNotification) {

        // Check if network is connected
        if (!Utils.isNetworkConnected(this)){
            Toast.makeText(this, getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
            return;
        }

        if (uid == null)
            return;

        progressBar.setVisibility(View.VISIBLE);

        // Firebase User details
        String name = fUser.getDisplayName();
        if (name == null || name.equals(""))
            name = firstName + " " + lastName;

//        try {
//            name = URLEncoder.encode(name, "utf-8");
//            name = name.replace(" ", "%20");
//        } catch (UnsupportedEncodingException e) {
//            e.printStackTrace();
//        }

        String phone = fUser.getPhoneNumber();;
        String email = fUser.getEmail();

        String token = MyPreferenceManager.getInstance(this).getString(SettingsKeys.KEY_DEVICE_TOKEN, "");

        JSONObject requestParam = new JSONObject();
        try {
            requestParam.put("firebaseUID", uid);
            requestParam.put("name", name);
            requestParam.put("phone", phone != null ? phone : "");
            requestParam.put("email", email != null ? email : "");
            requestParam.put("token", token);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // Create the request body
        RequestBody body = RequestBody.create(okhttp3.MediaType.parse("application/json; charset=utf-8"),
                requestParam.toString());

        // Call apis
        KesaaApplication.getKesaaAPI().getUserDetails(body)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<UserResponseData>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(UserResponseData jsonObject) {
                        progressBar.setVisibility(View.GONE);
                        Log.d(TAG, "GetUserDetails : " + jsonObject.toString());

                        if (jsonObject.getCode() == 200) {
                            processServerUserDetails(fUser, uid, jsonObject.getData());
                        }
                        else{
                            // Show error message
                            if (MyPreferenceManager.getInstance(OTPActivity.this).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                                Toast.makeText(OTPActivity.this, jsonObject.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(OTPActivity.this, jsonObject.getArabicMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(OTPActivity.this, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                        Log.d(TAG, "GetUserDetails Error: " + e.getLocalizedMessage());
                    }

                    @Override
                    public void onComplete() {

                    }
                });

    }

    public void processServerUserDetails(FirebaseUser fUser, String uid, UserData user) {
        if (ActiveSession.getInstance() != null) {
            if (ActiveSession.getInstance().currentUser == null) {
                ActiveSession.getInstance().currentUser = new UserTemplate(uid);
            }
            ActiveSession.getInstance().currentUser.id = user.getId();
            ActiveSession.getInstance().currentUser.uid = uid;

            ActiveSession.getInstance().currentUser.firstName = firstName;
            ActiveSession.getInstance().currentUser.lastName = lastName;

            // Get user details
            String username = user.getName();
            String email = user.getEmail();
            String phone = user.getPhone();
            String profilePicture = null;
            if (fUser.getPhotoUrl() != null)
                profilePicture = fUser.getPhotoUrl().toString();

            if (username != null) {
                ActiveSession.getInstance().currentUser.fullName = username;

                String[] names = username.split(" ");
                if (names.length > 1) {
                    ActiveSession.getInstance().currentUser.firstName = names[0];
                    ActiveSession.getInstance().currentUser.lastName = names[1];
                }
            }
            else{
                ActiveSession.getInstance().currentUser.fullName = ActiveSession.getInstance().currentUser.firstName + " " + ActiveSession.getInstance().currentUser.lastName;
            }

            // Save user name in local
            MyPreferenceManager.getInstance(this).put(SettingsKeys.KEY_FULL_NAME, ActiveSession.getInstance().currentUser.fullName);

            if (email != null) {
                ActiveSession.getInstance().currentUser.email = email;
            }

            if (phone != null) {
                ActiveSession.getInstance().currentUser.mobileNum = phone;
            }

            if (profilePicture != null) {
                ActiveSession.getInstance().currentUser.profileImageUrl = profilePicture;
                MyPreferenceManager.getInstance(OTPActivity.this).put(SettingsKeys.KEY_PROFILE_PICTURE, profilePicture);
            }

            if (ActiveSession.getInstance().currentUser.id > 0) {
                Log.d(TAG, "USER is : " + Integer.toString(ActiveSession.getInstance().currentUser.id));

                // Update user credentials
//                        updateUserDetails();

                // Go to StyleSelection Page
                MyPreferenceManager.getInstance(OTPActivity.this).put(SettingsKeys.KEY_IS_LOGGED, true);
                Intent intent = new Intent(OTPActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }

//        try {
//
//            JSONArray jArray = new JSONArray(incomingStr);
//            Log.d(TAG, Integer.toString(jArray.length()));
//            for (int arr_elem = 0 ; arr_elem < jArray.length() ; arr_elem++)
//            {
//                JSONObject explrObject = jArray.getJSONObject(arr_elem);
//                Log.d(TAG, explrObject.toString());
//                Log.d(TAG, Integer.toString(arr_elem));
//
//
//
//                } else {
//                    Toast.makeText(LoginActivity.this, "login : session is null  " , Toast.LENGTH_LONG).show();
//                }
//            }
//
//        } catch (Throwable t) {
//            Log.e(TAG, "Could not parse malformed user get JSONArray: \"" + t.getMessage() + "\"");
//        }

        }

//        try {
//
//            JSONArray jArray = new JSONArray(incomingStr);
//            Log.d(TAG, Integer.toString(jArray.length()));
//            for (int arr_elem = 0 ; arr_elem < jArray.length() ; arr_elem++)
//            {
//                JSONObject explrObject = jArray.getJSONObject(arr_elem);
//                Log.d(TAG, explrObject.toString());
//                Log.d(TAG, Integer.toString(arr_elem));
//
//                if (ActiveSession.getInstance() != null) {
//                    if (ActiveSession.getInstance().currentUser == null) {
//                        ActiveSession.getInstance().currentUser = new UserTemplate(uid);
//                    }
//
//                    ActiveSession.getInstance().currentUser.id = explrObject.getInt("user_id");
//                    ActiveSession.getInstance().currentUser.uid = uid;
//
//                    ActiveSession.getInstance().currentUser.firstName = firstName;
//                    ActiveSession.getInstance().currentUser.lastName = lastName;
//
//                    // Save user details
//                    // Get user details
//                    String username = fUser.getDisplayName();
//                    String email = fUser.getEmail();
//                    String phone = fUser.getPhoneNumber();
//                    String profilePicture = null;
//                    if (fUser.getPhotoUrl() != null)
//                        profilePicture = fUser.getPhotoUrl().toString();
//
//                    if (username != null) {
//                        ActiveSession.getInstance().currentUser.fullName = username;
//
//                        String[] names = username.split(" ");
//                        if (names.length > 1){
//                            ActiveSession.getInstance().currentUser.firstName = names[0];
//                            ActiveSession.getInstance().currentUser.lastName = names[1];
//                        }
//                    }
//                    else{
//                        ActiveSession.getInstance().currentUser.fullName = ActiveSession.getInstance().currentUser.firstName + " " + ActiveSession.getInstance().currentUser.lastName;
//                    }
//
//                    MyPreferenceManager.getInstance(this).put(SettingsKeys.KEY_FULL_NAME, ActiveSession.getInstance().currentUser.fullName);
//
//
//
//                    if (email != null){
//                        ActiveSession.getInstance().currentUser.email = email;
//                    }
//                    else{
//                        ActiveSession.getInstance().currentUser.email = "";
//                    }
//
//                    if (phone != null){
//                        ActiveSession.getInstance().currentUser.mobileNum = phone;
//                    }
//
//                    if (profilePicture != null){
//                        ActiveSession.getInstance().currentUser.profileImageUrl = profilePicture;
//                        MyPreferenceManager.getInstance(OTPActivity.this).put(SettingsKeys.KEY_PROFILE_PICTURE, profilePicture);
//                    }
//                    else{
//                        ActiveSession.getInstance().currentUser.profileImageUrl = "";
//                        MyPreferenceManager.getInstance(OTPActivity.this).put(SettingsKeys.KEY_PROFILE_PICTURE, profilePicture);
//                    }
//
//                    // Update user credentials
//                    updateUserDetails();
//
//                } else {
//                    Toast.makeText(OTPActivity.this, "login : session is null  " , Toast.LENGTH_LONG).show();
//                }
//            }
//
//        } catch (Throwable t) {
//            Log.e(TAG, "Could not parse malformed userdet JSONArray: \"" + t.getMessage() + "\"");
//        }


    }

    // Update user credentials
    private void updateUserDetails(){
        // Check if network is connected
        if (!Utils.isNetworkConnected(this)){
            Toast.makeText(this, getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);

        String username = "";
        if (ActiveSession.getInstance().currentUser.fullName != null || !ActiveSession.getInstance().currentUser.fullName.equals(""))
            username = ActiveSession.getInstance().currentUser.fullName;
        else
            username = ActiveSession.getInstance().currentUser.firstName + " " + ActiveSession.getInstance().currentUser.lastName;

        String phone = ActiveSession.getInstance().currentUser.mobileNum.replace("+", "");
        String email = ActiveSession.getInstance().currentUser.email == null ? "" : ActiveSession.getInstance().currentUser.email;
        String userId = String.valueOf(ActiveSession.getInstance().currentUser.id);

        try {
            username = URLEncoder.encode(username, "utf-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        username = username.replace(" ", "%20");

//        KesaaApplication.getKesaaAPI().updateUserCredentials(username, phone, email, userId)
//                .subscribeOn(Schedulers.io())
//                .observeOn(AndroidSchedulers.mainThread())
//                .subscribe(new Observer<JsonObject>() {
//                    @Override
//                    public void onSubscribe(Disposable d) {
//
//                    }
//
//                    @Override
//                    public void onNext(JsonObject jsonObject) {
//                        progressBar.setVisibility(View.GONE);
//                        if (jsonObject.get("status").getAsInt() == 1){
//                            Log.d(TAG, "User details updated successfully");
//
//                            // Go to main page
//                            MyPreferenceManager.getInstance(OTPActivity.this).put(SettingsKeys.KEY_IS_LOGGED, true);
//                            Intent intent = new Intent(OTPActivity.this, MainActivity.class);
//                            startActivity(intent);
//                            finish();
//                        }
//                        else{
//                            Log.d(TAG, "Failed to update user details : " + jsonObject.get("message").getAsString());
//                        }
//                    }
//
//                    @Override
//                    public void onError(Throwable e) {
//                        Log.d(TAG, "Failed to update user details : " + e.getLocalizedMessage());
//                        progressBar.setVisibility(View.GONE);
//                    }
//
//                    @Override
//                    public void onComplete() {
//
//                    }
//                });
    }

}
