package com.tailor.kesaa.activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

//import com.facebook.AccessToken;
//import com.facebook.CallbackManager;
//import com.facebook.FacebookCallback;
//import com.facebook.FacebookException;
//import com.facebook.login.LoginResult;
//import com.facebook.login.widget.LoginButton;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FacebookAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.tailor.kesaa.KesaaApplication;
import com.tailor.kesaa.MainActivity;
import com.tailor.kesaa.R;
import com.tailor.kesaa.customs.CustomFontEditText;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;
import com.tailor.kesaa.global.Utils;
import com.tailor.kesaa.instagram.AuthenticationDialog;
import com.tailor.kesaa.instagram.AuthenticationListener;
import com.tailor.kesaa.model.ActiveSession;
import com.tailor.kesaa.model.UserTemplate;
import com.tailor.kesaa.model.user.UserData;
import com.tailor.kesaa.model.user.UserResponseData;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import okhttp3.RequestBody;

public class LoginActivity extends KessaActivity implements AuthenticationListener {

    private static final String TAG = "Login";
    private static int RC_SIGN_IN = 1001;

    private static final String SIGN_IN_CANCELLED = "12501";
    private static final String SIGN_IN_FAILED    = "12500";

    // Firebase
    public FirebaseAuth firebaseAuth;
    public FirebaseUser firebaseUser;
    public GoogleSignInClient mGoogleSignInClient;

    // Instagram
    private String token = null;
    private AuthenticationDialog authenticationDialog = null;

    // Session
    public ActiveSession currentSession = null;

    // Check if phone verification button is pressed
    private boolean isPhoneVerify = false;


    // ProgressBar
    @BindView(R.id.progressBar)
    ProgressBar progressBar;

    // First Name
    @BindView(R.id.first_name_edt)
    CustomFontEditText firstNameText;

    // Last Name
    @BindView(R.id.last_name_edt)
    CustomFontEditText lastNameText;

    // Phone Number
    @BindView(R.id.phone_edt)
    CustomFontEditText phoneText;

    // user phone number
    String userPhoneNumber;

    // Facebook LoginButton
//    @BindView(R.id.fb_login_button)
//    LoginButton fbLoginButton;
//
//    private CallbackManager callbackManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Check current locale
        if (MyPreferenceManager.getInstance(this).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
            changeLocale("en","US");
        }
        else{
            changeLocale("ar","SA");
        }

        setContentView(R.layout.fragment_login_reg);

        ButterKnife.bind(this);

        currentSession = ActiveSession.getInstance();

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();

        // initialize Facebook SDK
        initFbLogin();

        // Init GoogleSignIn
        initGoogleSignIn();

        // Check if user logged in already
        boolean loggedIn = MyPreferenceManager.getInstance().getBoolean(SettingsKeys.KEY_IS_LOGGED);
        if (firebaseUser != null && loggedIn)
        {
            getMySQLUserDetailsFromUid(firebaseUser, firebaseUser.getUid(),false);
        }
    }

    // Google SignIn
    @OnClick(R.id.google_login_image) void loginWithGoogle(){
        signIn();
    }

    // Login with Phone
    @OnClick(R.id.btn_login_reg) void loginWithPhone(){
        verifyPhone();
    }

    // Login with Facebook
    @OnClick(R.id.fb_login_image) void loginWithFacebook(){
        // Check if network is connected
        if (!Utils.isNetworkConnected(this)){
            Toast.makeText(this, getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
            return;
        }

        // do Facebook Login
//        fbLoginButton.setReadPermissions("email", "public_profile");
//        fbLoginButton.performClick();

        //check already have access token
//        token = MyPreferenceManager.getInstance(this).getString(SettingsKeys.KEY_INSTAGRAM_TOKEN);
//        if (token != null) {
//            getUserInfoByAccessToken(token);
//        }
//        else {
//            authenticationDialog = new AuthenticationDialog(this, this);
//            authenticationDialog.setCancelable(true);
//            authenticationDialog.show();
//        }
    }

    private void initFbLogin(){
 /*
        callbackManager = CallbackManager.Factory.create();

        // Callback registration
        fbLoginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {

                Log.d(TAG, "facebook:onSuccess:" + loginResult);
                handleFacebookAccessToken(loginResult.getAccessToken());
            }

            @Override
            public void onCancel() {
                progressBar.setVisibility(View.GONE);

                Log.d(TAG, "*** Facebook Login Canceled ***");
            }

            @Override
            public void onError(FacebookException exception) {
                progressBar.setVisibility(View.GONE);

                Log.d(TAG, "*** Facebook Login Failed ***");
                Utils.showAlert(LoginActivity.this, exception.getLocalizedMessage());
            }
        });
  */
    }

//    private void handleFacebookAccessToken(AccessToken token) {
//        Log.d(TAG, "handleFacebookAccessToken:" + token);
//
//        progressBar.setVisibility(View.VISIBLE);
//
//        AuthCredential credential = FacebookAuthProvider.getCredential(token.getToken());
//        firebaseAuth.signInWithCredential(credential)
//                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
//                    @Override
//                    public void onComplete(@NonNull Task<AuthResult> task) {
//
//                        progressBar.setVisibility(View.GONE);
//
//                        if (task.isSuccessful()) {
//                            // Sign in success, update UI with the signed-in user's information
//                            Log.d(TAG, "signInWithCredential:success");
//
//                            firebaseUser = firebaseAuth.getCurrentUser();
//                            getMySQLUserDetailsFromUid(firebaseUser, firebaseUser.getUid(),false);
//                        }
//                        else {
//                            // If sign in fails, display a message to the user.
//                            Log.d(TAG, "Facebook signInWithCredential:failure ", task.getException());
//                            Toast.makeText(LoginActivity.this, getString(R.string.sign_in_failed), Toast.LENGTH_SHORT).show();
//                        }
//
//                        // ...
//                    }
//                });
//    }

    // get user info
    private void getUserInfoByAccessToken(String token){
    }

    // Initialize the google signin
    private void initGoogleSignIn(){
        // Check if network is connected
//        if (!Utils.isNetworkConnected(this)){
//            Toast.makeText(this, getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
//            return;
//        }

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.google_android_web_id))
                .requestEmail()
                .build();


        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
        boolean loggedIn = MyPreferenceManager.getInstance().getBoolean(SettingsKeys.KEY_IS_LOGGED);

        if (account != null)
        {
            if (firebaseUser != null && loggedIn)
            {
                getMySQLUserDetailsFromUid(firebaseUser, firebaseUser.getUid(),false);
            }

        } else {
            Log.d("GOOGLE_AUTH","account is null");
        }

        currentSession.firebaseAuth = firebaseAuth;
        currentSession.firebaseUser = firebaseUser;
    }

    // Google SignIn
    private void signIn() {
        if (mGoogleSignInClient != null){
            Intent signInIntent = mGoogleSignInClient.getSignInIntent();
            startActivityForResult(signInIntent, RC_SIGN_IN);
        }
        else{
            initGoogleSignIn();
        }
    }


    // Instagram Listener
    @Override
    public void onTokenReceived(String auth_token) {
        if (auth_token == null)
            return;

        Log.d(TAG, "Instagram Authentication Token : " + auth_token);
        MyPreferenceManager.getInstance(this).put(SettingsKeys.KEY_INSTAGRAM_TOKEN, auth_token);
        token = auth_token;
        getUserInfoByAccessToken(token);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
//        callbackManager.onActivityResult(requestCode, resultCode, data);

        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                // Google Sign In was successful, authenticate with Firebase
                Toast.makeText(LoginActivity.this, "Google Sign In Success" , Toast.LENGTH_SHORT).show();
                GoogleSignInAccount account = task.getResult(ApiException.class);
                firebaseAuthWithGoogle(account);

            } catch (ApiException e) {
                // Google Sign In failed, update UI appropriately

                Log.d(TAG, "Google sign in failed : ", e);
                // ...

                if (e.getLocalizedMessage().contains(SIGN_IN_CANCELLED)) {
                    Toast.makeText(LoginActivity.this, getString(R.string.sign_in_cancelled) , Toast.LENGTH_LONG).show();
                }
                else{
//                    Toast.makeText(LoginActivity.this, getString(R.string.sign_in_failed) , Toast.LENGTH_LONG).show();
                    Toast.makeText(LoginActivity.this, e.getLocalizedMessage() , Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    // Get User ID from server
    public void getMySQLUserDetailsFromUid(FirebaseUser fUser, final String uid, final boolean cameFromNotification) {
        // Check if network is connected
        if (!Utils.isNetworkConnected(this)){
            Toast.makeText(this, getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
            return;
        }

        if (uid == null)
            return;

        progressBar.setVisibility(View.VISIBLE);

        // Firebase User details
        String name = fUser.getDisplayName();
//        try {
//            name = URLEncoder.encode(name, "utf-8");
//            name = name.replace(" ", "%20");
//        } catch (UnsupportedEncodingException e) {
//            e.printStackTrace();
//        }

        String phone = fUser.getPhoneNumber();
        String email = fUser.getEmail();

        String deviceToken = MyPreferenceManager.getInstance(this).getString(SettingsKeys.KEY_DEVICE_TOKEN, "");

        JSONObject requestParam = new JSONObject();
        try {
            requestParam.put("firebaseUID", uid);
            requestParam.put("name", name != null ? name : "");
            requestParam.put("token", deviceToken);
            requestParam.put("phone", phone != null ? phone : "");
            requestParam.put("email", email != null ? email : "");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // Create the request body
        RequestBody body = RequestBody.create(okhttp3.MediaType.parse("application/json; charset=utf-8"),
                requestParam.toString());


        // Call apis
        KesaaApplication.getKesaaAPI().getUserDetails(body)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<UserResponseData>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(UserResponseData jsonObject) {
                        progressBar.setVisibility(View.GONE);
                        Log.d(TAG, "GetUserDetails : " + jsonObject.toString());

                        if (jsonObject.getCode() == 200) {
                            processServerUserDetails(fUser, uid, jsonObject.getData());
                        }
                        else{
                            // Show error message
                            if (MyPreferenceManager.getInstance(LoginActivity.this).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                                Toast.makeText(LoginActivity.this, jsonObject.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(LoginActivity.this, jsonObject.getArabicMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(LoginActivity.this, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                        Log.d(TAG, "GetUserDetails Error: " + e.getLocalizedMessage());

                        // Test
                        // Go to StyleSelection Page
//                        gotoStyleSelectionPage();
                    }

                    @Override
                    public void onComplete() {

                    }
                });

    }

    public void processServerUserDetails(FirebaseUser fUser, String uid, UserData user) {
        // Check if network is connected
        if (!Utils.isNetworkConnected(this)) {
            Toast.makeText(this, getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
            return;
        }

        if (currentSession != null) {
            if (currentSession.currentUser == null) {
                currentSession.currentUser = new UserTemplate(uid);
            }
            currentSession.currentUser.id = user.getId();
            currentSession.currentUser.uid = uid;

            // Get user details
            String username = user.getName();
            String email = user.getEmail();
            String phone = user.getPhone();
            String profilePicture = null;
            if (fUser.getPhotoUrl() != null)
                profilePicture = fUser.getPhotoUrl().toString();

            if (username != null) {
                ActiveSession.getInstance().currentUser.fullName = username;

                String[] names = username.split(" ");
                if (names.length > 1) {
                    ActiveSession.getInstance().currentUser.firstName = names[0];
                    ActiveSession.getInstance().currentUser.lastName = names[1];
                }
            }
            else{
                username = "";
            }

            // Save username in local
            MyPreferenceManager.getInstance(this).put(SettingsKeys.KEY_FULL_NAME, ActiveSession.getInstance().currentUser.fullName);

            if (email != null) {
                ActiveSession.getInstance().currentUser.email = email;
            }

            if (phone != null) {
                ActiveSession.getInstance().currentUser.mobileNum = phone;
            }

            if (profilePicture != null) {
                ActiveSession.getInstance().currentUser.profileImageUrl = profilePicture;
                MyPreferenceManager.getInstance(LoginActivity.this).put(SettingsKeys.KEY_PROFILE_PICTURE, profilePicture);
            }

            if (currentSession.currentUser.id > 0) {
                Log.d(TAG, "USER is : " + Integer.toString(currentSession.currentUser.id));

                // Update user credentials
//                        updateUserDetails();

                // Go to StyleSelection Page
                gotoStyleSelectionPage();
            }

        }
    }


    // [START sign_in_with_phone]
    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        firebaseAuth.signInWithCredential(credential)
                .addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update session  with the signed-in user's information
                            Log.d(TAG, "signInWithPhoneCredential:success");
                            FirebaseUser user = task.getResult().getUser();
                            firebaseUser = user;

                            getMySQLUserDetailsFromUid(firebaseUser, user.getUid(),false);
                        } else {
                            // Sign in failed, display a message and update the UI
                            Log.d(TAG, "signInWithCredential:failure", task.getException());
                            if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                                // The verification code entered was invalid
                            }
                        }
                    }
                });
    }
    // [END sign_in_with_phone]

    private void firebaseAuthWithGoogle(GoogleSignInAccount acct) {
        Log.d(TAG, "firebaseAuthWithGoogle : " + acct.getId());

        // Check if network is connected
        if (!Utils.isNetworkConnected(this)){
            Toast.makeText(this, getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
            return;
        }


        AuthCredential credential = GoogleAuthProvider.getCredential(acct.getIdToken(), null);
        firebaseAuth.signInWithCredential(credential)
                .addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "signInWithgmailCredential:success");

                            FirebaseUser user = firebaseAuth.getCurrentUser();
                            firebaseUser = user;

                            // Go to the MainActivity from here
                            getMySQLUserDetailsFromUid(firebaseUser, user.getUid(),false);
                        }
                        else {
                            // If sign in fails, display a message to the user.
                            Log.d(TAG, "signInWithCredential:failure", task.getException());
                            try{
                                if (task.getException().getLocalizedMessage().contains(SIGN_IN_CANCELLED)) {
                                    Toast.makeText(LoginActivity.this, getString(R.string.sign_in_cancelled) , Toast.LENGTH_LONG).show();
                                }
                                else{
                                    Toast.makeText(LoginActivity.this, getString(R.string.sign_in_failed) , Toast.LENGTH_LONG).show();
                                }
                            }
                            catch (Exception e){
                                e.printStackTrace();
                                Toast.makeText(LoginActivity.this, e.getLocalizedMessage() , Toast.LENGTH_LONG).show();
                            }
                        }

                        // ...
                    }
                });
    }

    // Navigate into style selection page
    private void gotoStyleSelectionPage(){
        MyPreferenceManager.getInstance(this).put(SettingsKeys.KEY_IS_LOGGED, true);
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    private boolean isValidMobile(String phone) {
        return android.util.Patterns.PHONE.matcher(phone).matches();
    }

    // Verify phone number
    public void verifyPhone(){
        // Check if network is connected
        if (!Utils.isNetworkConnected(this)){
            Toast.makeText(this, getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
            return;
        }

        userPhoneNumber = phoneText.getText().toString();

        userPhoneNumber = "+966" + userPhoneNumber;
        if (isValidMobile(userPhoneNumber)) {
            isPhoneVerify = true;

            progressBar.setVisibility(View.VISIBLE);

            PhoneAuthProvider.getInstance().verifyPhoneNumber(
                    userPhoneNumber, 60 /*timeout*/, TimeUnit.SECONDS,
                    this,
                    new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

                        @Override
                        public void onCodeSent(String verificationId,
                                               PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                            Log.d(TAG,"Code sent");
                            progressBar.setVisibility(View.GONE);

                            isPhoneVerify = false;

                            // Go to Otp page
                            Intent intent = new Intent(LoginActivity.this, OTPActivity.class);
                            intent.putExtra("otp_id", verificationId);
                            intent.putExtra(SettingsKeys.KEY_FIRST_NAME, firstNameText.getText().toString());
                            intent.putExtra(SettingsKeys.KEY_LAST_NAME, lastNameText.getText().toString());
                            intent.putExtra(SettingsKeys.KEY_PHONE, userPhoneNumber);
                            SettingsKeys.resendingToken = forceResendingToken;
                            startActivity(intent);
                        }

                        @Override
                        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {
                            // Sign in with the credential
                            Log.d(TAG,"Phone Verification Succeeded");
                            progressBar.setVisibility(View.GONE);

                            isPhoneVerify = false;

                            signInWithPhoneAuthCredential(phoneAuthCredential);
                        }

                        @Override
                        public void onVerificationFailed(FirebaseException e) {
                            Log.d(TAG,R.string.ph_verify_failed_text + e.toString());
                            progressBar.setVisibility(View.GONE);

                            Toast.makeText(LoginActivity.this, e.getLocalizedMessage() , Toast.LENGTH_LONG).show();

                            isPhoneVerify = false;
                        }

                    });
        } else {
            Toast.makeText(LoginActivity.this, R.string.ph_invalid_text , Toast.LENGTH_LONG).show();
        }
    }
}
