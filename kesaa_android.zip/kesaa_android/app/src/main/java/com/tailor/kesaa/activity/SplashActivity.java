package com.tailor.kesaa.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.annotation.Nullable;

import com.tailor.kesaa.R;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;

import butterknife.ButterKnife;

public class SplashActivity extends KessaActivity {

    Intent intent;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_splash);
        ButterKnife.bind(this);

        if (MyPreferenceManager.getInstance(this).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
            changeLocale("en","US");
        }
        else{
            changeLocale("ar","SA");
        }

        checkLogin();
    }

    private void checkLogin(){

        if (MyPreferenceManager.getInstance(this).getBoolean(SettingsKeys.KEY_IS_LOGGED)){
            intent = new Intent(SplashActivity.this, LoginActivity.class);
        }
        else{
            intent = new Intent(SplashActivity.this, LanguageSelectActivity.class);
        }

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(intent);
                finish();
            }
        }, 1500);
    }
}
