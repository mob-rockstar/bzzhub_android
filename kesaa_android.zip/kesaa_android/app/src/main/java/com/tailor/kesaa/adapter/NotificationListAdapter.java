package com.tailor.kesaa.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.daimajia.swipe.SimpleSwipeListener;
import com.daimajia.swipe.SwipeLayout;
import com.daimajia.swipe.adapters.BaseSwipeAdapter;
import com.tailor.kesaa.R;
import com.tailor.kesaa.global.AllHelpers;
import com.tailor.kesaa.model.notification.NotificationDetail;

import java.util.Date;
import java.util.List;

public class NotificationListAdapter extends BaseSwipeAdapter {
    private Context mContext;

    List<NotificationDetail> notifications;

    public NotificationListAdapter(Context mContext, List<NotificationDetail> notificationArray) {
        this.mContext = mContext;
        this.notifications = notificationArray;
    }

    @Override
    public int getSwipeLayoutResourceId(int position) {
        return R.id.swipe;
    }

    @Override
    public View generateView(int position, ViewGroup parent) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.item_notification_list, null);
        SwipeLayout swipeLayout = (SwipeLayout)v.findViewById(getSwipeLayoutResourceId(position));
        swipeLayout.addSwipeListener(new SimpleSwipeListener() {
            @Override
            public void onOpen(SwipeLayout layout) {

            }
        });
        swipeLayout.setOnDoubleClickListener(new SwipeLayout.DoubleClickListener() {
            @Override
            public void onDoubleClick(SwipeLayout layout, boolean surface) {
                Toast.makeText(mContext, "DoubleClick", Toast.LENGTH_SHORT).show();
            }
        });
        v.findViewById(R.id.trash_image).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(mContext, "click delete", Toast.LENGTH_SHORT).show();
            }
        });
        return v;
    }

    @Override
    public void fillValues(int position, View convertView) {
//        TextView t = (TextView)convertView.findViewById(R.id.position);
//        t.setText((position + 1) + ".");

        NotificationDetail notificationDetail = notifications.get(position);

        // Content
        TextView notificationContent = convertView.findViewById(R.id.notification_msg_tex);
        notificationContent.setText(notificationDetail.getText());

        // Date
        TextView notificationDate = convertView.findViewById(R.id.notification_date_tex);
        Date notiDate = AllHelpers.strToDate(notificationDetail.getCreatedDate());
        notificationDate.setText(AllHelpers.dateToStr(notiDate));

        // Title
        TextView notificationTitle = convertView.findViewById(R.id.notification_title_text);
        notificationTitle.setText(mContext.getString(R.string.order_format, "#" + notificationDetail.getOrderId()));

    }

    @Override
    public int getCount() {
        return notifications.size();
    }

    @Override
    public Object getItem(int position) {
        return notifications.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
}
