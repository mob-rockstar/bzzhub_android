package com.tailor.kesaa.adapter;


import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;

import androidx.annotation.Nullable;

import java.util.ArrayList;

import com.bumptech.glide.Glide;
import com.tailor.kesaa.R;
import com.tailor.kesaa.customs.CustomFontButton;
import com.tailor.kesaa.customs.CustomFontTextView;
import com.tailor.kesaa.listener.DoubleClickListener;
import com.tailor.kesaa.model.tailor.TailorDetails;
import com.tailor.kesaa.fragment.TailorListFragment;

import butterknife.BindView;
import butterknife.ButterKnife;

public class TailorDataAdapter extends ArrayAdapter<TailorDetails> implements View.OnClickListener {

    private ArrayList<TailorDetails> tailorDataSet;
    private TailorListFragment masterTfrag;
    Context mContext;

    private String TAG = "TAIL_FRAG_ADAPT";

    public  int screen_width = -1;
    public  int screen_height = -1;

    public float optionPrice = 0f;


    // View lookup cache
    static class TailorDetailCardHolder {
        @BindView(R.id.select_tailor_btn)
        CustomFontButton selectTailorButton;

        @BindView(R.id.tailor_name_text)
        CustomFontTextView tailorNameText;

        @BindView(R.id.rating_bar)
        RatingBar tailorNumStars;

        @BindView(R.id.review_num_text)
        CustomFontTextView tailorReviewsText;

        @BindView(R.id.tailor_approx_price)
        CustomFontTextView tailorApproxPriceText;

        @BindView(R.id.price_layout)
        LinearLayout tailorPriceLayout;

        @BindView(R.id.rate_review_horiz_row)
        LinearLayout tailorReviewLayout;

        @BindView(R.id.tailor_profile_img)
        ImageView tailorPic;

        @BindView(R.id.tailor_profile_check)
        ImageView tailorCheck;

//        @BindView(R.id.card_horiz_row)
//        LinearLayout overallCardWrapper;

        @BindView(R.id.tailor_info_layout)
        LinearLayout tailorInfoLayout;

        @BindView(R.id.delivery_time_text)
        CustomFontTextView deliveryDaysText;

        public TailorDetailCardHolder(View view){
            ButterKnife.bind(this, view);
        }
    }



    public TailorDataAdapter(ArrayList<TailorDetails> data, Context context, TailorListFragment tFrag, int width, int height, float price) {
        super(context, R.layout.tailor_list_card, data);
        this.tailorDataSet = data;
        this.mContext=context;
        this.masterTfrag = tFrag;
        this.screen_width = width;
        this.screen_height = height;
        this.optionPrice = price;
    }



    @Override
    public void onClick(View v) {

        TailorDetails currTailorDetail = null;
        if ( v.getTag() != null) {
            int position = (Integer) v.getTag();
            Object object = getItem(position);
            currTailorDetail = (TailorDetails) object;


            Log.d(TAG, "Adapter view " + v.getId());

            switch (v.getId()) {
                case R.id.select_tailor_btn:
                    Log.d(TAG, "Btn");
                    masterTfrag.cardOptionClicked("btn_" +v.getTag().toString(), currTailorDetail);
                    break;
                case R.id.tailor_profile_img:
                    Log.d(TAG, "Pic");
                    masterTfrag.cardOptionClicked("pic_" +v.getTag().toString(), currTailorDetail);
                    //masterTfrag.picSelectedForReview(currTailorDetail.getName());
                    break;

                case R.id.rate_review_horiz_row:
                    Log.d(TAG, "rate");
                    masterTfrag.cardOptionClicked("rate_"+v.getTag().toString(), currTailorDetail);
                    //masterTfrag.picSelectedForReview(currTailorDetail.getName());
                    break;

                case R.id.price_layout:
                    Log.d(TAG, "Price");
                    masterTfrag.cardOptionClicked("price_"+v.getTag().toString(), currTailorDetail);
                    //masterTfrag.picSelectedForReview(currTailorDetail.getName());
                    break;
                case R.id.tailor_info_layout:
                    Log.d(TAG, "Tailor Information");
                    masterTfrag.cardOptionClicked("tailorInfo_"+v.getTag().toString(), currTailorDetail);

                default:
                    Log.d(TAG, "Other");
                    masterTfrag.cardOptionClicked("Something else " + currTailorDetail.getName(), currTailorDetail);
                    break;

            }
        }

    }

    @Override
    public int getCount() {
        return tailorDataSet.size();
    }

    @Nullable
    @Override
    public TailorDetails getItem(int position) {
        return tailorDataSet.get(position);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        TailorDetails dataModel = getItem(position);

        // Check if an existing view is being reused, otherwise inflate the view
        TailorDetailCardHolder viewHolder; // view lookup cache stored in tag
        LayoutInflater inflater = LayoutInflater.from(getContext());

        final View result;

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.tailor_list_card, parent, false);
            viewHolder = new TailorDetailCardHolder(convertView);
            convertView.setTag(viewHolder);
        }
        else {
            viewHolder = (TailorDetailCardHolder) convertView.getTag();
        }

        float alphaVal = 0.80f;

        if (masterTfrag != null) {
            if (masterTfrag.selectedTailor != null) {
                if (masterTfrag.selectedTailor.id == dataModel.id) {
                    viewHolder.tailorCheck.setVisibility(View.VISIBLE);
                    alphaVal = 1.0f;

                } else {
                    viewHolder.tailorCheck.setVisibility(View.GONE);
                    alphaVal = 0.80f;

                }
            } else if (masterTfrag.masterActivity.currentOrderItem.tailor_id == dataModel.id) {
                viewHolder.tailorCheck.setVisibility(View.VISIBLE);
                alphaVal = 1.0f;
            }
            else{
                viewHolder.tailorCheck.setVisibility(View.GONE);
            }
        } else {
            viewHolder.tailorCheck.setVisibility(View.GONE);
        }

        // Tailor Name
        viewHolder.tailorNameText.setText(dataModel.getName());

        // Delivery time
        viewHolder.deliveryDaysText.setText(mContext.getString(R.string.delivery_days_format, String.valueOf(dataModel.deliveryDays)));

        // Rating
        String reviewText = String.valueOf(dataModel.getReviews());
        viewHolder.tailorReviewsText.setText(reviewText);
        viewHolder.tailorReviewsText.setTag(position);
        viewHolder.tailorReviewsText.setOnClickListener(this);

        viewHolder.tailorReviewLayout.setOnClickListener(this);
        viewHolder.tailorReviewLayout.setTag(position);

        // Tailor Rating
        viewHolder.tailorNumStars.setRating(dataModel.getRating());

        // Tailor Image
        viewHolder.tailorPic.setOnClickListener(this);
        viewHolder.tailorPic.setTag(position);
        Glide.with(mContext).load(dataModel.TailorImagePath).into(viewHolder.tailorPic);


        // Select tailor button
        viewHolder.selectTailorButton.setTag(position);
        viewHolder.selectTailorButton.setOnClickListener(this);


        // Price layout
        viewHolder.tailorPriceLayout.setTag(position);
        viewHolder.tailorPriceLayout.setOnClickListener(new DoubleClickListener() {
            @Override
            public void onSingleClick(View v) {

            }

            @Override
            public void onDoubleClick(View v) {
                masterTfrag.cardOptionClicked("price_"+v.getTag().toString(), tailorDataSet.get((int)v.getTag()));
            }
        });


        // Price
        float totalPrice = dataModel.totalCost - dataModel.deliveryCost + optionPrice;
        viewHolder.tailorApproxPriceText.setText(mContext.getString(R.string.sar, String.valueOf(totalPrice)));

        viewHolder.tailorInfoLayout.setOnClickListener(this);
        viewHolder.tailorInfoLayout.setTag(position);

//        viewHolder.overallCardWrapper.setAlpha(alphaVal);
        viewHolder.tailorReviewsText.setAlpha(alphaVal);
        viewHolder.tailorNumStars.setAlpha(alphaVal);
        viewHolder.tailorPic.setAlpha(alphaVal);
        viewHolder.tailorReviewLayout.setAlpha(alphaVal);
        viewHolder.tailorPic.setAlpha(alphaVal);
        viewHolder.selectTailorButton.setAlpha(alphaVal);
        viewHolder.tailorReviewLayout.setAlpha(alphaVal);
        viewHolder.tailorPriceLayout.setAlpha(alphaVal);
        viewHolder.tailorPriceLayout.setAlpha(alphaVal);
        viewHolder.tailorApproxPriceText.setAlpha(alphaVal);

        // Return the completed view to render on screen
        return convertView;
    }



}
