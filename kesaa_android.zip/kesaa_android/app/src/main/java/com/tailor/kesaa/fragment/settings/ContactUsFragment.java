package com.tailor.kesaa.fragment.settings;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.tailor.kesaa.MainActivity;
import com.tailor.kesaa.R;
import com.tailor.kesaa.customs.CustomFontEditText;
import com.tailor.kesaa.global.SettingsKeys;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class ContactUsFragment extends Fragment {
    public MainActivity masterActivity;

    // Subject
    @BindView(R.id.subject_edt)
    CustomFontEditText subjectEdit;

    @BindView(R.id.message_edt)
    CustomFontEditText messageEdit;

    // Message

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_contact_us, container, false);
        ButterKnife.bind(this,view);


        masterActivity = (MainActivity) getActivity();
        if (masterActivity != null){
            masterActivity.showActionBar();
            masterActivity.setFragTitle(getString(R.string.contact_us_title));
        }

        return view;
    }

    @OnClick(R.id.instagram_image) void openInstagram(){
        Uri uri = Uri.parse(SettingsKeys.INSTAGRAM_LINK);
        Intent likeIng = new Intent(Intent.ACTION_VIEW, uri);

        likeIng.setPackage("com.instagram.android");

        try {
            startActivity(likeIng);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(SettingsKeys.INSTAGRAM_LINK)));
        }
    }

    @OnClick(R.id.whatsapp_image) void openWhatsApp(){
        // Open Whatsapp
        String contact = "+966501281591"; // use country code with your phone number
        String url = "https://api.whatsapp.com/send?phone=" + contact;
        try {
            PackageManager pm = masterActivity.getPackageManager();
            pm.getPackageInfo("com.whatsapp", PackageManager.GET_ACTIVITIES);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse(url));
            startActivity(i);
        } catch (PackageManager.NameNotFoundException e) {
            Toast.makeText(masterActivity, "Whatsapp is not installed in your phone", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    @OnClick(R.id.send_button) void sendEmail(){
        if (subjectEdit.getText().toString().isEmpty() || messageEdit.getText().toString().isEmpty()){
            Toast.makeText(masterActivity, getString(R.string.enter_all_options), Toast.LENGTH_SHORT).show();
            return;
        }

        Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
                "mailto", SettingsKeys.CONTACT_EMAIL, null));
//        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_EMAIL, SettingsKeys.CONTACT_EMAIL);
        intent.putExtra(Intent.EXTRA_SUBJECT, subjectEdit.getText().toString());
        intent.putExtra(Intent.EXTRA_TEXT, messageEdit.getText().toString());

        startActivity(Intent.createChooser(intent, getString(R.string.send_email)));
    }
}
