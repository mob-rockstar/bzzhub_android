package com.tailor.kesaa.model;

public class Item  {

    private final String name;
    private final int id;
    private final String itemClass;
    private final String itemDetail;
    private final int image_res_id;
    private final boolean isActive = true;
    public boolean isSelected = false;


    public Item(String name, int id, String itemClass, String itemDetail, int imgId, boolean isSelected) {
        this.name = name;
        this.id = id;
        this.isSelected = isSelected;
        this.itemClass = itemClass;
        this.itemDetail = itemDetail;
        this.image_res_id= imgId;
    }

    public int getId() {
        return id;
    }
    public int getImageResID() {
        return image_res_id;
    }
    public String getName() {
        return name;
    }
    public String getClassName() {
        return itemClass;
    }
    public String getDetail() {
        return itemDetail;
    }
    public int getItemArrayPos() {
        return id;
    }


}
