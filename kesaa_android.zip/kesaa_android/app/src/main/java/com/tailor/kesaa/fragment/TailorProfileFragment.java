package com.tailor.kesaa.fragment;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.gson.JsonObject;
import com.tailor.kesaa.KesaaApplication;
import com.tailor.kesaa.MainActivity;
import com.tailor.kesaa.R;
import com.tailor.kesaa.adapter.TailorReviewListAdapter;
import com.tailor.kesaa.customs.CustomFontButton;
import com.tailor.kesaa.customs.CustomFontEditText;
import com.tailor.kesaa.customs.CustomFontTextView;
import com.tailor.kesaa.global.EventBusMessage;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;
import com.tailor.kesaa.model.tailor.CommentDetail;
import com.tailor.kesaa.model.tailor.CommentListResponse;
import com.tailor.kesaa.model.tailor.TailorDetails;
import com.iarcuschin.simpleratingbar.SimpleRatingBar;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import okhttp3.RequestBody;

public class TailorProfileFragment extends Fragment {

    private static final String TAG = "TailorProfile";

    // Tailor name
    @BindView(R.id.tailor_name_text)
    CustomFontTextView tailorNameText;

    @BindView(R.id.ratingBar)
    RatingBar ratingBar;

    @BindView(R.id.reviews_text)
    CustomFontTextView reviewsText;

    @BindView(R.id.tailor_approx_price)
    CustomFontTextView priceText;

    @BindView(R.id.delivery_time_text)
    CustomFontTextView deliveryTimeText;

    @BindView(R.id.select_tailor_btn)
    CustomFontButton selectTailorButton;

    @BindView(R.id.tailor_profile_img)
    ImageView tailorProfileImage;

    @BindView(R.id.review_list)
    ListView reviewList;

    @BindView(R.id.progressBar)
    ProgressBar progressBar;

    // Rate button
    @BindView(R.id.rate_tailor_btn)
    CustomFontButton rateButton;

    public MainActivity masterActivity;

    // Current Tailor Information
    TailorDetails currTailor;

    private RequestOptions requestOptions;

    // Review list adapter
    TailorReviewListAdapter listAdapter;

    List<CommentDetail> comments = new ArrayList<>();


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View containerView =   inflater.inflate(R.layout.fragment_tailor_profile, container, false);
        ButterKnife.bind(this, containerView);

        // Title Bar
        masterActivity = (MainActivity) getActivity();
        if (masterActivity != null){
            masterActivity.setFragTitle(getString(R.string.tailor_profile));
            masterActivity.showActionBar();
        }

        requestOptions = new RequestOptions();
        requestOptions.placeholder(R.drawable.ic_placeholder);
        requestOptions.error(R.drawable.ic_placeholder);

        if (getArguments() != null){
            currTailor = (TailorDetails)getArguments().getSerializable("selected_tailor");
        }

        initProfileView();

        return containerView;
    }

    // Rate tailor
    @OnClick(R.id.rate_tailor_btn) void rateThisTailor(){
        showRatePopup();
    }

    private void showRatePopup(){
        try {
            Dialog dialog = new Dialog(masterActivity);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView(R.layout.dialog_rate_tailor);
            dialog.getWindow().setBackgroundDrawableResource(R.drawable.empty);
            dialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);

            // Tailor Name
            CustomFontTextView nameText = dialog.findViewById(R.id.tailor_name_text);
            nameText.setText(currTailor.getName());

            // Comment
            CustomFontEditText commentText = dialog.findViewById(R.id.comment_edit);

            // Rating Bar
            SimpleRatingBar ratingBar = dialog.findViewById(R.id.ratingBar);


            // Save
            CustomFontButton saveButton = dialog.findViewById(R.id.save_button);
            saveButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    dialog.dismiss();
                    rateTailor(currTailor.id, commentText.getText().toString().trim(), ratingBar.getRating());
                }
            });

            // Cancel
            CustomFontButton cancelButton = dialog.findViewById(R.id.cancel_button);
            cancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    dialog.dismiss();

                }
            });

            dialog.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Rate tailor
    private void rateTailor(int tailorId, String comment, float rate){
        int uId = masterActivity.currentSession.currentUser.id;
        JSONObject requestParam = new JSONObject();
        try {
            requestParam.put("userId", uId);
            requestParam.put("tailorId", tailorId);
            requestParam.put("comment", comment);
            requestParam.put("rating", rate);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // Create the request body
        RequestBody body = RequestBody.create(okhttp3.MediaType.parse("application/json; charset=utf-8"),
                requestParam.toString());

        // Show the loading progress
        progressBar.setVisibility(View.VISIBLE);

        KesaaApplication.getKesaaAPI().rateTailor(body)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<JsonObject>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(JsonObject response) {
                        progressBar.setVisibility(View.GONE);
                        if (response.get("code").getAsInt() == 200){
                            loadComments();
                        }
                        else{
                            // Show error message
                            if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                                Toast.makeText(masterActivity, response.get("message").getAsString(), Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(masterActivity, response.get("arabicMessage").getAsString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(masterActivity, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }

    @OnClick(R.id.select_tailor_btn) void selectedTailor(){
        EventBus.getDefault().post(new EventBusMessage(EventBusMessage.MessageType.SELECTED_TAILOR, currTailor));

        // Dismiss
        masterActivity.getSupportFragmentManager().popBackStack();
    }

    // Initialize the Profile information view
    private void initProfileView(){
        // Profile image
        Glide.with(masterActivity).load(currTailor.TailorImagePath).into(tailorProfileImage);

        // Name
        tailorNameText.setText(currTailor.TailorName);

        // Price
        priceText.setText(getString(R.string.sar, String.valueOf(currTailor.totalCost - currTailor.deliveryCost)));

        // rating
        ratingBar.setRating(currTailor.TailorStarRating);

        // reviews
        reviewsText.setText(String.valueOf(currTailor.getReviews()));

        initReviewsList();
    }

    // Initialize the Review list
    private void initReviewsList(){
//        comments.clear();
//        listAdapter = new TailorReviewListAdapter(masterActivity, comments);
//        reviewList.setAdapter(listAdapter);

        loadComments();
    }

    // Update the tailor rating
    private void updateTailorRating(){
        float totalRating = 0f;
        for (CommentDetail comment : comments) {
            totalRating += comment.getRating();
        }

        if (comments.size() > 0){
            totalRating = totalRating / comments.size();
        }
        else{
            totalRating = currTailor.TailorStarRating;
        }

        ratingBar.setRating(totalRating);
    }

    private void loadComments(){
        progressBar.setVisibility(View.VISIBLE);
        KesaaApplication.getKesaaAPI().getComments(currTailor.id)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<CommentListResponse>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(CommentListResponse commentListResponse) {
                        progressBar.setVisibility(View.GONE);

                        if (commentListResponse.getCode() == 200){
                            if (commentListResponse.getData()!= null){
                                comments.clear();
                                comments = commentListResponse.getData().getComments();

                                // refresh list
                                listAdapter = new TailorReviewListAdapter(masterActivity, comments);
                                reviewList.setAdapter(listAdapter);

                                updateTailorRating();
                            }
                        }
                        else{
                            // Show error message
                            if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                                Toast.makeText(masterActivity, commentListResponse.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(masterActivity, commentListResponse.getArabicMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(masterActivity, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }

}
