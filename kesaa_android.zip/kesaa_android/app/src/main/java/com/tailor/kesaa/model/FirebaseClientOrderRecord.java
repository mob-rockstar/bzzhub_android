package com.tailor.kesaa.model;

import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class FirebaseClientOrderRecord {

    public String trans_order_id;
    public String order_status;
    public int tailor_id;
    public String user_id;

    public FirebaseClientOrderRecord() {
        // Default constructor required for calls to DataSnapshot.getValue(User.class)
    }

    public FirebaseClientOrderRecord(String order_id, String order_status, int tailor_id) {

        this.trans_order_id = order_id;
        this.order_status = order_status;
        this.tailor_id = tailor_id;


    }

}