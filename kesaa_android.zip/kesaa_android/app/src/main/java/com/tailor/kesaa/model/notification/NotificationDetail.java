package com.tailor.kesaa.model.notification;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class NotificationDetail {
    @SerializedName("id")
    @Expose
    private int id;

    @SerializedName("orderId")
    @Expose
    private int orderId;

    @SerializedName("text")
    @Expose
    private String text;

    @SerializedName("createdDate")
    @Expose
    private String createdDate;

    @SerializedName("userId")
    @Expose
    private int userId;

    @SerializedName("notificationCode")
    @Expose
    private int notificationCode;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getNotificationCode() {
        return notificationCode;
    }

    public void setNotificationCode(int notificationCode) {
        this.notificationCode = notificationCode;
    }
}
