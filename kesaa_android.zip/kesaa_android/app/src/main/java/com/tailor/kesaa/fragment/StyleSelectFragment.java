package com.tailor.kesaa.fragment;

import android.content.Context;
import android.graphics.Point;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.viewpager.widget.ViewPager;

import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.tailor.kesaa.KesaaApplication;
import com.tailor.kesaa.customs.FadePageTransformer;
import com.tailor.kesaa.MainActivity;
import com.tailor.kesaa.R;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;
import com.tailor.kesaa.adapter.ThobeStylePageAdapter;
import com.tailor.kesaa.model.thobe.ThobeStyleData;
import com.tailor.kesaa.model.thobe.ThobeStyleListResponse;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

import static android.text.Layout.JUSTIFICATION_MODE_INTER_WORD;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link StyleSelectFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link StyleSelectFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class StyleSelectFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    public int selected_thobe_style = 0;
    private ThobeStyleData selectedThobeStyle;

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    public TextView styleText;
    public TextView styleTitle;
    private String TAG = "THOBESTYLE";
    private OnFragmentInteractionListener mListener;

    public MainActivity masterActivity;
//    public ArrayList<ThobeStyleDataHolder> thobeTypeList;

    private List<ThobeStyleData> thobeTypeList = new ArrayList<>();

    @BindView(R.id.btn_confirm_style)
    Button confirmButton;

    @BindView(R.id.progressBar)
    ProgressBar progressBar;

    @BindView(R.id.thobe_style_viewpager)
    ViewPager thobeViewPager;

    public StyleSelectFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment StyleSelectFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static StyleSelectFragment newInstance(String param1, String param2) {
        StyleSelectFragment fragment = new StyleSelectFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        masterActivity = (MainActivity) getActivity();
        if (masterActivity != null){
            masterActivity.showActionBar();
        }

        if (masterActivity != null) {
            masterActivity.setFragTitle(getString(R.string.sel_style_title));

            // Firebase analytics event
            Bundle bundle = new Bundle();
            bundle.putString(FirebaseAnalytics.Param.SCREEN_NAME, "Confirm Style");
            bundle.putString(FirebaseAnalytics.Param.SCREEN_CLASS, getClass().getSimpleName());
            masterActivity.mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SCREEN_VIEW, bundle);

            // init time
//            masterActivity.currentSession.user_has_selected_time = false;
//            masterActivity.currentSession.user_has_selected_date = false;
//            masterActivity.currentSession.measure_time_interval = -1;
//
//            if (masterActivity.currentOrderItem != null){
//                masterActivity.currentOrderItem = null;
//                masterActivity.createNewOrderItem();
//            }
//
//            // clear cart items
//            if (masterActivity.currentSession != null)
//                masterActivity.currentSession.current_session_cart.clear();

            if (masterActivity.currentOrderItem == null){
                masterActivity.createNewOrderItem();
            }
        }

        // Inflate the layout for this fragment
        View frag_view = inflater.inflate(R.layout.fragment_style_select, container, false);
        ButterKnife.bind(this, frag_view);

        styleText = frag_view.findViewById(R.id.style_descr_text);
        styleTitle = frag_view.findViewById(R.id.style_title_text);

//        if ( Build.VERSION.SDK_INT >= 26 ) {
//            styleText.setJustificationMode(JUSTIFICATION_MODE_INTER_WORD);
//        }
//        else{
//
//        }

//        styleText.setText(R.string.default_descr_string);

        // Get thobes from server
        loadThobeStyles();

        // Clear previous fragments
        clearPreviousFragments();

        return frag_view;
    }

    // Load thobe styles from server
    private void loadThobeStyles(){
        progressBar.setVisibility(View.VISIBLE);
        KesaaApplication.getKesaaAPI().getThobes()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ThobeStyleListResponse>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(ThobeStyleListResponse thobeStyleListResponse) {
                        progressBar.setVisibility(View.GONE);

                        if (thobeStyleListResponse.getCode() == 200){
                            if (thobeStyleListResponse.getData() != null){
                                thobeTypeList = thobeStyleListResponse.getData().getThobes();
                                initThobeViewPager();
                            }
                        }
                        else{
                            // Show error message
                            if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                                Toast.makeText(masterActivity, thobeStyleListResponse.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(masterActivity, thobeStyleListResponse.getArabicMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(masterActivity, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }

    // Initialize ViewPager
    private void initThobeViewPager(){
//        ViewPager viewPager = frag_view.findViewById(R.id.thobe_style_viewpager);
        final ThobeStylePageAdapter pageAdapter = new ThobeStylePageAdapter(this.getContext(),thobeTypeList,this );

        ViewPager.OnPageChangeListener mPageChangeListener = new ViewPager.OnPageChangeListener() {

            @Override
            public void onPageScrollStateChanged(int arg0) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onPageScrolled(int arg0, float arg1, int arg2) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onPageSelected(int pos) {
//                Toast toast =Toast.makeText(getContext(),"Page swiped " + Integer.toString(pos),Toast.LENGTH_SHORT);
                //toast.show();

//                String styleDescription = "";
//                String styleTitleStr = "";
                selected_thobe_style = pos;

                ThobeStyleData selectedThobe = thobeTypeList.get(pos);
                selectedThobeStyle = selectedThobe;

                if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                    styleText.setText(selectedThobe.getEnglishDescription());
                    styleTitle.setText(selectedThobe.getEnglishName());
                }
                else{
                    styleText.setText(selectedThobe.getArabicDescription());
                    styleTitle.setText(selectedThobe.getArabicName());
                }


                newStyleSwiped(pos);

//                confirmStyle(confirmButton);
            }

        };

        thobeViewPager.addOnPageChangeListener(mPageChangeListener);

        Display display = getActivity().getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int width = size.x;
        int height = size.y;
        long spacer_width = (Math.round(-1 * (0.25 * width)));
        Log.d(TAG, "Width " + width);
        Log.d(TAG, "Height " + height);

        thobeViewPager.setAdapter(pageAdapter);
        thobeViewPager.setOffscreenPageLimit(thobeTypeList.size());
        thobeViewPager.setPageMargin( (int) spacer_width );

        FadePageTransformer stylePageTransformer = new FadePageTransformer();
        //com.ToxicBakery.viewpager.transforms.FlipHorizontalTransformer stylePageTransformer = new com.ToxicBakery.viewpager.transforms.FlipHorizontalTransformer();
        thobeViewPager.setPageTransformer(false, stylePageTransformer );
        LinearLayoutManager layManager = new LinearLayoutManager(this.getContext(),LinearLayoutManager.HORIZONTAL,false);


        // Select default item
        thobeViewPager.setCurrentItem(0);

        // Display the selected thobe title and description
        if (thobeTypeList.size() > 0){
            selectedThobeStyle = thobeTypeList.get(0);

            if (MyPreferenceManager.getInstance(getActivity()).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                styleText.setText(thobeTypeList.get(0).getEnglishDescription());
                styleTitle.setText(thobeTypeList.get(0).getEnglishName());
            }
            else{
                styleText.setText(thobeTypeList.get(0).getArabicDescription());
                styleTitle.setText(thobeTypeList.get(0).getArabicName());
            }
        }
    }

    public void clearPreviousFragments(){
        if (masterActivity != null && masterActivity.getSupportFragmentManager() != null){
            int backStackCount = masterActivity.getSupportFragmentManager().getBackStackEntryCount();
            if (backStackCount > 1){
                for (int entry = backStackCount - 2; entry >= 0; entry --){
                    masterActivity.getSupportFragmentManager().popBackStack(entry, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                }
            }
        }
    }


    // Selected style icon
    public void selectedStyle(View view){
        confirmStyle(view);
    }

    // Clicked confirm button
    @OnClick(R.id.btn_confirm_style) void confirmed(){
        confirmStyle(confirmButton);
    }

    private void confirmStyle(View view){
        if ( masterActivity.currentSession != null) {
            if (masterActivity.currentOrderItem != null) {

                if (masterActivity.currentOrderItem.selectedThobe != null && selectedThobeStyle != masterActivity.currentOrderItem.selectedThobe){
                    // clear previous selected options
                    masterActivity.currentOrderItem.optSelectedMap = null;
                }

                // Save the selected thobe
                masterActivity.currentOrderItem.selectedThobe = selectedThobeStyle;
                masterActivity.currentOrderItem.order_thobe_style = selected_thobe_style;

                // Set the selected size into Large
                masterActivity.currentOrderItem.order_size = 2;

                // go to customize style page
                Navigation.findNavController(view).navigate(R.id.action_styleSelectFragment_to_customizeStyleFragment);
            }
            else {
                Toast err_toast = Toast.makeText(getContext(),R.string.error_order_init,Toast.LENGTH_LONG);
                err_toast.show();
            }
        } else {
            Toast err_toast = Toast.makeText(getContext(),R.string.error_session_init,Toast.LENGTH_LONG);
            err_toast.show();
        }
    }



    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onStyleSelectFragmentInteraction("");
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public void newStyleSwiped(int style_id){

//        if (masterActivity != null) {
//            if (masterActivity.currentOrderItem != null) {
//                if (selectedThobeStyle != null){
//                    masterActivity.currentOrderItem.selectedThobe = selectedThobeStyle;
//                    masterActivity.currentOrderItem.order_thobe_style = selectedThobeStyle.getId();
//                }
//            }
//        }
    }
    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void setFragTitle(String newTitle);
        void onStyleSelectFragmentInteraction(String data);
    }
}
