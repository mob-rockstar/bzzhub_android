package com.tailor.kesaa.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RatingBar;

import com.bumptech.glide.request.RequestOptions;
import com.tailor.kesaa.R;
import com.tailor.kesaa.customs.CustomFontTextView;
import com.tailor.kesaa.model.tailor.CommentDetail;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import de.hdodenhof.circleimageview.CircleImageView;

public class TailorReviewListAdapter extends BaseAdapter {
    Context mContext;
    LayoutInflater inflater = null;
    List<CommentDetail> commentDetails;
    private RequestOptions requestOptions;

    public TailorReviewListAdapter(Context context, List<CommentDetail> comments){
        this.mContext = context;
        this.commentDetails = comments;
        this.inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        requestOptions = new RequestOptions();
        requestOptions.placeholder(R.drawable.ic_placeholder);
        requestOptions.error(R.drawable.ic_placeholder);
    }

    @Override
    public int getCount() {
        return commentDetails.size();
    }

    @Override
    public Object getItem(int position) {
        return commentDetails.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        TailorReviewHolder holder;
        if (convertView == null){
            convertView = inflater.inflate(R.layout.item_tailor_review_list, parent, false);
            holder = new TailorReviewHolder(convertView);
            convertView.setTag(holder);
        }
        else{
            holder = (TailorReviewHolder) convertView.getTag();
        }

        CommentDetail comment = commentDetails.get(position);

        // Rating
        holder.ratingBar.setRating(comment.getRating());

        // Comment
        holder.reviewText.setText(comment.getComment());

        // User name
        holder.usernameText.setText(comment.getUserName());

        // User Image

        return convertView;
    }

    static class TailorReviewHolder{
        @BindView(R.id.user_image)
        CircleImageView userImageView;

        @BindView(R.id.user_name_text)
        CustomFontTextView usernameText;

        @BindView(R.id.ratingBar)
        RatingBar ratingBar;

        @BindView(R.id.review_text)
        CustomFontTextView reviewText;

        public TailorReviewHolder(View view){
            ButterKnife.bind(this, view);
        }
    }
}
