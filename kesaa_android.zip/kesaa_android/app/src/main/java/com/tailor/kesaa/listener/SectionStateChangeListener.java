package com.tailor.kesaa.listener;

import com.tailor.kesaa.model.Section;

public interface SectionStateChangeListener{
    void onSectionStateChanged(Section section, boolean isOpen);

}
