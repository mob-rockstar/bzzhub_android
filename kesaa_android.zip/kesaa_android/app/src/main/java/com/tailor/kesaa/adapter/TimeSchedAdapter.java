package com.tailor.kesaa.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.tailor.kesaa.R;
import com.tailor.kesaa.fragment.MeasureScheduleFragment;

public class TimeSchedAdapter extends RecyclerView.Adapter<TimeSchedAdapter.TimeSchedViewHolder> {


    private Context mContext;
    public int width;
    public int height;
    public RecyclerView recyclerView;
    private ArrayList<String> timeSchedDataElements;
    public MeasureScheduleFragment msFrag;

    public TimeSchedAdapter(Context mContext, ArrayList<String> timeSchedElements, RecyclerView recyclerView, MeasureScheduleFragment mFrag) {

//        this.width = width;
//        this.height = height;
        this.mContext = mContext;
        this.timeSchedDataElements = timeSchedElements;
        this.recyclerView = recyclerView;
        this.msFrag = mFrag;
    }

    public  class TimeSchedViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        // each data item is just a string in this case
        public TextView timeText;

        @Override
        public void onClick(View view) {

            int position = getAdapterPosition();
            String tag = (String) view.getTag();
            TimeSchedAdapter.TimeSchedViewHolder holder = (TimeSchedAdapter.TimeSchedViewHolder) recyclerView.findViewHolderForAdapterPosition(position);
            if (msFrag != null) {

                msFrag.setSelectedTimeInt(position,true);
            }

        }


        public TimeSchedViewHolder(View itemView, int screen_width, int screen_height) {
            super(itemView);

            /*
            CardView baseline_card_layout = itemView.findViewById(R.id.time_sched_elem_wrapper);
            CardView.LayoutParams  lParams = (CardView.LayoutParams) baseline_card_layout.getLayoutParams();
            lParams.width = Math.round(screen_width/4);
            baseline_card_layout.setLayoutParams(lParams );
            */
            timeText = itemView.findViewById(R.id.time_sched_elem_text);
            timeText.setOnClickListener(this);

        }
    }

    @NonNull
    @Override
    public TimeSchedViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.time_sched_element, parent, false);
        return new TimeSchedViewHolder(itemView,this.width, this.height);
    }

    @Override
    public void onBindViewHolder(@NonNull TimeSchedViewHolder holder, int position) {

        if (msFrag != null) {

            if (msFrag.activeSelectedTimeInt == position) {
                holder.timeText.setText(timeSchedDataElements.get(position));
                holder.timeText.setBackgroundResource(R.drawable.green_round_corner_back);
                holder.timeText.setTextColor(Color.parseColor("#FFFFFF"));
            } else {
                holder.timeText.setText(timeSchedDataElements.get(position));
                holder.timeText.setBackgroundResource(R.drawable.white_round_corner_back);
                holder.timeText.setTextColor(Color.parseColor("#000000"));

            }

        } else {

            holder.timeText.setText(timeSchedDataElements.get(position));
            holder.timeText.setBackgroundResource(R.drawable.white_round_corner_back);
            holder.timeText.setTextColor(Color.parseColor("#000000"));

        }
    }

    @Override
    public int getItemCount() {

        return timeSchedDataElements.size();
    }





}
