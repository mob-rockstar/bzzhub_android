package com.tailor.kesaa.fragment.settings;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.tailor.kesaa.KesaaApplication;
import com.tailor.kesaa.MainActivity;
import com.tailor.kesaa.R;
import com.tailor.kesaa.adapter.FaqListAdapter;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;
import com.tailor.kesaa.model.faq.FaqDetail;
import com.tailor.kesaa.model.faq.FaqListResponse;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class FaqFragment extends Fragment {
    public MainActivity masterActivity;

//    List<String> questions = new ArrayList<>();
//    List<String> answers = new ArrayList<>();

    @BindView(R.id.faq_list)
    ListView faqListView;

    @BindView(R.id.progressBar)
    ProgressBar progressBar;

    FaqListAdapter adapter;
    List<FaqDetail> faqDetails = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_faq, container, false);
        ButterKnife.bind(this,view);


        masterActivity = (MainActivity) getActivity();
        if (masterActivity != null){
            masterActivity.showActionBar();
            masterActivity.setFragTitle(getString(R.string.faq_title));
        }

        loadFaqs();

        return view;
    }

    // load faq list from server
    private void loadFaqs(){
        progressBar.setVisibility(View.VISIBLE);
        KesaaApplication.getKesaaAPI().getFaqList()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<FaqListResponse>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(FaqListResponse faqListResponse) {
                        progressBar.setVisibility(View.GONE);
                        if (faqListResponse.getCode() == 200){
                            faqDetails.clear();
                            if (faqListResponse.getData() != null){
                                faqDetails = faqListResponse.getData().getFaqDetails();
                            }

                            // refresh faq list
                            initFaqList();
                        }
                        else{
                            // Show error message
                            if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                                Toast.makeText(masterActivity, faqListResponse.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(masterActivity, faqListResponse.getArabicMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(masterActivity, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }

    private void initFaqList(){

        adapter = new FaqListAdapter(masterActivity, faqDetails);
        faqListView.setAdapter(adapter);


    }
}
