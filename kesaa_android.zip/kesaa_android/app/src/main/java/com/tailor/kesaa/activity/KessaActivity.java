package com.tailor.kesaa.activity;

import android.content.res.Resources;
import android.util.DisplayMetrics;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class KessaActivity extends AppCompatActivity {

    // Change locale
    public void changeLocale(String localeCode, String countryCode){
        Locale locale = new Locale(localeCode, countryCode);

//        Locale.setDefault(locale);
//        Configuration config = new Configuration();
//        config.locale = locale;
//        getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());

        Resources res = getResources();

        // Change locale settings in the app.
        DisplayMetrics dm = res.getDisplayMetrics();
        android.content.res.Configuration conf = res.getConfiguration();
        conf.setLocale(locale); // API 17+ only.

        res.updateConfiguration(conf, dm);
    }
}
