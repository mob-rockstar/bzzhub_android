package com.tailor.kesaa.model;

import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class FirebaseTailorOrderRecord {

    public String trans_order_id;
    public String order_status;
    public String user_uid;

    public FirebaseTailorOrderRecord () {
        // Default constructor required for calls to DataSnapshot.getValue(User.class)
    }

    public FirebaseTailorOrderRecord (String order_id, String order_status, String user_uid) {

        this.trans_order_id = order_id;
        this.order_status = order_status;
        this.user_uid = user_uid;

    }

}