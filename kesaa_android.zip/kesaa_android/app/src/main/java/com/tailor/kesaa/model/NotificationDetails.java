package com.tailor.kesaa.model;

import java.util.Date;

public class NotificationDetails {

    private String thobeTypeList[] = {"Saudi Style" , "Emarati Style", "Bahraini Style", "Kuwaiti Style", "Omani Style", "Qatari Style"};

    public int orderThobeType;
    public int scheduleID;
    public String tailorName;
    public String thobeTypeName;
    public Date orderBookingDate;
    public Date orderCompletionDate;
    public int orderBookingTimeInterval;
    public int orderBookingStatus;
    public int measureStatus;
    public int order_id;


    public NotificationDetails(int scheduleID, String tailorName, int thisThobeType, Date thisBookingDate, int thisBookingTime, int thisBookingStatus, int measureStatus, int order_id, Date thisCompletionDate){
        this.scheduleID = scheduleID;
        this.orderThobeType = thisThobeType;
        this.tailorName = tailorName;
        this.thobeTypeName = thobeTypeList[thisThobeType];
        this.orderBookingDate = thisBookingDate;
        this.orderBookingTimeInterval = thisBookingTime;
        this.orderBookingStatus = thisBookingStatus;
        this.measureStatus = measureStatus;
        this.order_id = order_id;
        this.orderCompletionDate = thisCompletionDate;

    }

}
