package com.tailor.kesaa.global;

public class EventBusMessage {
    public static class MessageType {
        public final static int SMS_VERIFIED            = 0X01;
        public final static int LOGGED_IN               = 0X02;
        public final static int ORDER_CREATED           = 0x03;
        public final static int SIGNED_OUT              = 0x04;
        public final static int NEW_ADDRESS_CREATED     = 0x05;
        public final static int SELECTED_TAILOR         = 0x06;
        public final static int UPDATED_PROFILE         = 0x07;
        public final static int LANGUAGE_UPDATED        = 0x08;
        public final static int HYPERPAY_ASYNC_CALLBACK = 0x09;
    }

    private int messageType;
    private String message;
    private Object object;


    public EventBusMessage(int messageType, String json) {
        this.messageType = messageType;
        this.message = json;
    }

    public EventBusMessage(int messageType) {
        this.messageType = messageType;
    }

    public EventBusMessage(int messageType, Object data) {
        this.messageType = messageType;
        this.object = data;
    }

    public int getMessageType() {
        return messageType;
    }

    public void setMessageType(int messageType) {
        this.messageType = messageType;
    }


    public String getMessage() {
        return message;
    }

    public void setMessage(String json) {
        this.message = json;
    }

    public Object getObject() {
        return object;
    }

    public void setObject(Object object) {
        this.object = object;
    }

}
