package com.tailor.kesaa.fragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.tailor.kesaa.model.LocationTemplate;
import com.tailor.kesaa.MainActivity;
import com.tailor.kesaa.R;
import com.tailor.kesaa.adapter.AddressListAdapter;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link AddressListFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link AddressListFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AddressListFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private String TAG = "ADRLISTFRAG";
    public MainActivity masterActivity;
    public ArrayList<LocationTemplate> addrDetailsArray;
    private OnFragmentInteractionListener mListener;
    private Context localContext = null;
    private boolean firstPass = true;
    public ProgressBar spinner;
    public ListView addressListView;
    public View addressListMainView;

    private static AddressListAdapter addressAdapter;


    public AddressListFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AddressListFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static AddressListFragment newInstance(String param1, String param2) {
        AddressListFragment fragment = new AddressListFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);

        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        /*
        if (masterActivity == null) {
            getActivity().getSupportFragmentManager().beginTransaction().remove(this).commit();
        } else {
            masterActivity.currState = TAG;
        }
        */
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_address_list, container, false);
        masterActivity = (MainActivity) getActivity();
        TextView headerText = view.findViewById(R.id.addrHeaderText);

        addressListMainView = view;
        addressListView = view.findViewById(R.id.addr_list);


        if (mListener != null) {
            mListener.setFragTitle(getString(R.string.your_addr_title));
        }

        if (masterActivity.currentSession.currentUser.userLocations != null) {
            if (masterActivity.currentSession.currentUser.userLocations.size() >0 ) {
//                addressAdapter = new AddressListAdapter(masterActivity.currentSession.currentUser.userLocations,getContext(),this);
//                addressListView.setAdapter(addressAdapter);
//                addressAdapter.notifyDataSetChanged();
            }
        }

        localContext = view.getContext();


        Button updateAddresses = view.findViewById(R.id.update_addresses);
        updateAddresses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (masterActivity.currentSession.currentUser.defaultUserAddressIndex >=0 ) {
                    // Default Address is set -> check which mainLine path you were on and return, either to the ThobeStyle, or the MeasureSchedule screen
                    if (masterActivity.currentSession.lastMainLineScreen.contentEquals("measureSchedule")) {
                        saveCurrentAddressSetLocally();
                        Navigation.findNavController(v).navigate(R.id.action_addressListFragment_to_measureScheduleFragment);
                    }

                }  else {
                    Toast.makeText(getContext(), "Please set at least one address as default", Toast.LENGTH_SHORT).show();
                }

            }
        });



        if (masterActivity.currentSession.currentUser.userLocations == null) {
            masterActivity.currentSession.currentUser.userLocations = new ArrayList<>();
            headerText.setText(R.string.set_addr_text);
        } else {
            if (masterActivity.currentSession.currentUser.userLocations.size() == 0){
                headerText.setText(R.string.set_addr_text);
            }
        }

        // Firebase analytics event
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.SCREEN_NAME, "Select Address");
        bundle.putString(FirebaseAnalytics.Param.SCREEN_CLASS, getClass().getSimpleName());
        masterActivity.mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SCREEN_VIEW, bundle);

        return view;
    }

    public void saveCurrentAddressSetLocally(){
        //masterActivity.setSharePrefs("saved_address_string" ,masterActivity.currentSession.currentUser.convertAddressesToJSON() );
        String fullAdressString = masterActivity.currentSession.currentUser.convertAddressesToJSON();
        Log.d(TAG, fullAdressString);
        sendMySQLAddressString(fullAdressString);
    }


    public void sendMySQLAddressString(String addrString) {

        try{

            String addrArrayJStr = addrString;
            String user_id = Integer.toString(masterActivity.currentSession.currentUser.id);
            String user_uid = masterActivity.currentSession.currentUser.uid;

            String url = "http://harrierlabs.com/kessa/admin/validated/customer_control_master.php?func=10&addressJSON="+ addrArrayJStr+"&user_id="+user_id+"&user_uid="+user_uid;
            Log.d(TAG,"calling pricecontrol with" + url);

            // Instantiate the RequestQueue.
            RequestQueue queue = Volley.newRequestQueue(this.getContext());
            StringRequest sr = new StringRequest(Request.Method.GET, url,
                    new com.android.volley.Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            Log.d(TAG, "success! response: " + response.toString());
                            processInsertAddressResult(response.toString());
                        }
                    },
                    new com.android.volley.Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Log.d(TAG, "error: " + error.toString());
                        }
                    })
            {

                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String,String> params = new HashMap<String, String>();
                    params.put("Content-Type","application/x-www-form-urlencoded");
                    return params;
                }
            };
            queue.add(sr);



        } catch (Exception e ) {
            Log.d(TAG, "Addr URL encoding error");
        }
    }

    public void loadLocalAddressList() {

    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onAddressFragmentInteraction(-1);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }




    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        // TODO Add your menu entries here
        inflater.inflate(R.menu.address_add_menu,menu);
        super.onCreateOptionsMenu(menu, inflater);
    }


    // handle button activities
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.add_address_btn) {
            // do something here
            Toast.makeText(this.getContext(), "Adding New Location ", Toast.LENGTH_SHORT).show();
            //address mode = -1 implies a new address is being added
            // (if not, pass the relevant index to be edited
            if (masterActivity != null) {
                if (masterActivity.currentSession.lastMainLineScreen.contentEquals("measureSchedule") ) {
                    Navigation.findNavController(addressListMainView).navigate(R.id.action_addressListFragment_to_locationMapperFragment);
                }

            }
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        //MenuItem item = menu.findItem(R.id.action_settings);
        //item.setVisible(true);
        super.onPrepareOptionsMenu(menu);
    }

    public void adjustDefaultAddresses(int newDefault) {

        LocationTemplate currLocation;

        if (newDefault < 0) {
            newDefault = 0;
        }

        for (int i = 0 ; i < masterActivity.currentSession.currentUser.userLocations.size() ; i++) {

            currLocation = masterActivity.currentSession.currentUser.userLocations.get(i);

            if (i == newDefault){
                currLocation.defaultSet = true;
            } else {
                currLocation.defaultSet = false;
            }
            masterActivity.currentSession.currentUser.userLocations.set(i, currLocation);
        }

        updateAddressListAndNotify();
    }

    public void setDefaultCheck(){

        String savedDefaultIndex = masterActivity.getSharedPrefs("saved_address_default_index");
        if (savedDefaultIndex != null) {
            if (savedDefaultIndex.length() > 0) {
                masterActivity.currentSession.currentUser.defaultUserAddressIndex = Integer.parseInt(savedDefaultIndex);
                adjustDefaultAddresses( masterActivity.currentSession.currentUser.defaultUserAddressIndex );
                addressAdapter.notifyDataSetChanged();

            }
        }

    }



    public void updateAddressListAndNotify(){

        addrDetailsArray = new ArrayList<>();
        for (int i = 0 ; i < masterActivity.currentSession.currentUser.userLocations.size() ; i++)
        {
            addrDetailsArray.add(masterActivity.currentSession.currentUser.userLocations.get(i));
        }

        if (localContext != null)
        {
//            addressAdapter= new AddressListAdapter(addrDetailsArray,localContext,this);
//            addressListView.setAdapter(addressAdapter);
//            addressAdapter.notifyDataSetChanged();
        }

    }

    public void setBlankAddressCards(){

        LocationTemplate homeLocation = new LocationTemplate();
        LocationTemplate workLocation = new LocationTemplate();
        LocationTemplate otherLocation = new LocationTemplate();

        homeLocation.addrType = 0;
        workLocation.addrType = 1;
        otherLocation.addrType = 2;

        if (addrDetailsArray ==null) {
            addrDetailsArray = new ArrayList<>();
        }
        addrDetailsArray.add(homeLocation);
        addrDetailsArray.add(workLocation);
        addrDetailsArray.add(otherLocation);

//        addressAdapter= new AddressListAdapter(addrDetailsArray,localContext,this);
//        addressListView.setAdapter(addressAdapter);
//        addressAdapter.notifyDataSetChanged();

    }

    public void loadLocalAddressString(){


        String saved_address_string = masterActivity.getSharedPrefs("saved_address_string");
        if (saved_address_string != null) {
            if (saved_address_string.length() > 0) {

                masterActivity.currentSession.currentUser.addressJSONstr = saved_address_string;
                convertJSONtoAddr();
                updateAddressListAndNotify();

            } else {
                //setBlankAddressCards();
            }
        } else {
            //setBlankAddressCards();
        }


    }

    public void addrCardOptionClicked(String cardOpt) {
        Log.d(TAG,cardOpt + " clicked");

        String[] selectedOption = cardOpt.split("_");

        if (selectedOption.length>1)
        {
            switch (selectedOption[0]) {
                case "pic":
                    Log.d(TAG,"Pic # : " + selectedOption[1]);
                    //masterActivity.currentUser.selectedAddress = Integer.parseInt(selectedOption[1]);
                    break;
                case "data":
                    Log.d(TAG,"Data # : " + selectedOption[1]);
                    masterActivity.currentSession.currentUser.defaultUserAddressIndex = Integer.parseInt(selectedOption[1]);
                    Log.d(TAG,"Setting " + Integer.toString(masterActivity.currentSession.currentUser.defaultUserAddressIndex) + " as default");
                    adjustDefaultAddresses(masterActivity.currentSession.currentUser.defaultUserAddressIndex);

                    break;

                case "map":
                    // take them to a Location Selection screen

                    String addrLine1 = addrDetailsArray.get(Integer.parseInt(selectedOption[1])).addrLine1;
                    String addrLine2 = addrDetailsArray.get(Integer.parseInt(selectedOption[1])).addrLine2;
                    int addrType = addrDetailsArray.get(Integer.parseInt(selectedOption[1])).addrType;
                    String city = addrDetailsArray.get(Integer.parseInt(selectedOption[1])).city;
                    String region = addrDetailsArray.get(Integer.parseInt(selectedOption[1])).region;
                    String zipCode = addrDetailsArray.get(Integer.parseInt(selectedOption[1])).zipCode;
                    String addr_phone = addrDetailsArray.get(Integer.parseInt(selectedOption[1])).addr_phone;


                    //pick this ps
                   // Log.d(TAG,"Price # : " + selectedOption[1] + " from tailorID " + Integer.toString(selectedTailorID));
                    //mListener.onTailorListFragmentInteraction("pay");

                    break;
            }
        }
    }


    public void convertJSONtoAddr() {

        masterActivity.currentSession.currentUser.userLocations = new ArrayList<>();

        try {

            JSONArray addrJSONarr = new JSONArray(masterActivity.currentSession.currentUser.addressJSONstr);

            for (int i = 0; i < addrJSONarr.length(); i++) {

                LocationTemplate currLocation = new LocationTemplate();

                try {

                    Log.d(TAG, "convertJSONtoArray");

                    JSONObject currAddr = new JSONObject();
                    currAddr = (JSONObject) addrJSONarr.get(i);

                    Double latitude, longitude;

                    currLocation.unitNum = currAddr.get("unitNum").toString();
                    currLocation.addrLine1 = currAddr.get("addrLine1").toString();
                    currLocation.addrLine2 = currAddr.get("addrLine2").toString();
                    currLocation.city = currAddr.get("city").toString();
                    currLocation.region = currAddr.get("region").toString();
                    currLocation.zipCode = currAddr.get("zipCode").toString();
                    currLocation.addrType = Integer.parseInt(currAddr.get("addrType").toString());
                    latitude = Double.parseDouble(currAddr.get("lat").toString());
                    longitude = Double.parseDouble(currAddr.get("long").toString());
                    currLocation.latLng = new LatLng(latitude,longitude);

                    masterActivity.currentSession.currentUser.userLocations.add(currLocation);
                    //Log.d(TAG, "Reconvert" + currAddr.get("unitNum").toString());

                } catch (Exception e) {
                    Log.d(TAG, "Error converting single JSONObect ");
                }

            }

            addressAdapter.notifyDataSetChanged();

        }catch(Exception e){
            Log.d(TAG, "Error in conversion of JSON to addr array");
        }
    }


    public void checkPushAddressesToServer(){

        masterActivity.setSharePrefs("saved_address_string" ,masterActivity.currentSession.currentUser.convertAddressesToJSON() );
        masterActivity.setSharePrefs("saved_address_default_index", Integer.toString(masterActivity.currentSession.currentUser.defaultUserAddressIndex));

        if (!masterActivity.currentSession.currentUser.userAddressesUpdatedOnServer && (masterActivity.currentSession.currentUser.userLocations != null))  {
            if (masterActivity.currentSession.currentUser.userLocations.size() > 0) {
                //first save the addresses in localSharedPrefs
                sendMySQLAddressString();
            }
        }

    }





    public void processInsertAddressResult(String incomingStr) {

        convertJSONtoAddr();

        try {

            JSONArray jArray = new JSONArray(incomingStr);
            Log.d(TAG, Integer.toString(jArray.length()));
            for (int arr_elem = 0 ; arr_elem < jArray.length() ; arr_elem++)
            {
                JSONObject explrObject = jArray.getJSONObject(arr_elem);
                Log.d(TAG, explrObject.toString());
                Log.d(TAG, Integer.toString(arr_elem));


            }
            Log.d(TAG, "past the loop");


            if (spinner != null) {
                spinner.setVisibility(View.GONE);
            }




        } catch (Throwable t) {

            Log.e("MEASURESCHED", "Could not parse malformed JSONArray: \"" + t.getMessage() + "\"");
        }


    }



    public void sendMySQLAddressString() {



        try{

            String addrArrayJStr = URLEncoder.encode(masterActivity.currentSession.currentUser.convertAddressesToJSON(),"UTF-8");
            String user_id = Integer.toString(masterActivity.currentSession.currentUser.id);
            String user_uid = masterActivity.currentSession.currentUser.uid;

            String url = "http://harrierlabs.com/kessa/admin/production/customer_control_master.php?func=10&addressJSON="+ addrArrayJStr+"&user_id="+user_id+"&user_uid="+user_uid;
            Log.d(TAG,"calling pricecontrol with" + url);

            // Instantiate the RequestQueue.
            RequestQueue queue = Volley.newRequestQueue(this.getContext());
            StringRequest sr = new StringRequest(Request.Method.GET, url,
                    new com.android.volley.Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            Log.d(TAG, "success! response: " + response.toString());
                            processInsertAddressResult(response.toString());
                        }
                    },
                    new com.android.volley.Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Log.d(TAG, "error: " + error.toString());
                        }
                    })
            {

                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String,String> params = new HashMap<String, String>();
                    params.put("Content-Type","application/x-www-form-urlencoded");
                    return params;
                }
            };
            queue.add(sr);



        } catch (Exception e ) {
            Log.d(TAG, "Addr URL encoding error");
        }





    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void setFragTitle(String newTitle);
        void onAddressFragmentInteraction(int addressMode);
    }
}
