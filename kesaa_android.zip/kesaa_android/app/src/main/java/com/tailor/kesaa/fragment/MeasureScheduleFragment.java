package com.tailor.kesaa.fragment;

import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bigkoo.pickerview.builder.OptionsPickerBuilder;
import com.bigkoo.pickerview.listener.OnOptionsSelectChangeListener;
import com.bigkoo.pickerview.listener.OnOptionsSelectListener;
import com.bigkoo.pickerview.view.OptionsPickerView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.tailor.kesaa.KesaaApplication;
import com.tailor.kesaa.customs.CustomFontButton;
import com.tailor.kesaa.customs.CustomFontEditText;
import com.tailor.kesaa.customs.CustomFontTextView;
import com.tailor.kesaa.customs.MySpinner;
import com.tailor.kesaa.global.AllHelpers;
import com.tailor.kesaa.MainActivity;
import com.tailor.kesaa.R;
import com.tailor.kesaa.adapter.TimeSchedAdapter;
import com.tailor.kesaa.global.MyDayBgDecorator;
import com.tailor.kesaa.global.MyDayDecorator;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;
import com.tailor.kesaa.global.Utils;
import com.tailor.kesaa.model.ActiveSession;
import com.tailor.kesaa.model.AddressData;
import com.tailor.kesaa.model.AddressListData;
import com.tailor.kesaa.model.WeekDayDetails;
import com.tailor.kesaa.adapter.WeekDayRecycleAdapter;
import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.MaterialCalendarView;
import com.prolificinteractive.materialcalendarview.OnDateSelectedListener;


import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link MeasureScheduleFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link MeasureScheduleFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class MeasureScheduleFragment extends Fragment implements AdapterView.OnItemSelectedListener {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    public String TAG = "SCHED_FRAG";

    public MainActivity masterActivity;
    private OptionsPickerView customCalendarOptions;

    final ArrayList<String> yearOptions = new ArrayList<String>();
    final ArrayList<ArrayList<String>> yearMonthOptions = new ArrayList<>();
    final ArrayList<ArrayList<ArrayList<String>>> yearMonthDayOptions = new ArrayList<ArrayList<ArrayList<String>>>();


    public static final int numYears = 2;
    public int num_months_first_year = -1;
    public int num_months_second_year = -1;

    // Time slots
    public ArrayList<String> availableTimeIntervalsStr = new ArrayList<String>();
    public ArrayList<Integer> availableTimeIntervalsPos = new ArrayList<>();

    private List<Integer> allTimeslots = new ArrayList<>();

    public ArrayList<String> thisYearMonths = new ArrayList<String>();
    public ArrayList<String> nextYearMonths = new ArrayList<String>();

    public ArrayList<Integer> thisYearMonthsInt = new ArrayList<Integer>();
    public ArrayList<Integer> nextYearMonthsInt = new ArrayList<Integer>();

    public RecyclerView timeSchedule;
    public RecyclerView.Adapter timeScheduleAdapter;
    public RecyclerView.LayoutManager timeSchedLayoutManager;
    public int activeSelectedTimeInt = -1;

    public RecyclerView dateSchedule;
    public WeekDayRecycleAdapter dateScheduleAdapter;
    public RecyclerView.LayoutManager dateSchedLayoutManager;

    public ArrayList<WeekDayDetails> weekDayArray= new ArrayList<>();

    public MySpinner addressSpinner;
    public TextView activeMonthYearHeader;

    // Address list
    List<String> addressItems = new ArrayList<>();

    // Selected measurement date
    public Date selectedDate;

    public boolean blockedDatesLoaded = false;
    public boolean userSelectedDate = false;

    //public ArrayList[] monthDays = new ArrayList[12];
    public ArrayList<ArrayList<String>> monthDays = new ArrayList<ArrayList<String>>(12);


    private OnFragmentInteractionListener mListener;

    @BindView(R.id.address_layout)
    RelativeLayout addressLayout;

    @BindView(R.id.location_layout)
    RelativeLayout locationLayout;

    @BindView(R.id.calendarView)
    MaterialCalendarView calendarView;

    @BindView(R.id.btn_confirm_schedule)
    CustomFontButton confirmButton;


    @BindView(R.id.sched_add_address_btn)
    ImageButton addAddressButton;

    // Progress Bar
    @BindView(R.id.progressBar)
    ProgressBar progressBar;

    // Delivery instructions
    @BindView(R.id.delivery_instructions_text)
    CustomFontEditText deliveryInstructionsText;

    // Selected order address
    AddressData selectedOrderAddress = null;

    @BindView(R.id.no_address_text)
    CustomFontTextView noAddressText;

    public MeasureScheduleFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment MeasureScheduleFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static MeasureScheduleFragment newInstance(String param1, String param2) {
        MeasureScheduleFragment fragment = new MeasureScheduleFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        masterActivity = (MainActivity) getActivity();
        if (masterActivity != null){
            masterActivity.showActionBar();
            masterActivity.setFragTitle(getString(R.string.meas_sched_title));

            // Firebase analytics event
            Bundle bundle = new Bundle();
            bundle.putString(FirebaseAnalytics.Param.SCREEN_NAME, "Schedule Appointment");
            bundle.putString(FirebaseAnalytics.Param.SCREEN_CLASS, getClass().getSimpleName());
            masterActivity.mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SCREEN_VIEW, bundle);
        }


        masterActivity.currentSession.lastMainLineScreen ="measureSchedule";
        // Inflate the layout for this fragment
        View frag_view = inflater.inflate(R.layout.fragment_measure_schedule, container, false);
        ButterKnife.bind(this, frag_view);


        // Save current selected date
//        selectedDate = Calendar.getInstance().getTime();
//        masterActivity.currentSession.user_has_selected_date = true;

        if (MyPreferenceManager.getInstance(getActivity()).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
            addressLayout.setBackgroundResource(R.drawable.half_round_grey_spinner_back);
            locationLayout.setBackgroundResource(R.drawable.half_round_gold_button_back);
        }
        else {
            addressLayout.setBackgroundResource(R.drawable.half_round_grey_spinner_back_ar);
            locationLayout.setBackgroundResource(R.drawable.half_round_gold_button_back_ar);
        }

        addressSpinner = frag_view.findViewById(R.id.sched_address_spinner);

        weekDayArray = new ArrayList<>();

        if (masterActivity.currentSession.filledSchedList == null)
            masterActivity.currentSession.filledSchedList = new HashMap<Date, ArrayList<Integer>>();


        activeMonthYearHeader = frag_view.findViewById(R.id.measure_date_month_year_tv);

        // Time Slots
        timeSchedule = frag_view.findViewById(R.id.time_schedule_recyler);
        timeSchedule.setHasFixedSize(true);
        timeSchedLayoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
        timeSchedule.setLayoutManager(timeSchedLayoutManager);

        timeScheduleAdapter = new TimeSchedAdapter(getContext(), availableTimeIntervalsStr, timeSchedule, this );
        timeSchedule.setAdapter(timeScheduleAdapter);
        timeScheduleAdapter.notifyDataSetChanged();

        // Calendar
        dateSchedule = frag_view.findViewById(R.id.dateSchedulerRecycler);
        dateSchedule.setHasFixedSize(true);
        dateSchedLayoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
        dateSchedule.setLayoutManager(dateSchedLayoutManager);


        dateScheduleAdapter = new WeekDayRecycleAdapter(dateSchedule, weekDayArray,this, masterActivity.master_screen_width,masterActivity.master_screen_height,getContext());
        dateSchedule.setAdapter(dateScheduleAdapter);
        dateScheduleAdapter.notifyDataSetChanged();

        ConstraintLayout dateLayout = frag_view.findViewById(R.id.sched_date_layout);

        dateLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                customCalendarOptions.show();
            }
        });

        // Initialize the calendar view
        initCalendarView();

        // Load address list
        loadAddressSpinner();

        return frag_view;
    }

    // Initialize the Calendar View
    private void initCalendarView(){
        calendarView.setDynamicHeightEnabled(true);

        // Set decorator
        calendarView.addDecorator(new MyDayDecorator(masterActivity));
//        calendarView.addDecorator(new MyDayBgDecorator(masterActivity));

        // set minimum date
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        int currentMonth = Calendar.getInstance().get(Calendar.MONTH) + 1;
        int currentDay = Calendar.getInstance().get(Calendar.DAY_OF_MONTH) + 1;

        // Check day
        if (currentMonth == 2){
            if (currentYear % 4 == 0){
                if (currentDay > 29){
                    currentDay = 1;
                    currentMonth = currentMonth + 1;
                }
            }
            else{
                if (currentDay > 28) {
                    currentDay = 1;
                    currentMonth = currentMonth + 1;
                }
            }
        }
        else if (currentMonth == 4 || currentMonth == 6 || currentMonth == 9 || currentMonth == 11){
            if (currentDay > 30) {
                currentDay = 1;
                currentMonth = currentMonth + 1;
            }
        }
        else {
            if (currentDay > 31) {
                currentDay = 1;

                currentMonth = currentMonth + 1;

            }
        }

        // Check month
        if (currentMonth > 12) {
            currentMonth = 1;
            currentYear = currentYear + 1;
        }

        // Set the minimum available date in calendar
        calendarView.state().edit().setMinimumDate(CalendarDay.from(currentYear, currentMonth, currentDay)).commit();

        // Select the current date
        CalendarDay defaultDate = CalendarDay.from(Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH) + 1, Calendar.getInstance().get(Calendar.DAY_OF_MONTH));


        // Set DateSelectedListener
        calendarView.setOnDateChangedListener(new OnDateSelectedListener() {
            @Override
            public void onDateSelected(@NonNull MaterialCalendarView materialCalendarView, @NonNull CalendarDay calendarDay, boolean b) {
                int selectedYear = calendarDay.getYear();
                int selectedMonth = calendarDay.getMonth();
                int selectedDay = calendarDay.getDay();

                Calendar calendar = Calendar.getInstance();
                // check if user selected current date
                if (selectedYear == calendar.get(Calendar.YEAR) && selectedMonth == calendar.get(Calendar.MONTH) + 1 && selectedDay == calendar.get(Calendar.DAY_OF_MONTH)) {
                    Log.d(TAG, "Can't select today");
                }
                else{
                    calendar.set(selectedYear, selectedMonth - 1, selectedDay);

                    // Remove the previous date background
                    if (selectedDate != null){
                        calendarView.addDecorator(new MyDayBgDecorator(masterActivity, getCalendarDate(selectedDate), true));
                    }

                    selectedDate = calendar.getTime();
                    userSelectedDate = true;
                    masterActivity.currentSession.measure_date = selectedDate;
                    calendarView.addDecorator(new MyDayBgDecorator(masterActivity, getCalendarDate(selectedDate), false));
                    ActiveSession.getInstance().user_has_selected_date = true;

                    masterActivity.currentSession.user_has_selected_time = false;
                    masterActivity.currentSession.measure_time_interval = -1;

                    // Get available timeslots
                    loadTimeslots(AllHelpers.dateToStr(selectedDate, "yyyy-MM-dd"));
                }

                Log.d(TAG, "*** Selected date string : " + AllHelpers.dateToStr(selectedDate));
                Log.d(TAG, "*** Selected date string : " + AllHelpers.dateToStr(selectedDate, "yyyy-MM-dd"));
            }
        });

        // set header locale
        int currentLngCode = MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE);
        calendarView.setTitleFormatter(day -> {
            Locale locale;
            if (currentLngCode == SettingsKeys.KEY_ENGLISH){
                locale = new Locale("en");
            }
            else{
                locale = new Locale("ar");
            }

            DateFormat dateFormat = new SimpleDateFormat("MMMM yyyy", locale);

            Date currentDate = new GregorianCalendar(day.getYear(), day.getMonth() - 1, day.getDay()).getTime();
            return dateFormat.format(currentDate);
        });

        // Get time slots of default selected date
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        Date tomorrow = calendar.getTime();


        if (masterActivity.currentSession.measure_date != null){
            selectedDate =  masterActivity.currentSession.measure_date;
            userSelectedDate = true;
        }
        else{
            // Set the default date
            selectedDate = tomorrow;
            userSelectedDate = true;
            masterActivity.currentSession.measure_date = selectedDate;
        }

        setDefaultDateInCalendar(selectedDate);

        // Select the previous selected time
        if (masterActivity.currentSession.user_has_selected_time) {

            if (allTimeslots.size() > 0){
                int position = allTimeslots.indexOf(masterActivity.currentSession.measure_time_interval);
                if (position >= 0){
                    activeSelectedTimeInt = position;
                    setSelectedTimeInt(position, false);
                }
            }
        }

        // Load the available time slots
        if (selectedDate != null){
            loadTimeslots(AllHelpers.dateToStr(selectedDate, "yyyy-MM-dd"));
        }
        else{
            loadTimeslots(AllHelpers.dateToStr(tomorrow, "yyyy-MM-dd"));
        }

    }

    private CalendarDay getCalendarDate(Date convertDate){
        Calendar cal = Calendar.getInstance();
        cal.setTime(selectedDate);

        CalendarDay calendarDate = CalendarDay.from(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH));

        return calendarDate;
    }

    // Convert date into local date
    public void setDefaultDateInCalendar(Date selectedDate) {

        CalendarDay defaultDate = getCalendarDate(selectedDate);
        calendarView.setSelectedDate(defaultDate);
        calendarView.addDecorator(new MyDayBgDecorator(masterActivity, defaultDate, false));
    }

    // Load time stamps depending on selected date
    private void loadTimeslots(String dateString){
        activeSelectedTimeInt = -1;

        progressBar.setVisibility(View.VISIBLE);
        KesaaApplication.getKesaaAPI().getTimeSlots(dateString)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<JsonObject>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(JsonObject jsonObject) {
                        progressBar.setVisibility(View.GONE);

                        if (jsonObject.get("code").getAsInt() == 200){
                            availableTimeIntervalsStr.clear();
                            allTimeslots.clear();

                            JsonObject timeslotJson = jsonObject.getAsJsonObject("data");


                            if (timeslotJson != null){
                                // Id
                                if (timeslotJson.get("id") != null){
                                    masterActivity.currentSession.timeSlotId = timeslotJson.get("id").getAsInt();
                                }

                                // Timeslots array
                                if (timeslotJson.get("slots") != null){
                                    JsonArray timeslots = timeslotJson.get("slots").getAsJsonArray();
                                    if (timeslots != null){

                                        int slotCount = timeslots.size();

                                        for (int idx = 0; idx < slotCount; idx++){
                                            int slotValue = timeslots.get(idx).getAsInt();
                                            allTimeslots.add(slotValue);
                                            String slotStr = slotValue + ":00";

                                            availableTimeIntervalsStr.add(slotStr);
                                        }
                                    }
                                }
                            }

                            // Select the previous selected time
                            if (masterActivity.currentSession.user_has_selected_time) {
                                if (allTimeslots.size() > 0){
                                    int position = allTimeslots.indexOf(masterActivity.currentSession.measure_time_interval);
                                    if (position >= 0){
                                        activeSelectedTimeInt = position;
                                    }
                                }
                            }

                            // Refresh time slots
                            timeScheduleAdapter.notifyDataSetChanged();
                        }
                        else{
                            // Show error message
                            if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                                Toast.makeText(masterActivity, jsonObject.get("message").getAsString(), Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(masterActivity, jsonObject.get("arabicMessage").getAsString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(masterActivity, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }

    // Add new address
    @OnClick(R.id.sched_add_address_btn) void addNewAddress(){
        locationButtonClicked(addAddressButton);
    }

    // Confirm schedule
    @OnClick(R.id.btn_confirm_schedule) void confirmSchedule(){
        if (checkAllValuesSet()) {
            if (selectedOrderAddress == null){
                Toast.makeText(getContext(), R.string.select_your_address, Toast.LENGTH_SHORT).show();
            }
            else{
                if (masterActivity.currentOrderItem != null){
                    masterActivity.currentOrderItem.orderDeliveryInstructions = deliveryInstructionsText.getText().toString().trim();
                }

                ActiveSession.getInstance().currentUser.currOrderAddress = selectedOrderAddress;
                Navigation.findNavController(confirmButton).navigate(R.id.action_measureScheduleFragment_to_tailorListFragment);
            }

        } else {
            Toast.makeText(getContext(), R.string.sched_values_not_set, Toast.LENGTH_SHORT).show();
        }
    }

    public boolean checkAllValuesSet(){

        boolean allValsSet = true;

        if (!userSelectedDate) {
            allValsSet = false;
        }

        if (activeSelectedTimeInt < 0) {
            allValsSet = false;
        }

        /*
        if (masterActivity.currentSession.currentUser.defaultUserAddressIndex <0 ){
            allValsSet = false;
        }
        */

        return allValsSet;

    }

    public void loadSelectedAvailableTimeIntervals() {

        if (blockedDatesLoaded) {
            Log.d(TAG, "Loading Time ints again for : " + AllHelpers.dateToStr(selectedDate));
            if (masterActivity.currentSession.filledSchedList.containsKey(selectedDate)) {
                // fucking Java - increment by one month for zero offset date here
                Calendar c = Calendar.getInstance();
                c.setTime(selectedDate);
                c.add(Calendar.MONTH, 1);
                Date selected_date_with_shifted_month =  c.getTime();

                ArrayList<Integer> blockedInts = masterActivity.currentSession.filledSchedList.get(selectedDate);
                Log.d(TAG, "Key found with  " + Integer.toString(blockedInts.size()) + " entries");
                availableTimeIntervalsPos.clear();
                availableTimeIntervalsStr.clear();

                        for (int i = 0; i < AllHelpers.timeIntervalShortStr.length ; i++) {

                            if (!blockedInts.contains(i)) {
                                availableTimeIntervalsPos.add(i);
                                availableTimeIntervalsStr.add(AllHelpers.timeIntervalShortStr[i]);
                            }

                        }

                        timeScheduleAdapter.notifyDataSetChanged();

            }

        }  else {

            availableTimeIntervalsPos.clear();
            availableTimeIntervalsStr.clear();

            for (int i = 0; i < AllHelpers.timeIntervalShortStr.length ; i++) {
                availableTimeIntervalsPos.add(i);
                availableTimeIntervalsStr.add(AllHelpers.timeIntervalShortStr[i]);

            }

        }
    }

    // Load all address
    public void loadAddressSpinner(){
        if (masterActivity != null && !Utils.isNetworkConnected(masterActivity)){
            Toast.makeText(masterActivity, getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
            return;
        }

        // load address list
        KesaaApplication.getKesaaAPI().getAddressList(String.valueOf(ActiveSession.getInstance().currentUser.id))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<AddressListData>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(AddressListData response) {
                        progressBar.setVisibility(View.GONE);
                        Log.d(TAG, "Address List Response: " + response.toString());

                        if (response.getCode() == 200){
                            List<AddressData> addressArray = response.getData().getAddresses();
                            if (addressArray != null){
                                ActiveSession.getInstance().currentUser.addressList = addressArray;

                                // Init address spinner
                                initAddressSpinner();
                            }
                        }
                        else{
                            // Show error message
                            if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                                Toast.makeText(getActivity(), response.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(getActivity(), response.getArabicMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(getContext(), e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                        Log.d(TAG, "Address List Error: " + e.getLocalizedMessage());

                        // Init address spinner
                        initAddressSpinner();
                    }

                    @Override
                    public void onComplete() {

                    }
                });


    }

    // Initialize the address spinner
    private void initAddressSpinner(){
        try{
            addressItems.clear();

            int defaultSelection = -1;
            if (masterActivity != null) {
                int addressCount = masterActivity.currentSession.currentUser.addressList.size();
                if (addressCount > 0) {
                    for(int i =0; i < addressCount; i++ ) {

                        String curr_addr_string;
                        int type = masterActivity.currentSession.currentUser.addressList.get(i).getAddrType();
                        if (type == 0)
                        {
                            curr_addr_string = masterActivity.currentSession.currentUser.addressList.get(i).getAddrLine1() + "( " +  getString(R.string.home_address) + " )"; //getString(R.string.home_address);
                        }
                        else if (type == 1) {
                            curr_addr_string = masterActivity.currentSession.currentUser.addressList.get(i).getAddrLine1() + "( " + getString(R.string.work_address) + " )"; //"Work : " + masterActivity.currentSession.currentUser.addressList.get(i).getAddrLine1();
                        }
                        else if (type == 2) {
                            curr_addr_string = masterActivity.currentSession.currentUser.addressList.get(i).getAddrLine1() + "( " + getString(R.string.other_address) + " )"; // "Other : " + masterActivity.currentSession.currentUser.addressList.get(i).getAddrLine1();
                        }
                        else {
                            curr_addr_string = "";
                        }

                        addressItems.add(curr_addr_string);

                        if (masterActivity.currentSession.currentUser.addressList.get(i).getIsDefault() == 1){
                            masterActivity.currentSession.currentUser.defaultUserAddressIndex = i;
                        }
                    }

                    if (masterActivity.currentSession.currentUser.defaultUserAddressIndex >= 0) {
                        defaultSelection = masterActivity.currentSession.currentUser.defaultUserAddressIndex;
                    }

                }
            }


            if (addressItems.size() == 0){
                addressSpinner.setVisibility(View.GONE);
                noAddressText.setVisibility(View.VISIBLE);

                noAddressText.setText(getString(R.string.add_new_address));
            }
            else{
                addressItems.add(getString(R.string.select_your_address));

                addressSpinner.setVisibility(View.VISIBLE);
                noAddressText.setVisibility(View.GONE);
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(), R.layout.address_spinner_item, addressItems) {
                @Override
                public int getCount() {
                    // don't display last item. It is used as hint.
                    int count = super.getCount();
                    return count > 0 ? count - 1 : count;
                }
            };


            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

            // Set adapter
            addressSpinner.setAdapter(adapter);
            addressSpinner.setOnItemSelectedEvenIfUnchangedListener(this);

            // Show hint text
            if (defaultSelection >= 0) {
                addressSpinner.setSelection(defaultSelection);
            } else {
                addressSpinner.setSelection(adapter.getCount());
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    // Address Spinner ItemClickListener
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String item = addressItems.get(position);
        Log.d(TAG, "selected address : item");

        if (!item.isEmpty() && !item.equals(" ")){
            if (position < ActiveSession.getInstance().currentUser.addressList.size())
                selectedOrderAddress = ActiveSession.getInstance().currentUser.addressList.get(position);
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    // Pick the current location
    public void locationButtonClicked(View view){

        // if you have saved locations, go to the address list fragment, if not go to the Location Mapper Fragment

        Bundle bundle = new Bundle();
        bundle.putBoolean("isFromAddressList", false);

        if (masterActivity.currentSession.currentUser.addressList.size() == 0) {
            //Navigation.findNavController(view).navigate(R.id.action_measureScheduleFragment_to_addrListFragment);

            Navigation.findNavController(view).navigate(R.id.action_measureScheduleFragment_to_locationMapperFragment, bundle);
        }
        else {

            if (masterActivity.currentSession.currentUser.userLocations.size() == 0) {
                //Navigation.findNavController(view).navigate(R.id.action_measureScheduleFragment_to_addrListFragment);
                Navigation.findNavController(view).navigate(R.id.action_measureScheduleFragment_to_locationMapperFragment, bundle);
            }
            else  {
                Navigation.findNavController(view).navigate(R.id.action_measureScheduleFragment_to_addrListFragment);
            }

        }

    }

    public void setYearMonth() {

        // Have to use the stupid old style date class or assume Android >= Oreo

        // Pre
        Date tomorrow = new Date();
        Date one_year_ahead = new Date();

        Calendar c = Calendar.getInstance();
        c.setTime(tomorrow);
        int startingMonth = c.get(Calendar.MONTH);
        c.add(Calendar.DATE, 1);
        tomorrow = c.getTime();
        int active_year = c.get(Calendar.YEAR);

        c.add(Calendar.DATE, 365);
        one_year_ahead = c.getTime();
        int endingMonth = c.get(Calendar.MONTH);


        //Fill the years
        yearOptions.add(Integer.toString(active_year));
        yearOptions.add(Integer.toString(active_year + 1));


        // Fill the months


        for (int i = 0; i < 12; i++) {

            int curr_active_month = (i + startingMonth) % 12;

            if (i + startingMonth <= 11) {
                //c.set(active_year,curr_active_month,1);
                thisYearMonths.add(AllHelpers.monthNames[curr_active_month]);
                thisYearMonthsInt.add(i);
            } else {
                nextYearMonths.add(AllHelpers.monthNames[curr_active_month]);
                nextYearMonthsInt.add(i);
                //c.set(active_year+1,curr_active_month,1);
            }

            //int max_num_days = c.getActualMaximum(Calendar.DAY_OF_MONTH);
        }

        num_months_first_year = thisYearMonths.size();
        num_months_second_year = nextYearMonths.size();

        yearMonthOptions.add(thisYearMonths);
        yearMonthOptions.add(nextYearMonths);

        setActiveDays();

    }
    public void setActiveDays(){

        int startMonthIndex = thisYearMonthsInt.get(0);

        for(int month_index = 0; month_index < 12 ; month_index++ ) {
            ArrayList<String> currMonthDays = new ArrayList<>();

            for(int day_index =1 ; day_index <= 31; day_index++)
            {
                if ((month_index == 1) && (day_index >29)) {
                    //don't add Feb extras
                } else {
                    currMonthDays.add(Integer.toString(day_index));
                }

            }

            monthDays.add(month_index,currMonthDays);
        }

        int first_year_start_month = startMonthIndex;
        int first_year_end_month = 11;
        int second_year_start_month = 0;
        int second_year_end_month = (11-startMonthIndex);


        ArrayList<ArrayList<String>> firstYearMonthWrapper = new ArrayList<ArrayList<String>>();
        ArrayList<ArrayList<String>> secondYearMonthWrapper = new ArrayList<ArrayList<String>>();



        for (int first_year_counter = first_year_start_month; first_year_counter <= first_year_end_month ; first_year_counter++) {

            firstYearMonthWrapper.add(monthDays.get(first_year_counter));

        }

        for (int second_year_counter = second_year_start_month; second_year_counter <= second_year_end_month ; second_year_counter++) {
            secondYearMonthWrapper.add(monthDays.get(second_year_counter));
        }

        yearMonthDayOptions.add(firstYearMonthWrapper);
        yearMonthDayOptions.add(secondYearMonthWrapper);
        updateCalendarPicker();

    }
    void fillWeekArray(ArrayList<Date> prev_days, ArrayList<Date> next_days){
        //prev_days from 2 to 0 and next_days from 0 to 2

        if ((prev_days.size() >= 3) && (next_days.size()>=4 )) {

            weekDayArray.clear();

            for (int i = 0 ; i<3 ; i++) {
                Date current_date = prev_days.get(2-i);
                Calendar cal = Calendar.getInstance();
                cal.setTime(current_date);
                int day_int =  cal.get(Calendar.DAY_OF_MONTH);
                int weekday_int =   cal.get(Calendar.DAY_OF_WEEK);
                String weekday_str = String.format("%ta", cal);

                WeekDayDetails insert_day = new WeekDayDetails();
                insert_day.dayDate = day_int;

                insert_day.dayName = weekday_str;
                weekDayArray.add(insert_day);
            }

            for (int i = 0 ; i<4 ; i++) {
                Date current_date = next_days.get(i);
                Calendar cal = Calendar.getInstance();
                cal.setTime(current_date);
                int day_int =  cal.get(Calendar.DAY_OF_MONTH);
                int weekday_int =   cal.get(Calendar.DAY_OF_WEEK);
                String weekday_str = String.format("%ta", cal);

                WeekDayDetails insert_day = new WeekDayDetails();
                insert_day.dayDate = day_int;
                insert_day.dayName = weekday_str;
                weekDayArray.add(insert_day);
            }

            dateScheduleAdapter.notifyDataSetChanged();
            loadSelectedAvailableTimeIntervals();

        }

    }
    void setWeekDisplayRange(){
        // check the day before selected Date

        ArrayList<Date> prev_days = new ArrayList<>();
        ArrayList<Date> next_days = new ArrayList<>();
        Calendar cal = Calendar.getInstance();
        cal.setTime(selectedDate);

        while (prev_days.size() <3) {
            cal.add(Calendar.DATE, -1);

            Date active_prev_day = cal.getTime();
            cal.setTime(active_prev_day);
            if (masterActivity.currentSession.filledSchedList != null ){
                if (masterActivity.currentSession.filledSchedList.containsKey(active_prev_day)) {
                    ArrayList<Integer> bookedSlots = masterActivity.currentSession.filledSchedList.get(active_prev_day);
                    if (bookedSlots.size() <= 15 ) {
                        prev_days.add(active_prev_day);
                    }
                } else {
                    prev_days.add(active_prev_day);
                }

            } else {
                prev_days.add(active_prev_day);
            }
        }
        next_days.add(selectedDate);

        cal.setTime(selectedDate);
        while (next_days.size() <4) {
            cal.add(Calendar.DATE, 1);

            Date active_next_day = cal.getTime();
            cal.setTime(active_next_day);
            if (masterActivity.currentSession.filledSchedList.containsKey(active_next_day)) {
                ArrayList<Integer> bookedSlots = masterActivity.currentSession.filledSchedList.get(active_next_day);
                if (bookedSlots.size() <= 15 ) {
                    next_days.add(active_next_day);
                }
            } else {
                next_days.add(active_next_day);
            }
        }
        fillWeekArray(prev_days,next_days);
       // Log.d(TAG,"Prev "+ Integer.toString(prev_days.size()) + " Next " + Integer.toString(next_days.size()));
        //Log.d(TAG,"Prev "+ AllHelpers.dateToStr(prev_days.get(0)) + " Next " + AllHelpers.dateToStr(next_days.get(0))  );


    }

    public void initDefaultDay(){

        Calendar cal = Calendar.getInstance();
        if (masterActivity.currentSession.user_has_selected_date)
        {
            cal.setTime(masterActivity.currentSession.measure_date);
        } else {
            cal.add(Calendar.DATE, 1);
        }

        selectedDate =  cal.getTime();
        String year = Integer.toString(cal.get(Calendar.YEAR));
        String month = AllHelpers.monthNames[cal.get(Calendar.MONTH)]; //Integer.toString(cal.get(Calendar.MONTH)+1);
        String day = Integer.toString(cal.get(Calendar.DATE));
        setSelectedDate(year,month,day);

        loadSelectedAvailableTimeIntervals();

        if (masterActivity.currentSession.user_has_selected_time) {
            activeSelectedTimeInt = masterActivity.currentSession.measure_time_interval;
            loadSelectedAvailableTimeIntervals();
            setSelectedTimeInt(masterActivity.currentSession.measure_time_interval, false);
        }


    }

    // Called whenever user selected time slot
    public void setSelectedTimeInt(int position, boolean calledByAdapter) {

        if ((activeSelectedTimeInt == position) && (calledByAdapter)) {
            activeSelectedTimeInt = -1;
            masterActivity.currentSession.user_has_selected_time = false;
            masterActivity.currentSession.measure_time_interval = -1;
        }
        else {
            String selectedTimeString = availableTimeIntervalsStr.get(position);
            int actual_time_index = position; //AllHelpers.findActualTimeIntervalIndex(selectedTimeString);
            activeSelectedTimeInt = position; //AllHelpers.findActualTimeIntervalIndex(selectedTimeString); //this needs to be set by position - to mark the correct index green

            masterActivity.currentSession.measure_time_interval = allTimeslots.get(position); // this needs to be set by the index in the master array so that the correct time gets sent to the server
            masterActivity.currentSession.user_has_selected_time = true;
        }

        timeScheduleAdapter.notifyDataSetChanged();
    }

    public int getRelativeTimeIntervalIndex(String selectedTimeString){
        int relativeIndex = -1;

        for (int i=0;i<availableTimeIntervalsStr.size();i++) {
            if (availableTimeIntervalsStr.get(i).contentEquals(selectedTimeString)){
                relativeIndex = i;
                break;
            }
        }
        return relativeIndex;
    }

    public  void setSelectedDate(String year, String month, String day){
        int year_int = Integer.parseInt(year);
        int day_int = Integer.parseInt(day);
        int month_int =-1;

        String month_year_text = "";

        for(int i=0; i < AllHelpers.monthNames.length; i++) {
            if (AllHelpers.monthNames[i].contains(month))
                month_int = i;
        }

        if (month_int >=0 ) {
            month_year_text = AllHelpers.fullMonthNames[month_int] + " " + Integer.toString(year_int);
            if (activeMonthYearHeader != null) {
                activeMonthYearHeader.setText(month_year_text);
            }
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.YEAR, year_int);
            cal.set(Calendar.MONTH, month_int);
            cal.set(Calendar.DAY_OF_MONTH, day_int);
            cal.set(Calendar.MILLISECOND, 0);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MINUTE, 0);
            cal.set(Calendar.HOUR_OF_DAY, 0);
            selectedDate =  cal.getTime();
            masterActivity.currentSession.measure_date = selectedDate;
            masterActivity.currentSession.user_has_selected_date = true;
            //Toast.makeText(getContext(), AllHelpers.dateToStr(selectedDate), Toast.LENGTH_SHORT).show();
            setWeekDisplayRange();
        }
        userSelectedDate = true;



    }

    public void updateCalendarPicker() {

        customCalendarOptions = new OptionsPickerBuilder(getContext(), new OnOptionsSelectListener() {
            @Override
            public void onOptionsSelect(int options1, int options2, int options3, View v) {
                String tx = "Year " + yearOptions.get(options1) + ", Month " + yearMonthOptions.get(options1).get(options2) +", Day " + yearMonthDayOptions.get(options1).get(options2).get(options3);
                setSelectedDate(yearOptions.get(options1),  yearMonthOptions.get(options1).get(options2),yearMonthDayOptions.get(options1).get(options2).get(options3) );


            }
        }).setTitleText("Schedule")
                .setContentTextSize(20)
                .setDividerColor(Color.LTGRAY)
                .setSelectOptions(0, 1)
                .setBgColor(Color.WHITE)
                .setTitleBgColor(Color.DKGRAY)
                .setTitleColor(Color.LTGRAY)
                .setCancelColor(Color.YELLOW)
                .setSubmitColor(Color.YELLOW)
                .setTextColorCenter(Color.LTGRAY)
                .isRestoreItem(true)
                .isCenterLabel(false)
                .setOutSideColor(0x00000000)
                .setOptionsSelectChangeListener(new OnOptionsSelectChangeListener() {
                    @Override
                    public void onOptionsSelectChanged(int options1, int options2, int options3) {
                        String str = "options1: " + options1 + "\noptions2: " + options2 + "\noptions3: " + options3;
                        //Toast.makeText(getContext(), str, Toast.LENGTH_SHORT).show();
                    }
                })
                .build();

        customCalendarOptions.setPicker(yearOptions, yearMonthOptions, yearMonthDayOptions);

    }

    public void loadDatePicker(){
        // get all the booked/blocked dates from the server - these will have to be removed from the display list


        Date tomorrow = new Date();
        Date one_year_ahead = new Date();

        Calendar c = Calendar.getInstance();
        c.setTime(tomorrow);
        int startingMonth = c.get(Calendar.MONTH);
        c.add(Calendar.DATE, 1);
        tomorrow = c.getTime();
        c.add(Calendar.DATE, 365);
        one_year_ahead = c.getTime();
        int endingMonth = c.get(Calendar.MONTH);

        int active_year = c.get(Calendar.YEAR);



        yearOptions.add(Integer.toString(active_year));
        yearOptions.add(Integer.toString(active_year+1));



        for(int i = 0 ; i < 12 ; i++ ) {

            int curr_active_month = (i + startingMonth) % 12;

            if (i+startingMonth <= 11) {
                c.set(active_year,curr_active_month,1);
            } else {
                c.set(active_year+1,curr_active_month,1);
            }

            //int max_num_days = c.getActualMaximum(Calendar.DAY_OF_MONTH);

        }



    }

    public void loadTimePicker() {
        // for the selected date, load the allowable times.

    }


    public void processFilledSchedules(String incomingStr) {
        if (!incomingStr.contains("NODATA")) {
            try {

                JSONArray jArray = new JSONArray(incomingStr);
                //Log.d(TAG, Integer.toString(jArray.length()));
                for (int arr_elem = 0 ; arr_elem < jArray.length() ; arr_elem++)
                {

                    JSONObject explrObject = jArray.getJSONObject(arr_elem);
                    //Log.d(TAG, explrObject.toString());
                    //Log.d(TAG, Integer.toString(arr_elem));


                    String confirmed_date_str = explrObject.getString("confirmed_date");
                    Date confirmed_date = AllHelpers.strToDate(confirmed_date_str);
                    int confirmed_time_int = Integer.parseInt(explrObject.getString("confirmed_time_int"));



                    ArrayList<Integer> currTimeInts;
                    if (masterActivity.currentSession.filledSchedList.get(confirmed_date) != null) {
                        currTimeInts = masterActivity.currentSession.filledSchedList.get(confirmed_date);
                    } else {
                        currTimeInts = new ArrayList<Integer>();
                    }

                    currTimeInts.add(confirmed_time_int);

                    masterActivity.currentSession.filledSchedList.put(confirmed_date,currTimeInts);

                }
                blockedDatesLoaded = true;
                Log.d(TAG, "past the loop");
                loadSelectedAvailableTimeIntervals();
                // prep the picker to get this data back into it


            } catch (Throwable t) {

                Log.e(TAG, "Could not parse malformed JSONArray: \"" + t.getMessage() + "\"");
            }


        } else {
            Log.d(TAG, "No Schedules after this date ? ");
        }


    }

    // Get available schedule list
    public void getMySqlFilledSchedules() {
        if (masterActivity != null && !Utils.isNetworkConnected(masterActivity)){
            Toast.makeText(masterActivity, getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
            return;
        }

        Date tomorrow = new Date();


        Calendar c = Calendar.getInstance();
        c.setTime(tomorrow);
        c.add(Calendar.DATE, 1);
        tomorrow = c.getTime();


        String currDate = AllHelpers.dateToStr(tomorrow);
        //String testDate = "2018-10-05";

        String url = "http://harrierlabs.com/kessa/admin/production/schedule_control_master.php?func=4&currdate="+currDate;
        Log.d(TAG,"calling schedulecontrol with" + url);

        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this.getContext());
        StringRequest sr = new StringRequest(Request.Method.GET, url,
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //Log.d(TAG, "success! response: " + response.toString());
                        processFilledSchedules(response.toString());
                    }
                },
                new com.android.volley.Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d(TAG, "error: " + error.toString());
                    }
                })
        {

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String,String> params = new HashMap<String, String>();
                params.put("Content-Type","application/x-www-form-urlencoded");
                return params;
            }
        };
        queue.add(sr);

    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onMeasureScheduleFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void setFragTitle(String newTitle);
        void onMeasureScheduleFragmentInteraction(Uri uri);
    }
}
