package com.tailor.kesaa.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;
import com.tailor.kesaa.model.CustomizeOptionElement;
import com.tailor.kesaa.fragment.CustomizeStyleFragment;
import com.tailor.kesaa.R;

import java.util.ArrayList;


public class CustomizerDataAdapter extends ArrayAdapter<CustomizeOptionElement> implements  View.OnClickListener {


    private static OnItemClickListener mOnItemClickLister;
    private CustomizeStyleFragment customizeParentFrag;

    public ArrayList<CustomizeOptionElement> CustomizeOptionElementDataSet;
    Context mContext;

    private int lastPosition = -1;

    private  static class TailorBaseOptionCardHolder {
        TextView customizeOptionName;
        ImageView customizeOptionPic;
        ImageView customizeCheckSelect;

        RelativeLayout containerLayout;
    }



    public CustomizerDataAdapter(Context context, ArrayList<CustomizeOptionElement> data, CustomizeStyleFragment serviceFrag ){
        super(context, R.layout.customize_item, data);
        this.CustomizeOptionElementDataSet = data;
        this.mContext=context;
        this.customizeParentFrag = serviceFrag;

    }

    public interface OnItemClickListener {
        void onItemClicked(View view, int pos);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mOnItemClickLister = listener;
    }



    @Override
    public void onClick(View v) {

        int position=(Integer) v.getTag();
        Object object= getItem(position);
        CustomizeOptionElement currBaseOption = (CustomizeOptionElement)object;

        String tester = "none";
        if (currBaseOption.optionSelected) {
            tester = "true " ;
        } else {
            tester = "false ";
        }

        Toast err_toast = Toast.makeText(getContext(),"clicked on " + ((CustomizeOptionElement) object).optionName + tester,Toast.LENGTH_LONG);
        //err_toast.show();
        customizeParentFrag.optionToggled(currBaseOption.optionDBname, currBaseOption.id_num, currBaseOption);
        //customizeParentFrag.popUpActivePriceDialog(currBaseOption.getOptionName(),currBaseOption.getDbOptionName(),currBaseOption.optionPrice);

    }



    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        CustomizeOptionElement dataModel = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view
        TailorBaseOptionCardHolder viewHolder; // view lookup cache stored in tag

        final View result;

        if ((convertView == null) || convertView.getTag() == null) {

            viewHolder = new TailorBaseOptionCardHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.customize_item, parent, false);
            viewHolder.customizeOptionName = convertView.findViewById(R.id.customize_text_item);
            viewHolder.customizeOptionPic =  convertView.findViewById(R.id.customize_image_item);
            viewHolder.customizeCheckSelect =  convertView.findViewById(R.id.customize_check_item);
            viewHolder.containerLayout = convertView.findViewById(R.id.container_layout);

            result = convertView;

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (TailorBaseOptionCardHolder) convertView.getTag();
            result=convertView;
        }

/*
        Animation animation = AnimationUtils.loadAnimation(mContext,  R.anim.shake);
        result.startAnimation(animation);
*/


        // Category name
        if (MyPreferenceManager.getInstance(mContext).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ARABIC){
            viewHolder.customizeOptionName.setText(dataModel.optionNameAr);
        }
        else{
            viewHolder.customizeOptionName.setText(dataModel.optionName);
        }

        // Category Photo
//        viewHolder.customizeOptionPic.setImageResource(AllHelpers.optImageSetter(dataModel.optionName));
        Glide.with(mContext).load(dataModel.imagePath).into(viewHolder.customizeOptionPic);


        if (customizeParentFrag.masterActivity.currentOrderItem.optSelectedMap.get(dataModel.categoryId) != null) {
            CustomizeOptionElement selectedOption = customizeParentFrag.masterActivity.currentOrderItem.optSelectedMap.get(dataModel.categoryId);
            if (dataModel.id_num == selectedOption.id_num) {
                viewHolder.customizeCheckSelect.setVisibility(View.VISIBLE);
            }
            else{
                viewHolder.customizeCheckSelect.setVisibility(View.INVISIBLE);
            }

        } else {
            viewHolder.customizeCheckSelect.setVisibility(View.INVISIBLE);
        }

//        if (dataModel.optionSelected) {
//            viewHolder.customizeCheckSelect.setVisibility(View.VISIBLE);
//        }
//        else {
//            viewHolder.customizeCheckSelect.setVisibility(View.INVISIBLE);
//        }


//        viewHolder.customizeOptionName.setTag(position);
//        viewHolder.customizeOptionPic.setTag(position);
        viewHolder.containerLayout.setTag(position);

        /*
        if (dataModel.optionPrice > 0) {
            viewHolder.baseOptionPrice.setText("SAR " + Double.toString(dataModel.optionPrice));
            viewHolder.baseOptionPic.setImageAlpha(255);
            viewHolder.baseOptionPic.setMaxHeight(300);
            viewHolder.baseOptionName.setTextColor(Color.argb(255,0,0,0));
            viewHolder.baseOptionPrice.setTextColor(Color.argb(255,0,0,0));

        } else {
            viewHolder.baseOptionPrice.setText("SAR 0.0" );
            viewHolder.baseOptionPic.setImageAlpha(30);
            viewHolder.baseOptionPic.setMaxHeight(200);
            viewHolder.baseOptionName.setTextColor(Color.argb(30,0,0,0));
            viewHolder.baseOptionPrice.setTextColor(Color.argb(30,0,0,0));
        }
    */

        viewHolder.containerLayout.setOnClickListener(this);
//        viewHolder.customizeOptionPic.setOnClickListener(this);
//        viewHolder.customizeOptionName.setOnClickListener(this);

        // Return the completed view to render on screen
        return convertView;
    }



}
