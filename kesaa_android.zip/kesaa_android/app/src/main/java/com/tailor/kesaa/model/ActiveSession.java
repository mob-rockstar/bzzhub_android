package com.tailor.kesaa.model;

import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthProvider;
import com.tailor.kesaa.model.order.OrderHistoryDetails;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class ActiveSession {



    public int user_id;

    // Measurement Date
    public Date measure_date = null;
    public int measure_time_interval;

    // Selected date id
    public int timeSlotId;

    public int actual_measure_time_index;
    public int session_language=0;

    public int last_active_transaction_number = -1;
    public boolean session_has_moved_past_init = false;

    public boolean user_has_selected_date = false;
    public boolean user_has_selected_time = false;

    public String coupon_codes = "";
    public UserTemplate currentUser;
    public String lastMainLineScreen = "selectThobeStyle";
    public FirebaseAuth firebaseAuth;
    public FirebaseUser firebaseUser;
    public String mVerificationId;
    public PhoneAuthProvider.ForceResendingToken mResendToken;
    public OrderHistoryDetails currentOrderOfInterest = null;


    public ArrayList<OrderItemTemplate> current_session_cart = new ArrayList<>();
    public HashMap<Date, ArrayList<Integer>> filledSchedList = null;

    private static ActiveSession instance = null;

    public static ActiveSession getInstance(){
        if (instance == null){
            Date currentTime = Calendar.getInstance().getTime();
            instance = new ActiveSession(0, null,0,0,0, "");
        }

        return instance;
    }

    public ActiveSession(int user_id, Date measure_date, int measure_time_interval, int actual_measure_time_index,  int session_language, String coupon_codes) {
        this.session_language = session_language;
        this.user_id = user_id;
        this.measure_date = measure_date;
        this.measure_time_interval = measure_time_interval;
        this.actual_measure_time_index = actual_measure_time_index;
        this.coupon_codes = coupon_codes;
        this.current_session_cart = new ArrayList<>();
    }

    public void addItemToCart(OrderItemTemplate newItem){

        if (current_session_cart == null) {
            current_session_cart = new ArrayList<>();
            current_session_cart.add(newItem);
        } else {

            current_session_cart.add(newItem);
        }

    }

    // Update the price in current order item
    public void updateAllCartItemsPrice(){

        if (current_session_cart != null) {

            for(int i = 0 ; i < current_session_cart.size() ; i++){
                float item_price = current_session_cart.get(i).item_total_price;
//                int item_price_rounded = item_price.intValue();
//                current_session_cart.get(i).item_total_price =  item_price * current_session_cart.get(i).order_quantity ;
            }
        }
    }

    // Get total price of selected options
    public float getTotalOptionPrice(OrderItemTemplate orderItem){
        float optionPrice = 0.0f;

        List<Integer> options = new ArrayList<>();
        Iterator myIterator = orderItem.optSelectedMap.keySet().iterator();
        while(myIterator.hasNext()) {
            Integer key = (Integer) myIterator.next();
            CustomizeOptionElement value = (CustomizeOptionElement) orderItem.optSelectedMap.get(key);

            if (value != null){
                optionPrice += Float.parseFloat(value.price);
            }
        }

        return optionPrice;
    }

    // Get total price including VAT
    public float getTotalCartPrice(){
        float totalPrice = 0.0f;
        float shippingPrice = 0.0f;
        float optionPrice = 0.0f;

        if (current_session_cart != null) {

            for(int i = 0 ; i < current_session_cart.size() ; i++){
                OrderItemTemplate orderItem = current_session_cart.get(i);
                totalPrice += orderItem.item_price * orderItem.order_quantity ;
                shippingPrice = orderItem.deliveryCost;

                // Get total amount of options
                Iterator myIterator = orderItem.optSelectedMap.keySet().iterator();
                while(myIterator.hasNext()) {
                    Integer key = (Integer) myIterator.next();
                    CustomizeOptionElement value = (CustomizeOptionElement) orderItem.optSelectedMap.get(key);

                    if (value != null){
                        optionPrice += Float.parseFloat(value.price);
                    }
                }

                optionPrice = optionPrice * orderItem.order_quantity;
            }

        } else {
           totalPrice = 0.0f;
        }

        Log.d("ActiveSession", "Options Price : " + optionPrice);

//        return totalPrice + shippingPrice + optionPrice;
        return totalPrice + optionPrice;
    }


}
