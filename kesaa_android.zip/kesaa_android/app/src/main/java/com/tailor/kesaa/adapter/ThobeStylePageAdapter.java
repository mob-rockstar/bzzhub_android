package com.tailor.kesaa.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.tailor.kesaa.R;
import com.tailor.kesaa.fragment.StyleSelectFragment;
import com.tailor.kesaa.model.thobe.ThobeStyleData;

public class ThobeStylePageAdapter extends PagerAdapter implements ViewPager.PageTransformer {

    public final static float BIG_SCALE = 1.0f;
    public final static float SMALL_SCALE = 0.7f;
    public final static float DIFF_SCALE = BIG_SCALE - SMALL_SCALE;

    private Context mContext;
    private List<ThobeStyleData> thobeStyleDataSet;
    public StyleSelectFragment parentFrag;
    private RequestOptions requestOptions;

    public ThobeStylePageAdapter(Context context, List<ThobeStyleData> thobeStyleArray, StyleSelectFragment incomingParentFrag) {
        mContext = context;
        thobeStyleDataSet = thobeStyleArray;
        parentFrag = incomingParentFrag;

        requestOptions = new RequestOptions();
        requestOptions.placeholder(R.drawable.ic_saudi_style);
        requestOptions.error(R.drawable.ic_saudi_style);
    }

    public Object instantiateItem(ViewGroup collection, int position) {
        //ThobeStyleDataHolder thobeData = thobeStyleDataSet.get(position);
        LayoutInflater inflater = LayoutInflater.from(mContext);
        ViewGroup curr_style_layout = (ViewGroup) inflater.inflate(R.layout.circle_style_card, collection, false);

        ImageView circStyleImage = curr_style_layout.findViewById(R.id.thobe_style_circle_image);

        ThobeStyleData thobeStyleData = thobeStyleDataSet.get(position);
        if (thobeStyleData.getImage() != null && !thobeStyleData.getImage().equals("")) {
            Glide.with(mContext).load(thobeStyleData.getImage()).apply(requestOptions).into(circStyleImage);
        }
        else{
            Log.d("ThobeStyle", "Image doesn't exist");
        }

//        int img_resource = 1;
//
//
//        if (position == AllHelpers.SAUDI) {
//            circStyleImage.setImageResource(R.drawable.ic_saudi_style);
//        } else if (position == AllHelpers.EMIRATI) {
//            circStyleImage.setImageResource(R.drawable.ic_uae_style);
//        }  else if (position == AllHelpers.KUWAITI) {
//            circStyleImage.setImageResource(R.drawable.ic_kuwait_style);
//        }  else if (position == AllHelpers.BAHRAINI) {
//            circStyleImage.setImageResource(R.drawable.ic_bahrain_style);
//        }


        /*
        if (position == 0) {
            circStyleImage.setImageResource(R.mipmap.crop_emir);
        } else if (position == 1) {
            circStyleImage.setImageResource(R.mipmap.crop_kuwaiti);
        }  else if (position == 2) {
            circStyleImage.setImageResource(R.mipmap.crop_omani);
        }  else if (position == 3) {
            circStyleImage.setImageResource(R.mipmap.crop_saudi);
        }
        */

        // set OnClickListener
        circStyleImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                parentFrag.selectedStyle(v);
            }
        });


        parentFrag.newStyleSwiped(position);

        collection.addView(curr_style_layout);
        return curr_style_layout;
    }

    @Override
    public int getCount() {
        return thobeStyleDataSet.size();
    }


    @Override
    public void destroyItem(ViewGroup collection, int position, Object view) {
        collection.removeView((View) view);
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public void transformPage(@NonNull View page, float position) {

        int pageWidth = page.getWidth();
        int pageHeight = page.getHeight();
/*
        StyleLinearLayout myLinearLayout = (StyleLinearLayout) page.findViewById(R.id.style_card_layout);
        float scale = BIG_SCALE;

        if (position > 0) {
            scale = scale - position * DIFF_SCALE;
            myLinearLayout.setTranslationY(pageHeight);
        } else {
            scale = scale + position * DIFF_SCALE;
        }
        if (scale < 0) scale = 0;


        myLinearLayout.setScaleBoth(scale);

*/


    }
}


