package com.tailor.kesaa.global;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.tailor.kesaa.R;
import com.tailor.kesaa.model.CustomizeOptionElement;
import com.tailor.kesaa.model.TailorBaseOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.Writer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AllHelpers {


    public static final int  EMIRATI = 0;
    public static final int  SAUDI = 1;
    public static final int  BAHRAINI = 2;
    public static final int  KUWAITI = 3;

    public static final int  PAY_TYPE_UNKNOWN = -1;
    public static final int  PAY_TYPE_HYPERPAY  = 0;
    public static final int  PAY_TYPE_CASH = 1;

    public static final int  PAY_STATUS_PASSED = 0;
    public static final int  PAY_STATUS_COD_PEND = 1;
    public static final int  PAY_STATUS_FAIL = 2;
    public static final int  PAY_STATUS_UNKNOWN = 3;

    // Option Type
    public static final int OPTION_TYPE_FABRIC      = 3;
    public static final int OPTION_TYPE_COLLAR      = 2;
    public static final int OPTION_TYPE_CUFF        = 1;
    public static final int OPTION_TYPE_PLACKET     = 4;
    public static final int OPTION_TYPE_POCKET      = 5;
    public static final int OPTION_TYPE_SIDE_POCKET = 6;


    public static final String[] fullMonthNames = new String[]{"January", "February", "March","April", "May", "June","July", "August", "September","October", "November", "December"};
    public static final String[] monthNames = new String[]{"Jan", "Feb", "Mar","Apr", "May", "Jun","Jul", "Aug", "Sep","Oct", "Nov", "Dec"};
    public static final String[] dayNames = new String[]{"Sun", "Mon", "Tue","Wed", "Thu", "Fri","Sat"};

    public static final String[] optionNamesArray = new String[]{"base_price", "saudi_style", "emarati_style", "bahraini_style", "omani_style", "kuwaiti_style", "qatari_style", "band_collar", "business_collar", "curved_collar", "mandarin_single_collar", "mandarin_double_collar",  "simple_cuff", "classic_cuff", "french_cuff", "urban_cuff",  "one_button_cuff", "two_button_cuff", "three_button_cuff","simple_classic_placket","simple_hidden_placket", "zipper_placket", "simple_double_spocket", "simple_zipper_spocket" ,  "inclined_pocket", "pointed_pocket", "round_pocket", "no_flap", "point_pocket_flap", "extra_opt", "show_white_fabric","off_white_fabric","blue_white_fabric","cream_fabric","white_fabric","light_brown_fabric","brown_fabric","dark_brown_fabric","grey_fabric","dark_grey_fabric","black_fabric"};
    public static final String[] optionNamesCategory = new String[]{"REF", "THOBE", "THOBE", "THOBE", "THOBE", "THOBE", "THOBE", "COLLAR", "COLLAR", "COLLAR", "COLLAR", "COLLAR",  "CUFF", "CUFF", "CUFF", "CUFF",  "CUFF", "CUFF", "CUFF","PLACKET","PLACKET", "PLACKET", "SIDEPOCKET", "SIDEPOCKET" ,  "POCKET", "POCKET", "POCKET", "POCKET", "POCKET", "REF", "FABRIC","FABRIC","FABRIC","FABRIC","FABRIC","FABRIC","FABRIC","FABRIC","FABRIC","FABRIC","FABRIC"};

    public static String[] timeIntervals  = {"06:00 AM - 08:00 AM","08:00 AM - 10:00 AM","10:00 AM - 12:00 PM","12:00 PM - 14:00 PM","14:00 PM - 16:00 PM","16:00 PM - 18:00 PM","18:00 PM - 20:00 PM","20:00 PM - 22:00 PM","22:00 PM - 00:00 AM"};
    public static String[] timeIntervalShortStr  = {"06:00 AM","07:00 AM","08:00 AM","09:00 AM","10:00 AM","11:00 AM","12:00 PM","1:00 PM","2:00 PM","3:00 PM","4:00 PM","5:00 PM","6:00 PM","7:00 PM","8:00 PM","9:00 PM","10:00 PM"};
    public static String[] master_db_status_readable = {"New\nOrder","Measurement\nin Process","Awaiting\nPayment","Payment\n Done","Tailoring\nUnderway","Tailoring\nComplete","Tailoring\non Hold","Pickup\nin Progress","Delivery\nin Progress","Delivered\n"};
//                                                           0                1                       2                3               4                   5                          6                7                     8                  9

    public static String[] master_db_status_summary_string = {"Order Receieved","Measurement","Measurement","Tailor\nAccepted","\nSewing","\nSewing","Tailoring\non Hold","Picked\nUp","Picked\nUp","\nDelivered"};


    public static String[] merged_statuses  = {"ORDER_NEW","ORDER_MEASURE_OTW","ORDER_MEASURE_DONE","ORDER_PAYMENT_DONE","ORDER_TAILOR_PROCESS","ORDER_TAILOR_DONE","ORDER_TAILOR_HOLD","ORDER_PICKUP_OTW","ORDER_DELIVERY_OTW","ORDER_DELIVERY_DONE"};


    public static int findActualTimeIntervalIndex(String selectedTimeString){
        int actualIndex = -1;

        for (int i=0;i<timeIntervalShortStr.length;i++) {
            if (timeIntervalShortStr[i].contentEquals(selectedTimeString)){
                actualIndex = i;
                break;
            }

        }
        return actualIndex;
    }

    public static String getStyleName(int style_id ) {

        switch (style_id){

            case 0 :
                return "Saudi";
            case 1:
                return "Emarati";

            case 2 :
                return "Bahraini";

            case 3 :
                return "Kuwaiti";

            default:
                return "Unknown";



        }

    }


    public static String optFabricID(int identifier) {
        String fabrDescr  = "";

        switch (identifier) {

            case 0:
                fabrDescr = "Snow White";
                break;
            case 1:
                fabrDescr = "Off White ";
                break;
            case 2:
                fabrDescr = "Blue White";
                break;

            case 3:
                fabrDescr = "Cream";
                break;
            case 4:
                fabrDescr = "White";
                break;
            case 5:
                fabrDescr = "Light Brown";
                break;
            case 6:
                fabrDescr = "Brown";
                break;
            case 7:
                fabrDescr = "Dark Brown";
                break;
            case 8:
                fabrDescr = "Grey";
                break;
            case 9:
                fabrDescr = "Dark Grey";
                break;
            case 10:
                fabrDescr = "Black";
                break;
        }

        return fabrDescr;
    }

    public static String optFabricImage(String identifier) {
        String fabrDescr  = "";

        switch (identifier) {

            case "Snow White":
                fabrDescr = "Soft White Description goes here";
                break;
            case "Off White":
                fabrDescr = "Off White Description goes here";
                break;
            case "Blue White":
                fabrDescr = "Blue White Description goes here";
                break;

            case "Cream":
                fabrDescr = "Cream Description goes here";
                break;
            case "White":
                fabrDescr = "White Description goes here";
                break;
            case "Light Brown":
                fabrDescr = "Light Brown Description goes here";
                break;
            case "Brown":
                fabrDescr = "Brown Description goes here";
                break;
            case "Dark Brown":
                fabrDescr = "Dark Brown Description goes here";
                break;
            case "Grey":
                fabrDescr = "Grey Description goes here";
                break;
            case "Dark Grey":
                fabrDescr = "Dark Grey Description goes here";
                break;
            case "Black":
                fabrDescr = "Black Description goes here";
                break;
        }

        return fabrDescr;
    }

    public static String optFabricDescr(String identifier) {
        String fabrDescr  = "";

        switch (identifier) {

            case "Snow White":
                fabrDescr = "Soft White Description goes here";
                break;
            case "Off White":
                fabrDescr = "Off White Description goes here";
                break;
            case "Blue White":
                fabrDescr = "Blue White Description goes here";
                break;

            case "Cream":
                fabrDescr = "Cream Description goes here";
                break;
            case "White":
                fabrDescr = "White Description goes here";
                break;
            case "Light Brown":
                fabrDescr = "Light Brown Description goes here";
                break;
            case "Brown":
                fabrDescr = "Brown Description goes here";
                break;
            case "Dark Brown":
                fabrDescr = "Dark Brown Description goes here";
                break;
            case "Grey":
                fabrDescr = "Grey Description goes here";
                break;
            case "Dark Grey":
                fabrDescr = "Dark Grey Description goes here";
                break;
            case "Black":
                fabrDescr = "Black Description goes here";
                break;
        }

        return fabrDescr;
    }


    public static int optImageSetter(String identifier)
    {
        int resID = 0;

        switch (identifier)
        {


            case "Snow White" :
                resID = R.mipmap.snow_white_swatch;
                break;
            case "Off White" :
                resID = R.mipmap.off_white_swatch;
                break;
            case "Blue White" :
                resID = R.mipmap.blue_white_swatch;
                break;

            case "Cream" :
                resID = R.mipmap.cream_swatch;
                break;
            case "White" :
                resID = R.mipmap.white_swatch;
                break;
            case "Light Brown" :
                resID = R.mipmap.light_brown_swatch;
                break;
            case "Brown" :
                resID = R.mipmap.brown_swatch;
                break;
            case "Dark Brown" :
                resID = R.mipmap.dark_brown_swatch;
                break;
            case "Grey" :
                resID = R.mipmap.light_grey_swatch;
                break;
            case "Dark Grey" :
                resID = R.mipmap.dark_grey_swatch;
                break;
            case "Black" :
                resID = R.mipmap.black_swatch;
                break;


            case "Band Collar" :
                resID = R.mipmap.collar_band;
                break;
            case "Business Collar" :
                resID = R.mipmap.collar_business;
                break;
            case "Curved Collar" :
                resID = R.mipmap.collar_curved;
                break;

            case "Mandarin Single" :
                resID = R.mipmap.collar_mandarin1;
                break;
            case "Mandarin Double" :
                resID = R.mipmap.collar_mandarin2;
                break;





            case "Simple Cuff" :
                resID = R.mipmap.cuffs_simple;
                break;

            case "Classic Cuff" :
                resID = R.mipmap.cuffs_classic;
                break;

            case "French Cuff" :
                resID = R.mipmap.cuffs_french;
                break;

            case "Single Button" :
                resID = R.mipmap.cuffs_single;
                break;
            case "Double Button" :
                resID = R.mipmap.cuffs_double;
                break;
            case "Triple Button" :
                resID = R.mipmap.cuffs_triple;
                break;
            case "Urban Cuffs" :
                resID = R.mipmap.cuffs_urban;
                break;



            case "Classic Placket" :
                resID = R.mipmap.placket_simple_classic;
                break;
            case "Hidden Placket" :
                resID = R.mipmap.placket_simple_hidden;
                break;
            case "Zipper Placket" :
                resID = R.mipmap.placket_zipper;
                break;


            case "Simple Pocket" :
                resID = R.mipmap.pocket_simple_double;
                break;

            case "Zipper Pocket" :
                resID = R.mipmap.pocket_simple_zipper;
                break;


            case "Inclined Pocket" :
                resID = R.mipmap.pocket_inclined;
                break;
            case "Pointed Pocket" :
                resID = R.mipmap.pocket_pointed;
                break;
            case "Round Pocket" :
                resID = R.mipmap.pocket_round;
                break;

            case "No Flap" :
                resID = R.mipmap.pocketflap_none;
                break;
            case "Pointed Flap" :
                resID = R.mipmap.pocketflap_pointed;
                break;



            case "Simple Double Pocket" :
                resID = R.mipmap.pocket_simple_double;
                break;
            case "Simple Zipper Pocket" :
                resID = R.mipmap.pocket_simple_zipper;
                break;

            default:
                resID = 0;


        }


        return resID;
    }

    public static String dateToStr(Date inpDate) {
        DateFormat dateFormat = new SimpleDateFormat("d MMMM yyyy", new Locale("en"));
        return dateFormat.format(inpDate);
    }

    public static String dateToStr(Date inpDate, String dateFormatString) {
        DateFormat dateFormat = new SimpleDateFormat(dateFormatString, new Locale("en"));
        return dateFormat.format(inpDate);
    }


    public static Date strToDate(String inpStr) {
        try {
            String setDate = inpStr;
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", new Locale("en"));
            Date utilDate = formatter.parse(setDate);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(utilDate);
            calendar.set(Calendar.MILLISECOND, 0);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.HOUR, 0);
            utilDate = calendar.getTime();
            return  utilDate;
        } catch (Throwable t) {
            Log.e("DT_CONV", "Could not convert date");
            return null;
        }
    }

    public static Date strToDate(String timeStr, String formatterString) {
        try {
            String setDate = timeStr;
            SimpleDateFormat formatter = new SimpleDateFormat(formatterString, new Locale("en"));
            Date utilDate = formatter.parse(setDate);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(utilDate);
            calendar.set(Calendar.MILLISECOND, 0);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.HOUR, 0);
            utilDate = calendar.getTime();
            return  utilDate;
        } catch (Throwable t) {
            Log.e("DT_CONV", "Could not convert date");
            return null;
        }
    }


    public static void arrTraverse(JSONArray sourceArray)
    {
        if(sourceArray!=null && sourceArray.length()>0){
            for (int i = 0; i < sourceArray.length(); i++) {
                try {

                    JSONObject childJsonObj = sourceArray.getJSONObject(i);
                    int idVal = (int) childJsonObj.get("id");
                    String nameVal = (String) childJsonObj.get("name");
                    Log.d("ARRAY"," : "+ nameVal);


                }  catch(org.json.JSONException exception){

                }


            }

        }
    }

    public static ArrayList<CustomizeOptionElement> jsonToAL(JSONArray sourceArray) {
        ArrayList<CustomizeOptionElement> sinkArray = new ArrayList<CustomizeOptionElement>();

        if(sourceArray!=null && sourceArray.length()>0){
            for (int i = 0; i < sourceArray.length(); i++) {
                try {

                    JSONObject childJsonObj = sourceArray.getJSONObject(i);
                    int idVal = (int) childJsonObj.get("id");
                    String nameVal = (String) childJsonObj.get("name");
                    String nameAr = (String) childJsonObj.get("name_ar");
                    String dbNameVal = (String) childJsonObj.get("dbname");

                    double priceVal = (double) childJsonObj.get("price");

                    Log.d("Helper", dbNameVal + " is " +  Double.toString(priceVal));
                    int activeInt = (int) childJsonObj.get("active");
                    boolean activeState;
                    if (activeInt > 0) activeState = true;
                    else activeState = false;
                    //String optionName, String optionDBname, int picResourceID, boolean optionSelected
                    sinkArray.add(new CustomizeOptionElement(idVal,nameVal,dbNameVal, false, nameAr));

                }  catch(org.json.JSONException exception){

                }

            }

        }


        return sinkArray;

    }


    public static ArrayList<TailorBaseOptions> hardCloneArrayList(ArrayList<TailorBaseOptions> sourceArray) {

        ArrayList<TailorBaseOptions> sinkArray = new ArrayList<TailorBaseOptions>();

        for (int i = 0 ; i< sourceArray.size() ; i++)
        {
            sinkArray.add(sourceArray.get(i));
        }

        return sinkArray;
    }


    public void saveJSONtoAsset(Context context, JSONArray jsonArray, String fname) {

        try {

            Writer outputWriter;
            File jsonFile = new File(fname);
            outputWriter = new BufferedWriter(new FileWriter(jsonFile));
            outputWriter.write(jsonArray.toString());
            outputWriter.close();
            //Toast.makeText(context, "Options Saved", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(context, e.getMessage(), Toast.LENGTH_LONG).show();
        }



    }


    public static String loadJSONFromAsset(Context context, String fname) {
        String json = null;
        try {
            InputStream is = context.getAssets().open(fname);

            int size = is.available();

            byte[] buffer = new byte[size];

            is.read(buffer);

            is.close();

            json = new String(buffer, "UTF-8");


        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;

    }


}