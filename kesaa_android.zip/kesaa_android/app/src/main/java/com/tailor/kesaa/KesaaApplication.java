package com.tailor.kesaa;

import android.app.Application;

import com.bumptech.glide.request.target.ViewTarget;
import com.crashlytics.android.Crashlytics;
import io.fabric.sdk.android.Fabric;

//import com.facebook.FacebookSdk;
//import com.facebook.appevents.AppEventsLogger;
import com.tailor.kesaa.webservice.KesaaServiceManager;

public class KesaaApplication extends Application {

    private static KesaaServiceManager serviceManager;


    @Override
    public void onCreate() {
        super.onCreate();

        serviceManager = new KesaaServiceManager(getApplicationContext());

        Fabric.with(this, new Crashlytics());

        ViewTarget.setTagId(R.id.glide_tag);

        // Initialize Facebook
//        FacebookSdk.sdkInitialize(getApplicationContext());
//        AppEventsLogger.activateApp(this);
    }

    // Get instance of KesaaServiceManager
    public static KesaaServiceManager getKesaaAPI(){
        return serviceManager;
    }

}
