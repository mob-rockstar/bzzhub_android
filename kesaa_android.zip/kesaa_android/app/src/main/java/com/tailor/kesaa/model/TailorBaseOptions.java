package com.tailor.kesaa.model;

public class TailorBaseOptions {

    public int optionID;
    public String optionName;
    public String optionDBname;
    public String optionPicLink;
    public boolean optionSelected;

    public double optionPrice;
    public String displayName;
    public boolean optionOffered;

    public TailorBaseOptions(int optID, String optionName, String optDBname, String optionPicLink, double optionPrice, String displayName, boolean optionOffered) {
        this.optionID =optID;
        this.optionName=optionName;
        this.optionDBname=optDBname;
        this.optionPicLink=optionPicLink;
        this.optionSelected = false;

        this.optionPrice = optionPrice;
        this.displayName = displayName;
        this.optionOffered = optionOffered;
    }

    public String getOptionName() {
        return optionName;
    }
    public String getDbOptionName() {
        return optionDBname;
    }
    public int getOptionID() {
        return optionID;
    }
    public void toggleSelection() { optionSelected = !optionSelected; }
    public boolean isSelected() {return  optionSelected;}
}
