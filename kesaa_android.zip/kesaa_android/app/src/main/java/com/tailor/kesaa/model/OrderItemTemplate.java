package com.tailor.kesaa.model;

import com.tailor.kesaa.model.thobe.ThobeStyleData;

import java.util.Date;
import java.util.Map;

public class OrderItemTemplate {


    public int user_id;
    public String user_uid;

    // Tailor info
    public String tailor_name = "";
    public int tailor_id = -1;

    public int order_size;
    public int order_shipping_type;
    public int order_quantity;

    // Cost
    public float item_price = 0.0f;
    public Double item_tailor_price;
    public float item_total_price = 0;
    public float deliveryCost = 0;

    public String whose_order;

    public int schedule_id;
    public int ref_order_id;
    public int trav_tailor_id;

    public Date confirmed_date;
    public int confirmed_time_int;
    public String order_notes;

    public int order_thobe_style;

    // Fabric
    public int order_thobe_fabric = -1;
    public CustomizeOptionElement selectedFabricOption;

    // Cuffs
    public int order_thobe_cuff = -1;
    public CustomizeOptionElement selectedCuffOption;

    // Collar
    public int order_thobe_collar = -1;
    public CustomizeOptionElement selectedCollarOption;

    public int order_thobe_byoke;
    public int order_thobe_fyoke;

    // Placket
    public int order_thobe_placket = -1;
    public CustomizeOptionElement selectedPlacketOption;

    public int order_thobe_numpocket;

    // Pocket
    public int order_thobe_pocketstyle = -1;
    public CustomizeOptionElement selectedPocketOption;

    public int order_thobe_placketstyle;

    public int order_thobe_pleat;

    // Side Pocket
    public int order_thobe_sidepocket = -1;
    public CustomizeOptionElement selectedSidePocketOption;

    public int order_thobe_slit;
    public int order_thobe_elbow;

    public Date order_placement_date;
    public Date order_delivery_date;

    public int     order_payment_type = -1;
    public int     order_payment_status = -1;
    public String  tap_transaction_reference = "";


    public String orderDeliveryInstructions = "";

    public Map<Integer, CustomizeOptionElement> optSelectedMap = null;

    public int order_confirm_status;

    public boolean order_placed_in_cart = false;

    // Selected thobe style
    public ThobeStyleData selectedThobe = null;

    public OrderItemTemplate(int schedule_id, int ref_order_id, int trav_tailor_id, Date confirmed_date,
                             int confirmed_time_int, int tailor_id, int order_size, int item_quantity,
                             float item_price, float item_total_price, String whose_order, int order_thobe_style,
                             int order_thobe_fabric, int order_thobe_cuff, int order_thobe_collar, int order_thobe_byoke,
                             int order_thobe_fyoke, int order_thobe_placket, int order_thobe_numpocket,
                             int order_thobe_pocketstyle, int order_thobe_placketstyle, int order_thobe_pleat,
                             int order_thobe_sidepocket, int order_thobe_slit, int order_thobe_elbow,
                             Date order_placement_date, Date order_delivery_date, String order_notes,
                             int order_confirm_status, int user_id, String deliveryInstructions, Map<Integer, CustomizeOptionElement> selectedOptionMap) {

        this.user_id = user_id;
        this.schedule_id = schedule_id;
        this.ref_order_id = ref_order_id;
        this.trav_tailor_id = trav_tailor_id;
        this.confirmed_date = confirmed_date;
        this.confirmed_time_int = confirmed_time_int;
        this.tailor_id = tailor_id;
        this.order_size = order_size;
        this.order_quantity = item_quantity;
        this.item_price = item_price;
        this.item_total_price = item_total_price;
        this.whose_order = whose_order;
        this.order_thobe_style = order_thobe_style;
        this.order_thobe_fabric = order_thobe_fabric;
        this.order_thobe_cuff = order_thobe_cuff;
        this.order_thobe_collar = order_thobe_collar;
        this.order_thobe_byoke = order_thobe_byoke;
        this.order_thobe_fyoke = order_thobe_fyoke;
        this.order_thobe_placket = order_thobe_placket;
        this.order_thobe_numpocket = order_thobe_numpocket;
        this.order_thobe_pocketstyle = order_thobe_pocketstyle;
        this.order_thobe_placketstyle = order_thobe_placketstyle;
        this.order_thobe_pleat = order_thobe_pleat;
        this.order_thobe_sidepocket = order_thobe_sidepocket;
        this.order_thobe_slit = order_thobe_slit;
        this.order_thobe_elbow = order_thobe_elbow;
        this.order_placement_date = order_placement_date;
        this.order_delivery_date = order_delivery_date;
        this.order_notes = order_notes;
        this.order_confirm_status = order_confirm_status;
        this.orderDeliveryInstructions = deliveryInstructions;

        optSelectedMap = selectedOptionMap;
    }
}
