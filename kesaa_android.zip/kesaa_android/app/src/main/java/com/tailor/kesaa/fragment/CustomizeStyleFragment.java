package com.tailor.kesaa.fragment;

import android.app.Dialog;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;


import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.tailor.kesaa.KesaaApplication;
import com.tailor.kesaa.adapter.CustomOptionListAdapter;
import com.tailor.kesaa.customs.CustomFontButton;
import com.tailor.kesaa.customs.CustomFontTextView;
import com.tailor.kesaa.global.EventBusMessage;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;
import com.tailor.kesaa.model.CustomizeOptionElement;
import com.tailor.kesaa.MainActivity;
import com.tailor.kesaa.R;
import com.tailor.kesaa.model.style.OptionListResponse;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link CustomizeStyleFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link CustomizeStyleFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CustomizeStyleFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    public String TAG = "CUSTOMIZE_FRG";

    public MainActivity masterActivity;
    public View masterServiceView;
    public ViewGroup masterServiceContainer;

    private List<CustomizeOptionElement> allOptions = new ArrayList<>();

    private OnFragmentInteractionListener mListener;


    @BindView(R.id.btn_confirm_customize)
    CustomFontButton confirmStyleButton;

    @BindView(R.id.progressBar)
    ProgressBar progressBar;

    public int selectedHeader = 0;

    // List View
    @BindView(R.id.option_list)
    ListView optionsListView;

    // Options Dictionary
    Map<Integer, List<CustomizeOptionElement>> optionsDict = new HashMap<>();

    // Options list adapter
    CustomOptionListAdapter customOptionListAdapter;

    // Handler for reload listview
    Handler reloadHandler = new Handler();

    public CustomizeStyleFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment CustomizeStyleFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static CustomizeStyleFragment newInstance(String param1, String param2) {
        CustomizeStyleFragment fragment = new CustomizeStyleFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        masterActivity = (MainActivity) getActivity();
        if (masterActivity != null) {
            masterActivity.showActionBar();
            masterActivity.setFragTitle(getString(R.string.customize_style));

            // Firebase analytics event
            Bundle bundle = new Bundle();
            bundle.putString(FirebaseAnalytics.Param.SCREEN_NAME, "Measurements Customization");
            bundle.putString(FirebaseAnalytics.Param.SCREEN_CLASS, getClass().getSimpleName());
            masterActivity.mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SCREEN_VIEW, bundle);
        }

        // Inflate the layout for this fragment
        View frag_view = inflater.inflate(R.layout.fragment_customize_style, container, false);
        ButterKnife.bind(this, frag_view);

        // Register EventBus
        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this);

        masterServiceView = frag_view;
        masterServiceContainer = container;

        masterActivity.currentSession.lastMainLineScreen = "customizeOptions";

        // Load all options from server
        loadCustomizationOptions();

        return frag_view;
    }

    @Override
    public void onDestroy() {
        // Unregister EventBus
        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }

        super.onDestroy();
    }


    @Subscribe(threadMode = ThreadMode.MAIN)
    public void OnEventMessage(EventBusMessage messageEvent) {
        if (messageEvent != null) {
            int messageType = messageEvent.getMessageType();
            if (messageType == EventBusMessage.MessageType.LANGUAGE_UPDATED) { // updated language
//                refreshScrollViews();
            }
        }
    }


    @OnClick(R.id.btn_confirm_customize)
    void confirmStyle() {
        if (allCustomizationsSelected()) {

            // Go to Measurement schedule page
            Navigation.findNavController(confirmStyleButton).navigate(R.id.action_customizeStyleFragment_to_measureScheduleFragment);

        }
    }

    public boolean allCustomizationsSelected() {
        boolean isSelectedAll = true;

        if (masterActivity.currentOrderItem.optSelectedMap!= null && masterActivity.currentOrderItem.optSelectedMap.size() > 0){

            if (masterActivity.currentOrderItem.optSelectedMap.size() < this.optionsDict.size()){
                isSelectedAll = false;
            }
            else{
                Iterator myIterator = masterActivity.currentOrderItem.optSelectedMap.keySet().iterator();
                while(myIterator.hasNext()) {
                    Integer key = (Integer) myIterator.next();
                    CustomizeOptionElement value = (CustomizeOptionElement) masterActivity.currentOrderItem.optSelectedMap.get(key);

                    if (value == null){
                        isSelectedAll = false;
                        break;
                    }
                }
            }
        }
        else{
            isSelectedAll = false;
        }

        if (!isSelectedAll) {
            Toast.makeText(this.getContext(), getString(R.string.complete_all_options), Toast.LENGTH_LONG).show();
        }

        return isSelectedAll;

    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onCustomizeStyleFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    // Show fabric dialog
    private void showFilterDialog(CustomizeOptionElement fabricOption) {
        try {
            Dialog dialog = new Dialog(masterActivity);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView(R.layout.dialog_fabric_details);
            dialog.getWindow().setBackgroundDrawableResource(R.drawable.empty);
            dialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);

            // Fabric name
            CustomFontTextView nameText = dialog.findViewById(R.id.fabric_name_text);

            // Fabric description
            CustomFontTextView descriptionText = dialog.findViewById(R.id.fabric_description_text);

            if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH) {
                nameText.setText(fabricOption.optionName);
                descriptionText.setText(fabricOption.enDescription);
            } else {
                nameText.setText(fabricOption.optionNameAr);
                descriptionText.setText(fabricOption.arDescription);
            }


            // Fabric image
            ImageView fabricImage = dialog.findViewById(R.id.fabric_image);

            Glide.with(masterActivity).load(fabricOption.imagePath).into(fabricImage);
//            fabricImage.setImageResource(AllHelpers.optImageSetter(fabricOption.optionName));


            // Save
            CustomFontButton saveButton = dialog.findViewById(R.id.save_button);
            saveButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    dialog.dismiss();

                }
            });


            dialog.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    // Initialize the selected option Map
    public void initOptionsMap() {
        int optionCount = allOptions.size();
        for (int optIndex = 0; optIndex < optionCount; optIndex++) {
            CustomizeOptionElement option = allOptions.get(optIndex);
            String optionKey = allOptions.get(optIndex).optionDBname;
            masterActivity.currentOrderItem.optSelectedMap.put(option.categoryId, null);
        }
    }


    public void optionToggled(String optKeyName, int optionID, CustomizeOptionElement fabricOption) {

        boolean activelySelected = false;
//        String catName = getCategoryName(optKeyName);
        Integer categoryId = fabricOption.categoryId;

        try {
            if (masterActivity.currentOrderItem.optSelectedMap.get(categoryId) != null) {
                masterActivity.currentOrderItem.optSelectedMap.put(categoryId, null);

            } else {
                activelySelected = true;
                masterActivity.currentOrderItem.optSelectedMap.put(categoryId, fabricOption);

                // show fabric detail dialog : type = 1
                if (fabricOption.type == 1){
                    showFilterDialog(fabricOption);
                }
            }

            if (activelySelected) {
                //set only one item in this category
//                setSingleMapOption(fabricOption);

                // Expand next category
                if (selectedHeader < optionsDict.size() - 1) {
                    selectedHeader += 1;
                }
                else{
                    selectedHeader = -1;
                }

//                triggerNextCategory(fabricOption);
            }
            else {
                // deselect everything in this category
//                deselectFullCategory(fabricOption);
            }

            // Save the selected option
//            setOrderOptionCurrentMaster(optKeyName, optionID, activelySelected, fabricOption);
//            updateArraySelections();

            // Reload the list view
            customOptionListAdapter = new CustomOptionListAdapter(masterActivity, optionsDict, this);
            optionsListView.setAdapter(customOptionListAdapter);
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    // update expandable views
    public void updateExpandableStatus(){

        customOptionListAdapter = new CustomOptionListAdapter(masterActivity, optionsDict, this);
        optionsListView.setAdapter(customOptionListAdapter);

    }


    // Load thobe option list from server
    public void loadCustomizationOptions() {

        progressBar.setVisibility(View.VISIBLE);

        // Call api to load options
        KesaaApplication.getKesaaAPI().getCustomOptions(masterActivity.currentOrderItem.selectedThobe.getId())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<OptionListResponse>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(OptionListResponse optionListResponse) {
                        progressBar.setVisibility(View.GONE);

                        if (optionListResponse.getCode() == 200) {
                            if (optionListResponse.getOptions() != null) {
                                // Sort options according to option type
                                sortOptions(optionListResponse.getOptions());
                            }
                        } else {
                            // Show error message
                            if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH) {
                                Toast.makeText(getActivity(), optionListResponse.getMessage(), Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(getActivity(), optionListResponse.getArabicMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(getActivity(), e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onComplete() {

                    }
                });

    }

    // Sort options
    private void sortOptions(List<CustomizeOptionElement> options) {
        allOptions.clear();
        allOptions = options;

        LinkedHashMap<Integer, List<CustomizeOptionElement>> map = new LinkedHashMap<>();
        int optionCount = options.size();
        int lastCategoryId = -1;
        List<CustomizeOptionElement> optionsGroup = new ArrayList<>();

        for (int i = 0 ; i < optionCount ; i++){
            CustomizeOptionElement option = options.get(i);
            int categoryId = option.categoryId;

            if (lastCategoryId == -1 || lastCategoryId == categoryId) {
                lastCategoryId = categoryId;
                optionsGroup.add(option);
            }
            else{
                map.put(lastCategoryId, optionsGroup);

                optionsGroup = new ArrayList<>();
                lastCategoryId = categoryId;
                optionsGroup.add(option);
            }
        }

        map.put(lastCategoryId, optionsGroup);

//        for (CustomizeOptionElement option : options) {
//            Integer categoryId = option.categoryId;
//
//            List<CustomizeOptionElement> optionsGroup = (List<CustomizeOptionElement>)map.get(categoryId);
//            if (optionsGroup != null) {
//                optionsGroup.add(option);
//            }
//            else{
//                optionsGroup = new ArrayList<>();
//                optionsGroup.add(option);
//            }
//
//            // Update value
//            map.put(categoryId, optionsGroup);
//        }

//        this.optionsDict = new TreeMap<Integer, List<CustomizeOptionElement>>(map);
        this.optionsDict = map;

        if (masterActivity.currentOrderItem.optSelectedMap == null) {
            masterActivity.currentOrderItem.optSelectedMap = new HashMap<Integer, CustomizeOptionElement>();
        }

        // display options
        customOptionListAdapter = new CustomOptionListAdapter(masterActivity, optionsDict, this);
        optionsListView.setAdapter(customOptionListAdapter);

    }



    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void setFragTitle(String newTitle);

        void onCustomizeStyleFragmentInteraction(Uri uri);
    }


}
