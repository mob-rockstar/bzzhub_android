package com.tailor.kesaa.fragment;

import android.app.Dialog;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.widget.AutoCompleteTextView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.tailor.kesaa.KesaaApplication;
import com.tailor.kesaa.MainActivity;
import com.tailor.kesaa.R;
import com.tailor.kesaa.adapter.TailorDataAdapter;
import com.tailor.kesaa.customs.CustomFontButton;
import com.tailor.kesaa.global.AllHelpers;
import com.tailor.kesaa.global.EventBusMessage;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;
import com.tailor.kesaa.global.Utils;
import com.tailor.kesaa.model.CustomizeOptionElement;
import com.tailor.kesaa.model.tailor.TailorDetails;
import com.tailor.kesaa.model.tailor.TailorListResponse;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link TailorListFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link TailorListFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class TailorListFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    public String TAG = "TAIL_FRAG";
    public MainActivity masterActivity;

    public int selectedTailorPosition = -1;
    public int selectedTailorID = -1;

    // Tailor array
    ArrayList<TailorDetails> tailorDetailsArray = new ArrayList<>();
    ArrayList<TailorDetails> searchedTailors    = new ArrayList<>();

    public ArrayList<TailorDetails> sortedTailorDetailArray;
    ListView tailorListView;

    private static TailorDataAdapter tailorListAdapter;
    private String sortString = "ALPHA";

    private OnFragmentInteractionListener mListener;

    @BindView(R.id.tailor_list_spinner)
    ProgressBar progressBar;

    @BindView(R.id.search_text)
    AutoCompleteTextView searchText;

    @BindView(R.id.btn_confirm_tailor)
    CustomFontButton confirmButton;

    View containerView;

    // Selected tailor
    public TailorDetails selectedTailor = null;

    // Filter options
    int filterOption = -1;

    public TailorListFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment TailorListFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static TailorListFragment newInstance(String param1, String param2) {
        TailorListFragment fragment = new TailorListFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        // TODO Add your menu entries here
        inflater.inflate(R.menu.select_tailor_menu,menu);
    }


    // handle button activities
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.show_filter) { // Show filter dialog
            if (masterActivity != null) {
                showFilterDialog();
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        containerView =   inflater.inflate(R.layout.fragment_tailor_list, container, false);
        ButterKnife.bind(this, containerView);

        if (!EventBus.getDefault().isRegistered(this))
            EventBus.getDefault().register(this);

        masterActivity = (MainActivity) getActivity();
        masterActivity = (MainActivity) getActivity();
        if (masterActivity != null){
            masterActivity.showActionBar();
            masterActivity.setFragTitle(getString(R.string.sel_tailor_title));

            // Firebase analytics event
            Bundle bundle = new Bundle();
            bundle.putString(FirebaseAnalytics.Param.SCREEN_NAME, "Tailor Selection");
            bundle.putString(FirebaseAnalytics.Param.SCREEN_CLASS, getClass().getSimpleName());
            masterActivity.mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SCREEN_VIEW, bundle);
        }

        tailorListView= containerView.findViewById(R.id.tailor_list);

        float totalOptionsPrice = masterActivity.currentSession.getTotalOptionPrice(masterActivity.currentOrderItem);
        tailorListAdapter = new TailorDataAdapter(tailorDetailsArray,containerView.getContext(),this, masterActivity.master_screen_width, masterActivity.master_screen_height, totalOptionsPrice);
        tailorListView.setAdapter(tailorListAdapter);

        initSearchBar();

        getMySqlPricedTailorList();

        return containerView;
    }

    @Override
    public void onDestroy() {
        // Unregister EventBus
        if (EventBus.getDefault().isRegistered(this)){
            EventBus.getDefault().unregister(this);
        }

        super.onDestroy();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void OnEventMessage(EventBusMessage messageEvent){
        if (messageEvent != null){
            int messageType = messageEvent.getMessageType();
            if (messageType == EventBusMessage.MessageType.SELECTED_TAILOR){ // Selected Tailor
                selectedTailor = (TailorDetails) messageEvent.getObject();

                // Update the tailor list
                updateTailorList();
            }
        }
    }

    // Update the tailor list
    private void updateTailorList(){
        if (tailorListAdapter != null){
            tailorListAdapter.notifyDataSetChanged();
        }
    }

    // Confirm tailor
    @OnClick(R.id.btn_confirm_tailor) void confirmTailor(){
        if (selectedTailor == null && masterActivity.currentOrderItem.tailor_id < 0){
            Toast.makeText(getContext(), getString(R.string.please_select_tailor), Toast.LENGTH_SHORT).show();
        }
        else{
            if (selectedTailor != null){
                // save current tailor information
                masterActivity.currentOrderItem.tailor_id               = selectedTailor.id;
                masterActivity.currentOrderItem.tailor_name             = selectedTailor.TailorName;
                masterActivity.currentOrderItem.item_price              = selectedTailor.totalCost - selectedTailor.deliveryCost;
                masterActivity.currentOrderItem.item_total_price        = selectedTailor.TailorApproxPrice;
                masterActivity.currentOrderItem.deliveryCost            = selectedTailor.deliveryCost;
            }

            // Go to order review page
            Navigation.findNavController(confirmButton).navigate(R.id.action_tailorListFragment_to_orderReviewFragment);
        }
    }

    // Show filter dialog
    private void showFilterDialog(){
        try {
            Dialog dialog = new Dialog(masterActivity);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView(R.layout.dialog_filter);
            dialog.getWindow().setBackgroundDrawableResource(R.drawable.empty);
            dialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);

            // Radio group
            RadioGroup filterGroup = dialog.findViewById(R.id.options_group);
            switch (filterOption){
                case SettingsKeys.FilterOptions.PRICE_HIGH_TO_LOW:
                    filterGroup.check(R.id.price_highlow_radio);
                    break;
                case SettingsKeys.FilterOptions.PRICE_LOW_TO_HIGH:
                    filterGroup.check(R.id.price_lowhigh_radio);
                    break;
                case SettingsKeys.FilterOptions.ALPHABETICAL:
                    filterGroup.check(R.id.alphabetic_radio);
                    break;
                case SettingsKeys.FilterOptions.RATING_HIGH_TO_LOW:
                    filterGroup.check(R.id.rating_highlow_radio);
                    break;
                case SettingsKeys.FilterOptions.RATING_LOW_TO_HIGH:
                    filterGroup.check(R.id.rating_lowhigh_radio);
                    break;
            }

            // Cancel
            CustomFontButton cancelButton = dialog.findViewById(R.id.cancel_button);
            cancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

            // Save
            CustomFontButton saveButton = dialog.findViewById(R.id.save_button);
            saveButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int selectedId = filterGroup.getCheckedRadioButtonId();
                    switch (selectedId){
                        case R.id.price_highlow_radio:
                            filterOption = SettingsKeys.FilterOptions.PRICE_HIGH_TO_LOW;
                            break;
                        case R.id.price_lowhigh_radio:
                            filterOption = SettingsKeys.FilterOptions.PRICE_LOW_TO_HIGH;
                            break;
                        case R.id.alphabetic_radio:
                            filterOption = SettingsKeys.FilterOptions.ALPHABETICAL;
                            break;
                        case R.id.rating_highlow_radio:
                            filterOption = SettingsKeys.FilterOptions.RATING_HIGH_TO_LOW;
                            break;
                        case R.id.rating_lowhigh_radio:
                            filterOption = SettingsKeys.FilterOptions.RATING_LOW_TO_HIGH;
                            break;
                    }

                    sortTailorList();

                    dialog.dismiss();

                }
            });


            dialog.show();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    // Sort tailor list
    private void sortTailorList(){
        setSortedTailorArray();
    }

    // Initialize the search bar
    private void initSearchBar(){
        // Autocomplete SearchText
        searchText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {

                    // Hide keyboard
                    Utils.hideKeyboard(masterActivity);

                    String searchKey = v.getText().toString().trim();
                    Log.d(TAG, "Search key = " + searchKey);
                    return true;
                }
                return false;
            }
        });

        // Search with entered string
        searchText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String currSearchKey =  s.toString().trim();

                tailorDetailsArray.clear();

                for (int i = 0; i < searchedTailors.size() ; i++)
                    if (searchedTailors.get(i).TailorName.toLowerCase().contains(currSearchKey.toLowerCase())){
                        tailorDetailsArray.add(searchedTailors.get(i));
                    }

                float totalPrice = masterActivity.currentSession.getTotalOptionPrice(masterActivity.currentOrderItem);
                tailorListAdapter = new TailorDataAdapter(tailorDetailsArray, containerView.getContext(),TailorListFragment.this, masterActivity.master_screen_width, masterActivity.master_screen_height, totalPrice);
                tailorListView.setAdapter(tailorListAdapter);
            }
        });
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onTailorListFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public void processPricedTailorList(String incomingStr) {

        tailorDetailsArray.clear();
        searchedTailors.clear();

        try {

            JSONArray jArray = new JSONArray(incomingStr);
            Log.d(TAG, Integer.toString(jArray.length()));
            for (int arr_elem = 0 ; arr_elem < jArray.length() ; arr_elem++)
            {

                JSONObject explrObject = jArray.getJSONObject(arr_elem);
                Log.d(TAG, explrObject.toString());
                Log.d(TAG, Integer.toString(arr_elem));

                if (explrObject.has("result")){
                    String resultMsg = explrObject.getString("result");
                    if (resultMsg.equals("no_such_tailors")){
                        Toast.makeText(getContext(), getString(R.string.no_such_tailors), Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(getContext(), resultMsg, Toast.LENGTH_SHORT).show();
                    }

                    break;
                }
                else{
                    int tailor_id = Integer.parseInt(explrObject.getString("tailor_id"));
                    String tailor_name = explrObject.getString("tailor_name");

                    String tailor_rating = explrObject.getString("tailor_rating");
                    Float tailor_price_float = Float.parseFloat(explrObject.getString("tailor_price"));
                    int tailor_price_roundup = Math.round(tailor_price_float);


//                    this.searchedTailors.add(new TailorDetails(tailor_id, tailor_name,"Unknown address", tailor_rating, 0, tailor_price_roundup));
                }

                //this.filteredDetailArray.add(new OrderListDetails(schedule_id,ref_order_id,trav_tailor_id,this_confirmed_date, confirmed_time_int,request_confirmation_status,measurement_complete_status, tailor_id,order_quantity,order_price,whose_order, this_order_placed_date,this_order_delivery_date,order_notes,order_thobe_style,order_thobe_fabric,order_thobe_cuff,order_thobe_collar,order_thobe_byoke,order_thobe_fyoke,order_thobe_placket,order_thobe_numpocket,order_thobe_pocketstyle,order_thobe_placketstyle,order_thobe_pleat,order_thobe_sidepocket,order_thobe_slit,order_thobe_elbow,order_confirm_status));

            }

            Log.d(TAG, "past the loop");

            tailorDetailsArray.addAll(searchedTailors);

            // sort array
            setSortedTailorArray();

            // hide progress bar
            progressBar.setVisibility(View.GONE);

        } catch (Throwable t) {

            Log.e("MEASURESCHED", "Could not parse malformed JSONArray: \"" + t.getMessage() + "\"");
        }


    }


    public void getMySqlPricedTailorList() {

        if (masterActivity != null && !Utils.isNetworkConnected(masterActivity)){
            Toast.makeText(masterActivity, getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
            return;
        }

        // Get option array
        List<Integer> options = new ArrayList<>();
        Iterator myIterator = masterActivity.currentOrderItem.optSelectedMap.keySet().iterator();
        while(myIterator.hasNext()) {
            Integer key = (Integer) myIterator.next();
            CustomizeOptionElement value = (CustomizeOptionElement) masterActivity.currentOrderItem.optSelectedMap.get(key);

            if (value != null){
                options.add(value.id_num);
            }
        }
//        options.add(masterActivity.currentOrderItem.selectedFabricOption.optionDBname);
//        options.add(masterActivity.currentOrderItem.selectedCuffOption.optionDBname);
//        options.add(masterActivity.currentOrderItem.selectedCollarOption.optionDBname);
//        options.add(masterActivity.currentOrderItem.selectedPlacketOption.optionDBname);
//        options.add(masterActivity.currentOrderItem.selectedPocketOption.optionDBname);
//        options.add(masterActivity.currentOrderItem.selectedSidePocketOption.optionDBname);

        // Get selected size
        String sizeStr = "small";
        if (masterActivity.currentOrderItem.order_size == 0){
            sizeStr = "small";
        }
        else if (masterActivity.currentOrderItem.order_size == 1){
            sizeStr = "medium";
        }
        else if (masterActivity.currentOrderItem.order_size == 2){
            sizeStr = "large";
        }

//        JSONObject requestParam = new JSONObject();
//        try {
//            requestParam.put("size", sizeStr);
//            requestParam.put("requestDate", AllHelpers.dateToStr(masterActivity.currentSession.measure_date, "yyyy-MM-dd"));
//            requestParam.put("hour", masterActivity.currentSession.measure_time_interval);
//            requestParam.put("options", options);
//            requestParam.put("pageNumber", 1);
//            requestParam.put("pageSize", 30);
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//
//        // Create the request body
//        RequestBody body = RequestBody.create(okhttp3.MediaType.parse("application/json; charset=utf-8"),
//                requestParam.toString());

        HashMap<String, Object> params = new HashMap<>();
        params.put("size", sizeStr);
        params.put("requestDate", AllHelpers.dateToStr(masterActivity.currentSession.measure_date, "yyyy-MM-dd"));
        params.put("hour", masterActivity.currentSession.measure_time_interval);
        params.put("options", options);
        params.put("pageNumber", 1);
        params.put("pageSize", 30);

        progressBar.setVisibility(View.VISIBLE);

        KesaaApplication.getKesaaAPI().getTailors(params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<TailorListResponse>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(TailorListResponse tailorListResponse) {
                        progressBar.setVisibility(View.GONE);
                        if (tailorListResponse.getCode() == 200){
                            searchedTailors.clear();
                            tailorDetailsArray.clear();

                            searchedTailors = tailorListResponse.getData().getTailors();
                            tailorDetailsArray.addAll(searchedTailors);

                            // sort array
                            setSortedTailorArray();
                        }
                        else{
                            // Show error message
                            if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                                Toast.makeText(masterActivity, tailorListResponse.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(masterActivity, tailorListResponse.getArabicMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        progressBar.setVisibility(View.GONE);
                    }

                    @Override
                    public void onComplete() {

                    }
                });

//        String url = "http://harrierlabs.com/kessa/admin/production/pricing_control_master.php?func=1&thobe_type="+ thobe_type+ "&collar_type="+ collar_type+ "&cuff_type="+ cuff_type+ "&placket_type="+ placket_type + "&pocket_style_type="+ pocket_style_type+ "&fabric_type="+ fabric_type;
//        Log.d(TAG,"calling pricecontrol with" + url);
//
//        // Instantiate the RequestQueue.
//        RequestQueue queue = Volley.newRequestQueue(this.getContext());
//        StringRequest sr = new StringRequest(Request.Method.GET, url,
//                new com.android.volley.Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//                        Log.d(TAG, "success! response: " + response.toString());
//                        progressBar.setVisibility(View.GONE);
//                        processPricedTailorList(response.toString());
//                    }
//                },
//                new com.android.volley.Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        Log.d(TAG, "error: " + error.toString());
//                        progressBar.setVisibility(View.GONE);
//                        Toast.makeText(getContext(), error.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
//                    }
//                })
//        {
//
//            @Override
//            public Map<String, String> getHeaders() throws AuthFailureError {
//                Map<String,String> params = new HashMap<String, String>();
//                params.put("Content-Type","application/x-www-form-urlencoded");
//                return params;
//            }
//        };
//        queue.add(sr);

    }

    // Item Click Listener
    public void cardOptionClicked(String cardOpt, TailorDetails tailorDetails) {
        Log.d(TAG,cardOpt + " clicked");

        String[] selectedOption = cardOpt.split("_");

        if (selectedOption.length > 1)
        {

            int selected_tailor_position_int =  Integer.parseInt(selectedOption[1]);

            if (selectedOption[0].contentEquals("btn") || selectedOption[0].contentEquals("price")) {

                selectedTailor = tailorDetails;
                selectedTailorPosition = selected_tailor_position_int;

                masterActivity.currentOrderItem.tailor_id               = selectedTailor.id;
                masterActivity.currentOrderItem.tailor_name             = selectedTailor.TailorName;
                masterActivity.currentOrderItem.item_price              = selectedTailor.TailorApproxPrice;
                masterActivity.currentOrderItem.item_total_price        = selectedTailor.TailorApproxPrice;

                if (selectedOption[0].contentEquals("btn")){
                    tailorListAdapter.notifyDataSetChanged();
                }
                else{
                    // Go to Order Review page
                    Navigation.findNavController(tailorListView).navigate(R.id.action_tailorListFragment_to_orderReviewFragment);
                }
            }
            else if (selectedOption[0].contentEquals("tailorInfo") || selectedOption[0].contentEquals("rate")){
                Bundle bundle = new Bundle();
                bundle.putSerializable("selected_tailor", tailorDetails);
                Navigation.findNavController(tailorListView).navigate(R.id.tailorProfileFragment, bundle);
            }

        }
    }


    public void setSortedTailorArray() {

        //sortedTailorDetailArray.clear();
        //sortedTailorDetailArray = (ArrayList<TailorDetails>)tailorDetailsArray.clone();

        if (filterOption >= 0) {

            if (filterOption == SettingsKeys.FilterOptions.PRICE_HIGH_TO_LOW) {
                Collections.sort(tailorDetailsArray, new SortHiLo());
            }
            else if (filterOption == SettingsKeys.FilterOptions.PRICE_LOW_TO_HIGH) {
                Collections.sort(tailorDetailsArray, new SortLoHi());
            }
            else if (filterOption == SettingsKeys.FilterOptions.RATING_HIGH_TO_LOW) {
                Collections.sort(tailorDetailsArray, new SortRatingHiLo());
            }
            else if (filterOption == SettingsKeys.FilterOptions.RATING_LOW_TO_HIGH) {
                Collections.sort(tailorDetailsArray, new SortRatingLoHi());
            }
            else if (filterOption == SettingsKeys.FilterOptions.ALPHABETICAL) {
                Collections.sort(tailorDetailsArray, new SortAlpha());
            }
        }

//        tailorListAdapter = new TailorDataAdapter(tailorDetailsArray, containerView.getContext(),TailorListFragment.this, masterActivity.master_screen_width, masterActivity.master_screen_height);
//        tailorListView.setAdapter(tailorListAdapter);

        tailorListAdapter.notifyDataSetChanged();
    }

    // Price Low to High
    class SortLoHi implements Comparator<TailorDetails>
    {

        public int compare(TailorDetails a, TailorDetails b)
        {
            float compVal =  a.TailorApproxPrice - b.TailorApproxPrice;
            if (compVal > 0)
                return 1;
            else
                return -1;

        }

    }

    // Price High to Low
    class SortHiLo implements Comparator<TailorDetails>
    {

        public int compare(TailorDetails a, TailorDetails b)
        {
            float compVal =  a.TailorApproxPrice - b.TailorApproxPrice;
            if (compVal > 0)
                return -1;
            else
                return 1;

        }

    }

    // Rating High to Low
    class SortRatingHiLo implements Comparator<TailorDetails>
    {

        public int compare(TailorDetails a, TailorDetails b)
        {
            float compVal =  a.TailorStarRating - b.TailorStarRating;
            if (compVal > 0)
                return -1;
            else
                return 1;

        }

    }

    // Rating High to Low
    class SortRatingLoHi implements Comparator<TailorDetails>
    {

        public int compare(TailorDetails a, TailorDetails b)
        {
            float compVal =  a.TailorStarRating - b.TailorStarRating;
            if (compVal > 0)
                return 1;
            else
                return -1;

        }

    }

    // Alphabetical
    class SortAlpha implements Comparator<TailorDetails>
    {

        public int compare(TailorDetails a, TailorDetails b)
        {
            return a.getName().compareTo(b.getName());
        }

    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void setFragTitle(String newTitle);
        void onTailorListFragmentInteraction(Uri uri);
    }
}
