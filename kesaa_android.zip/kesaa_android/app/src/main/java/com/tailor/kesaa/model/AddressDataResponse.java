package com.tailor.kesaa.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AddressDataResponse implements Serializable {

    @SerializedName("rows")
    @Expose
    private List<AddressData> addresses = new ArrayList<>();

    @SerializedName("total")
    @Expose
    private Integer total;

    @SerializedName("page")
    @Expose
    private Integer page;

    @SerializedName("pageSize")
    @Expose
    private Integer pageSize;

    @SerializedName("totalPages")
    @Expose
    private Integer totalPages;

    public List<AddressData> getAddresses() {
        return addresses;
    }

    public void setAddresses(List<AddressData> rows) {
        this.addresses = rows;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(Integer totalPages) {
        this.totalPages = totalPages;
    }
}
