package com.tailor.kesaa.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.tailor.kesaa.R;
import com.tailor.kesaa.customs.CustomFontTextView;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;
import com.tailor.kesaa.model.faq.FaqDetail;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class FaqListAdapter extends BaseAdapter {

    private Context mContext;
    private LayoutInflater layoutInflater;

//    private List<String> questionArray;
//    private List<String> answerArray;

    private List<FaqDetail> faqDetails;

    public FaqListAdapter(Context context, List<FaqDetail> faqs){
        this.mContext = context;
        this.faqDetails = faqs;
        this.layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public FaqListAdapter() {
        super();
    }

    @Override
    public int getCount() {
        return faqDetails.size();
    }

    @Override
    public Object getItem(int position) {
        return faqDetails.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        FaqHolder holder;
        if (convertView == null){
            convertView = this.layoutInflater.inflate(R.layout.item_faq_list, null);
            holder = new FaqHolder(convertView);
            convertView.setTag(holder);

        }
        else{
            holder = (FaqHolder) convertView.getTag();
        }

        FaqDetail faqDetail = faqDetails.get(position);
        if (MyPreferenceManager.getInstance(mContext).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH) {
            holder.questionText.setText(faqDetail.getEnglishQuestion());
            holder.answerText.setText(faqDetail.getEnglishAnswer());
        }
        else{
            holder.questionText.setText(faqDetail.getArabicQuestion());
            holder.answerText.setText(faqDetail.getArabicAnswer());
        }

        return convertView;
    }

    static class FaqHolder{
        @BindView(R.id.question_text)
        CustomFontTextView questionText;

        @BindView(R.id.answer_text)
        CustomFontTextView answerText;

        public FaqHolder(View view){
            ButterKnife.bind(this, view);
        }
    }
}
