package com.tailor.kesaa.fragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.tailor.kesaa.KesaaApplication;
import com.tailor.kesaa.MainActivity;
import com.tailor.kesaa.adapter.OrderHistoryAdapter;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;
import com.tailor.kesaa.global.Utils;
import com.tailor.kesaa.model.order.OrderHistoryDetails;
import com.tailor.kesaa.R;
import com.tailor.kesaa.model.order.OrderListResponse;
import com.tailor.kesaa.widgets.SwipyRefreshLayout;
import com.tailor.kesaa.widgets.SwipyRefreshLayoutDirection;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import okhttp3.RequestBody;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link OrderHistoryFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link OrderHistoryFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class OrderHistoryFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    public String TAG = "ORDHISTFRAG";

    public MainActivity masterActivity;

    public int master_screen_width = -1;
    public int master_screen_height = -1;

    public ArrayList<OrderHistoryDetails> orderHistoryArray =null;
    public ListView orderHistoryListview;
    public OrderHistoryAdapter orderHistoryAdapter;
    public View main_history_view;

    private OnFragmentInteractionListener mListener;


    @BindView(R.id.refresh_layout)
    SwipyRefreshLayout refreshLayout;

    @BindView(R.id.progressBar)
    ProgressBar progressBar;

    public OrderHistoryFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment OrderHistoryFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static OrderHistoryFragment newInstance(String param1, String param2) {
        OrderHistoryFragment fragment = new OrderHistoryFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment


        masterActivity = (MainActivity) getActivity();
        if (masterActivity != null) {
            masterActivity.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            masterActivity.setFragTitle(getString(R.string.ord_history_title));
        }

        View frag_view = inflater.inflate(R.layout.fragment_order_history, container, false);
        ButterKnife.bind(this, frag_view);

        main_history_view = frag_view;

        orderHistoryListview = frag_view.findViewById(R.id.ord_history_listview);
        orderHistoryArray = new ArrayList<>();

        if (masterActivity != null) {
            getMySqlUserOrderList();
        }


        // Set refresh layout listener
        refreshLayout.setOnRefreshListener(new SwipyRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh(SwipyRefreshLayoutDirection direction) {
                Log.d("OrderHistory", "Refresh triggered at " + (direction == SwipyRefreshLayoutDirection.TOP ? "top" : "bottom"));

                getMySqlUserOrderList();
            }
        });

        return frag_view;
    }



    public void getMySqlUserOrderList() {
        if (masterActivity != null && !Utils.isNetworkConnected(masterActivity)){
            Toast.makeText(masterActivity, getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
            return;
        }

        // Get user id
        int uId = masterActivity.currentSession.currentUser.id;
        JSONObject requestParam = new JSONObject();
        try {
            requestParam.put("userId", uId);
            requestParam.put("pageSize", 30);
            requestParam.put("pageNumber", 1);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // Create the request body
        RequestBody body = RequestBody.create(okhttp3.MediaType.parse("application/json; charset=utf-8"),
                requestParam.toString());

        // Show the loading progress
        progressBar.setVisibility(View.VISIBLE);

        KesaaApplication.getKesaaAPI().getOrders(body)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<OrderListResponse>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(OrderListResponse orderListResponse) {
                        progressBar.setVisibility(View.GONE);

                        if (orderListResponse.getCode() == 200){
                            orderHistoryArray.clear();
                            if (orderListResponse.getData() != null){
                                orderHistoryArray = orderListResponse.getData().getOrders();
                            }

                            // Reload order history
                            initOrderHistoryList();
                        }
                        else{
                            // Show error message
                            if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                                Toast.makeText(masterActivity, orderListResponse.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(masterActivity, orderListResponse.getArabicMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(masterActivity, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onComplete() {

                    }
                });

//        String url = "http://harrierlabs.com/kessa/admin/production/customer_control_master.php?func=111&user_id=" + uId;
//        Log.d(TAG,"calling customer_control with" + url);
//
//
//        // Instantiate the RequestQueue.
//        RequestQueue queue = Volley.newRequestQueue(this.getContext());
//        StringRequest sr = new StringRequest(Request.Method.GET, url,
//                new com.android.volley.Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//                        Log.d(TAG, "success! response: " + response.toString());
//                        processServerUserOrderDetails(response.toString());
//                    }
//                },
//                new com.android.volley.Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        Log.d(TAG, "error: " + error.toString());
//
//                        // Hide refresh layout
//                        refreshLayout.setRefreshing(false);
//                    }
//                })
//        {
//
//            @Override
//            public Map<String, String> getHeaders() throws AuthFailureError {
//                Map<String,String> params = new HashMap<String, String>();
//                params.put("Content-Type","application/x-www-form-urlencoded");
//                return params;
//            }
//        };
//        queue.add(sr);

    }

    private void initOrderHistoryList(){
        orderHistoryAdapter = new OrderHistoryAdapter(orderHistoryArray,getContext(), this, masterActivity.master_screen_width,master_screen_height);
        orderHistoryListview.setAdapter(orderHistoryAdapter);
//        orderHistoryAdapter.notifyDataSetChanged();
    }

//    public void processServerUserOrderDetails(String incomingStr) {
//
//        // Hide refresh layout
//        refreshLayout.setRefreshing(false);
//
//        try {
//
//            JSONArray jArray = new JSONArray(incomingStr);
//            Log.d(TAG, Integer.toString(jArray.length()));
//            for (int arr_elem = 0 ; arr_elem < jArray.length() ; arr_elem++)
//            {
//                JSONObject explrObject = jArray.getJSONObject(arr_elem);
//                Log.d(TAG, explrObject.toString());
//                Log.d(TAG, Integer.toString(arr_elem));
//
//                int transaction_id = Integer.parseInt(explrObject.getString("transaction_id"));
//                int order_id = Integer.parseInt(explrObject.getString("order_id"));
//                int tailor_id = Integer.parseInt(explrObject.getString("tailor_id"));
//                int order_size = Integer.parseInt(explrObject.getString("order_size"));
//                int order_quantity = Integer.parseInt(explrObject.getString("order_quantity"));
//                int user_id = Integer.parseInt(explrObject.getString("user_id"));
//                int order_price = Integer.parseInt(explrObject.getString("order_price"));
//                int order_thobe_style = Integer.parseInt(explrObject.getString("order_thobe_style"));
//                int order_thobe_fabric = Integer.parseInt(explrObject.getString("order_thobe_fabric"));
//                int order_thobe_collar = Integer.parseInt(explrObject.getString("order_thobe_collar"));
//                int order_thobe_cuff = Integer.parseInt(explrObject.getString("order_thobe_cuff"));
//                int order_thobe_placket = Integer.parseInt(explrObject.getString("order_thobe_placket"));
//                int order_thobe_pocketstyle = Integer.parseInt(explrObject.getString("order_thobe_pocketstyle"));
//                int order_thobe_sidepocket = Integer.parseInt(explrObject.getString("order_thobe_sidepocket"));
//                int order_confirm_status = Integer.parseInt(explrObject.getString("order_confirm_status"));
//
//                Date orderBookingDate = AllHelpers.strToDate(explrObject.getString("order_placement_date"));
//
//                String user_uid = explrObject.getString("firebaseUID");
//                String tailor_name = explrObject.getString("tailor_name");
//
//                OrderHistoryDetails order_detail = new OrderHistoryDetails();
//                order_detail.transaction_id = transaction_id ;
//                order_detail.order_id = order_id;
//                order_detail.user_id = user_id;
//                order_detail.order_tailor_id = tailor_id;
//                order_detail.order_size = order_size;
//                order_detail.order_qty = order_quantity;
//                order_detail.order_total_price = order_price;
//                order_detail.order_status = order_confirm_status;
//                order_detail.order_cancel_status = 0;
//                order_detail.order_tailor_name = tailor_name;
//
//                order_detail.order_thobe_style = order_thobe_style;
//                order_detail.order_fabric_type = order_thobe_fabric;
//                order_detail.order_collar_type = order_thobe_collar;
//                order_detail.order_cuffs_type = order_thobe_cuff;
//                order_detail.order_placket_type = order_thobe_placket;
//                order_detail.order_pocket_type = order_thobe_pocketstyle;
//                order_detail.order_sidepocket_type = order_thobe_sidepocket;
////                order_detail.order_placement_date = orderBookingDate;
//                order_detail.order_status = order_confirm_status;
//
//
//                //int scheduleID,String tailorName, int thisThobeType, Date thisBookingDate,  int thisBookingStatus,   int order_id, Date thisCompletionDate
//
//                this.orderHistoryArray.add(order_detail);
//
//                //check if this user's details are saved in sharedPrefs
//            }
//
//
//            // Sort the order history by date
////            Collections.sort(this.orderHistoryArray, new SortOrdersByDate());
//
//            orderHistoryAdapter = new OrderHistoryAdapter(orderHistoryArray,getContext(), this, masterActivity.master_screen_width,master_screen_height);
//            orderHistoryListview.setAdapter(orderHistoryAdapter);
//            orderHistoryAdapter.notifyDataSetChanged();
//
//        } catch (Throwable t) {
//            Log.e(TAG, "Could not parse malformed userdet JSONArray: \"" + t.getMessage() + "\"");
//        }
//
//
//    }

    // Sort
    // Rating High to Low
//    class SortOrdersByDate implements Comparator<OrderHistoryDetails>
//    {
//        // Used for sorting in ascending order of
//        public int compare(OrderHistoryDetails a, OrderHistoryDetails b)
//        {
//            if (a.order_placement_date.getTime() > b.order_placement_date.getTime()){
//                return -1;
//            }
//            else if (a.order_placement_date.getTime() == b.order_placement_date.getTime()){
//                return 0;
//            }
//            else{
//                return 1;
//            }
//        }
//
//    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onOrderHistoryFragmentInteraction("");
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public void orderClicked(int position){

        OrderHistoryDetails currentOrderOfInterest = orderHistoryArray.get(position);
        masterActivity.currentSession.currentOrderOfInterest = currentOrderOfInterest;

        // Go to order detail page
        Navigation.findNavController(main_history_view).navigate(R.id.action_orderHistoryFragment_to_orderDetailsFragment);


    }
    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        void setFragTitle(String newTitle);
        void onOrderHistoryFragmentInteraction(String data);
    }
}
