package com.tailor.kesaa.fragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.tailor.kesaa.KesaaApplication;
import com.tailor.kesaa.MainActivity;
import com.tailor.kesaa.R;
import com.tailor.kesaa.customs.CustomFontEditText;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;
import com.tailor.kesaa.global.Utils;
import com.tailor.kesaa.model.ActiveSession;

import org.json.JSONException;
import org.json.JSONObject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import okhttp3.RequestBody;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link SettingsProfileFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link SettingsProfileFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class SettingsProfileFragment extends Fragment {
    private static final String TAG = "Settings";

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    public MainActivity masterActivity;

    // First name
    @BindView(R.id.first_name_edt)
    CustomFontEditText firstNameText;

    // Last Name
    @BindView(R.id.last_name_edt)
    CustomFontEditText lastNameText;

    // Phone
    @BindView(R.id.phone_edt)
    CustomFontEditText phoneText;

    // Email
    @BindView(R.id.email_edt)
    CustomFontEditText emailText;

    @BindView(R.id.progressBar)
    ProgressBar progressBar;

    public SettingsProfileFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment SettingsProfileFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static SettingsProfileFragment newInstance(String param1, String param2) {
        SettingsProfileFragment fragment = new SettingsProfileFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_settings_profile, container, false);
        ButterKnife.bind(this,view);

        masterActivity = (MainActivity) getActivity();
        if (masterActivity != null){
            masterActivity.setFragTitle(getString(R.string.settings_title));
            masterActivity.showActionBar();
        }

        initUI();

        return view;
    }

    private void initUI(){
        if (ActiveSession.getInstance().currentUser.firstName != null){
            firstNameText.setText(ActiveSession.getInstance().currentUser.firstName);
        }


        if (ActiveSession.getInstance().currentUser.lastName != null){
            lastNameText.setText(ActiveSession.getInstance().currentUser.lastName);
        }

        if (ActiveSession.getInstance().currentUser.mobileNum != null){
            phoneText.setText(ActiveSession.getInstance().currentUser.mobileNum);
        }

        if (ActiveSession.getInstance().currentUser.email != null){
            emailText.setText(ActiveSession.getInstance().currentUser.email);
        }

    }

    @OnClick(R.id.settings_update_btn) void updateProfile(){

        if (masterActivity != null && !Utils.isNetworkConnected(masterActivity)){
            Toast.makeText(masterActivity, getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);

        String username = firstNameText.getText().toString().trim() + " " + lastNameText.getText().toString().trim();

        String phone = phoneText.getText().toString().trim();
        String email = emailText.getText().toString().trim();
        String userId = String.valueOf(ActiveSession.getInstance().currentUser.id);

//        try {
//            username = URLEncoder.encode(username, "utf-8");
//        } catch (UnsupportedEncodingException e) {
//            e.printStackTrace();
//        }

        JSONObject requestParam = new JSONObject();
        try {
            requestParam.put("userId", ActiveSession.getInstance().currentUser.id);
            requestParam.put("firebaseUID", ActiveSession.getInstance().currentUser.uid);
            requestParam.put("name", username.trim());
            requestParam.put("phone", phone);
            requestParam.put("email", email);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // Create the request body
        RequestBody body = RequestBody.create(okhttp3.MediaType.parse("application/json; charset=utf-8"),
                requestParam.toString());

        KesaaApplication.getKesaaAPI().updateUserCredentials(body)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<JsonObject>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(JsonObject jsonObject) {
                        progressBar.setVisibility(View.GONE);
                        if (jsonObject.get("code").getAsInt() == 200){
                            Log.d(TAG, "User details updated successfully");

                            //
                            ActiveSession.getInstance().currentUser.fullName    = firstNameText.getText().toString().trim() + " " + lastNameText.getText().toString().trim();;
                            ActiveSession.getInstance().currentUser.firstName   = firstNameText.getText().toString().trim();
                            ActiveSession.getInstance().currentUser.lastName    = lastNameText.getText().toString().trim();
                            ActiveSession.getInstance().currentUser.email       = emailText.getText().toString().trim();
                            ActiveSession.getInstance().currentUser.mobileNum   = phoneText.getText().toString().trim();

                            // Save user name
                            MyPreferenceManager.getInstance(masterActivity).put(SettingsKeys.KEY_FULL_NAME, ActiveSession.getInstance().currentUser.fullName);
                            MyPreferenceManager.getInstance(masterActivity).put(SettingsKeys.KEY_EMAIL, ActiveSession.getInstance().currentUser.email);

                            if (masterActivity != null){
                                masterActivity.getUserDetails();

                                // go to home page
                                masterActivity.navController.navigate(R.id.action_settingsProfileFragment_to_styleSelectFragment);
                            }

                        }
                        else{
                            Log.d(TAG, "Failed to update user details : " + jsonObject.get("message").getAsString());

                            // Show error message
                            if (MyPreferenceManager.getInstance(masterActivity).getInt(SettingsKeys.KEY_CURRENT_LANGUAGE) == SettingsKeys.KEY_ENGLISH){
                                Toast.makeText(masterActivity, jsonObject.get("message").getAsString(), Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(masterActivity, jsonObject.get("arabicMessage").getAsString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.d(TAG, "Failed to update user details : " + e.getLocalizedMessage());
                        progressBar.setVisibility(View.GONE);
                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onSettingsFragmentInteraction("");
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onSettingsFragmentInteraction(String data);
    }
}
