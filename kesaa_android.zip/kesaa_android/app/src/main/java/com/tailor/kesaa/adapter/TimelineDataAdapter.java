package com.tailor.kesaa.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.tailor.kesaa.R;
import com.tailor.kesaa.model.TimelineDataElements;

public class TimelineDataAdapter extends RecyclerView.Adapter<TimelineDataAdapter.TimeElementViewHolder> {


    public static final int ORD_RCVD = 0;
    public static final int TLR_VIST = 1;
    public static final int TLR_PROC = 2;
    public static final int ORD_DLVD = 3;


    private Context mContext;
    public int width;
    public int height;
    public int currentState;
    private ArrayList<TimelineDataElements> timelineDataElements;

    public TimelineDataAdapter(Context mContext, ArrayList<TimelineDataElements> timelineDataElements, int width, int height, int currentState) {

        this.currentState = currentState;
        this.width = width;
        this.height = height;
        this.mContext = mContext;
        this.timelineDataElements = timelineDataElements;
    }



    @NonNull
    @Override
    public TimeElementViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.timeline_element_card2, parent, false);

        return new TimeElementViewHolder(itemView, this.width, this.height);
    }

    @Override
    public void onBindViewHolder(@NonNull TimeElementViewHolder holder, int position) {

        //TimelineDataElements currentTimelineElement = timelineDataElements.get(position);

        /*
        holder.iconText.setText(currentTimelineElement.timeLineText);
        holder.checkImg.setImageResource(currentTimelineElement.checkBoxImageResID);
        holder.iconImg.setImageResource(currentTimelineElement.timeLineIcon);
        */


        String timeLineText = timelineDataElements.get(position).timeLineText;


        if (position==0) {
            holder.iconText.setText(timeLineText);
            //holder.checkImg.setImageResource(R.mipmap.green_check);
            holder.iconImg.setImageResource(R.drawable.ordrcv_round);


        } else if (position==1) {
            holder.iconText.setText(timeLineText);
            //holder.checkImg.setImageResource(R.mipmap.green_check);
            holder.iconImg.setImageResource(R.drawable.measure_round);


        } else if (position==2) {

            holder.iconText.setText(timeLineText);
            //holder.checkImg.setImageResource(R.mipmap.green_check);
            holder.iconImg.setImageResource(R.drawable.accept_round);

        } else if (position==3) {
            holder.iconText.setText(timeLineText);
            //holder.checkImg.setImageResource(R.mipmap.green_check);
            holder.iconImg.setImageResource(R.drawable.sewround);

        } else if (position==4) {
            holder.iconText.setText(timeLineText);
            //holder.checkImg.setImageResource(R.mipmap.green_check);
            holder.iconImg.setImageResource(R.drawable.pickup_round);

        } else if (position==5) {
            holder.iconText.setText(timeLineText);
            //holder.checkImg.setImageResource(R.mipmap.green_check);
            holder.iconImg.setImageResource(R.drawable.deliver_round);

        } else {
            holder.iconText.setText("No\nstatus");
            //holder.checkImg.setImageResource(R.mipmap.green_check);
            holder.iconImg.setImageResource(R.drawable.ordrcv_round);
        }




        if (position <= currentState) {
            holder.lineHolder.setBackgroundResource(R.drawable.timeline_solid);
        } else {
            holder.lineHolder.setBackgroundResource(R.drawable.timeline_dash);
        }

        if (position <= currentState) {
            holder.checkImg.setImageResource(R.mipmap.green_check);
        } else {
            holder.checkImg.setImageResource(R.drawable.gold_border_white_circle);
        }


        float alphaLevel = 1.0f;
        if (position <= currentState) {
            alphaLevel = 1.0f;
        } else {
            alphaLevel = 0.2f;
        }
        holder.iconImg.setAlpha(alphaLevel);
        holder.iconText.setAlpha(alphaLevel);

        /*
        if (timelineDataElements.get(position).lineType == 0) {
            holder.lineHolder.setBackgroundResource(R.drawable.timeline_solid);
        } else {
            holder.lineHolder.setBackgroundResource(R.drawable.timeline_dash);
        }


        if (timelineDataElements.get(position).checkType == 0) {
            holder.checkImg.setImageResource(R.drawable.gold_border_white_circle);
        } else {
            holder.checkImg.setImageResource(R.mipmap.green_check);
        }
        */






    }

    @Override
    public int getItemCount() {
        if (timelineDataElements != null) {
            return timelineDataElements.size();
        }else {
            return 0;
        }

    }

    public static class TimeElementViewHolder extends RecyclerView.ViewHolder {
        // each data item is just a string in this case
        public TextView iconText;
        public ImageView checkImg;
        public ImageView iconImg;
        public LinearLayout lineHolder;

        public TimeElementViewHolder(View itemView, int screen_width, int screen_height) {
            super(itemView);

            LinearLayout baseline_card_layout = itemView.findViewById(R.id.timeline_element_layout);
            ViewGroup.LayoutParams lParams = baseline_card_layout.getLayoutParams();
            lParams.width = Math.round(screen_width/4);
            baseline_card_layout.setLayoutParams(lParams );

            iconText = itemView.findViewById(R.id.timeline_text);
            checkImg = itemView.findViewById(R.id.timeline_check_img);
            iconImg = itemView.findViewById(R.id.timeline_icon_img);
            lineHolder = itemView.findViewById(R.id.timeline_element_layout);

        }
    }





}
