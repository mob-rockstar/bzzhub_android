package com.tailor.kesaa;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.net.Uri;
import android.os.Bundle;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
//import com.firebase.ui.auth.AuthUI;
//import com.facebook.login.LoginManager;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.tailor.kesaa.activity.KessaActivity;
import com.tailor.kesaa.activity.LoginActivity;
import com.tailor.kesaa.customs.CustomFontTextView;
import com.tailor.kesaa.customs.TypefaceSpan;
import com.tailor.kesaa.fragment.AddressListFragment;
import com.tailor.kesaa.fragment.CheckOutFragment;
import com.tailor.kesaa.fragment.CustomizeStyleFragment;

import com.tailor.kesaa.fragment.LocationMapperFragment;

import com.tailor.kesaa.fragment.MeasureScheduleFragment;
import com.tailor.kesaa.fragment.NotificationFragment;
import com.tailor.kesaa.fragment.OrderDetailsFragment;
import com.tailor.kesaa.fragment.OrderHistoryFragment;
import com.tailor.kesaa.fragment.OrderReviewFragment;
import com.tailor.kesaa.fragment.SettingsProfileFragment;
import com.tailor.kesaa.fragment.SizeSelectFrag;
import com.tailor.kesaa.fragment.StyleSelectFragment;
import com.tailor.kesaa.fragment.TailorListFragment;
import com.tailor.kesaa.fragment.TailorReviewFragment;
import com.tailor.kesaa.global.EventBusMessage;
import com.tailor.kesaa.global.MyPreferenceManager;
import com.tailor.kesaa.global.SettingsKeys;
import com.tailor.kesaa.global.SettingsManager;
import com.tailor.kesaa.global.Utils;
import com.tailor.kesaa.model.ActiveSession;
import com.tailor.kesaa.model.LocationTemplate;
import com.tailor.kesaa.model.OrderItemTemplate;
import com.tailor.kesaa.model.UserTemplate;

import androidx.annotation.NonNull;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import butterknife.ButterKnife;
import butterknife.OnClick;
import company.tap.gosellapi.open.buttons.PayButtonView;
import company.tap.gosellapi.open.controllers.SDKSession;
import de.hdodenhof.circleimageview.CircleImageView;

import android.text.Spannable;
import android.text.SpannableString;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.greenrobot.eventbus.EventBus;

import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends KessaActivity
        implements NavigationView.OnNavigationItemSelectedListener,
StyleSelectFragment.OnFragmentInteractionListener, SizeSelectFrag.OnFragmentInteractionListener, CustomizeStyleFragment.OnFragmentInteractionListener,
MeasureScheduleFragment.OnFragmentInteractionListener, TailorListFragment.OnFragmentInteractionListener, TailorReviewFragment.OnFragmentInteractionListener,
OrderReviewFragment.OnFragmentInteractionListener, CheckOutFragment.OnFragmentInteractionListener, OrderHistoryFragment.OnFragmentInteractionListener,
LocationMapperFragment.OnFragmentInteractionListener, AddressListFragment.OnFragmentInteractionListener,
OrderDetailsFragment.OnFragmentInteractionListener, NotificationFragment.OnFragmentInteractionListener,
SettingsProfileFragment.OnFragmentInteractionListener {

    public Toolbar toolbar;
    public DrawerLayout drawerLayout;
    public NavController navController;
    public NavigationView navigationView;
    public AppBarConfiguration appBarConfig;
    public ActiveSession currentSession = null;
    public OrderItemTemplate currentOrderItem;
    private SharedPreferences kessaClientSharedPrefs;

    public Context mainContext;

    private String TAG = "MAINACT";

    public int master_screen_width = 0;
    public int master_screen_height = 0;

    private FirebaseAuth mAuth;
    public GoogleSignInClient mGoogleSignInClient;

    //TAP Payment Related Variables
    private final int SDK_REQUEST_CODE = 1001;
    private SDKSession sdkSession;
    public Button payButton;
    public PayButtonView payButtonView;
    private SettingsManager settingsManager;

    // User name
    CustomFontTextView userNameText;

    // User email
    CustomFontTextView userEmailText;

    // User Profile image
    CircleImageView profileImageView;

    private RequestOptions requestOptions;

    // Firebase analytics
    public FirebaseAnalytics mFirebaseAnalytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ButterKnife.bind(this);

        // Obtain the FirebaseAnalytics instance.
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);

        requestOptions = new RequestOptions();
        requestOptions.placeholder(R.drawable.ic_placeholder);
        requestOptions.error(R.drawable.ic_placeholder);


        mainContext = this.getApplicationContext();
        Date currentTime = Calendar.getInstance().getTime();
        currentSession = ActiveSession.getInstance();

        settingsManager = SettingsManager.getInstance();
        settingsManager.setPref(this);


        Display display =  this.getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        master_screen_width = size.x;
        master_screen_height = size.y;

        clearLastSessionDetails();

        setupNavigation();

        loadUserInformation();
    }

    // Get user profile
    private void loadUserInformation(){
        if (currentSession.currentUser == null){
            return;
        }

        // Update the user info in left side menu
        getUserDetails();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);

        if (intent.getScheme().equals("kesaa")) {
            String checkoutId = intent.getData().getQueryParameter("id");

            /* request payment status */
            EventBus.getDefault().post(new EventBusMessage(EventBusMessage.MessageType.HYPERPAY_ASYNC_CALLBACK, checkoutId));
        }
    }

    @Override
    protected void onPause() {

        super.onPause();
        Log.d(TAG,"OnPause Called");
        //saveCurrentStateBeforePause();

    }

    @Override
    protected void onResume() {

        super.onResume();
        reloadStateAfterResume();
        //Log.d(TAG,"OnResume Called");

    }

    @Override
    protected void onStop() {
        super.onStop();  // Always call the superclass method first
        Log.d(TAG,"OnStop");
    }


    public boolean previousLocalUserExits(){
        boolean preUser = false;
        String prev_uuid = getSharedPrefs("SAVED_UUID");

        if (prev_uuid.length() > 0) {
            preUser = true;
            currentSession.currentUser.uid = prev_uuid;
            // if the user exists then grab the database user_id awel
            currentSession.currentUser.id = Integer.parseInt(getSharedPrefs("SAVED_USER_ID"));
            currentSession.session_language = Integer.parseInt(getSharedPrefs("SAVED_LANG_PREF"));
        }

        return preUser;
    }



    public void clearLastSessionDetails(){

        kessaClientSharedPrefs = getSharedPreferences("SESS_DETAILS",
                Context.MODE_PRIVATE);

        kessaClientSharedPrefs.edit().remove("PAUSED_SESSION").commit();
        kessaClientSharedPrefs.edit().remove("PAUSED_ORDER").commit();
        kessaClientSharedPrefs.edit().apply();
    }


    public void clearPreviousDefaultAddress(){
        if (currentSession.currentUser != null ) {
            if (currentSession.currentUser.defaultUserAddressIndex >= 0) {
                currentSession.currentUser.defaultUserAddressIndex = -1;
            }
        }

        for (int i=0;i<currentSession.currentUser.userLocations.size();i++) {
            LocationTemplate curr_location  = currentSession.currentUser.userLocations.get(i);
            if (curr_location.defaultSet) {
                Log.d(TAG, "Changing addr" + Integer.toString(i) + " to default false");
            } else {
                Log.d(TAG, "Addr" + Integer.toString(i) + " was already false");
            }
            curr_location.defaultSet = false;
            currentSession.currentUser.userLocations.set(i, curr_location);
        }
    }

    private void setupNavigation() {

        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_navigation);
        //getSupportActionBar().setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(this, R.color.fui_transparent)));
        //toolbar.setBackgroundColor(Color.parseColor("#00000000"));

        drawerLayout = findViewById(R.id.drawer_layout);
        drawerLayout.addDrawerListener(new DrawerLayout.DrawerListener() {
            @Override
            public void onDrawerSlide(@NonNull View drawerView, float slideOffset) {

            }

            @Override
            public void onDrawerOpened(@NonNull View drawerView) {
                getUserDetails();
            }

            @Override
            public void onDrawerClosed(@NonNull View drawerView) {

            }

            @Override
            public void onDrawerStateChanged(int newState) {

            }
        });
        navigationView = findViewById(R.id.nav_view);
        navController = Navigation.findNavController(this, R.id.nav_host_fragment);

        // Set main screens with menu icon
        Set<Integer> homeScreens = new HashSet<>();
        homeScreens.add(R.id.styleSelectFragment);
        homeScreens.add(R.id.orderHistoryFragment);
        homeScreens.add(R.id.settingsProfileFragment);
        homeScreens.add(R.id.faqFragment);
        homeScreens.add(R.id.contactUsFragment);
        homeScreens.add(R.id.addressesFragment);
        homeScreens.add(R.id.notificationFragment);

        appBarConfig = new AppBarConfiguration.Builder(homeScreens).setDrawerLayout(drawerLayout).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfig);
        //NavigationUI.setupActionBarWithNavController(this, navController, drawerLayout);
        NavigationUI.setupWithNavController(navigationView, navController);

        navigationView.setNavigationItemSelectedListener(this);
    }

    // Get user details
    public void getUserDetails(){

        View headerLayout = navigationView.getHeaderView(0);
        if (headerLayout != null){
            userNameText = (CustomFontTextView) headerLayout.findViewById(R.id.header_user_name_text);
            userEmailText = (CustomFontTextView)headerLayout.findViewById(R.id.header_user_email_text);
            profileImageView = headerLayout.findViewById(R.id.profile_image);

            // User name
            if (ActiveSession.getInstance().currentUser.fullName != null && !ActiveSession.getInstance().currentUser.fullName.equals("")){
                String fullname = ActiveSession.getInstance().currentUser.fullName;
                userNameText.setText(fullname);
            }
            else{
                String fullname = MyPreferenceManager.getInstance(MainActivity.this).getString(SettingsKeys.KEY_FULL_NAME, "");
                userNameText.setText(fullname);
            }

            // Email
            if (ActiveSession.getInstance().currentUser.email != null){
                userEmailText.setText(ActiveSession.getInstance().currentUser.email);
            }
            else{
                String emailAddress = MyPreferenceManager.getInstance(MainActivity.this).getString(SettingsKeys.KEY_EMAIL, "");
                userEmailText.setText(emailAddress);
            }

            // Profile Image
            ActiveSession.getInstance().currentUser.profileImageUrl = MyPreferenceManager.getInstance(MainActivity.this).getString(SettingsKeys.KEY_PROFILE_PICTURE, null);
            if (ActiveSession.getInstance().currentUser.profileImageUrl != null && !ActiveSession.getInstance().currentUser.profileImageUrl.equals("")){
                Glide.with(MainActivity.this).load(ActiveSession.getInstance().currentUser.profileImageUrl).apply(requestOptions).into(profileImageView);
            }
        }

    }

    public String getSharedPrefs(String key_name) {

        String ret_val = "";

        kessaClientSharedPrefs = getSharedPreferences("SESS_DETAILS",
                Context.MODE_PRIVATE);

        if (kessaClientSharedPrefs.contains(key_name)) {
            ret_val =  kessaClientSharedPrefs.getString(key_name, "");
        }

        return ret_val;

    }

    public void setSharePrefs(String key_name, String value) {

        if (kessaClientSharedPrefs == null ) {
            kessaClientSharedPrefs = getSharedPreferences("SESS_DETAILS",
                    Context.MODE_PRIVATE);
        }

        SharedPreferences.Editor editor = kessaClientSharedPrefs.edit();
        editor.putString(key_name, value);
        editor.commit();
    }

    @Override
    public boolean onSupportNavigateUp() {


        //override fun onSupportNavigateUp() = findNavController(R.id.my_nav_host_fragment).navigateUp(appBarConfiguration)
        if (drawerLayout != null) {
            if ( navController.getCurrentDestination().getId() == navController.getGraph().getStartDestination()) {
                drawerLayout.openDrawer(GravityCompat.START);
                return true;
            } else if (navController.getCurrentDestination().getId() == R.id.styleSelectFragment) {
                drawerLayout.openDrawer(GravityCompat.START);
                return  true;
            } else if (navController.getCurrentDestination().getId() == R.id.orderHistoryFragment) {
                drawerLayout.openDrawer(GravityCompat.START);
                return  true;
            } else if (navController.getCurrentDestination().getId() == R.id.settingsProfileFragment) {
                drawerLayout.openDrawer(GravityCompat.START);
                return  true;
            } else if (navController.getCurrentDestination().getId() == R.id.faqFragment) {
                drawerLayout.openDrawer(GravityCompat.START);
                return true;
            }
            else if (navController.getCurrentDestination().getId() == R.id.contactUsFragment) {
                drawerLayout.openDrawer(GravityCompat.START);
                return true;
            }
            else  if (navController.getCurrentDestination().getId() == R.id.addressesFragment){
                drawerLayout.openDrawer(GravityCompat.START);
                return true;
            }
            else if (navController.getCurrentDestination().getId() == R.id.notificationFragment){
                drawerLayout.openDrawer(GravityCompat.START);
                return true;
            }
            else {
                //drawerLayout.closeDrawer(GravityCompat.START);
                return navController.navigateUp();
            }

        }
        else {
            return navController.navigateUp();
        }
    }

    @Override
    public void onBackPressed() {
        // In Order placed page, back button should not work
        if (navController != null){
            if (navController.getCurrentDestination().getId() == R.id.checkOutFragment) {
                return;
            }
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }

        updateToolBarTitle();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.

        int id = item.getItemId();

        if (navigationView != null) {

            if (id == R.id.menu_home) {
                navController.navigate(R.id.styleSelectFragment);
            }
            else if (id == R.id.menu_your_orders) {
                navController.navigate(R.id.orderHistoryFragment);
            }
            else if (id == R.id.menu_notifications) {
                navController.navigate(R.id.notificationFragment);
            }
            else if (id == R.id.menu_settings) {
                navController.navigate(R.id.settingsProfileFragment);
            }
            else if (id == R.id.menu_addresses) {
                navController.navigate(R.id.addressesFragment);
            }
            else if (id == R.id.menu_faq) {
                navController.navigate(R.id.faqFragment);
            }
            else if (id == R.id.menu_contact_us) {
                navController.navigate(R.id.contactUsFragment);
            }
            else if (id == R.id.menu_logout) {
                logout();
            }
            else {

            }

        }

        closeNavigationDrawer();

        return true;
    }

    // English
    @OnClick(R.id.english_layout) void selectedEnglish(){
        closeNavigationDrawer();

        MyPreferenceManager.getInstance(this).put(SettingsKeys.KEY_CURRENT_LANGUAGE, SettingsKeys.KEY_ENGLISH);
        changeLocale("en","US");


        // reload activity
        refreshActivity();

        // post event
        EventBus.getDefault().post(new EventBusMessage(EventBusMessage.MessageType.LANGUAGE_UPDATED));
    }

    // Arabic
    @OnClick(R.id.arabic_layout) void selectedArabic(){
        closeNavigationDrawer();

        MyPreferenceManager.getInstance(this).put(SettingsKeys.KEY_CURRENT_LANGUAGE, SettingsKeys.KEY_ARABIC);
        changeLocale("ar","SA");


        // reload activity
        refreshActivity();

        // post event
        EventBus.getDefault().post(new EventBusMessage(EventBusMessage.MessageType.LANGUAGE_UPDATED));
    }

    // Close the navigation drawer layout
    private void closeNavigationDrawer(){
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
    }

    private void refreshActivity(){
        finish();
        startActivity(getIntent());
    }

    // Update Toolbar Title
    private void updateToolBarTitle(){
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);

        // loop through all toolbar children right after setting support
        // action bar because the text view has no id assigned

        // also make sure that the activity has some title here
        // because calling setText() with an empty string actually
        // removes the text view from the toolbar

        TextView toolbarTitle = null;
        if (toolbar != null){
            for (int i = 0; i < toolbar.getChildCount(); ++i) {
                View child = toolbar.getChildAt(i);

                // assuming that the title is the first instance of TextView
                // you can also check if the title string matches
                if (child instanceof TextView) {
                    toolbarTitle = (TextView)child;
                    Log.d(TAG, "Toolbar Title = " + toolbarTitle.getText().toString());

                    setFragTitle(toolbarTitle.getText().toString());
                    break;
                }
            }
        }

    }

    private void googleSignOut() {
        mGoogleSignInClient.signOut()
                .addOnCompleteListener(this, new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        // ...
                    }
                });
    }

    // Log out
    private void logout(){
        // Check if network is connected
        if (!Utils.isNetworkConnected(this)){
            Toast.makeText(this, getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
            return;
        }

        if (mGoogleSignInClient != null) {
            googleSignOut();
        }

//        FirebaseAuth.getInstance().signOut();

        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        FirebaseAuth.AuthStateListener mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null) {
                    // User is signed in
                    Log.d(TAG, "onAuthStateChanged:signed_in:" + user.getUid());
                } else {
                    // User is signed out
                    Log.d(TAG,"onAuthStateChanged:signed_out");
                    gotoLoginPage();
                }
            }
        };

        mAuth.addAuthStateListener(mAuthListener);

        // Sign Out
        mAuth.signOut();
    }

    // Go to login page
    private void gotoLoginPage(){

        // Logout from facebook
//        LoginManager.getInstance().logOut();

        MyPreferenceManager.getInstance(this).put(SettingsKeys.KEY_FULL_NAME, null);
        MyPreferenceManager.getInstance(this).put(SettingsKeys.KEY_EMAIL, "");
        MyPreferenceManager.getInstance(this).put(SettingsKeys.KEY_IS_LOGGED, false);

        // initialize into null
        ActiveSession.getInstance().currentUser = null;

        Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }


    public void reloadStateAfterResume(){
        // v0 save all the order related parameters (serialized Array) save all the user locations (if any) Serialized Array, then save the current order
        // v1 save the current Session, currentOrder
        Gson sessionGson = new Gson();
        Gson orderGson = new Gson();

        String sessionString    = getSharedPrefs("PAUSED_SESSION");
        String orderString      = getSharedPrefs("PAUSED_ORDER");

        if (sessionString != null) {
            if (sessionString.length() >0) {

                if (sessionGson.fromJson(sessionString, new TypeToken<ActiveSession>(){}.getType()) != null) {
                    currentSession= sessionGson.fromJson(sessionString, new TypeToken<ActiveSession>(){}.getType());
                }
                if (orderGson.fromJson(orderString, new TypeToken<OrderItemTemplate>(){}.getType()) != null) {
                    currentOrderItem = orderGson.fromJson(orderString, new TypeToken<OrderItemTemplate>(){}.getType());
                }
                currentOrderItem.user_id = -1;
            }
        } else {
            Log.d(TAG, "Cannot recover Session from Saved State");



        }

    }

    public void createNewOrderItem() {
        Date currentDate = Calendar.getInstance().getTime();
        currentOrderItem = new OrderItemTemplate(-1, -1, -1, currentDate,
                -1, -1, -1, 1,
                0.0f, 0, "Own", -1
                -1, -1, -1, -1, -1, -1,-1
                -1, -1, -1
                -1,-1,-1,-1,-1,-1,
                currentDate, currentDate,"", -1, -1, "", null);
        currentOrderItem.order_placed_in_cart = false;

    }

    @Override
    public void onCheckoutFragmentInteraction(Uri uri) {

    }

    @Override
    public void onCustomizeStyleFragmentInteraction(Uri uri) {

    }


    @Override
    public void onMeasureScheduleFragmentInteraction(Uri uri) {

    }

    @Override
    public void onOrderReviewFragmentInteraction(Uri uri) {

    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }

    @Override
    public void onStyleSelectFragmentInteraction(String data) {

    }

    @Override
    public void onTailorListFragmentInteraction(Uri uri) {

    }

    @Override
    public void onTailorReviewFragmentInteraction(Uri uri) {

    }

    @Override
    public void setFragTitle(String newTitle){

        SpannableString s = new SpannableString(newTitle);
        s.setSpan(new TypefaceSpan(MainActivity.this, "Tajawal-Bold.ttf"), 0, s.length(),
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        if (getSupportActionBar() != null)
            getSupportActionBar().setTitle(s);
    }

    public void hideActionBar(){getSupportActionBar().hide();}
    public void showActionBar(){getSupportActionBar().show();}


    @Override
    public void onOrderHistoryFragmentInteraction(String data){

    }

    @Override
    public void onLocationMapFragmentInteraction(String data){

    }

    @Override
    public void onAddressFragmentInteraction(int addressMode) {

    }

    @Override
    public void onOrderDetailsFragmentInteraction(String data) {

    }

    @Override
    public void  onNotificationFragmentInteraction(String mode, int order_id) {

    }

    @Override
    public void  onSettingsFragmentInteraction(String data) {

    }


}
